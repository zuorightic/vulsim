`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [31:0] mul_tree_17_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_25; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_26; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_28; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_29; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_30; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_32; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_33; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_34; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_17_35; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_36; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_37; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_38; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_39; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_40; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_41; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_42; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_43; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_50; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_51; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_52; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_54; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_55; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_58; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_59; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_18_60; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_61; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_62; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_63; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_64; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_65; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_66; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_67; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_68; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_72; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_74; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_75; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_76; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_77; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_78; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_79; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_80; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_81; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_82; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_83; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_84; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_19_85; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_86; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_87; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_88; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_89; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_90; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_91; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_92; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_93; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_94; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_96; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_97; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_98; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_100; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_101; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_102; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_104; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_105; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_106; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_108; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_109; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_20_110; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_113; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_114; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_115; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_116; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_119; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_120; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s7; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s7; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_7_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] rtlzz_pipe_8_s4; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] rtlzz_pipe_48_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_56_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_60_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_9_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] rtlzz_pipe_11_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_8Core rtlzz_owner_8(.a(64'(rtlzz_pipe_7_s3)), .b(64'(rtlzz_pipe_4_s3)), .cin(1'b0), .value(s8_norm_add_2_v0));
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_10Core rtlzz_owner_10(.a(64'(rtlzz_pipe_9_s6)), .b(64'(rtlzz_pipe_3_s6)), .cin(1'b0), .value(s8_norm_add_5_v0));
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_12Core rtlzz_owner_12(.a(64'(rtlzz_pipe_11_s7)), .b(64'(rtlzz_pipe_2_s7)), .cin(1'b0), .value(s8_norm_add_8_v0));
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_14_reduce rtlzz_reduce_14(.i98(mul_tree_20_98), .i101(mul_tree_20_101), .i105(mul_tree_20_105), .i134(rtlzz_pipe_1_s7), .y(s8_norm_add_11_v0));
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign arith_original_17 = mul_tree_17_45; // decl: <none>; prim: <none>
    assign arith_original_18 = mul_tree_18_70; // decl: <none>; prim: <none>
    assign arith_original_19 = mul_tree_19_95; // decl: <none>; prim: <none>
    assign arith_original_20 = mul_tree_20_120; // decl: <none>; prim: <none>
    assign mul_tree_17_21 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_22 = x[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(32'(mul_tree_17_21)), .b(32'(mul_tree_17_22)), .cin(1'b0), .value(mul_tree_17_23));
    assign mul_tree_17_24 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_25 = x[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(32'(mul_tree_17_24)), .b(32'(mul_tree_17_25)), .cin(1'b0), .value(mul_tree_17_26[31:0]));
    assign mul_tree_17_26[63:32] = '0;
    assign mul_tree_17_27 = {mul_tree_17_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_28 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_29 = x[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(32'(mul_tree_17_28)), .b(32'(mul_tree_17_29)), .cin(1'b0), .value(mul_tree_17_30[31:0]));
    assign mul_tree_17_30[63:32] = '0;
    assign mul_tree_17_31 = {mul_tree_17_30, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_32 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_33 = x[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_34 = 64'(($unsigned(64'($unsigned(mul_tree_17_32))) * $unsigned(64'($unsigned(mul_tree_17_33))))); // decl: <none>; prim: <none>
    assign mul_tree_17_35 = {mul_tree_17_34, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_36 = ({33'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_37 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(64'(mul_tree_17_36)), .b(96'(mul_tree_17_37)), .cin(1'h0), .value(mul_tree_17_38[63:0]));
    assign mul_tree_17_38[96:64] = '0;
    assign mul_tree_17_39 = ({33'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_40 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_41Core rtlzz_owner_41(.a(96'(mul_tree_17_39)), .b(128'(mul_tree_17_40)), .cin(1'h0), .value(mul_tree_17_41[63:0]));
    assign mul_tree_17_41[128:64] = '0;
    assign mul_tree_17_42 = ({33'h0, rtlzz_pipe_38_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_43 = ({1'h0, rtlzz_pipe_41_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(97'(mul_tree_17_42)), .b(129'(mul_tree_17_43)), .cin(1'h0), .value(mul_tree_17_44[63:0]));
    assign mul_tree_17_44[129:64] = '0;
    assign mul_tree_17_45 = mul_tree_17_44[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_46 = rtlzz_pipe_8_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_47 = rtlzz_pipe_0_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_18_46)), .b(32'(mul_tree_18_47)), .cin(1'b0), .value(mul_tree_18_48));
    assign mul_tree_18_49 = rtlzz_pipe_8_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_50 = rtlzz_pipe_0_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(32'(mul_tree_18_49)), .b(32'(mul_tree_18_50)), .cin(1'b0), .value(mul_tree_18_51[31:0]));
    assign mul_tree_18_51[63:32] = '0;
    assign mul_tree_18_52 = {mul_tree_18_51, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_53 = rtlzz_pipe_8_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_54 = rtlzz_pipe_0_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_55Core rtlzz_owner_55(.a(32'(mul_tree_18_53)), .b(32'(mul_tree_18_54)), .cin(1'b0), .value(mul_tree_18_55[31:0]));
    assign mul_tree_18_55[63:32] = '0;
    assign mul_tree_18_56 = {mul_tree_18_55, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_57 = rtlzz_pipe_8_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_58 = rtlzz_pipe_0_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_59 = 64'(($unsigned(64'($unsigned(mul_tree_18_57))) * $unsigned(64'($unsigned(mul_tree_18_58))))); // decl: <none>; prim: <none>
    assign mul_tree_18_60 = {mul_tree_18_59, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_61 = ({33'h0, rtlzz_pipe_48_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_62 = ({1'h0, rtlzz_pipe_52_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_64 = ({33'h0, rtlzz_pipe_56_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_65 = ({1'h0, rtlzz_pipe_60_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_67 = ({33'h0, mul_tree_18_63}); // decl: <none>; prim: <none>
    assign mul_tree_18_68 = ({1'h0, mul_tree_18_66}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_69_reduce rtlzz_reduce_69(.i159(rtlzz_pipe_48_s5), .i160(rtlzz_pipe_52_s5), .i161(rtlzz_pipe_56_s5), .y(mul_tree_18_69));
    assign mul_tree_18_70 = mul_tree_18_69[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_71 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_72 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(32'(mul_tree_19_71)), .b(32'(mul_tree_19_72)), .cin(1'b0), .value(mul_tree_19_73));
    assign mul_tree_19_74 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_75 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(32'(mul_tree_19_74)), .b(32'(mul_tree_19_75)), .cin(1'b0), .value(mul_tree_19_76[31:0]));
    assign mul_tree_19_76[63:32] = '0;
    assign mul_tree_19_77 = {mul_tree_19_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_78 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_79 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(32'(mul_tree_19_78)), .b(32'(mul_tree_19_79)), .cin(1'b0), .value(mul_tree_19_80[31:0]));
    assign mul_tree_19_80[63:32] = '0;
    assign mul_tree_19_81 = {mul_tree_19_80, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_82 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_83 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_84 = 64'(($unsigned(64'($unsigned(mul_tree_19_82))) * $unsigned(64'($unsigned(mul_tree_19_83))))); // decl: <none>; prim: <none>
    assign mul_tree_19_85 = {mul_tree_19_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_86 = ({33'h0, mul_tree_19_73}); // decl: <none>; prim: <none>
    assign mul_tree_19_87 = ({1'h0, mul_tree_19_77}); // decl: <none>; prim: <none>
    assign mul_tree_19_89 = ({33'h0, mul_tree_19_81}); // decl: <none>; prim: <none>
    assign mul_tree_19_90 = ({1'h0, mul_tree_19_85}); // decl: <none>; prim: <none>
    assign mul_tree_19_92 = ({33'h0, mul_tree_19_88}); // decl: <none>; prim: <none>
    assign mul_tree_19_93 = ({1'h0, mul_tree_19_91}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94_reduce rtlzz_reduce_94(.i73(mul_tree_19_73), .i76(mul_tree_19_76), .i80(mul_tree_19_80), .y(mul_tree_19_94));
    assign mul_tree_19_95 = mul_tree_19_94[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_96 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_97 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_20_96)), .b(32'(mul_tree_20_97)), .cin(1'b0), .value(mul_tree_20_98));
    assign mul_tree_20_99 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_100 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_101Core rtlzz_owner_101(.a(32'(mul_tree_20_99)), .b(32'(mul_tree_20_100)), .cin(1'b0), .value(mul_tree_20_101[31:0]));
    assign mul_tree_20_101[63:32] = '0;
    assign mul_tree_20_102 = {mul_tree_20_101, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_103 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_104 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105Core rtlzz_owner_105(.a(32'(mul_tree_20_103)), .b(32'(mul_tree_20_104)), .cin(1'b0), .value(mul_tree_20_105[31:0]));
    assign mul_tree_20_105[63:32] = '0;
    assign mul_tree_20_106 = {mul_tree_20_105, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_107 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_108 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_109 = 64'(($unsigned(64'($unsigned(mul_tree_20_107))) * $unsigned(64'($unsigned(mul_tree_20_108))))); // decl: <none>; prim: <none>
    assign mul_tree_20_110 = {mul_tree_20_109, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_111 = ({33'h0, mul_tree_20_98}); // decl: <none>; prim: <none>
    assign mul_tree_20_112 = ({1'h0, mul_tree_20_102}); // decl: <none>; prim: <none>
    assign mul_tree_20_114 = ({33'h0, mul_tree_20_106}); // decl: <none>; prim: <none>
    assign mul_tree_20_115 = ({1'h0, mul_tree_20_110}); // decl: <none>; prim: <none>
    assign mul_tree_20_117 = ({33'h0, mul_tree_20_113}); // decl: <none>; prim: <none>
    assign mul_tree_20_118 = ({1'h0, mul_tree_20_116}); // decl: <none>; prim: <none>
    assign mul_tree_20_120 = mul_tree_20_119[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_1_s1 <= 64'h0;
            rtlzz_pipe_1_s2 <= 64'h0;
            rtlzz_pipe_1_s3 <= 64'h0;
            rtlzz_pipe_1_s4 <= 64'h0;
            rtlzz_pipe_1_s5 <= 64'h0;
            rtlzz_pipe_1_s6 <= 64'h0;
            rtlzz_pipe_1_s7 <= 64'h0;
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_2_s3 <= 64'h0;
            rtlzz_pipe_2_s4 <= 64'h0;
            rtlzz_pipe_2_s5 <= 64'h0;
            rtlzz_pipe_2_s6 <= 64'h0;
            rtlzz_pipe_2_s7 <= 64'h0;
            rtlzz_pipe_3_s1 <= 64'h0;
            rtlzz_pipe_3_s2 <= 64'h0;
            rtlzz_pipe_3_s3 <= 64'h0;
            rtlzz_pipe_3_s4 <= 64'h0;
            rtlzz_pipe_3_s5 <= 64'h0;
            rtlzz_pipe_3_s6 <= 64'h0;
            rtlzz_pipe_4_s1 <= 64'h0;
            rtlzz_pipe_4_s2 <= 64'h0;
            rtlzz_pipe_4_s3 <= 64'h0;
            rtlzz_pipe_23_s1 <= 64'h0;
            rtlzz_pipe_27_s1 <= 96'h0;
            rtlzz_pipe_31_s1 <= 96'h0;
            rtlzz_pipe_35_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 97'h0;
            rtlzz_pipe_41_s2 <= 129'h0;
            rtlzz_pipe_7_s3 <= 64'h0;
            rtlzz_pipe_8_s4 <= 64'h0;
            rtlzz_pipe_48_s5 <= 64'h0;
            rtlzz_pipe_52_s5 <= 96'h0;
            rtlzz_pipe_56_s5 <= 96'h0;
            rtlzz_pipe_60_s5 <= 128'h0;
            rtlzz_pipe_9_s6 <= 64'h0;
            rtlzz_pipe_11_s7 <= 64'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_1_s1 <= c0; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1_s2 <= rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1_s3 <= rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1_s4 <= rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1_s5 <= rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1_s6 <= rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1_s7 <= rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (iv) begin
        rtlzz_pipe_2_s1 <= c1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_2_s3 <= rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_2_s4 <= rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_2_s5 <= rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_2_s6 <= rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_2_s7 <= rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= c2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_3_s2 <= rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_3_s4 <= rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_3_s5 <= rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_3_s6 <= rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= c3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_4_s3 <= rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_17_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_17_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_17_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_17_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= mul_tree_17_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= mul_tree_17_41; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_8_s4 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_48_s5 <= mul_tree_18_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= mul_tree_18_52; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_56_s5 <= mul_tree_18_56; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_60_s5 <= mul_tree_18_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_9_s6 <= s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_11_s7 <= s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14_reduce(input wire [63:0] i98, input wire [63:0] i101, input wire [63:0] i105, input wire [63:0] i134, output wire [63:0] y);
wire [63:0] t0 = {i98[63], i98[62], i98[61], i98[60], i98[59], i98[58], i98[57], i98[56], i98[55], i98[54], i98[53], i98[52], i98[51], i98[50], i98[49], i98[48], i98[47], i98[46], i98[45], i98[44], i98[43], i98[42], i98[41], i98[40], i98[39], i98[38], i98[37], i98[36], i98[35], i98[34], i98[33], i98[32], i98[31], i98[30], i98[29], i98[28], i98[27], i98[26], i98[25], i98[24], i98[23], i98[22], i98[21], i98[20], i98[19], i98[18], i98[17], i98[16], i98[15], i98[14], i98[13], i98[12], i98[11], i98[10], i98[9], i98[8], i98[7], i98[6], i98[5], i98[4], i98[3], i98[2], i98[1], i98[0]};
wire [63:0] t1 = {i101[31], i101[30], i101[29], i101[28], i101[27], i101[26], i101[25], i101[24], i101[23], i101[22], i101[21], i101[20], i101[19], i101[18], i101[17], i101[16], i101[15], i101[14], i101[13], i101[12], i101[11], i101[10], i101[9], i101[8], i101[7], i101[6], i101[5], i101[4], i101[3], i101[2], i101[1], i101[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i105[31], i105[30], i105[29], i105[28], i105[27], i105[26], i105[25], i105[24], i105[23], i105[22], i105[21], i105[20], i105[19], i105[18], i105[17], i105[16], i105[15], i105[14], i105[13], i105[12], i105[11], i105[10], i105[9], i105[8], i105[7], i105[6], i105[5], i105[4], i105[3], i105[2], i105[1], i105[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i134[63], i134[62], i134[61], i134[60], i134[59], i134[58], i134[57], i134[56], i134[55], i134[54], i134[53], i134[52], i134[51], i134[50], i134[49], i134[48], i134[47], i134[46], i134[45], i134[44], i134[43], i134[42], i134[41], i134[40], i134[39], i134[38], i134[37], i134[36], i134[35], i134[34], i134[33], i134[32], i134[31], i134[30], i134[29], i134[28], i134[27], i134[26], i134[25], i134[24], i134[23], i134[22], i134[21], i134[20], i134[19], i134[18], i134[17], i134[16], i134[15], i134[14], i134[13], i134[12], i134[11], i134[10], i134[9], i134[8], i134[7], i134[6], i134[5], i134[4], i134[3], i134[2], i134[1], i134[0]};
wire [63:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69_reduce(input wire [63:0] i159, input wire [95:0] i160, input wire [95:0] i161, output wire [129:0] y);
wire [63:0] t0 = {i159[63], i159[62], i159[61], i159[60], i159[59], i159[58], i159[57], i159[56], i159[55], i159[54], i159[53], i159[52], i159[51], i159[50], i159[49], i159[48], i159[47], i159[46], i159[45], i159[44], i159[43], i159[42], i159[41], i159[40], i159[39], i159[38], i159[37], i159[36], i159[35], i159[34], i159[33], i159[32], i159[31], i159[30], i159[29], i159[28], i159[27], i159[26], i159[25], i159[24], i159[23], i159[22], i159[21], i159[20], i159[19], i159[18], i159[17], i159[16], i159[15], i159[14], i159[13], i159[12], i159[11], i159[10], i159[9], i159[8], i159[7], i159[6], i159[5], i159[4], i159[3], i159[2], i159[1], i159[0]};
wire [63:0] t1 = {i160[63], i160[62], i160[61], i160[60], i160[59], i160[58], i160[57], i160[56], i160[55], i160[54], i160[53], i160[52], i160[51], i160[50], i160[49], i160[48], i160[47], i160[46], i160[45], i160[44], i160[43], i160[42], i160[41], i160[40], i160[39], i160[38], i160[37], i160[36], i160[35], i160[34], i160[33], i160[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i161[63], i161[62], i161[61], i161[60], i161[59], i161[58], i161[57], i161[56], i161[55], i161[54], i161[53], i161[52], i161[51], i161[50], i161[49], i161[48], i161[47], i161[46], i161[45], i161[44], i161[43], i161[42], i161[41], i161[40], i161[39], i161[38], i161[37], i161[36], i161[35], i161[34], i161[33], i161[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94_reduce(input wire [63:0] i73, input wire [63:0] i76, input wire [63:0] i80, output wire [129:0] y);
wire [63:0] t0 = {i73[63], i73[62], i73[61], i73[60], i73[59], i73[58], i73[57], i73[56], i73[55], i73[54], i73[53], i73[52], i73[51], i73[50], i73[49], i73[48], i73[47], i73[46], i73[45], i73[44], i73[43], i73[42], i73[41], i73[40], i73[39], i73[38], i73[37], i73[36], i73[35], i73[34], i73[33], i73[32], i73[31], i73[30], i73[29], i73[28], i73[27], i73[26], i73[25], i73[24], i73[23], i73[22], i73[21], i73[20], i73[19], i73[18], i73[17], i73[16], i73[15], i73[14], i73[13], i73[12], i73[11], i73[10], i73[9], i73[8], i73[7], i73[6], i73[5], i73[4], i73[3], i73[2], i73[1], i73[0]};
wire [63:0] t1 = {i76[31], i76[30], i76[29], i76[28], i76[27], i76[26], i76[25], i76[24], i76[23], i76[22], i76[21], i76[20], i76[19], i76[18], i76[17], i76[16], i76[15], i76[14], i76[13], i76[12], i76[11], i76[10], i76[9], i76[8], i76[7], i76[6], i76[5], i76[4], i76[3], i76[2], i76[1], i76[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i80[31], i80[30], i80[29], i80[28], i80[27], i80[26], i80[25], i80[24], i80[23], i80[22], i80[21], i80[20], i80[19], i80[18], i80[17], i80[16], i80[15], i80[14], i80[13], i80[12], i80[11], i80[10], i80[9], i80[8], i80[7], i80[6], i80[5], i80[4], i80[3], i80[2], i80[1], i80[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_8Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_8();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [63:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
