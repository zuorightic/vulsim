`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [31:0] mul_tree_130_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_160; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_161; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_162; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_163; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_164; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_165; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_166; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_167; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_168; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_169; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_170; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_172; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_174; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_175; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_176; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_177; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_179; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_180; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_181; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_182; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_183; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_184; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_185; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_186; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_187; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_188; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_189; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_190; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_191; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_192; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_193; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_194; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_196; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_197; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_198; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_200; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_201; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_202; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_204; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_205; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_208; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_209; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_210; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_211; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_212; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_213; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_214; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_215; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_216; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_217; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_218; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_219; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_220; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_221; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_222; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_224; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_225; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_226; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_228; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_229; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_230; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_232; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_233; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_234; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_235; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_236; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_237; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_238; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_239; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_240; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_241; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_242; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_243; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_244; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_245; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_246; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_247; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_248; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_249; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_250; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_251; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_252; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_253; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_254; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_255; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_256; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_257; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_258; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_259; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_260; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_261; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_262; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_263; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_264; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_265; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_266; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_267; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_268; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_269; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_270; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_271; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_272; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_273; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_274; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_275; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_276; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_277; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_278; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_279; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_280; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_281; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_282; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_283; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_284; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_285; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_286; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_287; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_288; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_289; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_290; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_291; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_292; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_293; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_294; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_295; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_296; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_297; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_298; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_299; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_300; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_301; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_302; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_303; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_304; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_305; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_306; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_307; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_308; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_309; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_310; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_311; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_312; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_313; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_314; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_315; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_316; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_317; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_318; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_319; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_320; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_321; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_322; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_323; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_324; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_325; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_326; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_327; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_328; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_329; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_330; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_331; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_332; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_333; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_334; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_335; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_336; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_337; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_338; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_339; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_340; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_341; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_342; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_343; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_344; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_345; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_346; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_347; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_348; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_349; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_350; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_351; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_352; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_353; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_354; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_355; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_356; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_357; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_358; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_359; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_360; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_361; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_362; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_363; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_364; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_365; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_366; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_367; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_368; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_369; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_373; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_374; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_375; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_376; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_377; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_378; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_379; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_380; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_381; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_382; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_383; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_384; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_385; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_386; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_387; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_388; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_389; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_390; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_391; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_392; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_393; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_394; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_398; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_399; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_400; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_401; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_402; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_403; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_404; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_405; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_406; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_407; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_408; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_409; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_410; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_411; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_412; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_413; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_414; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_415; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_416; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_417; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_418; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_419; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_420; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_421; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_422; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_423; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_424; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_425; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_426; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_427; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_428; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_429; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_430; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_431; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_432; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_433; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_434; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_435; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_436; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_437; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_438; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_439; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_440; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_441; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_442; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_443; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_444; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_446; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_447; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_448; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_449; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_450; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_451; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_452; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_453; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_454; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_455; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_456; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_457; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_458; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_459; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_460; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_461; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_462; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_463; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_464; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_465; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_466; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_467; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_468; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_469; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_471; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_472; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_476; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_477; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_478; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_479; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_480; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_481; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_482; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_483; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_484; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_485; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_486; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_487; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_488; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_489; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_490; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_491; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_492; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_493; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_494; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_496; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_497; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_501; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_502; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_503; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_504; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_505; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_506; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_507; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_508; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_509; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_510; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_511; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_512; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_513; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_514; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_515; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_516; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_517; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_518; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_519; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_521; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_522; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_523; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_524; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_525; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_526; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_527; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_528; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_529; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_530; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_531; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_532; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_533; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_534; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_535; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_536; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_537; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_538; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_539; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_540; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_541; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_542; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_543; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_544; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_545; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_156_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_160_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_166_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [63:0] rtlzz_pipe_173_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_177_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_181_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_185_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_188_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [63:0] rtlzz_pipe_198_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_202_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_206_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_210_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_223_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_227_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_231_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_235_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_238_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_241_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_36_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [63:0] rtlzz_pipe_248_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_252_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_256_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_260_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_263_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_263_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_277_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_281_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_288_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_291_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [63:0] rtlzz_pipe_298_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_302_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_306_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_310_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_313_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_316_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_327_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_331_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_335_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_338_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_341_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_40_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] rtlzz_pipe_40_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] rtlzz_pipe_40_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [128:0] rtlzz_pipe_52_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [129:0] rtlzz_pipe_58_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [96:0] rtlzz_pipe_363_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_366_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_41_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [63:0] rtlzz_pipe_373_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_377_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_381_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_385_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_42_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] rtlzz_pipe_42_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] rtlzz_pipe_42_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] rtlzz_pipe_42_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [128:0] rtlzz_pipe_53_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [63:0] rtlzz_pipe_398_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_402_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_406_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_410_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_43_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [63:0] rtlzz_pipe_423_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_427_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_431_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_435_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_438_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [128:0] rtlzz_pipe_54_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [96:0] rtlzz_pipe_463_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_466_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_473_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_477_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_481_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_485_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_488_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_491_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_46_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] rtlzz_pipe_46_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [128:0] rtlzz_pipe_55_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] rtlzz_pipe_55_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] rtlzz_pipe_55_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [63:0] rtlzz_pipe_498_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_502_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_506_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_510_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_513_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_516_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_523_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_523_s2; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_527_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_527_s2; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_531_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_531_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_535_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_535_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_538_s3; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_538_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_541_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_541_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_48_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(128'(rtlzz_pipe_33_s5)), .b(128'(s8_norm_mul_6_v0)), .cin(1'b0), .value(s8_norm_add_64_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(128'(s8_norm_mul_26_v0)), .b(128'(rtlzz_pipe_40_s5)), .cin(1'b0), .value(s8_norm_add_67_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(128'(rtlzz_pipe_41_s6)), .b(128'(rtlzz_pipe_42_s6)), .cin(1'b0), .value(s8_norm_add_68_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(128'(rtlzz_pipe_43_s6)), .b(128'(rtlzz_pipe_44_s6)), .cin(1'b0), .value(s8_norm_add_69_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_55Core rtlzz_owner_55(.a(128'(s8_norm_mul_50_v0)), .b(128'(rtlzz_pipe_46_s4)), .cin(1'b0), .value(s8_norm_add_70_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58_reduce rtlzz_reduce_58(.i269(mul_tree_134_269), .i655(rtlzz_pipe_38_s6), .i671(rtlzz_pipe_52_s6), .y(s8_norm_add_73_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63_reduce rtlzz_reduce_63(.i219(mul_tree_132_219), .i519(mul_tree_144_519), .i622(rtlzz_pipe_49_s7), .i637(rtlzz_pipe_36_s7), .i672(rtlzz_pipe_58_s7), .i687(rtlzz_pipe_53_s7), .i703(rtlzz_pipe_54_s7), .i716(rtlzz_pipe_55_s7), .i737(rtlzz_pipe_48_s7), .y(s8_norm_add_78_v0));
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    assign arith_original_130 = mul_tree_130_170; // decl: <none>; prim: <none>
    assign arith_original_131 = mul_tree_131_195; // decl: <none>; prim: <none>
    assign arith_original_132 = mul_tree_132_220; // decl: <none>; prim: <none>
    assign arith_original_133 = mul_tree_133_245; // decl: <none>; prim: <none>
    assign arith_original_134 = mul_tree_134_270; // decl: <none>; prim: <none>
    assign arith_original_135 = mul_tree_135_295; // decl: <none>; prim: <none>
    assign arith_original_136 = mul_tree_136_320; // decl: <none>; prim: <none>
    assign arith_original_137 = mul_tree_137_345; // decl: <none>; prim: <none>
    assign arith_original_138 = mul_tree_138_370; // decl: <none>; prim: <none>
    assign arith_original_139 = mul_tree_139_395; // decl: <none>; prim: <none>
    assign arith_original_140 = mul_tree_140_420; // decl: <none>; prim: <none>
    assign arith_original_141 = mul_tree_141_445; // decl: <none>; prim: <none>
    assign arith_original_142 = mul_tree_142_470; // decl: <none>; prim: <none>
    assign arith_original_143 = mul_tree_143_495; // decl: <none>; prim: <none>
    assign arith_original_144 = mul_tree_144_520; // decl: <none>; prim: <none>
    assign arith_original_145 = mul_tree_145_545; // decl: <none>; prim: <none>
    assign mul_tree_130_146 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_147 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_130_146)), .b(32'(mul_tree_130_147)), .cin(1'b0), .value(mul_tree_130_148));
    assign mul_tree_130_149 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_150 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_130_149)), .b(32'(mul_tree_130_150)), .cin(1'b0), .value(mul_tree_130_151));
    assign mul_tree_130_152 = {mul_tree_130_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_153 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_154 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_130_153)), .b(32'(mul_tree_130_154)), .cin(1'b0), .value(mul_tree_130_155));
    assign mul_tree_130_156 = {mul_tree_130_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_157 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_158 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_130_157)), .b(32'(mul_tree_130_158)), .cin(1'b0), .value(mul_tree_130_159));
    assign mul_tree_130_160 = {mul_tree_130_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_161 = ({33'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_162 = ({1'h0, rtlzz_pipe_152_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(64'(mul_tree_130_161)), .b(96'(mul_tree_130_162)), .cin(1'h0), .value(mul_tree_130_163));
    assign mul_tree_130_164 = ({33'h0, rtlzz_pipe_156_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_165 = ({1'h0, rtlzz_pipe_160_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(96'(mul_tree_130_164)), .b(128'(mul_tree_130_165)), .cin(1'h0), .value(mul_tree_130_166[127:0]));
    assign mul_tree_130_166[128:128] = '0;
    assign mul_tree_130_167 = ({33'h0, rtlzz_pipe_163_s2}); // decl: <none>; prim: <none>
    assign mul_tree_130_168 = ({1'h0, rtlzz_pipe_166_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_169Core rtlzz_owner_169(.a(97'(mul_tree_130_167)), .b(129'(mul_tree_130_168)), .cin(1'h0), .value(mul_tree_130_169[127:0]));
    assign mul_tree_130_169[129:128] = '0;
    assign mul_tree_130_170 = mul_tree_130_169[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_171 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_172 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_173Core rtlzz_owner_173(.a(32'(mul_tree_131_171)), .b(32'(mul_tree_131_172)), .cin(1'b0), .value(mul_tree_131_173));
    assign mul_tree_131_174 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_175 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(32'(mul_tree_131_174)), .b(32'(mul_tree_131_175)), .cin(1'b0), .value(mul_tree_131_176));
    assign mul_tree_131_177 = {mul_tree_131_176, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_178 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_179 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(32'(mul_tree_131_178)), .b(32'(mul_tree_131_179)), .cin(1'b0), .value(mul_tree_131_180));
    assign mul_tree_131_181 = {mul_tree_131_180, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_182 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_183 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(32'(mul_tree_131_182)), .b(32'(mul_tree_131_183)), .cin(1'b0), .value(mul_tree_131_184));
    assign mul_tree_131_185 = {mul_tree_131_184, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_186 = ({33'h0, rtlzz_pipe_173_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_187 = ({1'h0, rtlzz_pipe_177_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(64'(mul_tree_131_186)), .b(96'(mul_tree_131_187)), .cin(1'h0), .value(mul_tree_131_188));
    assign mul_tree_131_189 = ({33'h0, rtlzz_pipe_181_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_190 = ({1'h0, rtlzz_pipe_185_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_191Core rtlzz_owner_191(.a(96'(mul_tree_131_189)), .b(128'(mul_tree_131_190)), .cin(1'h0), .value(mul_tree_131_191[127:0]));
    assign mul_tree_131_191[128:128] = '0;
    assign mul_tree_131_192 = ({33'h0, rtlzz_pipe_188_s5}); // decl: <none>; prim: <none>
    assign mul_tree_131_193 = ({1'h0, rtlzz_pipe_191_s5}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(97'(mul_tree_131_192)), .b(129'(mul_tree_131_193)), .cin(1'h0), .value(mul_tree_131_194[127:0]));
    assign mul_tree_131_194[129:128] = '0;
    assign mul_tree_131_195 = mul_tree_131_194[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_196 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_197 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(32'(mul_tree_132_196)), .b(32'(mul_tree_132_197)), .cin(1'b0), .value(mul_tree_132_198));
    assign mul_tree_132_199 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_200 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(32'(mul_tree_132_199)), .b(32'(mul_tree_132_200)), .cin(1'b0), .value(mul_tree_132_201));
    assign mul_tree_132_202 = {mul_tree_132_201, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_203 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_204 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_205Core rtlzz_owner_205(.a(32'(mul_tree_132_203)), .b(32'(mul_tree_132_204)), .cin(1'b0), .value(mul_tree_132_205));
    assign mul_tree_132_206 = {mul_tree_132_205, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_207 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_208 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_209Core rtlzz_owner_209(.a(32'(mul_tree_132_207)), .b(32'(mul_tree_132_208)), .cin(1'b0), .value(mul_tree_132_209));
    assign mul_tree_132_210 = {mul_tree_132_209, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_211 = ({33'h0, rtlzz_pipe_198_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_212 = ({1'h0, rtlzz_pipe_202_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_214 = ({33'h0, rtlzz_pipe_206_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_215 = ({1'h0, rtlzz_pipe_210_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_217 = ({33'h0, mul_tree_132_213}); // decl: <none>; prim: <none>
    assign mul_tree_132_218 = ({1'h0, mul_tree_132_216}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_219_reduce rtlzz_reduce_219(.i623(rtlzz_pipe_198_s7), .i624(rtlzz_pipe_202_s7), .i625(rtlzz_pipe_206_s7), .i626(rtlzz_pipe_210_s7), .y(mul_tree_132_219));
    assign mul_tree_132_220 = mul_tree_132_219[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_221 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_222 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223Core rtlzz_owner_223(.a(32'(mul_tree_133_221)), .b(32'(mul_tree_133_222)), .cin(1'b0), .value(mul_tree_133_223));
    assign mul_tree_133_224 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_225 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(32'(mul_tree_133_224)), .b(32'(mul_tree_133_225)), .cin(1'b0), .value(mul_tree_133_226));
    assign mul_tree_133_227 = {mul_tree_133_226, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_228 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_229 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(32'(mul_tree_133_228)), .b(32'(mul_tree_133_229)), .cin(1'b0), .value(mul_tree_133_230));
    assign mul_tree_133_231 = {mul_tree_133_230, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_232 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_233 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(32'(mul_tree_133_232)), .b(32'(mul_tree_133_233)), .cin(1'b0), .value(mul_tree_133_234));
    assign mul_tree_133_235 = {mul_tree_133_234, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_236 = ({33'h0, rtlzz_pipe_223_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_237 = ({1'h0, rtlzz_pipe_227_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(64'(mul_tree_133_236)), .b(96'(mul_tree_133_237)), .cin(1'h0), .value(mul_tree_133_238));
    assign mul_tree_133_239 = ({33'h0, rtlzz_pipe_231_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_240 = ({1'h0, rtlzz_pipe_235_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_241Core rtlzz_owner_241(.a(96'(mul_tree_133_239)), .b(128'(mul_tree_133_240)), .cin(1'h0), .value(mul_tree_133_241[127:0]));
    assign mul_tree_133_241[128:128] = '0;
    assign mul_tree_133_242 = ({33'h0, rtlzz_pipe_238_s2}); // decl: <none>; prim: <none>
    assign mul_tree_133_243 = ({1'h0, rtlzz_pipe_241_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(97'(mul_tree_133_242)), .b(129'(mul_tree_133_243)), .cin(1'h0), .value(mul_tree_133_244[127:0]));
    assign mul_tree_133_244[129:128] = '0;
    assign mul_tree_133_245 = mul_tree_133_244[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_246 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_247 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(32'(mul_tree_134_246)), .b(32'(mul_tree_134_247)), .cin(1'b0), .value(mul_tree_134_248));
    assign mul_tree_134_249 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_250 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_251Core rtlzz_owner_251(.a(32'(mul_tree_134_249)), .b(32'(mul_tree_134_250)), .cin(1'b0), .value(mul_tree_134_251));
    assign mul_tree_134_252 = {mul_tree_134_251, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_253 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_254 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_255Core rtlzz_owner_255(.a(32'(mul_tree_134_253)), .b(32'(mul_tree_134_254)), .cin(1'b0), .value(mul_tree_134_255));
    assign mul_tree_134_256 = {mul_tree_134_255, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_257 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_258 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_259Core rtlzz_owner_259(.a(32'(mul_tree_134_257)), .b(32'(mul_tree_134_258)), .cin(1'b0), .value(mul_tree_134_259));
    assign mul_tree_134_260 = {mul_tree_134_259, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_261 = ({33'h0, rtlzz_pipe_248_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_262 = ({1'h0, rtlzz_pipe_252_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_263Core rtlzz_owner_263(.a(64'(mul_tree_134_261)), .b(96'(mul_tree_134_262)), .cin(1'h0), .value(mul_tree_134_263));
    assign mul_tree_134_264 = ({33'h0, rtlzz_pipe_256_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_265 = ({1'h0, rtlzz_pipe_260_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_266Core rtlzz_owner_266(.a(96'(mul_tree_134_264)), .b(128'(mul_tree_134_265)), .cin(1'h0), .value(mul_tree_134_266[127:0]));
    assign mul_tree_134_266[128:128] = '0;
    assign mul_tree_134_267 = ({33'h0, rtlzz_pipe_263_s6}); // decl: <none>; prim: <none>
    assign mul_tree_134_268 = ({1'h0, rtlzz_pipe_266_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_269Core rtlzz_owner_269(.a(97'(mul_tree_134_267)), .b(129'(mul_tree_134_268)), .cin(1'h0), .value(mul_tree_134_269[127:0]));
    assign mul_tree_134_269[129:128] = '0;
    assign mul_tree_134_270 = mul_tree_134_269[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_271 = mul_precision_108[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_272 = mul_precision_109[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_273Core rtlzz_owner_273(.a(32'(mul_tree_135_271)), .b(32'(mul_tree_135_272)), .cin(1'b0), .value(mul_tree_135_273));
    assign mul_tree_135_274 = mul_precision_108[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_275 = mul_precision_109[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(32'(mul_tree_135_274)), .b(32'(mul_tree_135_275)), .cin(1'b0), .value(mul_tree_135_276));
    assign mul_tree_135_277 = {mul_tree_135_276, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_278 = mul_precision_108[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_279 = mul_precision_109[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(32'(mul_tree_135_278)), .b(32'(mul_tree_135_279)), .cin(1'b0), .value(mul_tree_135_280));
    assign mul_tree_135_281 = {mul_tree_135_280, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_282 = mul_precision_108[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_283 = mul_precision_109[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_284Core rtlzz_owner_284(.a(32'(mul_tree_135_282)), .b(32'(mul_tree_135_283)), .cin(1'b0), .value(mul_tree_135_284));
    assign mul_tree_135_285 = {mul_tree_135_284, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_286 = ({33'h0, rtlzz_pipe_273_s1}); // decl: <none>; prim: <none>
    assign mul_tree_135_287 = ({1'h0, rtlzz_pipe_277_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_288Core rtlzz_owner_288(.a(64'(mul_tree_135_286)), .b(96'(mul_tree_135_287)), .cin(1'h0), .value(mul_tree_135_288));
    assign mul_tree_135_289 = ({33'h0, rtlzz_pipe_281_s1}); // decl: <none>; prim: <none>
    assign mul_tree_135_290 = ({1'h0, rtlzz_pipe_285_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_291Core rtlzz_owner_291(.a(96'(mul_tree_135_289)), .b(128'(mul_tree_135_290)), .cin(1'h0), .value(mul_tree_135_291[127:0]));
    assign mul_tree_135_291[128:128] = '0;
    assign mul_tree_135_292 = ({33'h0, rtlzz_pipe_288_s2}); // decl: <none>; prim: <none>
    assign mul_tree_135_293 = ({1'h0, rtlzz_pipe_291_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294Core rtlzz_owner_294(.a(97'(mul_tree_135_292)), .b(129'(mul_tree_135_293)), .cin(1'h0), .value(mul_tree_135_294[127:0]));
    assign mul_tree_135_294[129:128] = '0;
    assign mul_tree_135_295 = mul_tree_135_294[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_296 = rtlzz_pipe_110_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_297 = rtlzz_pipe_111_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(32'(mul_tree_136_296)), .b(32'(mul_tree_136_297)), .cin(1'b0), .value(mul_tree_136_298));
    assign mul_tree_136_299 = rtlzz_pipe_110_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_300 = rtlzz_pipe_111_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(32'(mul_tree_136_299)), .b(32'(mul_tree_136_300)), .cin(1'b0), .value(mul_tree_136_301));
    assign mul_tree_136_302 = {mul_tree_136_301, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_303 = rtlzz_pipe_110_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_304 = rtlzz_pipe_111_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_305Core rtlzz_owner_305(.a(32'(mul_tree_136_303)), .b(32'(mul_tree_136_304)), .cin(1'b0), .value(mul_tree_136_305));
    assign mul_tree_136_306 = {mul_tree_136_305, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_307 = rtlzz_pipe_110_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_308 = rtlzz_pipe_111_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(32'(mul_tree_136_307)), .b(32'(mul_tree_136_308)), .cin(1'b0), .value(mul_tree_136_309));
    assign mul_tree_136_310 = {mul_tree_136_309, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_311 = ({33'h0, rtlzz_pipe_298_s4}); // decl: <none>; prim: <none>
    assign mul_tree_136_312 = ({1'h0, rtlzz_pipe_302_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(64'(mul_tree_136_311)), .b(96'(mul_tree_136_312)), .cin(1'h0), .value(mul_tree_136_313));
    assign mul_tree_136_314 = ({33'h0, rtlzz_pipe_306_s4}); // decl: <none>; prim: <none>
    assign mul_tree_136_315 = ({1'h0, rtlzz_pipe_310_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_136_314)), .b(128'(mul_tree_136_315)), .cin(1'h0), .value(mul_tree_136_316[127:0]));
    assign mul_tree_136_316[128:128] = '0;
    assign mul_tree_136_317 = ({33'h0, rtlzz_pipe_313_s5}); // decl: <none>; prim: <none>
    assign mul_tree_136_318 = ({1'h0, rtlzz_pipe_316_s5}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(97'(mul_tree_136_317)), .b(129'(mul_tree_136_318)), .cin(1'h0), .value(mul_tree_136_319[127:0]));
    assign mul_tree_136_319[129:128] = '0;
    assign mul_tree_136_320 = mul_tree_136_319[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_321 = mul_precision_112[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_322 = mul_precision_113[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_323Core rtlzz_owner_323(.a(32'(mul_tree_137_321)), .b(32'(mul_tree_137_322)), .cin(1'b0), .value(mul_tree_137_323));
    assign mul_tree_137_324 = mul_precision_112[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_325 = mul_precision_113[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_326Core rtlzz_owner_326(.a(32'(mul_tree_137_324)), .b(32'(mul_tree_137_325)), .cin(1'b0), .value(mul_tree_137_326));
    assign mul_tree_137_327 = {mul_tree_137_326, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_328 = mul_precision_112[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_329 = mul_precision_113[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(32'(mul_tree_137_328)), .b(32'(mul_tree_137_329)), .cin(1'b0), .value(mul_tree_137_330));
    assign mul_tree_137_331 = {mul_tree_137_330, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_332 = mul_precision_112[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_333 = mul_precision_113[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(32'(mul_tree_137_332)), .b(32'(mul_tree_137_333)), .cin(1'b0), .value(mul_tree_137_334));
    assign mul_tree_137_335 = {mul_tree_137_334, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_336 = ({33'h0, rtlzz_pipe_323_s1}); // decl: <none>; prim: <none>
    assign mul_tree_137_337 = ({1'h0, rtlzz_pipe_327_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_338Core rtlzz_owner_338(.a(64'(mul_tree_137_336)), .b(96'(mul_tree_137_337)), .cin(1'h0), .value(mul_tree_137_338));
    assign mul_tree_137_339 = ({33'h0, rtlzz_pipe_331_s1}); // decl: <none>; prim: <none>
    assign mul_tree_137_340 = ({1'h0, rtlzz_pipe_335_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_341Core rtlzz_owner_341(.a(96'(mul_tree_137_339)), .b(128'(mul_tree_137_340)), .cin(1'h0), .value(mul_tree_137_341[127:0]));
    assign mul_tree_137_341[128:128] = '0;
    assign mul_tree_137_342 = ({33'h0, rtlzz_pipe_338_s2}); // decl: <none>; prim: <none>
    assign mul_tree_137_343 = ({1'h0, rtlzz_pipe_341_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_344Core rtlzz_owner_344(.a(97'(mul_tree_137_342)), .b(129'(mul_tree_137_343)), .cin(1'h0), .value(mul_tree_137_344[127:0]));
    assign mul_tree_137_344[129:128] = '0;
    assign mul_tree_137_345 = mul_tree_137_344[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_346 = rtlzz_pipe_114_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_347 = rtlzz_pipe_115_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(32'(mul_tree_138_346)), .b(32'(mul_tree_138_347)), .cin(1'b0), .value(mul_tree_138_348));
    assign mul_tree_138_349 = rtlzz_pipe_114_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_350 = rtlzz_pipe_115_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(32'(mul_tree_138_349)), .b(32'(mul_tree_138_350)), .cin(1'b0), .value(mul_tree_138_351));
    assign mul_tree_138_352 = {mul_tree_138_351, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_353 = rtlzz_pipe_114_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_354 = rtlzz_pipe_115_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(32'(mul_tree_138_353)), .b(32'(mul_tree_138_354)), .cin(1'b0), .value(mul_tree_138_355));
    assign mul_tree_138_356 = {mul_tree_138_355, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_357 = rtlzz_pipe_114_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_358 = rtlzz_pipe_115_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(32'(mul_tree_138_357)), .b(32'(mul_tree_138_358)), .cin(1'b0), .value(mul_tree_138_359));
    assign mul_tree_138_360 = {mul_tree_138_359, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_361 = ({33'h0, mul_tree_138_348}); // decl: <none>; prim: <none>
    assign mul_tree_138_362 = ({1'h0, mul_tree_138_352}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_363Core rtlzz_owner_363(.a(64'(mul_tree_138_361)), .b(96'(mul_tree_138_362)), .cin(1'h0), .value(mul_tree_138_363));
    assign mul_tree_138_364 = ({33'h0, mul_tree_138_356}); // decl: <none>; prim: <none>
    assign mul_tree_138_365 = ({1'h0, mul_tree_138_360}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366Core rtlzz_owner_366(.a(96'(mul_tree_138_364)), .b(128'(mul_tree_138_365)), .cin(1'h0), .value(mul_tree_138_366[127:0]));
    assign mul_tree_138_366[128:128] = '0;
    assign mul_tree_138_367 = ({33'h0, rtlzz_pipe_363_s4}); // decl: <none>; prim: <none>
    assign mul_tree_138_368 = ({1'h0, rtlzz_pipe_366_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(97'(mul_tree_138_367)), .b(129'(mul_tree_138_368)), .cin(1'h0), .value(mul_tree_138_369[127:0]));
    assign mul_tree_138_369[129:128] = '0;
    assign mul_tree_138_370 = mul_tree_138_369[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_371 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_372 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_139_371)), .b(32'(mul_tree_139_372)), .cin(1'b0), .value(mul_tree_139_373));
    assign mul_tree_139_374 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_375 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(32'(mul_tree_139_374)), .b(32'(mul_tree_139_375)), .cin(1'b0), .value(mul_tree_139_376));
    assign mul_tree_139_377 = {mul_tree_139_376, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_378 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_379 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_380Core rtlzz_owner_380(.a(32'(mul_tree_139_378)), .b(32'(mul_tree_139_379)), .cin(1'b0), .value(mul_tree_139_380));
    assign mul_tree_139_381 = {mul_tree_139_380, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_382 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_383 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_384Core rtlzz_owner_384(.a(32'(mul_tree_139_382)), .b(32'(mul_tree_139_383)), .cin(1'b0), .value(mul_tree_139_384));
    assign mul_tree_139_385 = {mul_tree_139_384, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_386 = ({33'h0, rtlzz_pipe_373_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_387 = ({1'h0, rtlzz_pipe_377_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(64'(mul_tree_139_386)), .b(96'(mul_tree_139_387)), .cin(1'h0), .value(mul_tree_139_388));
    assign mul_tree_139_389 = ({33'h0, rtlzz_pipe_381_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_390 = ({1'h0, rtlzz_pipe_385_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391Core rtlzz_owner_391(.a(96'(mul_tree_139_389)), .b(128'(mul_tree_139_390)), .cin(1'h0), .value(mul_tree_139_391[127:0]));
    assign mul_tree_139_391[128:128] = '0;
    assign mul_tree_139_392 = ({33'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_139_393 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(97'(mul_tree_139_392)), .b(129'(mul_tree_139_393)), .cin(1'h0), .value(mul_tree_139_394[127:0]));
    assign mul_tree_139_394[129:128] = '0;
    assign mul_tree_139_395 = mul_tree_139_394[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_396 = rtlzz_pipe_118_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_397 = rtlzz_pipe_119_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_140_396)), .b(32'(mul_tree_140_397)), .cin(1'b0), .value(mul_tree_140_398));
    assign mul_tree_140_399 = rtlzz_pipe_118_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_400 = rtlzz_pipe_119_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_401Core rtlzz_owner_401(.a(32'(mul_tree_140_399)), .b(32'(mul_tree_140_400)), .cin(1'b0), .value(mul_tree_140_401));
    assign mul_tree_140_402 = {mul_tree_140_401, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_403 = rtlzz_pipe_118_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_404 = rtlzz_pipe_119_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405Core rtlzz_owner_405(.a(32'(mul_tree_140_403)), .b(32'(mul_tree_140_404)), .cin(1'b0), .value(mul_tree_140_405));
    assign mul_tree_140_406 = {mul_tree_140_405, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_407 = rtlzz_pipe_118_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_408 = rtlzz_pipe_119_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(32'(mul_tree_140_407)), .b(32'(mul_tree_140_408)), .cin(1'b0), .value(mul_tree_140_409));
    assign mul_tree_140_410 = {mul_tree_140_409, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_411 = ({33'h0, rtlzz_pipe_398_s5}); // decl: <none>; prim: <none>
    assign mul_tree_140_412 = ({1'h0, rtlzz_pipe_402_s5}); // decl: <none>; prim: <none>
    assign mul_tree_140_414 = ({33'h0, rtlzz_pipe_406_s5}); // decl: <none>; prim: <none>
    assign mul_tree_140_415 = ({1'h0, rtlzz_pipe_410_s5}); // decl: <none>; prim: <none>
    assign mul_tree_140_417 = ({33'h0, mul_tree_140_413}); // decl: <none>; prim: <none>
    assign mul_tree_140_418 = ({1'h0, mul_tree_140_416}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419_reduce rtlzz_reduce_419(.i688(rtlzz_pipe_398_s5), .i689(rtlzz_pipe_402_s5), .i690(rtlzz_pipe_406_s5), .i691(rtlzz_pipe_410_s5), .y(mul_tree_140_419));
    assign mul_tree_140_420 = mul_tree_140_419[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_421 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_422 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(32'(mul_tree_141_421)), .b(32'(mul_tree_141_422)), .cin(1'b0), .value(mul_tree_141_423));
    assign mul_tree_141_424 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_425 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_426Core rtlzz_owner_426(.a(32'(mul_tree_141_424)), .b(32'(mul_tree_141_425)), .cin(1'b0), .value(mul_tree_141_426));
    assign mul_tree_141_427 = {mul_tree_141_426, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_428 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_429 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(32'(mul_tree_141_428)), .b(32'(mul_tree_141_429)), .cin(1'b0), .value(mul_tree_141_430));
    assign mul_tree_141_431 = {mul_tree_141_430, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_432 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_433 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_434Core rtlzz_owner_434(.a(32'(mul_tree_141_432)), .b(32'(mul_tree_141_433)), .cin(1'b0), .value(mul_tree_141_434));
    assign mul_tree_141_435 = {mul_tree_141_434, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_436 = ({33'h0, rtlzz_pipe_423_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_437 = ({1'h0, rtlzz_pipe_427_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_438Core rtlzz_owner_438(.a(64'(mul_tree_141_436)), .b(96'(mul_tree_141_437)), .cin(1'h0), .value(mul_tree_141_438));
    assign mul_tree_141_439 = ({33'h0, rtlzz_pipe_431_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_440 = ({1'h0, rtlzz_pipe_435_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_441Core rtlzz_owner_441(.a(96'(mul_tree_141_439)), .b(128'(mul_tree_141_440)), .cin(1'h0), .value(mul_tree_141_441[127:0]));
    assign mul_tree_141_441[128:128] = '0;
    assign mul_tree_141_442 = ({33'h0, rtlzz_pipe_438_s2}); // decl: <none>; prim: <none>
    assign mul_tree_141_443 = ({1'h0, rtlzz_pipe_441_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_444Core rtlzz_owner_444(.a(97'(mul_tree_141_442)), .b(129'(mul_tree_141_443)), .cin(1'h0), .value(mul_tree_141_444[127:0]));
    assign mul_tree_141_444[129:128] = '0;
    assign mul_tree_141_445 = mul_tree_141_444[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_446 = rtlzz_pipe_122_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_447 = rtlzz_pipe_123_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_448Core rtlzz_owner_448(.a(32'(mul_tree_142_446)), .b(32'(mul_tree_142_447)), .cin(1'b0), .value(mul_tree_142_448));
    assign mul_tree_142_449 = rtlzz_pipe_122_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_450 = rtlzz_pipe_123_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(32'(mul_tree_142_449)), .b(32'(mul_tree_142_450)), .cin(1'b0), .value(mul_tree_142_451));
    assign mul_tree_142_452 = {mul_tree_142_451, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_453 = rtlzz_pipe_122_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_454 = rtlzz_pipe_123_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(32'(mul_tree_142_453)), .b(32'(mul_tree_142_454)), .cin(1'b0), .value(mul_tree_142_455));
    assign mul_tree_142_456 = {mul_tree_142_455, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_457 = rtlzz_pipe_122_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_458 = rtlzz_pipe_123_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_459Core rtlzz_owner_459(.a(32'(mul_tree_142_457)), .b(32'(mul_tree_142_458)), .cin(1'b0), .value(mul_tree_142_459));
    assign mul_tree_142_460 = {mul_tree_142_459, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_461 = ({33'h0, mul_tree_142_448}); // decl: <none>; prim: <none>
    assign mul_tree_142_462 = ({1'h0, mul_tree_142_452}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_463Core rtlzz_owner_463(.a(64'(mul_tree_142_461)), .b(96'(mul_tree_142_462)), .cin(1'h0), .value(mul_tree_142_463));
    assign mul_tree_142_464 = ({33'h0, mul_tree_142_456}); // decl: <none>; prim: <none>
    assign mul_tree_142_465 = ({1'h0, mul_tree_142_460}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_466Core rtlzz_owner_466(.a(96'(mul_tree_142_464)), .b(128'(mul_tree_142_465)), .cin(1'h0), .value(mul_tree_142_466[127:0]));
    assign mul_tree_142_466[128:128] = '0;
    assign mul_tree_142_467 = ({33'h0, rtlzz_pipe_463_s4}); // decl: <none>; prim: <none>
    assign mul_tree_142_468 = ({1'h0, rtlzz_pipe_466_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_469Core rtlzz_owner_469(.a(97'(mul_tree_142_467)), .b(129'(mul_tree_142_468)), .cin(1'h0), .value(mul_tree_142_469[127:0]));
    assign mul_tree_142_469[129:128] = '0;
    assign mul_tree_142_470 = mul_tree_142_469[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_471 = mul_precision_124[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_472 = mul_precision_125[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_473Core rtlzz_owner_473(.a(32'(mul_tree_143_471)), .b(32'(mul_tree_143_472)), .cin(1'b0), .value(mul_tree_143_473));
    assign mul_tree_143_474 = mul_precision_124[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_475 = mul_precision_125[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_143_474)), .b(32'(mul_tree_143_475)), .cin(1'b0), .value(mul_tree_143_476));
    assign mul_tree_143_477 = {mul_tree_143_476, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_478 = mul_precision_124[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_479 = mul_precision_125[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_480Core rtlzz_owner_480(.a(32'(mul_tree_143_478)), .b(32'(mul_tree_143_479)), .cin(1'b0), .value(mul_tree_143_480));
    assign mul_tree_143_481 = {mul_tree_143_480, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_482 = mul_precision_124[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_483 = mul_precision_125[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_484Core rtlzz_owner_484(.a(32'(mul_tree_143_482)), .b(32'(mul_tree_143_483)), .cin(1'b0), .value(mul_tree_143_484));
    assign mul_tree_143_485 = {mul_tree_143_484, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_486 = ({33'h0, rtlzz_pipe_473_s1}); // decl: <none>; prim: <none>
    assign mul_tree_143_487 = ({1'h0, rtlzz_pipe_477_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_488Core rtlzz_owner_488(.a(64'(mul_tree_143_486)), .b(96'(mul_tree_143_487)), .cin(1'h0), .value(mul_tree_143_488));
    assign mul_tree_143_489 = ({33'h0, rtlzz_pipe_481_s1}); // decl: <none>; prim: <none>
    assign mul_tree_143_490 = ({1'h0, rtlzz_pipe_485_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_491Core rtlzz_owner_491(.a(96'(mul_tree_143_489)), .b(128'(mul_tree_143_490)), .cin(1'h0), .value(mul_tree_143_491[127:0]));
    assign mul_tree_143_491[128:128] = '0;
    assign mul_tree_143_492 = ({33'h0, rtlzz_pipe_488_s2}); // decl: <none>; prim: <none>
    assign mul_tree_143_493 = ({1'h0, rtlzz_pipe_491_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_494Core rtlzz_owner_494(.a(97'(mul_tree_143_492)), .b(129'(mul_tree_143_493)), .cin(1'h0), .value(mul_tree_143_494[127:0]));
    assign mul_tree_143_494[129:128] = '0;
    assign mul_tree_143_495 = mul_tree_143_494[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_496 = rtlzz_pipe_126_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_497 = rtlzz_pipe_127_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_498Core rtlzz_owner_498(.a(32'(mul_tree_144_496)), .b(32'(mul_tree_144_497)), .cin(1'b0), .value(mul_tree_144_498));
    assign mul_tree_144_499 = rtlzz_pipe_126_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_500 = rtlzz_pipe_127_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_144_499)), .b(32'(mul_tree_144_500)), .cin(1'b0), .value(mul_tree_144_501));
    assign mul_tree_144_502 = {mul_tree_144_501, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_503 = rtlzz_pipe_126_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_504 = rtlzz_pipe_127_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(32'(mul_tree_144_503)), .b(32'(mul_tree_144_504)), .cin(1'b0), .value(mul_tree_144_505));
    assign mul_tree_144_506 = {mul_tree_144_505, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_507 = rtlzz_pipe_126_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_508 = rtlzz_pipe_127_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_509Core rtlzz_owner_509(.a(32'(mul_tree_144_507)), .b(32'(mul_tree_144_508)), .cin(1'b0), .value(mul_tree_144_509));
    assign mul_tree_144_510 = {mul_tree_144_509, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_511 = ({33'h0, rtlzz_pipe_498_s6}); // decl: <none>; prim: <none>
    assign mul_tree_144_512 = ({1'h0, rtlzz_pipe_502_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_513Core rtlzz_owner_513(.a(64'(mul_tree_144_511)), .b(96'(mul_tree_144_512)), .cin(1'h0), .value(mul_tree_144_513));
    assign mul_tree_144_514 = ({33'h0, rtlzz_pipe_506_s6}); // decl: <none>; prim: <none>
    assign mul_tree_144_515 = ({1'h0, rtlzz_pipe_510_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_516Core rtlzz_owner_516(.a(96'(mul_tree_144_514)), .b(128'(mul_tree_144_515)), .cin(1'h0), .value(mul_tree_144_516[127:0]));
    assign mul_tree_144_516[128:128] = '0;
    assign mul_tree_144_517 = ({33'h0, rtlzz_pipe_513_s7}); // decl: <none>; prim: <none>
    assign mul_tree_144_518 = ({1'h0, rtlzz_pipe_516_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_519Core rtlzz_owner_519(.a(97'(mul_tree_144_517)), .b(129'(mul_tree_144_518)), .cin(1'h0), .value(mul_tree_144_519[127:0]));
    assign mul_tree_144_519[129:128] = '0;
    assign mul_tree_144_520 = mul_tree_144_519[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_521 = mul_precision_128[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_522 = mul_precision_129[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_523Core rtlzz_owner_523(.a(32'(mul_tree_145_521)), .b(32'(mul_tree_145_522)), .cin(1'b0), .value(mul_tree_145_523));
    assign mul_tree_145_524 = mul_precision_128[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_525 = mul_precision_129[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(32'(mul_tree_145_524)), .b(32'(mul_tree_145_525)), .cin(1'b0), .value(mul_tree_145_526));
    assign mul_tree_145_527 = {mul_tree_145_526, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_528 = mul_precision_128[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_529 = mul_precision_129[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_530Core rtlzz_owner_530(.a(32'(mul_tree_145_528)), .b(32'(mul_tree_145_529)), .cin(1'b0), .value(mul_tree_145_530));
    assign mul_tree_145_531 = {mul_tree_145_530, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_532 = mul_precision_128[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_533 = mul_precision_129[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_534Core rtlzz_owner_534(.a(32'(mul_tree_145_532)), .b(32'(mul_tree_145_533)), .cin(1'b0), .value(mul_tree_145_534));
    assign mul_tree_145_535 = {mul_tree_145_534, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_536 = ({33'h0, rtlzz_pipe_523_s2}); // decl: <none>; prim: <none>
    assign mul_tree_145_537 = ({1'h0, rtlzz_pipe_527_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_538Core rtlzz_owner_538(.a(64'(mul_tree_145_536)), .b(96'(mul_tree_145_537)), .cin(1'h0), .value(mul_tree_145_538));
    assign mul_tree_145_539 = ({33'h0, rtlzz_pipe_531_s2}); // decl: <none>; prim: <none>
    assign mul_tree_145_540 = ({1'h0, rtlzz_pipe_535_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_541Core rtlzz_owner_541(.a(96'(mul_tree_145_539)), .b(128'(mul_tree_145_540)), .cin(1'h0), .value(mul_tree_145_541[127:0]));
    assign mul_tree_145_541[128:128] = '0;
    assign mul_tree_145_542 = ({33'h0, rtlzz_pipe_538_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_543 = ({1'h0, rtlzz_pipe_541_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_544Core rtlzz_owner_544(.a(97'(mul_tree_145_542)), .b(129'(mul_tree_145_543)), .cin(1'h0), .value(mul_tree_145_544[127:0]));
    assign mul_tree_145_544[129:128] = '0;
    assign mul_tree_145_545 = mul_tree_145_544[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_100_s2 <= 64'h0;
            rtlzz_pipe_100_s3 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_101_s2 <= 64'h0;
            rtlzz_pipe_101_s3 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_102_s3 <= 64'h0;
            rtlzz_pipe_102_s4 <= 64'h0;
            rtlzz_pipe_102_s5 <= 64'h0;
            rtlzz_pipe_102_s6 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_103_s3 <= 64'h0;
            rtlzz_pipe_103_s4 <= 64'h0;
            rtlzz_pipe_103_s5 <= 64'h0;
            rtlzz_pipe_103_s6 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_110_s1 <= 64'h0;
            rtlzz_pipe_110_s2 <= 64'h0;
            rtlzz_pipe_110_s3 <= 64'h0;
            rtlzz_pipe_111_s1 <= 64'h0;
            rtlzz_pipe_111_s2 <= 64'h0;
            rtlzz_pipe_111_s3 <= 64'h0;
            rtlzz_pipe_114_s1 <= 64'h0;
            rtlzz_pipe_114_s2 <= 64'h0;
            rtlzz_pipe_114_s3 <= 64'h0;
            rtlzz_pipe_115_s1 <= 64'h0;
            rtlzz_pipe_115_s2 <= 64'h0;
            rtlzz_pipe_115_s3 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_118_s2 <= 64'h0;
            rtlzz_pipe_118_s3 <= 64'h0;
            rtlzz_pipe_118_s4 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_119_s2 <= 64'h0;
            rtlzz_pipe_119_s3 <= 64'h0;
            rtlzz_pipe_119_s4 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_126_s1 <= 64'h0;
            rtlzz_pipe_126_s2 <= 64'h0;
            rtlzz_pipe_126_s3 <= 64'h0;
            rtlzz_pipe_126_s4 <= 64'h0;
            rtlzz_pipe_126_s5 <= 64'h0;
            rtlzz_pipe_127_s1 <= 64'h0;
            rtlzz_pipe_127_s2 <= 64'h0;
            rtlzz_pipe_127_s3 <= 64'h0;
            rtlzz_pipe_127_s4 <= 64'h0;
            rtlzz_pipe_127_s5 <= 64'h0;
            rtlzz_pipe_148_s1 <= 64'h0;
            rtlzz_pipe_152_s1 <= 96'h0;
            rtlzz_pipe_156_s1 <= 96'h0;
            rtlzz_pipe_160_s1 <= 128'h0;
            rtlzz_pipe_163_s2 <= 97'h0;
            rtlzz_pipe_166_s2 <= 129'h0;
            rtlzz_pipe_33_s3 <= 128'h0;
            rtlzz_pipe_33_s4 <= 128'h0;
            rtlzz_pipe_33_s5 <= 128'h0;
            rtlzz_pipe_173_s4 <= 64'h0;
            rtlzz_pipe_177_s4 <= 96'h0;
            rtlzz_pipe_181_s4 <= 96'h0;
            rtlzz_pipe_185_s4 <= 128'h0;
            rtlzz_pipe_188_s5 <= 97'h0;
            rtlzz_pipe_191_s5 <= 129'h0;
            rtlzz_pipe_49_s6 <= 129'h0;
            rtlzz_pipe_49_s7 <= 129'h0;
            rtlzz_pipe_198_s7 <= 64'h0;
            rtlzz_pipe_202_s7 <= 96'h0;
            rtlzz_pipe_206_s7 <= 96'h0;
            rtlzz_pipe_210_s7 <= 128'h0;
            rtlzz_pipe_223_s1 <= 64'h0;
            rtlzz_pipe_227_s1 <= 96'h0;
            rtlzz_pipe_231_s1 <= 96'h0;
            rtlzz_pipe_235_s1 <= 128'h0;
            rtlzz_pipe_238_s2 <= 97'h0;
            rtlzz_pipe_241_s2 <= 129'h0;
            rtlzz_pipe_36_s3 <= 128'h0;
            rtlzz_pipe_36_s4 <= 128'h0;
            rtlzz_pipe_36_s5 <= 128'h0;
            rtlzz_pipe_36_s6 <= 128'h0;
            rtlzz_pipe_36_s7 <= 128'h0;
            rtlzz_pipe_248_s4 <= 64'h0;
            rtlzz_pipe_252_s4 <= 96'h0;
            rtlzz_pipe_256_s4 <= 96'h0;
            rtlzz_pipe_260_s4 <= 128'h0;
            rtlzz_pipe_263_s5 <= 97'h0;
            rtlzz_pipe_263_s6 <= 97'h0;
            rtlzz_pipe_266_s5 <= 129'h0;
            rtlzz_pipe_266_s6 <= 129'h0;
            rtlzz_pipe_273_s1 <= 64'h0;
            rtlzz_pipe_277_s1 <= 96'h0;
            rtlzz_pipe_281_s1 <= 96'h0;
            rtlzz_pipe_285_s1 <= 128'h0;
            rtlzz_pipe_288_s2 <= 97'h0;
            rtlzz_pipe_291_s2 <= 129'h0;
            rtlzz_pipe_38_s3 <= 128'h0;
            rtlzz_pipe_38_s4 <= 128'h0;
            rtlzz_pipe_38_s5 <= 128'h0;
            rtlzz_pipe_38_s6 <= 128'h0;
            rtlzz_pipe_298_s4 <= 64'h0;
            rtlzz_pipe_302_s4 <= 96'h0;
            rtlzz_pipe_306_s4 <= 96'h0;
            rtlzz_pipe_310_s4 <= 128'h0;
            rtlzz_pipe_313_s5 <= 97'h0;
            rtlzz_pipe_316_s5 <= 129'h0;
            rtlzz_pipe_323_s1 <= 64'h0;
            rtlzz_pipe_327_s1 <= 96'h0;
            rtlzz_pipe_331_s1 <= 96'h0;
            rtlzz_pipe_335_s1 <= 128'h0;
            rtlzz_pipe_338_s2 <= 97'h0;
            rtlzz_pipe_341_s2 <= 129'h0;
            rtlzz_pipe_40_s3 <= 128'h0;
            rtlzz_pipe_40_s4 <= 128'h0;
            rtlzz_pipe_40_s5 <= 128'h0;
            rtlzz_pipe_52_s6 <= 129'h0;
            rtlzz_pipe_58_s7 <= 130'h0;
            rtlzz_pipe_363_s4 <= 97'h0;
            rtlzz_pipe_366_s4 <= 129'h0;
            rtlzz_pipe_41_s5 <= 128'h0;
            rtlzz_pipe_41_s6 <= 128'h0;
            rtlzz_pipe_373_s1 <= 64'h0;
            rtlzz_pipe_377_s1 <= 96'h0;
            rtlzz_pipe_381_s1 <= 96'h0;
            rtlzz_pipe_385_s1 <= 128'h0;
            rtlzz_pipe_388_s2 <= 97'h0;
            rtlzz_pipe_391_s2 <= 129'h0;
            rtlzz_pipe_42_s3 <= 128'h0;
            rtlzz_pipe_42_s4 <= 128'h0;
            rtlzz_pipe_42_s5 <= 128'h0;
            rtlzz_pipe_42_s6 <= 128'h0;
            rtlzz_pipe_53_s7 <= 129'h0;
            rtlzz_pipe_398_s5 <= 64'h0;
            rtlzz_pipe_402_s5 <= 96'h0;
            rtlzz_pipe_406_s5 <= 96'h0;
            rtlzz_pipe_410_s5 <= 128'h0;
            rtlzz_pipe_43_s6 <= 128'h0;
            rtlzz_pipe_423_s1 <= 64'h0;
            rtlzz_pipe_427_s1 <= 96'h0;
            rtlzz_pipe_431_s1 <= 96'h0;
            rtlzz_pipe_435_s1 <= 128'h0;
            rtlzz_pipe_438_s2 <= 97'h0;
            rtlzz_pipe_441_s2 <= 129'h0;
            rtlzz_pipe_44_s3 <= 128'h0;
            rtlzz_pipe_44_s4 <= 128'h0;
            rtlzz_pipe_44_s5 <= 128'h0;
            rtlzz_pipe_44_s6 <= 128'h0;
            rtlzz_pipe_54_s7 <= 129'h0;
            rtlzz_pipe_463_s4 <= 97'h0;
            rtlzz_pipe_466_s4 <= 129'h0;
            rtlzz_pipe_473_s1 <= 64'h0;
            rtlzz_pipe_477_s1 <= 96'h0;
            rtlzz_pipe_481_s1 <= 96'h0;
            rtlzz_pipe_485_s1 <= 128'h0;
            rtlzz_pipe_488_s2 <= 97'h0;
            rtlzz_pipe_491_s2 <= 129'h0;
            rtlzz_pipe_46_s3 <= 128'h0;
            rtlzz_pipe_46_s4 <= 128'h0;
            rtlzz_pipe_55_s5 <= 129'h0;
            rtlzz_pipe_55_s6 <= 129'h0;
            rtlzz_pipe_55_s7 <= 129'h0;
            rtlzz_pipe_498_s6 <= 64'h0;
            rtlzz_pipe_502_s6 <= 96'h0;
            rtlzz_pipe_506_s6 <= 96'h0;
            rtlzz_pipe_510_s6 <= 128'h0;
            rtlzz_pipe_513_s7 <= 97'h0;
            rtlzz_pipe_516_s7 <= 129'h0;
            rtlzz_pipe_523_s1 <= 64'h0;
            rtlzz_pipe_523_s2 <= 64'h0;
            rtlzz_pipe_527_s1 <= 96'h0;
            rtlzz_pipe_527_s2 <= 96'h0;
            rtlzz_pipe_531_s1 <= 96'h0;
            rtlzz_pipe_531_s2 <= 96'h0;
            rtlzz_pipe_535_s1 <= 128'h0;
            rtlzz_pipe_535_s2 <= 128'h0;
            rtlzz_pipe_538_s3 <= 97'h0;
            rtlzz_pipe_538_s4 <= 97'h0;
            rtlzz_pipe_541_s3 <= 129'h0;
            rtlzz_pipe_541_s4 <= 129'h0;
            rtlzz_pipe_48_s5 <= 128'h0;
            rtlzz_pipe_48_s6 <= 128'h0;
            rtlzz_pipe_48_s7 <= 128'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_100_s2 <= rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_101_s2 <= rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_101_s3 <= rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_102_s3 <= rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_102_s4 <= rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_102_s6 <= rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_103_s4 <= rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_103_s5 <= rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_110_s1 <= mul_precision_110; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_110_s2 <= rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_110_s3 <= rtlzz_pipe_110_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_precision_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_111_s2 <= rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_111_s3 <= rtlzz_pipe_111_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_114_s1 <= mul_precision_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_114_s3 <= rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_115_s1 <= mul_precision_115; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_115_s3 <= rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_118_s2 <= rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_118_s3 <= rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_118_s4 <= rtlzz_pipe_118_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_119_s2 <= rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_119_s3 <= rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_119_s4 <= rtlzz_pipe_119_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_126_s1 <= mul_precision_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_126_s2 <= rtlzz_pipe_126_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_126_s3 <= rtlzz_pipe_126_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_126_s4 <= rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_126_s5 <= rtlzz_pipe_126_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_127_s1 <= mul_precision_127; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_127_s2 <= rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_127_s3 <= rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_127_s4 <= rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_127_s5 <= rtlzz_pipe_127_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_130_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= mul_tree_130_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= mul_tree_130_156; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_160_s1 <= mul_tree_130_160; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= mul_tree_130_163; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_166_s2 <= mul_tree_130_166; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_33_s4 <= rtlzz_pipe_33_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_33_s5 <= rtlzz_pipe_33_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_173_s4 <= mul_tree_131_173; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_177_s4 <= mul_tree_131_177; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_181_s4 <= mul_tree_131_181; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_185_s4 <= mul_tree_131_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_188_s5 <= mul_tree_131_188; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_191_s5 <= mul_tree_131_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_49_s6 <= s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_49_s7 <= rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_198_s7 <= mul_tree_132_198; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_202_s7 <= mul_tree_132_202; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_206_s7 <= mul_tree_132_206; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_210_s7 <= mul_tree_132_210; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_223_s1 <= mul_tree_133_223; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_227_s1 <= mul_tree_133_227; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_231_s1 <= mul_tree_133_231; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= mul_tree_133_235; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_238_s2 <= mul_tree_133_238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_241_s2 <= mul_tree_133_241; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_36_s3 <= s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_36_s4 <= rtlzz_pipe_36_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= rtlzz_pipe_36_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_36_s6 <= rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_36_s7 <= rtlzz_pipe_36_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_248_s4 <= mul_tree_134_248; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_252_s4 <= mul_tree_134_252; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_256_s4 <= mul_tree_134_256; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_260_s4 <= mul_tree_134_260; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_263_s5 <= mul_tree_134_263; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_263_s6 <= rtlzz_pipe_263_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= mul_tree_134_266; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_266_s6 <= rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= mul_tree_135_273; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_277_s1 <= mul_tree_135_277; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_281_s1 <= mul_tree_135_281; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_285_s1 <= mul_tree_135_285; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_288_s2 <= mul_tree_135_288; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_291_s2 <= mul_tree_135_291; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_38_s4 <= rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_38_s5 <= rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_38_s6 <= rtlzz_pipe_38_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_298_s4 <= mul_tree_136_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_302_s4 <= mul_tree_136_302; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_306_s4 <= mul_tree_136_306; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_310_s4 <= mul_tree_136_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_313_s5 <= mul_tree_136_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_316_s5 <= mul_tree_136_316; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_323_s1 <= mul_tree_137_323; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_327_s1 <= mul_tree_137_327; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_331_s1 <= mul_tree_137_331; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_335_s1 <= mul_tree_137_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_338_s2 <= mul_tree_137_338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_341_s2 <= mul_tree_137_341; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_40_s3 <= s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_40_s4 <= rtlzz_pipe_40_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_40_s5 <= rtlzz_pipe_40_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_58_s7 <= s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_363_s4 <= mul_tree_138_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_366_s4 <= mul_tree_138_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_41_s5 <= s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_41_s6 <= rtlzz_pipe_41_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (iv) begin
        rtlzz_pipe_373_s1 <= mul_tree_139_373; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_377_s1 <= mul_tree_139_377; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_381_s1 <= mul_tree_139_381; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_385_s1 <= mul_tree_139_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_139_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_139_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_42_s4 <= rtlzz_pipe_42_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_42_s5 <= rtlzz_pipe_42_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_42_s6 <= rtlzz_pipe_42_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_53_s7 <= s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_398_s5 <= mul_tree_140_398; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_402_s5 <= mul_tree_140_402; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_406_s5 <= mul_tree_140_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_410_s5 <= mul_tree_140_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_43_s6 <= s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (iv) begin
        rtlzz_pipe_423_s1 <= mul_tree_141_423; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_427_s1 <= mul_tree_141_427; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_431_s1 <= mul_tree_141_431; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_435_s1 <= mul_tree_141_435; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_438_s2 <= mul_tree_141_438; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_441_s2 <= mul_tree_141_441; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_44_s4 <= rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_44_s6 <= rtlzz_pipe_44_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_54_s7 <= s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_463_s4 <= mul_tree_142_463; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_466_s4 <= mul_tree_142_466; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_473_s1 <= mul_tree_143_473; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_477_s1 <= mul_tree_143_477; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_481_s1 <= mul_tree_143_481; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_485_s1 <= mul_tree_143_485; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_488_s2 <= mul_tree_143_488; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_491_s2 <= mul_tree_143_491; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_46_s3 <= s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_46_s4 <= rtlzz_pipe_46_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_55_s5 <= s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_55_s6 <= rtlzz_pipe_55_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_55_s7 <= rtlzz_pipe_55_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_498_s6 <= mul_tree_144_498; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_502_s6 <= mul_tree_144_502; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_506_s6 <= mul_tree_144_506; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_510_s6 <= mul_tree_144_510; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_513_s7 <= mul_tree_144_513; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_516_s7 <= mul_tree_144_516; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_523_s1 <= mul_tree_145_523; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_523_s2 <= rtlzz_pipe_523_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_527_s1 <= mul_tree_145_527; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_527_s2 <= rtlzz_pipe_527_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_531_s1 <= mul_tree_145_531; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_531_s2 <= rtlzz_pipe_531_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_535_s1 <= mul_tree_145_535; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_535_s2 <= rtlzz_pipe_535_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_538_s3 <= mul_tree_145_538; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_538_s4 <= rtlzz_pipe_538_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_541_s3 <= mul_tree_145_541; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_541_s4 <= rtlzz_pipe_541_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_48_s5 <= s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_48_s6 <= rtlzz_pipe_48_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_48_s7 <= rtlzz_pipe_48_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58_reduce(input wire [129:0] i269, input wire [127:0] i655, input wire [128:0] i671, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, i269[127], i269[126], i269[125], i269[124], i269[123], i269[122], i269[121], i269[120], i269[119], i269[118], i269[117], i269[116], i269[115], i269[114], i269[113], i269[112], i269[111], i269[110], i269[109], i269[108], i269[107], i269[106], i269[105], i269[104], i269[103], i269[102], i269[101], i269[100], i269[99], i269[98], i269[97], i269[96], i269[95], i269[94], i269[93], i269[92], i269[91], i269[90], i269[89], i269[88], i269[87], i269[86], i269[85], i269[84], i269[83], i269[82], i269[81], i269[80], i269[79], i269[78], i269[77], i269[76], i269[75], i269[74], i269[73], i269[72], i269[71], i269[70], i269[69], i269[68], i269[67], i269[66], i269[65], i269[64], i269[63], i269[62], i269[61], i269[60], i269[59], i269[58], i269[57], i269[56], i269[55], i269[54], i269[53], i269[52], i269[51], i269[50], i269[49], i269[48], i269[47], i269[46], i269[45], i269[44], i269[43], i269[42], i269[41], i269[40], i269[39], i269[38], i269[37], i269[36], i269[35], i269[34], i269[33], i269[32], i269[31], i269[30], i269[29], i269[28], i269[27], i269[26], i269[25], i269[24], i269[23], i269[22], i269[21], i269[20], i269[19], i269[18], i269[17], i269[16], i269[15], i269[14], i269[13], i269[12], i269[11], i269[10], i269[9], i269[8], i269[7], i269[6], i269[5], i269[4], i269[3], i269[2], i269[1], i269[0]};
wire [129:0] t1 = {1'b0, 1'b0, i655[127], i655[126], i655[125], i655[124], i655[123], i655[122], i655[121], i655[120], i655[119], i655[118], i655[117], i655[116], i655[115], i655[114], i655[113], i655[112], i655[111], i655[110], i655[109], i655[108], i655[107], i655[106], i655[105], i655[104], i655[103], i655[102], i655[101], i655[100], i655[99], i655[98], i655[97], i655[96], i655[95], i655[94], i655[93], i655[92], i655[91], i655[90], i655[89], i655[88], i655[87], i655[86], i655[85], i655[84], i655[83], i655[82], i655[81], i655[80], i655[79], i655[78], i655[77], i655[76], i655[75], i655[74], i655[73], i655[72], i655[71], i655[70], i655[69], i655[68], i655[67], i655[66], i655[65], i655[64], i655[63], i655[62], i655[61], i655[60], i655[59], i655[58], i655[57], i655[56], i655[55], i655[54], i655[53], i655[52], i655[51], i655[50], i655[49], i655[48], i655[47], i655[46], i655[45], i655[44], i655[43], i655[42], i655[41], i655[40], i655[39], i655[38], i655[37], i655[36], i655[35], i655[34], i655[33], i655[32], i655[31], i655[30], i655[29], i655[28], i655[27], i655[26], i655[25], i655[24], i655[23], i655[22], i655[21], i655[20], i655[19], i655[18], i655[17], i655[16], i655[15], i655[14], i655[13], i655[12], i655[11], i655[10], i655[9], i655[8], i655[7], i655[6], i655[5], i655[4], i655[3], i655[2], i655[1], i655[0]};
wire [129:0] t2 = {1'b0, i671[128], i671[127], i671[126], i671[125], i671[124], i671[123], i671[122], i671[121], i671[120], i671[119], i671[118], i671[117], i671[116], i671[115], i671[114], i671[113], i671[112], i671[111], i671[110], i671[109], i671[108], i671[107], i671[106], i671[105], i671[104], i671[103], i671[102], i671[101], i671[100], i671[99], i671[98], i671[97], i671[96], i671[95], i671[94], i671[93], i671[92], i671[91], i671[90], i671[89], i671[88], i671[87], i671[86], i671[85], i671[84], i671[83], i671[82], i671[81], i671[80], i671[79], i671[78], i671[77], i671[76], i671[75], i671[74], i671[73], i671[72], i671[71], i671[70], i671[69], i671[68], i671[67], i671[66], i671[65], i671[64], i671[63], i671[62], i671[61], i671[60], i671[59], i671[58], i671[57], i671[56], i671[55], i671[54], i671[53], i671[52], i671[51], i671[50], i671[49], i671[48], i671[47], i671[46], i671[45], i671[44], i671[43], i671[42], i671[41], i671[40], i671[39], i671[38], i671[37], i671[36], i671[35], i671[34], i671[33], i671[32], i671[31], i671[30], i671[29], i671[28], i671[27], i671[26], i671[25], i671[24], i671[23], i671[22], i671[21], i671[20], i671[19], i671[18], i671[17], i671[16], i671[15], i671[14], i671[13], i671[12], i671[11], i671[10], i671[9], i671[8], i671[7], i671[6], i671[5], i671[4], i671[3], i671[2], i671[1], i671[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63_reduce(input wire [129:0] i219, input wire [129:0] i519, input wire [128:0] i622, input wire [127:0] i637, input wire [129:0] i672, input wire [128:0] i687, input wire [128:0] i703, input wire [128:0] i716, input wire [127:0] i737, output wire [131:0] y);
wire [131:0] t0 = {1'b0, 1'b0, 1'b0, i622[128], i622[127], i622[126], i622[125], i622[124], i622[123], i622[122], i622[121], i622[120], i622[119], i622[118], i622[117], i622[116], i622[115], i622[114], i622[113], i622[112], i622[111], i622[110], i622[109], i622[108], i622[107], i622[106], i622[105], i622[104], i622[103], i622[102], i622[101], i622[100], i622[99], i622[98], i622[97], i622[96], i622[95], i622[94], i622[93], i622[92], i622[91], i622[90], i622[89], i622[88], i622[87], i622[86], i622[85], i622[84], i622[83], i622[82], i622[81], i622[80], i622[79], i622[78], i622[77], i622[76], i622[75], i622[74], i622[73], i622[72], i622[71], i622[70], i622[69], i622[68], i622[67], i622[66], i622[65], i622[64], i622[63], i622[62], i622[61], i622[60], i622[59], i622[58], i622[57], i622[56], i622[55], i622[54], i622[53], i622[52], i622[51], i622[50], i622[49], i622[48], i622[47], i622[46], i622[45], i622[44], i622[43], i622[42], i622[41], i622[40], i622[39], i622[38], i622[37], i622[36], i622[35], i622[34], i622[33], i622[32], i622[31], i622[30], i622[29], i622[28], i622[27], i622[26], i622[25], i622[24], i622[23], i622[22], i622[21], i622[20], i622[19], i622[18], i622[17], i622[16], i622[15], i622[14], i622[13], i622[12], i622[11], i622[10], i622[9], i622[8], i622[7], i622[6], i622[5], i622[4], i622[3], i622[2], i622[1], i622[0]};
wire [131:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, i219[127], i219[126], i219[125], i219[124], i219[123], i219[122], i219[121], i219[120], i219[119], i219[118], i219[117], i219[116], i219[115], i219[114], i219[113], i219[112], i219[111], i219[110], i219[109], i219[108], i219[107], i219[106], i219[105], i219[104], i219[103], i219[102], i219[101], i219[100], i219[99], i219[98], i219[97], i219[96], i219[95], i219[94], i219[93], i219[92], i219[91], i219[90], i219[89], i219[88], i219[87], i219[86], i219[85], i219[84], i219[83], i219[82], i219[81], i219[80], i219[79], i219[78], i219[77], i219[76], i219[75], i219[74], i219[73], i219[72], i219[71], i219[70], i219[69], i219[68], i219[67], i219[66], i219[65], i219[64], i219[63], i219[62], i219[61], i219[60], i219[59], i219[58], i219[57], i219[56], i219[55], i219[54], i219[53], i219[52], i219[51], i219[50], i219[49], i219[48], i219[47], i219[46], i219[45], i219[44], i219[43], i219[42], i219[41], i219[40], i219[39], i219[38], i219[37], i219[36], i219[35], i219[34], i219[33], i219[32], i219[31], i219[30], i219[29], i219[28], i219[27], i219[26], i219[25], i219[24], i219[23], i219[22], i219[21], i219[20], i219[19], i219[18], i219[17], i219[16], i219[15], i219[14], i219[13], i219[12], i219[11], i219[10], i219[9], i219[8], i219[7], i219[6], i219[5], i219[4], i219[3], i219[2], i219[1], i219[0]};
wire [131:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, i637[127], i637[126], i637[125], i637[124], i637[123], i637[122], i637[121], i637[120], i637[119], i637[118], i637[117], i637[116], i637[115], i637[114], i637[113], i637[112], i637[111], i637[110], i637[109], i637[108], i637[107], i637[106], i637[105], i637[104], i637[103], i637[102], i637[101], i637[100], i637[99], i637[98], i637[97], i637[96], i637[95], i637[94], i637[93], i637[92], i637[91], i637[90], i637[89], i637[88], i637[87], i637[86], i637[85], i637[84], i637[83], i637[82], i637[81], i637[80], i637[79], i637[78], i637[77], i637[76], i637[75], i637[74], i637[73], i637[72], i637[71], i637[70], i637[69], i637[68], i637[67], i637[66], i637[65], i637[64], i637[63], i637[62], i637[61], i637[60], i637[59], i637[58], i637[57], i637[56], i637[55], i637[54], i637[53], i637[52], i637[51], i637[50], i637[49], i637[48], i637[47], i637[46], i637[45], i637[44], i637[43], i637[42], i637[41], i637[40], i637[39], i637[38], i637[37], i637[36], i637[35], i637[34], i637[33], i637[32], i637[31], i637[30], i637[29], i637[28], i637[27], i637[26], i637[25], i637[24], i637[23], i637[22], i637[21], i637[20], i637[19], i637[18], i637[17], i637[16], i637[15], i637[14], i637[13], i637[12], i637[11], i637[10], i637[9], i637[8], i637[7], i637[6], i637[5], i637[4], i637[3], i637[2], i637[1], i637[0]};
wire [131:0] t3 = {1'b0, 1'b0, i672[129], i672[128], i672[127], i672[126], i672[125], i672[124], i672[123], i672[122], i672[121], i672[120], i672[119], i672[118], i672[117], i672[116], i672[115], i672[114], i672[113], i672[112], i672[111], i672[110], i672[109], i672[108], i672[107], i672[106], i672[105], i672[104], i672[103], i672[102], i672[101], i672[100], i672[99], i672[98], i672[97], i672[96], i672[95], i672[94], i672[93], i672[92], i672[91], i672[90], i672[89], i672[88], i672[87], i672[86], i672[85], i672[84], i672[83], i672[82], i672[81], i672[80], i672[79], i672[78], i672[77], i672[76], i672[75], i672[74], i672[73], i672[72], i672[71], i672[70], i672[69], i672[68], i672[67], i672[66], i672[65], i672[64], i672[63], i672[62], i672[61], i672[60], i672[59], i672[58], i672[57], i672[56], i672[55], i672[54], i672[53], i672[52], i672[51], i672[50], i672[49], i672[48], i672[47], i672[46], i672[45], i672[44], i672[43], i672[42], i672[41], i672[40], i672[39], i672[38], i672[37], i672[36], i672[35], i672[34], i672[33], i672[32], i672[31], i672[30], i672[29], i672[28], i672[27], i672[26], i672[25], i672[24], i672[23], i672[22], i672[21], i672[20], i672[19], i672[18], i672[17], i672[16], i672[15], i672[14], i672[13], i672[12], i672[11], i672[10], i672[9], i672[8], i672[7], i672[6], i672[5], i672[4], i672[3], i672[2], i672[1], i672[0]};
wire [131:0] t4 = {1'b0, 1'b0, 1'b0, i687[128], i687[127], i687[126], i687[125], i687[124], i687[123], i687[122], i687[121], i687[120], i687[119], i687[118], i687[117], i687[116], i687[115], i687[114], i687[113], i687[112], i687[111], i687[110], i687[109], i687[108], i687[107], i687[106], i687[105], i687[104], i687[103], i687[102], i687[101], i687[100], i687[99], i687[98], i687[97], i687[96], i687[95], i687[94], i687[93], i687[92], i687[91], i687[90], i687[89], i687[88], i687[87], i687[86], i687[85], i687[84], i687[83], i687[82], i687[81], i687[80], i687[79], i687[78], i687[77], i687[76], i687[75], i687[74], i687[73], i687[72], i687[71], i687[70], i687[69], i687[68], i687[67], i687[66], i687[65], i687[64], i687[63], i687[62], i687[61], i687[60], i687[59], i687[58], i687[57], i687[56], i687[55], i687[54], i687[53], i687[52], i687[51], i687[50], i687[49], i687[48], i687[47], i687[46], i687[45], i687[44], i687[43], i687[42], i687[41], i687[40], i687[39], i687[38], i687[37], i687[36], i687[35], i687[34], i687[33], i687[32], i687[31], i687[30], i687[29], i687[28], i687[27], i687[26], i687[25], i687[24], i687[23], i687[22], i687[21], i687[20], i687[19], i687[18], i687[17], i687[16], i687[15], i687[14], i687[13], i687[12], i687[11], i687[10], i687[9], i687[8], i687[7], i687[6], i687[5], i687[4], i687[3], i687[2], i687[1], i687[0]};
wire [131:0] t5 = {1'b0, 1'b0, 1'b0, i703[128], i703[127], i703[126], i703[125], i703[124], i703[123], i703[122], i703[121], i703[120], i703[119], i703[118], i703[117], i703[116], i703[115], i703[114], i703[113], i703[112], i703[111], i703[110], i703[109], i703[108], i703[107], i703[106], i703[105], i703[104], i703[103], i703[102], i703[101], i703[100], i703[99], i703[98], i703[97], i703[96], i703[95], i703[94], i703[93], i703[92], i703[91], i703[90], i703[89], i703[88], i703[87], i703[86], i703[85], i703[84], i703[83], i703[82], i703[81], i703[80], i703[79], i703[78], i703[77], i703[76], i703[75], i703[74], i703[73], i703[72], i703[71], i703[70], i703[69], i703[68], i703[67], i703[66], i703[65], i703[64], i703[63], i703[62], i703[61], i703[60], i703[59], i703[58], i703[57], i703[56], i703[55], i703[54], i703[53], i703[52], i703[51], i703[50], i703[49], i703[48], i703[47], i703[46], i703[45], i703[44], i703[43], i703[42], i703[41], i703[40], i703[39], i703[38], i703[37], i703[36], i703[35], i703[34], i703[33], i703[32], i703[31], i703[30], i703[29], i703[28], i703[27], i703[26], i703[25], i703[24], i703[23], i703[22], i703[21], i703[20], i703[19], i703[18], i703[17], i703[16], i703[15], i703[14], i703[13], i703[12], i703[11], i703[10], i703[9], i703[8], i703[7], i703[6], i703[5], i703[4], i703[3], i703[2], i703[1], i703[0]};
wire [131:0] t6 = {1'b0, 1'b0, 1'b0, i716[128], i716[127], i716[126], i716[125], i716[124], i716[123], i716[122], i716[121], i716[120], i716[119], i716[118], i716[117], i716[116], i716[115], i716[114], i716[113], i716[112], i716[111], i716[110], i716[109], i716[108], i716[107], i716[106], i716[105], i716[104], i716[103], i716[102], i716[101], i716[100], i716[99], i716[98], i716[97], i716[96], i716[95], i716[94], i716[93], i716[92], i716[91], i716[90], i716[89], i716[88], i716[87], i716[86], i716[85], i716[84], i716[83], i716[82], i716[81], i716[80], i716[79], i716[78], i716[77], i716[76], i716[75], i716[74], i716[73], i716[72], i716[71], i716[70], i716[69], i716[68], i716[67], i716[66], i716[65], i716[64], i716[63], i716[62], i716[61], i716[60], i716[59], i716[58], i716[57], i716[56], i716[55], i716[54], i716[53], i716[52], i716[51], i716[50], i716[49], i716[48], i716[47], i716[46], i716[45], i716[44], i716[43], i716[42], i716[41], i716[40], i716[39], i716[38], i716[37], i716[36], i716[35], i716[34], i716[33], i716[32], i716[31], i716[30], i716[29], i716[28], i716[27], i716[26], i716[25], i716[24], i716[23], i716[22], i716[21], i716[20], i716[19], i716[18], i716[17], i716[16], i716[15], i716[14], i716[13], i716[12], i716[11], i716[10], i716[9], i716[8], i716[7], i716[6], i716[5], i716[4], i716[3], i716[2], i716[1], i716[0]};
wire [131:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, i519[127], i519[126], i519[125], i519[124], i519[123], i519[122], i519[121], i519[120], i519[119], i519[118], i519[117], i519[116], i519[115], i519[114], i519[113], i519[112], i519[111], i519[110], i519[109], i519[108], i519[107], i519[106], i519[105], i519[104], i519[103], i519[102], i519[101], i519[100], i519[99], i519[98], i519[97], i519[96], i519[95], i519[94], i519[93], i519[92], i519[91], i519[90], i519[89], i519[88], i519[87], i519[86], i519[85], i519[84], i519[83], i519[82], i519[81], i519[80], i519[79], i519[78], i519[77], i519[76], i519[75], i519[74], i519[73], i519[72], i519[71], i519[70], i519[69], i519[68], i519[67], i519[66], i519[65], i519[64], i519[63], i519[62], i519[61], i519[60], i519[59], i519[58], i519[57], i519[56], i519[55], i519[54], i519[53], i519[52], i519[51], i519[50], i519[49], i519[48], i519[47], i519[46], i519[45], i519[44], i519[43], i519[42], i519[41], i519[40], i519[39], i519[38], i519[37], i519[36], i519[35], i519[34], i519[33], i519[32], i519[31], i519[30], i519[29], i519[28], i519[27], i519[26], i519[25], i519[24], i519[23], i519[22], i519[21], i519[20], i519[19], i519[18], i519[17], i519[16], i519[15], i519[14], i519[13], i519[12], i519[11], i519[10], i519[9], i519[8], i519[7], i519[6], i519[5], i519[4], i519[3], i519[2], i519[1], i519[0]};
wire [131:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, i737[127], i737[126], i737[125], i737[124], i737[123], i737[122], i737[121], i737[120], i737[119], i737[118], i737[117], i737[116], i737[115], i737[114], i737[113], i737[112], i737[111], i737[110], i737[109], i737[108], i737[107], i737[106], i737[105], i737[104], i737[103], i737[102], i737[101], i737[100], i737[99], i737[98], i737[97], i737[96], i737[95], i737[94], i737[93], i737[92], i737[91], i737[90], i737[89], i737[88], i737[87], i737[86], i737[85], i737[84], i737[83], i737[82], i737[81], i737[80], i737[79], i737[78], i737[77], i737[76], i737[75], i737[74], i737[73], i737[72], i737[71], i737[70], i737[69], i737[68], i737[67], i737[66], i737[65], i737[64], i737[63], i737[62], i737[61], i737[60], i737[59], i737[58], i737[57], i737[56], i737[55], i737[54], i737[53], i737[52], i737[51], i737[50], i737[49], i737[48], i737[47], i737[46], i737[45], i737[44], i737[43], i737[42], i737[41], i737[40], i737[39], i737[38], i737[37], i737[36], i737[35], i737[34], i737[33], i737[32], i737[31], i737[30], i737[29], i737[28], i737[27], i737[26], i737[25], i737[24], i737[23], i737[22], i737[21], i737[20], i737[19], i737[18], i737[17], i737[16], i737[15], i737[14], i737[13], i737[12], i737[11], i737[10], i737[9], i737[8], i737[7], i737[6], i737[5], i737[4], i737[3], i737[2], i737[1], i737[0]};
wire [131:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219_reduce(input wire [63:0] i623, input wire [95:0] i624, input wire [95:0] i625, input wire [127:0] i626, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i623[63], i623[62], i623[61], i623[60], i623[59], i623[58], i623[57], i623[56], i623[55], i623[54], i623[53], i623[52], i623[51], i623[50], i623[49], i623[48], i623[47], i623[46], i623[45], i623[44], i623[43], i623[42], i623[41], i623[40], i623[39], i623[38], i623[37], i623[36], i623[35], i623[34], i623[33], i623[32], i623[31], i623[30], i623[29], i623[28], i623[27], i623[26], i623[25], i623[24], i623[23], i623[22], i623[21], i623[20], i623[19], i623[18], i623[17], i623[16], i623[15], i623[14], i623[13], i623[12], i623[11], i623[10], i623[9], i623[8], i623[7], i623[6], i623[5], i623[4], i623[3], i623[2], i623[1], i623[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i624[95], i624[94], i624[93], i624[92], i624[91], i624[90], i624[89], i624[88], i624[87], i624[86], i624[85], i624[84], i624[83], i624[82], i624[81], i624[80], i624[79], i624[78], i624[77], i624[76], i624[75], i624[74], i624[73], i624[72], i624[71], i624[70], i624[69], i624[68], i624[67], i624[66], i624[65], i624[64], i624[63], i624[62], i624[61], i624[60], i624[59], i624[58], i624[57], i624[56], i624[55], i624[54], i624[53], i624[52], i624[51], i624[50], i624[49], i624[48], i624[47], i624[46], i624[45], i624[44], i624[43], i624[42], i624[41], i624[40], i624[39], i624[38], i624[37], i624[36], i624[35], i624[34], i624[33], i624[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i625[95], i625[94], i625[93], i625[92], i625[91], i625[90], i625[89], i625[88], i625[87], i625[86], i625[85], i625[84], i625[83], i625[82], i625[81], i625[80], i625[79], i625[78], i625[77], i625[76], i625[75], i625[74], i625[73], i625[72], i625[71], i625[70], i625[69], i625[68], i625[67], i625[66], i625[65], i625[64], i625[63], i625[62], i625[61], i625[60], i625[59], i625[58], i625[57], i625[56], i625[55], i625[54], i625[53], i625[52], i625[51], i625[50], i625[49], i625[48], i625[47], i625[46], i625[45], i625[44], i625[43], i625[42], i625[41], i625[40], i625[39], i625[38], i625[37], i625[36], i625[35], i625[34], i625[33], i625[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i626[127], i626[126], i626[125], i626[124], i626[123], i626[122], i626[121], i626[120], i626[119], i626[118], i626[117], i626[116], i626[115], i626[114], i626[113], i626[112], i626[111], i626[110], i626[109], i626[108], i626[107], i626[106], i626[105], i626[104], i626[103], i626[102], i626[101], i626[100], i626[99], i626[98], i626[97], i626[96], i626[95], i626[94], i626[93], i626[92], i626[91], i626[90], i626[89], i626[88], i626[87], i626[86], i626[85], i626[84], i626[83], i626[82], i626[81], i626[80], i626[79], i626[78], i626[77], i626[76], i626[75], i626[74], i626[73], i626[72], i626[71], i626[70], i626[69], i626[68], i626[67], i626[66], i626[65], i626[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419_reduce(input wire [63:0] i688, input wire [95:0] i689, input wire [95:0] i690, input wire [127:0] i691, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i688[63], i688[62], i688[61], i688[60], i688[59], i688[58], i688[57], i688[56], i688[55], i688[54], i688[53], i688[52], i688[51], i688[50], i688[49], i688[48], i688[47], i688[46], i688[45], i688[44], i688[43], i688[42], i688[41], i688[40], i688[39], i688[38], i688[37], i688[36], i688[35], i688[34], i688[33], i688[32], i688[31], i688[30], i688[29], i688[28], i688[27], i688[26], i688[25], i688[24], i688[23], i688[22], i688[21], i688[20], i688[19], i688[18], i688[17], i688[16], i688[15], i688[14], i688[13], i688[12], i688[11], i688[10], i688[9], i688[8], i688[7], i688[6], i688[5], i688[4], i688[3], i688[2], i688[1], i688[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i689[95], i689[94], i689[93], i689[92], i689[91], i689[90], i689[89], i689[88], i689[87], i689[86], i689[85], i689[84], i689[83], i689[82], i689[81], i689[80], i689[79], i689[78], i689[77], i689[76], i689[75], i689[74], i689[73], i689[72], i689[71], i689[70], i689[69], i689[68], i689[67], i689[66], i689[65], i689[64], i689[63], i689[62], i689[61], i689[60], i689[59], i689[58], i689[57], i689[56], i689[55], i689[54], i689[53], i689[52], i689[51], i689[50], i689[49], i689[48], i689[47], i689[46], i689[45], i689[44], i689[43], i689[42], i689[41], i689[40], i689[39], i689[38], i689[37], i689[36], i689[35], i689[34], i689[33], i689[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i690[95], i690[94], i690[93], i690[92], i690[91], i690[90], i690[89], i690[88], i690[87], i690[86], i690[85], i690[84], i690[83], i690[82], i690[81], i690[80], i690[79], i690[78], i690[77], i690[76], i690[75], i690[74], i690[73], i690[72], i690[71], i690[70], i690[69], i690[68], i690[67], i690[66], i690[65], i690[64], i690[63], i690[62], i690[61], i690[60], i690[59], i690[58], i690[57], i690[56], i690[55], i690[54], i690[53], i690[52], i690[51], i690[50], i690[49], i690[48], i690[47], i690[46], i690[45], i690[44], i690[43], i690[42], i690[41], i690[40], i690[39], i690[38], i690[37], i690[36], i690[35], i690[34], i690[33], i690[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i691[127], i691[126], i691[125], i691[124], i691[123], i691[122], i691[121], i691[120], i691[119], i691[118], i691[117], i691[116], i691[115], i691[114], i691[113], i691[112], i691[111], i691[110], i691[109], i691[108], i691[107], i691[106], i691[105], i691[104], i691[103], i691[102], i691[101], i691[100], i691[99], i691[98], i691[97], i691[96], i691[95], i691[94], i691[93], i691[92], i691[91], i691[90], i691[89], i691[88], i691[87], i691[86], i691[85], i691[84], i691[83], i691[82], i691[81], i691[80], i691[79], i691[78], i691[77], i691[76], i691[75], i691[74], i691[73], i691[72], i691[71], i691[70], i691[69], i691[68], i691[67], i691[66], i691[65], i691[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_263Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_263();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_338Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_338();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_341Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_341();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_463Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_463();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_469Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_469();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_541Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_541();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
