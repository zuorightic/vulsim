`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_65; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_37_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_67; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_69; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_71; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_72; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_73; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_75; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_77; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_37_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_79; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_81; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_83; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_84; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_85; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_37_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_87; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_89; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_37_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_91; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_93; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_95; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_96; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_97; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_37_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_99; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_37_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_101; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_102; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_37_103; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_37_104; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_37_105; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_106; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_107; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_108; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_37_109; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_37_110; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_37_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_114; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_115; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_116; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_37_117; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_37_118; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_37_119; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_37_120; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_121; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_122; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_123; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_124; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_125; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_126; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_37_127; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_37_128; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_37_129; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_37_130; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_37_131; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_37_132; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_37_133; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_37_134; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_37_135; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_136; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_137; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_138; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_37_139; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_37_140; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_37_141; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_37_142; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_37_143; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_37_144; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_37_145; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_37_146; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_37_147; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_148; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_150; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_151; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_152; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_154; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_38_155; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_156; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_159; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_160; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_162; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_38_163; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_164; // decl: <none>; prim: <none>
    logic mul_tree_38_165; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_166; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_167; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_168; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_169; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_170; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_38_171; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_172; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_174; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_175; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_176; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_177; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_178; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_38_179; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_180; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_181; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_182; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_183; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_184; // decl: <none>; prim: <none>
    logic mul_tree_38_185; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_186; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_187; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_188; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_189; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_190; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_191; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_192; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_193; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_194; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_38_195; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_196; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_197; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_198; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_199; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_200; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_201; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_202; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_38_203; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_204; // decl: <none>; prim: <none>
    logic mul_tree_38_205; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_206; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_207; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_208; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_209; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_210; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_38_211; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_212; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_213; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_214; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_215; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_216; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_217; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_218; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_38_219; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_220; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_221; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_222; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_223; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_224; // decl: <none>; prim: <none>
    logic mul_tree_38_225; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_226; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_227; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_228; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_229; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_230; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_231; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_232; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_233; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_234; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_38_235; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_236; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_237; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_238; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_239; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_240; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_241; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_242; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_38_243; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_244; // decl: <none>; prim: <none>
    logic mul_tree_38_245; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_246; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_247; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_248; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_249; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_250; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_38_251; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_252; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_253; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_254; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_255; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_256; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_257; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_258; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_38_259; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_260; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_261; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_262; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_263; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_264; // decl: <none>; prim: <none>
    logic mul_tree_38_265; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_266; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_267; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_268; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_269; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_270; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_271; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_272; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_273; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_274; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_38_275; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_276; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_277; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_278; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_279; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_280; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_281; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_282; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_38_283; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_284; // decl: <none>; prim: <none>
    logic mul_tree_38_285; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_286; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_287; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_288; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_289; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_290; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_38_291; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_292; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_293; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_294; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_295; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_296; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_297; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_298; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_38_299; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_300; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_301; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_302; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_303; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_38_304; // decl: <none>; prim: <none>
    logic mul_tree_38_305; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_38_306; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_307; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_38_308; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_38_309; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_38_310; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_311; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_312; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_313; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_314; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_315; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_316; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_317; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_318; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_319; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_320; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_321; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_322; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_323; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_324; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_38_325; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_326; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_327; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_328; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_38_329; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_38_330; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_38_331; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_332; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_333; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_334; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_335; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_336; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_337; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_338; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_339; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_38_340; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_341; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_342; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_343; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_344; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_345; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_346; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_347; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_348; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_349; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_350; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_351; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_352; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_353; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_354; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_38_355; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_356; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_357; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_358; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_38_359; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_38_360; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_38_361; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_362; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_363; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_38_364; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_365; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_366; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_367; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_368; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_369; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_38_370; // decl: <none>; prim: <none>
    logic [82:0] mul_tree_38_371; // decl: <none>; prim: <none>
    logic [82:0] mul_tree_38_372; // decl: <none>; prim: <none>
    logic [82:0] mul_tree_38_373; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_374; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_375; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_376; // decl: <none>; prim: <none>
    logic [114:0] mul_tree_38_377; // decl: <none>; prim: <none>
    logic [114:0] mul_tree_38_378; // decl: <none>; prim: <none>
    logic [114:0] mul_tree_38_379; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_38_380; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_38_381; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_38_382; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_383; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_384; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_38_385; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_386; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_387; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_388; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_389; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_390; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_391; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_38_392; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_38_393; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_38_394; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_395; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_396; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_397; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_38_398; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_38_399; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_38_400; // decl: <none>; prim: <none>
    logic [115:0] mul_tree_38_401; // decl: <none>; prim: <none>
    logic [115:0] mul_tree_38_402; // decl: <none>; prim: <none>
    logic [115:0] mul_tree_38_403; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_404; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_405; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_38_406; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_38_407; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_38_408; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_38_409; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_410; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_411; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_412; // decl: <none>; prim: <none>
    logic [116:0] mul_tree_38_413; // decl: <none>; prim: <none>
    logic [116:0] mul_tree_38_414; // decl: <none>; prim: <none>
    logic [116:0] mul_tree_38_415; // decl: <none>; prim: <none>
    logic [164:0] mul_tree_38_416; // decl: <none>; prim: <none>
    logic [164:0] mul_tree_38_417; // decl: <none>; prim: <none>
    logic [164:0] mul_tree_38_418; // decl: <none>; prim: <none>
    logic [165:0] mul_tree_38_419; // decl: <none>; prim: <none>
    logic [165:0] mul_tree_38_420; // decl: <none>; prim: <none>
    logic [165:0] mul_tree_38_421; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_38_422; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_38_423; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_38_424; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_425; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_426; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_427; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_428; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_429; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_430; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_431; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_39_432; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_433; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_434; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_435; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_436; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_437; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_438; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_439; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_39_440; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_441; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_442; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_443; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_39_444; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_445; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_446; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_447; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_448; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_449; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_450; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_451; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_39_452; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_453; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_454; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_455; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_456; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_457; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_458; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_459; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_460; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_461; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_462; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_463; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_39_464; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_465; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_466; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_467; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_468; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_469; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_471; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_39_472; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_473; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_475; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_39_476; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_477; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_478; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_479; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_480; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_481; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_482; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_483; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_39_484; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_485; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_486; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_487; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_488; // decl: <none>; prim: <none>
    logic mul_tree_39_489; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_490; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_39_491; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_492; // decl: <none>; prim: <none>
    logic mul_tree_39_493; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_494; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_39_495; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_496; // decl: <none>; prim: <none>
    logic mul_tree_39_497; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_498; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_39_499; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_39_500; // decl: <none>; prim: <none>
    logic mul_tree_39_501; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_39_502; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_39_503; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_504; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_39_505; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_39_506; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_39_507; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_508; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_509; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_510; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_39_511; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_39_512; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_39_513; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_514; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_515; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_516; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_517; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_518; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_39_519; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_39_520; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_39_521; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_39_522; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_523; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_524; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_525; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_526; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_527; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_528; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_529; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_530; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_531; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_532; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_533; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_534; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_39_535; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_39_536; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_39_537; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_538; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_539; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_39_540; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_39_541; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_39_542; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_39_543; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_544; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_545; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_546; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_547; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_548; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_549; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_39_550; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_39_551; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_39_552; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_553; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_554; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_555; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_39_556; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_39_557; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_39_558; // decl: <none>; prim: <none>
    logic [132:0] mul_tree_39_559; // decl: <none>; prim: <none>
    logic [132:0] mul_tree_39_560; // decl: <none>; prim: <none>
    logic [132:0] mul_tree_39_561; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_562; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_66_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_86_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_90_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_98_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_111_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_126_s2; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_129_s3; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_132_s3; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_135_s3; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_138_s3; // decl: <none>; prim: <none>
    logic [98:0] rtlzz_pipe_141_s4; // decl: <none>; prim: <none>
    logic [130:0] rtlzz_pipe_144_s4; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s6; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_370_s7; // decl: <none>; prim: <none>
    logic [82:0] rtlzz_pipe_373_s7; // decl: <none>; prim: <none>
    logic [98:0] rtlzz_pipe_376_s7; // decl: <none>; prim: <none>
    logic [114:0] rtlzz_pipe_379_s7; // decl: <none>; prim: <none>
    logic [130:0] rtlzz_pipe_382_s7; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_385_s7; // decl: <none>; prim: <none>
    logic [146:0] rtlzz_pipe_388_s7; // decl: <none>; prim: <none>
    logic [162:0] rtlzz_pipe_391_s7; // decl: <none>; prim: <none>
    logic [178:0] rtlzz_pipe_394_s7; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_397_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s5 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s7 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(129'(tmp_workload_top_int_129__16_v0)), .b(129'(n3_v0)), .cin(1'b0), .value(s8_norm_sub_14_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_sub_18_v0[63:0]));
    assign s8_norm_sub_18_v0[128:64] = '0;
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_148; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_425; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_562; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(16'(mul_tree_37_40)), .b(16'(mul_tree_37_41)), .cin(1'b0), .value(mul_tree_37_42));
    assign mul_tree_37_43 = mul_precision_28[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(16'(mul_tree_37_43)), .b(16'(mul_tree_37_44)), .cin(1'b0), .value(mul_tree_37_45));
    assign mul_tree_37_46 = {mul_tree_37_45, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(16'(mul_tree_37_47)), .b(16'(mul_tree_37_48)), .cin(1'b0), .value(mul_tree_37_49));
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(16'(mul_tree_37_51)), .b(16'(mul_tree_37_52)), .cin(1'b0), .value(mul_tree_37_53));
    assign mul_tree_37_54 = {mul_tree_37_53, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = mul_precision_28[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_37_56 = mul_precision_29[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_57Core rtlzz_owner_57(.a(16'(mul_tree_37_55)), .b(16'(mul_tree_37_56)), .cin(1'b0), .value(mul_tree_37_57));
    assign mul_tree_37_58 = {mul_tree_37_57, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_59 = mul_precision_28[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_37_60 = mul_precision_29[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(16'(mul_tree_37_59)), .b(16'(mul_tree_37_60)), .cin(1'b0), .value(mul_tree_37_61));
    assign mul_tree_37_62 = {mul_tree_37_61, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_63 = mul_precision_28[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_37_64 = mul_precision_29[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_65Core rtlzz_owner_65(.a(16'(mul_tree_37_63)), .b(16'(mul_tree_37_64)), .cin(1'b0), .value(mul_tree_37_65));
    assign mul_tree_37_66 = {mul_tree_37_65, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_67 = mul_precision_28[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_37_68 = mul_precision_29[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_69Core rtlzz_owner_69(.a(16'(mul_tree_37_67)), .b(16'(mul_tree_37_68)), .cin(1'b0), .value(mul_tree_37_69));
    assign mul_tree_37_70 = {mul_tree_37_69, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_71 = mul_precision_28[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_72 = mul_precision_29[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(16'(mul_tree_37_71)), .b(16'(mul_tree_37_72)), .cin(1'b0), .value(mul_tree_37_73));
    assign mul_tree_37_74 = {mul_tree_37_73, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_75 = mul_precision_28[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_76 = mul_precision_29[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_77Core rtlzz_owner_77(.a(16'(mul_tree_37_75)), .b(16'(mul_tree_37_76)), .cin(1'b0), .value(mul_tree_37_77));
    assign mul_tree_37_78 = {mul_tree_37_77, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_79 = mul_precision_28[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_80 = mul_precision_29[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_81Core rtlzz_owner_81(.a(16'(mul_tree_37_79)), .b(16'(mul_tree_37_80)), .cin(1'b0), .value(mul_tree_37_81));
    assign mul_tree_37_82 = {mul_tree_37_81, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_83 = mul_precision_28[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_84 = mul_precision_29[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(16'(mul_tree_37_83)), .b(16'(mul_tree_37_84)), .cin(1'b0), .value(mul_tree_37_85));
    assign mul_tree_37_86 = {mul_tree_37_85, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_87 = mul_precision_28[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_37_88 = mul_precision_29[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_89Core rtlzz_owner_89(.a(16'(mul_tree_37_87)), .b(16'(mul_tree_37_88)), .cin(1'b0), .value(mul_tree_37_89));
    assign mul_tree_37_90 = {mul_tree_37_89, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_91 = mul_precision_28[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_37_92 = mul_precision_29[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_93Core rtlzz_owner_93(.a(16'(mul_tree_37_91)), .b(16'(mul_tree_37_92)), .cin(1'b0), .value(mul_tree_37_93));
    assign mul_tree_37_94 = {mul_tree_37_93, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_95 = mul_precision_28[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_37_96 = mul_precision_29[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(16'(mul_tree_37_95)), .b(16'(mul_tree_37_96)), .cin(1'b0), .value(mul_tree_37_97));
    assign mul_tree_37_98 = {mul_tree_37_97, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_99 = mul_precision_28[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_37_100 = mul_precision_29[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_101Core rtlzz_owner_101(.a(16'(mul_tree_37_99)), .b(16'(mul_tree_37_100)), .cin(1'b0), .value(mul_tree_37_101));
    assign mul_tree_37_102 = {mul_tree_37_101, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_103 = ({17'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_104 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105Core rtlzz_owner_105(.a(32'(mul_tree_37_103)), .b(48'(mul_tree_37_104)), .cin(1'h0), .value(mul_tree_37_105));
    assign mul_tree_37_106 = ({17'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_107 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(64'(mul_tree_37_106)), .b(80'(mul_tree_37_107)), .cin(1'h0), .value(mul_tree_37_108));
    assign mul_tree_37_109 = ({17'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_110 = ({1'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_111Core rtlzz_owner_111(.a(48'(mul_tree_37_109)), .b(64'(mul_tree_37_110)), .cin(1'h0), .value(mul_tree_37_111));
    assign mul_tree_37_112 = ({17'h0, rtlzz_pipe_66_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_113 = ({1'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(80'(mul_tree_37_112)), .b(96'(mul_tree_37_113)), .cin(1'h0), .value(mul_tree_37_114));
    assign mul_tree_37_115 = ({17'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_116 = ({1'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_117Core rtlzz_owner_117(.a(64'(mul_tree_37_115)), .b(80'(mul_tree_37_116)), .cin(1'h0), .value(mul_tree_37_117));
    assign mul_tree_37_118 = ({17'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_119 = ({1'h0, rtlzz_pipe_86_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(96'(mul_tree_37_118)), .b(112'(mul_tree_37_119)), .cin(1'h0), .value(mul_tree_37_120));
    assign mul_tree_37_121 = ({17'h0, rtlzz_pipe_90_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_122 = ({1'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(80'(mul_tree_37_121)), .b(96'(mul_tree_37_122)), .cin(1'h0), .value(mul_tree_37_123));
    assign mul_tree_37_124 = ({17'h0, rtlzz_pipe_98_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_125 = ({1'h0, rtlzz_pipe_102_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(112'(mul_tree_37_124)), .b(128'(mul_tree_37_125)), .cin(1'h0), .value(mul_tree_37_126[127:0]));
    assign mul_tree_37_126[128:128] = '0;
    assign mul_tree_37_127 = ({33'h0, rtlzz_pipe_105_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_128 = ({1'h0, rtlzz_pipe_108_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(49'(mul_tree_37_127)), .b(81'(mul_tree_37_128)), .cin(1'h0), .value(mul_tree_37_129));
    assign mul_tree_37_130 = ({33'h0, rtlzz_pipe_111_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_131 = ({1'h0, rtlzz_pipe_114_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(65'(mul_tree_37_130)), .b(97'(mul_tree_37_131)), .cin(1'h0), .value(mul_tree_37_132));
    assign mul_tree_37_133 = ({33'h0, rtlzz_pipe_117_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_134 = ({1'h0, rtlzz_pipe_120_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_135Core rtlzz_owner_135(.a(81'(mul_tree_37_133)), .b(113'(mul_tree_37_134)), .cin(1'h0), .value(mul_tree_37_135));
    assign mul_tree_37_136 = ({33'h0, rtlzz_pipe_123_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_137 = ({1'h0, rtlzz_pipe_126_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(97'(mul_tree_37_136)), .b(129'(mul_tree_37_137)), .cin(1'h0), .value(mul_tree_37_138[127:0]));
    assign mul_tree_37_138[129:128] = '0;
    assign mul_tree_37_139 = ({17'h0, rtlzz_pipe_129_s3}); // decl: <none>; prim: <none>
    assign mul_tree_37_140 = ({1'h0, rtlzz_pipe_132_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_141Core rtlzz_owner_141(.a(82'(mul_tree_37_139)), .b(98'(mul_tree_37_140)), .cin(1'h0), .value(mul_tree_37_141));
    assign mul_tree_37_142 = ({17'h0, rtlzz_pipe_135_s3}); // decl: <none>; prim: <none>
    assign mul_tree_37_143 = ({1'h0, rtlzz_pipe_138_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(114'(mul_tree_37_142)), .b(130'(mul_tree_37_143)), .cin(1'h0), .value(mul_tree_37_144[127:0]));
    assign mul_tree_37_144[130:128] = '0;
    assign mul_tree_37_145 = ({33'h0, rtlzz_pipe_141_s4}); // decl: <none>; prim: <none>
    assign mul_tree_37_146 = ({1'h0, rtlzz_pipe_144_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_147Core rtlzz_owner_147(.a(99'(mul_tree_37_145)), .b(131'(mul_tree_37_146)), .cin(1'h0), .value(mul_tree_37_147[127:0]));
    assign mul_tree_37_147[131:128] = '0;
    assign mul_tree_37_148 = mul_tree_37_147[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_149 = rtlzz_pipe_31_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_150 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(16'(mul_tree_38_149)), .b(16'(mul_tree_38_150)), .cin(1'b0), .value(mul_tree_38_151));
    assign mul_tree_38_152 = rtlzz_pipe_31_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_153 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(16'(mul_tree_38_152)), .b(16'(mul_tree_38_153)), .cin(1'b0), .value(mul_tree_38_154));
    assign mul_tree_38_155 = {mul_tree_38_154, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_156 = rtlzz_pipe_31_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_157 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_158Core rtlzz_owner_158(.a(16'(mul_tree_38_156)), .b(16'(mul_tree_38_157)), .cin(1'b0), .value(mul_tree_38_158));
    assign mul_tree_38_159 = {mul_tree_38_158, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_160 = rtlzz_pipe_31_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_161 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_162Core rtlzz_owner_162(.a(16'(mul_tree_38_160)), .b(16'(mul_tree_38_161)), .cin(1'b0), .value(mul_tree_38_162));
    assign mul_tree_38_163 = {mul_tree_38_162, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_164 = rtlzz_pipe_31_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_165 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(16'(mul_tree_38_164)), .b(1'(mul_tree_38_165)), .cin(1'b0), .value(mul_tree_38_166));
    assign mul_tree_38_167 = {mul_tree_38_166, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_168 = rtlzz_pipe_31_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_38_169 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(16'(mul_tree_38_168)), .b(16'(mul_tree_38_169)), .cin(1'b0), .value(mul_tree_38_170));
    assign mul_tree_38_171 = {mul_tree_38_170, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_172 = rtlzz_pipe_31_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_38_173 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(16'(mul_tree_38_172)), .b(16'(mul_tree_38_173)), .cin(1'b0), .value(mul_tree_38_174));
    assign mul_tree_38_175 = {mul_tree_38_174, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_176 = rtlzz_pipe_31_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_38_177 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_178Core rtlzz_owner_178(.a(16'(mul_tree_38_176)), .b(16'(mul_tree_38_177)), .cin(1'b0), .value(mul_tree_38_178));
    assign mul_tree_38_179 = {mul_tree_38_178, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_180 = rtlzz_pipe_31_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_38_181 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_182Core rtlzz_owner_182(.a(16'(mul_tree_38_180)), .b(16'(mul_tree_38_181)), .cin(1'b0), .value(mul_tree_38_182));
    assign mul_tree_38_183 = {mul_tree_38_182, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_184 = rtlzz_pipe_31_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_38_185 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_186Core rtlzz_owner_186(.a(16'(mul_tree_38_184)), .b(1'(mul_tree_38_185)), .cin(1'b0), .value(mul_tree_38_186));
    assign mul_tree_38_187 = {mul_tree_38_186, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_188 = rtlzz_pipe_31_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_189 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_190Core rtlzz_owner_190(.a(16'(mul_tree_38_188)), .b(16'(mul_tree_38_189)), .cin(1'b0), .value(mul_tree_38_190));
    assign mul_tree_38_191 = {mul_tree_38_190, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_192 = rtlzz_pipe_31_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_193 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(16'(mul_tree_38_192)), .b(16'(mul_tree_38_193)), .cin(1'b0), .value(mul_tree_38_194));
    assign mul_tree_38_195 = {mul_tree_38_194, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_196 = rtlzz_pipe_31_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_197 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(16'(mul_tree_38_196)), .b(16'(mul_tree_38_197)), .cin(1'b0), .value(mul_tree_38_198));
    assign mul_tree_38_199 = {mul_tree_38_198, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_200 = rtlzz_pipe_31_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_201 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_202Core rtlzz_owner_202(.a(16'(mul_tree_38_200)), .b(16'(mul_tree_38_201)), .cin(1'b0), .value(mul_tree_38_202));
    assign mul_tree_38_203 = {mul_tree_38_202, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_204 = rtlzz_pipe_31_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_205 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(16'(mul_tree_38_204)), .b(1'(mul_tree_38_205)), .cin(1'b0), .value(mul_tree_38_206));
    assign mul_tree_38_207 = {mul_tree_38_206, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_208 = rtlzz_pipe_31_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_38_209 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_210Core rtlzz_owner_210(.a(16'(mul_tree_38_208)), .b(16'(mul_tree_38_209)), .cin(1'b0), .value(mul_tree_38_210));
    assign mul_tree_38_211 = {mul_tree_38_210, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_212 = rtlzz_pipe_31_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_38_213 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_214Core rtlzz_owner_214(.a(16'(mul_tree_38_212)), .b(16'(mul_tree_38_213)), .cin(1'b0), .value(mul_tree_38_214));
    assign mul_tree_38_215 = {mul_tree_38_214, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_216 = rtlzz_pipe_31_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_38_217 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(16'(mul_tree_38_216)), .b(16'(mul_tree_38_217)), .cin(1'b0), .value(mul_tree_38_218));
    assign mul_tree_38_219 = {mul_tree_38_218, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_220 = rtlzz_pipe_31_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_38_221 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_222Core rtlzz_owner_222(.a(16'(mul_tree_38_220)), .b(16'(mul_tree_38_221)), .cin(1'b0), .value(mul_tree_38_222));
    assign mul_tree_38_223 = {mul_tree_38_222, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_224 = rtlzz_pipe_31_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_38_225 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(16'(mul_tree_38_224)), .b(1'(mul_tree_38_225)), .cin(1'b0), .value(mul_tree_38_226));
    assign mul_tree_38_227 = {mul_tree_38_226, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_228 = rtlzz_pipe_31_s6[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_229 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(16'(mul_tree_38_228)), .b(16'(mul_tree_38_229)), .cin(1'b0), .value(mul_tree_38_230));
    assign mul_tree_38_231 = {mul_tree_38_230, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_232 = rtlzz_pipe_31_s6[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_233 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(16'(mul_tree_38_232)), .b(16'(mul_tree_38_233)), .cin(1'b0), .value(mul_tree_38_234));
    assign mul_tree_38_235 = {mul_tree_38_234, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_236 = rtlzz_pipe_31_s6[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_237 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(16'(mul_tree_38_236)), .b(16'(mul_tree_38_237)), .cin(1'b0), .value(mul_tree_38_238));
    assign mul_tree_38_239 = {mul_tree_38_238, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_240 = rtlzz_pipe_31_s6[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_241 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_242Core rtlzz_owner_242(.a(16'(mul_tree_38_240)), .b(16'(mul_tree_38_241)), .cin(1'b0), .value(mul_tree_38_242));
    assign mul_tree_38_243 = {mul_tree_38_242, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_244 = rtlzz_pipe_31_s6[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_245 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_246Core rtlzz_owner_246(.a(16'(mul_tree_38_244)), .b(1'(mul_tree_38_245)), .cin(1'b0), .value(mul_tree_38_246));
    assign mul_tree_38_247 = {mul_tree_38_246, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_248 = rtlzz_pipe_31_s6[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_38_249 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_250Core rtlzz_owner_250(.a(16'(mul_tree_38_248)), .b(16'(mul_tree_38_249)), .cin(1'b0), .value(mul_tree_38_250));
    assign mul_tree_38_251 = {mul_tree_38_250, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_252 = rtlzz_pipe_31_s6[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_38_253 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_254Core rtlzz_owner_254(.a(16'(mul_tree_38_252)), .b(16'(mul_tree_38_253)), .cin(1'b0), .value(mul_tree_38_254));
    assign mul_tree_38_255 = {mul_tree_38_254, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_256 = rtlzz_pipe_31_s6[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_38_257 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_258Core rtlzz_owner_258(.a(16'(mul_tree_38_256)), .b(16'(mul_tree_38_257)), .cin(1'b0), .value(mul_tree_38_258));
    assign mul_tree_38_259 = {mul_tree_38_258, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_260 = rtlzz_pipe_31_s6[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_38_261 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_262Core rtlzz_owner_262(.a(16'(mul_tree_38_260)), .b(16'(mul_tree_38_261)), .cin(1'b0), .value(mul_tree_38_262));
    assign mul_tree_38_263 = {mul_tree_38_262, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_264 = rtlzz_pipe_31_s6[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_38_265 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_266Core rtlzz_owner_266(.a(16'(mul_tree_38_264)), .b(1'(mul_tree_38_265)), .cin(1'b0), .value(mul_tree_38_266));
    assign mul_tree_38_267 = {mul_tree_38_266, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_268 = rtlzz_pipe_31_s6[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_269 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_270Core rtlzz_owner_270(.a(16'(mul_tree_38_268)), .b(16'(mul_tree_38_269)), .cin(1'b0), .value(mul_tree_38_270));
    assign mul_tree_38_271 = {mul_tree_38_270, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_272 = rtlzz_pipe_31_s6[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_273 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_274Core rtlzz_owner_274(.a(16'(mul_tree_38_272)), .b(16'(mul_tree_38_273)), .cin(1'b0), .value(mul_tree_38_274));
    assign mul_tree_38_275 = {mul_tree_38_274, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_276 = rtlzz_pipe_31_s6[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_277 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_278Core rtlzz_owner_278(.a(16'(mul_tree_38_276)), .b(16'(mul_tree_38_277)), .cin(1'b0), .value(mul_tree_38_278));
    assign mul_tree_38_279 = {mul_tree_38_278, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_280 = rtlzz_pipe_31_s6[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_281 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_282Core rtlzz_owner_282(.a(16'(mul_tree_38_280)), .b(16'(mul_tree_38_281)), .cin(1'b0), .value(mul_tree_38_282));
    assign mul_tree_38_283 = {mul_tree_38_282, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_284 = rtlzz_pipe_31_s6[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_285 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_286Core rtlzz_owner_286(.a(16'(mul_tree_38_284)), .b(1'(mul_tree_38_285)), .cin(1'b0), .value(mul_tree_38_286));
    assign mul_tree_38_287 = {mul_tree_38_286, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_288 = rtlzz_pipe_31_s6[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_38_289 = rtlzz_pipe_32_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_290Core rtlzz_owner_290(.a(16'(mul_tree_38_288)), .b(16'(mul_tree_38_289)), .cin(1'b0), .value(mul_tree_38_290));
    assign mul_tree_38_291 = {mul_tree_38_290, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_292 = rtlzz_pipe_31_s6[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_38_293 = rtlzz_pipe_32_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294Core rtlzz_owner_294(.a(16'(mul_tree_38_292)), .b(16'(mul_tree_38_293)), .cin(1'b0), .value(mul_tree_38_294));
    assign mul_tree_38_295 = {mul_tree_38_294, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_296 = rtlzz_pipe_31_s6[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_38_297 = rtlzz_pipe_32_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(16'(mul_tree_38_296)), .b(16'(mul_tree_38_297)), .cin(1'b0), .value(mul_tree_38_298));
    assign mul_tree_38_299 = {mul_tree_38_298, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_300 = rtlzz_pipe_31_s6[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_38_301 = rtlzz_pipe_32_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_302Core rtlzz_owner_302(.a(16'(mul_tree_38_300)), .b(16'(mul_tree_38_301)), .cin(1'b0), .value(mul_tree_38_302));
    assign mul_tree_38_303 = {mul_tree_38_302, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_304 = rtlzz_pipe_31_s6[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_38_305 = rtlzz_pipe_32_s6[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_306Core rtlzz_owner_306(.a(16'(mul_tree_38_304)), .b(1'(mul_tree_38_305)), .cin(1'b0), .value(mul_tree_38_306));
    assign mul_tree_38_307 = {mul_tree_38_306, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_308 = ({17'h0, mul_tree_38_151}); // decl: <none>; prim: <none>
    assign mul_tree_38_309 = ({1'h0, mul_tree_38_155}); // decl: <none>; prim: <none>
    assign mul_tree_38_311 = ({17'h0, mul_tree_38_159}); // decl: <none>; prim: <none>
    assign mul_tree_38_312 = ({1'h0, mul_tree_38_163}); // decl: <none>; prim: <none>
    assign mul_tree_38_314 = ({1'h0, mul_tree_38_167}); // decl: <none>; prim: <none>
    assign mul_tree_38_315 = ({34'h0, mul_tree_38_171}); // decl: <none>; prim: <none>
    assign mul_tree_38_317 = ({17'h0, mul_tree_38_175}); // decl: <none>; prim: <none>
    assign mul_tree_38_318 = ({1'h0, mul_tree_38_179}); // decl: <none>; prim: <none>
    assign mul_tree_38_320 = ({2'h0, mul_tree_38_183}); // decl: <none>; prim: <none>
    assign mul_tree_38_321 = ({1'h0, mul_tree_38_187}); // decl: <none>; prim: <none>
    assign mul_tree_38_323 = ({17'h0, mul_tree_38_191}); // decl: <none>; prim: <none>
    assign mul_tree_38_324 = ({1'h0, mul_tree_38_195}); // decl: <none>; prim: <none>
    assign mul_tree_38_326 = ({17'h0, mul_tree_38_199}); // decl: <none>; prim: <none>
    assign mul_tree_38_327 = ({1'h0, mul_tree_38_203}); // decl: <none>; prim: <none>
    assign mul_tree_38_329 = ({1'h0, mul_tree_38_207}); // decl: <none>; prim: <none>
    assign mul_tree_38_330 = ({34'h0, mul_tree_38_211}); // decl: <none>; prim: <none>
    assign mul_tree_38_332 = ({17'h0, mul_tree_38_215}); // decl: <none>; prim: <none>
    assign mul_tree_38_333 = ({1'h0, mul_tree_38_219}); // decl: <none>; prim: <none>
    assign mul_tree_38_335 = ({2'h0, mul_tree_38_223}); // decl: <none>; prim: <none>
    assign mul_tree_38_336 = ({1'h0, mul_tree_38_227}); // decl: <none>; prim: <none>
    assign mul_tree_38_338 = ({17'h0, mul_tree_38_231}); // decl: <none>; prim: <none>
    assign mul_tree_38_339 = ({1'h0, mul_tree_38_235}); // decl: <none>; prim: <none>
    assign mul_tree_38_341 = ({17'h0, mul_tree_38_239}); // decl: <none>; prim: <none>
    assign mul_tree_38_342 = ({1'h0, mul_tree_38_243}); // decl: <none>; prim: <none>
    assign mul_tree_38_344 = ({1'h0, mul_tree_38_247}); // decl: <none>; prim: <none>
    assign mul_tree_38_345 = ({34'h0, mul_tree_38_251}); // decl: <none>; prim: <none>
    assign mul_tree_38_347 = ({17'h0, mul_tree_38_255}); // decl: <none>; prim: <none>
    assign mul_tree_38_348 = ({1'h0, mul_tree_38_259}); // decl: <none>; prim: <none>
    assign mul_tree_38_350 = ({2'h0, mul_tree_38_263}); // decl: <none>; prim: <none>
    assign mul_tree_38_351 = ({1'h0, mul_tree_38_267}); // decl: <none>; prim: <none>
    assign mul_tree_38_353 = ({17'h0, mul_tree_38_271}); // decl: <none>; prim: <none>
    assign mul_tree_38_354 = ({1'h0, mul_tree_38_275}); // decl: <none>; prim: <none>
    assign mul_tree_38_356 = ({17'h0, mul_tree_38_279}); // decl: <none>; prim: <none>
    assign mul_tree_38_357 = ({1'h0, mul_tree_38_283}); // decl: <none>; prim: <none>
    assign mul_tree_38_359 = ({1'h0, mul_tree_38_287}); // decl: <none>; prim: <none>
    assign mul_tree_38_360 = ({34'h0, mul_tree_38_291}); // decl: <none>; prim: <none>
    assign mul_tree_38_362 = ({17'h0, mul_tree_38_295}); // decl: <none>; prim: <none>
    assign mul_tree_38_363 = ({1'h0, mul_tree_38_299}); // decl: <none>; prim: <none>
    assign mul_tree_38_365 = ({2'h0, mul_tree_38_303}); // decl: <none>; prim: <none>
    assign mul_tree_38_366 = ({1'h0, mul_tree_38_307}); // decl: <none>; prim: <none>
    assign mul_tree_38_368 = ({33'h0, mul_tree_38_310}); // decl: <none>; prim: <none>
    assign mul_tree_38_369 = ({1'h0, mul_tree_38_313}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370_reduce rtlzz_reduce_370(.i151(mul_tree_38_151), .i154(mul_tree_38_154), .i158(mul_tree_38_158), .i162(mul_tree_38_162), .y(mul_tree_38_370));
    assign mul_tree_38_371 = ({1'h0, mul_tree_38_316}); // decl: <none>; prim: <none>
    assign mul_tree_38_372 = ({2'h0, mul_tree_38_319}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373_reduce rtlzz_reduce_373(.i166(mul_tree_38_166), .i170(mul_tree_38_170), .i174(mul_tree_38_174), .i178(mul_tree_38_178), .y(mul_tree_38_373));
    assign mul_tree_38_374 = ({1'h0, mul_tree_38_322}); // decl: <none>; prim: <none>
    assign mul_tree_38_375 = ({18'h0, mul_tree_38_325}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376_reduce rtlzz_reduce_376(.i182(mul_tree_38_182), .i186(mul_tree_38_186), .i190(mul_tree_38_190), .i194(mul_tree_38_194), .y(mul_tree_38_376));
    assign mul_tree_38_377 = ({2'h0, mul_tree_38_328}); // decl: <none>; prim: <none>
    assign mul_tree_38_378 = ({1'h0, mul_tree_38_331}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_379_reduce rtlzz_reduce_379(.i198(mul_tree_38_198), .i202(mul_tree_38_202), .i206(mul_tree_38_206), .i210(mul_tree_38_210), .y(mul_tree_38_379));
    assign mul_tree_38_380 = ({18'h0, mul_tree_38_334}); // decl: <none>; prim: <none>
    assign mul_tree_38_381 = ({1'h0, mul_tree_38_337}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382_reduce rtlzz_reduce_382(.i214(mul_tree_38_214), .i218(mul_tree_38_218), .i222(mul_tree_38_222), .i226(mul_tree_38_226), .y(mul_tree_38_382));
    assign mul_tree_38_383 = ({33'h0, mul_tree_38_340}); // decl: <none>; prim: <none>
    assign mul_tree_38_384 = ({1'h0, mul_tree_38_343}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385_reduce rtlzz_reduce_385(.i230(mul_tree_38_230), .i234(mul_tree_38_234), .i238(mul_tree_38_238), .i242(mul_tree_38_242), .y(mul_tree_38_385));
    assign mul_tree_38_386 = ({1'h0, mul_tree_38_346}); // decl: <none>; prim: <none>
    assign mul_tree_38_387 = ({2'h0, mul_tree_38_349}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388_reduce rtlzz_reduce_388(.i246(mul_tree_38_246), .i250(mul_tree_38_250), .i254(mul_tree_38_254), .i258(mul_tree_38_258), .y(mul_tree_38_388));
    assign mul_tree_38_389 = ({1'h0, mul_tree_38_352}); // decl: <none>; prim: <none>
    assign mul_tree_38_390 = ({18'h0, mul_tree_38_355}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391_reduce rtlzz_reduce_391(.i262(mul_tree_38_262), .i266(mul_tree_38_266), .i270(mul_tree_38_270), .i274(mul_tree_38_274), .y(mul_tree_38_391));
    assign mul_tree_38_392 = ({2'h0, mul_tree_38_358}); // decl: <none>; prim: <none>
    assign mul_tree_38_393 = ({1'h0, mul_tree_38_361}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394_reduce rtlzz_reduce_394(.i278(mul_tree_38_278), .i282(mul_tree_38_282), .i286(mul_tree_38_286), .i290(mul_tree_38_290), .y(mul_tree_38_394));
    assign mul_tree_38_395 = ({18'h0, mul_tree_38_364}); // decl: <none>; prim: <none>
    assign mul_tree_38_396 = ({1'h0, mul_tree_38_367}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397_reduce rtlzz_reduce_397(.i294(mul_tree_38_294), .i298(mul_tree_38_298), .i302(mul_tree_38_302), .i306(mul_tree_38_306), .y(mul_tree_38_397));
    assign mul_tree_38_398 = ({2'h0, rtlzz_pipe_370_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_399 = ({1'h0, rtlzz_pipe_373_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_401 = ({17'h0, rtlzz_pipe_376_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_402 = ({1'h0, rtlzz_pipe_379_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_404 = ({16'h0, rtlzz_pipe_382_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_405 = ({1'h0, rtlzz_pipe_385_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_407 = ({17'h0, rtlzz_pipe_388_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_408 = ({1'h0, rtlzz_pipe_391_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_410 = ({17'h0, rtlzz_pipe_394_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_411 = ({1'h0, rtlzz_pipe_397_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_413 = ({33'h0, mul_tree_38_400}); // decl: <none>; prim: <none>
    assign mul_tree_38_414 = ({1'h0, mul_tree_38_403}); // decl: <none>; prim: <none>
    assign mul_tree_38_416 = ({18'h0, mul_tree_38_406}); // decl: <none>; prim: <none>
    assign mul_tree_38_417 = ({1'h0, mul_tree_38_409}); // decl: <none>; prim: <none>
    assign mul_tree_38_419 = ({49'h0, mul_tree_38_415}); // decl: <none>; prim: <none>
    assign mul_tree_38_420 = ({1'h0, mul_tree_38_418}); // decl: <none>; prim: <none>
    assign mul_tree_38_422 = ({31'h0, mul_tree_38_421}); // decl: <none>; prim: <none>
    assign mul_tree_38_423 = ({1'h0, mul_tree_38_412}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_424_reduce rtlzz_reduce_424(.i618(rtlzz_pipe_370_s7), .i619(rtlzz_pipe_373_s7), .i620(rtlzz_pipe_376_s7), .i621(rtlzz_pipe_379_s7), .i622(rtlzz_pipe_382_s7), .i623(rtlzz_pipe_385_s7), .i624(rtlzz_pipe_388_s7), .i625(rtlzz_pipe_391_s7), .i626(rtlzz_pipe_394_s7), .i627(rtlzz_pipe_397_s7), .y(mul_tree_38_424));
    assign mul_tree_38_425 = mul_tree_38_424[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_426 = mul_precision_34[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_427 = rtlzz_pipe_35_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_428Core rtlzz_owner_428(.a(16'(mul_tree_39_426)), .b(16'(mul_tree_39_427)), .cin(1'b0), .value(mul_tree_39_428));
    assign mul_tree_39_429 = mul_precision_34[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_430 = rtlzz_pipe_35_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_431Core rtlzz_owner_431(.a(16'(mul_tree_39_429)), .b(16'(mul_tree_39_430)), .cin(1'b0), .value(mul_tree_39_431));
    assign mul_tree_39_432 = {mul_tree_39_431, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_433 = mul_precision_34[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_434 = rtlzz_pipe_35_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_435Core rtlzz_owner_435(.a(16'(mul_tree_39_433)), .b(16'(mul_tree_39_434)), .cin(1'b0), .value(mul_tree_39_435));
    assign mul_tree_39_436 = {mul_tree_39_435, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_437 = mul_precision_34[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_438 = rtlzz_pipe_35_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_439Core rtlzz_owner_439(.a(16'(mul_tree_39_437)), .b(16'(mul_tree_39_438)), .cin(1'b0), .value(mul_tree_39_439));
    assign mul_tree_39_440 = {mul_tree_39_439, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_441 = mul_precision_34[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_39_442 = rtlzz_pipe_35_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_443Core rtlzz_owner_443(.a(16'(mul_tree_39_441)), .b(16'(mul_tree_39_442)), .cin(1'b0), .value(mul_tree_39_443));
    assign mul_tree_39_444 = {mul_tree_39_443, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_445 = mul_precision_34[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_39_446 = rtlzz_pipe_35_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_447Core rtlzz_owner_447(.a(16'(mul_tree_39_445)), .b(16'(mul_tree_39_446)), .cin(1'b0), .value(mul_tree_39_447));
    assign mul_tree_39_448 = {mul_tree_39_447, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_449 = mul_precision_34[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_39_450 = rtlzz_pipe_35_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(16'(mul_tree_39_449)), .b(16'(mul_tree_39_450)), .cin(1'b0), .value(mul_tree_39_451));
    assign mul_tree_39_452 = {mul_tree_39_451, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_453 = mul_precision_34[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_39_454 = rtlzz_pipe_35_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(16'(mul_tree_39_453)), .b(16'(mul_tree_39_454)), .cin(1'b0), .value(mul_tree_39_455));
    assign mul_tree_39_456 = {mul_tree_39_455, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_457 = mul_precision_34[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_458 = rtlzz_pipe_35_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_459Core rtlzz_owner_459(.a(16'(mul_tree_39_457)), .b(16'(mul_tree_39_458)), .cin(1'b0), .value(mul_tree_39_459));
    assign mul_tree_39_460 = {mul_tree_39_459, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_461 = mul_precision_34[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_462 = rtlzz_pipe_35_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_463Core rtlzz_owner_463(.a(16'(mul_tree_39_461)), .b(16'(mul_tree_39_462)), .cin(1'b0), .value(mul_tree_39_463));
    assign mul_tree_39_464 = {mul_tree_39_463, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_465 = mul_precision_34[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_466 = rtlzz_pipe_35_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_467Core rtlzz_owner_467(.a(16'(mul_tree_39_465)), .b(16'(mul_tree_39_466)), .cin(1'b0), .value(mul_tree_39_467));
    assign mul_tree_39_468 = {mul_tree_39_467, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_469 = mul_precision_34[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_470 = rtlzz_pipe_35_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_471Core rtlzz_owner_471(.a(16'(mul_tree_39_469)), .b(16'(mul_tree_39_470)), .cin(1'b0), .value(mul_tree_39_471));
    assign mul_tree_39_472 = {mul_tree_39_471, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_473 = mul_precision_34[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_39_474 = rtlzz_pipe_35_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_475Core rtlzz_owner_475(.a(16'(mul_tree_39_473)), .b(16'(mul_tree_39_474)), .cin(1'b0), .value(mul_tree_39_475));
    assign mul_tree_39_476 = {mul_tree_39_475, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_477 = mul_precision_34[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_39_478 = rtlzz_pipe_35_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_479Core rtlzz_owner_479(.a(16'(mul_tree_39_477)), .b(16'(mul_tree_39_478)), .cin(1'b0), .value(mul_tree_39_479));
    assign mul_tree_39_480 = {mul_tree_39_479, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_481 = mul_precision_34[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_39_482 = rtlzz_pipe_35_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_483Core rtlzz_owner_483(.a(16'(mul_tree_39_481)), .b(16'(mul_tree_39_482)), .cin(1'b0), .value(mul_tree_39_483));
    assign mul_tree_39_484 = {mul_tree_39_483, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_485 = mul_precision_34[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_39_486 = rtlzz_pipe_35_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_487Core rtlzz_owner_487(.a(16'(mul_tree_39_485)), .b(16'(mul_tree_39_486)), .cin(1'b0), .value(mul_tree_39_487));
    assign mul_tree_39_488 = {mul_tree_39_487, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_489 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_490 = rtlzz_pipe_35_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_491Core rtlzz_owner_491(.a(1'(mul_tree_39_489)), .b(16'(mul_tree_39_490)), .cin(1'b0), .value(mul_tree_39_491));
    assign mul_tree_39_492 = {mul_tree_39_491, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_493 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_494 = rtlzz_pipe_35_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_495Core rtlzz_owner_495(.a(1'(mul_tree_39_493)), .b(16'(mul_tree_39_494)), .cin(1'b0), .value(mul_tree_39_495));
    assign mul_tree_39_496 = {mul_tree_39_495, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_497 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_498 = rtlzz_pipe_35_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_499Core rtlzz_owner_499(.a(1'(mul_tree_39_497)), .b(16'(mul_tree_39_498)), .cin(1'b0), .value(mul_tree_39_499));
    assign mul_tree_39_500 = {mul_tree_39_499, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_501 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_502 = rtlzz_pipe_35_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_503Core rtlzz_owner_503(.a(1'(mul_tree_39_501)), .b(16'(mul_tree_39_502)), .cin(1'b0), .value(mul_tree_39_503));
    assign mul_tree_39_504 = {mul_tree_39_503, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_505 = ({17'h0, mul_tree_39_428}); // decl: <none>; prim: <none>
    assign mul_tree_39_506 = ({1'h0, mul_tree_39_432}); // decl: <none>; prim: <none>
    assign mul_tree_39_508 = ({17'h0, mul_tree_39_436}); // decl: <none>; prim: <none>
    assign mul_tree_39_509 = ({1'h0, mul_tree_39_440}); // decl: <none>; prim: <none>
    assign mul_tree_39_511 = ({17'h0, mul_tree_39_444}); // decl: <none>; prim: <none>
    assign mul_tree_39_512 = ({1'h0, mul_tree_39_448}); // decl: <none>; prim: <none>
    assign mul_tree_39_514 = ({17'h0, mul_tree_39_452}); // decl: <none>; prim: <none>
    assign mul_tree_39_515 = ({1'h0, mul_tree_39_456}); // decl: <none>; prim: <none>
    assign mul_tree_39_517 = ({17'h0, mul_tree_39_460}); // decl: <none>; prim: <none>
    assign mul_tree_39_518 = ({1'h0, mul_tree_39_464}); // decl: <none>; prim: <none>
    assign mul_tree_39_520 = ({17'h0, mul_tree_39_468}); // decl: <none>; prim: <none>
    assign mul_tree_39_521 = ({1'h0, mul_tree_39_472}); // decl: <none>; prim: <none>
    assign mul_tree_39_523 = ({17'h0, mul_tree_39_476}); // decl: <none>; prim: <none>
    assign mul_tree_39_524 = ({1'h0, mul_tree_39_480}); // decl: <none>; prim: <none>
    assign mul_tree_39_526 = ({17'h0, mul_tree_39_484}); // decl: <none>; prim: <none>
    assign mul_tree_39_527 = ({1'h0, mul_tree_39_488}); // decl: <none>; prim: <none>
    assign mul_tree_39_529 = ({17'h0, mul_tree_39_492}); // decl: <none>; prim: <none>
    assign mul_tree_39_530 = ({1'h0, mul_tree_39_496}); // decl: <none>; prim: <none>
    assign mul_tree_39_532 = ({17'h0, mul_tree_39_500}); // decl: <none>; prim: <none>
    assign mul_tree_39_533 = ({1'h0, mul_tree_39_504}); // decl: <none>; prim: <none>
    assign mul_tree_39_535 = ({33'h0, mul_tree_39_507}); // decl: <none>; prim: <none>
    assign mul_tree_39_536 = ({1'h0, mul_tree_39_510}); // decl: <none>; prim: <none>
    assign mul_tree_39_538 = ({33'h0, mul_tree_39_513}); // decl: <none>; prim: <none>
    assign mul_tree_39_539 = ({1'h0, mul_tree_39_516}); // decl: <none>; prim: <none>
    assign mul_tree_39_541 = ({33'h0, mul_tree_39_519}); // decl: <none>; prim: <none>
    assign mul_tree_39_542 = ({1'h0, mul_tree_39_522}); // decl: <none>; prim: <none>
    assign mul_tree_39_544 = ({33'h0, mul_tree_39_525}); // decl: <none>; prim: <none>
    assign mul_tree_39_545 = ({1'h0, mul_tree_39_528}); // decl: <none>; prim: <none>
    assign mul_tree_39_547 = ({33'h0, mul_tree_39_531}); // decl: <none>; prim: <none>
    assign mul_tree_39_548 = ({1'h0, mul_tree_39_534}); // decl: <none>; prim: <none>
    assign mul_tree_39_550 = ({17'h0, mul_tree_39_537}); // decl: <none>; prim: <none>
    assign mul_tree_39_551 = ({1'h0, mul_tree_39_540}); // decl: <none>; prim: <none>
    assign mul_tree_39_553 = ({17'h0, mul_tree_39_543}); // decl: <none>; prim: <none>
    assign mul_tree_39_554 = ({1'h0, mul_tree_39_546}); // decl: <none>; prim: <none>
    assign mul_tree_39_556 = ({33'h0, mul_tree_39_552}); // decl: <none>; prim: <none>
    assign mul_tree_39_557 = ({1'h0, mul_tree_39_555}); // decl: <none>; prim: <none>
    assign mul_tree_39_559 = ({1'h0, mul_tree_39_558}); // decl: <none>; prim: <none>
    assign mul_tree_39_560 = ({2'h0, mul_tree_39_549}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_561_reduce rtlzz_reduce_561(.i428(mul_tree_39_428), .i431(mul_tree_39_431), .i435(mul_tree_39_435), .i439(mul_tree_39_439), .i443(mul_tree_39_443), .i447(mul_tree_39_447), .i451(mul_tree_39_451), .i455(mul_tree_39_455), .i459(mul_tree_39_459), .i463(mul_tree_39_463), .i467(mul_tree_39_467), .i471(mul_tree_39_471), .i475(mul_tree_39_475), .i479(mul_tree_39_479), .i483(mul_tree_39_483), .i487(mul_tree_39_487), .i491(mul_tree_39_491), .i495(mul_tree_39_495), .i499(mul_tree_39_499), .i503(mul_tree_39_503), .y(mul_tree_39_561));
    assign mul_tree_39_562 = mul_tree_39_561[128:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_32_s6 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 32'h0;
            rtlzz_pipe_46_s1 <= 48'h0;
            rtlzz_pipe_50_s1 <= 64'h0;
            rtlzz_pipe_54_s1 <= 80'h0;
            rtlzz_pipe_58_s1 <= 48'h0;
            rtlzz_pipe_62_s1 <= 64'h0;
            rtlzz_pipe_66_s1 <= 80'h0;
            rtlzz_pipe_70_s1 <= 96'h0;
            rtlzz_pipe_74_s1 <= 64'h0;
            rtlzz_pipe_78_s1 <= 80'h0;
            rtlzz_pipe_82_s1 <= 96'h0;
            rtlzz_pipe_86_s1 <= 112'h0;
            rtlzz_pipe_90_s1 <= 80'h0;
            rtlzz_pipe_94_s1 <= 96'h0;
            rtlzz_pipe_98_s1 <= 112'h0;
            rtlzz_pipe_102_s1 <= 128'h0;
            rtlzz_pipe_105_s2 <= 49'h0;
            rtlzz_pipe_108_s2 <= 81'h0;
            rtlzz_pipe_111_s2 <= 65'h0;
            rtlzz_pipe_114_s2 <= 97'h0;
            rtlzz_pipe_117_s2 <= 81'h0;
            rtlzz_pipe_120_s2 <= 113'h0;
            rtlzz_pipe_123_s2 <= 97'h0;
            rtlzz_pipe_126_s2 <= 129'h0;
            rtlzz_pipe_129_s3 <= 82'h0;
            rtlzz_pipe_132_s3 <= 98'h0;
            rtlzz_pipe_135_s3 <= 114'h0;
            rtlzz_pipe_138_s3 <= 130'h0;
            rtlzz_pipe_141_s4 <= 99'h0;
            rtlzz_pipe_144_s4 <= 131'h0;
            rtlzz_pipe_23_s5 <= 193'h0;
            rtlzz_pipe_25_s5 <= 129'h0;
            rtlzz_pipe_25_s6 <= 129'h0;
            rtlzz_pipe_25_s7 <= 129'h0;
            rtlzz_pipe_31_s6 <= 128'h0;
            rtlzz_pipe_370_s7 <= 82'h0;
            rtlzz_pipe_373_s7 <= 83'h0;
            rtlzz_pipe_376_s7 <= 99'h0;
            rtlzz_pipe_379_s7 <= 115'h0;
            rtlzz_pipe_382_s7 <= 131'h0;
            rtlzz_pipe_385_s7 <= 146'h0;
            rtlzz_pipe_388_s7 <= 147'h0;
            rtlzz_pipe_391_s7 <= 163'h0;
            rtlzz_pipe_394_s7 <= 179'h0;
            rtlzz_pipe_397_s7 <= 195'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_32_s6 <= rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_37_58; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_37_62; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_66_s1 <= mul_tree_37_66; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_70_s1 <= mul_tree_37_70; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_74_s1 <= mul_tree_37_74; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_78_s1 <= mul_tree_37_78; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_37_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_86_s1 <= mul_tree_37_86; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_90_s1 <= mul_tree_37_90; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_37_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_98_s1 <= mul_tree_37_98; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_tree_37_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_105_s2 <= mul_tree_37_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_108_s2 <= mul_tree_37_108; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_111_s2 <= mul_tree_37_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= mul_tree_37_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_117_s2 <= mul_tree_37_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_120_s2 <= mul_tree_37_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= mul_tree_37_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_126_s2 <= mul_tree_37_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_129_s3 <= mul_tree_37_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_132_s3 <= mul_tree_37_132; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_135_s3 <= mul_tree_37_135; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_138_s3 <= mul_tree_37_138; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_141_s4 <= mul_tree_37_141; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_144_s4 <= mul_tree_37_144; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_23_s5 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_25_s5 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_25_s6 <= rtlzz_pipe_25_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_25_s7 <= rtlzz_pipe_25_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_31_s6 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_370_s7 <= mul_tree_38_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_373_s7 <= mul_tree_38_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_376_s7 <= mul_tree_38_376; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_379_s7 <= mul_tree_38_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_382_s7 <= mul_tree_38_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_385_s7 <= mul_tree_38_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_388_s7 <= mul_tree_38_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_391_s7 <= mul_tree_38_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_394_s7 <= mul_tree_38_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_397_s7 <= mul_tree_38_397; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370_reduce(input wire [31:0] i151, input wire [31:0] i154, input wire [31:0] i158, input wire [31:0] i162, output wire [81:0] y);
wire [81:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i151[31], i151[30], i151[29], i151[28], i151[27], i151[26], i151[25], i151[24], i151[23], i151[22], i151[21], i151[20], i151[19], i151[18], i151[17], i151[16], i151[15], i151[14], i151[13], i151[12], i151[11], i151[10], i151[9], i151[8], i151[7], i151[6], i151[5], i151[4], i151[3], i151[2], i151[1], i151[0]};
wire [81:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i154[31], i154[30], i154[29], i154[28], i154[27], i154[26], i154[25], i154[24], i154[23], i154[22], i154[21], i154[20], i154[19], i154[18], i154[17], i154[16], i154[15], i154[14], i154[13], i154[12], i154[11], i154[10], i154[9], i154[8], i154[7], i154[6], i154[5], i154[4], i154[3], i154[2], i154[1], i154[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i158[31], i158[30], i158[29], i158[28], i158[27], i158[26], i158[25], i158[24], i158[23], i158[22], i158[21], i158[20], i158[19], i158[18], i158[17], i158[16], i158[15], i158[14], i158[13], i158[12], i158[11], i158[10], i158[9], i158[8], i158[7], i158[6], i158[5], i158[4], i158[3], i158[2], i158[1], i158[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t3 = {1'b0, 1'b0, i162[31], i162[30], i162[29], i162[28], i162[27], i162[26], i162[25], i162[24], i162[23], i162[22], i162[21], i162[20], i162[19], i162[18], i162[17], i162[16], i162[15], i162[14], i162[13], i162[12], i162[11], i162[10], i162[9], i162[8], i162[7], i162[6], i162[5], i162[4], i162[3], i162[2], i162[1], i162[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373_reduce(input wire [16:0] i166, input wire [31:0] i170, input wire [31:0] i174, input wire [31:0] i178, output wire [82:0] y);
wire [82:0] t0 = {1'b0, 1'b0, i166[16], i166[15], i166[14], i166[13], i166[12], i166[11], i166[10], i166[9], i166[8], i166[7], i166[6], i166[5], i166[4], i166[3], i166[2], i166[1], i166[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [82:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i170[31], i170[30], i170[29], i170[28], i170[27], i170[26], i170[25], i170[24], i170[23], i170[22], i170[21], i170[20], i170[19], i170[18], i170[17], i170[16], i170[15], i170[14], i170[13], i170[12], i170[11], i170[10], i170[9], i170[8], i170[7], i170[6], i170[5], i170[4], i170[3], i170[2], i170[1], i170[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [82:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i174[31], i174[30], i174[29], i174[28], i174[27], i174[26], i174[25], i174[24], i174[23], i174[22], i174[21], i174[20], i174[19], i174[18], i174[17], i174[16], i174[15], i174[14], i174[13], i174[12], i174[11], i174[10], i174[9], i174[8], i174[7], i174[6], i174[5], i174[4], i174[3], i174[2], i174[1], i174[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [82:0] t3 = {1'b0, 1'b0, 1'b0, i178[31], i178[30], i178[29], i178[28], i178[27], i178[26], i178[25], i178[24], i178[23], i178[22], i178[21], i178[20], i178[19], i178[18], i178[17], i178[16], i178[15], i178[14], i178[13], i178[12], i178[11], i178[10], i178[9], i178[8], i178[7], i178[6], i178[5], i178[4], i178[3], i178[2], i178[1], i178[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [82:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376_reduce(input wire [31:0] i182, input wire [16:0] i186, input wire [31:0] i190, input wire [31:0] i194, output wire [98:0] y);
wire [98:0] t0 = {1'b0, 1'b0, 1'b0, i182[31], i182[30], i182[29], i182[28], i182[27], i182[26], i182[25], i182[24], i182[23], i182[22], i182[21], i182[20], i182[19], i182[18], i182[17], i182[16], i182[15], i182[14], i182[13], i182[12], i182[11], i182[10], i182[9], i182[8], i182[7], i182[6], i182[5], i182[4], i182[3], i182[2], i182[1], i182[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [98:0] t1 = {1'b0, 1'b0, i186[16], i186[15], i186[14], i186[13], i186[12], i186[11], i186[10], i186[9], i186[8], i186[7], i186[6], i186[5], i186[4], i186[3], i186[2], i186[1], i186[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [98:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i190[31], i190[30], i190[29], i190[28], i190[27], i190[26], i190[25], i190[24], i190[23], i190[22], i190[21], i190[20], i190[19], i190[18], i190[17], i190[16], i190[15], i190[14], i190[13], i190[12], i190[11], i190[10], i190[9], i190[8], i190[7], i190[6], i190[5], i190[4], i190[3], i190[2], i190[1], i190[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [98:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i194[31], i194[30], i194[29], i194[28], i194[27], i194[26], i194[25], i194[24], i194[23], i194[22], i194[21], i194[20], i194[19], i194[18], i194[17], i194[16], i194[15], i194[14], i194[13], i194[12], i194[11], i194[10], i194[9], i194[8], i194[7], i194[6], i194[5], i194[4], i194[3], i194[2], i194[1], i194[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [98:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379_reduce(input wire [31:0] i198, input wire [31:0] i202, input wire [16:0] i206, input wire [31:0] i210, output wire [114:0] y);
wire [114:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i198[31], i198[30], i198[29], i198[28], i198[27], i198[26], i198[25], i198[24], i198[23], i198[22], i198[21], i198[20], i198[19], i198[18], i198[17], i198[16], i198[15], i198[14], i198[13], i198[12], i198[11], i198[10], i198[9], i198[8], i198[7], i198[6], i198[5], i198[4], i198[3], i198[2], i198[1], i198[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [114:0] t1 = {1'b0, 1'b0, 1'b0, i202[31], i202[30], i202[29], i202[28], i202[27], i202[26], i202[25], i202[24], i202[23], i202[22], i202[21], i202[20], i202[19], i202[18], i202[17], i202[16], i202[15], i202[14], i202[13], i202[12], i202[11], i202[10], i202[9], i202[8], i202[7], i202[6], i202[5], i202[4], i202[3], i202[2], i202[1], i202[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [114:0] t2 = {1'b0, 1'b0, i206[16], i206[15], i206[14], i206[13], i206[12], i206[11], i206[10], i206[9], i206[8], i206[7], i206[6], i206[5], i206[4], i206[3], i206[2], i206[1], i206[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [114:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i210[31], i210[30], i210[29], i210[28], i210[27], i210[26], i210[25], i210[24], i210[23], i210[22], i210[21], i210[20], i210[19], i210[18], i210[17], i210[16], i210[15], i210[14], i210[13], i210[12], i210[11], i210[10], i210[9], i210[8], i210[7], i210[6], i210[5], i210[4], i210[3], i210[2], i210[1], i210[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [114:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382_reduce(input wire [31:0] i214, input wire [31:0] i218, input wire [31:0] i222, input wire [16:0] i226, output wire [130:0] y);
wire [130:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i214[31], i214[30], i214[29], i214[28], i214[27], i214[26], i214[25], i214[24], i214[23], i214[22], i214[21], i214[20], i214[19], i214[18], i214[17], i214[16], i214[15], i214[14], i214[13], i214[12], i214[11], i214[10], i214[9], i214[8], i214[7], i214[6], i214[5], i214[4], i214[3], i214[2], i214[1], i214[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [130:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i218[31], i218[30], i218[29], i218[28], i218[27], i218[26], i218[25], i218[24], i218[23], i218[22], i218[21], i218[20], i218[19], i218[18], i218[17], i218[16], i218[15], i218[14], i218[13], i218[12], i218[11], i218[10], i218[9], i218[8], i218[7], i218[6], i218[5], i218[4], i218[3], i218[2], i218[1], i218[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [130:0] t2 = {1'b0, 1'b0, 1'b0, i222[31], i222[30], i222[29], i222[28], i222[27], i222[26], i222[25], i222[24], i222[23], i222[22], i222[21], i222[20], i222[19], i222[18], i222[17], i222[16], i222[15], i222[14], i222[13], i222[12], i222[11], i222[10], i222[9], i222[8], i222[7], i222[6], i222[5], i222[4], i222[3], i222[2], i222[1], i222[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [130:0] t3 = {1'b0, 1'b0, i226[16], i226[15], i226[14], i226[13], i226[12], i226[11], i226[10], i226[9], i226[8], i226[7], i226[6], i226[5], i226[4], i226[3], i226[2], i226[1], i226[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [130:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385_reduce(input wire [31:0] i230, input wire [31:0] i234, input wire [31:0] i238, input wire [31:0] i242, output wire [145:0] y);
wire [145:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i230[31], i230[30], i230[29], i230[28], i230[27], i230[26], i230[25], i230[24], i230[23], i230[22], i230[21], i230[20], i230[19], i230[18], i230[17], i230[16], i230[15], i230[14], i230[13], i230[12], i230[11], i230[10], i230[9], i230[8], i230[7], i230[6], i230[5], i230[4], i230[3], i230[2], i230[1], i230[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i234[31], i234[30], i234[29], i234[28], i234[27], i234[26], i234[25], i234[24], i234[23], i234[22], i234[21], i234[20], i234[19], i234[18], i234[17], i234[16], i234[15], i234[14], i234[13], i234[12], i234[11], i234[10], i234[9], i234[8], i234[7], i234[6], i234[5], i234[4], i234[3], i234[2], i234[1], i234[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i238[31], i238[30], i238[29], i238[28], i238[27], i238[26], i238[25], i238[24], i238[23], i238[22], i238[21], i238[20], i238[19], i238[18], i238[17], i238[16], i238[15], i238[14], i238[13], i238[12], i238[11], i238[10], i238[9], i238[8], i238[7], i238[6], i238[5], i238[4], i238[3], i238[2], i238[1], i238[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t3 = {1'b0, 1'b0, i242[31], i242[30], i242[29], i242[28], i242[27], i242[26], i242[25], i242[24], i242[23], i242[22], i242[21], i242[20], i242[19], i242[18], i242[17], i242[16], i242[15], i242[14], i242[13], i242[12], i242[11], i242[10], i242[9], i242[8], i242[7], i242[6], i242[5], i242[4], i242[3], i242[2], i242[1], i242[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388_reduce(input wire [16:0] i246, input wire [31:0] i250, input wire [31:0] i254, input wire [31:0] i258, output wire [146:0] y);
wire [146:0] t0 = {1'b0, 1'b0, i246[16], i246[15], i246[14], i246[13], i246[12], i246[11], i246[10], i246[9], i246[8], i246[7], i246[6], i246[5], i246[4], i246[3], i246[2], i246[1], i246[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [146:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i250[31], i250[30], i250[29], i250[28], i250[27], i250[26], i250[25], i250[24], i250[23], i250[22], i250[21], i250[20], i250[19], i250[18], i250[17], i250[16], i250[15], i250[14], i250[13], i250[12], i250[11], i250[10], i250[9], i250[8], i250[7], i250[6], i250[5], i250[4], i250[3], i250[2], i250[1], i250[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [146:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i254[31], i254[30], i254[29], i254[28], i254[27], i254[26], i254[25], i254[24], i254[23], i254[22], i254[21], i254[20], i254[19], i254[18], i254[17], i254[16], i254[15], i254[14], i254[13], i254[12], i254[11], i254[10], i254[9], i254[8], i254[7], i254[6], i254[5], i254[4], i254[3], i254[2], i254[1], i254[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [146:0] t3 = {1'b0, 1'b0, 1'b0, i258[31], i258[30], i258[29], i258[28], i258[27], i258[26], i258[25], i258[24], i258[23], i258[22], i258[21], i258[20], i258[19], i258[18], i258[17], i258[16], i258[15], i258[14], i258[13], i258[12], i258[11], i258[10], i258[9], i258[8], i258[7], i258[6], i258[5], i258[4], i258[3], i258[2], i258[1], i258[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [146:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391_reduce(input wire [31:0] i262, input wire [16:0] i266, input wire [31:0] i270, input wire [31:0] i274, output wire [162:0] y);
wire [162:0] t0 = {1'b0, 1'b0, 1'b0, i262[31], i262[30], i262[29], i262[28], i262[27], i262[26], i262[25], i262[24], i262[23], i262[22], i262[21], i262[20], i262[19], i262[18], i262[17], i262[16], i262[15], i262[14], i262[13], i262[12], i262[11], i262[10], i262[9], i262[8], i262[7], i262[6], i262[5], i262[4], i262[3], i262[2], i262[1], i262[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [162:0] t1 = {1'b0, 1'b0, i266[16], i266[15], i266[14], i266[13], i266[12], i266[11], i266[10], i266[9], i266[8], i266[7], i266[6], i266[5], i266[4], i266[3], i266[2], i266[1], i266[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [162:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i270[31], i270[30], i270[29], i270[28], i270[27], i270[26], i270[25], i270[24], i270[23], i270[22], i270[21], i270[20], i270[19], i270[18], i270[17], i270[16], i270[15], i270[14], i270[13], i270[12], i270[11], i270[10], i270[9], i270[8], i270[7], i270[6], i270[5], i270[4], i270[3], i270[2], i270[1], i270[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [162:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i274[31], i274[30], i274[29], i274[28], i274[27], i274[26], i274[25], i274[24], i274[23], i274[22], i274[21], i274[20], i274[19], i274[18], i274[17], i274[16], i274[15], i274[14], i274[13], i274[12], i274[11], i274[10], i274[9], i274[8], i274[7], i274[6], i274[5], i274[4], i274[3], i274[2], i274[1], i274[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [162:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394_reduce(input wire [31:0] i278, input wire [31:0] i282, input wire [16:0] i286, input wire [31:0] i290, output wire [178:0] y);
wire [178:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i278[31], i278[30], i278[29], i278[28], i278[27], i278[26], i278[25], i278[24], i278[23], i278[22], i278[21], i278[20], i278[19], i278[18], i278[17], i278[16], i278[15], i278[14], i278[13], i278[12], i278[11], i278[10], i278[9], i278[8], i278[7], i278[6], i278[5], i278[4], i278[3], i278[2], i278[1], i278[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [178:0] t1 = {1'b0, 1'b0, 1'b0, i282[31], i282[30], i282[29], i282[28], i282[27], i282[26], i282[25], i282[24], i282[23], i282[22], i282[21], i282[20], i282[19], i282[18], i282[17], i282[16], i282[15], i282[14], i282[13], i282[12], i282[11], i282[10], i282[9], i282[8], i282[7], i282[6], i282[5], i282[4], i282[3], i282[2], i282[1], i282[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [178:0] t2 = {1'b0, 1'b0, i286[16], i286[15], i286[14], i286[13], i286[12], i286[11], i286[10], i286[9], i286[8], i286[7], i286[6], i286[5], i286[4], i286[3], i286[2], i286[1], i286[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [178:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i290[31], i290[30], i290[29], i290[28], i290[27], i290[26], i290[25], i290[24], i290[23], i290[22], i290[21], i290[20], i290[19], i290[18], i290[17], i290[16], i290[15], i290[14], i290[13], i290[12], i290[11], i290[10], i290[9], i290[8], i290[7], i290[6], i290[5], i290[4], i290[3], i290[2], i290[1], i290[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [178:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397_reduce(input wire [31:0] i294, input wire [31:0] i298, input wire [31:0] i302, input wire [16:0] i306, output wire [194:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i294[31], i294[30], i294[29], i294[28], i294[27], i294[26], i294[25], i294[24], i294[23], i294[22], i294[21], i294[20], i294[19], i294[18], i294[17], i294[16], i294[15], i294[14], i294[13], i294[12], i294[11], i294[10], i294[9], i294[8], i294[7], i294[6], i294[5], i294[4], i294[3], i294[2], i294[1], i294[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i298[31], i298[30], i298[29], i298[28], i298[27], i298[26], i298[25], i298[24], i298[23], i298[22], i298[21], i298[20], i298[19], i298[18], i298[17], i298[16], i298[15], i298[14], i298[13], i298[12], i298[11], i298[10], i298[9], i298[8], i298[7], i298[6], i298[5], i298[4], i298[3], i298[2], i298[1], i298[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t2 = {1'b0, i302[31], i302[30], i302[29], i302[28], i302[27], i302[26], i302[25], i302[24], i302[23], i302[22], i302[21], i302[20], i302[19], i302[18], i302[17], i302[16], i302[15], i302[14], i302[13], i302[12], i302[11], i302[10], i302[9], i302[8], i302[7], i302[6], i302[5], i302[4], i302[3], i302[2], i302[1], i302[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t3 = {i306[16], i306[15], i306[14], i306[13], i306[12], i306[11], i306[10], i306[9], i306[8], i306[7], i306[6], i306[5], i306[4], i306[3], i306[2], i306[1], i306[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424_reduce(input wire [81:0] i618, input wire [82:0] i619, input wire [98:0] i620, input wire [114:0] i621, input wire [130:0] i622, input wire [145:0] i623, input wire [146:0] i624, input wire [162:0] i625, input wire [178:0] i626, input wire [194:0] i627, output wire [196:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i618[81], i618[80], i618[79], i618[78], i618[77], i618[76], i618[75], i618[74], i618[73], i618[72], i618[71], i618[70], i618[69], i618[68], i618[67], i618[66], i618[65], i618[64], i618[63], i618[62], i618[61], i618[60], i618[59], i618[58], i618[57], i618[56], i618[55], i618[54], i618[53], i618[52], i618[51], i618[50], i618[49], i618[48], i618[47], i618[46], i618[45], i618[44], i618[43], i618[42], i618[41], i618[40], i618[39], i618[38], i618[37], i618[36], i618[35], i618[34], i618[33], i618[32], i618[31], i618[30], i618[29], i618[28], i618[27], i618[26], i618[25], i618[24], i618[23], i618[22], i618[21], i618[20], i618[19], i618[18], i618[17], i618[16], i618[15], i618[14], i618[13], i618[12], i618[11], i618[10], i618[9], i618[8], i618[7], i618[6], i618[5], i618[4], i618[3], i618[2], i618[1], i618[0]};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i619[82], i619[81], i619[80], i619[79], i619[78], i619[77], i619[76], i619[75], i619[74], i619[73], i619[72], i619[71], i619[70], i619[69], i619[68], i619[67], i619[66], i619[65], i619[64], i619[63], i619[62], i619[61], i619[60], i619[59], i619[58], i619[57], i619[56], i619[55], i619[54], i619[53], i619[52], i619[51], i619[50], i619[49], i619[48], i619[47], i619[46], i619[45], i619[44], i619[43], i619[42], i619[41], i619[40], i619[39], i619[38], i619[37], i619[36], i619[35], i619[34], i619[33], i619[32], i619[31], i619[30], i619[29], i619[28], i619[27], i619[26], i619[25], i619[24], i619[23], i619[22], i619[21], i619[20], i619[19], i619[18], i619[17], i619[16], i619[15], i619[14], i619[13], i619[12], i619[11], i619[10], i619[9], i619[8], i619[7], i619[6], i619[5], i619[4], i619[3], i619[2], i619[1], i619[0]};
wire [192:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i620[98], i620[97], i620[96], i620[95], i620[94], i620[93], i620[92], i620[91], i620[90], i620[89], i620[88], i620[87], i620[86], i620[85], i620[84], i620[83], i620[82], i620[81], i620[80], i620[79], i620[78], i620[77], i620[76], i620[75], i620[74], i620[73], i620[72], i620[71], i620[70], i620[69], i620[68], i620[67], i620[66], i620[65], i620[64], i620[63], i620[62], i620[61], i620[60], i620[59], i620[58], i620[57], i620[56], i620[55], i620[54], i620[53], i620[52], i620[51], i620[50], i620[49], i620[48], i620[47], i620[46], i620[45], i620[44], i620[43], i620[42], i620[41], i620[40], i620[39], i620[38], i620[37], i620[36], i620[35], i620[34], i620[33], i620[32], i620[31], i620[30], i620[29], i620[28], i620[27], i620[26], i620[25], i620[24], i620[23], i620[22], i620[21], i620[20], i620[19], i620[18], i620[17], i620[16], i620[15], i620[14], i620[13], i620[12], i620[11], i620[10], i620[9], i620[8], i620[7], i620[6], i620[5], i620[4], i620[3], i620[2], i620[1], i620[0]};
wire [192:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i621[114], i621[113], i621[112], i621[111], i621[110], i621[109], i621[108], i621[107], i621[106], i621[105], i621[104], i621[103], i621[102], i621[101], i621[100], i621[99], i621[98], i621[97], i621[96], i621[95], i621[94], i621[93], i621[92], i621[91], i621[90], i621[89], i621[88], i621[87], i621[86], i621[85], i621[84], i621[83], i621[82], i621[81], i621[80], i621[79], i621[78], i621[77], i621[76], i621[75], i621[74], i621[73], i621[72], i621[71], i621[70], i621[69], i621[68], i621[67], i621[66], i621[65], i621[64], i621[63], i621[62], i621[61], i621[60], i621[59], i621[58], i621[57], i621[56], i621[55], i621[54], i621[53], i621[52], i621[51], i621[50], i621[49], i621[48], i621[47], i621[46], i621[45], i621[44], i621[43], i621[42], i621[41], i621[40], i621[39], i621[38], i621[37], i621[36], i621[35], i621[34], i621[33], i621[32], i621[31], i621[30], i621[29], i621[28], i621[27], i621[26], i621[25], i621[24], i621[23], i621[22], i621[21], i621[20], i621[19], i621[18], i621[17], i621[16], i621[15], i621[14], i621[13], i621[12], i621[11], i621[10], i621[9], i621[8], i621[7], i621[6], i621[5], i621[4], i621[3], i621[2], i621[1], i621[0]};
wire [192:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i622[130], i622[129], i622[128], i622[127], i622[126], i622[125], i622[124], i622[123], i622[122], i622[121], i622[120], i622[119], i622[118], i622[117], i622[116], i622[115], i622[114], i622[113], i622[112], i622[111], i622[110], i622[109], i622[108], i622[107], i622[106], i622[105], i622[104], i622[103], i622[102], i622[101], i622[100], i622[99], i622[98], i622[97], i622[96], i622[95], i622[94], i622[93], i622[92], i622[91], i622[90], i622[89], i622[88], i622[87], i622[86], i622[85], i622[84], i622[83], i622[82], i622[81], i622[80], i622[79], i622[78], i622[77], i622[76], i622[75], i622[74], i622[73], i622[72], i622[71], i622[70], i622[69], i622[68], i622[67], i622[66], i622[65], i622[64], i622[63], i622[62], i622[61], i622[60], i622[59], i622[58], i622[57], i622[56], i622[55], i622[54], i622[53], i622[52], i622[51], i622[50], i622[49], i622[48], i622[47], i622[46], i622[45], i622[44], i622[43], i622[42], i622[41], i622[40], i622[39], i622[38], i622[37], i622[36], i622[35], i622[34], i622[33], i622[32], i622[31], i622[30], i622[29], i622[28], i622[27], i622[26], i622[25], i622[24], i622[23], i622[22], i622[21], i622[20], i622[19], i622[18], i622[17], i622[16], i622[15], i622[14], i622[13], i622[12], i622[11], i622[10], i622[9], i622[8], i622[7], i622[6], i622[5], i622[4], i622[3], i622[2], i622[1], i622[0]};
wire [192:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i623[145], i623[144], i623[143], i623[142], i623[141], i623[140], i623[139], i623[138], i623[137], i623[136], i623[135], i623[134], i623[133], i623[132], i623[131], i623[130], i623[129], i623[128], i623[127], i623[126], i623[125], i623[124], i623[123], i623[122], i623[121], i623[120], i623[119], i623[118], i623[117], i623[116], i623[115], i623[114], i623[113], i623[112], i623[111], i623[110], i623[109], i623[108], i623[107], i623[106], i623[105], i623[104], i623[103], i623[102], i623[101], i623[100], i623[99], i623[98], i623[97], i623[96], i623[95], i623[94], i623[93], i623[92], i623[91], i623[90], i623[89], i623[88], i623[87], i623[86], i623[85], i623[84], i623[83], i623[82], i623[81], i623[80], i623[79], i623[78], i623[77], i623[76], i623[75], i623[74], i623[73], i623[72], i623[71], i623[70], i623[69], i623[68], i623[67], i623[66], i623[65], i623[64], i623[63], i623[62], i623[61], i623[60], i623[59], i623[58], i623[57], i623[56], i623[55], i623[54], i623[53], i623[52], i623[51], i623[50], i623[49], i623[48], i623[47], i623[46], i623[45], i623[44], i623[43], i623[42], i623[41], i623[40], i623[39], i623[38], i623[37], i623[36], i623[35], i623[34], i623[33], i623[32], i623[31], i623[30], i623[29], i623[28], i623[27], i623[26], i623[25], i623[24], i623[23], i623[22], i623[21], i623[20], i623[19], i623[18], i623[17], i623[16], i623[15], i623[14], i623[13], i623[12], i623[11], i623[10], i623[9], i623[8], i623[7], i623[6], i623[5], i623[4], i623[3], i623[2], i623[1], i623[0]};
wire [192:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i624[146], i624[145], i624[144], i624[143], i624[142], i624[141], i624[140], i624[139], i624[138], i624[137], i624[136], i624[135], i624[134], i624[133], i624[132], i624[131], i624[130], i624[129], i624[128], i624[127], i624[126], i624[125], i624[124], i624[123], i624[122], i624[121], i624[120], i624[119], i624[118], i624[117], i624[116], i624[115], i624[114], i624[113], i624[112], i624[111], i624[110], i624[109], i624[108], i624[107], i624[106], i624[105], i624[104], i624[103], i624[102], i624[101], i624[100], i624[99], i624[98], i624[97], i624[96], i624[95], i624[94], i624[93], i624[92], i624[91], i624[90], i624[89], i624[88], i624[87], i624[86], i624[85], i624[84], i624[83], i624[82], i624[81], i624[80], i624[79], i624[78], i624[77], i624[76], i624[75], i624[74], i624[73], i624[72], i624[71], i624[70], i624[69], i624[68], i624[67], i624[66], i624[65], i624[64], i624[63], i624[62], i624[61], i624[60], i624[59], i624[58], i624[57], i624[56], i624[55], i624[54], i624[53], i624[52], i624[51], i624[50], i624[49], i624[48], i624[47], i624[46], i624[45], i624[44], i624[43], i624[42], i624[41], i624[40], i624[39], i624[38], i624[37], i624[36], i624[35], i624[34], i624[33], i624[32], i624[31], i624[30], i624[29], i624[28], i624[27], i624[26], i624[25], i624[24], i624[23], i624[22], i624[21], i624[20], i624[19], i624[18], i624[17], i624[16], i624[15], i624[14], i624[13], i624[12], i624[11], i624[10], i624[9], i624[8], i624[7], i624[6], i624[5], i624[4], i624[3], i624[2], i624[1], i624[0]};
wire [192:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i625[162], i625[161], i625[160], i625[159], i625[158], i625[157], i625[156], i625[155], i625[154], i625[153], i625[152], i625[151], i625[150], i625[149], i625[148], i625[147], i625[146], i625[145], i625[144], i625[143], i625[142], i625[141], i625[140], i625[139], i625[138], i625[137], i625[136], i625[135], i625[134], i625[133], i625[132], i625[131], i625[130], i625[129], i625[128], i625[127], i625[126], i625[125], i625[124], i625[123], i625[122], i625[121], i625[120], i625[119], i625[118], i625[117], i625[116], i625[115], i625[114], i625[113], i625[112], i625[111], i625[110], i625[109], i625[108], i625[107], i625[106], i625[105], i625[104], i625[103], i625[102], i625[101], i625[100], i625[99], i625[98], i625[97], i625[96], i625[95], i625[94], i625[93], i625[92], i625[91], i625[90], i625[89], i625[88], i625[87], i625[86], i625[85], i625[84], i625[83], i625[82], i625[81], i625[80], i625[79], i625[78], i625[77], i625[76], i625[75], i625[74], i625[73], i625[72], i625[71], i625[70], i625[69], i625[68], i625[67], i625[66], i625[65], i625[64], i625[63], i625[62], i625[61], i625[60], i625[59], i625[58], i625[57], i625[56], i625[55], i625[54], i625[53], i625[52], i625[51], i625[50], i625[49], i625[48], i625[47], i625[46], i625[45], i625[44], i625[43], i625[42], i625[41], i625[40], i625[39], i625[38], i625[37], i625[36], i625[35], i625[34], i625[33], i625[32], i625[31], i625[30], i625[29], i625[28], i625[27], i625[26], i625[25], i625[24], i625[23], i625[22], i625[21], i625[20], i625[19], i625[18], i625[17], i625[16], i625[15], i625[14], i625[13], i625[12], i625[11], i625[10], i625[9], i625[8], i625[7], i625[6], i625[5], i625[4], i625[3], i625[2], i625[1], i625[0]};
wire [192:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i626[178], i626[177], i626[176], i626[175], i626[174], i626[173], i626[172], i626[171], i626[170], i626[169], i626[168], i626[167], i626[166], i626[165], i626[164], i626[163], i626[162], i626[161], i626[160], i626[159], i626[158], i626[157], i626[156], i626[155], i626[154], i626[153], i626[152], i626[151], i626[150], i626[149], i626[148], i626[147], i626[146], i626[145], i626[144], i626[143], i626[142], i626[141], i626[140], i626[139], i626[138], i626[137], i626[136], i626[135], i626[134], i626[133], i626[132], i626[131], i626[130], i626[129], i626[128], i626[127], i626[126], i626[125], i626[124], i626[123], i626[122], i626[121], i626[120], i626[119], i626[118], i626[117], i626[116], i626[115], i626[114], i626[113], i626[112], i626[111], i626[110], i626[109], i626[108], i626[107], i626[106], i626[105], i626[104], i626[103], i626[102], i626[101], i626[100], i626[99], i626[98], i626[97], i626[96], i626[95], i626[94], i626[93], i626[92], i626[91], i626[90], i626[89], i626[88], i626[87], i626[86], i626[85], i626[84], i626[83], i626[82], i626[81], i626[80], i626[79], i626[78], i626[77], i626[76], i626[75], i626[74], i626[73], i626[72], i626[71], i626[70], i626[69], i626[68], i626[67], i626[66], i626[65], i626[64], i626[63], i626[62], i626[61], i626[60], i626[59], i626[58], i626[57], i626[56], i626[55], i626[54], i626[53], i626[52], i626[51], i626[50], i626[49], i626[48], i626[47], i626[46], i626[45], i626[44], i626[43], i626[42], i626[41], i626[40], i626[39], i626[38], i626[37], i626[36], i626[35], i626[34], i626[33], i626[32], i626[31], i626[30], i626[29], i626[28], i626[27], i626[26], i626[25], i626[24], i626[23], i626[22], i626[21], i626[20], i626[19], i626[18], i626[17], i626[16], i626[15], i626[14], i626[13], i626[12], i626[11], i626[10], i626[9], i626[8], i626[7], i626[6], i626[5], i626[4], i626[3], i626[2], i626[1], i626[0]};
wire [192:0] t9 = {i627[192], i627[191], i627[190], i627[189], i627[188], i627[187], i627[186], i627[185], i627[184], i627[183], i627[182], i627[181], i627[180], i627[179], i627[178], i627[177], i627[176], i627[175], i627[174], i627[173], i627[172], i627[171], i627[170], i627[169], i627[168], i627[167], i627[166], i627[165], i627[164], i627[163], i627[162], i627[161], i627[160], i627[159], i627[158], i627[157], i627[156], i627[155], i627[154], i627[153], i627[152], i627[151], i627[150], i627[149], i627[148], i627[147], i627[146], i627[145], i627[144], i627[143], i627[142], i627[141], i627[140], i627[139], i627[138], i627[137], i627[136], i627[135], i627[134], i627[133], i627[132], i627[131], i627[130], i627[129], i627[128], i627[127], i627[126], i627[125], i627[124], i627[123], i627[122], i627[121], i627[120], i627[119], i627[118], i627[117], i627[116], i627[115], i627[114], i627[113], i627[112], i627[111], i627[110], i627[109], i627[108], i627[107], i627[106], i627[105], i627[104], i627[103], i627[102], i627[101], i627[100], i627[99], i627[98], i627[97], i627[96], i627[95], i627[94], i627[93], i627[92], i627[91], i627[90], i627[89], i627[88], i627[87], i627[86], i627[85], i627[84], i627[83], i627[82], i627[81], i627[80], i627[79], i627[78], i627[77], i627[76], i627[75], i627[74], i627[73], i627[72], i627[71], i627[70], i627[69], i627[68], i627[67], i627[66], i627[65], i627[64], i627[63], i627[62], i627[61], i627[60], i627[59], i627[58], i627[57], i627[56], i627[55], i627[54], i627[53], i627[52], i627[51], i627[50], i627[49], i627[48], i627[47], i627[46], i627[45], i627[44], i627[43], i627[42], i627[41], i627[40], i627[39], i627[38], i627[37], i627[36], i627[35], i627[34], i627[33], i627[32], i627[31], i627[30], i627[29], i627[28], i627[27], i627[26], i627[25], i627[24], i627[23], i627[22], i627[21], i627[20], i627[19], i627[18], i627[17], i627[16], i627[15], i627[14], i627[13], i627[12], i627[11], i627[10], i627[9], i627[8], i627[7], i627[6], i627[5], i627[4], i627[3], i627[2], i627[1], i627[0]};
wire [192:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_561_reduce(input wire [31:0] i428, input wire [31:0] i431, input wire [31:0] i435, input wire [31:0] i439, input wire [31:0] i443, input wire [31:0] i447, input wire [31:0] i451, input wire [31:0] i455, input wire [31:0] i459, input wire [31:0] i463, input wire [31:0] i467, input wire [31:0] i471, input wire [31:0] i475, input wire [31:0] i479, input wire [31:0] i483, input wire [31:0] i487, input wire [16:0] i491, input wire [16:0] i495, input wire [16:0] i499, input wire [16:0] i503, output wire [132:0] y);
wire [128:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i428[31], i428[30], i428[29], i428[28], i428[27], i428[26], i428[25], i428[24], i428[23], i428[22], i428[21], i428[20], i428[19], i428[18], i428[17], i428[16], i428[15], i428[14], i428[13], i428[12], i428[11], i428[10], i428[9], i428[8], i428[7], i428[6], i428[5], i428[4], i428[3], i428[2], i428[1], i428[0]};
wire [128:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i431[31], i431[30], i431[29], i431[28], i431[27], i431[26], i431[25], i431[24], i431[23], i431[22], i431[21], i431[20], i431[19], i431[18], i431[17], i431[16], i431[15], i431[14], i431[13], i431[12], i431[11], i431[10], i431[9], i431[8], i431[7], i431[6], i431[5], i431[4], i431[3], i431[2], i431[1], i431[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i435[31], i435[30], i435[29], i435[28], i435[27], i435[26], i435[25], i435[24], i435[23], i435[22], i435[21], i435[20], i435[19], i435[18], i435[17], i435[16], i435[15], i435[14], i435[13], i435[12], i435[11], i435[10], i435[9], i435[8], i435[7], i435[6], i435[5], i435[4], i435[3], i435[2], i435[1], i435[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i439[31], i439[30], i439[29], i439[28], i439[27], i439[26], i439[25], i439[24], i439[23], i439[22], i439[21], i439[20], i439[19], i439[18], i439[17], i439[16], i439[15], i439[14], i439[13], i439[12], i439[11], i439[10], i439[9], i439[8], i439[7], i439[6], i439[5], i439[4], i439[3], i439[2], i439[1], i439[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i443[31], i443[30], i443[29], i443[28], i443[27], i443[26], i443[25], i443[24], i443[23], i443[22], i443[21], i443[20], i443[19], i443[18], i443[17], i443[16], i443[15], i443[14], i443[13], i443[12], i443[11], i443[10], i443[9], i443[8], i443[7], i443[6], i443[5], i443[4], i443[3], i443[2], i443[1], i443[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i447[31], i447[30], i447[29], i447[28], i447[27], i447[26], i447[25], i447[24], i447[23], i447[22], i447[21], i447[20], i447[19], i447[18], i447[17], i447[16], i447[15], i447[14], i447[13], i447[12], i447[11], i447[10], i447[9], i447[8], i447[7], i447[6], i447[5], i447[4], i447[3], i447[2], i447[1], i447[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i451[31], i451[30], i451[29], i451[28], i451[27], i451[26], i451[25], i451[24], i451[23], i451[22], i451[21], i451[20], i451[19], i451[18], i451[17], i451[16], i451[15], i451[14], i451[13], i451[12], i451[11], i451[10], i451[9], i451[8], i451[7], i451[6], i451[5], i451[4], i451[3], i451[2], i451[1], i451[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i455[31], i455[30], i455[29], i455[28], i455[27], i455[26], i455[25], i455[24], i455[23], i455[22], i455[21], i455[20], i455[19], i455[18], i455[17], i455[16], i455[15], i455[14], i455[13], i455[12], i455[11], i455[10], i455[9], i455[8], i455[7], i455[6], i455[5], i455[4], i455[3], i455[2], i455[1], i455[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i459[31], i459[30], i459[29], i459[28], i459[27], i459[26], i459[25], i459[24], i459[23], i459[22], i459[21], i459[20], i459[19], i459[18], i459[17], i459[16], i459[15], i459[14], i459[13], i459[12], i459[11], i459[10], i459[9], i459[8], i459[7], i459[6], i459[5], i459[4], i459[3], i459[2], i459[1], i459[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t9 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i463[31], i463[30], i463[29], i463[28], i463[27], i463[26], i463[25], i463[24], i463[23], i463[22], i463[21], i463[20], i463[19], i463[18], i463[17], i463[16], i463[15], i463[14], i463[13], i463[12], i463[11], i463[10], i463[9], i463[8], i463[7], i463[6], i463[5], i463[4], i463[3], i463[2], i463[1], i463[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t10 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i467[31], i467[30], i467[29], i467[28], i467[27], i467[26], i467[25], i467[24], i467[23], i467[22], i467[21], i467[20], i467[19], i467[18], i467[17], i467[16], i467[15], i467[14], i467[13], i467[12], i467[11], i467[10], i467[9], i467[8], i467[7], i467[6], i467[5], i467[4], i467[3], i467[2], i467[1], i467[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t11 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i471[31], i471[30], i471[29], i471[28], i471[27], i471[26], i471[25], i471[24], i471[23], i471[22], i471[21], i471[20], i471[19], i471[18], i471[17], i471[16], i471[15], i471[14], i471[13], i471[12], i471[11], i471[10], i471[9], i471[8], i471[7], i471[6], i471[5], i471[4], i471[3], i471[2], i471[1], i471[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t12 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i475[31], i475[30], i475[29], i475[28], i475[27], i475[26], i475[25], i475[24], i475[23], i475[22], i475[21], i475[20], i475[19], i475[18], i475[17], i475[16], i475[15], i475[14], i475[13], i475[12], i475[11], i475[10], i475[9], i475[8], i475[7], i475[6], i475[5], i475[4], i475[3], i475[2], i475[1], i475[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t13 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i479[31], i479[30], i479[29], i479[28], i479[27], i479[26], i479[25], i479[24], i479[23], i479[22], i479[21], i479[20], i479[19], i479[18], i479[17], i479[16], i479[15], i479[14], i479[13], i479[12], i479[11], i479[10], i479[9], i479[8], i479[7], i479[6], i479[5], i479[4], i479[3], i479[2], i479[1], i479[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t14 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i483[31], i483[30], i483[29], i483[28], i483[27], i483[26], i483[25], i483[24], i483[23], i483[22], i483[21], i483[20], i483[19], i483[18], i483[17], i483[16], i483[15], i483[14], i483[13], i483[12], i483[11], i483[10], i483[9], i483[8], i483[7], i483[6], i483[5], i483[4], i483[3], i483[2], i483[1], i483[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t15 = {1'b0, i487[31], i487[30], i487[29], i487[28], i487[27], i487[26], i487[25], i487[24], i487[23], i487[22], i487[21], i487[20], i487[19], i487[18], i487[17], i487[16], i487[15], i487[14], i487[13], i487[12], i487[11], i487[10], i487[9], i487[8], i487[7], i487[6], i487[5], i487[4], i487[3], i487[2], i487[1], i487[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t16 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i491[16], i491[15], i491[14], i491[13], i491[12], i491[11], i491[10], i491[9], i491[8], i491[7], i491[6], i491[5], i491[4], i491[3], i491[2], i491[1], i491[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t17 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i495[16], i495[15], i495[14], i495[13], i495[12], i495[11], i495[10], i495[9], i495[8], i495[7], i495[6], i495[5], i495[4], i495[3], i495[2], i495[1], i495[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t18 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i499[16], i499[15], i499[14], i499[13], i499[12], i499[11], i499[10], i499[9], i499[8], i499[7], i499[6], i499[5], i499[4], i499[3], i499[2], i499[1], i499[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t19 = {i503[16], i503[15], i503[14], i503[13], i503[12], i503[11], i503[10], i503[9], i503[8], i503[7], i503[6], i503[5], i503[4], i503[3], i503[2], i503[1], i503[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14 + t15 + t16 + t17 + t18 + t19;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_65Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_65();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_77Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_77();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_89Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_89();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_93Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_93();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_111Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_111();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [48:0] a,input wire [80:0] b,input wire cin,output wire [81:0] value);
wire [48:0] masked_a=((a&49'h1ffffffffffff)|49'h0);
wire [80:0] masked_b=((b&81'h1ffffffffffffffffffff)|81'h0);
wire [81:0] aa=82'(masked_b);
wire [81:0] bb=82'(masked_a);
wire [82:0] extended={1'b0,aa}+{1'b0,bb}+83'(1'b0);
wire [81:0] native_value=extended[81:0];
assign value=native_value[0+:82];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [64:0] a,input wire [96:0] b,input wire cin,output wire [97:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [96:0] masked_b=((b&97'h1ffffffffffffffffffffffff)|97'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:98];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135Core(input wire [80:0] a,input wire [112:0] b,input wire cin,output wire [113:0] value);
wire [80:0] masked_a=((a&81'h1ffffffffffffffffffff)|81'h0);
wire [112:0] masked_b=((b&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [113:0] aa=114'(masked_b);
wire [113:0] bb=114'(masked_a);
wire [114:0] extended={1'b0,aa}+{1'b0,bb}+115'(1'b0);
wire [113:0] native_value=extended[113:0];
assign value=native_value[0+:114];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141Core(input wire [81:0] a,input wire [97:0] b,input wire cin,output wire [98:0] value);
wire [81:0] masked_a=((a&82'h3ffffffffffffffffffff)|82'h0);
wire [97:0] masked_b=((b&98'h3ffffffffffffffffffffffff)|98'h0);
wire [98:0] aa=99'(masked_b);
wire [98:0] bb=99'(masked_a);
wire [99:0] extended={1'b0,aa}+{1'b0,bb}+100'(1'b0);
wire [98:0] native_value=extended[98:0];
assign value=native_value[0+:99];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [113:0] a,input wire [129:0] b,input wire cin,output wire [127:0] value);
wire [113:0] masked_a=((a&114'h3ffffffffffffffffffffffffffff)|114'h0);
wire [129:0] masked_b=((b&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_b);
wire [129:0] bb=130'(masked_a);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147Core(input wire [98:0] a,input wire [130:0] b,input wire cin,output wire [127:0] value);
wire [98:0] masked_a=((a&99'h7ffffffffffffffffffffffff)|99'h0);
wire [130:0] masked_b=((b&131'h7ffffffffffffffffffffffffffffffff)|131'h0);
wire [130:0] aa=131'(masked_b);
wire [130:0] bb=131'(masked_a);
wire [131:0] extended={1'b0,aa}+{1'b0,bb}+132'(1'b0);
wire [130:0] native_value=extended[130:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_278Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_278();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_290Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_290();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306Core(input wire [15:0] a,input wire [0:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_428Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_428();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_431Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_431();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_435Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_435();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_439Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_439();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_463Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_463();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_467Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_467();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_471Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_471();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_475Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_475();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_479Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_479();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_487Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_487();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491Core(input wire [0:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_495Core(input wire [0:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_495();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_499Core(input wire [0:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_499();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_503Core(input wire [0:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [16:0] native_value=aa*bb;
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_503();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
