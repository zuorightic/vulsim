`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [7:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [41:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [57:0] rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [50:0] rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5_reduce rtlzz_reduce_5(.i123(rtlzz_pipe_2_s2), .i128(rtlzz_pipe_114_s2), .i129(rtlzz_pipe_117_s2), .y(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(8'(mul_tree_12_13)), .b(8'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(8'(mul_tree_12_16)), .b(8'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(8'(mul_tree_12_20)), .b(8'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(8'(mul_tree_12_24)), .b(8'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(8'(mul_tree_12_28)), .b(8'(mul_tree_12_29)), .cin(1'b0), .value(mul_tree_12_30));
    assign mul_tree_12_31 = {mul_tree_12_30, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(8'(mul_tree_12_32)), .b(8'(mul_tree_12_33)), .cin(1'b0), .value(mul_tree_12_34));
    assign mul_tree_12_35 = {mul_tree_12_34, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(8'(mul_tree_12_36)), .b(8'(mul_tree_12_37)), .cin(1'b0), .value(mul_tree_12_38));
    assign mul_tree_12_39 = {mul_tree_12_38, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(8'(mul_tree_12_40)), .b(8'(mul_tree_12_41)), .cin(1'b0), .value(mul_tree_12_42));
    assign mul_tree_12_43 = {mul_tree_12_42, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_46Core rtlzz_owner_46(.a(8'(mul_tree_12_44)), .b(8'(mul_tree_12_45)), .cin(1'b0), .value(mul_tree_12_46));
    assign mul_tree_12_47 = {mul_tree_12_46, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(8'(mul_tree_12_48)), .b(8'(mul_tree_12_49)), .cin(1'b0), .value(mul_tree_12_50));
    assign mul_tree_12_51 = {mul_tree_12_50, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(8'(mul_tree_12_52)), .b(8'(mul_tree_12_53)), .cin(1'b0), .value(mul_tree_12_54));
    assign mul_tree_12_55 = {mul_tree_12_54, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(8'(mul_tree_12_56)), .b(8'(mul_tree_12_57)), .cin(1'b0), .value(mul_tree_12_58));
    assign mul_tree_12_59 = {mul_tree_12_58, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_62Core rtlzz_owner_62(.a(8'(mul_tree_12_60)), .b(8'(mul_tree_12_61)), .cin(1'b0), .value(mul_tree_12_62));
    assign mul_tree_12_63 = {mul_tree_12_62, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_66Core rtlzz_owner_66(.a(8'(mul_tree_12_64)), .b(8'(mul_tree_12_65)), .cin(1'b0), .value(mul_tree_12_66));
    assign mul_tree_12_67 = {mul_tree_12_66, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(8'(mul_tree_12_68)), .b(8'(mul_tree_12_69)), .cin(1'b0), .value(mul_tree_12_70));
    assign mul_tree_12_71 = {mul_tree_12_70, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(8'(mul_tree_12_72)), .b(8'(mul_tree_12_73)), .cin(1'b0), .value(mul_tree_12_74));
    assign mul_tree_12_75 = {mul_tree_12_74, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({9'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({9'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({9'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({9'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({9'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({9'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({9'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({9'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({17'h0, mul_tree_12_78}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, mul_tree_12_81}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102_reduce rtlzz_reduce_102(.i15(mul_tree_12_15), .i18(mul_tree_12_18), .i22(mul_tree_12_22), .i26(mul_tree_12_26), .y(mul_tree_12_102));
    assign mul_tree_12_103 = ({17'h0, mul_tree_12_84}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105_reduce rtlzz_reduce_105(.i30(mul_tree_12_30), .i34(mul_tree_12_34), .i38(mul_tree_12_38), .i42(mul_tree_12_42), .y(mul_tree_12_105));
    assign mul_tree_12_106 = ({17'h0, mul_tree_12_90}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, mul_tree_12_93}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108_reduce rtlzz_reduce_108(.i46(mul_tree_12_46), .i50(mul_tree_12_50), .i54(mul_tree_12_54), .i58(mul_tree_12_58), .y(mul_tree_12_108));
    assign mul_tree_12_109 = ({17'h0, mul_tree_12_96}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_111_reduce rtlzz_reduce_111(.i62(mul_tree_12_62), .i66(mul_tree_12_66), .i70(mul_tree_12_70), .i74(mul_tree_12_74), .y(mul_tree_12_111));
    assign mul_tree_12_112 = ({9'h0, rtlzz_pipe_102_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(42'(mul_tree_12_112)), .b(50'(mul_tree_12_113)), .cin(1'h0), .value(mul_tree_12_114));
    assign mul_tree_12_115 = ({9'h0, rtlzz_pipe_108_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, rtlzz_pipe_111_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_117Core rtlzz_owner_117(.a(58'(mul_tree_12_115)), .b(66'(mul_tree_12_116)), .cin(1'h0), .value(mul_tree_12_117[63:0]));
    assign mul_tree_12_117[66:64] = '0;
    assign mul_tree_12_118 = ({17'h0, rtlzz_pipe_114_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, rtlzz_pipe_117_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_102_s1 <= 42'h0;
            rtlzz_pipe_105_s1 <= 50'h0;
            rtlzz_pipe_108_s1 <= 58'h0;
            rtlzz_pipe_111_s1 <= 66'h0;
            rtlzz_pipe_114_s2 <= 51'h0;
            rtlzz_pipe_117_s2 <= 67'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_tree_12_102; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_12_105; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_108_s1 <= mul_tree_12_108; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_tree_12_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= mul_tree_12_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_117_s2 <= mul_tree_12_117; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5_reduce(input wire [63:0] i123, input wire [50:0] i128, input wire [66:0] i129, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i128[50], i128[49], i128[48], i128[47], i128[46], i128[45], i128[44], i128[43], i128[42], i128[41], i128[40], i128[39], i128[38], i128[37], i128[36], i128[35], i128[34], i128[33], i128[32], i128[31], i128[30], i128[29], i128[28], i128[27], i128[26], i128[25], i128[24], i128[23], i128[22], i128[21], i128[20], i128[19], i128[18], i128[17], i128[16], i128[15], i128[14], i128[13], i128[12], i128[11], i128[10], i128[9], i128[8], i128[7], i128[6], i128[5], i128[4], i128[3], i128[2], i128[1], i128[0]};
wire [63:0] t1 = {i129[63], i129[62], i129[61], i129[60], i129[59], i129[58], i129[57], i129[56], i129[55], i129[54], i129[53], i129[52], i129[51], i129[50], i129[49], i129[48], i129[47], i129[46], i129[45], i129[44], i129[43], i129[42], i129[41], i129[40], i129[39], i129[38], i129[37], i129[36], i129[35], i129[34], i129[33], i129[32], i129[31], i129[30], i129[29], i129[28], i129[27], i129[26], i129[25], i129[24], i129[23], i129[22], i129[21], i129[20], i129[19], i129[18], i129[17], i129[16], i129[15], i129[14], i129[13], i129[12], i129[11], i129[10], i129[9], i129[8], i129[7], i129[6], i129[5], i129[4], i129[3], i129[2], i129[1], i129[0]};
wire [63:0] t2 = {i123[63], i123[62], i123[61], i123[60], i123[59], i123[58], i123[57], i123[56], i123[55], i123[54], i123[53], i123[52], i123[51], i123[50], i123[49], i123[48], i123[47], i123[46], i123[45], i123[44], i123[43], i123[42], i123[41], i123[40], i123[39], i123[38], i123[37], i123[36], i123[35], i123[34], i123[33], i123[32], i123[31], i123[30], i123[29], i123[28], i123[27], i123[26], i123[25], i123[24], i123[23], i123[22], i123[21], i123[20], i123[19], i123[18], i123[17], i123[16], i123[15], i123[14], i123[13], i123[12], i123[11], i123[10], i123[9], i123[8], i123[7], i123[6], i123[5], i123[4], i123[3], i123[2], i123[1], i123[0]};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102_reduce(input wire [15:0] i15, input wire [15:0] i18, input wire [15:0] i22, input wire [15:0] i26, output wire [41:0] y);
wire [41:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i15[15], i15[14], i15[13], i15[12], i15[11], i15[10], i15[9], i15[8], i15[7], i15[6], i15[5], i15[4], i15[3], i15[2], i15[1], i15[0]};
wire [41:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i18[15], i18[14], i18[13], i18[12], i18[11], i18[10], i18[9], i18[8], i18[7], i18[6], i18[5], i18[4], i18[3], i18[2], i18[1], i18[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i22[15], i22[14], i22[13], i22[12], i22[11], i22[10], i22[9], i22[8], i22[7], i22[6], i22[5], i22[4], i22[3], i22[2], i22[1], i22[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t3 = {1'b0, 1'b0, i26[15], i26[14], i26[13], i26[12], i26[11], i26[10], i26[9], i26[8], i26[7], i26[6], i26[5], i26[4], i26[3], i26[2], i26[1], i26[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105_reduce(input wire [15:0] i30, input wire [15:0] i34, input wire [15:0] i38, input wire [15:0] i42, output wire [49:0] y);
wire [49:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i30[15], i30[14], i30[13], i30[12], i30[11], i30[10], i30[9], i30[8], i30[7], i30[6], i30[5], i30[4], i30[3], i30[2], i30[1], i30[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i34[15], i34[14], i34[13], i34[12], i34[11], i34[10], i34[9], i34[8], i34[7], i34[6], i34[5], i34[4], i34[3], i34[2], i34[1], i34[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i38[15], i38[14], i38[13], i38[12], i38[11], i38[10], i38[9], i38[8], i38[7], i38[6], i38[5], i38[4], i38[3], i38[2], i38[1], i38[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t3 = {1'b0, 1'b0, i42[15], i42[14], i42[13], i42[12], i42[11], i42[10], i42[9], i42[8], i42[7], i42[6], i42[5], i42[4], i42[3], i42[2], i42[1], i42[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108_reduce(input wire [15:0] i46, input wire [15:0] i50, input wire [15:0] i54, input wire [15:0] i58, output wire [57:0] y);
wire [57:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i46[15], i46[14], i46[13], i46[12], i46[11], i46[10], i46[9], i46[8], i46[7], i46[6], i46[5], i46[4], i46[3], i46[2], i46[1], i46[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i50[15], i50[14], i50[13], i50[12], i50[11], i50[10], i50[9], i50[8], i50[7], i50[6], i50[5], i50[4], i50[3], i50[2], i50[1], i50[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i54[15], i54[14], i54[13], i54[12], i54[11], i54[10], i54[9], i54[8], i54[7], i54[6], i54[5], i54[4], i54[3], i54[2], i54[1], i54[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t3 = {1'b0, 1'b0, i58[15], i58[14], i58[13], i58[12], i58[11], i58[10], i58[9], i58[8], i58[7], i58[6], i58[5], i58[4], i58[3], i58[2], i58[1], i58[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_111_reduce(input wire [15:0] i62, input wire [15:0] i66, input wire [15:0] i70, input wire [15:0] i74, output wire [65:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i62[15], i62[14], i62[13], i62[12], i62[11], i62[10], i62[9], i62[8], i62[7], i62[6], i62[5], i62[4], i62[3], i62[2], i62[1], i62[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i66[15], i66[14], i66[13], i66[12], i66[11], i66[10], i66[9], i66[8], i66[7], i66[6], i66[5], i66[4], i66[3], i66[2], i66[1], i66[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i70[15], i70[14], i70[13], i70[12], i70[11], i70[10], i70[9], i70[8], i70[7], i70[6], i70[5], i70[4], i70[3], i70[2], i70[1], i70[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i74[15], i74[14], i74[13], i74[12], i74[11], i74[10], i74[9], i74[8], i74[7], i74[6], i74[5], i74[4], i74[3], i74[2], i74[1], i74[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [7:0] a,input wire [7:0] b,input wire cin,output wire [15:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [7:0] masked_b=((b&8'hff)|8'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [15:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [41:0] a,input wire [49:0] b,input wire cin,output wire [50:0] value);
wire [41:0] masked_a=((a&42'h3ffffffffff)|42'h0);
wire [49:0] masked_b=((b&50'h3ffffffffffff)|50'h0);
wire [50:0] aa=51'(masked_b);
wire [50:0] bb=51'(masked_a);
wire [51:0] extended={1'b0,aa}+{1'b0,bb}+52'(1'b0);
wire [50:0] native_value=extended[50:0];
assign value=native_value[0+:51];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117Core(input wire [57:0] a,input wire [65:0] b,input wire cin,output wire [63:0] value);
wire [57:0] masked_a=((a&58'h3ffffffffffffff)|58'h0);
wire [65:0] masked_b=((b&66'h3ffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_b);
wire [65:0] bb=66'(masked_a);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
