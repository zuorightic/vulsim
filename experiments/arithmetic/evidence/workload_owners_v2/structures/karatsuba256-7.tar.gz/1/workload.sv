`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_360; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_361; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_362; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_363; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_364; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_365; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_366; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_367; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_368; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_369; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_373; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_374; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_375; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_376; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_377; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_378; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_379; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_382; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_383; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_384; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_385; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_386; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_387; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_388; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_389; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_390; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_391; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_392; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_393; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_394; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_398; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_399; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_400; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_401; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_402; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_403; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_404; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_405; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_406; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_407; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_408; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_409; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_410; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_411; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_345_412; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_413; // decl: <none>; prim: <none>
    logic mul_tree_345_414; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_415; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_416; // decl: <none>; prim: <none>
    logic mul_tree_345_417; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_418; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_419; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_420; // decl: <none>; prim: <none>
    logic mul_tree_345_421; // decl: <none>; prim: <none>
    logic mul_tree_345_422; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_345_423; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_424; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_425; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_426; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_427; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_428; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_429; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_430; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_431; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_432; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_433; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_434; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_435; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_436; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_346_437; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_438; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_439; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_347_440; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_441; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_442; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_443; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_444; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_446; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_447; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_448; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_449; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_450; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_347_451; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_452; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_453; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_454; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_455; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_456; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_457; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_458; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_459; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_460; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_461; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_462; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_463; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_464; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_465; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_466; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_467; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_468; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_469; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_471; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_472; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_476; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_477; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_478; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_479; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_480; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_481; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_482; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_483; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_484; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_485; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_486; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_487; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_488; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_489; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_490; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_491; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_492; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_493; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_494; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_496; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_497; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_501; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_502; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_503; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_504; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_505; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_506; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_507; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_508; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_509; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_510; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_511; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_512; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_513; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_514; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_350_515; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_516; // decl: <none>; prim: <none>
    logic mul_tree_350_517; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_518; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_519; // decl: <none>; prim: <none>
    logic mul_tree_350_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_521; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_522; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_523; // decl: <none>; prim: <none>
    logic mul_tree_350_524; // decl: <none>; prim: <none>
    logic mul_tree_350_525; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_350_526; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_527; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_528; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_529; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_530; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_531; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_532; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_533; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_534; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_535; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_536; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_537; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_538; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_539; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_351_540; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_541; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_542; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_352_543; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_544; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_545; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_546; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_547; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_548; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_549; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_550; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_551; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_552; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_553; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_352_554; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_555; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_556; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_557; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_558; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_559; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_560; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_561; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_562; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_563; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_564; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_565; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_566; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_567; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_353_568; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_569; // decl: <none>; prim: <none>
    logic mul_tree_353_570; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_571; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_572; // decl: <none>; prim: <none>
    logic mul_tree_353_573; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_574; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_575; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_576; // decl: <none>; prim: <none>
    logic mul_tree_353_577; // decl: <none>; prim: <none>
    logic mul_tree_353_578; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_353_579; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_580; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_581; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_582; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_583; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_584; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_585; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_586; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_587; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_588; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_589; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_590; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_591; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_592; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_354_593; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_594; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_595; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_355_596; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_597; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_598; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_599; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_600; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_601; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_602; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_603; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_604; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_605; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_606; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_355_607; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_608; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_609; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_610; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_611; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_612; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_613; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_614; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_615; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_616; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_617; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_618; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_619; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_620; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_621; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_622; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_623; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_624; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_625; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_626; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_627; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_628; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_629; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_630; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_631; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_632; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_633; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_634; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_635; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_636; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_637; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_638; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_639; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_640; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_641; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_642; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_643; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_644; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_645; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_357_646; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_647; // decl: <none>; prim: <none>
    logic mul_tree_357_648; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_649; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_650; // decl: <none>; prim: <none>
    logic mul_tree_357_651; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_652; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_653; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_654; // decl: <none>; prim: <none>
    logic mul_tree_357_655; // decl: <none>; prim: <none>
    logic mul_tree_357_656; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_357_657; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_658; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_659; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_660; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_661; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_662; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_663; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_664; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_665; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_666; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_667; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_668; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_669; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_670; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_358_671; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_672; // decl: <none>; prim: <none>
    logic mul_tree_358_673; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_674; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_675; // decl: <none>; prim: <none>
    logic mul_tree_358_676; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_677; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_678; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_679; // decl: <none>; prim: <none>
    logic mul_tree_358_680; // decl: <none>; prim: <none>
    logic mul_tree_358_681; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_358_682; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_683; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_684; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_685; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_686; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_687; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_688; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_689; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_690; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_691; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_692; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_693; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_694; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_695; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_359_696; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_697; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_698; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_699; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_700; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_701; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_702; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_703; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_704; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_705; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_706; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_359_707; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_708; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_709; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_710; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_711; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_712; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_713; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_714; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_715; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_716; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_717; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_718; // decl: <none>; prim: <none>
    logic [31:0] limb_13_719; // decl: <none>; prim: <none>
    logic [31:0] limb_13_720; // decl: <none>; prim: <none>
    logic [32:0] limb_13_721; // decl: <none>; prim: <none>
    logic [31:0] limb_13_722; // decl: <none>; prim: <none>
    logic limb_13_723; // decl: <none>; prim: <none>
    logic [31:0] limb_13_724; // decl: <none>; prim: <none>
    logic [31:0] limb_13_725; // decl: <none>; prim: <none>
    logic [32:0] limb_13_726; // decl: <none>; prim: <none>
    logic [31:0] limb_13_727; // decl: <none>; prim: <none>
    logic limb_13_728; // decl: <none>; prim: <none>
    logic limb_13_729; // decl: <none>; prim: <none>
    logic limb_13_730; // decl: <none>; prim: <none>
    logic [1:0] limb_13_731; // decl: <none>; prim: <none>
    logic limb_13_732; // decl: <none>; prim: <none>
    logic [64:0] limb_13_733; // decl: <none>; prim: <none>
    logic [31:0] limb_15_734; // decl: <none>; prim: <none>
    logic [31:0] limb_15_735; // decl: <none>; prim: <none>
    logic [32:0] limb_15_736; // decl: <none>; prim: <none>
    logic [31:0] limb_15_737; // decl: <none>; prim: <none>
    logic limb_15_738; // decl: <none>; prim: <none>
    logic [31:0] limb_15_739; // decl: <none>; prim: <none>
    logic [31:0] limb_15_740; // decl: <none>; prim: <none>
    logic [32:0] limb_15_741; // decl: <none>; prim: <none>
    logic [31:0] limb_15_742; // decl: <none>; prim: <none>
    logic limb_15_743; // decl: <none>; prim: <none>
    logic limb_15_744; // decl: <none>; prim: <none>
    logic limb_15_745; // decl: <none>; prim: <none>
    logic [1:0] limb_15_746; // decl: <none>; prim: <none>
    logic limb_15_747; // decl: <none>; prim: <none>
    logic [64:0] limb_15_748; // decl: <none>; prim: <none>
    logic [31:0] limb_21_749; // decl: <none>; prim: <none>
    logic [31:0] limb_21_750; // decl: <none>; prim: <none>
    logic [32:0] limb_21_751; // decl: <none>; prim: <none>
    logic [31:0] limb_21_752; // decl: <none>; prim: <none>
    logic limb_21_753; // decl: <none>; prim: <none>
    logic [1:0] limb_21_754; // decl: <none>; prim: <none>
    logic [1:0] limb_21_755; // decl: <none>; prim: <none>
    logic [2:0] limb_21_756; // decl: <none>; prim: <none>
    logic [1:0] limb_21_757; // decl: <none>; prim: <none>
    logic [33:0] limb_21_758; // decl: <none>; prim: <none>
    logic [31:0] limb_23_759; // decl: <none>; prim: <none>
    logic [31:0] limb_23_760; // decl: <none>; prim: <none>
    logic [32:0] limb_23_761; // decl: <none>; prim: <none>
    logic [31:0] limb_23_762; // decl: <none>; prim: <none>
    logic limb_23_763; // decl: <none>; prim: <none>
    logic [1:0] limb_23_764; // decl: <none>; prim: <none>
    logic [1:0] limb_23_765; // decl: <none>; prim: <none>
    logic [2:0] limb_23_766; // decl: <none>; prim: <none>
    logic [1:0] limb_23_767; // decl: <none>; prim: <none>
    logic [33:0] limb_23_768; // decl: <none>; prim: <none>
    logic [31:0] limb_29_769; // decl: <none>; prim: <none>
    logic [31:0] limb_29_770; // decl: <none>; prim: <none>
    logic [31:0] limb_29_771; // decl: <none>; prim: <none>
    logic [32:0] limb_29_772; // decl: <none>; prim: <none>
    logic [31:0] limb_29_773; // decl: <none>; prim: <none>
    logic limb_29_774; // decl: <none>; prim: <none>
    logic [31:0] limb_29_775; // decl: <none>; prim: <none>
    logic [31:0] limb_29_776; // decl: <none>; prim: <none>
    logic [31:0] limb_29_777; // decl: <none>; prim: <none>
    logic [32:0] limb_29_778; // decl: <none>; prim: <none>
    logic [31:0] limb_29_779; // decl: <none>; prim: <none>
    logic limb_29_780; // decl: <none>; prim: <none>
    logic [3:0] limb_29_781; // decl: <none>; prim: <none>
    logic [3:0] limb_29_782; // decl: <none>; prim: <none>
    logic [3:0] limb_29_783; // decl: <none>; prim: <none>
    logic [4:0] limb_29_784; // decl: <none>; prim: <none>
    logic [3:0] limb_29_785; // decl: <none>; prim: <none>
    logic [67:0] limb_29_786; // decl: <none>; prim: <none>
    logic [31:0] limb_31_787; // decl: <none>; prim: <none>
    logic [31:0] limb_31_788; // decl: <none>; prim: <none>
    logic [31:0] limb_31_789; // decl: <none>; prim: <none>
    logic [32:0] limb_31_790; // decl: <none>; prim: <none>
    logic [31:0] limb_31_791; // decl: <none>; prim: <none>
    logic limb_31_792; // decl: <none>; prim: <none>
    logic [31:0] limb_31_793; // decl: <none>; prim: <none>
    logic [31:0] limb_31_794; // decl: <none>; prim: <none>
    logic [31:0] limb_31_795; // decl: <none>; prim: <none>
    logic [32:0] limb_31_796; // decl: <none>; prim: <none>
    logic [31:0] limb_31_797; // decl: <none>; prim: <none>
    logic limb_31_798; // decl: <none>; prim: <none>
    logic [3:0] limb_31_799; // decl: <none>; prim: <none>
    logic [3:0] limb_31_800; // decl: <none>; prim: <none>
    logic [3:0] limb_31_801; // decl: <none>; prim: <none>
    logic [4:0] limb_31_802; // decl: <none>; prim: <none>
    logic [3:0] limb_31_803; // decl: <none>; prim: <none>
    logic [67:0] limb_31_804; // decl: <none>; prim: <none>
    logic [31:0] limb_38_805; // decl: <none>; prim: <none>
    logic [31:0] limb_38_806; // decl: <none>; prim: <none>
    logic [31:0] limb_38_807; // decl: <none>; prim: <none>
    logic [32:0] limb_38_808; // decl: <none>; prim: <none>
    logic [31:0] limb_38_809; // decl: <none>; prim: <none>
    logic limb_38_810; // decl: <none>; prim: <none>
    logic [31:0] limb_38_811; // decl: <none>; prim: <none>
    logic [31:0] limb_38_812; // decl: <none>; prim: <none>
    logic [31:0] limb_38_813; // decl: <none>; prim: <none>
    logic [32:0] limb_38_814; // decl: <none>; prim: <none>
    logic [31:0] limb_38_815; // decl: <none>; prim: <none>
    logic limb_38_816; // decl: <none>; prim: <none>
    logic [31:0] limb_38_817; // decl: <none>; prim: <none>
    logic [31:0] limb_38_818; // decl: <none>; prim: <none>
    logic [31:0] limb_38_819; // decl: <none>; prim: <none>
    logic [32:0] limb_38_820; // decl: <none>; prim: <none>
    logic [31:0] limb_38_821; // decl: <none>; prim: <none>
    logic limb_38_822; // decl: <none>; prim: <none>
    logic [31:0] limb_38_823; // decl: <none>; prim: <none>
    logic [31:0] limb_38_824; // decl: <none>; prim: <none>
    logic [31:0] limb_38_825; // decl: <none>; prim: <none>
    logic [32:0] limb_38_826; // decl: <none>; prim: <none>
    logic [31:0] limb_38_827; // decl: <none>; prim: <none>
    logic limb_38_828; // decl: <none>; prim: <none>
    logic [1:0] limb_38_829; // decl: <none>; prim: <none>
    logic [1:0] limb_38_830; // decl: <none>; prim: <none>
    logic [1:0] limb_38_831; // decl: <none>; prim: <none>
    logic [2:0] limb_38_832; // decl: <none>; prim: <none>
    logic [1:0] limb_38_833; // decl: <none>; prim: <none>
    logic [129:0] limb_38_834; // decl: <none>; prim: <none>
    logic [31:0] limb_40_835; // decl: <none>; prim: <none>
    logic [31:0] limb_40_836; // decl: <none>; prim: <none>
    logic [31:0] limb_40_837; // decl: <none>; prim: <none>
    logic [32:0] limb_40_838; // decl: <none>; prim: <none>
    logic [31:0] limb_40_839; // decl: <none>; prim: <none>
    logic limb_40_840; // decl: <none>; prim: <none>
    logic [31:0] limb_40_841; // decl: <none>; prim: <none>
    logic [31:0] limb_40_842; // decl: <none>; prim: <none>
    logic [31:0] limb_40_843; // decl: <none>; prim: <none>
    logic [32:0] limb_40_844; // decl: <none>; prim: <none>
    logic [31:0] limb_40_845; // decl: <none>; prim: <none>
    logic limb_40_846; // decl: <none>; prim: <none>
    logic [31:0] limb_40_847; // decl: <none>; prim: <none>
    logic [31:0] limb_40_848; // decl: <none>; prim: <none>
    logic [31:0] limb_40_849; // decl: <none>; prim: <none>
    logic [32:0] limb_40_850; // decl: <none>; prim: <none>
    logic [31:0] limb_40_851; // decl: <none>; prim: <none>
    logic limb_40_852; // decl: <none>; prim: <none>
    logic [31:0] limb_40_853; // decl: <none>; prim: <none>
    logic [31:0] limb_40_854; // decl: <none>; prim: <none>
    logic [31:0] limb_40_855; // decl: <none>; prim: <none>
    logic [32:0] limb_40_856; // decl: <none>; prim: <none>
    logic [31:0] limb_40_857; // decl: <none>; prim: <none>
    logic limb_40_858; // decl: <none>; prim: <none>
    logic [1:0] limb_40_859; // decl: <none>; prim: <none>
    logic [1:0] limb_40_860; // decl: <none>; prim: <none>
    logic [1:0] limb_40_861; // decl: <none>; prim: <none>
    logic [2:0] limb_40_862; // decl: <none>; prim: <none>
    logic [1:0] limb_40_863; // decl: <none>; prim: <none>
    logic [129:0] limb_40_864; // decl: <none>; prim: <none>
    logic [31:0] limb_51_865; // decl: <none>; prim: <none>
    logic [31:0] limb_51_866; // decl: <none>; prim: <none>
    logic [32:0] limb_51_867; // decl: <none>; prim: <none>
    logic [31:0] limb_51_868; // decl: <none>; prim: <none>
    logic limb_51_869; // decl: <none>; prim: <none>
    logic [31:0] limb_51_870; // decl: <none>; prim: <none>
    logic [31:0] limb_51_871; // decl: <none>; prim: <none>
    logic [32:0] limb_51_872; // decl: <none>; prim: <none>
    logic [31:0] limb_51_873; // decl: <none>; prim: <none>
    logic limb_51_874; // decl: <none>; prim: <none>
    logic limb_51_875; // decl: <none>; prim: <none>
    logic limb_51_876; // decl: <none>; prim: <none>
    logic [1:0] limb_51_877; // decl: <none>; prim: <none>
    logic limb_51_878; // decl: <none>; prim: <none>
    logic [64:0] limb_51_879; // decl: <none>; prim: <none>
    logic [31:0] limb_53_880; // decl: <none>; prim: <none>
    logic [31:0] limb_53_881; // decl: <none>; prim: <none>
    logic [32:0] limb_53_882; // decl: <none>; prim: <none>
    logic [31:0] limb_53_883; // decl: <none>; prim: <none>
    logic limb_53_884; // decl: <none>; prim: <none>
    logic [31:0] limb_53_885; // decl: <none>; prim: <none>
    logic [31:0] limb_53_886; // decl: <none>; prim: <none>
    logic [32:0] limb_53_887; // decl: <none>; prim: <none>
    logic [31:0] limb_53_888; // decl: <none>; prim: <none>
    logic limb_53_889; // decl: <none>; prim: <none>
    logic limb_53_890; // decl: <none>; prim: <none>
    logic limb_53_891; // decl: <none>; prim: <none>
    logic [1:0] limb_53_892; // decl: <none>; prim: <none>
    logic limb_53_893; // decl: <none>; prim: <none>
    logic [64:0] limb_53_894; // decl: <none>; prim: <none>
    logic [31:0] limb_59_895; // decl: <none>; prim: <none>
    logic [31:0] limb_59_896; // decl: <none>; prim: <none>
    logic [32:0] limb_59_897; // decl: <none>; prim: <none>
    logic [31:0] limb_59_898; // decl: <none>; prim: <none>
    logic limb_59_899; // decl: <none>; prim: <none>
    logic [1:0] limb_59_900; // decl: <none>; prim: <none>
    logic [1:0] limb_59_901; // decl: <none>; prim: <none>
    logic [2:0] limb_59_902; // decl: <none>; prim: <none>
    logic [1:0] limb_59_903; // decl: <none>; prim: <none>
    logic [33:0] limb_59_904; // decl: <none>; prim: <none>
    logic [31:0] limb_61_905; // decl: <none>; prim: <none>
    logic [31:0] limb_61_906; // decl: <none>; prim: <none>
    logic [32:0] limb_61_907; // decl: <none>; prim: <none>
    logic [31:0] limb_61_908; // decl: <none>; prim: <none>
    logic limb_61_909; // decl: <none>; prim: <none>
    logic [1:0] limb_61_910; // decl: <none>; prim: <none>
    logic [1:0] limb_61_911; // decl: <none>; prim: <none>
    logic [2:0] limb_61_912; // decl: <none>; prim: <none>
    logic [1:0] limb_61_913; // decl: <none>; prim: <none>
    logic [33:0] limb_61_914; // decl: <none>; prim: <none>
    logic [31:0] limb_67_915; // decl: <none>; prim: <none>
    logic [31:0] limb_67_916; // decl: <none>; prim: <none>
    logic [31:0] limb_67_917; // decl: <none>; prim: <none>
    logic [32:0] limb_67_918; // decl: <none>; prim: <none>
    logic [31:0] limb_67_919; // decl: <none>; prim: <none>
    logic limb_67_920; // decl: <none>; prim: <none>
    logic [31:0] limb_67_921; // decl: <none>; prim: <none>
    logic [31:0] limb_67_922; // decl: <none>; prim: <none>
    logic [31:0] limb_67_923; // decl: <none>; prim: <none>
    logic [32:0] limb_67_924; // decl: <none>; prim: <none>
    logic [31:0] limb_67_925; // decl: <none>; prim: <none>
    logic limb_67_926; // decl: <none>; prim: <none>
    logic [3:0] limb_67_927; // decl: <none>; prim: <none>
    logic [3:0] limb_67_928; // decl: <none>; prim: <none>
    logic [3:0] limb_67_929; // decl: <none>; prim: <none>
    logic [4:0] limb_67_930; // decl: <none>; prim: <none>
    logic [3:0] limb_67_931; // decl: <none>; prim: <none>
    logic [67:0] limb_67_932; // decl: <none>; prim: <none>
    logic [31:0] limb_69_933; // decl: <none>; prim: <none>
    logic [31:0] limb_69_934; // decl: <none>; prim: <none>
    logic [31:0] limb_69_935; // decl: <none>; prim: <none>
    logic [32:0] limb_69_936; // decl: <none>; prim: <none>
    logic [31:0] limb_69_937; // decl: <none>; prim: <none>
    logic limb_69_938; // decl: <none>; prim: <none>
    logic [31:0] limb_69_939; // decl: <none>; prim: <none>
    logic [31:0] limb_69_940; // decl: <none>; prim: <none>
    logic [31:0] limb_69_941; // decl: <none>; prim: <none>
    logic [32:0] limb_69_942; // decl: <none>; prim: <none>
    logic [31:0] limb_69_943; // decl: <none>; prim: <none>
    logic limb_69_944; // decl: <none>; prim: <none>
    logic [3:0] limb_69_945; // decl: <none>; prim: <none>
    logic [3:0] limb_69_946; // decl: <none>; prim: <none>
    logic [3:0] limb_69_947; // decl: <none>; prim: <none>
    logic [4:0] limb_69_948; // decl: <none>; prim: <none>
    logic [3:0] limb_69_949; // decl: <none>; prim: <none>
    logic [67:0] limb_69_950; // decl: <none>; prim: <none>
    logic [31:0] limb_76_951; // decl: <none>; prim: <none>
    logic [31:0] limb_76_952; // decl: <none>; prim: <none>
    logic [31:0] limb_76_953; // decl: <none>; prim: <none>
    logic [32:0] limb_76_954; // decl: <none>; prim: <none>
    logic [31:0] limb_76_955; // decl: <none>; prim: <none>
    logic limb_76_956; // decl: <none>; prim: <none>
    logic [31:0] limb_76_957; // decl: <none>; prim: <none>
    logic [31:0] limb_76_958; // decl: <none>; prim: <none>
    logic [31:0] limb_76_959; // decl: <none>; prim: <none>
    logic [32:0] limb_76_960; // decl: <none>; prim: <none>
    logic [31:0] limb_76_961; // decl: <none>; prim: <none>
    logic limb_76_962; // decl: <none>; prim: <none>
    logic [31:0] limb_76_963; // decl: <none>; prim: <none>
    logic [31:0] limb_76_964; // decl: <none>; prim: <none>
    logic [31:0] limb_76_965; // decl: <none>; prim: <none>
    logic [32:0] limb_76_966; // decl: <none>; prim: <none>
    logic [31:0] limb_76_967; // decl: <none>; prim: <none>
    logic limb_76_968; // decl: <none>; prim: <none>
    logic [31:0] limb_76_969; // decl: <none>; prim: <none>
    logic [31:0] limb_76_970; // decl: <none>; prim: <none>
    logic [31:0] limb_76_971; // decl: <none>; prim: <none>
    logic [32:0] limb_76_972; // decl: <none>; prim: <none>
    logic [31:0] limb_76_973; // decl: <none>; prim: <none>
    logic limb_76_974; // decl: <none>; prim: <none>
    logic [1:0] limb_76_975; // decl: <none>; prim: <none>
    logic [1:0] limb_76_976; // decl: <none>; prim: <none>
    logic [1:0] limb_76_977; // decl: <none>; prim: <none>
    logic [2:0] limb_76_978; // decl: <none>; prim: <none>
    logic [1:0] limb_76_979; // decl: <none>; prim: <none>
    logic [129:0] limb_76_980; // decl: <none>; prim: <none>
    logic [31:0] limb_78_981; // decl: <none>; prim: <none>
    logic [31:0] limb_78_982; // decl: <none>; prim: <none>
    logic [31:0] limb_78_983; // decl: <none>; prim: <none>
    logic [32:0] limb_78_984; // decl: <none>; prim: <none>
    logic [31:0] limb_78_985; // decl: <none>; prim: <none>
    logic limb_78_986; // decl: <none>; prim: <none>
    logic [31:0] limb_78_987; // decl: <none>; prim: <none>
    logic [31:0] limb_78_988; // decl: <none>; prim: <none>
    logic [31:0] limb_78_989; // decl: <none>; prim: <none>
    logic [32:0] limb_78_990; // decl: <none>; prim: <none>
    logic [31:0] limb_78_991; // decl: <none>; prim: <none>
    logic limb_78_992; // decl: <none>; prim: <none>
    logic [31:0] limb_78_993; // decl: <none>; prim: <none>
    logic [31:0] limb_78_994; // decl: <none>; prim: <none>
    logic [31:0] limb_78_995; // decl: <none>; prim: <none>
    logic [32:0] limb_78_996; // decl: <none>; prim: <none>
    logic [31:0] limb_78_997; // decl: <none>; prim: <none>
    logic limb_78_998; // decl: <none>; prim: <none>
    logic [31:0] limb_78_999; // decl: <none>; prim: <none>
    logic [31:0] limb_78_1000; // decl: <none>; prim: <none>
    logic [31:0] limb_78_1001; // decl: <none>; prim: <none>
    logic [32:0] limb_78_1002; // decl: <none>; prim: <none>
    logic [31:0] limb_78_1003; // decl: <none>; prim: <none>
    logic limb_78_1004; // decl: <none>; prim: <none>
    logic [1:0] limb_78_1005; // decl: <none>; prim: <none>
    logic [1:0] limb_78_1006; // decl: <none>; prim: <none>
    logic [1:0] limb_78_1007; // decl: <none>; prim: <none>
    logic [2:0] limb_78_1008; // decl: <none>; prim: <none>
    logic [1:0] limb_78_1009; // decl: <none>; prim: <none>
    logic [129:0] limb_78_1010; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1011; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1012; // decl: <none>; prim: <none>
    logic [32:0] limb_85_1013; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1014; // decl: <none>; prim: <none>
    logic limb_85_1015; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1016; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1017; // decl: <none>; prim: <none>
    logic [32:0] limb_85_1018; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1019; // decl: <none>; prim: <none>
    logic limb_85_1020; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1021; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1022; // decl: <none>; prim: <none>
    logic [32:0] limb_85_1023; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1024; // decl: <none>; prim: <none>
    logic limb_85_1025; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1026; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1027; // decl: <none>; prim: <none>
    logic [32:0] limb_85_1028; // decl: <none>; prim: <none>
    logic [31:0] limb_85_1029; // decl: <none>; prim: <none>
    logic limb_85_1030; // decl: <none>; prim: <none>
    logic limb_85_1031; // decl: <none>; prim: <none>
    logic limb_85_1032; // decl: <none>; prim: <none>
    logic [1:0] limb_85_1033; // decl: <none>; prim: <none>
    logic limb_85_1034; // decl: <none>; prim: <none>
    logic [128:0] limb_85_1035; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1036; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1037; // decl: <none>; prim: <none>
    logic [32:0] limb_87_1038; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1039; // decl: <none>; prim: <none>
    logic limb_87_1040; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1041; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1042; // decl: <none>; prim: <none>
    logic [32:0] limb_87_1043; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1044; // decl: <none>; prim: <none>
    logic limb_87_1045; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1046; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1047; // decl: <none>; prim: <none>
    logic [32:0] limb_87_1048; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1049; // decl: <none>; prim: <none>
    logic limb_87_1050; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1051; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1052; // decl: <none>; prim: <none>
    logic [32:0] limb_87_1053; // decl: <none>; prim: <none>
    logic [31:0] limb_87_1054; // decl: <none>; prim: <none>
    logic limb_87_1055; // decl: <none>; prim: <none>
    logic limb_87_1056; // decl: <none>; prim: <none>
    logic limb_87_1057; // decl: <none>; prim: <none>
    logic [1:0] limb_87_1058; // decl: <none>; prim: <none>
    logic limb_87_1059; // decl: <none>; prim: <none>
    logic [128:0] limb_87_1060; // decl: <none>; prim: <none>
    logic [31:0] limb_95_1061; // decl: <none>; prim: <none>
    logic [31:0] limb_95_1062; // decl: <none>; prim: <none>
    logic [32:0] limb_95_1063; // decl: <none>; prim: <none>
    logic [31:0] limb_95_1064; // decl: <none>; prim: <none>
    logic limb_95_1065; // decl: <none>; prim: <none>
    logic [1:0] limb_95_1066; // decl: <none>; prim: <none>
    logic [1:0] limb_95_1067; // decl: <none>; prim: <none>
    logic [2:0] limb_95_1068; // decl: <none>; prim: <none>
    logic [1:0] limb_95_1069; // decl: <none>; prim: <none>
    logic [33:0] limb_95_1070; // decl: <none>; prim: <none>
    logic [31:0] limb_97_1071; // decl: <none>; prim: <none>
    logic [31:0] limb_97_1072; // decl: <none>; prim: <none>
    logic [32:0] limb_97_1073; // decl: <none>; prim: <none>
    logic [31:0] limb_97_1074; // decl: <none>; prim: <none>
    logic limb_97_1075; // decl: <none>; prim: <none>
    logic [1:0] limb_97_1076; // decl: <none>; prim: <none>
    logic [1:0] limb_97_1077; // decl: <none>; prim: <none>
    logic [2:0] limb_97_1078; // decl: <none>; prim: <none>
    logic [1:0] limb_97_1079; // decl: <none>; prim: <none>
    logic [33:0] limb_97_1080; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1081; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1082; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1083; // decl: <none>; prim: <none>
    logic [32:0] limb_103_1084; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1085; // decl: <none>; prim: <none>
    logic limb_103_1086; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1087; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1088; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1089; // decl: <none>; prim: <none>
    logic [32:0] limb_103_1090; // decl: <none>; prim: <none>
    logic [31:0] limb_103_1091; // decl: <none>; prim: <none>
    logic limb_103_1092; // decl: <none>; prim: <none>
    logic [3:0] limb_103_1093; // decl: <none>; prim: <none>
    logic [3:0] limb_103_1094; // decl: <none>; prim: <none>
    logic [3:0] limb_103_1095; // decl: <none>; prim: <none>
    logic [4:0] limb_103_1096; // decl: <none>; prim: <none>
    logic [3:0] limb_103_1097; // decl: <none>; prim: <none>
    logic [67:0] limb_103_1098; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1099; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1100; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1101; // decl: <none>; prim: <none>
    logic [32:0] limb_105_1102; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1103; // decl: <none>; prim: <none>
    logic limb_105_1104; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1105; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1106; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1107; // decl: <none>; prim: <none>
    logic [32:0] limb_105_1108; // decl: <none>; prim: <none>
    logic [31:0] limb_105_1109; // decl: <none>; prim: <none>
    logic limb_105_1110; // decl: <none>; prim: <none>
    logic [3:0] limb_105_1111; // decl: <none>; prim: <none>
    logic [3:0] limb_105_1112; // decl: <none>; prim: <none>
    logic [3:0] limb_105_1113; // decl: <none>; prim: <none>
    logic [4:0] limb_105_1114; // decl: <none>; prim: <none>
    logic [3:0] limb_105_1115; // decl: <none>; prim: <none>
    logic [67:0] limb_105_1116; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1117; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1118; // decl: <none>; prim: <none>
    logic [32:0] limb_113_1119; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1120; // decl: <none>; prim: <none>
    logic limb_113_1121; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1122; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1123; // decl: <none>; prim: <none>
    logic [32:0] limb_113_1124; // decl: <none>; prim: <none>
    logic [31:0] limb_113_1125; // decl: <none>; prim: <none>
    logic limb_113_1126; // decl: <none>; prim: <none>
    logic [1:0] limb_113_1127; // decl: <none>; prim: <none>
    logic [1:0] limb_113_1128; // decl: <none>; prim: <none>
    logic [2:0] limb_113_1129; // decl: <none>; prim: <none>
    logic [1:0] limb_113_1130; // decl: <none>; prim: <none>
    logic [65:0] limb_113_1131; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1132; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1133; // decl: <none>; prim: <none>
    logic [32:0] limb_115_1134; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1135; // decl: <none>; prim: <none>
    logic limb_115_1136; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1137; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1138; // decl: <none>; prim: <none>
    logic [32:0] limb_115_1139; // decl: <none>; prim: <none>
    logic [31:0] limb_115_1140; // decl: <none>; prim: <none>
    logic limb_115_1141; // decl: <none>; prim: <none>
    logic [1:0] limb_115_1142; // decl: <none>; prim: <none>
    logic [1:0] limb_115_1143; // decl: <none>; prim: <none>
    logic [2:0] limb_115_1144; // decl: <none>; prim: <none>
    logic [1:0] limb_115_1145; // decl: <none>; prim: <none>
    logic [65:0] limb_115_1146; // decl: <none>; prim: <none>
    logic [31:0] limb_121_1147; // decl: <none>; prim: <none>
    logic [31:0] limb_121_1148; // decl: <none>; prim: <none>
    logic [32:0] limb_121_1149; // decl: <none>; prim: <none>
    logic [31:0] limb_121_1150; // decl: <none>; prim: <none>
    logic limb_121_1151; // decl: <none>; prim: <none>
    logic [1:0] limb_121_1152; // decl: <none>; prim: <none>
    logic [1:0] limb_121_1153; // decl: <none>; prim: <none>
    logic [2:0] limb_121_1154; // decl: <none>; prim: <none>
    logic [1:0] limb_121_1155; // decl: <none>; prim: <none>
    logic [33:0] limb_121_1156; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1157; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1158; // decl: <none>; prim: <none>
    logic [32:0] limb_123_1159; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1160; // decl: <none>; prim: <none>
    logic limb_123_1161; // decl: <none>; prim: <none>
    logic [1:0] limb_123_1162; // decl: <none>; prim: <none>
    logic [1:0] limb_123_1163; // decl: <none>; prim: <none>
    logic [2:0] limb_123_1164; // decl: <none>; prim: <none>
    logic [1:0] limb_123_1165; // decl: <none>; prim: <none>
    logic [33:0] limb_123_1166; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1167; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1168; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1169; // decl: <none>; prim: <none>
    logic [32:0] limb_129_1170; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1171; // decl: <none>; prim: <none>
    logic limb_129_1172; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1173; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1174; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1175; // decl: <none>; prim: <none>
    logic [32:0] limb_129_1176; // decl: <none>; prim: <none>
    logic [31:0] limb_129_1177; // decl: <none>; prim: <none>
    logic limb_129_1178; // decl: <none>; prim: <none>
    logic [3:0] limb_129_1179; // decl: <none>; prim: <none>
    logic [3:0] limb_129_1180; // decl: <none>; prim: <none>
    logic [3:0] limb_129_1181; // decl: <none>; prim: <none>
    logic [4:0] limb_129_1182; // decl: <none>; prim: <none>
    logic [3:0] limb_129_1183; // decl: <none>; prim: <none>
    logic [67:0] limb_129_1184; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1185; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1186; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1187; // decl: <none>; prim: <none>
    logic [32:0] limb_131_1188; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1189; // decl: <none>; prim: <none>
    logic limb_131_1190; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1191; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1192; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1193; // decl: <none>; prim: <none>
    logic [32:0] limb_131_1194; // decl: <none>; prim: <none>
    logic [31:0] limb_131_1195; // decl: <none>; prim: <none>
    logic limb_131_1196; // decl: <none>; prim: <none>
    logic [3:0] limb_131_1197; // decl: <none>; prim: <none>
    logic [3:0] limb_131_1198; // decl: <none>; prim: <none>
    logic [3:0] limb_131_1199; // decl: <none>; prim: <none>
    logic [4:0] limb_131_1200; // decl: <none>; prim: <none>
    logic [3:0] limb_131_1201; // decl: <none>; prim: <none>
    logic [67:0] limb_131_1202; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1203; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1204; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1205; // decl: <none>; prim: <none>
    logic [32:0] limb_138_1206; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1207; // decl: <none>; prim: <none>
    logic limb_138_1208; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1209; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1210; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1211; // decl: <none>; prim: <none>
    logic [32:0] limb_138_1212; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1213; // decl: <none>; prim: <none>
    logic limb_138_1214; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1215; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1216; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1217; // decl: <none>; prim: <none>
    logic [32:0] limb_138_1218; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1219; // decl: <none>; prim: <none>
    logic limb_138_1220; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1221; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1222; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1223; // decl: <none>; prim: <none>
    logic [32:0] limb_138_1224; // decl: <none>; prim: <none>
    logic [31:0] limb_138_1225; // decl: <none>; prim: <none>
    logic limb_138_1226; // decl: <none>; prim: <none>
    logic [3:0] limb_138_1227; // decl: <none>; prim: <none>
    logic [3:0] limb_138_1228; // decl: <none>; prim: <none>
    logic [3:0] limb_138_1229; // decl: <none>; prim: <none>
    logic [4:0] limb_138_1230; // decl: <none>; prim: <none>
    logic [3:0] limb_138_1231; // decl: <none>; prim: <none>
    logic [131:0] limb_138_1232; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1233; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1234; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1235; // decl: <none>; prim: <none>
    logic [32:0] limb_140_1236; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1237; // decl: <none>; prim: <none>
    logic limb_140_1238; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1239; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1240; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1241; // decl: <none>; prim: <none>
    logic [32:0] limb_140_1242; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1243; // decl: <none>; prim: <none>
    logic limb_140_1244; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1245; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1246; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1247; // decl: <none>; prim: <none>
    logic [32:0] limb_140_1248; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1249; // decl: <none>; prim: <none>
    logic limb_140_1250; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1251; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1252; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1253; // decl: <none>; prim: <none>
    logic [32:0] limb_140_1254; // decl: <none>; prim: <none>
    logic [31:0] limb_140_1255; // decl: <none>; prim: <none>
    logic limb_140_1256; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1257; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1258; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1259; // decl: <none>; prim: <none>
    logic [4:0] limb_140_1260; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1261; // decl: <none>; prim: <none>
    logic [131:0] limb_140_1262; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1263; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1264; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1265; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1266; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1267; // decl: <none>; prim: <none>
    logic limb_147_1268; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1269; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1270; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1271; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1272; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1273; // decl: <none>; prim: <none>
    logic limb_147_1274; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1275; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1276; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1277; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1278; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1279; // decl: <none>; prim: <none>
    logic limb_147_1280; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1281; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1282; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1283; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1284; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1285; // decl: <none>; prim: <none>
    logic limb_147_1286; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1287; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1288; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1289; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1290; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1291; // decl: <none>; prim: <none>
    logic limb_147_1292; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1293; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1294; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1295; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1296; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1297; // decl: <none>; prim: <none>
    logic limb_147_1298; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1299; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1300; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1301; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1302; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1303; // decl: <none>; prim: <none>
    logic limb_147_1304; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1305; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1306; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1307; // decl: <none>; prim: <none>
    logic [32:0] limb_147_1308; // decl: <none>; prim: <none>
    logic [31:0] limb_147_1309; // decl: <none>; prim: <none>
    logic limb_147_1310; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1311; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1312; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1313; // decl: <none>; prim: <none>
    logic [2:0] limb_147_1314; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1315; // decl: <none>; prim: <none>
    logic [257:0] limb_147_1316; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1317; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1318; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1319; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1320; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1321; // decl: <none>; prim: <none>
    logic limb_149_1322; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1323; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1324; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1325; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1326; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1327; // decl: <none>; prim: <none>
    logic limb_149_1328; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1329; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1330; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1331; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1332; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1333; // decl: <none>; prim: <none>
    logic limb_149_1334; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1335; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1336; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1337; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1338; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1339; // decl: <none>; prim: <none>
    logic limb_149_1340; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1341; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1342; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1343; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1344; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1345; // decl: <none>; prim: <none>
    logic limb_149_1346; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1347; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1348; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1349; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1350; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1351; // decl: <none>; prim: <none>
    logic limb_149_1352; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1353; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1354; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1355; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1356; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1357; // decl: <none>; prim: <none>
    logic limb_149_1358; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1359; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1360; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1361; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1362; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1363; // decl: <none>; prim: <none>
    logic limb_149_1364; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1365; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1366; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1367; // decl: <none>; prim: <none>
    logic [2:0] limb_149_1368; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1369; // decl: <none>; prim: <none>
    logic [257:0] limb_149_1370; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1371; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1372; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1373; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1374; // decl: <none>; prim: <none>
    logic limb_157_1375; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1376; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1377; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1378; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1379; // decl: <none>; prim: <none>
    logic limb_157_1380; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1381; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1382; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1383; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1384; // decl: <none>; prim: <none>
    logic limb_157_1385; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1386; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1387; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1388; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1389; // decl: <none>; prim: <none>
    logic limb_157_1390; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1391; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1392; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1393; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1394; // decl: <none>; prim: <none>
    logic limb_157_1395; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1396; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1397; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1398; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1399; // decl: <none>; prim: <none>
    logic limb_157_1400; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1401; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1402; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1403; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1404; // decl: <none>; prim: <none>
    logic limb_157_1405; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1406; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1407; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1408; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1409; // decl: <none>; prim: <none>
    logic limb_157_1410; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1411; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1412; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1413; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1414; // decl: <none>; prim: <none>
    logic limb_157_1415; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1416; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1417; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1418; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1419; // decl: <none>; prim: <none>
    logic limb_157_1420; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1421; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1422; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1423; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1424; // decl: <none>; prim: <none>
    logic limb_157_1425; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1426; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1427; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1428; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1429; // decl: <none>; prim: <none>
    logic limb_157_1430; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1431; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1432; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1433; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1434; // decl: <none>; prim: <none>
    logic limb_157_1435; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1436; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1437; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1438; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1439; // decl: <none>; prim: <none>
    logic limb_157_1440; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1441; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1442; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1443; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1444; // decl: <none>; prim: <none>
    logic limb_157_1445; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1446; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1447; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1448; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1449; // decl: <none>; prim: <none>
    logic limb_157_1450; // decl: <none>; prim: <none>
    logic limb_157_1451; // decl: <none>; prim: <none>
    logic limb_157_1452; // decl: <none>; prim: <none>
    logic [1:0] limb_157_1453; // decl: <none>; prim: <none>
    logic limb_157_1454; // decl: <none>; prim: <none>
    logic [512:0] limb_157_1455; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1456; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1457; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1458; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1459; // decl: <none>; prim: <none>
    logic limb_216_1460; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1461; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1462; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1463; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1464; // decl: <none>; prim: <none>
    logic limb_216_1465; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1466; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1467; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1468; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1469; // decl: <none>; prim: <none>
    logic limb_216_1470; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1471; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1472; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1473; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1474; // decl: <none>; prim: <none>
    logic limb_216_1475; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1476; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1477; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1478; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1479; // decl: <none>; prim: <none>
    logic limb_216_1480; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1481; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1482; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1483; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1484; // decl: <none>; prim: <none>
    logic limb_216_1485; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1486; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1487; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1488; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1489; // decl: <none>; prim: <none>
    logic limb_216_1490; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1491; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1492; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1493; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1494; // decl: <none>; prim: <none>
    logic limb_216_1495; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1496; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1497; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1498; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1499; // decl: <none>; prim: <none>
    logic limb_216_1500; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1501; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1502; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1503; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1504; // decl: <none>; prim: <none>
    logic limb_216_1505; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1506; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1507; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1508; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1509; // decl: <none>; prim: <none>
    logic limb_216_1510; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1511; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1512; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1513; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1514; // decl: <none>; prim: <none>
    logic limb_216_1515; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1516; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1517; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1518; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1519; // decl: <none>; prim: <none>
    logic limb_216_1520; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1521; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1522; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1523; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1524; // decl: <none>; prim: <none>
    logic limb_216_1525; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1526; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1527; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1528; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1529; // decl: <none>; prim: <none>
    logic limb_216_1530; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1531; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1532; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1533; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1534; // decl: <none>; prim: <none>
    logic [511:0] limb_216_1535; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1536; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1537; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1538; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1539; // decl: <none>; prim: <none>
    logic limb_217_1540; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1541; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1542; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1543; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1544; // decl: <none>; prim: <none>
    logic limb_217_1545; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1546; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1547; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1548; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1549; // decl: <none>; prim: <none>
    logic limb_217_1550; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1551; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1552; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1553; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1554; // decl: <none>; prim: <none>
    logic limb_217_1555; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1556; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1557; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1558; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1559; // decl: <none>; prim: <none>
    logic limb_217_1560; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1561; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1562; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1563; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1564; // decl: <none>; prim: <none>
    logic limb_217_1565; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1566; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1567; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1568; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1569; // decl: <none>; prim: <none>
    logic limb_217_1570; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1571; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1572; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1573; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1574; // decl: <none>; prim: <none>
    logic limb_217_1575; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1576; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1577; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1578; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1579; // decl: <none>; prim: <none>
    logic limb_217_1580; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1581; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1582; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1583; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1584; // decl: <none>; prim: <none>
    logic limb_217_1585; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1586; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1587; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1588; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1589; // decl: <none>; prim: <none>
    logic limb_217_1590; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1591; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1592; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1593; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1594; // decl: <none>; prim: <none>
    logic limb_217_1595; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1596; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1597; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1598; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1599; // decl: <none>; prim: <none>
    logic limb_217_1600; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1601; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1602; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1603; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1604; // decl: <none>; prim: <none>
    logic limb_217_1605; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1606; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1607; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1608; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1609; // decl: <none>; prim: <none>
    logic limb_217_1610; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1611; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1612; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1613; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1614; // decl: <none>; prim: <none>
    logic [511:0] limb_217_1615; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1616; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1617; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1618; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1619; // decl: <none>; prim: <none>
    logic limb_218_1620; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1621; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1622; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1623; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1624; // decl: <none>; prim: <none>
    logic limb_218_1625; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1626; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1627; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1628; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1629; // decl: <none>; prim: <none>
    logic limb_218_1630; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1631; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1632; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1633; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1634; // decl: <none>; prim: <none>
    logic limb_218_1635; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1636; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1637; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1638; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1639; // decl: <none>; prim: <none>
    logic limb_218_1640; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1641; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1642; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1643; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1644; // decl: <none>; prim: <none>
    logic limb_218_1645; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1646; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1647; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1648; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1649; // decl: <none>; prim: <none>
    logic limb_218_1650; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1651; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1652; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1653; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1654; // decl: <none>; prim: <none>
    logic limb_218_1655; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1656; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1657; // decl: <none>; prim: <none>
    logic [2:0] limb_218_1658; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1659; // decl: <none>; prim: <none>
    logic [257:0] limb_218_1660; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1661; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1662; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1663; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1664; // decl: <none>; prim: <none>
    logic limb_219_1665; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1666; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1667; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1668; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1669; // decl: <none>; prim: <none>
    logic limb_219_1670; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1671; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1672; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1673; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1674; // decl: <none>; prim: <none>
    logic limb_219_1675; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1676; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1677; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1678; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1679; // decl: <none>; prim: <none>
    logic limb_219_1680; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1681; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1682; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1683; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1684; // decl: <none>; prim: <none>
    logic limb_219_1685; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1686; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1687; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1688; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1689; // decl: <none>; prim: <none>
    logic limb_219_1690; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1691; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1692; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1693; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1694; // decl: <none>; prim: <none>
    logic limb_219_1695; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1696; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1697; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1698; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1699; // decl: <none>; prim: <none>
    logic limb_219_1700; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1701; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1702; // decl: <none>; prim: <none>
    logic [2:0] limb_219_1703; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1704; // decl: <none>; prim: <none>
    logic [257:0] limb_219_1705; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1706; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1707; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1708; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1709; // decl: <none>; prim: <none>
    logic limb_220_1710; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1711; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1712; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1713; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1714; // decl: <none>; prim: <none>
    logic limb_220_1715; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1716; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1717; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1718; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1719; // decl: <none>; prim: <none>
    logic limb_220_1720; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1721; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1722; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1723; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1724; // decl: <none>; prim: <none>
    logic limb_220_1725; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1726; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1727; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1728; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1729; // decl: <none>; prim: <none>
    logic limb_220_1730; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1731; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1732; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1733; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1734; // decl: <none>; prim: <none>
    logic limb_220_1735; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1736; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1737; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1738; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1739; // decl: <none>; prim: <none>
    logic limb_220_1740; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1741; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1742; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1743; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1744; // decl: <none>; prim: <none>
    logic [255:0] limb_220_1745; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1746; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1747; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1748; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1749; // decl: <none>; prim: <none>
    logic limb_221_1750; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1751; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1752; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1753; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1754; // decl: <none>; prim: <none>
    logic limb_221_1755; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1756; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1757; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1758; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1759; // decl: <none>; prim: <none>
    logic limb_221_1760; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1761; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1762; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1763; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1764; // decl: <none>; prim: <none>
    logic limb_221_1765; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1766; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1767; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1768; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1769; // decl: <none>; prim: <none>
    logic limb_221_1770; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1771; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1772; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1773; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1774; // decl: <none>; prim: <none>
    logic limb_221_1775; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1776; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1777; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1778; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1779; // decl: <none>; prim: <none>
    logic limb_221_1780; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1781; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1782; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1783; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1784; // decl: <none>; prim: <none>
    logic [255:0] limb_221_1785; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1786; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1787; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1788; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1789; // decl: <none>; prim: <none>
    logic limb_222_1790; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1791; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1792; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1793; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1794; // decl: <none>; prim: <none>
    logic limb_222_1795; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1796; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1797; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1798; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1799; // decl: <none>; prim: <none>
    logic limb_222_1800; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1801; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1802; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1803; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1804; // decl: <none>; prim: <none>
    logic limb_222_1805; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1806; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1807; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1808; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1809; // decl: <none>; prim: <none>
    logic limb_222_1810; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1811; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1812; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1813; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1814; // decl: <none>; prim: <none>
    logic limb_222_1815; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1816; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1817; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1818; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1819; // decl: <none>; prim: <none>
    logic limb_222_1820; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1821; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1822; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1823; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1824; // decl: <none>; prim: <none>
    logic [255:0] limb_222_1825; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1826; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1827; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1828; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1829; // decl: <none>; prim: <none>
    logic limb_223_1830; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1831; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1832; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1833; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1834; // decl: <none>; prim: <none>
    logic limb_223_1835; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1836; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1837; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1838; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1839; // decl: <none>; prim: <none>
    logic limb_223_1840; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1841; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1842; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1843; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1844; // decl: <none>; prim: <none>
    logic limb_223_1845; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1846; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1847; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1848; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1849; // decl: <none>; prim: <none>
    logic limb_223_1850; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1851; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1852; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1853; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1854; // decl: <none>; prim: <none>
    logic limb_223_1855; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1856; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1857; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1858; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1859; // decl: <none>; prim: <none>
    logic limb_223_1860; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1861; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1862; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1863; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1864; // decl: <none>; prim: <none>
    logic [255:0] limb_223_1865; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1866; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1867; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1868; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1869; // decl: <none>; prim: <none>
    logic limb_224_1870; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1871; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1872; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1873; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1874; // decl: <none>; prim: <none>
    logic limb_224_1875; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1876; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1877; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1878; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1879; // decl: <none>; prim: <none>
    logic limb_224_1880; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1881; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1882; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1883; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1884; // decl: <none>; prim: <none>
    logic limb_224_1885; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1886; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1887; // decl: <none>; prim: <none>
    logic [4:0] limb_224_1888; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1889; // decl: <none>; prim: <none>
    logic [131:0] limb_224_1890; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1891; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1892; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1893; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1894; // decl: <none>; prim: <none>
    logic limb_225_1895; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1896; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1897; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1898; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1899; // decl: <none>; prim: <none>
    logic limb_225_1900; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1901; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1902; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1903; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1904; // decl: <none>; prim: <none>
    logic limb_225_1905; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1906; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1907; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1908; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1909; // decl: <none>; prim: <none>
    logic limb_225_1910; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1911; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1912; // decl: <none>; prim: <none>
    logic [4:0] limb_225_1913; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1914; // decl: <none>; prim: <none>
    logic [131:0] limb_225_1915; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1916; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1917; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1918; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1919; // decl: <none>; prim: <none>
    logic limb_226_1920; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1921; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1922; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1923; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1924; // decl: <none>; prim: <none>
    logic limb_226_1925; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1926; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1927; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1928; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1929; // decl: <none>; prim: <none>
    logic limb_226_1930; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1931; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1932; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1933; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1934; // decl: <none>; prim: <none>
    logic limb_226_1935; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1936; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1937; // decl: <none>; prim: <none>
    logic [2:0] limb_226_1938; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1939; // decl: <none>; prim: <none>
    logic [129:0] limb_226_1940; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1941; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1942; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1943; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1944; // decl: <none>; prim: <none>
    logic limb_227_1945; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1946; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1947; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1948; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1949; // decl: <none>; prim: <none>
    logic limb_227_1950; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1951; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1952; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1953; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1954; // decl: <none>; prim: <none>
    logic limb_227_1955; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1956; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1957; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1958; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1959; // decl: <none>; prim: <none>
    logic limb_227_1960; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1961; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1962; // decl: <none>; prim: <none>
    logic [2:0] limb_227_1963; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1964; // decl: <none>; prim: <none>
    logic [129:0] limb_227_1965; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1966; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1967; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1968; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1969; // decl: <none>; prim: <none>
    logic limb_228_1970; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1971; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1972; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1973; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1974; // decl: <none>; prim: <none>
    logic limb_228_1975; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1976; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1977; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1978; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1979; // decl: <none>; prim: <none>
    logic limb_228_1980; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1981; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1982; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1983; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1984; // decl: <none>; prim: <none>
    logic limb_228_1985; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1986; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1987; // decl: <none>; prim: <none>
    logic [2:0] limb_228_1988; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1989; // decl: <none>; prim: <none>
    logic [129:0] limb_228_1990; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1991; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1992; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1993; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1994; // decl: <none>; prim: <none>
    logic limb_229_1995; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1996; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1997; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1998; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1999; // decl: <none>; prim: <none>
    logic limb_229_2000; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2001; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2002; // decl: <none>; prim: <none>
    logic [32:0] limb_229_2003; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2004; // decl: <none>; prim: <none>
    logic limb_229_2005; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2006; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2007; // decl: <none>; prim: <none>
    logic [32:0] limb_229_2008; // decl: <none>; prim: <none>
    logic [31:0] limb_229_2009; // decl: <none>; prim: <none>
    logic limb_229_2010; // decl: <none>; prim: <none>
    logic [1:0] limb_229_2011; // decl: <none>; prim: <none>
    logic [1:0] limb_229_2012; // decl: <none>; prim: <none>
    logic [2:0] limb_229_2013; // decl: <none>; prim: <none>
    logic [1:0] limb_229_2014; // decl: <none>; prim: <none>
    logic [129:0] limb_229_2015; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2016; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2017; // decl: <none>; prim: <none>
    logic [32:0] limb_230_2018; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2019; // decl: <none>; prim: <none>
    logic limb_230_2020; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2021; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2022; // decl: <none>; prim: <none>
    logic [32:0] limb_230_2023; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2024; // decl: <none>; prim: <none>
    logic limb_230_2025; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2026; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2027; // decl: <none>; prim: <none>
    logic [32:0] limb_230_2028; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2029; // decl: <none>; prim: <none>
    logic limb_230_2030; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2031; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2032; // decl: <none>; prim: <none>
    logic [32:0] limb_230_2033; // decl: <none>; prim: <none>
    logic [31:0] limb_230_2034; // decl: <none>; prim: <none>
    logic limb_230_2035; // decl: <none>; prim: <none>
    logic [1:0] limb_230_2036; // decl: <none>; prim: <none>
    logic [1:0] limb_230_2037; // decl: <none>; prim: <none>
    logic [2:0] limb_230_2038; // decl: <none>; prim: <none>
    logic [1:0] limb_230_2039; // decl: <none>; prim: <none>
    logic [129:0] limb_230_2040; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2041; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2042; // decl: <none>; prim: <none>
    logic [32:0] limb_231_2043; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2044; // decl: <none>; prim: <none>
    logic limb_231_2045; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2046; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2047; // decl: <none>; prim: <none>
    logic [32:0] limb_231_2048; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2049; // decl: <none>; prim: <none>
    logic limb_231_2050; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2051; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2052; // decl: <none>; prim: <none>
    logic [32:0] limb_231_2053; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2054; // decl: <none>; prim: <none>
    logic limb_231_2055; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2056; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2057; // decl: <none>; prim: <none>
    logic [32:0] limb_231_2058; // decl: <none>; prim: <none>
    logic [31:0] limb_231_2059; // decl: <none>; prim: <none>
    logic limb_231_2060; // decl: <none>; prim: <none>
    logic [1:0] limb_231_2061; // decl: <none>; prim: <none>
    logic [1:0] limb_231_2062; // decl: <none>; prim: <none>
    logic [2:0] limb_231_2063; // decl: <none>; prim: <none>
    logic [1:0] limb_231_2064; // decl: <none>; prim: <none>
    logic [129:0] limb_231_2065; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_362_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_366_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_370_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_374_s5; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_174_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_387_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_391_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_395_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_399_s4; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s7; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [129:0] rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_175_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_465_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_469_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_473_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_477_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_48_s7; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [31:0] rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_719_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_724_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_729_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_729_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_164_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_734_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_739_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_744_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_267_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_269_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_299_s6; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_170_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_750_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_755_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_304_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_759_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_764_s6; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_455_s7; // decl: <none>; prim: <none>
    logic [68:0] rtlzz_pipe_458_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_789_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_795_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_801_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_807_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_813_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_819_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_825_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_831_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_837_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_842_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_849_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_854_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_860_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_866_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_871_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_876_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_184_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_274_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_276_s7; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_313_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_881_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_886_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_891_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_953_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_959_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_965_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_971_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_977_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1011_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1011_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1016_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1016_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1021_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1021_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1026_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1026_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1031_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1031_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_198_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_112_s3; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_284_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1036_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1036_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1039_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1041_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1041_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1044_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1046_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1046_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1049_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1051_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1051_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1054_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1055_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1056_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1056_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1056_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1057_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_287_s5; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_200_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_202_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1062_s3; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1067_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1081_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1087_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1093_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1101_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1107_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1113_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1117_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1122_s3; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1127_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1132_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1137_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1142_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_211_s6; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1150_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1151_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1152_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1153_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1169_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1175_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1181_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1235_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1241_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1247_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1253_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1259_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1387_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1392_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1397_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1402_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1407_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1412_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1417_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1422_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1427_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1432_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1437_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1442_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1447_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1452_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1866_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1871_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1876_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1881_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1886_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1205_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1211_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1217_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1223_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1229_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1661_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1666_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1671_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1676_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1681_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1686_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1691_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1696_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1701_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1263_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1269_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1275_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1281_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1287_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1293_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1299_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1305_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1311_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = limb_13_733; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = limb_15_748; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__32_v0 = (rtlzz_pipe_164_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (__beopt_width_546 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign s8_norm_add_36_v0 = limb_21_758; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__47_v0 = (__beopt_width_554 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_add_39_v0 = limb_23_768; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (rtlzz_pipe_170_s7 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = limb_29_786; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = limb_31_804; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (rtlzz_pipe_173_s7 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (rtlzz_pipe_174_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = limb_38_834; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__76_v0 = (rtlzz_pipe_175_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = limb_40_864; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__85_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = limb_51_879; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = limb_53_894; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__117_v0 = (__beopt_width_573 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (rtlzz_pipe_184_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign s8_norm_add_98_v0 = limb_59_904; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_add_101_v0 = limb_61_914; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = limb_67_932; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = limb_69_950; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = limb_76_980; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = limb_78_1010; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__164_v0 = (rtlzz_pipe_48_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = limb_85_1035; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = limb_87_1060; // decl: <none>; prim: <none>
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (rtlzz_pipe_112_s3 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (tmp_workload_top_int_66__243_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign s8_norm_add_152_v0 = limb_95_1070; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__207_v0 = (__beopt_width_606 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_add_155_v0 = limb_97_1080; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (rtlzz_pipe_200_s5 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = limb_103_1098; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = limb_105_1116; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__223_v0 = (rtlzz_pipe_202_s5 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s5 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (__beopt_width_617 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = limb_113_1131; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = limb_115_1146; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__252_v0 = (s8_norm_add_177_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (s8_norm_add_180_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (__beopt_width_627 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign s8_norm_add_195_v0 = limb_121_1156; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_add_198_v0 = limb_123_1166; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = limb_129_1184; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = limb_131_1202; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = limb_138_1232; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = limb_140_1262; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__305_v0 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = limb_147_1316; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = limb_149_1370; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = limb_157_1455; // decl: <none>; prim: <none>
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = limb_216_1535; // decl: <none>; prim: <none>
    assign __beopt_width_294 = limb_217_1615; // decl: <none>; prim: <none>
    assign __beopt_width_295 = limb_218_1660; // decl: <none>; prim: <none>
    assign __beopt_width_297 = limb_219_1705; // decl: <none>; prim: <none>
    assign __beopt_width_299 = limb_220_1745; // decl: <none>; prim: <none>
    assign __beopt_width_301 = limb_221_1785; // decl: <none>; prim: <none>
    assign __beopt_width_302 = limb_222_1825; // decl: <none>; prim: <none>
    assign __beopt_width_303 = limb_223_1865; // decl: <none>; prim: <none>
    assign __beopt_width_305 = limb_224_1890; // decl: <none>; prim: <none>
    assign __beopt_width_307 = limb_225_1915; // decl: <none>; prim: <none>
    assign __beopt_width_309 = limb_226_1940; // decl: <none>; prim: <none>
    assign __beopt_width_310 = limb_227_1965; // decl: <none>; prim: <none>
    assign __beopt_width_311 = limb_228_1990; // decl: <none>; prim: <none>
    assign __beopt_width_313 = limb_229_2015; // decl: <none>; prim: <none>
    assign __beopt_width_315 = limb_230_2040; // decl: <none>; prim: <none>
    assign __beopt_width_317 = limb_231_2065; // decl: <none>; prim: <none>
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (rtlzz_pipe_265_s5 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s6 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (rtlzz_pipe_267_s6 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (__beopt_width_337 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (rtlzz_pipe_269_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s6 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s7 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (__beopt_width_353 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s1 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (rtlzz_pipe_274_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (rtlzz_pipe_276_s7 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (rtlzz_pipe_278_s2 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (rtlzz_pipe_279_s3 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s3 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (__beopt_width_393 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (__beopt_width_396 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (__beopt_width_399 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (rtlzz_pipe_285_s5 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s3 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (rtlzz_pipe_287_s5 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (__beopt_width_417 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s6 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (__beopt_width_423 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s6 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = mul_tree_343_384; // decl: <none>; prim: <none>
    assign arith_original_344 = mul_tree_344_409; // decl: <none>; prim: <none>
    assign arith_original_345 = mul_tree_345_434; // decl: <none>; prim: <none>
    assign arith_original_346 = mul_tree_346_437; // decl: <none>; prim: <none>
    assign arith_original_347 = mul_tree_347_462; // decl: <none>; prim: <none>
    assign arith_original_348 = mul_tree_348_487; // decl: <none>; prim: <none>
    assign arith_original_349 = mul_tree_349_512; // decl: <none>; prim: <none>
    assign arith_original_350 = mul_tree_350_537; // decl: <none>; prim: <none>
    assign arith_original_351 = mul_tree_351_540; // decl: <none>; prim: <none>
    assign arith_original_352 = mul_tree_352_565; // decl: <none>; prim: <none>
    assign arith_original_353 = mul_tree_353_590; // decl: <none>; prim: <none>
    assign arith_original_354 = mul_tree_354_593; // decl: <none>; prim: <none>
    assign arith_original_355 = mul_tree_355_618; // decl: <none>; prim: <none>
    assign arith_original_356 = mul_tree_356_643; // decl: <none>; prim: <none>
    assign arith_original_357 = mul_tree_357_668; // decl: <none>; prim: <none>
    assign arith_original_358 = mul_tree_358_693; // decl: <none>; prim: <none>
    assign arith_original_359 = mul_tree_359_718; // decl: <none>; prim: <none>
    assign mul_tree_343_360 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_361 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_362Core rtlzz_owner_362(.a(32'(mul_tree_343_360)), .b(32'(mul_tree_343_361)), .cin(1'b0), .value(mul_tree_343_362));
    assign mul_tree_343_363 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_364 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_365Core rtlzz_owner_365(.a(32'(mul_tree_343_363)), .b(32'(mul_tree_343_364)), .cin(1'b0), .value(mul_tree_343_365));
    assign mul_tree_343_366 = {mul_tree_343_365, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_367 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_368 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(32'(mul_tree_343_367)), .b(32'(mul_tree_343_368)), .cin(1'b0), .value(mul_tree_343_369));
    assign mul_tree_343_370 = {mul_tree_343_369, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_371 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_372 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_343_371)), .b(32'(mul_tree_343_372)), .cin(1'b0), .value(mul_tree_343_373));
    assign mul_tree_343_374 = {mul_tree_343_373, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_375 = ({33'h0, rtlzz_pipe_362_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_376 = ({1'h0, rtlzz_pipe_366_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_378 = ({33'h0, rtlzz_pipe_370_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_379 = ({1'h0, rtlzz_pipe_374_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_381 = ({33'h0, mul_tree_343_377}); // decl: <none>; prim: <none>
    assign mul_tree_343_382 = ({1'h0, mul_tree_343_380}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_383_reduce rtlzz_reduce_383(.i2139(rtlzz_pipe_362_s5), .i2140(rtlzz_pipe_366_s5), .i2141(rtlzz_pipe_370_s5), .i2142(rtlzz_pipe_374_s5), .y(mul_tree_343_383));
    assign mul_tree_343_384 = mul_tree_343_383[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_385 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_386 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387Core rtlzz_owner_387(.a(32'(mul_tree_344_385)), .b(32'(mul_tree_344_386)), .cin(1'b0), .value(mul_tree_344_387));
    assign mul_tree_344_388 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_389 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_390Core rtlzz_owner_390(.a(32'(mul_tree_344_388)), .b(32'(mul_tree_344_389)), .cin(1'b0), .value(mul_tree_344_390));
    assign mul_tree_344_391 = {mul_tree_344_390, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_392 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_393 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(32'(mul_tree_344_392)), .b(32'(mul_tree_344_393)), .cin(1'b0), .value(mul_tree_344_394));
    assign mul_tree_344_395 = {mul_tree_344_394, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_396 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_397 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_344_396)), .b(32'(mul_tree_344_397)), .cin(1'b0), .value(mul_tree_344_398));
    assign mul_tree_344_399 = {mul_tree_344_398, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_400 = ({33'h0, rtlzz_pipe_387_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_401 = ({1'h0, rtlzz_pipe_391_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_403 = ({33'h0, rtlzz_pipe_395_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_404 = ({1'h0, rtlzz_pipe_399_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_406 = ({33'h0, mul_tree_344_402}); // decl: <none>; prim: <none>
    assign mul_tree_344_407 = ({1'h0, mul_tree_344_405}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_408_reduce rtlzz_reduce_408(.i2146(rtlzz_pipe_387_s4), .i2147(rtlzz_pipe_391_s4), .i2148(rtlzz_pipe_395_s4), .i2149(rtlzz_pipe_399_s4), .y(mul_tree_344_408));
    assign mul_tree_344_409 = mul_tree_344_408[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_410 = rtlzz_pipe_298_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_411 = rtlzz_pipe_299_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412Core rtlzz_owner_412(.a(32'(mul_tree_345_410)), .b(32'(mul_tree_345_411)), .cin(1'b0), .value(mul_tree_345_412));
    assign mul_tree_345_413 = rtlzz_pipe_298_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_414 = rtlzz_pipe_299_s6[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(32'(mul_tree_345_413)), .b(1'(mul_tree_345_414)), .cin(1'b0), .value(mul_tree_345_415));
    assign mul_tree_345_416 = {mul_tree_345_415, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_417 = rtlzz_pipe_298_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_418 = rtlzz_pipe_299_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(1'(mul_tree_345_417)), .b(32'(mul_tree_345_418)), .cin(1'b0), .value(mul_tree_345_419));
    assign mul_tree_345_420 = {mul_tree_345_419, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_421 = rtlzz_pipe_298_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_422 = rtlzz_pipe_299_s6[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(1'(mul_tree_345_421)), .b(1'(mul_tree_345_422)), .cin(1'b0), .value(mul_tree_345_423));
    assign mul_tree_345_424 = {mul_tree_345_423, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_425 = ({2'h0, mul_tree_345_412}); // decl: <none>; prim: <none>
    assign mul_tree_345_426 = ({1'h0, mul_tree_345_416}); // decl: <none>; prim: <none>
    assign mul_tree_345_428 = ({2'h0, mul_tree_345_420}); // decl: <none>; prim: <none>
    assign mul_tree_345_429 = ({1'h0, mul_tree_345_424}); // decl: <none>; prim: <none>
    assign mul_tree_345_431 = ({2'h0, mul_tree_345_427}); // decl: <none>; prim: <none>
    assign mul_tree_345_432 = ({1'h0, mul_tree_345_430}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433_reduce rtlzz_reduce_433(.i412(mul_tree_345_412), .i415(mul_tree_345_415), .i419(mul_tree_345_419), .i423(mul_tree_345_423), .y(mul_tree_345_433));
    assign mul_tree_345_434 = mul_tree_345_433[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_435 = mul_precision_301[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_436 = mul_precision_302[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_437Core rtlzz_owner_437(.a(32'(mul_tree_346_435)), .b(32'(mul_tree_346_436)), .cin(1'b0), .value(mul_tree_346_437));
    assign mul_tree_347_438 = rtlzz_pipe_304_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_439 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_440Core rtlzz_owner_440(.a(32'(mul_tree_347_438)), .b(32'(mul_tree_347_439)), .cin(1'b0), .value(mul_tree_347_440));
    assign mul_tree_347_441 = rtlzz_pipe_304_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_442 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_443Core rtlzz_owner_443(.a(32'(mul_tree_347_441)), .b(2'(mul_tree_347_442)), .cin(1'b0), .value(mul_tree_347_443));
    assign mul_tree_347_444 = {mul_tree_347_443, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_445 = rtlzz_pipe_304_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_446 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_447Core rtlzz_owner_447(.a(2'(mul_tree_347_445)), .b(32'(mul_tree_347_446)), .cin(1'b0), .value(mul_tree_347_447));
    assign mul_tree_347_448 = {mul_tree_347_447, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_449 = rtlzz_pipe_304_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_450 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(2'(mul_tree_347_449)), .b(2'(mul_tree_347_450)), .cin(1'b0), .value(mul_tree_347_451));
    assign mul_tree_347_452 = {mul_tree_347_451, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_453 = ({3'h0, mul_tree_347_440}); // decl: <none>; prim: <none>
    assign mul_tree_347_454 = ({1'h0, mul_tree_347_444}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(64'(mul_tree_347_453)), .b(66'(mul_tree_347_454)), .cin(1'h0), .value(mul_tree_347_455));
    assign mul_tree_347_456 = ({3'h0, mul_tree_347_448}); // decl: <none>; prim: <none>
    assign mul_tree_347_457 = ({1'h0, mul_tree_347_452}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_458Core rtlzz_owner_458(.a(66'(mul_tree_347_456)), .b(68'(mul_tree_347_457)), .cin(1'h0), .value(mul_tree_347_458[67:0]));
    assign mul_tree_347_458[68:68] = '0;
    assign mul_tree_347_459 = ({3'h0, rtlzz_pipe_455_s7}); // decl: <none>; prim: <none>
    assign mul_tree_347_460 = ({1'h0, rtlzz_pipe_458_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_461Core rtlzz_owner_461(.a(67'(mul_tree_347_459)), .b(69'(mul_tree_347_460)), .cin(1'h0), .value(mul_tree_347_461[67:0]));
    assign mul_tree_347_461[69:68] = '0;
    assign mul_tree_347_462 = mul_tree_347_461[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_463 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_464 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_465Core rtlzz_owner_465(.a(32'(mul_tree_348_463)), .b(32'(mul_tree_348_464)), .cin(1'b0), .value(mul_tree_348_465));
    assign mul_tree_348_466 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_467 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_468Core rtlzz_owner_468(.a(32'(mul_tree_348_466)), .b(32'(mul_tree_348_467)), .cin(1'b0), .value(mul_tree_348_468));
    assign mul_tree_348_469 = {mul_tree_348_468, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_470 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_471 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_472Core rtlzz_owner_472(.a(32'(mul_tree_348_470)), .b(32'(mul_tree_348_471)), .cin(1'b0), .value(mul_tree_348_472));
    assign mul_tree_348_473 = {mul_tree_348_472, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_474 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_475 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_348_474)), .b(32'(mul_tree_348_475)), .cin(1'b0), .value(mul_tree_348_476));
    assign mul_tree_348_477 = {mul_tree_348_476, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_478 = ({33'h0, rtlzz_pipe_465_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_479 = ({1'h0, rtlzz_pipe_469_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_481 = ({33'h0, rtlzz_pipe_473_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_482 = ({1'h0, rtlzz_pipe_477_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_484 = ({33'h0, mul_tree_348_480}); // decl: <none>; prim: <none>
    assign mul_tree_348_485 = ({1'h0, mul_tree_348_483}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_486_reduce rtlzz_reduce_486(.i2155(rtlzz_pipe_465_s6), .i2156(rtlzz_pipe_469_s6), .i2157(rtlzz_pipe_473_s6), .i2158(rtlzz_pipe_477_s6), .y(mul_tree_348_486));
    assign mul_tree_348_487 = mul_tree_348_486[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_488 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_489 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_490Core rtlzz_owner_490(.a(32'(mul_tree_349_488)), .b(32'(mul_tree_349_489)), .cin(1'b0), .value(mul_tree_349_490));
    assign mul_tree_349_491 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_492 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_493Core rtlzz_owner_493(.a(32'(mul_tree_349_491)), .b(32'(mul_tree_349_492)), .cin(1'b0), .value(mul_tree_349_493));
    assign mul_tree_349_494 = {mul_tree_349_493, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_495 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_496 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_497Core rtlzz_owner_497(.a(32'(mul_tree_349_495)), .b(32'(mul_tree_349_496)), .cin(1'b0), .value(mul_tree_349_497));
    assign mul_tree_349_498 = {mul_tree_349_497, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_499 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_500 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_349_499)), .b(32'(mul_tree_349_500)), .cin(1'b0), .value(mul_tree_349_501));
    assign mul_tree_349_502 = {mul_tree_349_501, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_503 = ({33'h0, mul_tree_349_490}); // decl: <none>; prim: <none>
    assign mul_tree_349_504 = ({1'h0, mul_tree_349_494}); // decl: <none>; prim: <none>
    assign mul_tree_349_506 = ({33'h0, mul_tree_349_498}); // decl: <none>; prim: <none>
    assign mul_tree_349_507 = ({1'h0, mul_tree_349_502}); // decl: <none>; prim: <none>
    assign mul_tree_349_509 = ({33'h0, mul_tree_349_505}); // decl: <none>; prim: <none>
    assign mul_tree_349_510 = ({1'h0, mul_tree_349_508}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_511_reduce rtlzz_reduce_511(.i490(mul_tree_349_490), .i493(mul_tree_349_493), .i497(mul_tree_349_497), .i501(mul_tree_349_501), .y(mul_tree_349_511));
    assign mul_tree_349_512 = mul_tree_349_511[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_513 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_514 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_515Core rtlzz_owner_515(.a(32'(mul_tree_350_513)), .b(32'(mul_tree_350_514)), .cin(1'b0), .value(mul_tree_350_515));
    assign mul_tree_350_516 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_517 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_518Core rtlzz_owner_518(.a(32'(mul_tree_350_516)), .b(1'(mul_tree_350_517)), .cin(1'b0), .value(mul_tree_350_518));
    assign mul_tree_350_519 = {mul_tree_350_518, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_520 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_521 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_522Core rtlzz_owner_522(.a(1'(mul_tree_350_520)), .b(32'(mul_tree_350_521)), .cin(1'b0), .value(mul_tree_350_522));
    assign mul_tree_350_523 = {mul_tree_350_522, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_524 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_525 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(1'(mul_tree_350_524)), .b(1'(mul_tree_350_525)), .cin(1'b0), .value(mul_tree_350_526));
    assign mul_tree_350_527 = {mul_tree_350_526, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_528 = ({2'h0, mul_tree_350_515}); // decl: <none>; prim: <none>
    assign mul_tree_350_529 = ({1'h0, mul_tree_350_519}); // decl: <none>; prim: <none>
    assign mul_tree_350_531 = ({2'h0, mul_tree_350_523}); // decl: <none>; prim: <none>
    assign mul_tree_350_532 = ({1'h0, mul_tree_350_527}); // decl: <none>; prim: <none>
    assign mul_tree_350_534 = ({2'h0, mul_tree_350_530}); // decl: <none>; prim: <none>
    assign mul_tree_350_535 = ({1'h0, mul_tree_350_533}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_536_reduce rtlzz_reduce_536(.i515(mul_tree_350_515), .i518(mul_tree_350_518), .i522(mul_tree_350_522), .i526(mul_tree_350_526), .y(mul_tree_350_536));
    assign mul_tree_350_537 = mul_tree_350_536[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_538 = mul_precision_316[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_539 = mul_precision_317[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_540Core rtlzz_owner_540(.a(32'(mul_tree_351_538)), .b(32'(mul_tree_351_539)), .cin(1'b0), .value(mul_tree_351_540));
    assign mul_tree_352_541 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_542 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_543Core rtlzz_owner_543(.a(32'(mul_tree_352_541)), .b(32'(mul_tree_352_542)), .cin(1'b0), .value(mul_tree_352_543));
    assign mul_tree_352_544 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_545 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_546Core rtlzz_owner_546(.a(32'(mul_tree_352_544)), .b(2'(mul_tree_352_545)), .cin(1'b0), .value(mul_tree_352_546));
    assign mul_tree_352_547 = {mul_tree_352_546, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_548 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_549 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(2'(mul_tree_352_548)), .b(32'(mul_tree_352_549)), .cin(1'b0), .value(mul_tree_352_550));
    assign mul_tree_352_551 = {mul_tree_352_550, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_552 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_553 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_554Core rtlzz_owner_554(.a(2'(mul_tree_352_552)), .b(2'(mul_tree_352_553)), .cin(1'b0), .value(mul_tree_352_554));
    assign mul_tree_352_555 = {mul_tree_352_554, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_556 = ({3'h0, mul_tree_352_543}); // decl: <none>; prim: <none>
    assign mul_tree_352_557 = ({1'h0, mul_tree_352_547}); // decl: <none>; prim: <none>
    assign mul_tree_352_559 = ({3'h0, mul_tree_352_551}); // decl: <none>; prim: <none>
    assign mul_tree_352_560 = ({1'h0, mul_tree_352_555}); // decl: <none>; prim: <none>
    assign mul_tree_352_562 = ({3'h0, mul_tree_352_558}); // decl: <none>; prim: <none>
    assign mul_tree_352_563 = ({1'h0, mul_tree_352_561}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_564_reduce rtlzz_reduce_564(.i543(mul_tree_352_543), .i546(mul_tree_352_546), .i550(mul_tree_352_550), .i554(mul_tree_352_554), .y(mul_tree_352_564));
    assign mul_tree_352_565 = mul_tree_352_564[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_566 = rtlzz_pipe_322_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_567 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_568Core rtlzz_owner_568(.a(32'(mul_tree_353_566)), .b(32'(mul_tree_353_567)), .cin(1'b0), .value(mul_tree_353_568));
    assign mul_tree_353_569 = rtlzz_pipe_322_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_570 = mul_precision_323[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_571Core rtlzz_owner_571(.a(32'(mul_tree_353_569)), .b(1'(mul_tree_353_570)), .cin(1'b0), .value(mul_tree_353_571));
    assign mul_tree_353_572 = {mul_tree_353_571, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_573 = rtlzz_pipe_322_s4[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_574 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_575Core rtlzz_owner_575(.a(1'(mul_tree_353_573)), .b(32'(mul_tree_353_574)), .cin(1'b0), .value(mul_tree_353_575));
    assign mul_tree_353_576 = {mul_tree_353_575, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_577 = rtlzz_pipe_322_s4[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_578 = mul_precision_323[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_579Core rtlzz_owner_579(.a(1'(mul_tree_353_577)), .b(1'(mul_tree_353_578)), .cin(1'b0), .value(mul_tree_353_579));
    assign mul_tree_353_580 = {mul_tree_353_579, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_581 = ({2'h0, mul_tree_353_568}); // decl: <none>; prim: <none>
    assign mul_tree_353_582 = ({1'h0, mul_tree_353_572}); // decl: <none>; prim: <none>
    assign mul_tree_353_584 = ({2'h0, mul_tree_353_576}); // decl: <none>; prim: <none>
    assign mul_tree_353_585 = ({1'h0, mul_tree_353_580}); // decl: <none>; prim: <none>
    assign mul_tree_353_587 = ({2'h0, mul_tree_353_583}); // decl: <none>; prim: <none>
    assign mul_tree_353_588 = ({1'h0, mul_tree_353_586}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589_reduce rtlzz_reduce_589(.i568(mul_tree_353_568), .i571(mul_tree_353_571), .i575(mul_tree_353_575), .i579(mul_tree_353_579), .y(mul_tree_353_589));
    assign mul_tree_353_590 = mul_tree_353_589[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_591 = rtlzz_pipe_325_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_592 = mul_precision_326[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_593Core rtlzz_owner_593(.a(32'(mul_tree_354_591)), .b(32'(mul_tree_354_592)), .cin(1'b0), .value(mul_tree_354_593));
    assign mul_tree_355_594 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_595 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_596Core rtlzz_owner_596(.a(32'(mul_tree_355_594)), .b(32'(mul_tree_355_595)), .cin(1'b0), .value(mul_tree_355_596));
    assign mul_tree_355_597 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_598 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_599Core rtlzz_owner_599(.a(32'(mul_tree_355_597)), .b(2'(mul_tree_355_598)), .cin(1'b0), .value(mul_tree_355_599));
    assign mul_tree_355_600 = {mul_tree_355_599, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_601 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_602 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_603Core rtlzz_owner_603(.a(2'(mul_tree_355_601)), .b(32'(mul_tree_355_602)), .cin(1'b0), .value(mul_tree_355_603));
    assign mul_tree_355_604 = {mul_tree_355_603, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_605 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_606 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_607Core rtlzz_owner_607(.a(2'(mul_tree_355_605)), .b(2'(mul_tree_355_606)), .cin(1'b0), .value(mul_tree_355_607));
    assign mul_tree_355_608 = {mul_tree_355_607, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_609 = ({3'h0, mul_tree_355_596}); // decl: <none>; prim: <none>
    assign mul_tree_355_610 = ({1'h0, mul_tree_355_600}); // decl: <none>; prim: <none>
    assign mul_tree_355_612 = ({3'h0, mul_tree_355_604}); // decl: <none>; prim: <none>
    assign mul_tree_355_613 = ({1'h0, mul_tree_355_608}); // decl: <none>; prim: <none>
    assign mul_tree_355_615 = ({3'h0, mul_tree_355_611}); // decl: <none>; prim: <none>
    assign mul_tree_355_616 = ({1'h0, mul_tree_355_614}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_617_reduce rtlzz_reduce_617(.i596(mul_tree_355_596), .i599(mul_tree_355_599), .i603(mul_tree_355_603), .i607(mul_tree_355_607), .y(mul_tree_355_617));
    assign mul_tree_355_618 = mul_tree_355_617[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_619 = rtlzz_pipe_331_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_620 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_621Core rtlzz_owner_621(.a(32'(mul_tree_356_619)), .b(32'(mul_tree_356_620)), .cin(1'b0), .value(mul_tree_356_621));
    assign mul_tree_356_622 = rtlzz_pipe_331_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_623 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_624Core rtlzz_owner_624(.a(32'(mul_tree_356_622)), .b(32'(mul_tree_356_623)), .cin(1'b0), .value(mul_tree_356_624));
    assign mul_tree_356_625 = {mul_tree_356_624, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_626 = rtlzz_pipe_331_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_627 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_628Core rtlzz_owner_628(.a(32'(mul_tree_356_626)), .b(32'(mul_tree_356_627)), .cin(1'b0), .value(mul_tree_356_628));
    assign mul_tree_356_629 = {mul_tree_356_628, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_630 = rtlzz_pipe_331_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_631 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_632Core rtlzz_owner_632(.a(32'(mul_tree_356_630)), .b(32'(mul_tree_356_631)), .cin(1'b0), .value(mul_tree_356_632));
    assign mul_tree_356_633 = {mul_tree_356_632, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_634 = ({33'h0, mul_tree_356_621}); // decl: <none>; prim: <none>
    assign mul_tree_356_635 = ({1'h0, mul_tree_356_625}); // decl: <none>; prim: <none>
    assign mul_tree_356_637 = ({33'h0, mul_tree_356_629}); // decl: <none>; prim: <none>
    assign mul_tree_356_638 = ({1'h0, mul_tree_356_633}); // decl: <none>; prim: <none>
    assign mul_tree_356_640 = ({33'h0, mul_tree_356_636}); // decl: <none>; prim: <none>
    assign mul_tree_356_641 = ({1'h0, mul_tree_356_639}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_642_reduce rtlzz_reduce_642(.i621(mul_tree_356_621), .i624(mul_tree_356_624), .i628(mul_tree_356_628), .i632(mul_tree_356_632), .y(mul_tree_356_642));
    assign mul_tree_356_643 = mul_tree_356_642[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_644 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_645 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_646Core rtlzz_owner_646(.a(32'(mul_tree_357_644)), .b(32'(mul_tree_357_645)), .cin(1'b0), .value(mul_tree_357_646));
    assign mul_tree_357_647 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_648 = mul_precision_335[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_649Core rtlzz_owner_649(.a(32'(mul_tree_357_647)), .b(1'(mul_tree_357_648)), .cin(1'b0), .value(mul_tree_357_649));
    assign mul_tree_357_650 = {mul_tree_357_649, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_651 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_652 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_653Core rtlzz_owner_653(.a(1'(mul_tree_357_651)), .b(32'(mul_tree_357_652)), .cin(1'b0), .value(mul_tree_357_653));
    assign mul_tree_357_654 = {mul_tree_357_653, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_655 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_656 = mul_precision_335[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_657Core rtlzz_owner_657(.a(1'(mul_tree_357_655)), .b(1'(mul_tree_357_656)), .cin(1'b0), .value(mul_tree_357_657));
    assign mul_tree_357_658 = {mul_tree_357_657, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_659 = ({2'h0, mul_tree_357_646}); // decl: <none>; prim: <none>
    assign mul_tree_357_660 = ({1'h0, mul_tree_357_650}); // decl: <none>; prim: <none>
    assign mul_tree_357_662 = ({2'h0, mul_tree_357_654}); // decl: <none>; prim: <none>
    assign mul_tree_357_663 = ({1'h0, mul_tree_357_658}); // decl: <none>; prim: <none>
    assign mul_tree_357_665 = ({2'h0, mul_tree_357_661}); // decl: <none>; prim: <none>
    assign mul_tree_357_666 = ({1'h0, mul_tree_357_664}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_667_reduce rtlzz_reduce_667(.i646(mul_tree_357_646), .i649(mul_tree_357_649), .i653(mul_tree_357_653), .i657(mul_tree_357_657), .y(mul_tree_357_667));
    assign mul_tree_357_668 = mul_tree_357_667[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_669 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_670 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_671Core rtlzz_owner_671(.a(32'(mul_tree_358_669)), .b(32'(mul_tree_358_670)), .cin(1'b0), .value(mul_tree_358_671));
    assign mul_tree_358_672 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_673 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_674Core rtlzz_owner_674(.a(32'(mul_tree_358_672)), .b(1'(mul_tree_358_673)), .cin(1'b0), .value(mul_tree_358_674));
    assign mul_tree_358_675 = {mul_tree_358_674, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_676 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_677 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_678Core rtlzz_owner_678(.a(1'(mul_tree_358_676)), .b(32'(mul_tree_358_677)), .cin(1'b0), .value(mul_tree_358_678));
    assign mul_tree_358_679 = {mul_tree_358_678, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_680 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_681 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_682Core rtlzz_owner_682(.a(1'(mul_tree_358_680)), .b(1'(mul_tree_358_681)), .cin(1'b0), .value(mul_tree_358_682));
    assign mul_tree_358_683 = {mul_tree_358_682, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_684 = ({2'h0, mul_tree_358_671}); // decl: <none>; prim: <none>
    assign mul_tree_358_685 = ({1'h0, mul_tree_358_675}); // decl: <none>; prim: <none>
    assign mul_tree_358_687 = ({2'h0, mul_tree_358_679}); // decl: <none>; prim: <none>
    assign mul_tree_358_688 = ({1'h0, mul_tree_358_683}); // decl: <none>; prim: <none>
    assign mul_tree_358_690 = ({2'h0, mul_tree_358_686}); // decl: <none>; prim: <none>
    assign mul_tree_358_691 = ({1'h0, mul_tree_358_689}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_692_reduce rtlzz_reduce_692(.i671(mul_tree_358_671), .i674(mul_tree_358_674), .i678(mul_tree_358_678), .i682(mul_tree_358_682), .y(mul_tree_358_692));
    assign mul_tree_358_693 = mul_tree_358_692[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_694 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_695 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_696Core rtlzz_owner_696(.a(32'(mul_tree_359_694)), .b(32'(mul_tree_359_695)), .cin(1'b0), .value(mul_tree_359_696));
    assign mul_tree_359_697 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_698 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_699Core rtlzz_owner_699(.a(32'(mul_tree_359_697)), .b(2'(mul_tree_359_698)), .cin(1'b0), .value(mul_tree_359_699));
    assign mul_tree_359_700 = {mul_tree_359_699, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_701 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_702 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_703Core rtlzz_owner_703(.a(2'(mul_tree_359_701)), .b(32'(mul_tree_359_702)), .cin(1'b0), .value(mul_tree_359_703));
    assign mul_tree_359_704 = {mul_tree_359_703, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_705 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_706 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_707Core rtlzz_owner_707(.a(2'(mul_tree_359_705)), .b(2'(mul_tree_359_706)), .cin(1'b0), .value(mul_tree_359_707));
    assign mul_tree_359_708 = {mul_tree_359_707, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_709 = ({3'h0, mul_tree_359_696}); // decl: <none>; prim: <none>
    assign mul_tree_359_710 = ({1'h0, mul_tree_359_700}); // decl: <none>; prim: <none>
    assign mul_tree_359_712 = ({3'h0, mul_tree_359_704}); // decl: <none>; prim: <none>
    assign mul_tree_359_713 = ({1'h0, mul_tree_359_708}); // decl: <none>; prim: <none>
    assign mul_tree_359_715 = ({3'h0, mul_tree_359_711}); // decl: <none>; prim: <none>
    assign mul_tree_359_716 = ({1'h0, mul_tree_359_714}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_717_reduce rtlzz_reduce_717(.i696(mul_tree_359_696), .i699(mul_tree_359_699), .i703(mul_tree_359_703), .i707(mul_tree_359_707), .y(mul_tree_359_717));
    assign mul_tree_359_718 = mul_tree_359_717[67:0]; // decl: <none>; prim: <none>
    assign limb_13_719 = tmp_workload_top_int_65__18_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_13_720 = __beopt_width_312[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_721Core rtlzz_owner_721(.a(32'(rtlzz_pipe_719_s4)), .b(32'(limb_13_720)), .cin(1'h0), .value(limb_13_721));
    assign limb_13_722 = limb_13_721[31:0]; // decl: <none>; prim: <none>
    assign limb_13_723 = limb_13_721[32]; // decl: <none>; prim: <none>
    assign limb_13_724 = tmp_workload_top_int_65__18_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_13_725 = __beopt_width_312[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_726Core rtlzz_owner_726(.a(32'(rtlzz_pipe_724_s4)), .b(32'(limb_13_725)), .cin(limb_13_723), .value(limb_13_726));
    assign limb_13_727 = limb_13_726[31:0]; // decl: <none>; prim: <none>
    assign limb_13_728 = limb_13_726[32]; // decl: <none>; prim: <none>
    assign limb_13_729 = tmp_workload_top_int_65__18_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_730 = __beopt_width_312[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_731Core rtlzz_owner_731(.a(1'(rtlzz_pipe_729_s4)), .b(1'(limb_13_730)), .cin(limb_13_728), .value(limb_13_731[0:0]));
    assign limb_13_731[1:1] = '0;
    assign limb_13_732 = limb_13_731[0]; // decl: <none>; prim: <none>
    assign limb_13_733 = {limb_13_732, limb_13_727, limb_13_722}; // decl: <none>; prim: <none>
    assign limb_15_734 = tmp_workload_top_int_65__23_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_15_735 = __beopt_width_318[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_736Core rtlzz_owner_736(.a(32'(rtlzz_pipe_734_s5)), .b(32'(limb_15_735)), .cin(1'h0), .value(limb_15_736));
    assign limb_15_737 = limb_15_736[31:0]; // decl: <none>; prim: <none>
    assign limb_15_738 = limb_15_736[32]; // decl: <none>; prim: <none>
    assign limb_15_739 = tmp_workload_top_int_65__23_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_15_740 = __beopt_width_318[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_741Core rtlzz_owner_741(.a(32'(rtlzz_pipe_739_s5)), .b(32'(limb_15_740)), .cin(limb_15_738), .value(limb_15_741));
    assign limb_15_742 = limb_15_741[31:0]; // decl: <none>; prim: <none>
    assign limb_15_743 = limb_15_741[32]; // decl: <none>; prim: <none>
    assign limb_15_744 = tmp_workload_top_int_65__23_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_745 = __beopt_width_318[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_746Core rtlzz_owner_746(.a(1'(rtlzz_pipe_744_s5)), .b(1'(limb_15_745)), .cin(limb_15_743), .value(limb_15_746[0:0]));
    assign limb_15_746[1:1] = '0;
    assign limb_15_747 = limb_15_746[0]; // decl: <none>; prim: <none>
    assign limb_15_748 = {limb_15_747, limb_15_742, limb_15_737}; // decl: <none>; prim: <none>
    assign limb_21_749 = tmp_workload_top_int_34__42_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_21_750 = __beopt_width_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_751Core rtlzz_owner_751(.a(32'(limb_21_749)), .b(32'(rtlzz_pipe_750_s5)), .cin(1'h0), .value(limb_21_751));
    assign limb_21_752 = limb_21_751[31:0]; // decl: <none>; prim: <none>
    assign limb_21_753 = limb_21_751[32]; // decl: <none>; prim: <none>
    assign limb_21_754 = tmp_workload_top_int_34__42_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_21_755 = __beopt_width_332[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_756Core rtlzz_owner_756(.a(2'(limb_21_754)), .b(2'(rtlzz_pipe_755_s5)), .cin(limb_21_753), .value(limb_21_756[1:0]));
    assign limb_21_756[2:2] = '0;
    assign limb_21_757 = limb_21_756[1:0]; // decl: <none>; prim: <none>
    assign limb_21_758 = {limb_21_757, limb_21_752}; // decl: <none>; prim: <none>
    assign limb_23_759 = tmp_workload_top_int_34__47_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_23_760 = __beopt_width_336[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_761Core rtlzz_owner_761(.a(32'(rtlzz_pipe_759_s6)), .b(32'(limb_23_760)), .cin(1'h0), .value(limb_23_761));
    assign limb_23_762 = limb_23_761[31:0]; // decl: <none>; prim: <none>
    assign limb_23_763 = limb_23_761[32]; // decl: <none>; prim: <none>
    assign limb_23_764 = tmp_workload_top_int_34__47_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_23_765 = __beopt_width_336[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_766Core rtlzz_owner_766(.a(2'(rtlzz_pipe_764_s6)), .b(2'(limb_23_765)), .cin(limb_23_763), .value(limb_23_766[1:0]));
    assign limb_23_766[2:2] = '0;
    assign limb_23_767 = limb_23_766[1:0]; // decl: <none>; prim: <none>
    assign limb_23_768 = {limb_23_767, limb_23_762}; // decl: <none>; prim: <none>
    assign limb_29_769 = n20_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_29_770 = tmp_workload_top_int_68__57_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_29_771 = (~limb_29_770); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_772Core rtlzz_owner_772(.a(32'(limb_29_769)), .b(32'(limb_29_771)), .cin(1'h1), .value(limb_29_772));
    assign limb_29_773 = limb_29_772[31:0]; // decl: <none>; prim: <none>
    assign limb_29_774 = limb_29_772[32]; // decl: <none>; prim: <none>
    assign limb_29_775 = n20_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_29_776 = tmp_workload_top_int_68__57_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_29_777 = (~limb_29_776); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_778Core rtlzz_owner_778(.a(32'(limb_29_775)), .b(32'(limb_29_777)), .cin(limb_29_774), .value(limb_29_778));
    assign limb_29_779 = limb_29_778[31:0]; // decl: <none>; prim: <none>
    assign limb_29_780 = limb_29_778[32]; // decl: <none>; prim: <none>
    assign limb_29_781 = n20_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_782 = tmp_workload_top_int_68__57_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_783 = (~limb_29_782); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_784Core rtlzz_owner_784(.a(4'(limb_29_781)), .b(4'(limb_29_783)), .cin(limb_29_780), .value(limb_29_784[3:0]));
    assign limb_29_784[4:4] = '0;
    assign limb_29_785 = limb_29_784[3:0]; // decl: <none>; prim: <none>
    assign limb_29_786 = {limb_29_785, limb_29_779, limb_29_773}; // decl: <none>; prim: <none>
    assign limb_31_787 = s8_norm_sub_45_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_31_788 = tmp_workload_top_int_68__60_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_31_789 = (~limb_31_788); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_790Core rtlzz_owner_790(.a(32'(limb_31_787)), .b(32'(rtlzz_pipe_789_s7)), .cin(1'h1), .value(limb_31_790));
    assign limb_31_791 = limb_31_790[31:0]; // decl: <none>; prim: <none>
    assign limb_31_792 = limb_31_790[32]; // decl: <none>; prim: <none>
    assign limb_31_793 = s8_norm_sub_45_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_31_794 = tmp_workload_top_int_68__60_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_31_795 = (~limb_31_794); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_796Core rtlzz_owner_796(.a(32'(limb_31_793)), .b(32'(rtlzz_pipe_795_s7)), .cin(limb_31_792), .value(limb_31_796));
    assign limb_31_797 = limb_31_796[31:0]; // decl: <none>; prim: <none>
    assign limb_31_798 = limb_31_796[32]; // decl: <none>; prim: <none>
    assign limb_31_799 = s8_norm_sub_45_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_800 = tmp_workload_top_int_68__60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_801 = (~limb_31_800); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_802Core rtlzz_owner_802(.a(4'(limb_31_799)), .b(4'(rtlzz_pipe_801_s7)), .cin(limb_31_798), .value(limb_31_802[3:0]));
    assign limb_31_802[4:4] = '0;
    assign limb_31_803 = limb_31_802[3:0]; // decl: <none>; prim: <none>
    assign limb_31_804 = {limb_31_803, limb_31_797, limb_31_791}; // decl: <none>; prim: <none>
    assign limb_38_805 = __beopt_width_317[31:0]; // decl: <none>; prim: <none>
    assign limb_38_806 = tmp_workload_top_int_130__73_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_38_807 = (~limb_38_806); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_808Core rtlzz_owner_808(.a(32'(limb_38_805)), .b(32'(rtlzz_pipe_807_s7)), .cin(1'h1), .value(limb_38_808));
    assign limb_38_809 = limb_38_808[31:0]; // decl: <none>; prim: <none>
    assign limb_38_810 = limb_38_808[32]; // decl: <none>; prim: <none>
    assign limb_38_811 = __beopt_width_317[63:32]; // decl: <none>; prim: <none>
    assign limb_38_812 = tmp_workload_top_int_130__73_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_38_813 = (~limb_38_812); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_814Core rtlzz_owner_814(.a(32'(limb_38_811)), .b(32'(rtlzz_pipe_813_s7)), .cin(limb_38_810), .value(limb_38_814));
    assign limb_38_815 = limb_38_814[31:0]; // decl: <none>; prim: <none>
    assign limb_38_816 = limb_38_814[32]; // decl: <none>; prim: <none>
    assign limb_38_817 = __beopt_width_317[95:64]; // decl: <none>; prim: <none>
    assign limb_38_818 = tmp_workload_top_int_130__73_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_38_819 = (~limb_38_818); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_820Core rtlzz_owner_820(.a(32'(limb_38_817)), .b(32'(rtlzz_pipe_819_s7)), .cin(limb_38_816), .value(limb_38_820));
    assign limb_38_821 = limb_38_820[31:0]; // decl: <none>; prim: <none>
    assign limb_38_822 = limb_38_820[32]; // decl: <none>; prim: <none>
    assign limb_38_823 = __beopt_width_317[127:96]; // decl: <none>; prim: <none>
    assign limb_38_824 = tmp_workload_top_int_130__73_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_38_825 = (~limb_38_824); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_826Core rtlzz_owner_826(.a(32'(limb_38_823)), .b(32'(rtlzz_pipe_825_s7)), .cin(limb_38_822), .value(limb_38_826));
    assign limb_38_827 = limb_38_826[31:0]; // decl: <none>; prim: <none>
    assign limb_38_828 = limb_38_826[32]; // decl: <none>; prim: <none>
    assign limb_38_829 = __beopt_width_317[129:128]; // decl: <none>; prim: <none>
    assign limb_38_830 = tmp_workload_top_int_130__73_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_38_831 = (~limb_38_830); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_832Core rtlzz_owner_832(.a(2'(limb_38_829)), .b(2'(rtlzz_pipe_831_s7)), .cin(limb_38_828), .value(limb_38_832[1:0]));
    assign limb_38_832[2:2] = '0;
    assign limb_38_833 = limb_38_832[1:0]; // decl: <none>; prim: <none>
    assign limb_38_834 = {limb_38_833, limb_38_827, limb_38_821, limb_38_815, limb_38_809}; // decl: <none>; prim: <none>
    assign limb_40_835 = s8_norm_sub_56_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_40_836 = tmp_workload_top_int_130__76_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_40_837 = (~limb_40_836); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_838Core rtlzz_owner_838(.a(32'(limb_40_835)), .b(32'(rtlzz_pipe_837_s7)), .cin(1'h1), .value(limb_40_838));
    assign limb_40_839 = limb_40_838[31:0]; // decl: <none>; prim: <none>
    assign limb_40_840 = limb_40_838[32]; // decl: <none>; prim: <none>
    assign limb_40_841 = s8_norm_sub_56_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_40_842 = tmp_workload_top_int_130__76_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_40_843 = (~rtlzz_pipe_842_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_844Core rtlzz_owner_844(.a(32'(limb_40_841)), .b(32'(limb_40_843)), .cin(limb_40_840), .value(limb_40_844));
    assign limb_40_845 = limb_40_844[31:0]; // decl: <none>; prim: <none>
    assign limb_40_846 = limb_40_844[32]; // decl: <none>; prim: <none>
    assign limb_40_847 = s8_norm_sub_56_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_40_848 = tmp_workload_top_int_130__76_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_40_849 = (~limb_40_848); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_850Core rtlzz_owner_850(.a(32'(limb_40_847)), .b(32'(rtlzz_pipe_849_s7)), .cin(limb_40_846), .value(limb_40_850));
    assign limb_40_851 = limb_40_850[31:0]; // decl: <none>; prim: <none>
    assign limb_40_852 = limb_40_850[32]; // decl: <none>; prim: <none>
    assign limb_40_853 = s8_norm_sub_56_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_40_854 = tmp_workload_top_int_130__76_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_40_855 = (~rtlzz_pipe_854_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_856Core rtlzz_owner_856(.a(32'(limb_40_853)), .b(32'(limb_40_855)), .cin(limb_40_852), .value(limb_40_856));
    assign limb_40_857 = limb_40_856[31:0]; // decl: <none>; prim: <none>
    assign limb_40_858 = limb_40_856[32]; // decl: <none>; prim: <none>
    assign limb_40_859 = s8_norm_sub_56_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_860 = tmp_workload_top_int_130__76_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_861 = (~rtlzz_pipe_860_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_862Core rtlzz_owner_862(.a(2'(limb_40_859)), .b(2'(limb_40_861)), .cin(limb_40_858), .value(limb_40_862[1:0]));
    assign limb_40_862[2:2] = '0;
    assign limb_40_863 = limb_40_862[1:0]; // decl: <none>; prim: <none>
    assign limb_40_864 = {limb_40_863, limb_40_857, limb_40_851, limb_40_845, limb_40_839}; // decl: <none>; prim: <none>
    assign limb_51_865 = tmp_workload_top_int_65__103_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_51_866 = __beopt_width_352[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_867Core rtlzz_owner_867(.a(32'(limb_51_865)), .b(32'(rtlzz_pipe_866_s6)), .cin(1'h0), .value(limb_51_867));
    assign limb_51_868 = limb_51_867[31:0]; // decl: <none>; prim: <none>
    assign limb_51_869 = limb_51_867[32]; // decl: <none>; prim: <none>
    assign limb_51_870 = tmp_workload_top_int_65__103_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_51_871 = __beopt_width_352[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_872Core rtlzz_owner_872(.a(32'(limb_51_870)), .b(32'(rtlzz_pipe_871_s6)), .cin(limb_51_869), .value(limb_51_872));
    assign limb_51_873 = limb_51_872[31:0]; // decl: <none>; prim: <none>
    assign limb_51_874 = limb_51_872[32]; // decl: <none>; prim: <none>
    assign limb_51_875 = tmp_workload_top_int_65__103_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_876 = __beopt_width_352[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_877Core rtlzz_owner_877(.a(1'(limb_51_875)), .b(1'(rtlzz_pipe_876_s6)), .cin(limb_51_874), .value(limb_51_877[0:0]));
    assign limb_51_877[1:1] = '0;
    assign limb_51_878 = limb_51_877[0]; // decl: <none>; prim: <none>
    assign limb_51_879 = {limb_51_878, limb_51_873, limb_51_868}; // decl: <none>; prim: <none>
    assign limb_53_880 = tmp_workload_top_int_65__108_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_53_881 = __beopt_width_357[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_882Core rtlzz_owner_882(.a(32'(limb_53_880)), .b(32'(rtlzz_pipe_881_s7)), .cin(1'h0), .value(limb_53_882));
    assign limb_53_883 = limb_53_882[31:0]; // decl: <none>; prim: <none>
    assign limb_53_884 = limb_53_882[32]; // decl: <none>; prim: <none>
    assign limb_53_885 = tmp_workload_top_int_65__108_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_53_886 = __beopt_width_357[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_887Core rtlzz_owner_887(.a(32'(limb_53_885)), .b(32'(rtlzz_pipe_886_s7)), .cin(limb_53_884), .value(limb_53_887));
    assign limb_53_888 = limb_53_887[31:0]; // decl: <none>; prim: <none>
    assign limb_53_889 = limb_53_887[32]; // decl: <none>; prim: <none>
    assign limb_53_890 = tmp_workload_top_int_65__108_v0[64]; // decl: <none>; prim: <none>
    assign limb_53_891 = __beopt_width_357[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_892Core rtlzz_owner_892(.a(1'(limb_53_890)), .b(1'(rtlzz_pipe_891_s7)), .cin(limb_53_889), .value(limb_53_892[0:0]));
    assign limb_53_892[1:1] = '0;
    assign limb_53_893 = limb_53_892[0]; // decl: <none>; prim: <none>
    assign limb_53_894 = {limb_53_893, limb_53_888, limb_53_883}; // decl: <none>; prim: <none>
    assign limb_59_895 = tmp_workload_top_int_34__127_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_59_896 = __beopt_width_367[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_897Core rtlzz_owner_897(.a(32'(limb_59_895)), .b(32'(limb_59_896)), .cin(1'h0), .value(limb_59_897));
    assign limb_59_898 = limb_59_897[31:0]; // decl: <none>; prim: <none>
    assign limb_59_899 = limb_59_897[32]; // decl: <none>; prim: <none>
    assign limb_59_900 = tmp_workload_top_int_34__127_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_59_901 = __beopt_width_367[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_902Core rtlzz_owner_902(.a(2'(limb_59_900)), .b(2'(limb_59_901)), .cin(limb_59_899), .value(limb_59_902[1:0]));
    assign limb_59_902[2:2] = '0;
    assign limb_59_903 = limb_59_902[1:0]; // decl: <none>; prim: <none>
    assign limb_59_904 = {limb_59_903, limb_59_898}; // decl: <none>; prim: <none>
    assign limb_61_905 = tmp_workload_top_int_34__132_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_61_906 = __beopt_width_370[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_907Core rtlzz_owner_907(.a(32'(limb_61_905)), .b(32'(limb_61_906)), .cin(1'h0), .value(limb_61_907));
    assign limb_61_908 = limb_61_907[31:0]; // decl: <none>; prim: <none>
    assign limb_61_909 = limb_61_907[32]; // decl: <none>; prim: <none>
    assign limb_61_910 = tmp_workload_top_int_34__132_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_61_911 = __beopt_width_370[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_912Core rtlzz_owner_912(.a(2'(limb_61_910)), .b(2'(limb_61_911)), .cin(limb_61_909), .value(limb_61_912[1:0]));
    assign limb_61_912[2:2] = '0;
    assign limb_61_913 = limb_61_912[1:0]; // decl: <none>; prim: <none>
    assign limb_61_914 = {limb_61_913, limb_61_908}; // decl: <none>; prim: <none>
    assign limb_67_915 = n41_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_67_916 = tmp_workload_top_int_68__142_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_67_917 = (~limb_67_916); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_918Core rtlzz_owner_918(.a(32'(limb_67_915)), .b(32'(limb_67_917)), .cin(1'h1), .value(limb_67_918));
    assign limb_67_919 = limb_67_918[31:0]; // decl: <none>; prim: <none>
    assign limb_67_920 = limb_67_918[32]; // decl: <none>; prim: <none>
    assign limb_67_921 = n41_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_67_922 = tmp_workload_top_int_68__142_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_67_923 = (~limb_67_922); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_924Core rtlzz_owner_924(.a(32'(limb_67_921)), .b(32'(limb_67_923)), .cin(limb_67_920), .value(limb_67_924));
    assign limb_67_925 = limb_67_924[31:0]; // decl: <none>; prim: <none>
    assign limb_67_926 = limb_67_924[32]; // decl: <none>; prim: <none>
    assign limb_67_927 = n41_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_928 = tmp_workload_top_int_68__142_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_929 = (~limb_67_928); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_930Core rtlzz_owner_930(.a(4'(limb_67_927)), .b(4'(limb_67_929)), .cin(limb_67_926), .value(limb_67_930[3:0]));
    assign limb_67_930[4:4] = '0;
    assign limb_67_931 = limb_67_930[3:0]; // decl: <none>; prim: <none>
    assign limb_67_932 = {limb_67_931, limb_67_925, limb_67_919}; // decl: <none>; prim: <none>
    assign limb_69_933 = s8_norm_sub_107_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_69_934 = tmp_workload_top_int_68__145_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_69_935 = (~limb_69_934); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_936Core rtlzz_owner_936(.a(32'(limb_69_933)), .b(32'(limb_69_935)), .cin(1'h1), .value(limb_69_936));
    assign limb_69_937 = limb_69_936[31:0]; // decl: <none>; prim: <none>
    assign limb_69_938 = limb_69_936[32]; // decl: <none>; prim: <none>
    assign limb_69_939 = s8_norm_sub_107_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_69_940 = tmp_workload_top_int_68__145_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_69_941 = (~limb_69_940); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_942Core rtlzz_owner_942(.a(32'(limb_69_939)), .b(32'(limb_69_941)), .cin(limb_69_938), .value(limb_69_942));
    assign limb_69_943 = limb_69_942[31:0]; // decl: <none>; prim: <none>
    assign limb_69_944 = limb_69_942[32]; // decl: <none>; prim: <none>
    assign limb_69_945 = s8_norm_sub_107_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_946 = tmp_workload_top_int_68__145_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_947 = (~limb_69_946); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_948Core rtlzz_owner_948(.a(4'(limb_69_945)), .b(4'(limb_69_947)), .cin(limb_69_944), .value(limb_69_948[3:0]));
    assign limb_69_948[4:4] = '0;
    assign limb_69_949 = limb_69_948[3:0]; // decl: <none>; prim: <none>
    assign limb_69_950 = {limb_69_949, limb_69_943, limb_69_937}; // decl: <none>; prim: <none>
    assign limb_76_951 = __beopt_width_313[31:0]; // decl: <none>; prim: <none>
    assign limb_76_952 = tmp_workload_top_int_130__158_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_76_953 = (~limb_76_952); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_954Core rtlzz_owner_954(.a(32'(limb_76_951)), .b(32'(rtlzz_pipe_953_s7)), .cin(1'h1), .value(limb_76_954));
    assign limb_76_955 = limb_76_954[31:0]; // decl: <none>; prim: <none>
    assign limb_76_956 = limb_76_954[32]; // decl: <none>; prim: <none>
    assign limb_76_957 = __beopt_width_313[63:32]; // decl: <none>; prim: <none>
    assign limb_76_958 = tmp_workload_top_int_130__158_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_76_959 = (~limb_76_958); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_960Core rtlzz_owner_960(.a(32'(limb_76_957)), .b(32'(rtlzz_pipe_959_s7)), .cin(limb_76_956), .value(limb_76_960));
    assign limb_76_961 = limb_76_960[31:0]; // decl: <none>; prim: <none>
    assign limb_76_962 = limb_76_960[32]; // decl: <none>; prim: <none>
    assign limb_76_963 = __beopt_width_313[95:64]; // decl: <none>; prim: <none>
    assign limb_76_964 = tmp_workload_top_int_130__158_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_76_965 = (~limb_76_964); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_966Core rtlzz_owner_966(.a(32'(limb_76_963)), .b(32'(rtlzz_pipe_965_s7)), .cin(limb_76_962), .value(limb_76_966));
    assign limb_76_967 = limb_76_966[31:0]; // decl: <none>; prim: <none>
    assign limb_76_968 = limb_76_966[32]; // decl: <none>; prim: <none>
    assign limb_76_969 = __beopt_width_313[127:96]; // decl: <none>; prim: <none>
    assign limb_76_970 = tmp_workload_top_int_130__158_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_76_971 = (~limb_76_970); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_972Core rtlzz_owner_972(.a(32'(limb_76_969)), .b(32'(rtlzz_pipe_971_s7)), .cin(limb_76_968), .value(limb_76_972));
    assign limb_76_973 = limb_76_972[31:0]; // decl: <none>; prim: <none>
    assign limb_76_974 = limb_76_972[32]; // decl: <none>; prim: <none>
    assign limb_76_975 = __beopt_width_313[129:128]; // decl: <none>; prim: <none>
    assign limb_76_976 = tmp_workload_top_int_130__158_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_76_977 = (~limb_76_976); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_978Core rtlzz_owner_978(.a(2'(limb_76_975)), .b(2'(rtlzz_pipe_977_s7)), .cin(limb_76_974), .value(limb_76_978[1:0]));
    assign limb_76_978[2:2] = '0;
    assign limb_76_979 = limb_76_978[1:0]; // decl: <none>; prim: <none>
    assign limb_76_980 = {limb_76_979, limb_76_973, limb_76_967, limb_76_961, limb_76_955}; // decl: <none>; prim: <none>
    assign limb_78_981 = s8_norm_sub_118_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_78_982 = tmp_workload_top_int_130__161_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_78_983 = (~limb_78_982); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_984Core rtlzz_owner_984(.a(32'(limb_78_981)), .b(32'(limb_78_983)), .cin(1'h1), .value(limb_78_984));
    assign limb_78_985 = limb_78_984[31:0]; // decl: <none>; prim: <none>
    assign limb_78_986 = limb_78_984[32]; // decl: <none>; prim: <none>
    assign limb_78_987 = s8_norm_sub_118_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_78_988 = tmp_workload_top_int_130__161_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_78_989 = (~limb_78_988); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_990Core rtlzz_owner_990(.a(32'(limb_78_987)), .b(32'(limb_78_989)), .cin(limb_78_986), .value(limb_78_990));
    assign limb_78_991 = limb_78_990[31:0]; // decl: <none>; prim: <none>
    assign limb_78_992 = limb_78_990[32]; // decl: <none>; prim: <none>
    assign limb_78_993 = s8_norm_sub_118_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_78_994 = tmp_workload_top_int_130__161_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_78_995 = (~limb_78_994); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_996Core rtlzz_owner_996(.a(32'(limb_78_993)), .b(32'(limb_78_995)), .cin(limb_78_992), .value(limb_78_996));
    assign limb_78_997 = limb_78_996[31:0]; // decl: <none>; prim: <none>
    assign limb_78_998 = limb_78_996[32]; // decl: <none>; prim: <none>
    assign limb_78_999 = s8_norm_sub_118_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_78_1000 = tmp_workload_top_int_130__161_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_78_1001 = (~limb_78_1000); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1002Core rtlzz_owner_1002(.a(32'(limb_78_999)), .b(32'(limb_78_1001)), .cin(limb_78_998), .value(limb_78_1002));
    assign limb_78_1003 = limb_78_1002[31:0]; // decl: <none>; prim: <none>
    assign limb_78_1004 = limb_78_1002[32]; // decl: <none>; prim: <none>
    assign limb_78_1005 = s8_norm_sub_118_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_1006 = tmp_workload_top_int_130__161_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_1007 = (~limb_78_1006); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1008Core rtlzz_owner_1008(.a(2'(limb_78_1005)), .b(2'(limb_78_1007)), .cin(limb_78_1004), .value(limb_78_1008[1:0]));
    assign limb_78_1008[2:2] = '0;
    assign limb_78_1009 = limb_78_1008[1:0]; // decl: <none>; prim: <none>
    assign limb_78_1010 = {limb_78_1009, limb_78_1003, limb_78_997, limb_78_991, limb_78_985}; // decl: <none>; prim: <none>
    assign limb_85_1011 = tmp_workload_top_int_129__174_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_85_1012 = __beopt_width_374[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1013Core rtlzz_owner_1013(.a(32'(rtlzz_pipe_1011_s2)), .b(32'(limb_85_1012)), .cin(1'h0), .value(limb_85_1013));
    assign limb_85_1014 = limb_85_1013[31:0]; // decl: <none>; prim: <none>
    assign limb_85_1015 = limb_85_1013[32]; // decl: <none>; prim: <none>
    assign limb_85_1016 = tmp_workload_top_int_129__174_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_85_1017 = __beopt_width_374[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1018Core rtlzz_owner_1018(.a(32'(rtlzz_pipe_1016_s2)), .b(32'(limb_85_1017)), .cin(limb_85_1015), .value(limb_85_1018));
    assign limb_85_1019 = limb_85_1018[31:0]; // decl: <none>; prim: <none>
    assign limb_85_1020 = limb_85_1018[32]; // decl: <none>; prim: <none>
    assign limb_85_1021 = tmp_workload_top_int_129__174_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_85_1022 = __beopt_width_374[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1023Core rtlzz_owner_1023(.a(32'(rtlzz_pipe_1021_s2)), .b(32'(limb_85_1022)), .cin(limb_85_1020), .value(limb_85_1023));
    assign limb_85_1024 = limb_85_1023[31:0]; // decl: <none>; prim: <none>
    assign limb_85_1025 = limb_85_1023[32]; // decl: <none>; prim: <none>
    assign limb_85_1026 = tmp_workload_top_int_129__174_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_85_1027 = __beopt_width_374[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1028Core rtlzz_owner_1028(.a(32'(rtlzz_pipe_1026_s2)), .b(32'(limb_85_1027)), .cin(limb_85_1025), .value(limb_85_1028));
    assign limb_85_1029 = limb_85_1028[31:0]; // decl: <none>; prim: <none>
    assign limb_85_1030 = limb_85_1028[32]; // decl: <none>; prim: <none>
    assign limb_85_1031 = tmp_workload_top_int_129__174_v0[128]; // decl: <none>; prim: <none>
    assign limb_85_1032 = __beopt_width_374[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1033Core rtlzz_owner_1033(.a(1'(rtlzz_pipe_1031_s2)), .b(1'(limb_85_1032)), .cin(limb_85_1030), .value(limb_85_1033[0:0]));
    assign limb_85_1033[1:1] = '0;
    assign limb_85_1034 = limb_85_1033[0]; // decl: <none>; prim: <none>
    assign limb_85_1035 = {limb_85_1034, limb_85_1029, limb_85_1024, limb_85_1019, limb_85_1014}; // decl: <none>; prim: <none>
    assign limb_87_1036 = tmp_workload_top_int_129__179_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_87_1037 = __beopt_width_378[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1038Core rtlzz_owner_1038(.a(32'(rtlzz_pipe_1036_s3)), .b(32'(limb_87_1037)), .cin(1'h0), .value(limb_87_1038));
    assign limb_87_1039 = limb_87_1038[31:0]; // decl: <none>; prim: <none>
    assign limb_87_1040 = limb_87_1038[32]; // decl: <none>; prim: <none>
    assign limb_87_1041 = tmp_workload_top_int_129__179_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_87_1042 = __beopt_width_378[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1043Core rtlzz_owner_1043(.a(32'(rtlzz_pipe_1041_s3)), .b(32'(limb_87_1042)), .cin(limb_87_1040), .value(limb_87_1043));
    assign limb_87_1044 = limb_87_1043[31:0]; // decl: <none>; prim: <none>
    assign limb_87_1045 = limb_87_1043[32]; // decl: <none>; prim: <none>
    assign limb_87_1046 = tmp_workload_top_int_129__179_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_87_1047 = __beopt_width_378[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1048Core rtlzz_owner_1048(.a(32'(rtlzz_pipe_1046_s3)), .b(32'(limb_87_1047)), .cin(limb_87_1045), .value(limb_87_1048));
    assign limb_87_1049 = limb_87_1048[31:0]; // decl: <none>; prim: <none>
    assign limb_87_1050 = limb_87_1048[32]; // decl: <none>; prim: <none>
    assign limb_87_1051 = tmp_workload_top_int_129__179_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_87_1052 = __beopt_width_378[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1053Core rtlzz_owner_1053(.a(32'(rtlzz_pipe_1051_s3)), .b(32'(limb_87_1052)), .cin(limb_87_1050), .value(limb_87_1053));
    assign limb_87_1054 = limb_87_1053[31:0]; // decl: <none>; prim: <none>
    assign limb_87_1055 = limb_87_1053[32]; // decl: <none>; prim: <none>
    assign limb_87_1056 = tmp_workload_top_int_129__179_v0[128]; // decl: <none>; prim: <none>
    assign limb_87_1057 = __beopt_width_378[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1058Core rtlzz_owner_1058(.a(1'(rtlzz_pipe_1056_s4)), .b(1'(rtlzz_pipe_1057_s4)), .cin(rtlzz_pipe_1055_s4), .value(limb_87_1058[0:0]));
    assign limb_87_1058[1:1] = '0;
    assign limb_87_1059 = limb_87_1058[0]; // decl: <none>; prim: <none>
    assign limb_87_1060 = {limb_87_1059, rtlzz_pipe_1054_s4, rtlzz_pipe_1049_s4, rtlzz_pipe_1044_s4, rtlzz_pipe_1039_s4}; // decl: <none>; prim: <none>
    assign limb_95_1061 = tmp_workload_top_int_34__202_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_95_1062 = __beopt_width_388[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1063Core rtlzz_owner_1063(.a(32'(limb_95_1061)), .b(32'(rtlzz_pipe_1062_s3)), .cin(1'h0), .value(limb_95_1063));
    assign limb_95_1064 = limb_95_1063[31:0]; // decl: <none>; prim: <none>
    assign limb_95_1065 = limb_95_1063[32]; // decl: <none>; prim: <none>
    assign limb_95_1066 = tmp_workload_top_int_34__202_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_95_1067 = __beopt_width_388[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1068Core rtlzz_owner_1068(.a(2'(limb_95_1066)), .b(2'(rtlzz_pipe_1067_s3)), .cin(limb_95_1065), .value(limb_95_1068[1:0]));
    assign limb_95_1068[2:2] = '0;
    assign limb_95_1069 = limb_95_1068[1:0]; // decl: <none>; prim: <none>
    assign limb_95_1070 = {limb_95_1069, limb_95_1064}; // decl: <none>; prim: <none>
    assign limb_97_1071 = tmp_workload_top_int_34__207_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_97_1072 = __beopt_width_391[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1073Core rtlzz_owner_1073(.a(32'(limb_97_1071)), .b(32'(limb_97_1072)), .cin(1'h0), .value(limb_97_1073));
    assign limb_97_1074 = limb_97_1073[31:0]; // decl: <none>; prim: <none>
    assign limb_97_1075 = limb_97_1073[32]; // decl: <none>; prim: <none>
    assign limb_97_1076 = tmp_workload_top_int_34__207_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_97_1077 = __beopt_width_391[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1078Core rtlzz_owner_1078(.a(2'(limb_97_1076)), .b(2'(limb_97_1077)), .cin(limb_97_1075), .value(limb_97_1078[1:0]));
    assign limb_97_1078[2:2] = '0;
    assign limb_97_1079 = limb_97_1078[1:0]; // decl: <none>; prim: <none>
    assign limb_97_1080 = {limb_97_1079, limb_97_1074}; // decl: <none>; prim: <none>
    assign limb_103_1081 = n60_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_103_1082 = tmp_workload_top_int_68__217_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_103_1083 = (~limb_103_1082); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1084Core rtlzz_owner_1084(.a(32'(rtlzz_pipe_1081_s5)), .b(32'(limb_103_1083)), .cin(1'h1), .value(limb_103_1084));
    assign limb_103_1085 = limb_103_1084[31:0]; // decl: <none>; prim: <none>
    assign limb_103_1086 = limb_103_1084[32]; // decl: <none>; prim: <none>
    assign limb_103_1087 = n60_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_103_1088 = tmp_workload_top_int_68__217_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_103_1089 = (~limb_103_1088); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1090Core rtlzz_owner_1090(.a(32'(rtlzz_pipe_1087_s5)), .b(32'(limb_103_1089)), .cin(limb_103_1086), .value(limb_103_1090));
    assign limb_103_1091 = limb_103_1090[31:0]; // decl: <none>; prim: <none>
    assign limb_103_1092 = limb_103_1090[32]; // decl: <none>; prim: <none>
    assign limb_103_1093 = n60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_1094 = tmp_workload_top_int_68__217_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_1095 = (~limb_103_1094); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1096Core rtlzz_owner_1096(.a(4'(rtlzz_pipe_1093_s5)), .b(4'(limb_103_1095)), .cin(limb_103_1092), .value(limb_103_1096[3:0]));
    assign limb_103_1096[4:4] = '0;
    assign limb_103_1097 = limb_103_1096[3:0]; // decl: <none>; prim: <none>
    assign limb_103_1098 = {limb_103_1097, limb_103_1091, limb_103_1085}; // decl: <none>; prim: <none>
    assign limb_105_1099 = s8_norm_sub_161_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_105_1100 = tmp_workload_top_int_68__220_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_105_1101 = (~limb_105_1100); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1102Core rtlzz_owner_1102(.a(32'(limb_105_1099)), .b(32'(rtlzz_pipe_1101_s5)), .cin(1'h1), .value(limb_105_1102));
    assign limb_105_1103 = limb_105_1102[31:0]; // decl: <none>; prim: <none>
    assign limb_105_1104 = limb_105_1102[32]; // decl: <none>; prim: <none>
    assign limb_105_1105 = s8_norm_sub_161_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_105_1106 = tmp_workload_top_int_68__220_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_105_1107 = (~limb_105_1106); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1108Core rtlzz_owner_1108(.a(32'(limb_105_1105)), .b(32'(rtlzz_pipe_1107_s5)), .cin(limb_105_1104), .value(limb_105_1108));
    assign limb_105_1109 = limb_105_1108[31:0]; // decl: <none>; prim: <none>
    assign limb_105_1110 = limb_105_1108[32]; // decl: <none>; prim: <none>
    assign limb_105_1111 = s8_norm_sub_161_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_1112 = tmp_workload_top_int_68__220_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_1113 = (~limb_105_1112); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1114Core rtlzz_owner_1114(.a(4'(limb_105_1111)), .b(4'(rtlzz_pipe_1113_s5)), .cin(limb_105_1110), .value(limb_105_1114[3:0]));
    assign limb_105_1114[4:4] = '0;
    assign limb_105_1115 = limb_105_1114[3:0]; // decl: <none>; prim: <none>
    assign limb_105_1116 = {limb_105_1115, limb_105_1109, limb_105_1103}; // decl: <none>; prim: <none>
    assign limb_113_1117 = tmp_workload_top_int_66__238_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_113_1118 = __beopt_width_401[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1119Core rtlzz_owner_1119(.a(32'(rtlzz_pipe_1117_s3)), .b(32'(limb_113_1118)), .cin(1'h0), .value(limb_113_1119));
    assign limb_113_1120 = limb_113_1119[31:0]; // decl: <none>; prim: <none>
    assign limb_113_1121 = limb_113_1119[32]; // decl: <none>; prim: <none>
    assign limb_113_1122 = tmp_workload_top_int_66__238_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_113_1123 = __beopt_width_401[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1124Core rtlzz_owner_1124(.a(32'(rtlzz_pipe_1122_s3)), .b(32'(limb_113_1123)), .cin(limb_113_1121), .value(limb_113_1124));
    assign limb_113_1125 = limb_113_1124[31:0]; // decl: <none>; prim: <none>
    assign limb_113_1126 = limb_113_1124[32]; // decl: <none>; prim: <none>
    assign limb_113_1127 = tmp_workload_top_int_66__238_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_113_1128 = __beopt_width_401[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1129Core rtlzz_owner_1129(.a(2'(rtlzz_pipe_1127_s3)), .b(2'(limb_113_1128)), .cin(limb_113_1126), .value(limb_113_1129[1:0]));
    assign limb_113_1129[2:2] = '0;
    assign limb_113_1130 = limb_113_1129[1:0]; // decl: <none>; prim: <none>
    assign limb_113_1131 = {limb_113_1130, limb_113_1125, limb_113_1120}; // decl: <none>; prim: <none>
    assign limb_115_1132 = tmp_workload_top_int_66__243_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_115_1133 = __beopt_width_404[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1134Core rtlzz_owner_1134(.a(32'(rtlzz_pipe_1132_s5)), .b(32'(limb_115_1133)), .cin(1'h0), .value(limb_115_1134));
    assign limb_115_1135 = limb_115_1134[31:0]; // decl: <none>; prim: <none>
    assign limb_115_1136 = limb_115_1134[32]; // decl: <none>; prim: <none>
    assign limb_115_1137 = tmp_workload_top_int_66__243_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_115_1138 = __beopt_width_404[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1139Core rtlzz_owner_1139(.a(32'(rtlzz_pipe_1137_s5)), .b(32'(limb_115_1138)), .cin(limb_115_1136), .value(limb_115_1139));
    assign limb_115_1140 = limb_115_1139[31:0]; // decl: <none>; prim: <none>
    assign limb_115_1141 = limb_115_1139[32]; // decl: <none>; prim: <none>
    assign limb_115_1142 = tmp_workload_top_int_66__243_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_115_1143 = __beopt_width_404[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1144Core rtlzz_owner_1144(.a(2'(rtlzz_pipe_1142_s5)), .b(2'(limb_115_1143)), .cin(limb_115_1141), .value(limb_115_1144[1:0]));
    assign limb_115_1144[2:2] = '0;
    assign limb_115_1145 = limb_115_1144[1:0]; // decl: <none>; prim: <none>
    assign limb_115_1146 = {limb_115_1145, limb_115_1140, limb_115_1135}; // decl: <none>; prim: <none>
    assign limb_121_1147 = tmp_workload_top_int_34__262_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_121_1148 = __beopt_width_416[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1149Core rtlzz_owner_1149(.a(32'(limb_121_1147)), .b(32'(limb_121_1148)), .cin(1'h0), .value(limb_121_1149));
    assign limb_121_1150 = limb_121_1149[31:0]; // decl: <none>; prim: <none>
    assign limb_121_1151 = limb_121_1149[32]; // decl: <none>; prim: <none>
    assign limb_121_1152 = tmp_workload_top_int_34__262_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_121_1153 = __beopt_width_416[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1154Core rtlzz_owner_1154(.a(2'(rtlzz_pipe_1152_s4)), .b(2'(rtlzz_pipe_1153_s4)), .cin(rtlzz_pipe_1151_s4), .value(limb_121_1154[1:0]));
    assign limb_121_1154[2:2] = '0;
    assign limb_121_1155 = limb_121_1154[1:0]; // decl: <none>; prim: <none>
    assign limb_121_1156 = {limb_121_1155, rtlzz_pipe_1150_s4}; // decl: <none>; prim: <none>
    assign limb_123_1157 = tmp_workload_top_int_34__267_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_123_1158 = __beopt_width_424[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1159Core rtlzz_owner_1159(.a(32'(limb_123_1157)), .b(32'(limb_123_1158)), .cin(1'h0), .value(limb_123_1159));
    assign limb_123_1160 = limb_123_1159[31:0]; // decl: <none>; prim: <none>
    assign limb_123_1161 = limb_123_1159[32]; // decl: <none>; prim: <none>
    assign limb_123_1162 = tmp_workload_top_int_34__267_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_123_1163 = __beopt_width_424[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1164Core rtlzz_owner_1164(.a(2'(limb_123_1162)), .b(2'(limb_123_1163)), .cin(limb_123_1161), .value(limb_123_1164[1:0]));
    assign limb_123_1164[2:2] = '0;
    assign limb_123_1165 = limb_123_1164[1:0]; // decl: <none>; prim: <none>
    assign limb_123_1166 = {limb_123_1165, limb_123_1160}; // decl: <none>; prim: <none>
    assign limb_129_1167 = n74_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_129_1168 = tmp_workload_top_int_68__277_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_129_1169 = (~limb_129_1168); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1170Core rtlzz_owner_1170(.a(32'(limb_129_1167)), .b(32'(rtlzz_pipe_1169_s6)), .cin(1'h1), .value(limb_129_1170));
    assign limb_129_1171 = limb_129_1170[31:0]; // decl: <none>; prim: <none>
    assign limb_129_1172 = limb_129_1170[32]; // decl: <none>; prim: <none>
    assign limb_129_1173 = n74_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_129_1174 = tmp_workload_top_int_68__277_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_129_1175 = (~limb_129_1174); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1176Core rtlzz_owner_1176(.a(32'(limb_129_1173)), .b(32'(rtlzz_pipe_1175_s6)), .cin(limb_129_1172), .value(limb_129_1176));
    assign limb_129_1177 = limb_129_1176[31:0]; // decl: <none>; prim: <none>
    assign limb_129_1178 = limb_129_1176[32]; // decl: <none>; prim: <none>
    assign limb_129_1179 = n74_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_1180 = tmp_workload_top_int_68__277_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_1181 = (~limb_129_1180); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1182Core rtlzz_owner_1182(.a(4'(limb_129_1179)), .b(4'(rtlzz_pipe_1181_s6)), .cin(limb_129_1178), .value(limb_129_1182[3:0]));
    assign limb_129_1182[4:4] = '0;
    assign limb_129_1183 = limb_129_1182[3:0]; // decl: <none>; prim: <none>
    assign limb_129_1184 = {limb_129_1183, limb_129_1177, limb_129_1171}; // decl: <none>; prim: <none>
    assign limb_131_1185 = s8_norm_sub_204_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_131_1186 = tmp_workload_top_int_68__280_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_131_1187 = (~limb_131_1186); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1188Core rtlzz_owner_1188(.a(32'(limb_131_1185)), .b(32'(limb_131_1187)), .cin(1'h1), .value(limb_131_1188));
    assign limb_131_1189 = limb_131_1188[31:0]; // decl: <none>; prim: <none>
    assign limb_131_1190 = limb_131_1188[32]; // decl: <none>; prim: <none>
    assign limb_131_1191 = s8_norm_sub_204_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_131_1192 = tmp_workload_top_int_68__280_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_131_1193 = (~limb_131_1192); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1194Core rtlzz_owner_1194(.a(32'(limb_131_1191)), .b(32'(limb_131_1193)), .cin(limb_131_1190), .value(limb_131_1194));
    assign limb_131_1195 = limb_131_1194[31:0]; // decl: <none>; prim: <none>
    assign limb_131_1196 = limb_131_1194[32]; // decl: <none>; prim: <none>
    assign limb_131_1197 = s8_norm_sub_204_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_1198 = tmp_workload_top_int_68__280_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_1199 = (~limb_131_1198); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1200Core rtlzz_owner_1200(.a(4'(limb_131_1197)), .b(4'(limb_131_1199)), .cin(limb_131_1196), .value(limb_131_1200[3:0]));
    assign limb_131_1200[4:4] = '0;
    assign limb_131_1201 = limb_131_1200[3:0]; // decl: <none>; prim: <none>
    assign limb_131_1202 = {limb_131_1201, limb_131_1195, limb_131_1189}; // decl: <none>; prim: <none>
    assign limb_138_1203 = __beopt_width_307[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1204 = tmp_workload_top_int_132__293_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1205 = (~limb_138_1204); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1206Core rtlzz_owner_1206(.a(32'(limb_138_1203)), .b(32'(rtlzz_pipe_1205_s6)), .cin(1'h1), .value(limb_138_1206));
    assign limb_138_1207 = limb_138_1206[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1208 = limb_138_1206[32]; // decl: <none>; prim: <none>
    assign limb_138_1209 = __beopt_width_307[63:32]; // decl: <none>; prim: <none>
    assign limb_138_1210 = tmp_workload_top_int_132__293_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_138_1211 = (~limb_138_1210); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1212Core rtlzz_owner_1212(.a(32'(limb_138_1209)), .b(32'(rtlzz_pipe_1211_s6)), .cin(limb_138_1208), .value(limb_138_1212));
    assign limb_138_1213 = limb_138_1212[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1214 = limb_138_1212[32]; // decl: <none>; prim: <none>
    assign limb_138_1215 = __beopt_width_307[95:64]; // decl: <none>; prim: <none>
    assign limb_138_1216 = tmp_workload_top_int_132__293_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_138_1217 = (~limb_138_1216); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1218Core rtlzz_owner_1218(.a(32'(limb_138_1215)), .b(32'(rtlzz_pipe_1217_s6)), .cin(limb_138_1214), .value(limb_138_1218));
    assign limb_138_1219 = limb_138_1218[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1220 = limb_138_1218[32]; // decl: <none>; prim: <none>
    assign limb_138_1221 = __beopt_width_307[127:96]; // decl: <none>; prim: <none>
    assign limb_138_1222 = tmp_workload_top_int_132__293_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_138_1223 = (~limb_138_1222); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1224Core rtlzz_owner_1224(.a(32'(limb_138_1221)), .b(32'(rtlzz_pipe_1223_s6)), .cin(limb_138_1220), .value(limb_138_1224));
    assign limb_138_1225 = limb_138_1224[31:0]; // decl: <none>; prim: <none>
    assign limb_138_1226 = limb_138_1224[32]; // decl: <none>; prim: <none>
    assign limb_138_1227 = __beopt_width_307[131:128]; // decl: <none>; prim: <none>
    assign limb_138_1228 = tmp_workload_top_int_132__293_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_138_1229 = (~limb_138_1228); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1230Core rtlzz_owner_1230(.a(4'(limb_138_1227)), .b(4'(rtlzz_pipe_1229_s6)), .cin(limb_138_1226), .value(limb_138_1230[3:0]));
    assign limb_138_1230[4:4] = '0;
    assign limb_138_1231 = limb_138_1230[3:0]; // decl: <none>; prim: <none>
    assign limb_138_1232 = {limb_138_1231, limb_138_1225, limb_138_1219, limb_138_1213, limb_138_1207}; // decl: <none>; prim: <none>
    assign limb_140_1233 = s8_norm_sub_215_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1234 = tmp_workload_top_int_132__296_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1235 = (~limb_140_1234); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1236Core rtlzz_owner_1236(.a(32'(limb_140_1233)), .b(32'(rtlzz_pipe_1235_s6)), .cin(1'h1), .value(limb_140_1236));
    assign limb_140_1237 = limb_140_1236[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1238 = limb_140_1236[32]; // decl: <none>; prim: <none>
    assign limb_140_1239 = s8_norm_sub_215_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_140_1240 = tmp_workload_top_int_132__296_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_140_1241 = (~limb_140_1240); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1242Core rtlzz_owner_1242(.a(32'(limb_140_1239)), .b(32'(rtlzz_pipe_1241_s6)), .cin(limb_140_1238), .value(limb_140_1242));
    assign limb_140_1243 = limb_140_1242[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1244 = limb_140_1242[32]; // decl: <none>; prim: <none>
    assign limb_140_1245 = s8_norm_sub_215_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_140_1246 = tmp_workload_top_int_132__296_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_140_1247 = (~limb_140_1246); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1248Core rtlzz_owner_1248(.a(32'(limb_140_1245)), .b(32'(rtlzz_pipe_1247_s6)), .cin(limb_140_1244), .value(limb_140_1248));
    assign limb_140_1249 = limb_140_1248[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1250 = limb_140_1248[32]; // decl: <none>; prim: <none>
    assign limb_140_1251 = s8_norm_sub_215_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_140_1252 = tmp_workload_top_int_132__296_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_140_1253 = (~limb_140_1252); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1254Core rtlzz_owner_1254(.a(32'(limb_140_1251)), .b(32'(rtlzz_pipe_1253_s6)), .cin(limb_140_1250), .value(limb_140_1254));
    assign limb_140_1255 = limb_140_1254[31:0]; // decl: <none>; prim: <none>
    assign limb_140_1256 = limb_140_1254[32]; // decl: <none>; prim: <none>
    assign limb_140_1257 = s8_norm_sub_215_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1258 = tmp_workload_top_int_132__296_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1259 = (~limb_140_1258); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1260Core rtlzz_owner_1260(.a(4'(limb_140_1257)), .b(4'(rtlzz_pipe_1259_s6)), .cin(limb_140_1256), .value(limb_140_1260[3:0]));
    assign limb_140_1260[4:4] = '0;
    assign limb_140_1261 = limb_140_1260[3:0]; // decl: <none>; prim: <none>
    assign limb_140_1262 = {limb_140_1261, limb_140_1255, limb_140_1249, limb_140_1243, limb_140_1237}; // decl: <none>; prim: <none>
    assign limb_147_1263 = __beopt_width_297[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1264 = tmp_workload_top_int_258__309_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1265 = (~limb_147_1264); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1266Core rtlzz_owner_1266(.a(32'(rtlzz_pipe_1263_s7)), .b(32'(limb_147_1265)), .cin(1'h1), .value(limb_147_1266));
    assign limb_147_1267 = limb_147_1266[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1268 = limb_147_1266[32]; // decl: <none>; prim: <none>
    assign limb_147_1269 = __beopt_width_297[63:32]; // decl: <none>; prim: <none>
    assign limb_147_1270 = tmp_workload_top_int_258__309_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_147_1271 = (~limb_147_1270); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1272Core rtlzz_owner_1272(.a(32'(rtlzz_pipe_1269_s7)), .b(32'(limb_147_1271)), .cin(limb_147_1268), .value(limb_147_1272));
    assign limb_147_1273 = limb_147_1272[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1274 = limb_147_1272[32]; // decl: <none>; prim: <none>
    assign limb_147_1275 = __beopt_width_297[95:64]; // decl: <none>; prim: <none>
    assign limb_147_1276 = tmp_workload_top_int_258__309_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_147_1277 = (~limb_147_1276); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1278Core rtlzz_owner_1278(.a(32'(rtlzz_pipe_1275_s7)), .b(32'(limb_147_1277)), .cin(limb_147_1274), .value(limb_147_1278));
    assign limb_147_1279 = limb_147_1278[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1280 = limb_147_1278[32]; // decl: <none>; prim: <none>
    assign limb_147_1281 = __beopt_width_297[127:96]; // decl: <none>; prim: <none>
    assign limb_147_1282 = tmp_workload_top_int_258__309_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_147_1283 = (~limb_147_1282); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1284Core rtlzz_owner_1284(.a(32'(rtlzz_pipe_1281_s7)), .b(32'(limb_147_1283)), .cin(limb_147_1280), .value(limb_147_1284));
    assign limb_147_1285 = limb_147_1284[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1286 = limb_147_1284[32]; // decl: <none>; prim: <none>
    assign limb_147_1287 = __beopt_width_297[159:128]; // decl: <none>; prim: <none>
    assign limb_147_1288 = tmp_workload_top_int_258__309_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_147_1289 = (~limb_147_1288); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1290Core rtlzz_owner_1290(.a(32'(rtlzz_pipe_1287_s7)), .b(32'(limb_147_1289)), .cin(limb_147_1286), .value(limb_147_1290));
    assign limb_147_1291 = limb_147_1290[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1292 = limb_147_1290[32]; // decl: <none>; prim: <none>
    assign limb_147_1293 = __beopt_width_297[191:160]; // decl: <none>; prim: <none>
    assign limb_147_1294 = tmp_workload_top_int_258__309_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_147_1295 = (~limb_147_1294); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1296Core rtlzz_owner_1296(.a(32'(rtlzz_pipe_1293_s7)), .b(32'(limb_147_1295)), .cin(limb_147_1292), .value(limb_147_1296));
    assign limb_147_1297 = limb_147_1296[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1298 = limb_147_1296[32]; // decl: <none>; prim: <none>
    assign limb_147_1299 = __beopt_width_297[223:192]; // decl: <none>; prim: <none>
    assign limb_147_1300 = tmp_workload_top_int_258__309_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_147_1301 = (~limb_147_1300); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1302Core rtlzz_owner_1302(.a(32'(rtlzz_pipe_1299_s7)), .b(32'(limb_147_1301)), .cin(limb_147_1298), .value(limb_147_1302));
    assign limb_147_1303 = limb_147_1302[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1304 = limb_147_1302[32]; // decl: <none>; prim: <none>
    assign limb_147_1305 = __beopt_width_297[255:224]; // decl: <none>; prim: <none>
    assign limb_147_1306 = tmp_workload_top_int_258__309_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_147_1307 = (~limb_147_1306); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1308Core rtlzz_owner_1308(.a(32'(rtlzz_pipe_1305_s7)), .b(32'(limb_147_1307)), .cin(limb_147_1304), .value(limb_147_1308));
    assign limb_147_1309 = limb_147_1308[31:0]; // decl: <none>; prim: <none>
    assign limb_147_1310 = limb_147_1308[32]; // decl: <none>; prim: <none>
    assign limb_147_1311 = __beopt_width_297[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1312 = tmp_workload_top_int_258__309_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1313 = (~limb_147_1312); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1314Core rtlzz_owner_1314(.a(2'(rtlzz_pipe_1311_s7)), .b(2'(limb_147_1313)), .cin(limb_147_1310), .value(limb_147_1314[1:0]));
    assign limb_147_1314[2:2] = '0;
    assign limb_147_1315 = limb_147_1314[1:0]; // decl: <none>; prim: <none>
    assign limb_147_1316 = {limb_147_1315, limb_147_1309, limb_147_1303, limb_147_1297, limb_147_1291, limb_147_1285, limb_147_1279, limb_147_1273, limb_147_1267}; // decl: <none>; prim: <none>
    assign limb_149_1317 = s8_norm_sub_226_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1318 = tmp_workload_top_int_258__312_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1319 = (~limb_149_1318); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1320Core rtlzz_owner_1320(.a(32'(limb_149_1317)), .b(32'(limb_149_1319)), .cin(1'h1), .value(limb_149_1320));
    assign limb_149_1321 = limb_149_1320[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1322 = limb_149_1320[32]; // decl: <none>; prim: <none>
    assign limb_149_1323 = s8_norm_sub_226_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_149_1324 = tmp_workload_top_int_258__312_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_149_1325 = (~limb_149_1324); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1326Core rtlzz_owner_1326(.a(32'(limb_149_1323)), .b(32'(limb_149_1325)), .cin(limb_149_1322), .value(limb_149_1326));
    assign limb_149_1327 = limb_149_1326[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1328 = limb_149_1326[32]; // decl: <none>; prim: <none>
    assign limb_149_1329 = s8_norm_sub_226_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_149_1330 = tmp_workload_top_int_258__312_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_149_1331 = (~limb_149_1330); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1332Core rtlzz_owner_1332(.a(32'(limb_149_1329)), .b(32'(limb_149_1331)), .cin(limb_149_1328), .value(limb_149_1332));
    assign limb_149_1333 = limb_149_1332[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1334 = limb_149_1332[32]; // decl: <none>; prim: <none>
    assign limb_149_1335 = s8_norm_sub_226_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_149_1336 = tmp_workload_top_int_258__312_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_149_1337 = (~limb_149_1336); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1338Core rtlzz_owner_1338(.a(32'(limb_149_1335)), .b(32'(limb_149_1337)), .cin(limb_149_1334), .value(limb_149_1338));
    assign limb_149_1339 = limb_149_1338[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1340 = limb_149_1338[32]; // decl: <none>; prim: <none>
    assign limb_149_1341 = s8_norm_sub_226_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_149_1342 = tmp_workload_top_int_258__312_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_149_1343 = (~limb_149_1342); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1344Core rtlzz_owner_1344(.a(32'(limb_149_1341)), .b(32'(limb_149_1343)), .cin(limb_149_1340), .value(limb_149_1344));
    assign limb_149_1345 = limb_149_1344[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1346 = limb_149_1344[32]; // decl: <none>; prim: <none>
    assign limb_149_1347 = s8_norm_sub_226_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_149_1348 = tmp_workload_top_int_258__312_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_149_1349 = (~limb_149_1348); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1350Core rtlzz_owner_1350(.a(32'(limb_149_1347)), .b(32'(limb_149_1349)), .cin(limb_149_1346), .value(limb_149_1350));
    assign limb_149_1351 = limb_149_1350[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1352 = limb_149_1350[32]; // decl: <none>; prim: <none>
    assign limb_149_1353 = s8_norm_sub_226_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_149_1354 = tmp_workload_top_int_258__312_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_149_1355 = (~limb_149_1354); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1356Core rtlzz_owner_1356(.a(32'(limb_149_1353)), .b(32'(limb_149_1355)), .cin(limb_149_1352), .value(limb_149_1356));
    assign limb_149_1357 = limb_149_1356[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1358 = limb_149_1356[32]; // decl: <none>; prim: <none>
    assign limb_149_1359 = s8_norm_sub_226_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_149_1360 = tmp_workload_top_int_258__312_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_149_1361 = (~limb_149_1360); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1362Core rtlzz_owner_1362(.a(32'(limb_149_1359)), .b(32'(limb_149_1361)), .cin(limb_149_1358), .value(limb_149_1362));
    assign limb_149_1363 = limb_149_1362[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1364 = limb_149_1362[32]; // decl: <none>; prim: <none>
    assign limb_149_1365 = s8_norm_sub_226_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1366 = tmp_workload_top_int_258__312_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1367 = (~limb_149_1366); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1368Core rtlzz_owner_1368(.a(2'(limb_149_1365)), .b(2'(limb_149_1367)), .cin(limb_149_1364), .value(limb_149_1368[1:0]));
    assign limb_149_1368[2:2] = '0;
    assign limb_149_1369 = limb_149_1368[1:0]; // decl: <none>; prim: <none>
    assign limb_149_1370 = {limb_149_1369, limb_149_1363, limb_149_1357, limb_149_1351, limb_149_1345, limb_149_1339, limb_149_1333, limb_149_1327, limb_149_1321}; // decl: <none>; prim: <none>
    assign limb_157_1371 = tmp_workload_top_int_513__325_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1372 = tmp_workload_top_int_513__327_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1373Core rtlzz_owner_1373(.a(32'(limb_157_1371)), .b(32'(rtlzz_pipe_1372_s7)), .cin(1'h0), .value(limb_157_1373));
    assign limb_157_1374 = limb_157_1373[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1375 = limb_157_1373[32]; // decl: <none>; prim: <none>
    assign limb_157_1376 = tmp_workload_top_int_513__325_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_157_1377 = tmp_workload_top_int_513__327_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1378Core rtlzz_owner_1378(.a(32'(limb_157_1376)), .b(32'(rtlzz_pipe_1377_s7)), .cin(limb_157_1375), .value(limb_157_1378));
    assign limb_157_1379 = limb_157_1378[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1380 = limb_157_1378[32]; // decl: <none>; prim: <none>
    assign limb_157_1381 = tmp_workload_top_int_513__325_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_157_1382 = tmp_workload_top_int_513__327_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1383Core rtlzz_owner_1383(.a(32'(limb_157_1381)), .b(32'(rtlzz_pipe_1382_s7)), .cin(limb_157_1380), .value(limb_157_1383));
    assign limb_157_1384 = limb_157_1383[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1385 = limb_157_1383[32]; // decl: <none>; prim: <none>
    assign limb_157_1386 = tmp_workload_top_int_513__325_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_157_1387 = tmp_workload_top_int_513__327_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1388Core rtlzz_owner_1388(.a(32'(limb_157_1386)), .b(32'(rtlzz_pipe_1387_s7)), .cin(limb_157_1385), .value(limb_157_1388));
    assign limb_157_1389 = limb_157_1388[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1390 = limb_157_1388[32]; // decl: <none>; prim: <none>
    assign limb_157_1391 = tmp_workload_top_int_513__325_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_157_1392 = tmp_workload_top_int_513__327_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1393Core rtlzz_owner_1393(.a(32'(limb_157_1391)), .b(32'(rtlzz_pipe_1392_s7)), .cin(limb_157_1390), .value(limb_157_1393));
    assign limb_157_1394 = limb_157_1393[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1395 = limb_157_1393[32]; // decl: <none>; prim: <none>
    assign limb_157_1396 = tmp_workload_top_int_513__325_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_157_1397 = tmp_workload_top_int_513__327_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1398Core rtlzz_owner_1398(.a(32'(limb_157_1396)), .b(32'(rtlzz_pipe_1397_s7)), .cin(limb_157_1395), .value(limb_157_1398));
    assign limb_157_1399 = limb_157_1398[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1400 = limb_157_1398[32]; // decl: <none>; prim: <none>
    assign limb_157_1401 = tmp_workload_top_int_513__325_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_157_1402 = tmp_workload_top_int_513__327_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1403Core rtlzz_owner_1403(.a(32'(limb_157_1401)), .b(32'(rtlzz_pipe_1402_s7)), .cin(limb_157_1400), .value(limb_157_1403));
    assign limb_157_1404 = limb_157_1403[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1405 = limb_157_1403[32]; // decl: <none>; prim: <none>
    assign limb_157_1406 = tmp_workload_top_int_513__325_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_157_1407 = tmp_workload_top_int_513__327_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1408Core rtlzz_owner_1408(.a(32'(limb_157_1406)), .b(32'(rtlzz_pipe_1407_s7)), .cin(limb_157_1405), .value(limb_157_1408));
    assign limb_157_1409 = limb_157_1408[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1410 = limb_157_1408[32]; // decl: <none>; prim: <none>
    assign limb_157_1411 = tmp_workload_top_int_513__325_v0[287:256]; // decl: <none>; prim: <none>
    assign limb_157_1412 = tmp_workload_top_int_513__327_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1413Core rtlzz_owner_1413(.a(32'(limb_157_1411)), .b(32'(rtlzz_pipe_1412_s7)), .cin(limb_157_1410), .value(limb_157_1413));
    assign limb_157_1414 = limb_157_1413[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1415 = limb_157_1413[32]; // decl: <none>; prim: <none>
    assign limb_157_1416 = tmp_workload_top_int_513__325_v0[319:288]; // decl: <none>; prim: <none>
    assign limb_157_1417 = tmp_workload_top_int_513__327_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1418Core rtlzz_owner_1418(.a(32'(limb_157_1416)), .b(32'(rtlzz_pipe_1417_s7)), .cin(limb_157_1415), .value(limb_157_1418));
    assign limb_157_1419 = limb_157_1418[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1420 = limb_157_1418[32]; // decl: <none>; prim: <none>
    assign limb_157_1421 = tmp_workload_top_int_513__325_v0[351:320]; // decl: <none>; prim: <none>
    assign limb_157_1422 = tmp_workload_top_int_513__327_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1423Core rtlzz_owner_1423(.a(32'(limb_157_1421)), .b(32'(rtlzz_pipe_1422_s7)), .cin(limb_157_1420), .value(limb_157_1423));
    assign limb_157_1424 = limb_157_1423[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1425 = limb_157_1423[32]; // decl: <none>; prim: <none>
    assign limb_157_1426 = tmp_workload_top_int_513__325_v0[383:352]; // decl: <none>; prim: <none>
    assign limb_157_1427 = tmp_workload_top_int_513__327_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1428Core rtlzz_owner_1428(.a(32'(limb_157_1426)), .b(32'(rtlzz_pipe_1427_s7)), .cin(limb_157_1425), .value(limb_157_1428));
    assign limb_157_1429 = limb_157_1428[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1430 = limb_157_1428[32]; // decl: <none>; prim: <none>
    assign limb_157_1431 = tmp_workload_top_int_513__325_v0[415:384]; // decl: <none>; prim: <none>
    assign limb_157_1432 = tmp_workload_top_int_513__327_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1433Core rtlzz_owner_1433(.a(32'(limb_157_1431)), .b(32'(rtlzz_pipe_1432_s7)), .cin(limb_157_1430), .value(limb_157_1433));
    assign limb_157_1434 = limb_157_1433[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1435 = limb_157_1433[32]; // decl: <none>; prim: <none>
    assign limb_157_1436 = tmp_workload_top_int_513__325_v0[447:416]; // decl: <none>; prim: <none>
    assign limb_157_1437 = tmp_workload_top_int_513__327_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1438Core rtlzz_owner_1438(.a(32'(limb_157_1436)), .b(32'(rtlzz_pipe_1437_s7)), .cin(limb_157_1435), .value(limb_157_1438));
    assign limb_157_1439 = limb_157_1438[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1440 = limb_157_1438[32]; // decl: <none>; prim: <none>
    assign limb_157_1441 = tmp_workload_top_int_513__325_v0[479:448]; // decl: <none>; prim: <none>
    assign limb_157_1442 = tmp_workload_top_int_513__327_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1443Core rtlzz_owner_1443(.a(32'(limb_157_1441)), .b(32'(rtlzz_pipe_1442_s7)), .cin(limb_157_1440), .value(limb_157_1443));
    assign limb_157_1444 = limb_157_1443[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1445 = limb_157_1443[32]; // decl: <none>; prim: <none>
    assign limb_157_1446 = tmp_workload_top_int_513__325_v0[511:480]; // decl: <none>; prim: <none>
    assign limb_157_1447 = tmp_workload_top_int_513__327_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1448Core rtlzz_owner_1448(.a(32'(limb_157_1446)), .b(32'(rtlzz_pipe_1447_s7)), .cin(limb_157_1445), .value(limb_157_1448));
    assign limb_157_1449 = limb_157_1448[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1450 = limb_157_1448[32]; // decl: <none>; prim: <none>
    assign limb_157_1451 = tmp_workload_top_int_513__325_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_1452 = tmp_workload_top_int_513__327_v0[512]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1453Core rtlzz_owner_1453(.a(1'(limb_157_1451)), .b(1'(rtlzz_pipe_1452_s7)), .cin(limb_157_1450), .value(limb_157_1453[0:0]));
    assign limb_157_1453[1:1] = '0;
    assign limb_157_1454 = limb_157_1453[0]; // decl: <none>; prim: <none>
    assign limb_157_1455 = {limb_157_1454, limb_157_1449, limb_157_1444, limb_157_1439, limb_157_1434, limb_157_1429, limb_157_1424, limb_157_1419, limb_157_1414, limb_157_1409, limb_157_1404, limb_157_1399, limb_157_1394, limb_157_1389, limb_157_1384, limb_157_1379, limb_157_1374}; // decl: <none>; prim: <none>
    assign limb_216_1456 = tmp_workload_top_int_512__315_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1457 = s8_norm_shift_234_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1458Core rtlzz_owner_1458(.a(32'(limb_216_1456)), .b(32'(limb_216_1457)), .cin(1'h0), .value(limb_216_1458));
    assign limb_216_1459 = limb_216_1458[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1460 = limb_216_1458[32]; // decl: <none>; prim: <none>
    assign limb_216_1461 = tmp_workload_top_int_512__315_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_216_1462 = s8_norm_shift_234_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1463Core rtlzz_owner_1463(.a(32'(limb_216_1461)), .b(32'(limb_216_1462)), .cin(limb_216_1460), .value(limb_216_1463));
    assign limb_216_1464 = limb_216_1463[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1465 = limb_216_1463[32]; // decl: <none>; prim: <none>
    assign limb_216_1466 = tmp_workload_top_int_512__315_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_216_1467 = s8_norm_shift_234_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1468Core rtlzz_owner_1468(.a(32'(limb_216_1466)), .b(32'(limb_216_1467)), .cin(limb_216_1465), .value(limb_216_1468));
    assign limb_216_1469 = limb_216_1468[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1470 = limb_216_1468[32]; // decl: <none>; prim: <none>
    assign limb_216_1471 = tmp_workload_top_int_512__315_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_216_1472 = s8_norm_shift_234_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1473Core rtlzz_owner_1473(.a(32'(limb_216_1471)), .b(32'(limb_216_1472)), .cin(limb_216_1470), .value(limb_216_1473));
    assign limb_216_1474 = limb_216_1473[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1475 = limb_216_1473[32]; // decl: <none>; prim: <none>
    assign limb_216_1476 = tmp_workload_top_int_512__315_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_216_1477 = s8_norm_shift_234_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1478Core rtlzz_owner_1478(.a(32'(limb_216_1476)), .b(32'(limb_216_1477)), .cin(limb_216_1475), .value(limb_216_1478));
    assign limb_216_1479 = limb_216_1478[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1480 = limb_216_1478[32]; // decl: <none>; prim: <none>
    assign limb_216_1481 = tmp_workload_top_int_512__315_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_216_1482 = s8_norm_shift_234_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1483Core rtlzz_owner_1483(.a(32'(limb_216_1481)), .b(32'(limb_216_1482)), .cin(limb_216_1480), .value(limb_216_1483));
    assign limb_216_1484 = limb_216_1483[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1485 = limb_216_1483[32]; // decl: <none>; prim: <none>
    assign limb_216_1486 = tmp_workload_top_int_512__315_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_216_1487 = s8_norm_shift_234_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1488Core rtlzz_owner_1488(.a(32'(limb_216_1486)), .b(32'(limb_216_1487)), .cin(limb_216_1485), .value(limb_216_1488));
    assign limb_216_1489 = limb_216_1488[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1490 = limb_216_1488[32]; // decl: <none>; prim: <none>
    assign limb_216_1491 = tmp_workload_top_int_512__315_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_216_1492 = s8_norm_shift_234_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1493Core rtlzz_owner_1493(.a(32'(limb_216_1491)), .b(32'(limb_216_1492)), .cin(limb_216_1490), .value(limb_216_1493));
    assign limb_216_1494 = limb_216_1493[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1495 = limb_216_1493[32]; // decl: <none>; prim: <none>
    assign limb_216_1496 = tmp_workload_top_int_512__315_v0[287:256]; // decl: <none>; prim: <none>
    assign limb_216_1497 = s8_norm_shift_234_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1498Core rtlzz_owner_1498(.a(32'(limb_216_1496)), .b(32'(limb_216_1497)), .cin(limb_216_1495), .value(limb_216_1498));
    assign limb_216_1499 = limb_216_1498[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1500 = limb_216_1498[32]; // decl: <none>; prim: <none>
    assign limb_216_1501 = tmp_workload_top_int_512__315_v0[319:288]; // decl: <none>; prim: <none>
    assign limb_216_1502 = s8_norm_shift_234_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1503Core rtlzz_owner_1503(.a(32'(limb_216_1501)), .b(32'(limb_216_1502)), .cin(limb_216_1500), .value(limb_216_1503));
    assign limb_216_1504 = limb_216_1503[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1505 = limb_216_1503[32]; // decl: <none>; prim: <none>
    assign limb_216_1506 = tmp_workload_top_int_512__315_v0[351:320]; // decl: <none>; prim: <none>
    assign limb_216_1507 = s8_norm_shift_234_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1508Core rtlzz_owner_1508(.a(32'(limb_216_1506)), .b(32'(limb_216_1507)), .cin(limb_216_1505), .value(limb_216_1508));
    assign limb_216_1509 = limb_216_1508[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1510 = limb_216_1508[32]; // decl: <none>; prim: <none>
    assign limb_216_1511 = tmp_workload_top_int_512__315_v0[383:352]; // decl: <none>; prim: <none>
    assign limb_216_1512 = s8_norm_shift_234_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1513Core rtlzz_owner_1513(.a(32'(limb_216_1511)), .b(32'(limb_216_1512)), .cin(limb_216_1510), .value(limb_216_1513));
    assign limb_216_1514 = limb_216_1513[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1515 = limb_216_1513[32]; // decl: <none>; prim: <none>
    assign limb_216_1516 = tmp_workload_top_int_512__315_v0[415:384]; // decl: <none>; prim: <none>
    assign limb_216_1517 = s8_norm_shift_234_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1518Core rtlzz_owner_1518(.a(32'(limb_216_1516)), .b(32'(limb_216_1517)), .cin(limb_216_1515), .value(limb_216_1518));
    assign limb_216_1519 = limb_216_1518[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1520 = limb_216_1518[32]; // decl: <none>; prim: <none>
    assign limb_216_1521 = tmp_workload_top_int_512__315_v0[447:416]; // decl: <none>; prim: <none>
    assign limb_216_1522 = s8_norm_shift_234_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1523Core rtlzz_owner_1523(.a(32'(limb_216_1521)), .b(32'(limb_216_1522)), .cin(limb_216_1520), .value(limb_216_1523));
    assign limb_216_1524 = limb_216_1523[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1525 = limb_216_1523[32]; // decl: <none>; prim: <none>
    assign limb_216_1526 = tmp_workload_top_int_512__315_v0[479:448]; // decl: <none>; prim: <none>
    assign limb_216_1527 = s8_norm_shift_234_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1528Core rtlzz_owner_1528(.a(32'(limb_216_1526)), .b(32'(limb_216_1527)), .cin(limb_216_1525), .value(limb_216_1528));
    assign limb_216_1529 = limb_216_1528[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1530 = limb_216_1528[32]; // decl: <none>; prim: <none>
    assign limb_216_1531 = tmp_workload_top_int_512__315_v0[511:480]; // decl: <none>; prim: <none>
    assign limb_216_1532 = s8_norm_shift_234_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1533Core rtlzz_owner_1533(.a(32'(limb_216_1531)), .b(32'(limb_216_1532)), .cin(limb_216_1530), .value(limb_216_1533[31:0]));
    assign limb_216_1533[32:32] = '0;
    assign limb_216_1534 = limb_216_1533[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1535 = {limb_216_1534, limb_216_1529, limb_216_1524, limb_216_1519, limb_216_1514, limb_216_1509, limb_216_1504, limb_216_1499, limb_216_1494, limb_216_1489, limb_216_1484, limb_216_1479, limb_216_1474, limb_216_1469, limb_216_1464, limb_216_1459}; // decl: <none>; prim: <none>
    assign limb_217_1536 = __beopt_width_292[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1537 = s8_norm_shift_231_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1538Core rtlzz_owner_1538(.a(32'(limb_217_1536)), .b(32'(limb_217_1537)), .cin(1'h0), .value(limb_217_1538));
    assign limb_217_1539 = limb_217_1538[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1540 = limb_217_1538[32]; // decl: <none>; prim: <none>
    assign limb_217_1541 = __beopt_width_292[63:32]; // decl: <none>; prim: <none>
    assign limb_217_1542 = s8_norm_shift_231_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1543Core rtlzz_owner_1543(.a(32'(limb_217_1541)), .b(32'(limb_217_1542)), .cin(limb_217_1540), .value(limb_217_1543));
    assign limb_217_1544 = limb_217_1543[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1545 = limb_217_1543[32]; // decl: <none>; prim: <none>
    assign limb_217_1546 = __beopt_width_292[95:64]; // decl: <none>; prim: <none>
    assign limb_217_1547 = s8_norm_shift_231_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1548Core rtlzz_owner_1548(.a(32'(limb_217_1546)), .b(32'(limb_217_1547)), .cin(limb_217_1545), .value(limb_217_1548));
    assign limb_217_1549 = limb_217_1548[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1550 = limb_217_1548[32]; // decl: <none>; prim: <none>
    assign limb_217_1551 = __beopt_width_292[127:96]; // decl: <none>; prim: <none>
    assign limb_217_1552 = s8_norm_shift_231_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1553Core rtlzz_owner_1553(.a(32'(limb_217_1551)), .b(32'(limb_217_1552)), .cin(limb_217_1550), .value(limb_217_1553));
    assign limb_217_1554 = limb_217_1553[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1555 = limb_217_1553[32]; // decl: <none>; prim: <none>
    assign limb_217_1556 = __beopt_width_292[159:128]; // decl: <none>; prim: <none>
    assign limb_217_1557 = s8_norm_shift_231_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1558Core rtlzz_owner_1558(.a(32'(limb_217_1556)), .b(32'(limb_217_1557)), .cin(limb_217_1555), .value(limb_217_1558));
    assign limb_217_1559 = limb_217_1558[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1560 = limb_217_1558[32]; // decl: <none>; prim: <none>
    assign limb_217_1561 = __beopt_width_292[191:160]; // decl: <none>; prim: <none>
    assign limb_217_1562 = s8_norm_shift_231_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1563Core rtlzz_owner_1563(.a(32'(limb_217_1561)), .b(32'(limb_217_1562)), .cin(limb_217_1560), .value(limb_217_1563));
    assign limb_217_1564 = limb_217_1563[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1565 = limb_217_1563[32]; // decl: <none>; prim: <none>
    assign limb_217_1566 = __beopt_width_292[223:192]; // decl: <none>; prim: <none>
    assign limb_217_1567 = s8_norm_shift_231_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1568Core rtlzz_owner_1568(.a(32'(limb_217_1566)), .b(32'(limb_217_1567)), .cin(limb_217_1565), .value(limb_217_1568));
    assign limb_217_1569 = limb_217_1568[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1570 = limb_217_1568[32]; // decl: <none>; prim: <none>
    assign limb_217_1571 = __beopt_width_292[255:224]; // decl: <none>; prim: <none>
    assign limb_217_1572 = s8_norm_shift_231_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1573Core rtlzz_owner_1573(.a(32'(limb_217_1571)), .b(32'(limb_217_1572)), .cin(limb_217_1570), .value(limb_217_1573));
    assign limb_217_1574 = limb_217_1573[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1575 = limb_217_1573[32]; // decl: <none>; prim: <none>
    assign limb_217_1576 = __beopt_width_292[287:256]; // decl: <none>; prim: <none>
    assign limb_217_1577 = s8_norm_shift_231_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1578Core rtlzz_owner_1578(.a(32'(limb_217_1576)), .b(32'(limb_217_1577)), .cin(limb_217_1575), .value(limb_217_1578));
    assign limb_217_1579 = limb_217_1578[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1580 = limb_217_1578[32]; // decl: <none>; prim: <none>
    assign limb_217_1581 = __beopt_width_292[319:288]; // decl: <none>; prim: <none>
    assign limb_217_1582 = s8_norm_shift_231_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1583Core rtlzz_owner_1583(.a(32'(limb_217_1581)), .b(32'(limb_217_1582)), .cin(limb_217_1580), .value(limb_217_1583));
    assign limb_217_1584 = limb_217_1583[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1585 = limb_217_1583[32]; // decl: <none>; prim: <none>
    assign limb_217_1586 = __beopt_width_292[351:320]; // decl: <none>; prim: <none>
    assign limb_217_1587 = s8_norm_shift_231_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1588Core rtlzz_owner_1588(.a(32'(limb_217_1586)), .b(32'(limb_217_1587)), .cin(limb_217_1585), .value(limb_217_1588));
    assign limb_217_1589 = limb_217_1588[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1590 = limb_217_1588[32]; // decl: <none>; prim: <none>
    assign limb_217_1591 = __beopt_width_292[383:352]; // decl: <none>; prim: <none>
    assign limb_217_1592 = s8_norm_shift_231_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1593Core rtlzz_owner_1593(.a(32'(limb_217_1591)), .b(32'(limb_217_1592)), .cin(limb_217_1590), .value(limb_217_1593));
    assign limb_217_1594 = limb_217_1593[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1595 = limb_217_1593[32]; // decl: <none>; prim: <none>
    assign limb_217_1596 = __beopt_width_292[415:384]; // decl: <none>; prim: <none>
    assign limb_217_1597 = s8_norm_shift_231_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1598Core rtlzz_owner_1598(.a(32'(limb_217_1596)), .b(32'(limb_217_1597)), .cin(limb_217_1595), .value(limb_217_1598));
    assign limb_217_1599 = limb_217_1598[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1600 = limb_217_1598[32]; // decl: <none>; prim: <none>
    assign limb_217_1601 = __beopt_width_292[447:416]; // decl: <none>; prim: <none>
    assign limb_217_1602 = s8_norm_shift_231_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1603Core rtlzz_owner_1603(.a(32'(limb_217_1601)), .b(32'(limb_217_1602)), .cin(limb_217_1600), .value(limb_217_1603));
    assign limb_217_1604 = limb_217_1603[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1605 = limb_217_1603[32]; // decl: <none>; prim: <none>
    assign limb_217_1606 = __beopt_width_292[479:448]; // decl: <none>; prim: <none>
    assign limb_217_1607 = s8_norm_shift_231_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1608Core rtlzz_owner_1608(.a(32'(limb_217_1606)), .b(32'(limb_217_1607)), .cin(limb_217_1605), .value(limb_217_1608));
    assign limb_217_1609 = limb_217_1608[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1610 = limb_217_1608[32]; // decl: <none>; prim: <none>
    assign limb_217_1611 = __beopt_width_292[511:480]; // decl: <none>; prim: <none>
    assign limb_217_1612 = s8_norm_shift_231_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1613Core rtlzz_owner_1613(.a(32'(limb_217_1611)), .b(32'(limb_217_1612)), .cin(limb_217_1610), .value(limb_217_1613[31:0]));
    assign limb_217_1613[32:32] = '0;
    assign limb_217_1614 = limb_217_1613[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1615 = {limb_217_1614, limb_217_1609, limb_217_1604, limb_217_1599, limb_217_1594, limb_217_1589, limb_217_1584, limb_217_1579, limb_217_1574, limb_217_1569, limb_217_1564, limb_217_1559, limb_217_1554, limb_217_1549, limb_217_1544, limb_217_1539}; // decl: <none>; prim: <none>
    assign limb_218_1616 = s8_norm_shift_223_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1617 = tmp_workload_top_int_258__299_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1618Core rtlzz_owner_1618(.a(32'(limb_218_1616)), .b(32'(limb_218_1617)), .cin(1'h0), .value(limb_218_1618));
    assign limb_218_1619 = limb_218_1618[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1620 = limb_218_1618[32]; // decl: <none>; prim: <none>
    assign limb_218_1621 = s8_norm_shift_223_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_218_1622 = tmp_workload_top_int_258__299_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1623Core rtlzz_owner_1623(.a(32'(limb_218_1621)), .b(32'(limb_218_1622)), .cin(limb_218_1620), .value(limb_218_1623));
    assign limb_218_1624 = limb_218_1623[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1625 = limb_218_1623[32]; // decl: <none>; prim: <none>
    assign limb_218_1626 = s8_norm_shift_223_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_218_1627 = tmp_workload_top_int_258__299_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1628Core rtlzz_owner_1628(.a(32'(limb_218_1626)), .b(32'(limb_218_1627)), .cin(limb_218_1625), .value(limb_218_1628));
    assign limb_218_1629 = limb_218_1628[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1630 = limb_218_1628[32]; // decl: <none>; prim: <none>
    assign limb_218_1631 = s8_norm_shift_223_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_218_1632 = tmp_workload_top_int_258__299_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1633Core rtlzz_owner_1633(.a(32'(limb_218_1631)), .b(32'(limb_218_1632)), .cin(limb_218_1630), .value(limb_218_1633));
    assign limb_218_1634 = limb_218_1633[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1635 = limb_218_1633[32]; // decl: <none>; prim: <none>
    assign limb_218_1636 = s8_norm_shift_223_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_218_1637 = tmp_workload_top_int_258__299_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1638Core rtlzz_owner_1638(.a(32'(limb_218_1636)), .b(32'(limb_218_1637)), .cin(limb_218_1635), .value(limb_218_1638));
    assign limb_218_1639 = limb_218_1638[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1640 = limb_218_1638[32]; // decl: <none>; prim: <none>
    assign limb_218_1641 = s8_norm_shift_223_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_218_1642 = tmp_workload_top_int_258__299_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1643Core rtlzz_owner_1643(.a(32'(limb_218_1641)), .b(32'(limb_218_1642)), .cin(limb_218_1640), .value(limb_218_1643));
    assign limb_218_1644 = limb_218_1643[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1645 = limb_218_1643[32]; // decl: <none>; prim: <none>
    assign limb_218_1646 = s8_norm_shift_223_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_218_1647 = tmp_workload_top_int_258__299_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1648Core rtlzz_owner_1648(.a(32'(limb_218_1646)), .b(32'(limb_218_1647)), .cin(limb_218_1645), .value(limb_218_1648));
    assign limb_218_1649 = limb_218_1648[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1650 = limb_218_1648[32]; // decl: <none>; prim: <none>
    assign limb_218_1651 = s8_norm_shift_223_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_218_1652 = tmp_workload_top_int_258__299_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1653Core rtlzz_owner_1653(.a(32'(limb_218_1651)), .b(32'(limb_218_1652)), .cin(limb_218_1650), .value(limb_218_1653));
    assign limb_218_1654 = limb_218_1653[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1655 = limb_218_1653[32]; // decl: <none>; prim: <none>
    assign limb_218_1656 = s8_norm_shift_223_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_1657 = tmp_workload_top_int_258__299_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1658Core rtlzz_owner_1658(.a(2'(limb_218_1656)), .b(2'(limb_218_1657)), .cin(limb_218_1655), .value(limb_218_1658[1:0]));
    assign limb_218_1658[2:2] = '0;
    assign limb_218_1659 = limb_218_1658[1:0]; // decl: <none>; prim: <none>
    assign limb_218_1660 = {limb_218_1659, limb_218_1654, limb_218_1649, limb_218_1644, limb_218_1639, limb_218_1634, limb_218_1629, limb_218_1624, limb_218_1619}; // decl: <none>; prim: <none>
    assign limb_219_1661 = __beopt_width_295[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1662 = s8_norm_shift_220_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1663Core rtlzz_owner_1663(.a(32'(rtlzz_pipe_1661_s6)), .b(32'(limb_219_1662)), .cin(1'h0), .value(limb_219_1663));
    assign limb_219_1664 = limb_219_1663[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1665 = limb_219_1663[32]; // decl: <none>; prim: <none>
    assign limb_219_1666 = __beopt_width_295[63:32]; // decl: <none>; prim: <none>
    assign limb_219_1667 = s8_norm_shift_220_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1668Core rtlzz_owner_1668(.a(32'(rtlzz_pipe_1666_s6)), .b(32'(limb_219_1667)), .cin(limb_219_1665), .value(limb_219_1668));
    assign limb_219_1669 = limb_219_1668[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1670 = limb_219_1668[32]; // decl: <none>; prim: <none>
    assign limb_219_1671 = __beopt_width_295[95:64]; // decl: <none>; prim: <none>
    assign limb_219_1672 = s8_norm_shift_220_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1673Core rtlzz_owner_1673(.a(32'(rtlzz_pipe_1671_s6)), .b(32'(limb_219_1672)), .cin(limb_219_1670), .value(limb_219_1673));
    assign limb_219_1674 = limb_219_1673[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1675 = limb_219_1673[32]; // decl: <none>; prim: <none>
    assign limb_219_1676 = __beopt_width_295[127:96]; // decl: <none>; prim: <none>
    assign limb_219_1677 = s8_norm_shift_220_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1678Core rtlzz_owner_1678(.a(32'(rtlzz_pipe_1676_s6)), .b(32'(limb_219_1677)), .cin(limb_219_1675), .value(limb_219_1678));
    assign limb_219_1679 = limb_219_1678[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1680 = limb_219_1678[32]; // decl: <none>; prim: <none>
    assign limb_219_1681 = __beopt_width_295[159:128]; // decl: <none>; prim: <none>
    assign limb_219_1682 = s8_norm_shift_220_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1683Core rtlzz_owner_1683(.a(32'(rtlzz_pipe_1681_s6)), .b(32'(limb_219_1682)), .cin(limb_219_1680), .value(limb_219_1683));
    assign limb_219_1684 = limb_219_1683[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1685 = limb_219_1683[32]; // decl: <none>; prim: <none>
    assign limb_219_1686 = __beopt_width_295[191:160]; // decl: <none>; prim: <none>
    assign limb_219_1687 = s8_norm_shift_220_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1688Core rtlzz_owner_1688(.a(32'(rtlzz_pipe_1686_s6)), .b(32'(limb_219_1687)), .cin(limb_219_1685), .value(limb_219_1688));
    assign limb_219_1689 = limb_219_1688[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1690 = limb_219_1688[32]; // decl: <none>; prim: <none>
    assign limb_219_1691 = __beopt_width_295[223:192]; // decl: <none>; prim: <none>
    assign limb_219_1692 = s8_norm_shift_220_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1693Core rtlzz_owner_1693(.a(32'(rtlzz_pipe_1691_s6)), .b(32'(limb_219_1692)), .cin(limb_219_1690), .value(limb_219_1693));
    assign limb_219_1694 = limb_219_1693[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1695 = limb_219_1693[32]; // decl: <none>; prim: <none>
    assign limb_219_1696 = __beopt_width_295[255:224]; // decl: <none>; prim: <none>
    assign limb_219_1697 = s8_norm_shift_220_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1698Core rtlzz_owner_1698(.a(32'(rtlzz_pipe_1696_s6)), .b(32'(limb_219_1697)), .cin(limb_219_1695), .value(limb_219_1698));
    assign limb_219_1699 = limb_219_1698[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1700 = limb_219_1698[32]; // decl: <none>; prim: <none>
    assign limb_219_1701 = __beopt_width_295[257:256]; // decl: <none>; prim: <none>
    assign limb_219_1702 = s8_norm_shift_220_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1703Core rtlzz_owner_1703(.a(2'(rtlzz_pipe_1701_s6)), .b(2'(limb_219_1702)), .cin(limb_219_1700), .value(limb_219_1703[1:0]));
    assign limb_219_1703[2:2] = '0;
    assign limb_219_1704 = limb_219_1703[1:0]; // decl: <none>; prim: <none>
    assign limb_219_1705 = {limb_219_1704, limb_219_1699, limb_219_1694, limb_219_1689, limb_219_1684, limb_219_1679, limb_219_1674, limb_219_1669, limb_219_1664}; // decl: <none>; prim: <none>
    assign limb_220_1706 = tmp_workload_top_int_256__164_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1707 = s8_norm_shift_126_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1708Core rtlzz_owner_1708(.a(32'(limb_220_1706)), .b(32'(limb_220_1707)), .cin(1'h0), .value(limb_220_1708));
    assign limb_220_1709 = limb_220_1708[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1710 = limb_220_1708[32]; // decl: <none>; prim: <none>
    assign limb_220_1711 = tmp_workload_top_int_256__164_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_220_1712 = s8_norm_shift_126_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1713Core rtlzz_owner_1713(.a(32'(limb_220_1711)), .b(32'(limb_220_1712)), .cin(limb_220_1710), .value(limb_220_1713));
    assign limb_220_1714 = limb_220_1713[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1715 = limb_220_1713[32]; // decl: <none>; prim: <none>
    assign limb_220_1716 = tmp_workload_top_int_256__164_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_220_1717 = s8_norm_shift_126_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1718Core rtlzz_owner_1718(.a(32'(limb_220_1716)), .b(32'(limb_220_1717)), .cin(limb_220_1715), .value(limb_220_1718));
    assign limb_220_1719 = limb_220_1718[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1720 = limb_220_1718[32]; // decl: <none>; prim: <none>
    assign limb_220_1721 = tmp_workload_top_int_256__164_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_220_1722 = s8_norm_shift_126_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1723Core rtlzz_owner_1723(.a(32'(limb_220_1721)), .b(32'(limb_220_1722)), .cin(limb_220_1720), .value(limb_220_1723));
    assign limb_220_1724 = limb_220_1723[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1725 = limb_220_1723[32]; // decl: <none>; prim: <none>
    assign limb_220_1726 = tmp_workload_top_int_256__164_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_220_1727 = s8_norm_shift_126_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1728Core rtlzz_owner_1728(.a(32'(limb_220_1726)), .b(32'(limb_220_1727)), .cin(limb_220_1725), .value(limb_220_1728));
    assign limb_220_1729 = limb_220_1728[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1730 = limb_220_1728[32]; // decl: <none>; prim: <none>
    assign limb_220_1731 = tmp_workload_top_int_256__164_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_220_1732 = s8_norm_shift_126_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1733Core rtlzz_owner_1733(.a(32'(limb_220_1731)), .b(32'(limb_220_1732)), .cin(limb_220_1730), .value(limb_220_1733));
    assign limb_220_1734 = limb_220_1733[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1735 = limb_220_1733[32]; // decl: <none>; prim: <none>
    assign limb_220_1736 = tmp_workload_top_int_256__164_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_220_1737 = s8_norm_shift_126_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1738Core rtlzz_owner_1738(.a(32'(limb_220_1736)), .b(32'(limb_220_1737)), .cin(limb_220_1735), .value(limb_220_1738));
    assign limb_220_1739 = limb_220_1738[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1740 = limb_220_1738[32]; // decl: <none>; prim: <none>
    assign limb_220_1741 = tmp_workload_top_int_256__164_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_220_1742 = s8_norm_shift_126_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1743Core rtlzz_owner_1743(.a(32'(limb_220_1741)), .b(32'(limb_220_1742)), .cin(limb_220_1740), .value(limb_220_1743[31:0]));
    assign limb_220_1743[32:32] = '0;
    assign limb_220_1744 = limb_220_1743[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1745 = {limb_220_1744, limb_220_1739, limb_220_1734, limb_220_1729, limb_220_1724, limb_220_1719, limb_220_1714, limb_220_1709}; // decl: <none>; prim: <none>
    assign limb_221_1746 = __beopt_width_299[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1747 = s8_norm_shift_123_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1748Core rtlzz_owner_1748(.a(32'(limb_221_1746)), .b(32'(limb_221_1747)), .cin(1'h0), .value(limb_221_1748));
    assign limb_221_1749 = limb_221_1748[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1750 = limb_221_1748[32]; // decl: <none>; prim: <none>
    assign limb_221_1751 = __beopt_width_299[63:32]; // decl: <none>; prim: <none>
    assign limb_221_1752 = s8_norm_shift_123_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1753Core rtlzz_owner_1753(.a(32'(limb_221_1751)), .b(32'(limb_221_1752)), .cin(limb_221_1750), .value(limb_221_1753));
    assign limb_221_1754 = limb_221_1753[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1755 = limb_221_1753[32]; // decl: <none>; prim: <none>
    assign limb_221_1756 = __beopt_width_299[95:64]; // decl: <none>; prim: <none>
    assign limb_221_1757 = s8_norm_shift_123_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1758Core rtlzz_owner_1758(.a(32'(limb_221_1756)), .b(32'(limb_221_1757)), .cin(limb_221_1755), .value(limb_221_1758));
    assign limb_221_1759 = limb_221_1758[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1760 = limb_221_1758[32]; // decl: <none>; prim: <none>
    assign limb_221_1761 = __beopt_width_299[127:96]; // decl: <none>; prim: <none>
    assign limb_221_1762 = s8_norm_shift_123_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1763Core rtlzz_owner_1763(.a(32'(limb_221_1761)), .b(32'(limb_221_1762)), .cin(limb_221_1760), .value(limb_221_1763));
    assign limb_221_1764 = limb_221_1763[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1765 = limb_221_1763[32]; // decl: <none>; prim: <none>
    assign limb_221_1766 = __beopt_width_299[159:128]; // decl: <none>; prim: <none>
    assign limb_221_1767 = s8_norm_shift_123_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1768Core rtlzz_owner_1768(.a(32'(limb_221_1766)), .b(32'(limb_221_1767)), .cin(limb_221_1765), .value(limb_221_1768));
    assign limb_221_1769 = limb_221_1768[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1770 = limb_221_1768[32]; // decl: <none>; prim: <none>
    assign limb_221_1771 = __beopt_width_299[191:160]; // decl: <none>; prim: <none>
    assign limb_221_1772 = s8_norm_shift_123_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1773Core rtlzz_owner_1773(.a(32'(limb_221_1771)), .b(32'(limb_221_1772)), .cin(limb_221_1770), .value(limb_221_1773));
    assign limb_221_1774 = limb_221_1773[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1775 = limb_221_1773[32]; // decl: <none>; prim: <none>
    assign limb_221_1776 = __beopt_width_299[223:192]; // decl: <none>; prim: <none>
    assign limb_221_1777 = s8_norm_shift_123_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1778Core rtlzz_owner_1778(.a(32'(limb_221_1776)), .b(32'(limb_221_1777)), .cin(limb_221_1775), .value(limb_221_1778));
    assign limb_221_1779 = limb_221_1778[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1780 = limb_221_1778[32]; // decl: <none>; prim: <none>
    assign limb_221_1781 = __beopt_width_299[255:224]; // decl: <none>; prim: <none>
    assign limb_221_1782 = s8_norm_shift_123_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1783Core rtlzz_owner_1783(.a(32'(limb_221_1781)), .b(32'(limb_221_1782)), .cin(limb_221_1780), .value(limb_221_1783[31:0]));
    assign limb_221_1783[32:32] = '0;
    assign limb_221_1784 = limb_221_1783[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1785 = {limb_221_1784, limb_221_1779, limb_221_1774, limb_221_1769, limb_221_1764, limb_221_1759, limb_221_1754, limb_221_1749}; // decl: <none>; prim: <none>
    assign limb_222_1786 = tmp_workload_top_int_256__79_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1787 = s8_norm_shift_64_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1788Core rtlzz_owner_1788(.a(32'(limb_222_1786)), .b(32'(limb_222_1787)), .cin(1'h0), .value(limb_222_1788));
    assign limb_222_1789 = limb_222_1788[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1790 = limb_222_1788[32]; // decl: <none>; prim: <none>
    assign limb_222_1791 = tmp_workload_top_int_256__79_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_222_1792 = s8_norm_shift_64_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1793Core rtlzz_owner_1793(.a(32'(limb_222_1791)), .b(32'(limb_222_1792)), .cin(limb_222_1790), .value(limb_222_1793));
    assign limb_222_1794 = limb_222_1793[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1795 = limb_222_1793[32]; // decl: <none>; prim: <none>
    assign limb_222_1796 = tmp_workload_top_int_256__79_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_222_1797 = s8_norm_shift_64_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1798Core rtlzz_owner_1798(.a(32'(limb_222_1796)), .b(32'(limb_222_1797)), .cin(limb_222_1795), .value(limb_222_1798));
    assign limb_222_1799 = limb_222_1798[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1800 = limb_222_1798[32]; // decl: <none>; prim: <none>
    assign limb_222_1801 = tmp_workload_top_int_256__79_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_222_1802 = s8_norm_shift_64_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1803Core rtlzz_owner_1803(.a(32'(limb_222_1801)), .b(32'(limb_222_1802)), .cin(limb_222_1800), .value(limb_222_1803));
    assign limb_222_1804 = limb_222_1803[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1805 = limb_222_1803[32]; // decl: <none>; prim: <none>
    assign limb_222_1806 = tmp_workload_top_int_256__79_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_222_1807 = s8_norm_shift_64_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1808Core rtlzz_owner_1808(.a(32'(limb_222_1806)), .b(32'(limb_222_1807)), .cin(limb_222_1805), .value(limb_222_1808));
    assign limb_222_1809 = limb_222_1808[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1810 = limb_222_1808[32]; // decl: <none>; prim: <none>
    assign limb_222_1811 = tmp_workload_top_int_256__79_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_222_1812 = s8_norm_shift_64_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1813Core rtlzz_owner_1813(.a(32'(limb_222_1811)), .b(32'(limb_222_1812)), .cin(limb_222_1810), .value(limb_222_1813));
    assign limb_222_1814 = limb_222_1813[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1815 = limb_222_1813[32]; // decl: <none>; prim: <none>
    assign limb_222_1816 = tmp_workload_top_int_256__79_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_222_1817 = s8_norm_shift_64_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1818Core rtlzz_owner_1818(.a(32'(limb_222_1816)), .b(32'(limb_222_1817)), .cin(limb_222_1815), .value(limb_222_1818));
    assign limb_222_1819 = limb_222_1818[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1820 = limb_222_1818[32]; // decl: <none>; prim: <none>
    assign limb_222_1821 = tmp_workload_top_int_256__79_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_222_1822 = s8_norm_shift_64_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1823Core rtlzz_owner_1823(.a(32'(limb_222_1821)), .b(32'(limb_222_1822)), .cin(limb_222_1820), .value(limb_222_1823[31:0]));
    assign limb_222_1823[32:32] = '0;
    assign limb_222_1824 = limb_222_1823[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1825 = {limb_222_1824, limb_222_1819, limb_222_1814, limb_222_1809, limb_222_1804, limb_222_1799, limb_222_1794, limb_222_1789}; // decl: <none>; prim: <none>
    assign limb_223_1826 = __beopt_width_302[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1827 = s8_norm_shift_61_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1828Core rtlzz_owner_1828(.a(32'(limb_223_1826)), .b(32'(limb_223_1827)), .cin(1'h0), .value(limb_223_1828));
    assign limb_223_1829 = limb_223_1828[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1830 = limb_223_1828[32]; // decl: <none>; prim: <none>
    assign limb_223_1831 = __beopt_width_302[63:32]; // decl: <none>; prim: <none>
    assign limb_223_1832 = s8_norm_shift_61_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1833Core rtlzz_owner_1833(.a(32'(limb_223_1831)), .b(32'(limb_223_1832)), .cin(limb_223_1830), .value(limb_223_1833));
    assign limb_223_1834 = limb_223_1833[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1835 = limb_223_1833[32]; // decl: <none>; prim: <none>
    assign limb_223_1836 = __beopt_width_302[95:64]; // decl: <none>; prim: <none>
    assign limb_223_1837 = s8_norm_shift_61_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1838Core rtlzz_owner_1838(.a(32'(limb_223_1836)), .b(32'(limb_223_1837)), .cin(limb_223_1835), .value(limb_223_1838));
    assign limb_223_1839 = limb_223_1838[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1840 = limb_223_1838[32]; // decl: <none>; prim: <none>
    assign limb_223_1841 = __beopt_width_302[127:96]; // decl: <none>; prim: <none>
    assign limb_223_1842 = s8_norm_shift_61_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1843Core rtlzz_owner_1843(.a(32'(limb_223_1841)), .b(32'(limb_223_1842)), .cin(limb_223_1840), .value(limb_223_1843));
    assign limb_223_1844 = limb_223_1843[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1845 = limb_223_1843[32]; // decl: <none>; prim: <none>
    assign limb_223_1846 = __beopt_width_302[159:128]; // decl: <none>; prim: <none>
    assign limb_223_1847 = s8_norm_shift_61_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1848Core rtlzz_owner_1848(.a(32'(limb_223_1846)), .b(32'(limb_223_1847)), .cin(limb_223_1845), .value(limb_223_1848));
    assign limb_223_1849 = limb_223_1848[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1850 = limb_223_1848[32]; // decl: <none>; prim: <none>
    assign limb_223_1851 = __beopt_width_302[191:160]; // decl: <none>; prim: <none>
    assign limb_223_1852 = s8_norm_shift_61_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1853Core rtlzz_owner_1853(.a(32'(limb_223_1851)), .b(32'(limb_223_1852)), .cin(limb_223_1850), .value(limb_223_1853));
    assign limb_223_1854 = limb_223_1853[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1855 = limb_223_1853[32]; // decl: <none>; prim: <none>
    assign limb_223_1856 = __beopt_width_302[223:192]; // decl: <none>; prim: <none>
    assign limb_223_1857 = s8_norm_shift_61_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1858Core rtlzz_owner_1858(.a(32'(limb_223_1856)), .b(32'(limb_223_1857)), .cin(limb_223_1855), .value(limb_223_1858));
    assign limb_223_1859 = limb_223_1858[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1860 = limb_223_1858[32]; // decl: <none>; prim: <none>
    assign limb_223_1861 = __beopt_width_302[255:224]; // decl: <none>; prim: <none>
    assign limb_223_1862 = s8_norm_shift_61_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1863Core rtlzz_owner_1863(.a(32'(limb_223_1861)), .b(32'(limb_223_1862)), .cin(limb_223_1860), .value(limb_223_1863[31:0]));
    assign limb_223_1863[32:32] = '0;
    assign limb_223_1864 = limb_223_1863[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1865 = {limb_223_1864, limb_223_1859, limb_223_1854, limb_223_1849, limb_223_1844, limb_223_1839, limb_223_1834, limb_223_1829}; // decl: <none>; prim: <none>
    assign limb_224_1866 = tmp_workload_top_int_132__283_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1867 = s8_norm_shift_212_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1868Core rtlzz_owner_1868(.a(32'(rtlzz_pipe_1866_s6)), .b(32'(limb_224_1867)), .cin(1'h0), .value(limb_224_1868));
    assign limb_224_1869 = limb_224_1868[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1870 = limb_224_1868[32]; // decl: <none>; prim: <none>
    assign limb_224_1871 = tmp_workload_top_int_132__283_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_224_1872 = s8_norm_shift_212_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1873Core rtlzz_owner_1873(.a(32'(rtlzz_pipe_1871_s6)), .b(32'(limb_224_1872)), .cin(limb_224_1870), .value(limb_224_1873));
    assign limb_224_1874 = limb_224_1873[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1875 = limb_224_1873[32]; // decl: <none>; prim: <none>
    assign limb_224_1876 = tmp_workload_top_int_132__283_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_224_1877 = s8_norm_shift_212_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1878Core rtlzz_owner_1878(.a(32'(rtlzz_pipe_1876_s6)), .b(32'(limb_224_1877)), .cin(limb_224_1875), .value(limb_224_1878));
    assign limb_224_1879 = limb_224_1878[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1880 = limb_224_1878[32]; // decl: <none>; prim: <none>
    assign limb_224_1881 = tmp_workload_top_int_132__283_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_224_1882 = s8_norm_shift_212_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1883Core rtlzz_owner_1883(.a(32'(rtlzz_pipe_1881_s6)), .b(32'(limb_224_1882)), .cin(limb_224_1880), .value(limb_224_1883));
    assign limb_224_1884 = limb_224_1883[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1885 = limb_224_1883[32]; // decl: <none>; prim: <none>
    assign limb_224_1886 = tmp_workload_top_int_132__283_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_1887 = s8_norm_shift_212_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1888Core rtlzz_owner_1888(.a(4'(rtlzz_pipe_1886_s6)), .b(4'(limb_224_1887)), .cin(limb_224_1885), .value(limb_224_1888[3:0]));
    assign limb_224_1888[4:4] = '0;
    assign limb_224_1889 = limb_224_1888[3:0]; // decl: <none>; prim: <none>
    assign limb_224_1890 = {limb_224_1889, limb_224_1884, limb_224_1879, limb_224_1874, limb_224_1869}; // decl: <none>; prim: <none>
    assign limb_225_1891 = __beopt_width_305[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1892 = s8_norm_shift_209_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1893Core rtlzz_owner_1893(.a(32'(limb_225_1891)), .b(32'(limb_225_1892)), .cin(1'h0), .value(limb_225_1893));
    assign limb_225_1894 = limb_225_1893[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1895 = limb_225_1893[32]; // decl: <none>; prim: <none>
    assign limb_225_1896 = __beopt_width_305[63:32]; // decl: <none>; prim: <none>
    assign limb_225_1897 = s8_norm_shift_209_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1898Core rtlzz_owner_1898(.a(32'(limb_225_1896)), .b(32'(limb_225_1897)), .cin(limb_225_1895), .value(limb_225_1898));
    assign limb_225_1899 = limb_225_1898[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1900 = limb_225_1898[32]; // decl: <none>; prim: <none>
    assign limb_225_1901 = __beopt_width_305[95:64]; // decl: <none>; prim: <none>
    assign limb_225_1902 = s8_norm_shift_209_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1903Core rtlzz_owner_1903(.a(32'(limb_225_1901)), .b(32'(limb_225_1902)), .cin(limb_225_1900), .value(limb_225_1903));
    assign limb_225_1904 = limb_225_1903[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1905 = limb_225_1903[32]; // decl: <none>; prim: <none>
    assign limb_225_1906 = __beopt_width_305[127:96]; // decl: <none>; prim: <none>
    assign limb_225_1907 = s8_norm_shift_209_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1908Core rtlzz_owner_1908(.a(32'(limb_225_1906)), .b(32'(limb_225_1907)), .cin(limb_225_1905), .value(limb_225_1908));
    assign limb_225_1909 = limb_225_1908[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1910 = limb_225_1908[32]; // decl: <none>; prim: <none>
    assign limb_225_1911 = __beopt_width_305[131:128]; // decl: <none>; prim: <none>
    assign limb_225_1912 = s8_norm_shift_209_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1913Core rtlzz_owner_1913(.a(4'(limb_225_1911)), .b(4'(limb_225_1912)), .cin(limb_225_1910), .value(limb_225_1913[3:0]));
    assign limb_225_1913[4:4] = '0;
    assign limb_225_1914 = limb_225_1913[3:0]; // decl: <none>; prim: <none>
    assign limb_225_1915 = {limb_225_1914, limb_225_1909, limb_225_1904, limb_225_1899, limb_225_1894}; // decl: <none>; prim: <none>
    assign limb_226_1916 = tmp_workload_top_int_130__223_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1917 = s8_norm_shift_169_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1918Core rtlzz_owner_1918(.a(32'(limb_226_1916)), .b(32'(limb_226_1917)), .cin(1'h0), .value(limb_226_1918));
    assign limb_226_1919 = limb_226_1918[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1920 = limb_226_1918[32]; // decl: <none>; prim: <none>
    assign limb_226_1921 = tmp_workload_top_int_130__223_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_226_1922 = s8_norm_shift_169_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1923Core rtlzz_owner_1923(.a(32'(limb_226_1921)), .b(32'(limb_226_1922)), .cin(limb_226_1920), .value(limb_226_1923));
    assign limb_226_1924 = limb_226_1923[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1925 = limb_226_1923[32]; // decl: <none>; prim: <none>
    assign limb_226_1926 = tmp_workload_top_int_130__223_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_226_1927 = s8_norm_shift_169_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1928Core rtlzz_owner_1928(.a(32'(limb_226_1926)), .b(32'(limb_226_1927)), .cin(limb_226_1925), .value(limb_226_1928));
    assign limb_226_1929 = limb_226_1928[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1930 = limb_226_1928[32]; // decl: <none>; prim: <none>
    assign limb_226_1931 = tmp_workload_top_int_130__223_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_226_1932 = s8_norm_shift_169_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1933Core rtlzz_owner_1933(.a(32'(limb_226_1931)), .b(32'(limb_226_1932)), .cin(limb_226_1930), .value(limb_226_1933));
    assign limb_226_1934 = limb_226_1933[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1935 = limb_226_1933[32]; // decl: <none>; prim: <none>
    assign limb_226_1936 = tmp_workload_top_int_130__223_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1937 = s8_norm_shift_169_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1938Core rtlzz_owner_1938(.a(2'(limb_226_1936)), .b(2'(limb_226_1937)), .cin(limb_226_1935), .value(limb_226_1938[1:0]));
    assign limb_226_1938[2:2] = '0;
    assign limb_226_1939 = limb_226_1938[1:0]; // decl: <none>; prim: <none>
    assign limb_226_1940 = {limb_226_1939, limb_226_1934, limb_226_1929, limb_226_1924, limb_226_1919}; // decl: <none>; prim: <none>
    assign limb_227_1941 = __beopt_width_309[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1942 = s8_norm_shift_166_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1943Core rtlzz_owner_1943(.a(32'(limb_227_1941)), .b(32'(limb_227_1942)), .cin(1'h0), .value(limb_227_1943));
    assign limb_227_1944 = limb_227_1943[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1945 = limb_227_1943[32]; // decl: <none>; prim: <none>
    assign limb_227_1946 = __beopt_width_309[63:32]; // decl: <none>; prim: <none>
    assign limb_227_1947 = s8_norm_shift_166_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1948Core rtlzz_owner_1948(.a(32'(limb_227_1946)), .b(32'(limb_227_1947)), .cin(limb_227_1945), .value(limb_227_1948));
    assign limb_227_1949 = limb_227_1948[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1950 = limb_227_1948[32]; // decl: <none>; prim: <none>
    assign limb_227_1951 = __beopt_width_309[95:64]; // decl: <none>; prim: <none>
    assign limb_227_1952 = s8_norm_shift_166_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1953Core rtlzz_owner_1953(.a(32'(limb_227_1951)), .b(32'(limb_227_1952)), .cin(limb_227_1950), .value(limb_227_1953));
    assign limb_227_1954 = limb_227_1953[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1955 = limb_227_1953[32]; // decl: <none>; prim: <none>
    assign limb_227_1956 = __beopt_width_309[127:96]; // decl: <none>; prim: <none>
    assign limb_227_1957 = s8_norm_shift_166_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1958Core rtlzz_owner_1958(.a(32'(limb_227_1956)), .b(32'(limb_227_1957)), .cin(limb_227_1955), .value(limb_227_1958));
    assign limb_227_1959 = limb_227_1958[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1960 = limb_227_1958[32]; // decl: <none>; prim: <none>
    assign limb_227_1961 = __beopt_width_309[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1962 = s8_norm_shift_166_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1963Core rtlzz_owner_1963(.a(2'(limb_227_1961)), .b(2'(limb_227_1962)), .cin(limb_227_1960), .value(limb_227_1963[1:0]));
    assign limb_227_1963[2:2] = '0;
    assign limb_227_1964 = limb_227_1963[1:0]; // decl: <none>; prim: <none>
    assign limb_227_1965 = {limb_227_1964, limb_227_1959, limb_227_1954, limb_227_1949, limb_227_1944}; // decl: <none>; prim: <none>
    assign limb_228_1966 = tmp_workload_top_int_130__148_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1967 = s8_norm_shift_115_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1968Core rtlzz_owner_1968(.a(32'(limb_228_1966)), .b(32'(limb_228_1967)), .cin(1'h0), .value(limb_228_1968));
    assign limb_228_1969 = limb_228_1968[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1970 = limb_228_1968[32]; // decl: <none>; prim: <none>
    assign limb_228_1971 = tmp_workload_top_int_130__148_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_228_1972 = s8_norm_shift_115_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1973Core rtlzz_owner_1973(.a(32'(limb_228_1971)), .b(32'(limb_228_1972)), .cin(limb_228_1970), .value(limb_228_1973));
    assign limb_228_1974 = limb_228_1973[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1975 = limb_228_1973[32]; // decl: <none>; prim: <none>
    assign limb_228_1976 = tmp_workload_top_int_130__148_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_228_1977 = s8_norm_shift_115_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1978Core rtlzz_owner_1978(.a(32'(limb_228_1976)), .b(32'(limb_228_1977)), .cin(limb_228_1975), .value(limb_228_1978));
    assign limb_228_1979 = limb_228_1978[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1980 = limb_228_1978[32]; // decl: <none>; prim: <none>
    assign limb_228_1981 = tmp_workload_top_int_130__148_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_228_1982 = s8_norm_shift_115_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1983Core rtlzz_owner_1983(.a(32'(limb_228_1981)), .b(32'(limb_228_1982)), .cin(limb_228_1980), .value(limb_228_1983));
    assign limb_228_1984 = limb_228_1983[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1985 = limb_228_1983[32]; // decl: <none>; prim: <none>
    assign limb_228_1986 = tmp_workload_top_int_130__148_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1987 = s8_norm_shift_115_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1988Core rtlzz_owner_1988(.a(2'(limb_228_1986)), .b(2'(limb_228_1987)), .cin(limb_228_1985), .value(limb_228_1988[1:0]));
    assign limb_228_1988[2:2] = '0;
    assign limb_228_1989 = limb_228_1988[1:0]; // decl: <none>; prim: <none>
    assign limb_228_1990 = {limb_228_1989, limb_228_1984, limb_228_1979, limb_228_1974, limb_228_1969}; // decl: <none>; prim: <none>
    assign limb_229_1991 = __beopt_width_311[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1992 = s8_norm_shift_112_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1993Core rtlzz_owner_1993(.a(32'(limb_229_1991)), .b(32'(limb_229_1992)), .cin(1'h0), .value(limb_229_1993));
    assign limb_229_1994 = limb_229_1993[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1995 = limb_229_1993[32]; // decl: <none>; prim: <none>
    assign limb_229_1996 = __beopt_width_311[63:32]; // decl: <none>; prim: <none>
    assign limb_229_1997 = s8_norm_shift_112_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1998Core rtlzz_owner_1998(.a(32'(limb_229_1996)), .b(32'(limb_229_1997)), .cin(limb_229_1995), .value(limb_229_1998));
    assign limb_229_1999 = limb_229_1998[31:0]; // decl: <none>; prim: <none>
    assign limb_229_2000 = limb_229_1998[32]; // decl: <none>; prim: <none>
    assign limb_229_2001 = __beopt_width_311[95:64]; // decl: <none>; prim: <none>
    assign limb_229_2002 = s8_norm_shift_112_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2003Core rtlzz_owner_2003(.a(32'(limb_229_2001)), .b(32'(limb_229_2002)), .cin(limb_229_2000), .value(limb_229_2003));
    assign limb_229_2004 = limb_229_2003[31:0]; // decl: <none>; prim: <none>
    assign limb_229_2005 = limb_229_2003[32]; // decl: <none>; prim: <none>
    assign limb_229_2006 = __beopt_width_311[127:96]; // decl: <none>; prim: <none>
    assign limb_229_2007 = s8_norm_shift_112_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2008Core rtlzz_owner_2008(.a(32'(limb_229_2006)), .b(32'(limb_229_2007)), .cin(limb_229_2005), .value(limb_229_2008));
    assign limb_229_2009 = limb_229_2008[31:0]; // decl: <none>; prim: <none>
    assign limb_229_2010 = limb_229_2008[32]; // decl: <none>; prim: <none>
    assign limb_229_2011 = __beopt_width_311[129:128]; // decl: <none>; prim: <none>
    assign limb_229_2012 = s8_norm_shift_112_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2013Core rtlzz_owner_2013(.a(2'(limb_229_2011)), .b(2'(limb_229_2012)), .cin(limb_229_2010), .value(limb_229_2013[1:0]));
    assign limb_229_2013[2:2] = '0;
    assign limb_229_2014 = limb_229_2013[1:0]; // decl: <none>; prim: <none>
    assign limb_229_2015 = {limb_229_2014, limb_229_2009, limb_229_2004, limb_229_1999, limb_229_1994}; // decl: <none>; prim: <none>
    assign limb_230_2016 = tmp_workload_top_int_130__63_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_230_2017 = s8_norm_shift_53_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2018Core rtlzz_owner_2018(.a(32'(limb_230_2016)), .b(32'(limb_230_2017)), .cin(1'h0), .value(limb_230_2018));
    assign limb_230_2019 = limb_230_2018[31:0]; // decl: <none>; prim: <none>
    assign limb_230_2020 = limb_230_2018[32]; // decl: <none>; prim: <none>
    assign limb_230_2021 = tmp_workload_top_int_130__63_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_230_2022 = s8_norm_shift_53_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2023Core rtlzz_owner_2023(.a(32'(limb_230_2021)), .b(32'(limb_230_2022)), .cin(limb_230_2020), .value(limb_230_2023));
    assign limb_230_2024 = limb_230_2023[31:0]; // decl: <none>; prim: <none>
    assign limb_230_2025 = limb_230_2023[32]; // decl: <none>; prim: <none>
    assign limb_230_2026 = tmp_workload_top_int_130__63_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_230_2027 = s8_norm_shift_53_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2028Core rtlzz_owner_2028(.a(32'(limb_230_2026)), .b(32'(limb_230_2027)), .cin(limb_230_2025), .value(limb_230_2028));
    assign limb_230_2029 = limb_230_2028[31:0]; // decl: <none>; prim: <none>
    assign limb_230_2030 = limb_230_2028[32]; // decl: <none>; prim: <none>
    assign limb_230_2031 = tmp_workload_top_int_130__63_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_230_2032 = s8_norm_shift_53_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2033Core rtlzz_owner_2033(.a(32'(limb_230_2031)), .b(32'(limb_230_2032)), .cin(limb_230_2030), .value(limb_230_2033));
    assign limb_230_2034 = limb_230_2033[31:0]; // decl: <none>; prim: <none>
    assign limb_230_2035 = limb_230_2033[32]; // decl: <none>; prim: <none>
    assign limb_230_2036 = tmp_workload_top_int_130__63_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_2037 = s8_norm_shift_53_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2038Core rtlzz_owner_2038(.a(2'(limb_230_2036)), .b(2'(limb_230_2037)), .cin(limb_230_2035), .value(limb_230_2038[1:0]));
    assign limb_230_2038[2:2] = '0;
    assign limb_230_2039 = limb_230_2038[1:0]; // decl: <none>; prim: <none>
    assign limb_230_2040 = {limb_230_2039, limb_230_2034, limb_230_2029, limb_230_2024, limb_230_2019}; // decl: <none>; prim: <none>
    assign limb_231_2041 = __beopt_width_315[31:0]; // decl: <none>; prim: <none>
    assign limb_231_2042 = s8_norm_shift_50_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2043Core rtlzz_owner_2043(.a(32'(limb_231_2041)), .b(32'(limb_231_2042)), .cin(1'h0), .value(limb_231_2043));
    assign limb_231_2044 = limb_231_2043[31:0]; // decl: <none>; prim: <none>
    assign limb_231_2045 = limb_231_2043[32]; // decl: <none>; prim: <none>
    assign limb_231_2046 = __beopt_width_315[63:32]; // decl: <none>; prim: <none>
    assign limb_231_2047 = s8_norm_shift_50_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2048Core rtlzz_owner_2048(.a(32'(limb_231_2046)), .b(32'(limb_231_2047)), .cin(limb_231_2045), .value(limb_231_2048));
    assign limb_231_2049 = limb_231_2048[31:0]; // decl: <none>; prim: <none>
    assign limb_231_2050 = limb_231_2048[32]; // decl: <none>; prim: <none>
    assign limb_231_2051 = __beopt_width_315[95:64]; // decl: <none>; prim: <none>
    assign limb_231_2052 = s8_norm_shift_50_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2053Core rtlzz_owner_2053(.a(32'(limb_231_2051)), .b(32'(limb_231_2052)), .cin(limb_231_2050), .value(limb_231_2053));
    assign limb_231_2054 = limb_231_2053[31:0]; // decl: <none>; prim: <none>
    assign limb_231_2055 = limb_231_2053[32]; // decl: <none>; prim: <none>
    assign limb_231_2056 = __beopt_width_315[127:96]; // decl: <none>; prim: <none>
    assign limb_231_2057 = s8_norm_shift_50_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2058Core rtlzz_owner_2058(.a(32'(limb_231_2056)), .b(32'(limb_231_2057)), .cin(limb_231_2055), .value(limb_231_2058));
    assign limb_231_2059 = limb_231_2058[31:0]; // decl: <none>; prim: <none>
    assign limb_231_2060 = limb_231_2058[32]; // decl: <none>; prim: <none>
    assign limb_231_2061 = __beopt_width_315[129:128]; // decl: <none>; prim: <none>
    assign limb_231_2062 = s8_norm_shift_50_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_2063Core rtlzz_owner_2063(.a(2'(limb_231_2061)), .b(2'(limb_231_2062)), .cin(limb_231_2060), .value(limb_231_2063[1:0]));
    assign limb_231_2063[2:2] = '0;
    assign limb_231_2064 = limb_231_2063[1:0]; // decl: <none>; prim: <none>
    assign limb_231_2065 = {limb_231_2064, limb_231_2059, limb_231_2054, limb_231_2049, limb_231_2044}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_265_s1 <= 65'h0;
            rtlzz_pipe_265_s2 <= 65'h0;
            rtlzz_pipe_265_s3 <= 65'h0;
            rtlzz_pipe_265_s4 <= 65'h0;
            rtlzz_pipe_265_s5 <= 65'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_270_s2 <= 128'h0;
            rtlzz_pipe_270_s3 <= 128'h0;
            rtlzz_pipe_270_s4 <= 128'h0;
            rtlzz_pipe_270_s5 <= 128'h0;
            rtlzz_pipe_270_s6 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_271_s3 <= 128'h0;
            rtlzz_pipe_271_s4 <= 128'h0;
            rtlzz_pipe_271_s5 <= 128'h0;
            rtlzz_pipe_271_s6 <= 128'h0;
            rtlzz_pipe_271_s7 <= 128'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_278_s1 <= 129'h0;
            rtlzz_pipe_278_s2 <= 129'h0;
            rtlzz_pipe_279_s1 <= 129'h0;
            rtlzz_pipe_279_s2 <= 129'h0;
            rtlzz_pipe_279_s3 <= 129'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_292_s3 <= 64'h0;
            rtlzz_pipe_292_s4 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_293_s3 <= 64'h0;
            rtlzz_pipe_293_s4 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s7 <= 64'h0;
            rtlzz_pipe_362_s5 <= 64'h0;
            rtlzz_pipe_366_s5 <= 96'h0;
            rtlzz_pipe_370_s5 <= 96'h0;
            rtlzz_pipe_374_s5 <= 128'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_10_s7 <= 256'h0;
            rtlzz_pipe_174_s6 <= 130'h0;
            rtlzz_pipe_387_s4 <= 64'h0;
            rtlzz_pipe_391_s4 <= 96'h0;
            rtlzz_pipe_395_s4 <= 96'h0;
            rtlzz_pipe_399_s4 <= 128'h0;
            rtlzz_pipe_11_s5 <= 256'h0;
            rtlzz_pipe_11_s6 <= 256'h0;
            rtlzz_pipe_11_s7 <= 256'h0;
            rtlzz_pipe_175_s5 <= 130'h0;
            rtlzz_pipe_175_s6 <= 130'h0;
            rtlzz_pipe_465_s6 <= 64'h0;
            rtlzz_pipe_469_s6 <= 96'h0;
            rtlzz_pipe_473_s6 <= 96'h0;
            rtlzz_pipe_477_s6 <= 128'h0;
            rtlzz_pipe_48_s7 <= 256'h0;
            rtlzz_pipe_719_s3 <= 32'h0;
            rtlzz_pipe_719_s4 <= 32'h0;
            rtlzz_pipe_724_s3 <= 32'h0;
            rtlzz_pipe_724_s4 <= 32'h0;
            rtlzz_pipe_729_s3 <= 1'h0;
            rtlzz_pipe_729_s4 <= 1'h0;
            rtlzz_pipe_164_s5 <= 66'h0;
            rtlzz_pipe_168_s5 <= 34'h0;
            rtlzz_pipe_266_s5 <= 64'h0;
            rtlzz_pipe_266_s6 <= 64'h0;
            rtlzz_pipe_298_s6 <= 33'h0;
            rtlzz_pipe_734_s5 <= 32'h0;
            rtlzz_pipe_739_s5 <= 32'h0;
            rtlzz_pipe_744_s5 <= 1'h0;
            rtlzz_pipe_267_s6 <= 64'h0;
            rtlzz_pipe_269_s6 <= 34'h0;
            rtlzz_pipe_299_s6 <= 33'h0;
            rtlzz_pipe_170_s7 <= 68'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_173_s7 <= 130'h0;
            rtlzz_pipe_750_s5 <= 32'h0;
            rtlzz_pipe_755_s5 <= 2'h0;
            rtlzz_pipe_304_s6 <= 34'h0;
            rtlzz_pipe_759_s6 <= 32'h0;
            rtlzz_pipe_764_s6 <= 2'h0;
            rtlzz_pipe_455_s7 <= 67'h0;
            rtlzz_pipe_458_s7 <= 69'h0;
            rtlzz_pipe_789_s7 <= 32'hffffffff;
            rtlzz_pipe_795_s7 <= 32'hffffffff;
            rtlzz_pipe_801_s7 <= 4'hf;
            rtlzz_pipe_807_s7 <= 32'hffffffff;
            rtlzz_pipe_813_s7 <= 32'hffffffff;
            rtlzz_pipe_819_s7 <= 32'hffffffff;
            rtlzz_pipe_825_s7 <= 32'hffffffff;
            rtlzz_pipe_831_s7 <= 2'h3;
            rtlzz_pipe_837_s7 <= 32'hffffffff;
            rtlzz_pipe_842_s7 <= 32'h0;
            rtlzz_pipe_849_s7 <= 32'hffffffff;
            rtlzz_pipe_854_s7 <= 32'h0;
            rtlzz_pipe_860_s7 <= 2'h0;
            rtlzz_pipe_866_s1 <= 32'h0;
            rtlzz_pipe_866_s2 <= 32'h0;
            rtlzz_pipe_866_s3 <= 32'h0;
            rtlzz_pipe_866_s4 <= 32'h0;
            rtlzz_pipe_866_s5 <= 32'h0;
            rtlzz_pipe_866_s6 <= 32'h0;
            rtlzz_pipe_871_s1 <= 32'h0;
            rtlzz_pipe_871_s2 <= 32'h0;
            rtlzz_pipe_871_s3 <= 32'h0;
            rtlzz_pipe_871_s4 <= 32'h0;
            rtlzz_pipe_871_s5 <= 32'h0;
            rtlzz_pipe_871_s6 <= 32'h0;
            rtlzz_pipe_876_s1 <= 1'h0;
            rtlzz_pipe_876_s2 <= 1'h0;
            rtlzz_pipe_876_s3 <= 1'h0;
            rtlzz_pipe_876_s4 <= 1'h0;
            rtlzz_pipe_876_s5 <= 1'h0;
            rtlzz_pipe_876_s6 <= 1'h0;
            rtlzz_pipe_184_s7 <= 34'h0;
            rtlzz_pipe_274_s7 <= 64'h0;
            rtlzz_pipe_276_s7 <= 34'h0;
            rtlzz_pipe_313_s7 <= 33'h0;
            rtlzz_pipe_881_s2 <= 32'h0;
            rtlzz_pipe_881_s3 <= 32'h0;
            rtlzz_pipe_881_s4 <= 32'h0;
            rtlzz_pipe_881_s5 <= 32'h0;
            rtlzz_pipe_881_s6 <= 32'h0;
            rtlzz_pipe_881_s7 <= 32'h0;
            rtlzz_pipe_886_s2 <= 32'h0;
            rtlzz_pipe_886_s3 <= 32'h0;
            rtlzz_pipe_886_s4 <= 32'h0;
            rtlzz_pipe_886_s5 <= 32'h0;
            rtlzz_pipe_886_s6 <= 32'h0;
            rtlzz_pipe_886_s7 <= 32'h0;
            rtlzz_pipe_891_s2 <= 1'h0;
            rtlzz_pipe_891_s3 <= 1'h0;
            rtlzz_pipe_891_s4 <= 1'h0;
            rtlzz_pipe_891_s5 <= 1'h0;
            rtlzz_pipe_891_s6 <= 1'h0;
            rtlzz_pipe_891_s7 <= 1'h0;
            rtlzz_pipe_953_s7 <= 32'hffffffff;
            rtlzz_pipe_959_s7 <= 32'hffffffff;
            rtlzz_pipe_965_s7 <= 32'hffffffff;
            rtlzz_pipe_971_s7 <= 32'hffffffff;
            rtlzz_pipe_977_s7 <= 2'h3;
            rtlzz_pipe_1011_s1 <= 32'h0;
            rtlzz_pipe_1011_s2 <= 32'h0;
            rtlzz_pipe_1016_s1 <= 32'h0;
            rtlzz_pipe_1016_s2 <= 32'h0;
            rtlzz_pipe_1021_s1 <= 32'h0;
            rtlzz_pipe_1021_s2 <= 32'h0;
            rtlzz_pipe_1026_s1 <= 32'h0;
            rtlzz_pipe_1026_s2 <= 32'h0;
            rtlzz_pipe_1031_s1 <= 1'h0;
            rtlzz_pipe_1031_s2 <= 1'h0;
            rtlzz_pipe_198_s3 <= 34'h0;
            rtlzz_pipe_112_s3 <= 66'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_284_s3 <= 128'h0;
            rtlzz_pipe_286_s3 <= 66'h0;
            rtlzz_pipe_322_s4 <= 33'h0;
            rtlzz_pipe_325_s4 <= 32'h0;
            rtlzz_pipe_331_s4 <= 64'h0;
            rtlzz_pipe_331_s5 <= 64'h0;
            rtlzz_pipe_1036_s2 <= 32'h0;
            rtlzz_pipe_1036_s3 <= 32'h0;
            rtlzz_pipe_1039_s4 <= 32'h0;
            rtlzz_pipe_1041_s2 <= 32'h0;
            rtlzz_pipe_1041_s3 <= 32'h0;
            rtlzz_pipe_1044_s4 <= 32'h0;
            rtlzz_pipe_1046_s2 <= 32'h0;
            rtlzz_pipe_1046_s3 <= 32'h0;
            rtlzz_pipe_1049_s4 <= 32'h0;
            rtlzz_pipe_1051_s2 <= 32'h0;
            rtlzz_pipe_1051_s3 <= 32'h0;
            rtlzz_pipe_1054_s4 <= 32'h0;
            rtlzz_pipe_1055_s4 <= 1'h0;
            rtlzz_pipe_1056_s2 <= 1'h0;
            rtlzz_pipe_1056_s3 <= 1'h0;
            rtlzz_pipe_1056_s4 <= 1'h0;
            rtlzz_pipe_1057_s4 <= 1'h0;
            rtlzz_pipe_285_s5 <= 128'h0;
            rtlzz_pipe_287_s5 <= 66'h0;
            rtlzz_pipe_200_s5 <= 68'h0;
            rtlzz_pipe_202_s5 <= 130'h0;
            rtlzz_pipe_203_s5 <= 130'h0;
            rtlzz_pipe_1062_s3 <= 32'h0;
            rtlzz_pipe_1067_s3 <= 2'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_1081_s5 <= 32'h0;
            rtlzz_pipe_1087_s5 <= 32'h0;
            rtlzz_pipe_1093_s5 <= 4'h0;
            rtlzz_pipe_1101_s5 <= 32'hffffffff;
            rtlzz_pipe_1107_s5 <= 32'hffffffff;
            rtlzz_pipe_1113_s5 <= 4'hf;
            rtlzz_pipe_1117_s3 <= 32'h0;
            rtlzz_pipe_1122_s3 <= 32'h0;
            rtlzz_pipe_1127_s3 <= 2'h0;
            rtlzz_pipe_334_s4 <= 33'h0;
            rtlzz_pipe_334_s5 <= 33'h0;
            rtlzz_pipe_337_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_337_s6 <= 33'h0;
            rtlzz_pipe_1132_s5 <= 32'h0;
            rtlzz_pipe_1137_s5 <= 32'h0;
            rtlzz_pipe_1142_s5 <= 2'h0;
            rtlzz_pipe_211_s6 <= 34'h0;
            rtlzz_pipe_289_s6 <= 66'h0;
            rtlzz_pipe_291_s6 <= 34'h0;
            rtlzz_pipe_1150_s4 <= 32'h0;
            rtlzz_pipe_1151_s4 <= 1'h0;
            rtlzz_pipe_1152_s4 <= 2'h0;
            rtlzz_pipe_1153_s4 <= 2'h0;
            rtlzz_pipe_340_s5 <= 34'h0;
            rtlzz_pipe_340_s6 <= 34'h0;
            rtlzz_pipe_1169_s6 <= 32'hffffffff;
            rtlzz_pipe_1175_s6 <= 32'hffffffff;
            rtlzz_pipe_1181_s6 <= 4'hf;
            rtlzz_pipe_1235_s6 <= 32'hffffffff;
            rtlzz_pipe_1241_s6 <= 32'hffffffff;
            rtlzz_pipe_1247_s6 <= 32'hffffffff;
            rtlzz_pipe_1253_s6 <= 32'hffffffff;
            rtlzz_pipe_1259_s6 <= 4'hf;
            rtlzz_pipe_1372_s1 <= 32'h0;
            rtlzz_pipe_1372_s2 <= 32'h0;
            rtlzz_pipe_1372_s3 <= 32'h0;
            rtlzz_pipe_1372_s4 <= 32'h0;
            rtlzz_pipe_1372_s5 <= 32'h0;
            rtlzz_pipe_1372_s6 <= 32'h0;
            rtlzz_pipe_1372_s7 <= 32'h0;
            rtlzz_pipe_1377_s1 <= 32'h0;
            rtlzz_pipe_1377_s2 <= 32'h0;
            rtlzz_pipe_1377_s3 <= 32'h0;
            rtlzz_pipe_1377_s4 <= 32'h0;
            rtlzz_pipe_1377_s5 <= 32'h0;
            rtlzz_pipe_1377_s6 <= 32'h0;
            rtlzz_pipe_1377_s7 <= 32'h0;
            rtlzz_pipe_1382_s1 <= 32'h0;
            rtlzz_pipe_1382_s2 <= 32'h0;
            rtlzz_pipe_1382_s3 <= 32'h0;
            rtlzz_pipe_1382_s4 <= 32'h0;
            rtlzz_pipe_1382_s5 <= 32'h0;
            rtlzz_pipe_1382_s6 <= 32'h0;
            rtlzz_pipe_1382_s7 <= 32'h0;
            rtlzz_pipe_1387_s1 <= 32'h0;
            rtlzz_pipe_1387_s2 <= 32'h0;
            rtlzz_pipe_1387_s3 <= 32'h0;
            rtlzz_pipe_1387_s4 <= 32'h0;
            rtlzz_pipe_1387_s5 <= 32'h0;
            rtlzz_pipe_1387_s6 <= 32'h0;
            rtlzz_pipe_1387_s7 <= 32'h0;
            rtlzz_pipe_1392_s1 <= 32'h0;
            rtlzz_pipe_1392_s2 <= 32'h0;
            rtlzz_pipe_1392_s3 <= 32'h0;
            rtlzz_pipe_1392_s4 <= 32'h0;
            rtlzz_pipe_1392_s5 <= 32'h0;
            rtlzz_pipe_1392_s6 <= 32'h0;
            rtlzz_pipe_1392_s7 <= 32'h0;
            rtlzz_pipe_1397_s1 <= 32'h0;
            rtlzz_pipe_1397_s2 <= 32'h0;
            rtlzz_pipe_1397_s3 <= 32'h0;
            rtlzz_pipe_1397_s4 <= 32'h0;
            rtlzz_pipe_1397_s5 <= 32'h0;
            rtlzz_pipe_1397_s6 <= 32'h0;
            rtlzz_pipe_1397_s7 <= 32'h0;
            rtlzz_pipe_1402_s1 <= 32'h0;
            rtlzz_pipe_1402_s2 <= 32'h0;
            rtlzz_pipe_1402_s3 <= 32'h0;
            rtlzz_pipe_1402_s4 <= 32'h0;
            rtlzz_pipe_1402_s5 <= 32'h0;
            rtlzz_pipe_1402_s6 <= 32'h0;
            rtlzz_pipe_1402_s7 <= 32'h0;
            rtlzz_pipe_1407_s1 <= 32'h0;
            rtlzz_pipe_1407_s2 <= 32'h0;
            rtlzz_pipe_1407_s3 <= 32'h0;
            rtlzz_pipe_1407_s4 <= 32'h0;
            rtlzz_pipe_1407_s5 <= 32'h0;
            rtlzz_pipe_1407_s6 <= 32'h0;
            rtlzz_pipe_1407_s7 <= 32'h0;
            rtlzz_pipe_1412_s1 <= 32'h0;
            rtlzz_pipe_1412_s2 <= 32'h0;
            rtlzz_pipe_1412_s3 <= 32'h0;
            rtlzz_pipe_1412_s4 <= 32'h0;
            rtlzz_pipe_1412_s5 <= 32'h0;
            rtlzz_pipe_1412_s6 <= 32'h0;
            rtlzz_pipe_1412_s7 <= 32'h0;
            rtlzz_pipe_1417_s1 <= 32'h0;
            rtlzz_pipe_1417_s2 <= 32'h0;
            rtlzz_pipe_1417_s3 <= 32'h0;
            rtlzz_pipe_1417_s4 <= 32'h0;
            rtlzz_pipe_1417_s5 <= 32'h0;
            rtlzz_pipe_1417_s6 <= 32'h0;
            rtlzz_pipe_1417_s7 <= 32'h0;
            rtlzz_pipe_1422_s1 <= 32'h0;
            rtlzz_pipe_1422_s2 <= 32'h0;
            rtlzz_pipe_1422_s3 <= 32'h0;
            rtlzz_pipe_1422_s4 <= 32'h0;
            rtlzz_pipe_1422_s5 <= 32'h0;
            rtlzz_pipe_1422_s6 <= 32'h0;
            rtlzz_pipe_1422_s7 <= 32'h0;
            rtlzz_pipe_1427_s1 <= 32'h0;
            rtlzz_pipe_1427_s2 <= 32'h0;
            rtlzz_pipe_1427_s3 <= 32'h0;
            rtlzz_pipe_1427_s4 <= 32'h0;
            rtlzz_pipe_1427_s5 <= 32'h0;
            rtlzz_pipe_1427_s6 <= 32'h0;
            rtlzz_pipe_1427_s7 <= 32'h0;
            rtlzz_pipe_1432_s1 <= 32'h0;
            rtlzz_pipe_1432_s2 <= 32'h0;
            rtlzz_pipe_1432_s3 <= 32'h0;
            rtlzz_pipe_1432_s4 <= 32'h0;
            rtlzz_pipe_1432_s5 <= 32'h0;
            rtlzz_pipe_1432_s6 <= 32'h0;
            rtlzz_pipe_1432_s7 <= 32'h0;
            rtlzz_pipe_1437_s1 <= 32'h0;
            rtlzz_pipe_1437_s2 <= 32'h0;
            rtlzz_pipe_1437_s3 <= 32'h0;
            rtlzz_pipe_1437_s4 <= 32'h0;
            rtlzz_pipe_1437_s5 <= 32'h0;
            rtlzz_pipe_1437_s6 <= 32'h0;
            rtlzz_pipe_1437_s7 <= 32'h0;
            rtlzz_pipe_1442_s1 <= 32'h0;
            rtlzz_pipe_1442_s2 <= 32'h0;
            rtlzz_pipe_1442_s3 <= 32'h0;
            rtlzz_pipe_1442_s4 <= 32'h0;
            rtlzz_pipe_1442_s5 <= 32'h0;
            rtlzz_pipe_1442_s6 <= 32'h0;
            rtlzz_pipe_1442_s7 <= 32'h0;
            rtlzz_pipe_1447_s1 <= 32'h0;
            rtlzz_pipe_1447_s2 <= 32'h0;
            rtlzz_pipe_1447_s3 <= 32'h0;
            rtlzz_pipe_1447_s4 <= 32'h0;
            rtlzz_pipe_1447_s5 <= 32'h0;
            rtlzz_pipe_1447_s6 <= 32'h0;
            rtlzz_pipe_1447_s7 <= 32'h0;
            rtlzz_pipe_1452_s1 <= 1'h0;
            rtlzz_pipe_1452_s2 <= 1'h0;
            rtlzz_pipe_1452_s3 <= 1'h0;
            rtlzz_pipe_1452_s4 <= 1'h0;
            rtlzz_pipe_1452_s5 <= 1'h0;
            rtlzz_pipe_1452_s6 <= 1'h0;
            rtlzz_pipe_1452_s7 <= 1'h0;
            rtlzz_pipe_1866_s6 <= 32'h0;
            rtlzz_pipe_1871_s6 <= 32'h0;
            rtlzz_pipe_1876_s6 <= 32'h0;
            rtlzz_pipe_1881_s6 <= 32'h0;
            rtlzz_pipe_1886_s6 <= 4'h0;
            rtlzz_pipe_1205_s6 <= 32'hffffffff;
            rtlzz_pipe_1211_s6 <= 32'hffffffff;
            rtlzz_pipe_1217_s6 <= 32'hffffffff;
            rtlzz_pipe_1223_s6 <= 32'hffffffff;
            rtlzz_pipe_1229_s6 <= 4'hf;
            rtlzz_pipe_1661_s6 <= 32'h0;
            rtlzz_pipe_1666_s6 <= 32'h0;
            rtlzz_pipe_1671_s6 <= 32'h0;
            rtlzz_pipe_1676_s6 <= 32'h0;
            rtlzz_pipe_1681_s6 <= 32'h0;
            rtlzz_pipe_1686_s6 <= 32'h0;
            rtlzz_pipe_1691_s6 <= 32'h0;
            rtlzz_pipe_1696_s6 <= 32'h0;
            rtlzz_pipe_1701_s6 <= 2'h0;
            rtlzz_pipe_1263_s7 <= 32'h0;
            rtlzz_pipe_1269_s7 <= 32'h0;
            rtlzz_pipe_1275_s7 <= 32'h0;
            rtlzz_pipe_1281_s7 <= 32'h0;
            rtlzz_pipe_1287_s7 <= 32'h0;
            rtlzz_pipe_1293_s7 <= 32'h0;
            rtlzz_pipe_1299_s7 <= 32'h0;
            rtlzz_pipe_1305_s7 <= 32'h0;
            rtlzz_pipe_1311_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= __beopt_width_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_265_s2 <= rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_265_s3 <= rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_265_s4 <= rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_265_s5 <= rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_270_s2 <= rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_270_s3 <= rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_270_s4 <= rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_270_s5 <= rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_270_s6 <= rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_271_s3 <= rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_271_s4 <= rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_271_s5 <= rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_271_s6 <= rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_271_s7 <= rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_278_s1 <= __beopt_width_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_278_s2 <= rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= __beopt_width_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_279_s2 <= rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_279_s3 <= rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_292_s3 <= rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_292_s4 <= rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_293_s3 <= rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_293_s4 <= rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_310_s7 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_362_s5 <= mul_tree_343_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_366_s5 <= mul_tree_343_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_370_s5 <= mul_tree_343_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_374_s5 <= mul_tree_343_374; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_174_s6 <= __beopt_width_561; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_387_s4 <= mul_tree_344_387; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_391_s4 <= mul_tree_344_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_395_s4 <= mul_tree_344_395; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_399_s4 <= mul_tree_344_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_11_s6 <= rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_11_s7 <= rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_175_s5 <= __beopt_width_562; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_175_s6 <= rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_465_s6 <= mul_tree_348_465; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_469_s6 <= mul_tree_348_469; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_473_s6 <= mul_tree_348_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_477_s6 <= mul_tree_348_477; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_48_s7 <= s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_719_s3 <= limb_13_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_719_s4 <= rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_724_s3 <= limb_13_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_724_s4 <= rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_729_s3 <= limb_13_729; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_729_s4 <= rtlzz_pipe_729_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_164_s5 <= __beopt_width_545; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_168_s5 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_266_s6 <= rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_298_s6 <= mul_precision_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_734_s5 <= limb_15_734; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_739_s5 <= limb_15_739; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_744_s5 <= limb_15_744; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_267_s6 <= __beopt_width_333; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_269_s6 <= __beopt_width_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_299_s6 <= mul_precision_299; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_170_s7 <= __beopt_width_557; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_173_s7 <= __beopt_width_560; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_750_s5 <= limb_21_750; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_755_s5 <= limb_21_755; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_304_s6 <= mul_precision_304; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_759_s6 <= limb_23_759; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_764_s6 <= limb_23_764; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_455_s7 <= mul_tree_347_455; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_458_s7 <= mul_tree_347_458; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_789_s7 <= limb_31_789; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_795_s7 <= limb_31_795; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_801_s7 <= limb_31_801; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_807_s7 <= limb_38_807; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_813_s7 <= limb_38_813; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_819_s7 <= limb_38_819; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_825_s7 <= limb_38_825; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_831_s7 <= limb_38_831; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_837_s7 <= limb_40_837; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_842_s7 <= limb_40_842; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_849_s7 <= limb_40_849; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_854_s7 <= limb_40_854; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_860_s7 <= limb_40_860; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_866_s1 <= limb_51_866; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_866_s2 <= rtlzz_pipe_866_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_866_s3 <= rtlzz_pipe_866_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_866_s4 <= rtlzz_pipe_866_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_866_s5 <= rtlzz_pipe_866_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_866_s6 <= rtlzz_pipe_866_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_871_s1 <= limb_51_871; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_871_s2 <= rtlzz_pipe_871_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_871_s3 <= rtlzz_pipe_871_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_871_s4 <= rtlzz_pipe_871_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_871_s5 <= rtlzz_pipe_871_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_871_s6 <= rtlzz_pipe_871_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_876_s1 <= limb_51_876; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_876_s2 <= rtlzz_pipe_876_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_876_s3 <= rtlzz_pipe_876_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_876_s4 <= rtlzz_pipe_876_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_876_s5 <= rtlzz_pipe_876_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_876_s6 <= rtlzz_pipe_876_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_184_s7 <= __beopt_width_579; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_274_s7 <= __beopt_width_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_276_s7 <= __beopt_width_372; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_313_s7 <= mul_precision_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_881_s2 <= limb_53_881; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_881_s3 <= rtlzz_pipe_881_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_881_s4 <= rtlzz_pipe_881_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_881_s5 <= rtlzz_pipe_881_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_881_s6 <= rtlzz_pipe_881_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_881_s7 <= rtlzz_pipe_881_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_886_s2 <= limb_53_886; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_886_s3 <= rtlzz_pipe_886_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_886_s4 <= rtlzz_pipe_886_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_886_s5 <= rtlzz_pipe_886_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_886_s6 <= rtlzz_pipe_886_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_886_s7 <= rtlzz_pipe_886_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_891_s2 <= limb_53_891; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_891_s3 <= rtlzz_pipe_891_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_891_s4 <= rtlzz_pipe_891_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_891_s5 <= rtlzz_pipe_891_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_891_s6 <= rtlzz_pipe_891_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_891_s7 <= rtlzz_pipe_891_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_953_s7 <= limb_76_953; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_959_s7 <= limb_76_959; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_965_s7 <= limb_76_965; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_971_s7 <= limb_76_971; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_977_s7 <= limb_76_977; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1011_s1 <= limb_85_1011; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1011_s2 <= rtlzz_pipe_1011_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1016_s1 <= limb_85_1016; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1016_s2 <= rtlzz_pipe_1016_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1021_s1 <= limb_85_1021; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1021_s2 <= rtlzz_pipe_1021_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1026_s1 <= limb_85_1026; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1026_s2 <= rtlzz_pipe_1026_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1031_s1 <= limb_85_1031; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1031_s2 <= rtlzz_pipe_1031_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_198_s3 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_284_s3 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_286_s3 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_322_s4 <= mul_precision_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_325_s4 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_331_s5 <= rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1036_s2 <= limb_87_1036; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1036_s3 <= rtlzz_pipe_1036_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1039_s4 <= limb_87_1039; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1041_s2 <= limb_87_1041; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1041_s3 <= rtlzz_pipe_1041_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1044_s4 <= limb_87_1044; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1046_s2 <= limb_87_1046; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1046_s3 <= rtlzz_pipe_1046_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1049_s4 <= limb_87_1049; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1051_s2 <= limb_87_1051; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1051_s3 <= rtlzz_pipe_1051_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1054_s4 <= limb_87_1054; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1055_s4 <= limb_87_1055; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1056_s2 <= limb_87_1056; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1056_s3 <= rtlzz_pipe_1056_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1056_s4 <= rtlzz_pipe_1056_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1057_s4 <= limb_87_1057; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_285_s5 <= __beopt_width_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_287_s5 <= __beopt_width_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_200_s5 <= __beopt_width_609; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_202_s5 <= __beopt_width_611; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_203_s5 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1062_s3 <= limb_95_1062; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1067_s3 <= limb_95_1067; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1081_s5 <= limb_103_1081; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1087_s5 <= limb_103_1087; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1093_s5 <= limb_103_1093; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1101_s5 <= limb_105_1101; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1107_s5 <= limb_105_1107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1113_s5 <= limb_105_1113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1117_s3 <= limb_113_1117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1122_s3 <= limb_113_1122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1127_s3 <= limb_113_1127; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_334_s4 <= mul_precision_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_337_s4 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_337_s6 <= rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1132_s5 <= limb_115_1132; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1137_s5 <= limb_115_1137; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1142_s5 <= limb_115_1142; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_211_s6 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_289_s6 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_291_s6 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1150_s4 <= limb_121_1150; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1151_s4 <= limb_121_1151; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1152_s4 <= limb_121_1152; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1153_s4 <= limb_121_1153; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_340_s5 <= mul_precision_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1169_s6 <= limb_129_1169; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1175_s6 <= limb_129_1175; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1181_s6 <= limb_129_1181; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1235_s6 <= limb_140_1235; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1241_s6 <= limb_140_1241; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1247_s6 <= limb_140_1247; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1253_s6 <= limb_140_1253; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1259_s6 <= limb_140_1259; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1372_s1 <= limb_157_1372; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1372_s2 <= rtlzz_pipe_1372_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1372_s3 <= rtlzz_pipe_1372_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1372_s4 <= rtlzz_pipe_1372_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1372_s5 <= rtlzz_pipe_1372_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1372_s6 <= rtlzz_pipe_1372_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1372_s7 <= rtlzz_pipe_1372_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1377_s1 <= limb_157_1377; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1377_s2 <= rtlzz_pipe_1377_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1377_s3 <= rtlzz_pipe_1377_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1377_s4 <= rtlzz_pipe_1377_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1377_s5 <= rtlzz_pipe_1377_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1377_s6 <= rtlzz_pipe_1377_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1377_s7 <= rtlzz_pipe_1377_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1382_s1 <= limb_157_1382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1382_s2 <= rtlzz_pipe_1382_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1382_s3 <= rtlzz_pipe_1382_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1382_s4 <= rtlzz_pipe_1382_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1382_s5 <= rtlzz_pipe_1382_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1382_s6 <= rtlzz_pipe_1382_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1382_s7 <= rtlzz_pipe_1382_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1387_s1 <= limb_157_1387; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1387_s2 <= rtlzz_pipe_1387_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1387_s3 <= rtlzz_pipe_1387_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1387_s4 <= rtlzz_pipe_1387_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1387_s5 <= rtlzz_pipe_1387_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1387_s6 <= rtlzz_pipe_1387_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1387_s7 <= rtlzz_pipe_1387_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1392_s1 <= limb_157_1392; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1392_s2 <= rtlzz_pipe_1392_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1392_s3 <= rtlzz_pipe_1392_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1392_s4 <= rtlzz_pipe_1392_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1392_s5 <= rtlzz_pipe_1392_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1392_s6 <= rtlzz_pipe_1392_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1392_s7 <= rtlzz_pipe_1392_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1397_s1 <= limb_157_1397; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1397_s2 <= rtlzz_pipe_1397_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1397_s3 <= rtlzz_pipe_1397_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1397_s4 <= rtlzz_pipe_1397_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1397_s5 <= rtlzz_pipe_1397_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1397_s6 <= rtlzz_pipe_1397_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1397_s7 <= rtlzz_pipe_1397_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1402_s1 <= limb_157_1402; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1402_s2 <= rtlzz_pipe_1402_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1402_s3 <= rtlzz_pipe_1402_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1402_s4 <= rtlzz_pipe_1402_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1402_s5 <= rtlzz_pipe_1402_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1402_s6 <= rtlzz_pipe_1402_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1402_s7 <= rtlzz_pipe_1402_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1407_s1 <= limb_157_1407; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1407_s2 <= rtlzz_pipe_1407_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1407_s3 <= rtlzz_pipe_1407_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1407_s4 <= rtlzz_pipe_1407_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1407_s5 <= rtlzz_pipe_1407_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1407_s6 <= rtlzz_pipe_1407_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1407_s7 <= rtlzz_pipe_1407_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1412_s1 <= limb_157_1412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1412_s2 <= rtlzz_pipe_1412_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1412_s3 <= rtlzz_pipe_1412_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1412_s4 <= rtlzz_pipe_1412_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1412_s5 <= rtlzz_pipe_1412_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1412_s6 <= rtlzz_pipe_1412_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1412_s7 <= rtlzz_pipe_1412_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1417_s1 <= limb_157_1417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1417_s2 <= rtlzz_pipe_1417_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1417_s3 <= rtlzz_pipe_1417_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1417_s4 <= rtlzz_pipe_1417_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1417_s5 <= rtlzz_pipe_1417_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1417_s6 <= rtlzz_pipe_1417_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1417_s7 <= rtlzz_pipe_1417_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1422_s1 <= limb_157_1422; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1422_s2 <= rtlzz_pipe_1422_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1422_s3 <= rtlzz_pipe_1422_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1422_s4 <= rtlzz_pipe_1422_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1422_s5 <= rtlzz_pipe_1422_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1422_s6 <= rtlzz_pipe_1422_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1422_s7 <= rtlzz_pipe_1422_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1427_s1 <= limb_157_1427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1427_s2 <= rtlzz_pipe_1427_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1427_s3 <= rtlzz_pipe_1427_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1427_s4 <= rtlzz_pipe_1427_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1427_s5 <= rtlzz_pipe_1427_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1427_s6 <= rtlzz_pipe_1427_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1427_s7 <= rtlzz_pipe_1427_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1432_s1 <= limb_157_1432; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1432_s2 <= rtlzz_pipe_1432_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1432_s3 <= rtlzz_pipe_1432_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1432_s4 <= rtlzz_pipe_1432_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1432_s5 <= rtlzz_pipe_1432_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1432_s6 <= rtlzz_pipe_1432_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1432_s7 <= rtlzz_pipe_1432_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1437_s1 <= limb_157_1437; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1437_s2 <= rtlzz_pipe_1437_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1437_s3 <= rtlzz_pipe_1437_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1437_s4 <= rtlzz_pipe_1437_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1437_s5 <= rtlzz_pipe_1437_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1437_s6 <= rtlzz_pipe_1437_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1437_s7 <= rtlzz_pipe_1437_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1442_s1 <= limb_157_1442; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1442_s2 <= rtlzz_pipe_1442_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1442_s3 <= rtlzz_pipe_1442_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1442_s4 <= rtlzz_pipe_1442_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1442_s5 <= rtlzz_pipe_1442_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1442_s6 <= rtlzz_pipe_1442_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1442_s7 <= rtlzz_pipe_1442_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1447_s1 <= limb_157_1447; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1447_s2 <= rtlzz_pipe_1447_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1447_s3 <= rtlzz_pipe_1447_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1447_s4 <= rtlzz_pipe_1447_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1447_s5 <= rtlzz_pipe_1447_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1447_s6 <= rtlzz_pipe_1447_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1447_s7 <= rtlzz_pipe_1447_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1452_s1 <= limb_157_1452; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1452_s2 <= rtlzz_pipe_1452_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1452_s3 <= rtlzz_pipe_1452_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1452_s4 <= rtlzz_pipe_1452_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1452_s5 <= rtlzz_pipe_1452_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1452_s6 <= rtlzz_pipe_1452_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1452_s7 <= rtlzz_pipe_1452_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1866_s6 <= limb_224_1866; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1871_s6 <= limb_224_1871; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1876_s6 <= limb_224_1876; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1881_s6 <= limb_224_1881; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1886_s6 <= limb_224_1886; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1205_s6 <= limb_138_1205; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1211_s6 <= limb_138_1211; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1217_s6 <= limb_138_1217; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1223_s6 <= limb_138_1223; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1229_s6 <= limb_138_1229; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1661_s6 <= limb_219_1661; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1666_s6 <= limb_219_1666; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1671_s6 <= limb_219_1671; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1676_s6 <= limb_219_1676; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1681_s6 <= limb_219_1681; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1686_s6 <= limb_219_1686; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1691_s6 <= limb_219_1691; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1696_s6 <= limb_219_1696; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1701_s6 <= limb_219_1701; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1263_s7 <= limb_147_1263; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1269_s7 <= limb_147_1269; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1275_s7 <= limb_147_1275; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1281_s7 <= limb_147_1281; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1287_s7 <= limb_147_1287; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1293_s7 <= limb_147_1293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1299_s7 <= limb_147_1299; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1305_s7 <= limb_147_1305; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1311_s7 <= limb_147_1311; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_383_reduce(input wire [63:0] i2139, input wire [95:0] i2140, input wire [95:0] i2141, input wire [127:0] i2142, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2139[63], i2139[62], i2139[61], i2139[60], i2139[59], i2139[58], i2139[57], i2139[56], i2139[55], i2139[54], i2139[53], i2139[52], i2139[51], i2139[50], i2139[49], i2139[48], i2139[47], i2139[46], i2139[45], i2139[44], i2139[43], i2139[42], i2139[41], i2139[40], i2139[39], i2139[38], i2139[37], i2139[36], i2139[35], i2139[34], i2139[33], i2139[32], i2139[31], i2139[30], i2139[29], i2139[28], i2139[27], i2139[26], i2139[25], i2139[24], i2139[23], i2139[22], i2139[21], i2139[20], i2139[19], i2139[18], i2139[17], i2139[16], i2139[15], i2139[14], i2139[13], i2139[12], i2139[11], i2139[10], i2139[9], i2139[8], i2139[7], i2139[6], i2139[5], i2139[4], i2139[3], i2139[2], i2139[1], i2139[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2140[95], i2140[94], i2140[93], i2140[92], i2140[91], i2140[90], i2140[89], i2140[88], i2140[87], i2140[86], i2140[85], i2140[84], i2140[83], i2140[82], i2140[81], i2140[80], i2140[79], i2140[78], i2140[77], i2140[76], i2140[75], i2140[74], i2140[73], i2140[72], i2140[71], i2140[70], i2140[69], i2140[68], i2140[67], i2140[66], i2140[65], i2140[64], i2140[63], i2140[62], i2140[61], i2140[60], i2140[59], i2140[58], i2140[57], i2140[56], i2140[55], i2140[54], i2140[53], i2140[52], i2140[51], i2140[50], i2140[49], i2140[48], i2140[47], i2140[46], i2140[45], i2140[44], i2140[43], i2140[42], i2140[41], i2140[40], i2140[39], i2140[38], i2140[37], i2140[36], i2140[35], i2140[34], i2140[33], i2140[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2141[95], i2141[94], i2141[93], i2141[92], i2141[91], i2141[90], i2141[89], i2141[88], i2141[87], i2141[86], i2141[85], i2141[84], i2141[83], i2141[82], i2141[81], i2141[80], i2141[79], i2141[78], i2141[77], i2141[76], i2141[75], i2141[74], i2141[73], i2141[72], i2141[71], i2141[70], i2141[69], i2141[68], i2141[67], i2141[66], i2141[65], i2141[64], i2141[63], i2141[62], i2141[61], i2141[60], i2141[59], i2141[58], i2141[57], i2141[56], i2141[55], i2141[54], i2141[53], i2141[52], i2141[51], i2141[50], i2141[49], i2141[48], i2141[47], i2141[46], i2141[45], i2141[44], i2141[43], i2141[42], i2141[41], i2141[40], i2141[39], i2141[38], i2141[37], i2141[36], i2141[35], i2141[34], i2141[33], i2141[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i2142[127], i2142[126], i2142[125], i2142[124], i2142[123], i2142[122], i2142[121], i2142[120], i2142[119], i2142[118], i2142[117], i2142[116], i2142[115], i2142[114], i2142[113], i2142[112], i2142[111], i2142[110], i2142[109], i2142[108], i2142[107], i2142[106], i2142[105], i2142[104], i2142[103], i2142[102], i2142[101], i2142[100], i2142[99], i2142[98], i2142[97], i2142[96], i2142[95], i2142[94], i2142[93], i2142[92], i2142[91], i2142[90], i2142[89], i2142[88], i2142[87], i2142[86], i2142[85], i2142[84], i2142[83], i2142[82], i2142[81], i2142[80], i2142[79], i2142[78], i2142[77], i2142[76], i2142[75], i2142[74], i2142[73], i2142[72], i2142[71], i2142[70], i2142[69], i2142[68], i2142[67], i2142[66], i2142[65], i2142[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408_reduce(input wire [63:0] i2146, input wire [95:0] i2147, input wire [95:0] i2148, input wire [127:0] i2149, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2146[63], i2146[62], i2146[61], i2146[60], i2146[59], i2146[58], i2146[57], i2146[56], i2146[55], i2146[54], i2146[53], i2146[52], i2146[51], i2146[50], i2146[49], i2146[48], i2146[47], i2146[46], i2146[45], i2146[44], i2146[43], i2146[42], i2146[41], i2146[40], i2146[39], i2146[38], i2146[37], i2146[36], i2146[35], i2146[34], i2146[33], i2146[32], i2146[31], i2146[30], i2146[29], i2146[28], i2146[27], i2146[26], i2146[25], i2146[24], i2146[23], i2146[22], i2146[21], i2146[20], i2146[19], i2146[18], i2146[17], i2146[16], i2146[15], i2146[14], i2146[13], i2146[12], i2146[11], i2146[10], i2146[9], i2146[8], i2146[7], i2146[6], i2146[5], i2146[4], i2146[3], i2146[2], i2146[1], i2146[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2147[95], i2147[94], i2147[93], i2147[92], i2147[91], i2147[90], i2147[89], i2147[88], i2147[87], i2147[86], i2147[85], i2147[84], i2147[83], i2147[82], i2147[81], i2147[80], i2147[79], i2147[78], i2147[77], i2147[76], i2147[75], i2147[74], i2147[73], i2147[72], i2147[71], i2147[70], i2147[69], i2147[68], i2147[67], i2147[66], i2147[65], i2147[64], i2147[63], i2147[62], i2147[61], i2147[60], i2147[59], i2147[58], i2147[57], i2147[56], i2147[55], i2147[54], i2147[53], i2147[52], i2147[51], i2147[50], i2147[49], i2147[48], i2147[47], i2147[46], i2147[45], i2147[44], i2147[43], i2147[42], i2147[41], i2147[40], i2147[39], i2147[38], i2147[37], i2147[36], i2147[35], i2147[34], i2147[33], i2147[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2148[95], i2148[94], i2148[93], i2148[92], i2148[91], i2148[90], i2148[89], i2148[88], i2148[87], i2148[86], i2148[85], i2148[84], i2148[83], i2148[82], i2148[81], i2148[80], i2148[79], i2148[78], i2148[77], i2148[76], i2148[75], i2148[74], i2148[73], i2148[72], i2148[71], i2148[70], i2148[69], i2148[68], i2148[67], i2148[66], i2148[65], i2148[64], i2148[63], i2148[62], i2148[61], i2148[60], i2148[59], i2148[58], i2148[57], i2148[56], i2148[55], i2148[54], i2148[53], i2148[52], i2148[51], i2148[50], i2148[49], i2148[48], i2148[47], i2148[46], i2148[45], i2148[44], i2148[43], i2148[42], i2148[41], i2148[40], i2148[39], i2148[38], i2148[37], i2148[36], i2148[35], i2148[34], i2148[33], i2148[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i2149[127], i2149[126], i2149[125], i2149[124], i2149[123], i2149[122], i2149[121], i2149[120], i2149[119], i2149[118], i2149[117], i2149[116], i2149[115], i2149[114], i2149[113], i2149[112], i2149[111], i2149[110], i2149[109], i2149[108], i2149[107], i2149[106], i2149[105], i2149[104], i2149[103], i2149[102], i2149[101], i2149[100], i2149[99], i2149[98], i2149[97], i2149[96], i2149[95], i2149[94], i2149[93], i2149[92], i2149[91], i2149[90], i2149[89], i2149[88], i2149[87], i2149[86], i2149[85], i2149[84], i2149[83], i2149[82], i2149[81], i2149[80], i2149[79], i2149[78], i2149[77], i2149[76], i2149[75], i2149[74], i2149[73], i2149[72], i2149[71], i2149[70], i2149[69], i2149[68], i2149[67], i2149[66], i2149[65], i2149[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433_reduce(input wire [63:0] i412, input wire [32:0] i415, input wire [32:0] i419, input wire [1:0] i423, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i412[63], i412[62], i412[61], i412[60], i412[59], i412[58], i412[57], i412[56], i412[55], i412[54], i412[53], i412[52], i412[51], i412[50], i412[49], i412[48], i412[47], i412[46], i412[45], i412[44], i412[43], i412[42], i412[41], i412[40], i412[39], i412[38], i412[37], i412[36], i412[35], i412[34], i412[33], i412[32], i412[31], i412[30], i412[29], i412[28], i412[27], i412[26], i412[25], i412[24], i412[23], i412[22], i412[21], i412[20], i412[19], i412[18], i412[17], i412[16], i412[15], i412[14], i412[13], i412[12], i412[11], i412[10], i412[9], i412[8], i412[7], i412[6], i412[5], i412[4], i412[3], i412[2], i412[1], i412[0]};
wire [65:0] t1 = {1'b0, i415[32], i415[31], i415[30], i415[29], i415[28], i415[27], i415[26], i415[25], i415[24], i415[23], i415[22], i415[21], i415[20], i415[19], i415[18], i415[17], i415[16], i415[15], i415[14], i415[13], i415[12], i415[11], i415[10], i415[9], i415[8], i415[7], i415[6], i415[5], i415[4], i415[3], i415[2], i415[1], i415[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i419[32], i419[31], i419[30], i419[29], i419[28], i419[27], i419[26], i419[25], i419[24], i419[23], i419[22], i419[21], i419[20], i419[19], i419[18], i419[17], i419[16], i419[15], i419[14], i419[13], i419[12], i419[11], i419[10], i419[9], i419[8], i419[7], i419[6], i419[5], i419[4], i419[3], i419[2], i419[1], i419[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i423[1], i423[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_486_reduce(input wire [63:0] i2155, input wire [95:0] i2156, input wire [95:0] i2157, input wire [127:0] i2158, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2155[63], i2155[62], i2155[61], i2155[60], i2155[59], i2155[58], i2155[57], i2155[56], i2155[55], i2155[54], i2155[53], i2155[52], i2155[51], i2155[50], i2155[49], i2155[48], i2155[47], i2155[46], i2155[45], i2155[44], i2155[43], i2155[42], i2155[41], i2155[40], i2155[39], i2155[38], i2155[37], i2155[36], i2155[35], i2155[34], i2155[33], i2155[32], i2155[31], i2155[30], i2155[29], i2155[28], i2155[27], i2155[26], i2155[25], i2155[24], i2155[23], i2155[22], i2155[21], i2155[20], i2155[19], i2155[18], i2155[17], i2155[16], i2155[15], i2155[14], i2155[13], i2155[12], i2155[11], i2155[10], i2155[9], i2155[8], i2155[7], i2155[6], i2155[5], i2155[4], i2155[3], i2155[2], i2155[1], i2155[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2156[95], i2156[94], i2156[93], i2156[92], i2156[91], i2156[90], i2156[89], i2156[88], i2156[87], i2156[86], i2156[85], i2156[84], i2156[83], i2156[82], i2156[81], i2156[80], i2156[79], i2156[78], i2156[77], i2156[76], i2156[75], i2156[74], i2156[73], i2156[72], i2156[71], i2156[70], i2156[69], i2156[68], i2156[67], i2156[66], i2156[65], i2156[64], i2156[63], i2156[62], i2156[61], i2156[60], i2156[59], i2156[58], i2156[57], i2156[56], i2156[55], i2156[54], i2156[53], i2156[52], i2156[51], i2156[50], i2156[49], i2156[48], i2156[47], i2156[46], i2156[45], i2156[44], i2156[43], i2156[42], i2156[41], i2156[40], i2156[39], i2156[38], i2156[37], i2156[36], i2156[35], i2156[34], i2156[33], i2156[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i2157[95], i2157[94], i2157[93], i2157[92], i2157[91], i2157[90], i2157[89], i2157[88], i2157[87], i2157[86], i2157[85], i2157[84], i2157[83], i2157[82], i2157[81], i2157[80], i2157[79], i2157[78], i2157[77], i2157[76], i2157[75], i2157[74], i2157[73], i2157[72], i2157[71], i2157[70], i2157[69], i2157[68], i2157[67], i2157[66], i2157[65], i2157[64], i2157[63], i2157[62], i2157[61], i2157[60], i2157[59], i2157[58], i2157[57], i2157[56], i2157[55], i2157[54], i2157[53], i2157[52], i2157[51], i2157[50], i2157[49], i2157[48], i2157[47], i2157[46], i2157[45], i2157[44], i2157[43], i2157[42], i2157[41], i2157[40], i2157[39], i2157[38], i2157[37], i2157[36], i2157[35], i2157[34], i2157[33], i2157[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i2158[127], i2158[126], i2158[125], i2158[124], i2158[123], i2158[122], i2158[121], i2158[120], i2158[119], i2158[118], i2158[117], i2158[116], i2158[115], i2158[114], i2158[113], i2158[112], i2158[111], i2158[110], i2158[109], i2158[108], i2158[107], i2158[106], i2158[105], i2158[104], i2158[103], i2158[102], i2158[101], i2158[100], i2158[99], i2158[98], i2158[97], i2158[96], i2158[95], i2158[94], i2158[93], i2158[92], i2158[91], i2158[90], i2158[89], i2158[88], i2158[87], i2158[86], i2158[85], i2158[84], i2158[83], i2158[82], i2158[81], i2158[80], i2158[79], i2158[78], i2158[77], i2158[76], i2158[75], i2158[74], i2158[73], i2158[72], i2158[71], i2158[70], i2158[69], i2158[68], i2158[67], i2158[66], i2158[65], i2158[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511_reduce(input wire [63:0] i490, input wire [63:0] i493, input wire [63:0] i497, input wire [63:0] i501, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[63], i490[62], i490[61], i490[60], i490[59], i490[58], i490[57], i490[56], i490[55], i490[54], i490[53], i490[52], i490[51], i490[50], i490[49], i490[48], i490[47], i490[46], i490[45], i490[44], i490[43], i490[42], i490[41], i490[40], i490[39], i490[38], i490[37], i490[36], i490[35], i490[34], i490[33], i490[32], i490[31], i490[30], i490[29], i490[28], i490[27], i490[26], i490[25], i490[24], i490[23], i490[22], i490[21], i490[20], i490[19], i490[18], i490[17], i490[16], i490[15], i490[14], i490[13], i490[12], i490[11], i490[10], i490[9], i490[8], i490[7], i490[6], i490[5], i490[4], i490[3], i490[2], i490[1], i490[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[63], i493[62], i493[61], i493[60], i493[59], i493[58], i493[57], i493[56], i493[55], i493[54], i493[53], i493[52], i493[51], i493[50], i493[49], i493[48], i493[47], i493[46], i493[45], i493[44], i493[43], i493[42], i493[41], i493[40], i493[39], i493[38], i493[37], i493[36], i493[35], i493[34], i493[33], i493[32], i493[31], i493[30], i493[29], i493[28], i493[27], i493[26], i493[25], i493[24], i493[23], i493[22], i493[21], i493[20], i493[19], i493[18], i493[17], i493[16], i493[15], i493[14], i493[13], i493[12], i493[11], i493[10], i493[9], i493[8], i493[7], i493[6], i493[5], i493[4], i493[3], i493[2], i493[1], i493[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[63], i497[62], i497[61], i497[60], i497[59], i497[58], i497[57], i497[56], i497[55], i497[54], i497[53], i497[52], i497[51], i497[50], i497[49], i497[48], i497[47], i497[46], i497[45], i497[44], i497[43], i497[42], i497[41], i497[40], i497[39], i497[38], i497[37], i497[36], i497[35], i497[34], i497[33], i497[32], i497[31], i497[30], i497[29], i497[28], i497[27], i497[26], i497[25], i497[24], i497[23], i497[22], i497[21], i497[20], i497[19], i497[18], i497[17], i497[16], i497[15], i497[14], i497[13], i497[12], i497[11], i497[10], i497[9], i497[8], i497[7], i497[6], i497[5], i497[4], i497[3], i497[2], i497[1], i497[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i501[63], i501[62], i501[61], i501[60], i501[59], i501[58], i501[57], i501[56], i501[55], i501[54], i501[53], i501[52], i501[51], i501[50], i501[49], i501[48], i501[47], i501[46], i501[45], i501[44], i501[43], i501[42], i501[41], i501[40], i501[39], i501[38], i501[37], i501[36], i501[35], i501[34], i501[33], i501[32], i501[31], i501[30], i501[29], i501[28], i501[27], i501[26], i501[25], i501[24], i501[23], i501[22], i501[21], i501[20], i501[19], i501[18], i501[17], i501[16], i501[15], i501[14], i501[13], i501[12], i501[11], i501[10], i501[9], i501[8], i501[7], i501[6], i501[5], i501[4], i501[3], i501[2], i501[1], i501[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_536_reduce(input wire [63:0] i515, input wire [32:0] i518, input wire [32:0] i522, input wire [1:0] i526, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i515[63], i515[62], i515[61], i515[60], i515[59], i515[58], i515[57], i515[56], i515[55], i515[54], i515[53], i515[52], i515[51], i515[50], i515[49], i515[48], i515[47], i515[46], i515[45], i515[44], i515[43], i515[42], i515[41], i515[40], i515[39], i515[38], i515[37], i515[36], i515[35], i515[34], i515[33], i515[32], i515[31], i515[30], i515[29], i515[28], i515[27], i515[26], i515[25], i515[24], i515[23], i515[22], i515[21], i515[20], i515[19], i515[18], i515[17], i515[16], i515[15], i515[14], i515[13], i515[12], i515[11], i515[10], i515[9], i515[8], i515[7], i515[6], i515[5], i515[4], i515[3], i515[2], i515[1], i515[0]};
wire [65:0] t1 = {1'b0, i518[32], i518[31], i518[30], i518[29], i518[28], i518[27], i518[26], i518[25], i518[24], i518[23], i518[22], i518[21], i518[20], i518[19], i518[18], i518[17], i518[16], i518[15], i518[14], i518[13], i518[12], i518[11], i518[10], i518[9], i518[8], i518[7], i518[6], i518[5], i518[4], i518[3], i518[2], i518[1], i518[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i526[1], i526[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_564_reduce(input wire [63:0] i543, input wire [33:0] i546, input wire [33:0] i550, input wire [3:0] i554, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i543[63], i543[62], i543[61], i543[60], i543[59], i543[58], i543[57], i543[56], i543[55], i543[54], i543[53], i543[52], i543[51], i543[50], i543[49], i543[48], i543[47], i543[46], i543[45], i543[44], i543[43], i543[42], i543[41], i543[40], i543[39], i543[38], i543[37], i543[36], i543[35], i543[34], i543[33], i543[32], i543[31], i543[30], i543[29], i543[28], i543[27], i543[26], i543[25], i543[24], i543[23], i543[22], i543[21], i543[20], i543[19], i543[18], i543[17], i543[16], i543[15], i543[14], i543[13], i543[12], i543[11], i543[10], i543[9], i543[8], i543[7], i543[6], i543[5], i543[4], i543[3], i543[2], i543[1], i543[0]};
wire [67:0] t1 = {1'b0, 1'b0, i546[33], i546[32], i546[31], i546[30], i546[29], i546[28], i546[27], i546[26], i546[25], i546[24], i546[23], i546[22], i546[21], i546[20], i546[19], i546[18], i546[17], i546[16], i546[15], i546[14], i546[13], i546[12], i546[11], i546[10], i546[9], i546[8], i546[7], i546[6], i546[5], i546[4], i546[3], i546[2], i546[1], i546[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i550[33], i550[32], i550[31], i550[30], i550[29], i550[28], i550[27], i550[26], i550[25], i550[24], i550[23], i550[22], i550[21], i550[20], i550[19], i550[18], i550[17], i550[16], i550[15], i550[14], i550[13], i550[12], i550[11], i550[10], i550[9], i550[8], i550[7], i550[6], i550[5], i550[4], i550[3], i550[2], i550[1], i550[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i554[3], i554[2], i554[1], i554[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589_reduce(input wire [63:0] i568, input wire [32:0] i571, input wire [32:0] i575, input wire [1:0] i579, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i568[63], i568[62], i568[61], i568[60], i568[59], i568[58], i568[57], i568[56], i568[55], i568[54], i568[53], i568[52], i568[51], i568[50], i568[49], i568[48], i568[47], i568[46], i568[45], i568[44], i568[43], i568[42], i568[41], i568[40], i568[39], i568[38], i568[37], i568[36], i568[35], i568[34], i568[33], i568[32], i568[31], i568[30], i568[29], i568[28], i568[27], i568[26], i568[25], i568[24], i568[23], i568[22], i568[21], i568[20], i568[19], i568[18], i568[17], i568[16], i568[15], i568[14], i568[13], i568[12], i568[11], i568[10], i568[9], i568[8], i568[7], i568[6], i568[5], i568[4], i568[3], i568[2], i568[1], i568[0]};
wire [65:0] t1 = {1'b0, i571[32], i571[31], i571[30], i571[29], i571[28], i571[27], i571[26], i571[25], i571[24], i571[23], i571[22], i571[21], i571[20], i571[19], i571[18], i571[17], i571[16], i571[15], i571[14], i571[13], i571[12], i571[11], i571[10], i571[9], i571[8], i571[7], i571[6], i571[5], i571[4], i571[3], i571[2], i571[1], i571[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i575[32], i575[31], i575[30], i575[29], i575[28], i575[27], i575[26], i575[25], i575[24], i575[23], i575[22], i575[21], i575[20], i575[19], i575[18], i575[17], i575[16], i575[15], i575[14], i575[13], i575[12], i575[11], i575[10], i575[9], i575[8], i575[7], i575[6], i575[5], i575[4], i575[3], i575[2], i575[1], i575[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i579[1], i579[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_617_reduce(input wire [63:0] i596, input wire [33:0] i599, input wire [33:0] i603, input wire [3:0] i607, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i596[63], i596[62], i596[61], i596[60], i596[59], i596[58], i596[57], i596[56], i596[55], i596[54], i596[53], i596[52], i596[51], i596[50], i596[49], i596[48], i596[47], i596[46], i596[45], i596[44], i596[43], i596[42], i596[41], i596[40], i596[39], i596[38], i596[37], i596[36], i596[35], i596[34], i596[33], i596[32], i596[31], i596[30], i596[29], i596[28], i596[27], i596[26], i596[25], i596[24], i596[23], i596[22], i596[21], i596[20], i596[19], i596[18], i596[17], i596[16], i596[15], i596[14], i596[13], i596[12], i596[11], i596[10], i596[9], i596[8], i596[7], i596[6], i596[5], i596[4], i596[3], i596[2], i596[1], i596[0]};
wire [67:0] t1 = {1'b0, 1'b0, i599[33], i599[32], i599[31], i599[30], i599[29], i599[28], i599[27], i599[26], i599[25], i599[24], i599[23], i599[22], i599[21], i599[20], i599[19], i599[18], i599[17], i599[16], i599[15], i599[14], i599[13], i599[12], i599[11], i599[10], i599[9], i599[8], i599[7], i599[6], i599[5], i599[4], i599[3], i599[2], i599[1], i599[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i603[33], i603[32], i603[31], i603[30], i603[29], i603[28], i603[27], i603[26], i603[25], i603[24], i603[23], i603[22], i603[21], i603[20], i603[19], i603[18], i603[17], i603[16], i603[15], i603[14], i603[13], i603[12], i603[11], i603[10], i603[9], i603[8], i603[7], i603[6], i603[5], i603[4], i603[3], i603[2], i603[1], i603[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i607[3], i607[2], i607[1], i607[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_642_reduce(input wire [63:0] i621, input wire [63:0] i624, input wire [63:0] i628, input wire [63:0] i632, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i621[63], i621[62], i621[61], i621[60], i621[59], i621[58], i621[57], i621[56], i621[55], i621[54], i621[53], i621[52], i621[51], i621[50], i621[49], i621[48], i621[47], i621[46], i621[45], i621[44], i621[43], i621[42], i621[41], i621[40], i621[39], i621[38], i621[37], i621[36], i621[35], i621[34], i621[33], i621[32], i621[31], i621[30], i621[29], i621[28], i621[27], i621[26], i621[25], i621[24], i621[23], i621[22], i621[21], i621[20], i621[19], i621[18], i621[17], i621[16], i621[15], i621[14], i621[13], i621[12], i621[11], i621[10], i621[9], i621[8], i621[7], i621[6], i621[5], i621[4], i621[3], i621[2], i621[1], i621[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i624[63], i624[62], i624[61], i624[60], i624[59], i624[58], i624[57], i624[56], i624[55], i624[54], i624[53], i624[52], i624[51], i624[50], i624[49], i624[48], i624[47], i624[46], i624[45], i624[44], i624[43], i624[42], i624[41], i624[40], i624[39], i624[38], i624[37], i624[36], i624[35], i624[34], i624[33], i624[32], i624[31], i624[30], i624[29], i624[28], i624[27], i624[26], i624[25], i624[24], i624[23], i624[22], i624[21], i624[20], i624[19], i624[18], i624[17], i624[16], i624[15], i624[14], i624[13], i624[12], i624[11], i624[10], i624[9], i624[8], i624[7], i624[6], i624[5], i624[4], i624[3], i624[2], i624[1], i624[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i628[63], i628[62], i628[61], i628[60], i628[59], i628[58], i628[57], i628[56], i628[55], i628[54], i628[53], i628[52], i628[51], i628[50], i628[49], i628[48], i628[47], i628[46], i628[45], i628[44], i628[43], i628[42], i628[41], i628[40], i628[39], i628[38], i628[37], i628[36], i628[35], i628[34], i628[33], i628[32], i628[31], i628[30], i628[29], i628[28], i628[27], i628[26], i628[25], i628[24], i628[23], i628[22], i628[21], i628[20], i628[19], i628[18], i628[17], i628[16], i628[15], i628[14], i628[13], i628[12], i628[11], i628[10], i628[9], i628[8], i628[7], i628[6], i628[5], i628[4], i628[3], i628[2], i628[1], i628[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i632[63], i632[62], i632[61], i632[60], i632[59], i632[58], i632[57], i632[56], i632[55], i632[54], i632[53], i632[52], i632[51], i632[50], i632[49], i632[48], i632[47], i632[46], i632[45], i632[44], i632[43], i632[42], i632[41], i632[40], i632[39], i632[38], i632[37], i632[36], i632[35], i632[34], i632[33], i632[32], i632[31], i632[30], i632[29], i632[28], i632[27], i632[26], i632[25], i632[24], i632[23], i632[22], i632[21], i632[20], i632[19], i632[18], i632[17], i632[16], i632[15], i632[14], i632[13], i632[12], i632[11], i632[10], i632[9], i632[8], i632[7], i632[6], i632[5], i632[4], i632[3], i632[2], i632[1], i632[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_667_reduce(input wire [63:0] i646, input wire [32:0] i649, input wire [32:0] i653, input wire [1:0] i657, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i646[63], i646[62], i646[61], i646[60], i646[59], i646[58], i646[57], i646[56], i646[55], i646[54], i646[53], i646[52], i646[51], i646[50], i646[49], i646[48], i646[47], i646[46], i646[45], i646[44], i646[43], i646[42], i646[41], i646[40], i646[39], i646[38], i646[37], i646[36], i646[35], i646[34], i646[33], i646[32], i646[31], i646[30], i646[29], i646[28], i646[27], i646[26], i646[25], i646[24], i646[23], i646[22], i646[21], i646[20], i646[19], i646[18], i646[17], i646[16], i646[15], i646[14], i646[13], i646[12], i646[11], i646[10], i646[9], i646[8], i646[7], i646[6], i646[5], i646[4], i646[3], i646[2], i646[1], i646[0]};
wire [65:0] t1 = {1'b0, i649[32], i649[31], i649[30], i649[29], i649[28], i649[27], i649[26], i649[25], i649[24], i649[23], i649[22], i649[21], i649[20], i649[19], i649[18], i649[17], i649[16], i649[15], i649[14], i649[13], i649[12], i649[11], i649[10], i649[9], i649[8], i649[7], i649[6], i649[5], i649[4], i649[3], i649[2], i649[1], i649[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i653[32], i653[31], i653[30], i653[29], i653[28], i653[27], i653[26], i653[25], i653[24], i653[23], i653[22], i653[21], i653[20], i653[19], i653[18], i653[17], i653[16], i653[15], i653[14], i653[13], i653[12], i653[11], i653[10], i653[9], i653[8], i653[7], i653[6], i653[5], i653[4], i653[3], i653[2], i653[1], i653[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i657[1], i657[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_692_reduce(input wire [63:0] i671, input wire [32:0] i674, input wire [32:0] i678, input wire [1:0] i682, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i671[63], i671[62], i671[61], i671[60], i671[59], i671[58], i671[57], i671[56], i671[55], i671[54], i671[53], i671[52], i671[51], i671[50], i671[49], i671[48], i671[47], i671[46], i671[45], i671[44], i671[43], i671[42], i671[41], i671[40], i671[39], i671[38], i671[37], i671[36], i671[35], i671[34], i671[33], i671[32], i671[31], i671[30], i671[29], i671[28], i671[27], i671[26], i671[25], i671[24], i671[23], i671[22], i671[21], i671[20], i671[19], i671[18], i671[17], i671[16], i671[15], i671[14], i671[13], i671[12], i671[11], i671[10], i671[9], i671[8], i671[7], i671[6], i671[5], i671[4], i671[3], i671[2], i671[1], i671[0]};
wire [65:0] t1 = {1'b0, i674[32], i674[31], i674[30], i674[29], i674[28], i674[27], i674[26], i674[25], i674[24], i674[23], i674[22], i674[21], i674[20], i674[19], i674[18], i674[17], i674[16], i674[15], i674[14], i674[13], i674[12], i674[11], i674[10], i674[9], i674[8], i674[7], i674[6], i674[5], i674[4], i674[3], i674[2], i674[1], i674[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i678[32], i678[31], i678[30], i678[29], i678[28], i678[27], i678[26], i678[25], i678[24], i678[23], i678[22], i678[21], i678[20], i678[19], i678[18], i678[17], i678[16], i678[15], i678[14], i678[13], i678[12], i678[11], i678[10], i678[9], i678[8], i678[7], i678[6], i678[5], i678[4], i678[3], i678[2], i678[1], i678[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i682[1], i682[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_717_reduce(input wire [63:0] i696, input wire [33:0] i699, input wire [33:0] i703, input wire [3:0] i707, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i696[63], i696[62], i696[61], i696[60], i696[59], i696[58], i696[57], i696[56], i696[55], i696[54], i696[53], i696[52], i696[51], i696[50], i696[49], i696[48], i696[47], i696[46], i696[45], i696[44], i696[43], i696[42], i696[41], i696[40], i696[39], i696[38], i696[37], i696[36], i696[35], i696[34], i696[33], i696[32], i696[31], i696[30], i696[29], i696[28], i696[27], i696[26], i696[25], i696[24], i696[23], i696[22], i696[21], i696[20], i696[19], i696[18], i696[17], i696[16], i696[15], i696[14], i696[13], i696[12], i696[11], i696[10], i696[9], i696[8], i696[7], i696[6], i696[5], i696[4], i696[3], i696[2], i696[1], i696[0]};
wire [67:0] t1 = {1'b0, 1'b0, i699[33], i699[32], i699[31], i699[30], i699[29], i699[28], i699[27], i699[26], i699[25], i699[24], i699[23], i699[22], i699[21], i699[20], i699[19], i699[18], i699[17], i699[16], i699[15], i699[14], i699[13], i699[12], i699[11], i699[10], i699[9], i699[8], i699[7], i699[6], i699[5], i699[4], i699[3], i699[2], i699[1], i699[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i703[33], i703[32], i703[31], i703[30], i703[29], i703[28], i703[27], i703[26], i703[25], i703[24], i703[23], i703[22], i703[21], i703[20], i703[19], i703[18], i703[17], i703[16], i703[15], i703[14], i703[13], i703[12], i703[11], i703[10], i703[9], i703[8], i703[7], i703[6], i703[5], i703[4], i703[3], i703[2], i703[1], i703[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i707[3], i707[2], i707[1], i707[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [63:0] a,input wire [65:0] b,input wire cin,output wire [66:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [65:0] masked_b=((b&66'h3ffffffff00000000)|66'h0);
wire [66:0] aa=67'(masked_a);
wire [66:0] bb=67'(masked_b);
wire [67:0] extended={1'b0,aa}+{1'b0,bb}+68'(1'b0);
wire [66:0] native_value=extended[66:0];
assign value=native_value[0+:67];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_458Core(input wire [65:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [65:0] masked_a=((a&66'h3ffffffff00000000)|66'h0);
wire [67:0] masked_b=((b&68'hf0000000000000000)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}+{1'b0,bb}+69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_458();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461Core(input wire [66:0] a,input wire [68:0] b,input wire cin,output wire [67:0] value);
wire [66:0] masked_a=((a&67'h7ffffffffffffffff)|67'h0);
wire [68:0] masked_b=((b&69'h1fffffffffffffffff)|69'h0);
wire [68:0] aa=69'(masked_b);
wire [68:0] bb=69'(masked_a);
wire [69:0] extended={1'b0,aa}+{1'b0,bb}+70'(1'b0);
wire [68:0] native_value=extended[68:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_721Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_721();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_741Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_741();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_746Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_746();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_751Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_751();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_756Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_756();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_761Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_761();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_802Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_802();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_808Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_808();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_814Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_814();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_820Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_820();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_826Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_826();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_832Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_832();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_838Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_838();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_844Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_844();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_850Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_850();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_856Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_856();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_867Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_867();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_872Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_872();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_877Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_877();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_882Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_882();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_887Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_887();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_892Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_892();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_897Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_897();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_902Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_902();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_918Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_918();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_924Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_924();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_930Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_930();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_936Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_936();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_942Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_942();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_948Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_948();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_954Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_954();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_960Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_960();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_966Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_966();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_972Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_972();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_978Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_978();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_984Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_984();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_990Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_990();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_996Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_996();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1002Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1002();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1008Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1008();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1013Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1013();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1018Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1018();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1023Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1023();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1033Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1033();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1038Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1038();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1043Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1043();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1048Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1048();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1053Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1053();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1063Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1063();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1068Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1068();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1073Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1073();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1078Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1078();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1096Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1096();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1102Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1108Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1114Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1119Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1119();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1124Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1134Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1139Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1149Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1154Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1164Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1170Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1176Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1182Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1182();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1188Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1194Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1200Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1206Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1212Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1218Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1224Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1230Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1236Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1242Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1242();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1248Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1254Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1260Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1266Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1272Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1272();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1278Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1278();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1290Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1290();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1296Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1296();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1302Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1302();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1308Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1308();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1314Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1314();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1320Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1320();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1326Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1326();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1332Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1332();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1338Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1338();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1344Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1344();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1350Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1350();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1356Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1356();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1362Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1362();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1368Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1368();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1378Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1378();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1383Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1383();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1388Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1393Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1393();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1403Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1403();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1408Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1408();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1413Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1413();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1418Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1418();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1423Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1428Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1428();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1433Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1433();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1438Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1443Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1448Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1448();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1453Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1453();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1458Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1458();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1463Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1463();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1468Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1468();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1473Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1473();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1478Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1478();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1483Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1483();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1488Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1488();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1493Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1493();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1498Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1498();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1503Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1503();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1508Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1508();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1513Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1513();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1518Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1518();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1523Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1523();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1528Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1528();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1533Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1533();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1538Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1538();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1543Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1543();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1548Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1548();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1553Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1553();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1558Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1558();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1563Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1563();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1568Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1568();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1573Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1573();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1578Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1578();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1583Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1583();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1588Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1588();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1593Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1593();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1598Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1598();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1603Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1603();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1608Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1608();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1613Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1613();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1618Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1618();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1623Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1623();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1628Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1633Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1633();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1638Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h3)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1638();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1643Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1643();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1648Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1648();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1653Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1653();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1658Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1658();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1663Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1663();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1668Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1668();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1673Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1673();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1678Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1678();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1683Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1683();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1688Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1688();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1693Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1693();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1698Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1698();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1703Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1703();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1708Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1708();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1713Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1713();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1718Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1718();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1723Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1723();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1728Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1728();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1733Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1733();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1738Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1738();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1743Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1743();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1748Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1748();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1753Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1753();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1758Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1758();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1763Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1763();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1768Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1768();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1773Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1773();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1778Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1778();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1783Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1783();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1788Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1788();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1793Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1793();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1798Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1798();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1803Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1803();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1808Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1808();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1813Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1813();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1818Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1818();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1823Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1823();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1828Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1828();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1833Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1833();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1838Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1838();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1843Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1843();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1848Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1848();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1853Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1853();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1858Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1858();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1863Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1863();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1868Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1868();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1873Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1873();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1878Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1878();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1883Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1883();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1888Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h0)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_b);
wire [3:0] bb=4'(masked_a);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1888();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1893Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1893();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1898Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1898();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1903Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1903();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1908Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1908();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1913Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1913();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1918Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1918();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1923Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1923();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1928Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1928();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1933Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1933();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1938Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1938();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1943Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1943();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1948Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1948();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1953Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1953();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1958Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1958();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1963Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1963();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1968Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1968();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1973Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1973();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1978Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1978();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1983Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1983();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1988Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1988();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1993Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1993();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1998Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1998();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2003Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2003();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2008Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2008();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2013Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2013();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2018Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2018();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2023Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2023();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2028Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2028();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2033Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2033();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2038Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2038();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2043Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2043();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2048Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2048();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2053Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2053();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2058Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2058();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2063Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_2063();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
