`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] rtlzz_pipe_34_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [128:0] rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [127:0] rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [128:0] rtlzz_pipe_50_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [127:0] rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [128:0] rtlzz_pipe_51_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [127:0] rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_39_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_40_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [128:0] rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [129:0] rtlzz_pipe_58_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [127:0] rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [128:0] rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] rtlzz_pipe_53_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [127:0] rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [128:0] rtlzz_pipe_54_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [129:0] rtlzz_pipe_59_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [127:0] rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] rtlzz_pipe_56_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [128:0] rtlzz_pipe_56_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(128'(rtlzz_pipe_33_s3)), .b(128'(rtlzz_pipe_34_s3)), .cin(1'b0), .value(s8_norm_add_64_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(128'(rtlzz_pipe_35_s6)), .b(128'(rtlzz_pipe_36_s6)), .cin(1'b0), .value(s8_norm_add_65_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(128'(s8_norm_mul_18_v0)), .b(128'(rtlzz_pipe_38_s5)), .cin(1'b0), .value(s8_norm_add_66_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(128'(rtlzz_pipe_39_s3)), .b(128'(rtlzz_pipe_40_s3)), .cin(1'b0), .value(s8_norm_add_67_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(128'(rtlzz_pipe_41_s4)), .b(128'(s8_norm_mul_38_v0)), .cin(1'b0), .value(s8_norm_add_68_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(128'(rtlzz_pipe_43_s5)), .b(128'(rtlzz_pipe_44_s5)), .cin(1'b0), .value(s8_norm_add_69_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(128'(rtlzz_pipe_47_s5)), .b(128'(rtlzz_pipe_48_s5)), .cin(1'b0), .value(s8_norm_add_71_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(129'(rtlzz_pipe_51_s6)), .b(129'(rtlzz_pipe_52_s6)), .cin(1'b0), .value(s8_norm_add_73_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_59Core rtlzz_owner_59(.a(129'(rtlzz_pipe_53_s6)), .b(129'(rtlzz_pipe_54_s6)), .cin(1'b0), .value(s8_norm_add_74_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63_reduce rtlzz_reduce_63(.i143(arith_original_143), .i222(rtlzz_pipe_49_s7), .i229(rtlzz_pipe_50_s7), .i242(rtlzz_pipe_58_s7), .i257(rtlzz_pipe_59_s7), .i261(rtlzz_pipe_45_s7), .i271(rtlzz_pipe_56_s7), .y(s8_norm_add_78_v0));
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(64'(mul_precision_98)), .b(64'(mul_precision_99)), .cin(1'b0), .value(arith_original_130));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(64'(rtlzz_pipe_100_s1)), .b(64'(rtlzz_pipe_101_s1)), .cin(1'b0), .value(arith_original_131));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(64'(rtlzz_pipe_102_s2)), .b(64'(rtlzz_pipe_103_s2)), .cin(1'b0), .value(arith_original_132));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_133Core rtlzz_owner_133(.a(64'(rtlzz_pipe_104_s4)), .b(64'(rtlzz_pipe_105_s4)), .cin(1'b0), .value(arith_original_133));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(64'(rtlzz_pipe_106_s5)), .b(64'(rtlzz_pipe_107_s5)), .cin(1'b0), .value(arith_original_134));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_135Core rtlzz_owner_135(.a(64'(mul_precision_108)), .b(64'(mul_precision_109)), .cin(1'b0), .value(arith_original_135));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(64'(rtlzz_pipe_110_s1)), .b(64'(rtlzz_pipe_111_s1)), .cin(1'b0), .value(arith_original_136));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_137Core rtlzz_owner_137(.a(64'(rtlzz_pipe_112_s2)), .b(64'(rtlzz_pipe_113_s2)), .cin(1'b0), .value(arith_original_137));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(64'(mul_precision_114)), .b(64'(mul_precision_115)), .cin(1'b0), .value(arith_original_138));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_139Core rtlzz_owner_139(.a(64'(rtlzz_pipe_116_s4)), .b(64'(rtlzz_pipe_117_s4)), .cin(1'b0), .value(arith_original_139));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(64'(rtlzz_pipe_118_s1)), .b(64'(rtlzz_pipe_119_s1)), .cin(1'b0), .value(arith_original_140));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_141Core rtlzz_owner_141(.a(64'(rtlzz_pipe_120_s2)), .b(64'(rtlzz_pipe_121_s2)), .cin(1'b0), .value(arith_original_141));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(64'(rtlzz_pipe_122_s3)), .b(64'(rtlzz_pipe_123_s3)), .cin(1'b0), .value(arith_original_142));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(64'(rtlzz_pipe_124_s7)), .b(64'(rtlzz_pipe_125_s7)), .cin(1'b0), .value(arith_original_143));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(64'(mul_precision_126)), .b(64'(mul_precision_127)), .cin(1'b0), .value(arith_original_144));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_145Core rtlzz_owner_145(.a(64'(rtlzz_pipe_128_s2)), .b(64'(rtlzz_pipe_129_s2)), .cin(1'b0), .value(arith_original_145));
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_104_s1 <= 64'h0;
            rtlzz_pipe_104_s2 <= 64'h0;
            rtlzz_pipe_104_s3 <= 64'h0;
            rtlzz_pipe_104_s4 <= 64'h0;
            rtlzz_pipe_105_s1 <= 64'h0;
            rtlzz_pipe_105_s2 <= 64'h0;
            rtlzz_pipe_105_s3 <= 64'h0;
            rtlzz_pipe_105_s4 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_106_s4 <= 64'h0;
            rtlzz_pipe_106_s5 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_107_s4 <= 64'h0;
            rtlzz_pipe_107_s5 <= 64'h0;
            rtlzz_pipe_110_s1 <= 64'h0;
            rtlzz_pipe_111_s1 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_116_s1 <= 64'h0;
            rtlzz_pipe_116_s2 <= 64'h0;
            rtlzz_pipe_116_s3 <= 64'h0;
            rtlzz_pipe_116_s4 <= 64'h0;
            rtlzz_pipe_117_s1 <= 64'h0;
            rtlzz_pipe_117_s2 <= 64'h0;
            rtlzz_pipe_117_s3 <= 64'h0;
            rtlzz_pipe_117_s4 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_120_s1 <= 64'h0;
            rtlzz_pipe_120_s2 <= 64'h0;
            rtlzz_pipe_121_s1 <= 64'h0;
            rtlzz_pipe_121_s2 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_124_s6 <= 64'h0;
            rtlzz_pipe_124_s7 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_125_s6 <= 64'h0;
            rtlzz_pipe_125_s7 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_128_s2 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_129_s2 <= 64'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_33_s2 <= 128'h0;
            rtlzz_pipe_33_s3 <= 128'h0;
            rtlzz_pipe_34_s2 <= 128'h0;
            rtlzz_pipe_34_s3 <= 128'h0;
            rtlzz_pipe_49_s4 <= 129'h0;
            rtlzz_pipe_49_s5 <= 129'h0;
            rtlzz_pipe_49_s6 <= 129'h0;
            rtlzz_pipe_49_s7 <= 129'h0;
            rtlzz_pipe_35_s3 <= 128'h0;
            rtlzz_pipe_35_s4 <= 128'h0;
            rtlzz_pipe_35_s5 <= 128'h0;
            rtlzz_pipe_35_s6 <= 128'h0;
            rtlzz_pipe_36_s5 <= 128'h0;
            rtlzz_pipe_36_s6 <= 128'h0;
            rtlzz_pipe_50_s7 <= 129'h0;
            rtlzz_pipe_38_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 128'h0;
            rtlzz_pipe_38_s3 <= 128'h0;
            rtlzz_pipe_38_s4 <= 128'h0;
            rtlzz_pipe_38_s5 <= 128'h0;
            rtlzz_pipe_51_s6 <= 129'h0;
            rtlzz_pipe_39_s2 <= 128'h0;
            rtlzz_pipe_39_s3 <= 128'h0;
            rtlzz_pipe_40_s3 <= 128'h0;
            rtlzz_pipe_52_s4 <= 129'h0;
            rtlzz_pipe_52_s5 <= 129'h0;
            rtlzz_pipe_52_s6 <= 129'h0;
            rtlzz_pipe_58_s7 <= 130'h0;
            rtlzz_pipe_41_s1 <= 128'h0;
            rtlzz_pipe_41_s2 <= 128'h0;
            rtlzz_pipe_41_s3 <= 128'h0;
            rtlzz_pipe_41_s4 <= 128'h0;
            rtlzz_pipe_53_s5 <= 129'h0;
            rtlzz_pipe_53_s6 <= 129'h0;
            rtlzz_pipe_43_s2 <= 128'h0;
            rtlzz_pipe_43_s3 <= 128'h0;
            rtlzz_pipe_43_s4 <= 128'h0;
            rtlzz_pipe_43_s5 <= 128'h0;
            rtlzz_pipe_44_s3 <= 128'h0;
            rtlzz_pipe_44_s4 <= 128'h0;
            rtlzz_pipe_44_s5 <= 128'h0;
            rtlzz_pipe_54_s6 <= 129'h0;
            rtlzz_pipe_59_s7 <= 130'h0;
            rtlzz_pipe_45_s4 <= 128'h0;
            rtlzz_pipe_45_s5 <= 128'h0;
            rtlzz_pipe_45_s6 <= 128'h0;
            rtlzz_pipe_45_s7 <= 128'h0;
            rtlzz_pipe_47_s1 <= 128'h0;
            rtlzz_pipe_47_s2 <= 128'h0;
            rtlzz_pipe_47_s3 <= 128'h0;
            rtlzz_pipe_47_s4 <= 128'h0;
            rtlzz_pipe_47_s5 <= 128'h0;
            rtlzz_pipe_48_s3 <= 128'h0;
            rtlzz_pipe_48_s4 <= 128'h0;
            rtlzz_pipe_48_s5 <= 128'h0;
            rtlzz_pipe_56_s6 <= 129'h0;
            rtlzz_pipe_56_s7 <= 129'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_104_s1 <= mul_precision_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_104_s3 <= rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_104_s4 <= rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_precision_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_105_s2 <= rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_105_s3 <= rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_105_s4 <= rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_106_s4 <= rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_107_s4 <= rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_107_s5 <= rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_110_s1 <= mul_precision_110; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_precision_111; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_116_s1 <= mul_precision_116; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_116_s2 <= rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_116_s3 <= rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_116_s4 <= rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_precision_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_117_s2 <= rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_117_s3 <= rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_117_s4 <= rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_120_s1 <= mul_precision_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_120_s2 <= rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_precision_121; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_121_s2 <= rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_124_s6 <= rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_124_s7 <= rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_125_s6 <= rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_125_s7 <= rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_128_s2 <= rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_129_s2 <= rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_34_s2 <= s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_49_s4 <= s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_49_s5 <= rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_49_s6 <= rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_49_s7 <= rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_36_s6 <= rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_50_s7 <= s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_38_s4 <= rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_38_s5 <= rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_51_s6 <= s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_39_s2 <= s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_39_s3 <= rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_40_s3 <= s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_58_s7 <= s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_41_s3 <= rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_41_s4 <= rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_53_s5 <= s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_53_s6 <= rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_43_s3 <= rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_43_s4 <= rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_43_s5 <= rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_44_s4 <= rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_54_s6 <= s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_59_s7 <= s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_45_s4 <= s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_45_s5 <= rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_47_s3 <= rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_47_s4 <= rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_47_s5 <= rtlzz_pipe_47_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_48_s4 <= rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_48_s5 <= rtlzz_pipe_48_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_56_s6 <= s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_56_s7 <= rtlzz_pipe_56_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63_reduce(input wire [127:0] i143, input wire [128:0] i222, input wire [128:0] i229, input wire [129:0] i242, input wire [129:0] i257, input wire [127:0] i261, input wire [128:0] i271, output wire [131:0] y);
wire [131:0] t0 = {1'b0, 1'b0, 1'b0, i222[128], i222[127], i222[126], i222[125], i222[124], i222[123], i222[122], i222[121], i222[120], i222[119], i222[118], i222[117], i222[116], i222[115], i222[114], i222[113], i222[112], i222[111], i222[110], i222[109], i222[108], i222[107], i222[106], i222[105], i222[104], i222[103], i222[102], i222[101], i222[100], i222[99], i222[98], i222[97], i222[96], i222[95], i222[94], i222[93], i222[92], i222[91], i222[90], i222[89], i222[88], i222[87], i222[86], i222[85], i222[84], i222[83], i222[82], i222[81], i222[80], i222[79], i222[78], i222[77], i222[76], i222[75], i222[74], i222[73], i222[72], i222[71], i222[70], i222[69], i222[68], i222[67], i222[66], i222[65], i222[64], i222[63], i222[62], i222[61], i222[60], i222[59], i222[58], i222[57], i222[56], i222[55], i222[54], i222[53], i222[52], i222[51], i222[50], i222[49], i222[48], i222[47], i222[46], i222[45], i222[44], i222[43], i222[42], i222[41], i222[40], i222[39], i222[38], i222[37], i222[36], i222[35], i222[34], i222[33], i222[32], i222[31], i222[30], i222[29], i222[28], i222[27], i222[26], i222[25], i222[24], i222[23], i222[22], i222[21], i222[20], i222[19], i222[18], i222[17], i222[16], i222[15], i222[14], i222[13], i222[12], i222[11], i222[10], i222[9], i222[8], i222[7], i222[6], i222[5], i222[4], i222[3], i222[2], i222[1], i222[0]};
wire [131:0] t1 = {1'b0, 1'b0, 1'b0, i229[128], i229[127], i229[126], i229[125], i229[124], i229[123], i229[122], i229[121], i229[120], i229[119], i229[118], i229[117], i229[116], i229[115], i229[114], i229[113], i229[112], i229[111], i229[110], i229[109], i229[108], i229[107], i229[106], i229[105], i229[104], i229[103], i229[102], i229[101], i229[100], i229[99], i229[98], i229[97], i229[96], i229[95], i229[94], i229[93], i229[92], i229[91], i229[90], i229[89], i229[88], i229[87], i229[86], i229[85], i229[84], i229[83], i229[82], i229[81], i229[80], i229[79], i229[78], i229[77], i229[76], i229[75], i229[74], i229[73], i229[72], i229[71], i229[70], i229[69], i229[68], i229[67], i229[66], i229[65], i229[64], i229[63], i229[62], i229[61], i229[60], i229[59], i229[58], i229[57], i229[56], i229[55], i229[54], i229[53], i229[52], i229[51], i229[50], i229[49], i229[48], i229[47], i229[46], i229[45], i229[44], i229[43], i229[42], i229[41], i229[40], i229[39], i229[38], i229[37], i229[36], i229[35], i229[34], i229[33], i229[32], i229[31], i229[30], i229[29], i229[28], i229[27], i229[26], i229[25], i229[24], i229[23], i229[22], i229[21], i229[20], i229[19], i229[18], i229[17], i229[16], i229[15], i229[14], i229[13], i229[12], i229[11], i229[10], i229[9], i229[8], i229[7], i229[6], i229[5], i229[4], i229[3], i229[2], i229[1], i229[0]};
wire [131:0] t2 = {1'b0, 1'b0, i242[129], i242[128], i242[127], i242[126], i242[125], i242[124], i242[123], i242[122], i242[121], i242[120], i242[119], i242[118], i242[117], i242[116], i242[115], i242[114], i242[113], i242[112], i242[111], i242[110], i242[109], i242[108], i242[107], i242[106], i242[105], i242[104], i242[103], i242[102], i242[101], i242[100], i242[99], i242[98], i242[97], i242[96], i242[95], i242[94], i242[93], i242[92], i242[91], i242[90], i242[89], i242[88], i242[87], i242[86], i242[85], i242[84], i242[83], i242[82], i242[81], i242[80], i242[79], i242[78], i242[77], i242[76], i242[75], i242[74], i242[73], i242[72], i242[71], i242[70], i242[69], i242[68], i242[67], i242[66], i242[65], i242[64], i242[63], i242[62], i242[61], i242[60], i242[59], i242[58], i242[57], i242[56], i242[55], i242[54], i242[53], i242[52], i242[51], i242[50], i242[49], i242[48], i242[47], i242[46], i242[45], i242[44], i242[43], i242[42], i242[41], i242[40], i242[39], i242[38], i242[37], i242[36], i242[35], i242[34], i242[33], i242[32], i242[31], i242[30], i242[29], i242[28], i242[27], i242[26], i242[25], i242[24], i242[23], i242[22], i242[21], i242[20], i242[19], i242[18], i242[17], i242[16], i242[15], i242[14], i242[13], i242[12], i242[11], i242[10], i242[9], i242[8], i242[7], i242[6], i242[5], i242[4], i242[3], i242[2], i242[1], i242[0]};
wire [131:0] t3 = {1'b0, 1'b0, i257[129], i257[128], i257[127], i257[126], i257[125], i257[124], i257[123], i257[122], i257[121], i257[120], i257[119], i257[118], i257[117], i257[116], i257[115], i257[114], i257[113], i257[112], i257[111], i257[110], i257[109], i257[108], i257[107], i257[106], i257[105], i257[104], i257[103], i257[102], i257[101], i257[100], i257[99], i257[98], i257[97], i257[96], i257[95], i257[94], i257[93], i257[92], i257[91], i257[90], i257[89], i257[88], i257[87], i257[86], i257[85], i257[84], i257[83], i257[82], i257[81], i257[80], i257[79], i257[78], i257[77], i257[76], i257[75], i257[74], i257[73], i257[72], i257[71], i257[70], i257[69], i257[68], i257[67], i257[66], i257[65], i257[64], i257[63], i257[62], i257[61], i257[60], i257[59], i257[58], i257[57], i257[56], i257[55], i257[54], i257[53], i257[52], i257[51], i257[50], i257[49], i257[48], i257[47], i257[46], i257[45], i257[44], i257[43], i257[42], i257[41], i257[40], i257[39], i257[38], i257[37], i257[36], i257[35], i257[34], i257[33], i257[32], i257[31], i257[30], i257[29], i257[28], i257[27], i257[26], i257[25], i257[24], i257[23], i257[22], i257[21], i257[20], i257[19], i257[18], i257[17], i257[16], i257[15], i257[14], i257[13], i257[12], i257[11], i257[10], i257[9], i257[8], i257[7], i257[6], i257[5], i257[4], i257[3], i257[2], i257[1], i257[0]};
wire [131:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, i261[127], i261[126], i261[125], i261[124], i261[123], i261[122], i261[121], i261[120], i261[119], i261[118], i261[117], i261[116], i261[115], i261[114], i261[113], i261[112], i261[111], i261[110], i261[109], i261[108], i261[107], i261[106], i261[105], i261[104], i261[103], i261[102], i261[101], i261[100], i261[99], i261[98], i261[97], i261[96], i261[95], i261[94], i261[93], i261[92], i261[91], i261[90], i261[89], i261[88], i261[87], i261[86], i261[85], i261[84], i261[83], i261[82], i261[81], i261[80], i261[79], i261[78], i261[77], i261[76], i261[75], i261[74], i261[73], i261[72], i261[71], i261[70], i261[69], i261[68], i261[67], i261[66], i261[65], i261[64], i261[63], i261[62], i261[61], i261[60], i261[59], i261[58], i261[57], i261[56], i261[55], i261[54], i261[53], i261[52], i261[51], i261[50], i261[49], i261[48], i261[47], i261[46], i261[45], i261[44], i261[43], i261[42], i261[41], i261[40], i261[39], i261[38], i261[37], i261[36], i261[35], i261[34], i261[33], i261[32], i261[31], i261[30], i261[29], i261[28], i261[27], i261[26], i261[25], i261[24], i261[23], i261[22], i261[21], i261[20], i261[19], i261[18], i261[17], i261[16], i261[15], i261[14], i261[13], i261[12], i261[11], i261[10], i261[9], i261[8], i261[7], i261[6], i261[5], i261[4], i261[3], i261[2], i261[1], i261[0]};
wire [131:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, i143[127], i143[126], i143[125], i143[124], i143[123], i143[122], i143[121], i143[120], i143[119], i143[118], i143[117], i143[116], i143[115], i143[114], i143[113], i143[112], i143[111], i143[110], i143[109], i143[108], i143[107], i143[106], i143[105], i143[104], i143[103], i143[102], i143[101], i143[100], i143[99], i143[98], i143[97], i143[96], i143[95], i143[94], i143[93], i143[92], i143[91], i143[90], i143[89], i143[88], i143[87], i143[86], i143[85], i143[84], i143[83], i143[82], i143[81], i143[80], i143[79], i143[78], i143[77], i143[76], i143[75], i143[74], i143[73], i143[72], i143[71], i143[70], i143[69], i143[68], i143[67], i143[66], i143[65], i143[64], i143[63], i143[62], i143[61], i143[60], i143[59], i143[58], i143[57], i143[56], i143[55], i143[54], i143[53], i143[52], i143[51], i143[50], i143[49], i143[48], i143[47], i143[46], i143[45], i143[44], i143[43], i143[42], i143[41], i143[40], i143[39], i143[38], i143[37], i143[36], i143[35], i143[34], i143[33], i143[32], i143[31], i143[30], i143[29], i143[28], i143[27], i143[26], i143[25], i143[24], i143[23], i143[22], i143[21], i143[20], i143[19], i143[18], i143[17], i143[16], i143[15], i143[14], i143[13], i143[12], i143[11], i143[10], i143[9], i143[8], i143[7], i143[6], i143[5], i143[4], i143[3], i143[2], i143[1], i143[0]};
wire [131:0] t6 = {1'b0, 1'b0, 1'b0, i271[128], i271[127], i271[126], i271[125], i271[124], i271[123], i271[122], i271[121], i271[120], i271[119], i271[118], i271[117], i271[116], i271[115], i271[114], i271[113], i271[112], i271[111], i271[110], i271[109], i271[108], i271[107], i271[106], i271[105], i271[104], i271[103], i271[102], i271[101], i271[100], i271[99], i271[98], i271[97], i271[96], i271[95], i271[94], i271[93], i271[92], i271[91], i271[90], i271[89], i271[88], i271[87], i271[86], i271[85], i271[84], i271[83], i271[82], i271[81], i271[80], i271[79], i271[78], i271[77], i271[76], i271[75], i271[74], i271[73], i271[72], i271[71], i271[70], i271[69], i271[68], i271[67], i271[66], i271[65], i271[64], i271[63], i271[62], i271[61], i271[60], i271[59], i271[58], i271[57], i271[56], i271[55], i271[54], i271[53], i271[52], i271[51], i271[50], i271[49], i271[48], i271[47], i271[46], i271[45], i271[44], i271[43], i271[42], i271[41], i271[40], i271[39], i271[38], i271[37], i271[36], i271[35], i271[34], i271[33], i271[32], i271[31], i271[30], i271[29], i271[28], i271[27], i271[26], i271[25], i271[24], i271[23], i271[22], i271[21], i271[20], i271[19], i271[18], i271[17], i271[16], i271[15], i271[14], i271[13], i271[12], i271[11], i271[10], i271[9], i271[8], i271[7], i271[6], i271[5], i271[4], i271[3], i271[2], i271[1], i271[0]};
wire [131:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
