`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] rtlzz_pipe_34_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [128:0] rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [127:0] rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [128:0] rtlzz_pipe_50_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [127:0] rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [128:0] rtlzz_pipe_51_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [127:0] rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_39_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_40_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [128:0] rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [129:0] rtlzz_pipe_58_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [127:0] rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [128:0] rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] rtlzz_pipe_53_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [127:0] rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [128:0] rtlzz_pipe_54_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [129:0] rtlzz_pipe_59_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [127:0] rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_48_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] rtlzz_pipe_56_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(128'(rtlzz_pipe_33_s3)), .b(128'(rtlzz_pipe_34_s3)), .cin(1'b0), .value(s8_norm_add_64_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(128'(rtlzz_pipe_35_s6)), .b(128'(rtlzz_pipe_36_s6)), .cin(1'b0), .value(s8_norm_add_65_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(128'(s8_norm_mul_18_v0)), .b(128'(rtlzz_pipe_38_s5)), .cin(1'b0), .value(s8_norm_add_66_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(128'(rtlzz_pipe_39_s3)), .b(128'(rtlzz_pipe_40_s3)), .cin(1'b0), .value(s8_norm_add_67_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(128'(rtlzz_pipe_41_s4)), .b(128'(s8_norm_mul_38_v0)), .cin(1'b0), .value(s8_norm_add_68_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(128'(rtlzz_pipe_43_s5)), .b(128'(rtlzz_pipe_44_s5)), .cin(1'b0), .value(s8_norm_add_69_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(128'(rtlzz_pipe_47_s6)), .b(128'(rtlzz_pipe_48_s6)), .cin(1'b0), .value(s8_norm_add_71_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(129'(rtlzz_pipe_51_s6)), .b(129'(rtlzz_pipe_52_s6)), .cin(1'b0), .value(s8_norm_add_73_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_59Core rtlzz_owner_59(.a(129'(rtlzz_pipe_53_s6)), .b(129'(rtlzz_pipe_54_s6)), .cin(1'b0), .value(s8_norm_add_74_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63_reduce rtlzz_reduce_63(.i143(arith_original_143), .i220(rtlzz_pipe_49_s7), .i227(rtlzz_pipe_50_s7), .i240(rtlzz_pipe_58_s7), .i255(rtlzz_pipe_59_s7), .i259(rtlzz_pipe_45_s7), .i271(rtlzz_pipe_56_s7), .y(s8_norm_add_78_v0));
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(64'(mul_precision_98)), .b(64'(mul_precision_99)), .cin(1'b0), .value(arith_original_130));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(64'(rtlzz_pipe_100_s1)), .b(64'(rtlzz_pipe_101_s1)), .cin(1'b0), .value(arith_original_131));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(64'(rtlzz_pipe_102_s2)), .b(64'(rtlzz_pipe_103_s2)), .cin(1'b0), .value(arith_original_132));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_133Core rtlzz_owner_133(.a(64'(rtlzz_pipe_104_s4)), .b(64'(rtlzz_pipe_105_s4)), .cin(1'b0), .value(arith_original_133));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(64'(rtlzz_pipe_106_s5)), .b(64'(rtlzz_pipe_107_s5)), .cin(1'b0), .value(arith_original_134));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_135Core rtlzz_owner_135(.a(64'(mul_precision_108)), .b(64'(mul_precision_109)), .cin(1'b0), .value(arith_original_135));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(64'(rtlzz_pipe_110_s1)), .b(64'(rtlzz_pipe_111_s1)), .cin(1'b0), .value(arith_original_136));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_137Core rtlzz_owner_137(.a(64'(rtlzz_pipe_112_s2)), .b(64'(rtlzz_pipe_113_s2)), .cin(1'b0), .value(arith_original_137));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(64'(mul_precision_114)), .b(64'(mul_precision_115)), .cin(1'b0), .value(arith_original_138));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_139Core rtlzz_owner_139(.a(64'(rtlzz_pipe_116_s4)), .b(64'(rtlzz_pipe_117_s4)), .cin(1'b0), .value(arith_original_139));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(64'(rtlzz_pipe_118_s1)), .b(64'(rtlzz_pipe_119_s1)), .cin(1'b0), .value(arith_original_140));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_141Core rtlzz_owner_141(.a(64'(rtlzz_pipe_120_s2)), .b(64'(rtlzz_pipe_121_s2)), .cin(1'b0), .value(arith_original_141));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(64'(rtlzz_pipe_122_s3)), .b(64'(rtlzz_pipe_123_s3)), .cin(1'b0), .value(arith_original_142));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(64'(rtlzz_pipe_124_s7)), .b(64'(rtlzz_pipe_125_s7)), .cin(1'b0), .value(arith_original_143));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(64'(mul_precision_126)), .b(64'(mul_precision_127)), .cin(1'b0), .value(arith_original_144));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_145Core rtlzz_owner_145(.a(64'(rtlzz_pipe_128_s1)), .b(64'(rtlzz_pipe_129_s1)), .cin(1'b0), .value(arith_original_145));
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_104_s1 <= 64'h0;
            rtlzz_pipe_104_s2 <= 64'h0;
            rtlzz_pipe_104_s3 <= 64'h0;
            rtlzz_pipe_104_s4 <= 64'h0;
            rtlzz_pipe_105_s1 <= 64'h0;
            rtlzz_pipe_105_s2 <= 64'h0;
            rtlzz_pipe_105_s3 <= 64'h0;
            rtlzz_pipe_105_s4 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_106_s4 <= 64'h0;
            rtlzz_pipe_106_s5 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_107_s4 <= 64'h0;
            rtlzz_pipe_107_s5 <= 64'h0;
            rtlzz_pipe_110_s1 <= 64'h0;
            rtlzz_pipe_111_s1 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_116_s1 <= 64'h0;
            rtlzz_pipe_116_s2 <= 64'h0;
            rtlzz_pipe_116_s3 <= 64'h0;
            rtlzz_pipe_116_s4 <= 64'h0;
            rtlzz_pipe_117_s1 <= 64'h0;
            rtlzz_pipe_117_s2 <= 64'h0;
            rtlzz_pipe_117_s3 <= 64'h0;
            rtlzz_pipe_117_s4 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_120_s1 <= 64'h0;
            rtlzz_pipe_120_s2 <= 64'h0;
            rtlzz_pipe_121_s1 <= 64'h0;
            rtlzz_pipe_121_s2 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_124_s6 <= 64'h0;
            rtlzz_pipe_124_s7 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_125_s6 <= 64'h0;
            rtlzz_pipe_125_s7 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_33_s2 <= 128'h0;
            rtlzz_pipe_33_s3 <= 128'h0;
            rtlzz_pipe_34_s2 <= 128'h0;
            rtlzz_pipe_34_s3 <= 128'h0;
            rtlzz_pipe_49_s4 <= 129'h0;
            rtlzz_pipe_49_s5 <= 129'h0;
            rtlzz_pipe_49_s6 <= 129'h0;
            rtlzz_pipe_49_s7 <= 129'h0;
            rtlzz_pipe_35_s3 <= 128'h0;
            rtlzz_pipe_35_s4 <= 128'h0;
            rtlzz_pipe_35_s5 <= 128'h0;
            rtlzz_pipe_35_s6 <= 128'h0;
            rtlzz_pipe_36_s5 <= 128'h0;
            rtlzz_pipe_36_s6 <= 128'h0;
            rtlzz_pipe_50_s7 <= 129'h0;
            rtlzz_pipe_38_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 128'h0;
            rtlzz_pipe_38_s3 <= 128'h0;
            rtlzz_pipe_38_s4 <= 128'h0;
            rtlzz_pipe_38_s5 <= 128'h0;
            rtlzz_pipe_51_s6 <= 129'h0;
            rtlzz_pipe_39_s2 <= 128'h0;
            rtlzz_pipe_39_s3 <= 128'h0;
            rtlzz_pipe_40_s3 <= 128'h0;
            rtlzz_pipe_52_s4 <= 129'h0;
            rtlzz_pipe_52_s5 <= 129'h0;
            rtlzz_pipe_52_s6 <= 129'h0;
            rtlzz_pipe_58_s7 <= 130'h0;
            rtlzz_pipe_41_s1 <= 128'h0;
            rtlzz_pipe_41_s2 <= 128'h0;
            rtlzz_pipe_41_s3 <= 128'h0;
            rtlzz_pipe_41_s4 <= 128'h0;
            rtlzz_pipe_53_s5 <= 129'h0;
            rtlzz_pipe_53_s6 <= 129'h0;
            rtlzz_pipe_43_s2 <= 128'h0;
            rtlzz_pipe_43_s3 <= 128'h0;
            rtlzz_pipe_43_s4 <= 128'h0;
            rtlzz_pipe_43_s5 <= 128'h0;
            rtlzz_pipe_44_s3 <= 128'h0;
            rtlzz_pipe_44_s4 <= 128'h0;
            rtlzz_pipe_44_s5 <= 128'h0;
            rtlzz_pipe_54_s6 <= 129'h0;
            rtlzz_pipe_59_s7 <= 130'h0;
            rtlzz_pipe_45_s4 <= 128'h0;
            rtlzz_pipe_45_s5 <= 128'h0;
            rtlzz_pipe_45_s6 <= 128'h0;
            rtlzz_pipe_45_s7 <= 128'h0;
            rtlzz_pipe_47_s1 <= 128'h0;
            rtlzz_pipe_47_s2 <= 128'h0;
            rtlzz_pipe_47_s3 <= 128'h0;
            rtlzz_pipe_47_s4 <= 128'h0;
            rtlzz_pipe_47_s5 <= 128'h0;
            rtlzz_pipe_47_s6 <= 128'h0;
            rtlzz_pipe_48_s2 <= 128'h0;
            rtlzz_pipe_48_s3 <= 128'h0;
            rtlzz_pipe_48_s4 <= 128'h0;
            rtlzz_pipe_48_s5 <= 128'h0;
            rtlzz_pipe_48_s6 <= 128'h0;
            rtlzz_pipe_56_s7 <= 129'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_104_s1 <= mul_precision_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_104_s3 <= rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_104_s4 <= rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_precision_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_105_s2 <= rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_105_s3 <= rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_105_s4 <= rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_106_s4 <= rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_107_s4 <= rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_107_s5 <= rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_110_s1 <= mul_precision_110; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_precision_111; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_116_s1 <= mul_precision_116; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_116_s2 <= rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_116_s3 <= rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_116_s4 <= rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_precision_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_117_s2 <= rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_117_s3 <= rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_117_s4 <= rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_120_s1 <= mul_precision_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_120_s2 <= rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_precision_121; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_121_s2 <= rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_124_s6 <= rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_124_s7 <= rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_125_s6 <= rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_125_s7 <= rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_34_s2 <= s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_49_s4 <= s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_49_s5 <= rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_49_s6 <= rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_49_s7 <= rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_36_s6 <= rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_50_s7 <= s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_38_s4 <= rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_38_s5 <= rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_51_s6 <= s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_39_s2 <= s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_39_s3 <= rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_40_s3 <= s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_58_s7 <= s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_41_s3 <= rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_41_s4 <= rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_53_s5 <= s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_53_s6 <= rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_43_s3 <= rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_43_s4 <= rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_43_s5 <= rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_44_s4 <= rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_54_s6 <= s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_59_s7 <= s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_45_s4 <= s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_45_s5 <= rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_47_s3 <= rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_47_s4 <= rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_47_s5 <= rtlzz_pipe_47_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_47_s6 <= rtlzz_pipe_47_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= rtlzz_pipe_48_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_48_s4 <= rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_48_s5 <= rtlzz_pipe_48_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_48_s6 <= rtlzz_pipe_48_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_56_s7 <= s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63_reduce(input wire [127:0] i143, input wire [128:0] i220, input wire [128:0] i227, input wire [129:0] i240, input wire [129:0] i255, input wire [127:0] i259, input wire [128:0] i271, output wire [131:0] y);
wire [131:0] t0 = {1'b0, 1'b0, 1'b0, i220[128], i220[127], i220[126], i220[125], i220[124], i220[123], i220[122], i220[121], i220[120], i220[119], i220[118], i220[117], i220[116], i220[115], i220[114], i220[113], i220[112], i220[111], i220[110], i220[109], i220[108], i220[107], i220[106], i220[105], i220[104], i220[103], i220[102], i220[101], i220[100], i220[99], i220[98], i220[97], i220[96], i220[95], i220[94], i220[93], i220[92], i220[91], i220[90], i220[89], i220[88], i220[87], i220[86], i220[85], i220[84], i220[83], i220[82], i220[81], i220[80], i220[79], i220[78], i220[77], i220[76], i220[75], i220[74], i220[73], i220[72], i220[71], i220[70], i220[69], i220[68], i220[67], i220[66], i220[65], i220[64], i220[63], i220[62], i220[61], i220[60], i220[59], i220[58], i220[57], i220[56], i220[55], i220[54], i220[53], i220[52], i220[51], i220[50], i220[49], i220[48], i220[47], i220[46], i220[45], i220[44], i220[43], i220[42], i220[41], i220[40], i220[39], i220[38], i220[37], i220[36], i220[35], i220[34], i220[33], i220[32], i220[31], i220[30], i220[29], i220[28], i220[27], i220[26], i220[25], i220[24], i220[23], i220[22], i220[21], i220[20], i220[19], i220[18], i220[17], i220[16], i220[15], i220[14], i220[13], i220[12], i220[11], i220[10], i220[9], i220[8], i220[7], i220[6], i220[5], i220[4], i220[3], i220[2], i220[1], i220[0]};
wire [131:0] t1 = {1'b0, 1'b0, 1'b0, i227[128], i227[127], i227[126], i227[125], i227[124], i227[123], i227[122], i227[121], i227[120], i227[119], i227[118], i227[117], i227[116], i227[115], i227[114], i227[113], i227[112], i227[111], i227[110], i227[109], i227[108], i227[107], i227[106], i227[105], i227[104], i227[103], i227[102], i227[101], i227[100], i227[99], i227[98], i227[97], i227[96], i227[95], i227[94], i227[93], i227[92], i227[91], i227[90], i227[89], i227[88], i227[87], i227[86], i227[85], i227[84], i227[83], i227[82], i227[81], i227[80], i227[79], i227[78], i227[77], i227[76], i227[75], i227[74], i227[73], i227[72], i227[71], i227[70], i227[69], i227[68], i227[67], i227[66], i227[65], i227[64], i227[63], i227[62], i227[61], i227[60], i227[59], i227[58], i227[57], i227[56], i227[55], i227[54], i227[53], i227[52], i227[51], i227[50], i227[49], i227[48], i227[47], i227[46], i227[45], i227[44], i227[43], i227[42], i227[41], i227[40], i227[39], i227[38], i227[37], i227[36], i227[35], i227[34], i227[33], i227[32], i227[31], i227[30], i227[29], i227[28], i227[27], i227[26], i227[25], i227[24], i227[23], i227[22], i227[21], i227[20], i227[19], i227[18], i227[17], i227[16], i227[15], i227[14], i227[13], i227[12], i227[11], i227[10], i227[9], i227[8], i227[7], i227[6], i227[5], i227[4], i227[3], i227[2], i227[1], i227[0]};
wire [131:0] t2 = {1'b0, 1'b0, i240[129], i240[128], i240[127], i240[126], i240[125], i240[124], i240[123], i240[122], i240[121], i240[120], i240[119], i240[118], i240[117], i240[116], i240[115], i240[114], i240[113], i240[112], i240[111], i240[110], i240[109], i240[108], i240[107], i240[106], i240[105], i240[104], i240[103], i240[102], i240[101], i240[100], i240[99], i240[98], i240[97], i240[96], i240[95], i240[94], i240[93], i240[92], i240[91], i240[90], i240[89], i240[88], i240[87], i240[86], i240[85], i240[84], i240[83], i240[82], i240[81], i240[80], i240[79], i240[78], i240[77], i240[76], i240[75], i240[74], i240[73], i240[72], i240[71], i240[70], i240[69], i240[68], i240[67], i240[66], i240[65], i240[64], i240[63], i240[62], i240[61], i240[60], i240[59], i240[58], i240[57], i240[56], i240[55], i240[54], i240[53], i240[52], i240[51], i240[50], i240[49], i240[48], i240[47], i240[46], i240[45], i240[44], i240[43], i240[42], i240[41], i240[40], i240[39], i240[38], i240[37], i240[36], i240[35], i240[34], i240[33], i240[32], i240[31], i240[30], i240[29], i240[28], i240[27], i240[26], i240[25], i240[24], i240[23], i240[22], i240[21], i240[20], i240[19], i240[18], i240[17], i240[16], i240[15], i240[14], i240[13], i240[12], i240[11], i240[10], i240[9], i240[8], i240[7], i240[6], i240[5], i240[4], i240[3], i240[2], i240[1], i240[0]};
wire [131:0] t3 = {1'b0, 1'b0, i255[129], i255[128], i255[127], i255[126], i255[125], i255[124], i255[123], i255[122], i255[121], i255[120], i255[119], i255[118], i255[117], i255[116], i255[115], i255[114], i255[113], i255[112], i255[111], i255[110], i255[109], i255[108], i255[107], i255[106], i255[105], i255[104], i255[103], i255[102], i255[101], i255[100], i255[99], i255[98], i255[97], i255[96], i255[95], i255[94], i255[93], i255[92], i255[91], i255[90], i255[89], i255[88], i255[87], i255[86], i255[85], i255[84], i255[83], i255[82], i255[81], i255[80], i255[79], i255[78], i255[77], i255[76], i255[75], i255[74], i255[73], i255[72], i255[71], i255[70], i255[69], i255[68], i255[67], i255[66], i255[65], i255[64], i255[63], i255[62], i255[61], i255[60], i255[59], i255[58], i255[57], i255[56], i255[55], i255[54], i255[53], i255[52], i255[51], i255[50], i255[49], i255[48], i255[47], i255[46], i255[45], i255[44], i255[43], i255[42], i255[41], i255[40], i255[39], i255[38], i255[37], i255[36], i255[35], i255[34], i255[33], i255[32], i255[31], i255[30], i255[29], i255[28], i255[27], i255[26], i255[25], i255[24], i255[23], i255[22], i255[21], i255[20], i255[19], i255[18], i255[17], i255[16], i255[15], i255[14], i255[13], i255[12], i255[11], i255[10], i255[9], i255[8], i255[7], i255[6], i255[5], i255[4], i255[3], i255[2], i255[1], i255[0]};
wire [131:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, i259[127], i259[126], i259[125], i259[124], i259[123], i259[122], i259[121], i259[120], i259[119], i259[118], i259[117], i259[116], i259[115], i259[114], i259[113], i259[112], i259[111], i259[110], i259[109], i259[108], i259[107], i259[106], i259[105], i259[104], i259[103], i259[102], i259[101], i259[100], i259[99], i259[98], i259[97], i259[96], i259[95], i259[94], i259[93], i259[92], i259[91], i259[90], i259[89], i259[88], i259[87], i259[86], i259[85], i259[84], i259[83], i259[82], i259[81], i259[80], i259[79], i259[78], i259[77], i259[76], i259[75], i259[74], i259[73], i259[72], i259[71], i259[70], i259[69], i259[68], i259[67], i259[66], i259[65], i259[64], i259[63], i259[62], i259[61], i259[60], i259[59], i259[58], i259[57], i259[56], i259[55], i259[54], i259[53], i259[52], i259[51], i259[50], i259[49], i259[48], i259[47], i259[46], i259[45], i259[44], i259[43], i259[42], i259[41], i259[40], i259[39], i259[38], i259[37], i259[36], i259[35], i259[34], i259[33], i259[32], i259[31], i259[30], i259[29], i259[28], i259[27], i259[26], i259[25], i259[24], i259[23], i259[22], i259[21], i259[20], i259[19], i259[18], i259[17], i259[16], i259[15], i259[14], i259[13], i259[12], i259[11], i259[10], i259[9], i259[8], i259[7], i259[6], i259[5], i259[4], i259[3], i259[2], i259[1], i259[0]};
wire [131:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, i143[127], i143[126], i143[125], i143[124], i143[123], i143[122], i143[121], i143[120], i143[119], i143[118], i143[117], i143[116], i143[115], i143[114], i143[113], i143[112], i143[111], i143[110], i143[109], i143[108], i143[107], i143[106], i143[105], i143[104], i143[103], i143[102], i143[101], i143[100], i143[99], i143[98], i143[97], i143[96], i143[95], i143[94], i143[93], i143[92], i143[91], i143[90], i143[89], i143[88], i143[87], i143[86], i143[85], i143[84], i143[83], i143[82], i143[81], i143[80], i143[79], i143[78], i143[77], i143[76], i143[75], i143[74], i143[73], i143[72], i143[71], i143[70], i143[69], i143[68], i143[67], i143[66], i143[65], i143[64], i143[63], i143[62], i143[61], i143[60], i143[59], i143[58], i143[57], i143[56], i143[55], i143[54], i143[53], i143[52], i143[51], i143[50], i143[49], i143[48], i143[47], i143[46], i143[45], i143[44], i143[43], i143[42], i143[41], i143[40], i143[39], i143[38], i143[37], i143[36], i143[35], i143[34], i143[33], i143[32], i143[31], i143[30], i143[29], i143[28], i143[27], i143[26], i143[25], i143[24], i143[23], i143[22], i143[21], i143[20], i143[19], i143[18], i143[17], i143[16], i143[15], i143[14], i143[13], i143[12], i143[11], i143[10], i143[9], i143[8], i143[7], i143[6], i143[5], i143[4], i143[3], i143[2], i143[1], i143[0]};
wire [131:0] t6 = {1'b0, 1'b0, 1'b0, i271[128], i271[127], i271[126], i271[125], i271[124], i271[123], i271[122], i271[121], i271[120], i271[119], i271[118], i271[117], i271[116], i271[115], i271[114], i271[113], i271[112], i271[111], i271[110], i271[109], i271[108], i271[107], i271[106], i271[105], i271[104], i271[103], i271[102], i271[101], i271[100], i271[99], i271[98], i271[97], i271[96], i271[95], i271[94], i271[93], i271[92], i271[91], i271[90], i271[89], i271[88], i271[87], i271[86], i271[85], i271[84], i271[83], i271[82], i271[81], i271[80], i271[79], i271[78], i271[77], i271[76], i271[75], i271[74], i271[73], i271[72], i271[71], i271[70], i271[69], i271[68], i271[67], i271[66], i271[65], i271[64], i271[63], i271[62], i271[61], i271[60], i271[59], i271[58], i271[57], i271[56], i271[55], i271[54], i271[53], i271[52], i271[51], i271[50], i271[49], i271[48], i271[47], i271[46], i271[45], i271[44], i271[43], i271[42], i271[41], i271[40], i271[39], i271[38], i271[37], i271[36], i271[35], i271[34], i271[33], i271[32], i271[31], i271[30], i271[29], i271[28], i271[27], i271[26], i271[25], i271[24], i271[23], i271[22], i271[21], i271[20], i271[19], i271[18], i271[17], i271[16], i271[15], i271[14], i271[13], i271[12], i271[11], i271[10], i271[9], i271[8], i271[7], i271[6], i271[5], i271[4], i271[3], i271[2], i271[1], i271[0]};
wire [131:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
