`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [31:0] mul_tree_130_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_160; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_161; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_162; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_163; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_164; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_165; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_166; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_167; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_168; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_169; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_170; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_172; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_174; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_175; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_176; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_177; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_179; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_180; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_181; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_182; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_183; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_184; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_185; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_186; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_187; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_188; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_189; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_190; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_191; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_192; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_193; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_194; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_196; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_197; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_198; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_200; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_201; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_202; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_204; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_205; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_208; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_209; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_210; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_211; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_212; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_213; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_214; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_215; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_216; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_217; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_218; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_219; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_220; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_221; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_222; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_224; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_225; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_226; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_228; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_229; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_230; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_232; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_233; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_234; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_235; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_236; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_237; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_238; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_239; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_240; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_241; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_242; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_243; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_244; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_245; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_246; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_247; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_248; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_249; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_250; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_251; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_252; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_253; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_254; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_255; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_256; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_257; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_258; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_259; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_260; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_261; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_262; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_263; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_264; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_265; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_266; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_267; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_268; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_269; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_270; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_271; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_272; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_273; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_274; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_275; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_276; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_277; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_278; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_279; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_280; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_281; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_282; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_283; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_284; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_285; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_286; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_287; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_288; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_289; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_290; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_291; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_292; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_293; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_294; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_295; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_296; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_297; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_298; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_299; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_300; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_301; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_302; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_303; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_304; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_305; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_306; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_307; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_308; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_309; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_310; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_311; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_312; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_313; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_314; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_315; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_316; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_317; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_318; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_319; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_320; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_321; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_322; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_323; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_324; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_325; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_326; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_327; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_328; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_329; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_330; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_331; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_332; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_333; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_334; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_335; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_336; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_337; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_338; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_339; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_340; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_341; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_342; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_343; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_344; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_345; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_346; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_347; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_348; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_349; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_350; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_351; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_352; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_353; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_354; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_355; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_356; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_357; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_358; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_359; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_360; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_361; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_362; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_363; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_364; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_365; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_366; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_367; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_368; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_369; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_373; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_374; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_375; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_376; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_377; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_378; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_379; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_380; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_381; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_382; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_383; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_384; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_385; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_386; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_387; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_388; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_389; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_390; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_391; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_392; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_393; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_394; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_398; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_399; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_400; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_401; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_402; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_403; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_404; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_405; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_406; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_407; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_408; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_409; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_410; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_411; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_412; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_413; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_414; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_415; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_416; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_417; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_418; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_419; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_420; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_421; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_422; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_423; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_424; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_425; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_426; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_427; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_428; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_429; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_430; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_431; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_432; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_433; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_434; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_435; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_436; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_437; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_438; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_439; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_440; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_441; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_442; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_443; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_444; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_446; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_447; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_448; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_449; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_450; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_451; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_452; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_453; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_454; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_455; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_456; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_457; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_458; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_459; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_460; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_461; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_462; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_463; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_464; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_465; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_466; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_467; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_468; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_469; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_471; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_472; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_476; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_477; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_478; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_479; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_480; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_481; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_482; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_483; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_484; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_485; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_486; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_487; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_488; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_489; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_490; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_491; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_492; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_493; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_494; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_496; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_497; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_501; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_502; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_503; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_504; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_505; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_506; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_507; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_508; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_509; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_510; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_511; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_512; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_513; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_514; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_515; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_516; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_517; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_518; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_519; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_521; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_522; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_523; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_524; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_525; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_526; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_527; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_528; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_529; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_530; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_531; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_532; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_533; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_534; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_535; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_536; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_537; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_538; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_539; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_540; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_541; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_542; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_543; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_544; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_545; // decl: <none>; prim: <none>
    logic [128:0] limb_49_546; // decl: <none>; prim: <none>
    logic [128:0] limb_49_547; // decl: <none>; prim: <none>
    logic [31:0] limb_49_548; // decl: <none>; prim: <none>
    logic [31:0] limb_49_549; // decl: <none>; prim: <none>
    logic [32:0] limb_49_550; // decl: <none>; prim: <none>
    logic [31:0] limb_49_551; // decl: <none>; prim: <none>
    logic limb_49_552; // decl: <none>; prim: <none>
    logic [31:0] limb_49_553; // decl: <none>; prim: <none>
    logic [31:0] limb_49_554; // decl: <none>; prim: <none>
    logic [32:0] limb_49_555; // decl: <none>; prim: <none>
    logic [31:0] limb_49_556; // decl: <none>; prim: <none>
    logic limb_49_557; // decl: <none>; prim: <none>
    logic [31:0] limb_49_558; // decl: <none>; prim: <none>
    logic [31:0] limb_49_559; // decl: <none>; prim: <none>
    logic [32:0] limb_49_560; // decl: <none>; prim: <none>
    logic [31:0] limb_49_561; // decl: <none>; prim: <none>
    logic limb_49_562; // decl: <none>; prim: <none>
    logic [31:0] limb_49_563; // decl: <none>; prim: <none>
    logic [31:0] limb_49_564; // decl: <none>; prim: <none>
    logic [32:0] limb_49_565; // decl: <none>; prim: <none>
    logic [31:0] limb_49_566; // decl: <none>; prim: <none>
    logic limb_49_567; // decl: <none>; prim: <none>
    logic limb_49_568; // decl: <none>; prim: <none>
    logic limb_49_569; // decl: <none>; prim: <none>
    logic [1:0] limb_49_570; // decl: <none>; prim: <none>
    logic limb_49_571; // decl: <none>; prim: <none>
    logic [128:0] limb_49_572; // decl: <none>; prim: <none>
    logic [128:0] limb_50_573; // decl: <none>; prim: <none>
    logic [128:0] limb_50_574; // decl: <none>; prim: <none>
    logic [31:0] limb_50_575; // decl: <none>; prim: <none>
    logic [31:0] limb_50_576; // decl: <none>; prim: <none>
    logic [32:0] limb_50_577; // decl: <none>; prim: <none>
    logic [31:0] limb_50_578; // decl: <none>; prim: <none>
    logic limb_50_579; // decl: <none>; prim: <none>
    logic [31:0] limb_50_580; // decl: <none>; prim: <none>
    logic [31:0] limb_50_581; // decl: <none>; prim: <none>
    logic [32:0] limb_50_582; // decl: <none>; prim: <none>
    logic [31:0] limb_50_583; // decl: <none>; prim: <none>
    logic limb_50_584; // decl: <none>; prim: <none>
    logic [31:0] limb_50_585; // decl: <none>; prim: <none>
    logic [31:0] limb_50_586; // decl: <none>; prim: <none>
    logic [32:0] limb_50_587; // decl: <none>; prim: <none>
    logic [31:0] limb_50_588; // decl: <none>; prim: <none>
    logic limb_50_589; // decl: <none>; prim: <none>
    logic [31:0] limb_50_590; // decl: <none>; prim: <none>
    logic [31:0] limb_50_591; // decl: <none>; prim: <none>
    logic [32:0] limb_50_592; // decl: <none>; prim: <none>
    logic [31:0] limb_50_593; // decl: <none>; prim: <none>
    logic limb_50_594; // decl: <none>; prim: <none>
    logic limb_50_595; // decl: <none>; prim: <none>
    logic limb_50_596; // decl: <none>; prim: <none>
    logic [1:0] limb_50_597; // decl: <none>; prim: <none>
    logic limb_50_598; // decl: <none>; prim: <none>
    logic [128:0] limb_50_599; // decl: <none>; prim: <none>
    logic [128:0] limb_51_600; // decl: <none>; prim: <none>
    logic [128:0] limb_51_601; // decl: <none>; prim: <none>
    logic [31:0] limb_51_602; // decl: <none>; prim: <none>
    logic [31:0] limb_51_603; // decl: <none>; prim: <none>
    logic [32:0] limb_51_604; // decl: <none>; prim: <none>
    logic [31:0] limb_51_605; // decl: <none>; prim: <none>
    logic limb_51_606; // decl: <none>; prim: <none>
    logic [31:0] limb_51_607; // decl: <none>; prim: <none>
    logic [31:0] limb_51_608; // decl: <none>; prim: <none>
    logic [32:0] limb_51_609; // decl: <none>; prim: <none>
    logic [31:0] limb_51_610; // decl: <none>; prim: <none>
    logic limb_51_611; // decl: <none>; prim: <none>
    logic [31:0] limb_51_612; // decl: <none>; prim: <none>
    logic [31:0] limb_51_613; // decl: <none>; prim: <none>
    logic [32:0] limb_51_614; // decl: <none>; prim: <none>
    logic [31:0] limb_51_615; // decl: <none>; prim: <none>
    logic limb_51_616; // decl: <none>; prim: <none>
    logic [31:0] limb_51_617; // decl: <none>; prim: <none>
    logic [31:0] limb_51_618; // decl: <none>; prim: <none>
    logic [32:0] limb_51_619; // decl: <none>; prim: <none>
    logic [31:0] limb_51_620; // decl: <none>; prim: <none>
    logic limb_51_621; // decl: <none>; prim: <none>
    logic limb_51_622; // decl: <none>; prim: <none>
    logic limb_51_623; // decl: <none>; prim: <none>
    logic [1:0] limb_51_624; // decl: <none>; prim: <none>
    logic limb_51_625; // decl: <none>; prim: <none>
    logic [128:0] limb_51_626; // decl: <none>; prim: <none>
    logic [128:0] limb_52_627; // decl: <none>; prim: <none>
    logic [128:0] limb_52_628; // decl: <none>; prim: <none>
    logic [31:0] limb_52_629; // decl: <none>; prim: <none>
    logic [31:0] limb_52_630; // decl: <none>; prim: <none>
    logic [32:0] limb_52_631; // decl: <none>; prim: <none>
    logic [31:0] limb_52_632; // decl: <none>; prim: <none>
    logic limb_52_633; // decl: <none>; prim: <none>
    logic [31:0] limb_52_634; // decl: <none>; prim: <none>
    logic [31:0] limb_52_635; // decl: <none>; prim: <none>
    logic [32:0] limb_52_636; // decl: <none>; prim: <none>
    logic [31:0] limb_52_637; // decl: <none>; prim: <none>
    logic limb_52_638; // decl: <none>; prim: <none>
    logic [31:0] limb_52_639; // decl: <none>; prim: <none>
    logic [31:0] limb_52_640; // decl: <none>; prim: <none>
    logic [32:0] limb_52_641; // decl: <none>; prim: <none>
    logic [31:0] limb_52_642; // decl: <none>; prim: <none>
    logic limb_52_643; // decl: <none>; prim: <none>
    logic [31:0] limb_52_644; // decl: <none>; prim: <none>
    logic [31:0] limb_52_645; // decl: <none>; prim: <none>
    logic [32:0] limb_52_646; // decl: <none>; prim: <none>
    logic [31:0] limb_52_647; // decl: <none>; prim: <none>
    logic limb_52_648; // decl: <none>; prim: <none>
    logic limb_52_649; // decl: <none>; prim: <none>
    logic limb_52_650; // decl: <none>; prim: <none>
    logic [1:0] limb_52_651; // decl: <none>; prim: <none>
    logic limb_52_652; // decl: <none>; prim: <none>
    logic [128:0] limb_52_653; // decl: <none>; prim: <none>
    logic [128:0] limb_53_654; // decl: <none>; prim: <none>
    logic [128:0] limb_53_655; // decl: <none>; prim: <none>
    logic [31:0] limb_53_656; // decl: <none>; prim: <none>
    logic [31:0] limb_53_657; // decl: <none>; prim: <none>
    logic [32:0] limb_53_658; // decl: <none>; prim: <none>
    logic [31:0] limb_53_659; // decl: <none>; prim: <none>
    logic limb_53_660; // decl: <none>; prim: <none>
    logic [31:0] limb_53_661; // decl: <none>; prim: <none>
    logic [31:0] limb_53_662; // decl: <none>; prim: <none>
    logic [32:0] limb_53_663; // decl: <none>; prim: <none>
    logic [31:0] limb_53_664; // decl: <none>; prim: <none>
    logic limb_53_665; // decl: <none>; prim: <none>
    logic [31:0] limb_53_666; // decl: <none>; prim: <none>
    logic [31:0] limb_53_667; // decl: <none>; prim: <none>
    logic [32:0] limb_53_668; // decl: <none>; prim: <none>
    logic [31:0] limb_53_669; // decl: <none>; prim: <none>
    logic limb_53_670; // decl: <none>; prim: <none>
    logic [31:0] limb_53_671; // decl: <none>; prim: <none>
    logic [31:0] limb_53_672; // decl: <none>; prim: <none>
    logic [32:0] limb_53_673; // decl: <none>; prim: <none>
    logic [31:0] limb_53_674; // decl: <none>; prim: <none>
    logic limb_53_675; // decl: <none>; prim: <none>
    logic limb_53_676; // decl: <none>; prim: <none>
    logic limb_53_677; // decl: <none>; prim: <none>
    logic [1:0] limb_53_678; // decl: <none>; prim: <none>
    logic limb_53_679; // decl: <none>; prim: <none>
    logic [128:0] limb_53_680; // decl: <none>; prim: <none>
    logic [128:0] limb_54_681; // decl: <none>; prim: <none>
    logic [128:0] limb_54_682; // decl: <none>; prim: <none>
    logic [31:0] limb_54_683; // decl: <none>; prim: <none>
    logic [31:0] limb_54_684; // decl: <none>; prim: <none>
    logic [32:0] limb_54_685; // decl: <none>; prim: <none>
    logic [31:0] limb_54_686; // decl: <none>; prim: <none>
    logic limb_54_687; // decl: <none>; prim: <none>
    logic [31:0] limb_54_688; // decl: <none>; prim: <none>
    logic [31:0] limb_54_689; // decl: <none>; prim: <none>
    logic [32:0] limb_54_690; // decl: <none>; prim: <none>
    logic [31:0] limb_54_691; // decl: <none>; prim: <none>
    logic limb_54_692; // decl: <none>; prim: <none>
    logic [31:0] limb_54_693; // decl: <none>; prim: <none>
    logic [31:0] limb_54_694; // decl: <none>; prim: <none>
    logic [32:0] limb_54_695; // decl: <none>; prim: <none>
    logic [31:0] limb_54_696; // decl: <none>; prim: <none>
    logic limb_54_697; // decl: <none>; prim: <none>
    logic [31:0] limb_54_698; // decl: <none>; prim: <none>
    logic [31:0] limb_54_699; // decl: <none>; prim: <none>
    logic [32:0] limb_54_700; // decl: <none>; prim: <none>
    logic [31:0] limb_54_701; // decl: <none>; prim: <none>
    logic limb_54_702; // decl: <none>; prim: <none>
    logic limb_54_703; // decl: <none>; prim: <none>
    logic limb_54_704; // decl: <none>; prim: <none>
    logic [1:0] limb_54_705; // decl: <none>; prim: <none>
    logic limb_54_706; // decl: <none>; prim: <none>
    logic [128:0] limb_54_707; // decl: <none>; prim: <none>
    logic [128:0] limb_55_708; // decl: <none>; prim: <none>
    logic [128:0] limb_55_709; // decl: <none>; prim: <none>
    logic [31:0] limb_55_710; // decl: <none>; prim: <none>
    logic [31:0] limb_55_711; // decl: <none>; prim: <none>
    logic [32:0] limb_55_712; // decl: <none>; prim: <none>
    logic [31:0] limb_55_713; // decl: <none>; prim: <none>
    logic limb_55_714; // decl: <none>; prim: <none>
    logic [31:0] limb_55_715; // decl: <none>; prim: <none>
    logic [31:0] limb_55_716; // decl: <none>; prim: <none>
    logic [32:0] limb_55_717; // decl: <none>; prim: <none>
    logic [31:0] limb_55_718; // decl: <none>; prim: <none>
    logic limb_55_719; // decl: <none>; prim: <none>
    logic [31:0] limb_55_720; // decl: <none>; prim: <none>
    logic [31:0] limb_55_721; // decl: <none>; prim: <none>
    logic [32:0] limb_55_722; // decl: <none>; prim: <none>
    logic [31:0] limb_55_723; // decl: <none>; prim: <none>
    logic limb_55_724; // decl: <none>; prim: <none>
    logic [31:0] limb_55_725; // decl: <none>; prim: <none>
    logic [31:0] limb_55_726; // decl: <none>; prim: <none>
    logic [32:0] limb_55_727; // decl: <none>; prim: <none>
    logic [31:0] limb_55_728; // decl: <none>; prim: <none>
    logic limb_55_729; // decl: <none>; prim: <none>
    logic limb_55_730; // decl: <none>; prim: <none>
    logic limb_55_731; // decl: <none>; prim: <none>
    logic [1:0] limb_55_732; // decl: <none>; prim: <none>
    logic limb_55_733; // decl: <none>; prim: <none>
    logic [128:0] limb_55_734; // decl: <none>; prim: <none>
    logic [128:0] limb_56_735; // decl: <none>; prim: <none>
    logic [128:0] limb_56_736; // decl: <none>; prim: <none>
    logic [31:0] limb_56_737; // decl: <none>; prim: <none>
    logic [31:0] limb_56_738; // decl: <none>; prim: <none>
    logic [32:0] limb_56_739; // decl: <none>; prim: <none>
    logic [31:0] limb_56_740; // decl: <none>; prim: <none>
    logic limb_56_741; // decl: <none>; prim: <none>
    logic [31:0] limb_56_742; // decl: <none>; prim: <none>
    logic [31:0] limb_56_743; // decl: <none>; prim: <none>
    logic [32:0] limb_56_744; // decl: <none>; prim: <none>
    logic [31:0] limb_56_745; // decl: <none>; prim: <none>
    logic limb_56_746; // decl: <none>; prim: <none>
    logic [31:0] limb_56_747; // decl: <none>; prim: <none>
    logic [31:0] limb_56_748; // decl: <none>; prim: <none>
    logic [32:0] limb_56_749; // decl: <none>; prim: <none>
    logic [31:0] limb_56_750; // decl: <none>; prim: <none>
    logic limb_56_751; // decl: <none>; prim: <none>
    logic [31:0] limb_56_752; // decl: <none>; prim: <none>
    logic [31:0] limb_56_753; // decl: <none>; prim: <none>
    logic [32:0] limb_56_754; // decl: <none>; prim: <none>
    logic [31:0] limb_56_755; // decl: <none>; prim: <none>
    logic limb_56_756; // decl: <none>; prim: <none>
    logic limb_56_757; // decl: <none>; prim: <none>
    logic limb_56_758; // decl: <none>; prim: <none>
    logic [1:0] limb_56_759; // decl: <none>; prim: <none>
    logic limb_56_760; // decl: <none>; prim: <none>
    logic [128:0] limb_56_761; // decl: <none>; prim: <none>
    logic [129:0] limb_57_762; // decl: <none>; prim: <none>
    logic [129:0] limb_57_763; // decl: <none>; prim: <none>
    logic [31:0] limb_57_764; // decl: <none>; prim: <none>
    logic [31:0] limb_57_765; // decl: <none>; prim: <none>
    logic [32:0] limb_57_766; // decl: <none>; prim: <none>
    logic [31:0] limb_57_767; // decl: <none>; prim: <none>
    logic limb_57_768; // decl: <none>; prim: <none>
    logic [31:0] limb_57_769; // decl: <none>; prim: <none>
    logic [31:0] limb_57_770; // decl: <none>; prim: <none>
    logic [32:0] limb_57_771; // decl: <none>; prim: <none>
    logic [31:0] limb_57_772; // decl: <none>; prim: <none>
    logic limb_57_773; // decl: <none>; prim: <none>
    logic [31:0] limb_57_774; // decl: <none>; prim: <none>
    logic [31:0] limb_57_775; // decl: <none>; prim: <none>
    logic [32:0] limb_57_776; // decl: <none>; prim: <none>
    logic [31:0] limb_57_777; // decl: <none>; prim: <none>
    logic limb_57_778; // decl: <none>; prim: <none>
    logic [31:0] limb_57_779; // decl: <none>; prim: <none>
    logic [31:0] limb_57_780; // decl: <none>; prim: <none>
    logic [32:0] limb_57_781; // decl: <none>; prim: <none>
    logic [31:0] limb_57_782; // decl: <none>; prim: <none>
    logic limb_57_783; // decl: <none>; prim: <none>
    logic [1:0] limb_57_784; // decl: <none>; prim: <none>
    logic [1:0] limb_57_785; // decl: <none>; prim: <none>
    logic [2:0] limb_57_786; // decl: <none>; prim: <none>
    logic [1:0] limb_57_787; // decl: <none>; prim: <none>
    logic [129:0] limb_57_788; // decl: <none>; prim: <none>
    logic [129:0] limb_58_789; // decl: <none>; prim: <none>
    logic [129:0] limb_58_790; // decl: <none>; prim: <none>
    logic [31:0] limb_58_791; // decl: <none>; prim: <none>
    logic [31:0] limb_58_792; // decl: <none>; prim: <none>
    logic [32:0] limb_58_793; // decl: <none>; prim: <none>
    logic [31:0] limb_58_794; // decl: <none>; prim: <none>
    logic limb_58_795; // decl: <none>; prim: <none>
    logic [31:0] limb_58_796; // decl: <none>; prim: <none>
    logic [31:0] limb_58_797; // decl: <none>; prim: <none>
    logic [32:0] limb_58_798; // decl: <none>; prim: <none>
    logic [31:0] limb_58_799; // decl: <none>; prim: <none>
    logic limb_58_800; // decl: <none>; prim: <none>
    logic [31:0] limb_58_801; // decl: <none>; prim: <none>
    logic [31:0] limb_58_802; // decl: <none>; prim: <none>
    logic [32:0] limb_58_803; // decl: <none>; prim: <none>
    logic [31:0] limb_58_804; // decl: <none>; prim: <none>
    logic limb_58_805; // decl: <none>; prim: <none>
    logic [31:0] limb_58_806; // decl: <none>; prim: <none>
    logic [31:0] limb_58_807; // decl: <none>; prim: <none>
    logic [32:0] limb_58_808; // decl: <none>; prim: <none>
    logic [31:0] limb_58_809; // decl: <none>; prim: <none>
    logic limb_58_810; // decl: <none>; prim: <none>
    logic [1:0] limb_58_811; // decl: <none>; prim: <none>
    logic [1:0] limb_58_812; // decl: <none>; prim: <none>
    logic [2:0] limb_58_813; // decl: <none>; prim: <none>
    logic [1:0] limb_58_814; // decl: <none>; prim: <none>
    logic [129:0] limb_58_815; // decl: <none>; prim: <none>
    logic [129:0] limb_59_816; // decl: <none>; prim: <none>
    logic [129:0] limb_59_817; // decl: <none>; prim: <none>
    logic [31:0] limb_59_818; // decl: <none>; prim: <none>
    logic [31:0] limb_59_819; // decl: <none>; prim: <none>
    logic [32:0] limb_59_820; // decl: <none>; prim: <none>
    logic [31:0] limb_59_821; // decl: <none>; prim: <none>
    logic limb_59_822; // decl: <none>; prim: <none>
    logic [31:0] limb_59_823; // decl: <none>; prim: <none>
    logic [31:0] limb_59_824; // decl: <none>; prim: <none>
    logic [32:0] limb_59_825; // decl: <none>; prim: <none>
    logic [31:0] limb_59_826; // decl: <none>; prim: <none>
    logic limb_59_827; // decl: <none>; prim: <none>
    logic [31:0] limb_59_828; // decl: <none>; prim: <none>
    logic [31:0] limb_59_829; // decl: <none>; prim: <none>
    logic [32:0] limb_59_830; // decl: <none>; prim: <none>
    logic [31:0] limb_59_831; // decl: <none>; prim: <none>
    logic limb_59_832; // decl: <none>; prim: <none>
    logic [31:0] limb_59_833; // decl: <none>; prim: <none>
    logic [31:0] limb_59_834; // decl: <none>; prim: <none>
    logic [32:0] limb_59_835; // decl: <none>; prim: <none>
    logic [31:0] limb_59_836; // decl: <none>; prim: <none>
    logic limb_59_837; // decl: <none>; prim: <none>
    logic [1:0] limb_59_838; // decl: <none>; prim: <none>
    logic [1:0] limb_59_839; // decl: <none>; prim: <none>
    logic [2:0] limb_59_840; // decl: <none>; prim: <none>
    logic [1:0] limb_59_841; // decl: <none>; prim: <none>
    logic [129:0] limb_59_842; // decl: <none>; prim: <none>
    logic [129:0] limb_60_843; // decl: <none>; prim: <none>
    logic [129:0] limb_60_844; // decl: <none>; prim: <none>
    logic [31:0] limb_60_845; // decl: <none>; prim: <none>
    logic [31:0] limb_60_846; // decl: <none>; prim: <none>
    logic [32:0] limb_60_847; // decl: <none>; prim: <none>
    logic [31:0] limb_60_848; // decl: <none>; prim: <none>
    logic limb_60_849; // decl: <none>; prim: <none>
    logic [31:0] limb_60_850; // decl: <none>; prim: <none>
    logic [31:0] limb_60_851; // decl: <none>; prim: <none>
    logic [32:0] limb_60_852; // decl: <none>; prim: <none>
    logic [31:0] limb_60_853; // decl: <none>; prim: <none>
    logic limb_60_854; // decl: <none>; prim: <none>
    logic [31:0] limb_60_855; // decl: <none>; prim: <none>
    logic [31:0] limb_60_856; // decl: <none>; prim: <none>
    logic [32:0] limb_60_857; // decl: <none>; prim: <none>
    logic [31:0] limb_60_858; // decl: <none>; prim: <none>
    logic limb_60_859; // decl: <none>; prim: <none>
    logic [31:0] limb_60_860; // decl: <none>; prim: <none>
    logic [31:0] limb_60_861; // decl: <none>; prim: <none>
    logic [32:0] limb_60_862; // decl: <none>; prim: <none>
    logic [31:0] limb_60_863; // decl: <none>; prim: <none>
    logic limb_60_864; // decl: <none>; prim: <none>
    logic [1:0] limb_60_865; // decl: <none>; prim: <none>
    logic [1:0] limb_60_866; // decl: <none>; prim: <none>
    logic [2:0] limb_60_867; // decl: <none>; prim: <none>
    logic [1:0] limb_60_868; // decl: <none>; prim: <none>
    logic [129:0] limb_60_869; // decl: <none>; prim: <none>
    logic [130:0] limb_61_870; // decl: <none>; prim: <none>
    logic [130:0] limb_61_871; // decl: <none>; prim: <none>
    logic [31:0] limb_61_872; // decl: <none>; prim: <none>
    logic [31:0] limb_61_873; // decl: <none>; prim: <none>
    logic [32:0] limb_61_874; // decl: <none>; prim: <none>
    logic [31:0] limb_61_875; // decl: <none>; prim: <none>
    logic limb_61_876; // decl: <none>; prim: <none>
    logic [31:0] limb_61_877; // decl: <none>; prim: <none>
    logic [31:0] limb_61_878; // decl: <none>; prim: <none>
    logic [32:0] limb_61_879; // decl: <none>; prim: <none>
    logic [31:0] limb_61_880; // decl: <none>; prim: <none>
    logic limb_61_881; // decl: <none>; prim: <none>
    logic [31:0] limb_61_882; // decl: <none>; prim: <none>
    logic [31:0] limb_61_883; // decl: <none>; prim: <none>
    logic [32:0] limb_61_884; // decl: <none>; prim: <none>
    logic [31:0] limb_61_885; // decl: <none>; prim: <none>
    logic limb_61_886; // decl: <none>; prim: <none>
    logic [31:0] limb_61_887; // decl: <none>; prim: <none>
    logic [31:0] limb_61_888; // decl: <none>; prim: <none>
    logic [32:0] limb_61_889; // decl: <none>; prim: <none>
    logic [31:0] limb_61_890; // decl: <none>; prim: <none>
    logic limb_61_891; // decl: <none>; prim: <none>
    logic [2:0] limb_61_892; // decl: <none>; prim: <none>
    logic [2:0] limb_61_893; // decl: <none>; prim: <none>
    logic [3:0] limb_61_894; // decl: <none>; prim: <none>
    logic [2:0] limb_61_895; // decl: <none>; prim: <none>
    logic [130:0] limb_61_896; // decl: <none>; prim: <none>
    logic [130:0] limb_62_897; // decl: <none>; prim: <none>
    logic [130:0] limb_62_898; // decl: <none>; prim: <none>
    logic [31:0] limb_62_899; // decl: <none>; prim: <none>
    logic [31:0] limb_62_900; // decl: <none>; prim: <none>
    logic [32:0] limb_62_901; // decl: <none>; prim: <none>
    logic [31:0] limb_62_902; // decl: <none>; prim: <none>
    logic limb_62_903; // decl: <none>; prim: <none>
    logic [31:0] limb_62_904; // decl: <none>; prim: <none>
    logic [31:0] limb_62_905; // decl: <none>; prim: <none>
    logic [32:0] limb_62_906; // decl: <none>; prim: <none>
    logic [31:0] limb_62_907; // decl: <none>; prim: <none>
    logic limb_62_908; // decl: <none>; prim: <none>
    logic [31:0] limb_62_909; // decl: <none>; prim: <none>
    logic [31:0] limb_62_910; // decl: <none>; prim: <none>
    logic [32:0] limb_62_911; // decl: <none>; prim: <none>
    logic [31:0] limb_62_912; // decl: <none>; prim: <none>
    logic limb_62_913; // decl: <none>; prim: <none>
    logic [31:0] limb_62_914; // decl: <none>; prim: <none>
    logic [31:0] limb_62_915; // decl: <none>; prim: <none>
    logic [32:0] limb_62_916; // decl: <none>; prim: <none>
    logic [31:0] limb_62_917; // decl: <none>; prim: <none>
    logic limb_62_918; // decl: <none>; prim: <none>
    logic [2:0] limb_62_919; // decl: <none>; prim: <none>
    logic [2:0] limb_62_920; // decl: <none>; prim: <none>
    logic [3:0] limb_62_921; // decl: <none>; prim: <none>
    logic [2:0] limb_62_922; // decl: <none>; prim: <none>
    logic [130:0] limb_62_923; // decl: <none>; prim: <none>
    logic [131:0] limb_63_924; // decl: <none>; prim: <none>
    logic [131:0] limb_63_925; // decl: <none>; prim: <none>
    logic [31:0] limb_63_926; // decl: <none>; prim: <none>
    logic [31:0] limb_63_927; // decl: <none>; prim: <none>
    logic [32:0] limb_63_928; // decl: <none>; prim: <none>
    logic [31:0] limb_63_929; // decl: <none>; prim: <none>
    logic limb_63_930; // decl: <none>; prim: <none>
    logic [31:0] limb_63_931; // decl: <none>; prim: <none>
    logic [31:0] limb_63_932; // decl: <none>; prim: <none>
    logic [32:0] limb_63_933; // decl: <none>; prim: <none>
    logic [31:0] limb_63_934; // decl: <none>; prim: <none>
    logic limb_63_935; // decl: <none>; prim: <none>
    logic [31:0] limb_63_936; // decl: <none>; prim: <none>
    logic [31:0] limb_63_937; // decl: <none>; prim: <none>
    logic [32:0] limb_63_938; // decl: <none>; prim: <none>
    logic [31:0] limb_63_939; // decl: <none>; prim: <none>
    logic limb_63_940; // decl: <none>; prim: <none>
    logic [31:0] limb_63_941; // decl: <none>; prim: <none>
    logic [31:0] limb_63_942; // decl: <none>; prim: <none>
    logic [32:0] limb_63_943; // decl: <none>; prim: <none>
    logic [31:0] limb_63_944; // decl: <none>; prim: <none>
    logic limb_63_945; // decl: <none>; prim: <none>
    logic [3:0] limb_63_946; // decl: <none>; prim: <none>
    logic [3:0] limb_63_947; // decl: <none>; prim: <none>
    logic [4:0] limb_63_948; // decl: <none>; prim: <none>
    logic [3:0] limb_63_949; // decl: <none>; prim: <none>
    logic [131:0] limb_63_950; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_156_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_160_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_166_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_173_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_177_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_181_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_185_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_188_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_213_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_216_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_223_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_227_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_231_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_235_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_238_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_241_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_248_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_252_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_256_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_260_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_273_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_273_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_277_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_277_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_281_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_281_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_298_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_302_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_306_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_310_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_313_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_316_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_327_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_327_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_331_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_335_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_363_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_366_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_373_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_377_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_381_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_385_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_413_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_416_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_423_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_427_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_431_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_435_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_438_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_448_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_456_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_460_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_473_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_477_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_481_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_485_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_498_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_502_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_506_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_510_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_513_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_516_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_523_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_527_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_531_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_535_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_548_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_548_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_548_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_548_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_549_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_553_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_553_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_553_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_553_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_554_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_558_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_558_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_558_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_558_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_559_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_563_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_563_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_563_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_563_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_564_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_568_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_568_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_568_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_568_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_569_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_576_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_576_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_576_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_581_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_581_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_581_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_581_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_581_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_591_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_591_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_591_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_591_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_591_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_596_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_596_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_596_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_596_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_596_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_602_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_602_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_602_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_607_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_607_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_607_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_612_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_612_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_612_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_622_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_622_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_622_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_629_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_629_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_629_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_634_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_634_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_634_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_639_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_639_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_639_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_644_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_644_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_644_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_649_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_649_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_649_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_672_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_672_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_672_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_672_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_672_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_684_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_684_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_686_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_686_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_689_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_689_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_691_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_691_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_694_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_694_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_696_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_696_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_699_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_699_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_701_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_701_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_702_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_702_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_703_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_703_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_704_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_704_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_704_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_704_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_710_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_710_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_715_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_715_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_720_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_720_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_725_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_725_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_730_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_730_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_737_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_737_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_740_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_740_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_741_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_742_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_742_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_742_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_743_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_745_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_746_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_747_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_747_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_747_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_747_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_748_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_748_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_752_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_752_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_752_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_752_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_753_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_753_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_757_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_757_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_757_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_757_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_758_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_758_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_764_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_769_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_774_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_779_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_784_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_792_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_792_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_797_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_797_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_802_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_802_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_807_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_807_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_812_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_812_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_819_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_824_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_829_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_834_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_839_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_846_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_851_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_856_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_861_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_866_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    assign s8_norm_add_64_v0 = limb_49_572; // decl: <none>; prim: <none>
    assign s8_norm_add_65_v0 = limb_50_599; // decl: <none>; prim: <none>
    assign s8_norm_add_66_v0 = limb_51_626; // decl: <none>; prim: <none>
    assign s8_norm_add_67_v0 = limb_52_653; // decl: <none>; prim: <none>
    assign s8_norm_add_68_v0 = limb_53_680; // decl: <none>; prim: <none>
    assign s8_norm_add_69_v0 = limb_54_707; // decl: <none>; prim: <none>
    assign s8_norm_add_70_v0 = limb_55_734; // decl: <none>; prim: <none>
    assign s8_norm_add_71_v0 = limb_56_761; // decl: <none>; prim: <none>
    assign s8_norm_add_72_v0 = limb_57_788; // decl: <none>; prim: <none>
    assign s8_norm_add_73_v0 = limb_58_815; // decl: <none>; prim: <none>
    assign s8_norm_add_74_v0 = limb_59_842; // decl: <none>; prim: <none>
    assign s8_norm_add_75_v0 = limb_60_869; // decl: <none>; prim: <none>
    assign s8_norm_add_76_v0 = limb_61_896; // decl: <none>; prim: <none>
    assign s8_norm_add_77_v0 = limb_62_923; // decl: <none>; prim: <none>
    assign s8_norm_add_78_v0 = limb_63_950; // decl: <none>; prim: <none>
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    assign arith_original_130 = mul_tree_130_170; // decl: <none>; prim: <none>
    assign arith_original_131 = mul_tree_131_195; // decl: <none>; prim: <none>
    assign arith_original_132 = mul_tree_132_220; // decl: <none>; prim: <none>
    assign arith_original_133 = mul_tree_133_245; // decl: <none>; prim: <none>
    assign arith_original_134 = mul_tree_134_270; // decl: <none>; prim: <none>
    assign arith_original_135 = mul_tree_135_295; // decl: <none>; prim: <none>
    assign arith_original_136 = mul_tree_136_320; // decl: <none>; prim: <none>
    assign arith_original_137 = mul_tree_137_345; // decl: <none>; prim: <none>
    assign arith_original_138 = mul_tree_138_370; // decl: <none>; prim: <none>
    assign arith_original_139 = mul_tree_139_395; // decl: <none>; prim: <none>
    assign arith_original_140 = mul_tree_140_420; // decl: <none>; prim: <none>
    assign arith_original_141 = mul_tree_141_445; // decl: <none>; prim: <none>
    assign arith_original_142 = mul_tree_142_470; // decl: <none>; prim: <none>
    assign arith_original_143 = mul_tree_143_495; // decl: <none>; prim: <none>
    assign arith_original_144 = mul_tree_144_520; // decl: <none>; prim: <none>
    assign arith_original_145 = mul_tree_145_545; // decl: <none>; prim: <none>
    assign mul_tree_130_146 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_147 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_130_146)), .b(32'(mul_tree_130_147)), .cin(1'b0), .value(mul_tree_130_148));
    assign mul_tree_130_149 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_150 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_130_149)), .b(32'(mul_tree_130_150)), .cin(1'b0), .value(mul_tree_130_151));
    assign mul_tree_130_152 = {mul_tree_130_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_153 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_154 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_130_153)), .b(32'(mul_tree_130_154)), .cin(1'b0), .value(mul_tree_130_155));
    assign mul_tree_130_156 = {mul_tree_130_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_157 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_158 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_130_157)), .b(32'(mul_tree_130_158)), .cin(1'b0), .value(mul_tree_130_159));
    assign mul_tree_130_160 = {mul_tree_130_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_161 = ({33'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_162 = ({1'h0, rtlzz_pipe_152_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(64'(mul_tree_130_161)), .b(96'(mul_tree_130_162)), .cin(1'h0), .value(mul_tree_130_163));
    assign mul_tree_130_164 = ({33'h0, rtlzz_pipe_156_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_165 = ({1'h0, rtlzz_pipe_160_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(96'(mul_tree_130_164)), .b(128'(mul_tree_130_165)), .cin(1'h0), .value(mul_tree_130_166[127:0]));
    assign mul_tree_130_166[128:128] = '0;
    assign mul_tree_130_167 = ({33'h0, rtlzz_pipe_163_s2}); // decl: <none>; prim: <none>
    assign mul_tree_130_168 = ({1'h0, rtlzz_pipe_166_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_169Core rtlzz_owner_169(.a(97'(mul_tree_130_167)), .b(129'(mul_tree_130_168)), .cin(1'h0), .value(mul_tree_130_169[127:0]));
    assign mul_tree_130_169[129:128] = '0;
    assign mul_tree_130_170 = mul_tree_130_169[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_171 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_172 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_173Core rtlzz_owner_173(.a(32'(mul_tree_131_171)), .b(32'(mul_tree_131_172)), .cin(1'b0), .value(mul_tree_131_173));
    assign mul_tree_131_174 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_175 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(32'(mul_tree_131_174)), .b(32'(mul_tree_131_175)), .cin(1'b0), .value(mul_tree_131_176));
    assign mul_tree_131_177 = {mul_tree_131_176, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_178 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_179 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(32'(mul_tree_131_178)), .b(32'(mul_tree_131_179)), .cin(1'b0), .value(mul_tree_131_180));
    assign mul_tree_131_181 = {mul_tree_131_180, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_182 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_183 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(32'(mul_tree_131_182)), .b(32'(mul_tree_131_183)), .cin(1'b0), .value(mul_tree_131_184));
    assign mul_tree_131_185 = {mul_tree_131_184, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_186 = ({33'h0, rtlzz_pipe_173_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_187 = ({1'h0, rtlzz_pipe_177_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(64'(mul_tree_131_186)), .b(96'(mul_tree_131_187)), .cin(1'h0), .value(mul_tree_131_188));
    assign mul_tree_131_189 = ({33'h0, rtlzz_pipe_181_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_190 = ({1'h0, rtlzz_pipe_185_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_191Core rtlzz_owner_191(.a(96'(mul_tree_131_189)), .b(128'(mul_tree_131_190)), .cin(1'h0), .value(mul_tree_131_191[127:0]));
    assign mul_tree_131_191[128:128] = '0;
    assign mul_tree_131_192 = ({33'h0, rtlzz_pipe_188_s5}); // decl: <none>; prim: <none>
    assign mul_tree_131_193 = ({1'h0, rtlzz_pipe_191_s5}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(97'(mul_tree_131_192)), .b(129'(mul_tree_131_193)), .cin(1'h0), .value(mul_tree_131_194[127:0]));
    assign mul_tree_131_194[129:128] = '0;
    assign mul_tree_131_195 = mul_tree_131_194[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_196 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_197 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(32'(mul_tree_132_196)), .b(32'(mul_tree_132_197)), .cin(1'b0), .value(mul_tree_132_198));
    assign mul_tree_132_199 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_200 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(32'(mul_tree_132_199)), .b(32'(mul_tree_132_200)), .cin(1'b0), .value(mul_tree_132_201));
    assign mul_tree_132_202 = {mul_tree_132_201, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_203 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_204 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_205Core rtlzz_owner_205(.a(32'(mul_tree_132_203)), .b(32'(mul_tree_132_204)), .cin(1'b0), .value(mul_tree_132_205));
    assign mul_tree_132_206 = {mul_tree_132_205, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_207 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_208 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_209Core rtlzz_owner_209(.a(32'(mul_tree_132_207)), .b(32'(mul_tree_132_208)), .cin(1'b0), .value(mul_tree_132_209));
    assign mul_tree_132_210 = {mul_tree_132_209, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_211 = ({33'h0, mul_tree_132_198}); // decl: <none>; prim: <none>
    assign mul_tree_132_212 = ({1'h0, mul_tree_132_202}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_213Core rtlzz_owner_213(.a(64'(mul_tree_132_211)), .b(96'(mul_tree_132_212)), .cin(1'h0), .value(mul_tree_132_213));
    assign mul_tree_132_214 = ({33'h0, mul_tree_132_206}); // decl: <none>; prim: <none>
    assign mul_tree_132_215 = ({1'h0, mul_tree_132_210}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(96'(mul_tree_132_214)), .b(128'(mul_tree_132_215)), .cin(1'h0), .value(mul_tree_132_216[127:0]));
    assign mul_tree_132_216[128:128] = '0;
    assign mul_tree_132_217 = ({33'h0, rtlzz_pipe_213_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_218 = ({1'h0, rtlzz_pipe_216_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_219Core rtlzz_owner_219(.a(97'(mul_tree_132_217)), .b(129'(mul_tree_132_218)), .cin(1'h0), .value(mul_tree_132_219[127:0]));
    assign mul_tree_132_219[129:128] = '0;
    assign mul_tree_132_220 = mul_tree_132_219[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_221 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_222 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223Core rtlzz_owner_223(.a(32'(mul_tree_133_221)), .b(32'(mul_tree_133_222)), .cin(1'b0), .value(mul_tree_133_223));
    assign mul_tree_133_224 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_225 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(32'(mul_tree_133_224)), .b(32'(mul_tree_133_225)), .cin(1'b0), .value(mul_tree_133_226));
    assign mul_tree_133_227 = {mul_tree_133_226, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_228 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_229 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(32'(mul_tree_133_228)), .b(32'(mul_tree_133_229)), .cin(1'b0), .value(mul_tree_133_230));
    assign mul_tree_133_231 = {mul_tree_133_230, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_232 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_233 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(32'(mul_tree_133_232)), .b(32'(mul_tree_133_233)), .cin(1'b0), .value(mul_tree_133_234));
    assign mul_tree_133_235 = {mul_tree_133_234, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_236 = ({33'h0, rtlzz_pipe_223_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_237 = ({1'h0, rtlzz_pipe_227_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(64'(mul_tree_133_236)), .b(96'(mul_tree_133_237)), .cin(1'h0), .value(mul_tree_133_238));
    assign mul_tree_133_239 = ({33'h0, rtlzz_pipe_231_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_240 = ({1'h0, rtlzz_pipe_235_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_241Core rtlzz_owner_241(.a(96'(mul_tree_133_239)), .b(128'(mul_tree_133_240)), .cin(1'h0), .value(mul_tree_133_241[127:0]));
    assign mul_tree_133_241[128:128] = '0;
    assign mul_tree_133_242 = ({33'h0, rtlzz_pipe_238_s2}); // decl: <none>; prim: <none>
    assign mul_tree_133_243 = ({1'h0, rtlzz_pipe_241_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(97'(mul_tree_133_242)), .b(129'(mul_tree_133_243)), .cin(1'h0), .value(mul_tree_133_244[127:0]));
    assign mul_tree_133_244[129:128] = '0;
    assign mul_tree_133_245 = mul_tree_133_244[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_246 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_247 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(32'(mul_tree_134_246)), .b(32'(mul_tree_134_247)), .cin(1'b0), .value(mul_tree_134_248));
    assign mul_tree_134_249 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_250 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_251Core rtlzz_owner_251(.a(32'(mul_tree_134_249)), .b(32'(mul_tree_134_250)), .cin(1'b0), .value(mul_tree_134_251));
    assign mul_tree_134_252 = {mul_tree_134_251, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_253 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_254 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_255Core rtlzz_owner_255(.a(32'(mul_tree_134_253)), .b(32'(mul_tree_134_254)), .cin(1'b0), .value(mul_tree_134_255));
    assign mul_tree_134_256 = {mul_tree_134_255, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_257 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_258 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_259Core rtlzz_owner_259(.a(32'(mul_tree_134_257)), .b(32'(mul_tree_134_258)), .cin(1'b0), .value(mul_tree_134_259));
    assign mul_tree_134_260 = {mul_tree_134_259, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_261 = ({33'h0, rtlzz_pipe_248_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_262 = ({1'h0, rtlzz_pipe_252_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_264 = ({33'h0, rtlzz_pipe_256_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_265 = ({1'h0, rtlzz_pipe_260_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_267 = ({33'h0, mul_tree_134_263}); // decl: <none>; prim: <none>
    assign mul_tree_134_268 = ({1'h0, mul_tree_134_266}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_269_reduce rtlzz_reduce_269(.i1055(rtlzz_pipe_248_s4), .i1056(rtlzz_pipe_252_s4), .i1057(rtlzz_pipe_256_s4), .i1058(rtlzz_pipe_260_s4), .y(mul_tree_134_269));
    assign mul_tree_134_270 = mul_tree_134_269[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_271 = rtlzz_pipe_108_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_272 = rtlzz_pipe_109_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_273Core rtlzz_owner_273(.a(32'(mul_tree_135_271)), .b(32'(mul_tree_135_272)), .cin(1'b0), .value(mul_tree_135_273));
    assign mul_tree_135_274 = rtlzz_pipe_108_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_275 = rtlzz_pipe_109_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(32'(mul_tree_135_274)), .b(32'(mul_tree_135_275)), .cin(1'b0), .value(mul_tree_135_276));
    assign mul_tree_135_277 = {mul_tree_135_276, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_278 = rtlzz_pipe_108_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_279 = rtlzz_pipe_109_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(32'(mul_tree_135_278)), .b(32'(mul_tree_135_279)), .cin(1'b0), .value(mul_tree_135_280));
    assign mul_tree_135_281 = {mul_tree_135_280, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_282 = rtlzz_pipe_108_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_283 = rtlzz_pipe_109_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_284Core rtlzz_owner_284(.a(32'(mul_tree_135_282)), .b(32'(mul_tree_135_283)), .cin(1'b0), .value(mul_tree_135_284));
    assign mul_tree_135_285 = {mul_tree_135_284, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_286 = ({33'h0, rtlzz_pipe_273_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_287 = ({1'h0, rtlzz_pipe_277_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_289 = ({33'h0, rtlzz_pipe_281_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_290 = ({1'h0, rtlzz_pipe_285_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_292 = ({33'h0, mul_tree_135_288}); // decl: <none>; prim: <none>
    assign mul_tree_135_293 = ({1'h0, mul_tree_135_291}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294_reduce rtlzz_reduce_294(.i1060(rtlzz_pipe_273_s7), .i1062(rtlzz_pipe_277_s7), .i1064(rtlzz_pipe_281_s7), .i1066(rtlzz_pipe_285_s7), .y(mul_tree_135_294));
    assign mul_tree_135_295 = mul_tree_135_294[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_296 = mul_precision_110[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_297 = mul_precision_111[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(32'(mul_tree_136_296)), .b(32'(mul_tree_136_297)), .cin(1'b0), .value(mul_tree_136_298));
    assign mul_tree_136_299 = mul_precision_110[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_300 = mul_precision_111[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(32'(mul_tree_136_299)), .b(32'(mul_tree_136_300)), .cin(1'b0), .value(mul_tree_136_301));
    assign mul_tree_136_302 = {mul_tree_136_301, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_303 = mul_precision_110[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_304 = mul_precision_111[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_305Core rtlzz_owner_305(.a(32'(mul_tree_136_303)), .b(32'(mul_tree_136_304)), .cin(1'b0), .value(mul_tree_136_305));
    assign mul_tree_136_306 = {mul_tree_136_305, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_307 = mul_precision_110[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_308 = mul_precision_111[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(32'(mul_tree_136_307)), .b(32'(mul_tree_136_308)), .cin(1'b0), .value(mul_tree_136_309));
    assign mul_tree_136_310 = {mul_tree_136_309, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_311 = ({33'h0, rtlzz_pipe_298_s1}); // decl: <none>; prim: <none>
    assign mul_tree_136_312 = ({1'h0, rtlzz_pipe_302_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(64'(mul_tree_136_311)), .b(96'(mul_tree_136_312)), .cin(1'h0), .value(mul_tree_136_313));
    assign mul_tree_136_314 = ({33'h0, rtlzz_pipe_306_s1}); // decl: <none>; prim: <none>
    assign mul_tree_136_315 = ({1'h0, rtlzz_pipe_310_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_136_314)), .b(128'(mul_tree_136_315)), .cin(1'h0), .value(mul_tree_136_316[127:0]));
    assign mul_tree_136_316[128:128] = '0;
    assign mul_tree_136_317 = ({33'h0, rtlzz_pipe_313_s2}); // decl: <none>; prim: <none>
    assign mul_tree_136_318 = ({1'h0, rtlzz_pipe_316_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(97'(mul_tree_136_317)), .b(129'(mul_tree_136_318)), .cin(1'h0), .value(mul_tree_136_319[127:0]));
    assign mul_tree_136_319[129:128] = '0;
    assign mul_tree_136_320 = mul_tree_136_319[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_321 = rtlzz_pipe_112_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_322 = rtlzz_pipe_113_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_323Core rtlzz_owner_323(.a(32'(mul_tree_137_321)), .b(32'(mul_tree_137_322)), .cin(1'b0), .value(mul_tree_137_323));
    assign mul_tree_137_324 = rtlzz_pipe_112_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_325 = rtlzz_pipe_113_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_326Core rtlzz_owner_326(.a(32'(mul_tree_137_324)), .b(32'(mul_tree_137_325)), .cin(1'b0), .value(mul_tree_137_326));
    assign mul_tree_137_327 = {mul_tree_137_326, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_328 = rtlzz_pipe_112_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_329 = rtlzz_pipe_113_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(32'(mul_tree_137_328)), .b(32'(mul_tree_137_329)), .cin(1'b0), .value(mul_tree_137_330));
    assign mul_tree_137_331 = {mul_tree_137_330, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_332 = rtlzz_pipe_112_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_333 = rtlzz_pipe_113_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(32'(mul_tree_137_332)), .b(32'(mul_tree_137_333)), .cin(1'b0), .value(mul_tree_137_334));
    assign mul_tree_137_335 = {mul_tree_137_334, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_336 = ({33'h0, rtlzz_pipe_323_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_337 = ({1'h0, rtlzz_pipe_327_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_339 = ({33'h0, rtlzz_pipe_331_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_340 = ({1'h0, rtlzz_pipe_335_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_342 = ({33'h0, mul_tree_137_338}); // decl: <none>; prim: <none>
    assign mul_tree_137_343 = ({1'h0, mul_tree_137_341}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_344_reduce rtlzz_reduce_344(.i1074(rtlzz_pipe_323_s5), .i1076(rtlzz_pipe_327_s5), .i1078(rtlzz_pipe_331_s5), .i1080(rtlzz_pipe_335_s5), .y(mul_tree_137_344));
    assign mul_tree_137_345 = mul_tree_137_344[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_346 = rtlzz_pipe_114_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_347 = rtlzz_pipe_115_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(32'(mul_tree_138_346)), .b(32'(mul_tree_138_347)), .cin(1'b0), .value(mul_tree_138_348));
    assign mul_tree_138_349 = rtlzz_pipe_114_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_350 = rtlzz_pipe_115_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(32'(mul_tree_138_349)), .b(32'(mul_tree_138_350)), .cin(1'b0), .value(mul_tree_138_351));
    assign mul_tree_138_352 = {mul_tree_138_351, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_353 = rtlzz_pipe_114_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_354 = rtlzz_pipe_115_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(32'(mul_tree_138_353)), .b(32'(mul_tree_138_354)), .cin(1'b0), .value(mul_tree_138_355));
    assign mul_tree_138_356 = {mul_tree_138_355, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_357 = rtlzz_pipe_114_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_358 = rtlzz_pipe_115_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(32'(mul_tree_138_357)), .b(32'(mul_tree_138_358)), .cin(1'b0), .value(mul_tree_138_359));
    assign mul_tree_138_360 = {mul_tree_138_359, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_361 = ({33'h0, mul_tree_138_348}); // decl: <none>; prim: <none>
    assign mul_tree_138_362 = ({1'h0, mul_tree_138_352}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_363Core rtlzz_owner_363(.a(64'(mul_tree_138_361)), .b(96'(mul_tree_138_362)), .cin(1'h0), .value(mul_tree_138_363));
    assign mul_tree_138_364 = ({33'h0, mul_tree_138_356}); // decl: <none>; prim: <none>
    assign mul_tree_138_365 = ({1'h0, mul_tree_138_360}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366Core rtlzz_owner_366(.a(96'(mul_tree_138_364)), .b(128'(mul_tree_138_365)), .cin(1'h0), .value(mul_tree_138_366[127:0]));
    assign mul_tree_138_366[128:128] = '0;
    assign mul_tree_138_367 = ({33'h0, rtlzz_pipe_363_s7}); // decl: <none>; prim: <none>
    assign mul_tree_138_368 = ({1'h0, rtlzz_pipe_366_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(97'(mul_tree_138_367)), .b(129'(mul_tree_138_368)), .cin(1'h0), .value(mul_tree_138_369[127:0]));
    assign mul_tree_138_369[129:128] = '0;
    assign mul_tree_138_370 = mul_tree_138_369[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_371 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_372 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_139_371)), .b(32'(mul_tree_139_372)), .cin(1'b0), .value(mul_tree_139_373));
    assign mul_tree_139_374 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_375 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(32'(mul_tree_139_374)), .b(32'(mul_tree_139_375)), .cin(1'b0), .value(mul_tree_139_376));
    assign mul_tree_139_377 = {mul_tree_139_376, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_378 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_379 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_380Core rtlzz_owner_380(.a(32'(mul_tree_139_378)), .b(32'(mul_tree_139_379)), .cin(1'b0), .value(mul_tree_139_380));
    assign mul_tree_139_381 = {mul_tree_139_380, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_382 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_383 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_384Core rtlzz_owner_384(.a(32'(mul_tree_139_382)), .b(32'(mul_tree_139_383)), .cin(1'b0), .value(mul_tree_139_384));
    assign mul_tree_139_385 = {mul_tree_139_384, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_386 = ({33'h0, rtlzz_pipe_373_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_387 = ({1'h0, rtlzz_pipe_377_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(64'(mul_tree_139_386)), .b(96'(mul_tree_139_387)), .cin(1'h0), .value(mul_tree_139_388));
    assign mul_tree_139_389 = ({33'h0, rtlzz_pipe_381_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_390 = ({1'h0, rtlzz_pipe_385_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391Core rtlzz_owner_391(.a(96'(mul_tree_139_389)), .b(128'(mul_tree_139_390)), .cin(1'h0), .value(mul_tree_139_391[127:0]));
    assign mul_tree_139_391[128:128] = '0;
    assign mul_tree_139_392 = ({33'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_139_393 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(97'(mul_tree_139_392)), .b(129'(mul_tree_139_393)), .cin(1'h0), .value(mul_tree_139_394[127:0]));
    assign mul_tree_139_394[129:128] = '0;
    assign mul_tree_139_395 = mul_tree_139_394[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_396 = rtlzz_pipe_118_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_397 = rtlzz_pipe_119_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_140_396)), .b(32'(mul_tree_140_397)), .cin(1'b0), .value(mul_tree_140_398));
    assign mul_tree_140_399 = rtlzz_pipe_118_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_400 = rtlzz_pipe_119_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_401Core rtlzz_owner_401(.a(32'(mul_tree_140_399)), .b(32'(mul_tree_140_400)), .cin(1'b0), .value(mul_tree_140_401));
    assign mul_tree_140_402 = {mul_tree_140_401, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_403 = rtlzz_pipe_118_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_404 = rtlzz_pipe_119_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405Core rtlzz_owner_405(.a(32'(mul_tree_140_403)), .b(32'(mul_tree_140_404)), .cin(1'b0), .value(mul_tree_140_405));
    assign mul_tree_140_406 = {mul_tree_140_405, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_407 = rtlzz_pipe_118_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_408 = rtlzz_pipe_119_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(32'(mul_tree_140_407)), .b(32'(mul_tree_140_408)), .cin(1'b0), .value(mul_tree_140_409));
    assign mul_tree_140_410 = {mul_tree_140_409, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_411 = ({33'h0, mul_tree_140_398}); // decl: <none>; prim: <none>
    assign mul_tree_140_412 = ({1'h0, mul_tree_140_402}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_413Core rtlzz_owner_413(.a(64'(mul_tree_140_411)), .b(96'(mul_tree_140_412)), .cin(1'h0), .value(mul_tree_140_413));
    assign mul_tree_140_414 = ({33'h0, mul_tree_140_406}); // decl: <none>; prim: <none>
    assign mul_tree_140_415 = ({1'h0, mul_tree_140_410}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_416Core rtlzz_owner_416(.a(96'(mul_tree_140_414)), .b(128'(mul_tree_140_415)), .cin(1'h0), .value(mul_tree_140_416[127:0]));
    assign mul_tree_140_416[128:128] = '0;
    assign mul_tree_140_417 = ({33'h0, rtlzz_pipe_413_s4}); // decl: <none>; prim: <none>
    assign mul_tree_140_418 = ({1'h0, rtlzz_pipe_416_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(97'(mul_tree_140_417)), .b(129'(mul_tree_140_418)), .cin(1'h0), .value(mul_tree_140_419[127:0]));
    assign mul_tree_140_419[129:128] = '0;
    assign mul_tree_140_420 = mul_tree_140_419[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_421 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_422 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(32'(mul_tree_141_421)), .b(32'(mul_tree_141_422)), .cin(1'b0), .value(mul_tree_141_423));
    assign mul_tree_141_424 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_425 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_426Core rtlzz_owner_426(.a(32'(mul_tree_141_424)), .b(32'(mul_tree_141_425)), .cin(1'b0), .value(mul_tree_141_426));
    assign mul_tree_141_427 = {mul_tree_141_426, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_428 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_429 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(32'(mul_tree_141_428)), .b(32'(mul_tree_141_429)), .cin(1'b0), .value(mul_tree_141_430));
    assign mul_tree_141_431 = {mul_tree_141_430, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_432 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_433 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_434Core rtlzz_owner_434(.a(32'(mul_tree_141_432)), .b(32'(mul_tree_141_433)), .cin(1'b0), .value(mul_tree_141_434));
    assign mul_tree_141_435 = {mul_tree_141_434, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_436 = ({33'h0, rtlzz_pipe_423_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_437 = ({1'h0, rtlzz_pipe_427_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_438Core rtlzz_owner_438(.a(64'(mul_tree_141_436)), .b(96'(mul_tree_141_437)), .cin(1'h0), .value(mul_tree_141_438));
    assign mul_tree_141_439 = ({33'h0, rtlzz_pipe_431_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_440 = ({1'h0, rtlzz_pipe_435_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_441Core rtlzz_owner_441(.a(96'(mul_tree_141_439)), .b(128'(mul_tree_141_440)), .cin(1'h0), .value(mul_tree_141_441[127:0]));
    assign mul_tree_141_441[128:128] = '0;
    assign mul_tree_141_442 = ({33'h0, rtlzz_pipe_438_s2}); // decl: <none>; prim: <none>
    assign mul_tree_141_443 = ({1'h0, rtlzz_pipe_441_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_444Core rtlzz_owner_444(.a(97'(mul_tree_141_442)), .b(129'(mul_tree_141_443)), .cin(1'h0), .value(mul_tree_141_444[127:0]));
    assign mul_tree_141_444[129:128] = '0;
    assign mul_tree_141_445 = mul_tree_141_444[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_446 = rtlzz_pipe_122_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_447 = rtlzz_pipe_123_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_448Core rtlzz_owner_448(.a(32'(mul_tree_142_446)), .b(32'(mul_tree_142_447)), .cin(1'b0), .value(mul_tree_142_448));
    assign mul_tree_142_449 = rtlzz_pipe_122_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_450 = rtlzz_pipe_123_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(32'(mul_tree_142_449)), .b(32'(mul_tree_142_450)), .cin(1'b0), .value(mul_tree_142_451));
    assign mul_tree_142_452 = {mul_tree_142_451, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_453 = rtlzz_pipe_122_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_454 = rtlzz_pipe_123_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(32'(mul_tree_142_453)), .b(32'(mul_tree_142_454)), .cin(1'b0), .value(mul_tree_142_455));
    assign mul_tree_142_456 = {mul_tree_142_455, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_457 = rtlzz_pipe_122_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_458 = rtlzz_pipe_123_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_459Core rtlzz_owner_459(.a(32'(mul_tree_142_457)), .b(32'(mul_tree_142_458)), .cin(1'b0), .value(mul_tree_142_459));
    assign mul_tree_142_460 = {mul_tree_142_459, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_461 = ({33'h0, rtlzz_pipe_448_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_462 = ({1'h0, rtlzz_pipe_452_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_464 = ({33'h0, rtlzz_pipe_456_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_465 = ({1'h0, rtlzz_pipe_460_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_467 = ({33'h0, mul_tree_142_463}); // decl: <none>; prim: <none>
    assign mul_tree_142_468 = ({1'h0, mul_tree_142_466}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_469_reduce rtlzz_reduce_469(.i1097(rtlzz_pipe_448_s5), .i1098(rtlzz_pipe_452_s5), .i1099(rtlzz_pipe_456_s5), .i1100(rtlzz_pipe_460_s5), .y(mul_tree_142_469));
    assign mul_tree_142_470 = mul_tree_142_469[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_471 = rtlzz_pipe_124_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_472 = rtlzz_pipe_125_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_473Core rtlzz_owner_473(.a(32'(mul_tree_143_471)), .b(32'(mul_tree_143_472)), .cin(1'b0), .value(mul_tree_143_473));
    assign mul_tree_143_474 = rtlzz_pipe_124_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_475 = rtlzz_pipe_125_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_143_474)), .b(32'(mul_tree_143_475)), .cin(1'b0), .value(mul_tree_143_476));
    assign mul_tree_143_477 = {mul_tree_143_476, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_478 = rtlzz_pipe_124_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_479 = rtlzz_pipe_125_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_480Core rtlzz_owner_480(.a(32'(mul_tree_143_478)), .b(32'(mul_tree_143_479)), .cin(1'b0), .value(mul_tree_143_480));
    assign mul_tree_143_481 = {mul_tree_143_480, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_482 = rtlzz_pipe_124_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_483 = rtlzz_pipe_125_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_484Core rtlzz_owner_484(.a(32'(mul_tree_143_482)), .b(32'(mul_tree_143_483)), .cin(1'b0), .value(mul_tree_143_484));
    assign mul_tree_143_485 = {mul_tree_143_484, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_486 = ({33'h0, rtlzz_pipe_473_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_487 = ({1'h0, rtlzz_pipe_477_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_489 = ({33'h0, rtlzz_pipe_481_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_490 = ({1'h0, rtlzz_pipe_485_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_492 = ({33'h0, mul_tree_143_488}); // decl: <none>; prim: <none>
    assign mul_tree_143_493 = ({1'h0, mul_tree_143_491}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_494_reduce rtlzz_reduce_494(.i1101(rtlzz_pipe_473_s7), .i1102(rtlzz_pipe_477_s7), .i1103(rtlzz_pipe_481_s7), .i1104(rtlzz_pipe_485_s7), .y(mul_tree_143_494));
    assign mul_tree_143_495 = mul_tree_143_494[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_496 = mul_precision_126[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_497 = mul_precision_127[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_498Core rtlzz_owner_498(.a(32'(mul_tree_144_496)), .b(32'(mul_tree_144_497)), .cin(1'b0), .value(mul_tree_144_498));
    assign mul_tree_144_499 = mul_precision_126[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_500 = mul_precision_127[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_144_499)), .b(32'(mul_tree_144_500)), .cin(1'b0), .value(mul_tree_144_501));
    assign mul_tree_144_502 = {mul_tree_144_501, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_503 = mul_precision_126[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_504 = mul_precision_127[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(32'(mul_tree_144_503)), .b(32'(mul_tree_144_504)), .cin(1'b0), .value(mul_tree_144_505));
    assign mul_tree_144_506 = {mul_tree_144_505, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_507 = mul_precision_126[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_508 = mul_precision_127[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_509Core rtlzz_owner_509(.a(32'(mul_tree_144_507)), .b(32'(mul_tree_144_508)), .cin(1'b0), .value(mul_tree_144_509));
    assign mul_tree_144_510 = {mul_tree_144_509, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_511 = ({33'h0, rtlzz_pipe_498_s1}); // decl: <none>; prim: <none>
    assign mul_tree_144_512 = ({1'h0, rtlzz_pipe_502_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_513Core rtlzz_owner_513(.a(64'(mul_tree_144_511)), .b(96'(mul_tree_144_512)), .cin(1'h0), .value(mul_tree_144_513));
    assign mul_tree_144_514 = ({33'h0, rtlzz_pipe_506_s1}); // decl: <none>; prim: <none>
    assign mul_tree_144_515 = ({1'h0, rtlzz_pipe_510_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_516Core rtlzz_owner_516(.a(96'(mul_tree_144_514)), .b(128'(mul_tree_144_515)), .cin(1'h0), .value(mul_tree_144_516[127:0]));
    assign mul_tree_144_516[128:128] = '0;
    assign mul_tree_144_517 = ({33'h0, rtlzz_pipe_513_s2}); // decl: <none>; prim: <none>
    assign mul_tree_144_518 = ({1'h0, rtlzz_pipe_516_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_519Core rtlzz_owner_519(.a(97'(mul_tree_144_517)), .b(129'(mul_tree_144_518)), .cin(1'h0), .value(mul_tree_144_519[127:0]));
    assign mul_tree_144_519[129:128] = '0;
    assign mul_tree_144_520 = mul_tree_144_519[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_521 = rtlzz_pipe_128_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_522 = rtlzz_pipe_129_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_523Core rtlzz_owner_523(.a(32'(mul_tree_145_521)), .b(32'(mul_tree_145_522)), .cin(1'b0), .value(mul_tree_145_523));
    assign mul_tree_145_524 = rtlzz_pipe_128_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_525 = rtlzz_pipe_129_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(32'(mul_tree_145_524)), .b(32'(mul_tree_145_525)), .cin(1'b0), .value(mul_tree_145_526));
    assign mul_tree_145_527 = {mul_tree_145_526, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_528 = rtlzz_pipe_128_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_529 = rtlzz_pipe_129_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_530Core rtlzz_owner_530(.a(32'(mul_tree_145_528)), .b(32'(mul_tree_145_529)), .cin(1'b0), .value(mul_tree_145_530));
    assign mul_tree_145_531 = {mul_tree_145_530, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_532 = rtlzz_pipe_128_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_533 = rtlzz_pipe_129_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_534Core rtlzz_owner_534(.a(32'(mul_tree_145_532)), .b(32'(mul_tree_145_533)), .cin(1'b0), .value(mul_tree_145_534));
    assign mul_tree_145_535 = {mul_tree_145_534, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_536 = ({33'h0, rtlzz_pipe_523_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_537 = ({1'h0, rtlzz_pipe_527_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_539 = ({33'h0, rtlzz_pipe_531_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_540 = ({1'h0, rtlzz_pipe_535_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_542 = ({33'h0, mul_tree_145_538}); // decl: <none>; prim: <none>
    assign mul_tree_145_543 = ({1'h0, mul_tree_145_541}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_544_reduce rtlzz_reduce_544(.i1111(rtlzz_pipe_523_s4), .i1112(rtlzz_pipe_527_s4), .i1113(rtlzz_pipe_531_s4), .i1114(rtlzz_pipe_535_s4), .y(mul_tree_145_544));
    assign mul_tree_145_545 = mul_tree_145_544[127:0]; // decl: <none>; prim: <none>
    assign limb_49_546 = ({1'h0, s8_norm_mul_2_v0}); // decl: <none>; prim: <none>
    assign limb_49_547 = ({1'h0, s8_norm_mul_6_v0}); // decl: <none>; prim: <none>
    assign limb_49_548 = limb_49_546[31:0]; // decl: <none>; prim: <none>
    assign limb_49_549 = limb_49_547[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(32'(rtlzz_pipe_548_s6)), .b(32'(rtlzz_pipe_549_s6)), .cin(1'h0), .value(limb_49_550));
    assign limb_49_551 = limb_49_550[31:0]; // decl: <none>; prim: <none>
    assign limb_49_552 = limb_49_550[32]; // decl: <none>; prim: <none>
    assign limb_49_553 = limb_49_546[63:32]; // decl: <none>; prim: <none>
    assign limb_49_554 = limb_49_547[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_555Core rtlzz_owner_555(.a(32'(rtlzz_pipe_553_s6)), .b(32'(rtlzz_pipe_554_s6)), .cin(limb_49_552), .value(limb_49_555));
    assign limb_49_556 = limb_49_555[31:0]; // decl: <none>; prim: <none>
    assign limb_49_557 = limb_49_555[32]; // decl: <none>; prim: <none>
    assign limb_49_558 = limb_49_546[95:64]; // decl: <none>; prim: <none>
    assign limb_49_559 = limb_49_547[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_560Core rtlzz_owner_560(.a(32'(rtlzz_pipe_558_s6)), .b(32'(rtlzz_pipe_559_s6)), .cin(limb_49_557), .value(limb_49_560));
    assign limb_49_561 = limb_49_560[31:0]; // decl: <none>; prim: <none>
    assign limb_49_562 = limb_49_560[32]; // decl: <none>; prim: <none>
    assign limb_49_563 = limb_49_546[127:96]; // decl: <none>; prim: <none>
    assign limb_49_564 = limb_49_547[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_565Core rtlzz_owner_565(.a(32'(rtlzz_pipe_563_s6)), .b(32'(rtlzz_pipe_564_s6)), .cin(limb_49_562), .value(limb_49_565));
    assign limb_49_566 = limb_49_565[31:0]; // decl: <none>; prim: <none>
    assign limb_49_567 = limb_49_565[32]; // decl: <none>; prim: <none>
    assign limb_49_568 = limb_49_546[128]; // decl: <none>; prim: <none>
    assign limb_49_569 = limb_49_547[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_570Core rtlzz_owner_570(.a(1'(rtlzz_pipe_568_s6)), .b(1'(rtlzz_pipe_569_s6)), .cin(limb_49_567), .value(limb_49_570[0:0]));
    assign limb_49_570[1:1] = '0;
    assign limb_49_571 = limb_49_570[0]; // decl: <none>; prim: <none>
    assign limb_49_572 = {limb_49_571, limb_49_566, limb_49_561, limb_49_556, limb_49_551}; // decl: <none>; prim: <none>
    assign limb_50_573 = ({1'h0, s8_norm_mul_10_v0}); // decl: <none>; prim: <none>
    assign limb_50_574 = ({1'h0, s8_norm_mul_14_v0}); // decl: <none>; prim: <none>
    assign limb_50_575 = limb_50_573[31:0]; // decl: <none>; prim: <none>
    assign limb_50_576 = limb_50_574[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_577Core rtlzz_owner_577(.a(32'(limb_50_575)), .b(32'(rtlzz_pipe_576_s7)), .cin(1'h0), .value(limb_50_577));
    assign limb_50_578 = limb_50_577[31:0]; // decl: <none>; prim: <none>
    assign limb_50_579 = limb_50_577[32]; // decl: <none>; prim: <none>
    assign limb_50_580 = limb_50_573[63:32]; // decl: <none>; prim: <none>
    assign limb_50_581 = limb_50_574[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_582Core rtlzz_owner_582(.a(32'(limb_50_580)), .b(32'(rtlzz_pipe_581_s7)), .cin(limb_50_579), .value(limb_50_582));
    assign limb_50_583 = limb_50_582[31:0]; // decl: <none>; prim: <none>
    assign limb_50_584 = limb_50_582[32]; // decl: <none>; prim: <none>
    assign limb_50_585 = limb_50_573[95:64]; // decl: <none>; prim: <none>
    assign limb_50_586 = limb_50_574[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_587Core rtlzz_owner_587(.a(32'(limb_50_585)), .b(32'(rtlzz_pipe_586_s7)), .cin(limb_50_584), .value(limb_50_587));
    assign limb_50_588 = limb_50_587[31:0]; // decl: <none>; prim: <none>
    assign limb_50_589 = limb_50_587[32]; // decl: <none>; prim: <none>
    assign limb_50_590 = limb_50_573[127:96]; // decl: <none>; prim: <none>
    assign limb_50_591 = limb_50_574[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_592Core rtlzz_owner_592(.a(32'(limb_50_590)), .b(32'(rtlzz_pipe_591_s7)), .cin(limb_50_589), .value(limb_50_592));
    assign limb_50_593 = limb_50_592[31:0]; // decl: <none>; prim: <none>
    assign limb_50_594 = limb_50_592[32]; // decl: <none>; prim: <none>
    assign limb_50_595 = limb_50_573[128]; // decl: <none>; prim: <none>
    assign limb_50_596 = limb_50_574[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_597Core rtlzz_owner_597(.a(1'(limb_50_595)), .b(1'(rtlzz_pipe_596_s7)), .cin(limb_50_594), .value(limb_50_597[0:0]));
    assign limb_50_597[1:1] = '0;
    assign limb_50_598 = limb_50_597[0]; // decl: <none>; prim: <none>
    assign limb_50_599 = {limb_50_598, limb_50_593, limb_50_588, limb_50_583, limb_50_578}; // decl: <none>; prim: <none>
    assign limb_51_600 = ({1'h0, s8_norm_mul_18_v0}); // decl: <none>; prim: <none>
    assign limb_51_601 = ({1'h0, s8_norm_mul_22_v0}); // decl: <none>; prim: <none>
    assign limb_51_602 = limb_51_600[31:0]; // decl: <none>; prim: <none>
    assign limb_51_603 = limb_51_601[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_604Core rtlzz_owner_604(.a(32'(rtlzz_pipe_602_s7)), .b(32'(limb_51_603)), .cin(1'h0), .value(limb_51_604));
    assign limb_51_605 = limb_51_604[31:0]; // decl: <none>; prim: <none>
    assign limb_51_606 = limb_51_604[32]; // decl: <none>; prim: <none>
    assign limb_51_607 = limb_51_600[63:32]; // decl: <none>; prim: <none>
    assign limb_51_608 = limb_51_601[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_609Core rtlzz_owner_609(.a(32'(rtlzz_pipe_607_s7)), .b(32'(limb_51_608)), .cin(limb_51_606), .value(limb_51_609));
    assign limb_51_610 = limb_51_609[31:0]; // decl: <none>; prim: <none>
    assign limb_51_611 = limb_51_609[32]; // decl: <none>; prim: <none>
    assign limb_51_612 = limb_51_600[95:64]; // decl: <none>; prim: <none>
    assign limb_51_613 = limb_51_601[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_614Core rtlzz_owner_614(.a(32'(rtlzz_pipe_612_s7)), .b(32'(limb_51_613)), .cin(limb_51_611), .value(limb_51_614));
    assign limb_51_615 = limb_51_614[31:0]; // decl: <none>; prim: <none>
    assign limb_51_616 = limb_51_614[32]; // decl: <none>; prim: <none>
    assign limb_51_617 = limb_51_600[127:96]; // decl: <none>; prim: <none>
    assign limb_51_618 = limb_51_601[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_619Core rtlzz_owner_619(.a(32'(rtlzz_pipe_617_s7)), .b(32'(limb_51_618)), .cin(limb_51_616), .value(limb_51_619));
    assign limb_51_620 = limb_51_619[31:0]; // decl: <none>; prim: <none>
    assign limb_51_621 = limb_51_619[32]; // decl: <none>; prim: <none>
    assign limb_51_622 = limb_51_600[128]; // decl: <none>; prim: <none>
    assign limb_51_623 = limb_51_601[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_624Core rtlzz_owner_624(.a(1'(rtlzz_pipe_622_s7)), .b(1'(limb_51_623)), .cin(limb_51_621), .value(limb_51_624[0:0]));
    assign limb_51_624[1:1] = '0;
    assign limb_51_625 = limb_51_624[0]; // decl: <none>; prim: <none>
    assign limb_51_626 = {limb_51_625, limb_51_620, limb_51_615, limb_51_610, limb_51_605}; // decl: <none>; prim: <none>
    assign limb_52_627 = ({1'h0, s8_norm_mul_26_v0}); // decl: <none>; prim: <none>
    assign limb_52_628 = ({1'h0, s8_norm_mul_30_v0}); // decl: <none>; prim: <none>
    assign limb_52_629 = limb_52_627[31:0]; // decl: <none>; prim: <none>
    assign limb_52_630 = limb_52_628[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_631Core rtlzz_owner_631(.a(32'(rtlzz_pipe_629_s5)), .b(32'(limb_52_630)), .cin(1'h0), .value(limb_52_631));
    assign limb_52_632 = limb_52_631[31:0]; // decl: <none>; prim: <none>
    assign limb_52_633 = limb_52_631[32]; // decl: <none>; prim: <none>
    assign limb_52_634 = limb_52_627[63:32]; // decl: <none>; prim: <none>
    assign limb_52_635 = limb_52_628[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_636Core rtlzz_owner_636(.a(32'(rtlzz_pipe_634_s5)), .b(32'(limb_52_635)), .cin(limb_52_633), .value(limb_52_636));
    assign limb_52_637 = limb_52_636[31:0]; // decl: <none>; prim: <none>
    assign limb_52_638 = limb_52_636[32]; // decl: <none>; prim: <none>
    assign limb_52_639 = limb_52_627[95:64]; // decl: <none>; prim: <none>
    assign limb_52_640 = limb_52_628[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_641Core rtlzz_owner_641(.a(32'(rtlzz_pipe_639_s5)), .b(32'(limb_52_640)), .cin(limb_52_638), .value(limb_52_641));
    assign limb_52_642 = limb_52_641[31:0]; // decl: <none>; prim: <none>
    assign limb_52_643 = limb_52_641[32]; // decl: <none>; prim: <none>
    assign limb_52_644 = limb_52_627[127:96]; // decl: <none>; prim: <none>
    assign limb_52_645 = limb_52_628[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_646Core rtlzz_owner_646(.a(32'(rtlzz_pipe_644_s5)), .b(32'(limb_52_645)), .cin(limb_52_643), .value(limb_52_646));
    assign limb_52_647 = limb_52_646[31:0]; // decl: <none>; prim: <none>
    assign limb_52_648 = limb_52_646[32]; // decl: <none>; prim: <none>
    assign limb_52_649 = limb_52_627[128]; // decl: <none>; prim: <none>
    assign limb_52_650 = limb_52_628[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_651Core rtlzz_owner_651(.a(1'(rtlzz_pipe_649_s5)), .b(1'(limb_52_650)), .cin(limb_52_648), .value(limb_52_651[0:0]));
    assign limb_52_651[1:1] = '0;
    assign limb_52_652 = limb_52_651[0]; // decl: <none>; prim: <none>
    assign limb_52_653 = {limb_52_652, limb_52_647, limb_52_642, limb_52_637, limb_52_632}; // decl: <none>; prim: <none>
    assign limb_53_654 = ({1'h0, s8_norm_mul_34_v0}); // decl: <none>; prim: <none>
    assign limb_53_655 = ({1'h0, s8_norm_mul_38_v0}); // decl: <none>; prim: <none>
    assign limb_53_656 = limb_53_654[31:0]; // decl: <none>; prim: <none>
    assign limb_53_657 = limb_53_655[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_658Core rtlzz_owner_658(.a(32'(limb_53_656)), .b(32'(rtlzz_pipe_657_s7)), .cin(1'h0), .value(limb_53_658));
    assign limb_53_659 = limb_53_658[31:0]; // decl: <none>; prim: <none>
    assign limb_53_660 = limb_53_658[32]; // decl: <none>; prim: <none>
    assign limb_53_661 = limb_53_654[63:32]; // decl: <none>; prim: <none>
    assign limb_53_662 = limb_53_655[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_663Core rtlzz_owner_663(.a(32'(limb_53_661)), .b(32'(rtlzz_pipe_662_s7)), .cin(limb_53_660), .value(limb_53_663));
    assign limb_53_664 = limb_53_663[31:0]; // decl: <none>; prim: <none>
    assign limb_53_665 = limb_53_663[32]; // decl: <none>; prim: <none>
    assign limb_53_666 = limb_53_654[95:64]; // decl: <none>; prim: <none>
    assign limb_53_667 = limb_53_655[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_668Core rtlzz_owner_668(.a(32'(limb_53_666)), .b(32'(rtlzz_pipe_667_s7)), .cin(limb_53_665), .value(limb_53_668));
    assign limb_53_669 = limb_53_668[31:0]; // decl: <none>; prim: <none>
    assign limb_53_670 = limb_53_668[32]; // decl: <none>; prim: <none>
    assign limb_53_671 = limb_53_654[127:96]; // decl: <none>; prim: <none>
    assign limb_53_672 = limb_53_655[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_673Core rtlzz_owner_673(.a(32'(limb_53_671)), .b(32'(rtlzz_pipe_672_s7)), .cin(limb_53_670), .value(limb_53_673));
    assign limb_53_674 = limb_53_673[31:0]; // decl: <none>; prim: <none>
    assign limb_53_675 = limb_53_673[32]; // decl: <none>; prim: <none>
    assign limb_53_676 = limb_53_654[128]; // decl: <none>; prim: <none>
    assign limb_53_677 = limb_53_655[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_678Core rtlzz_owner_678(.a(1'(limb_53_676)), .b(1'(rtlzz_pipe_677_s7)), .cin(limb_53_675), .value(limb_53_678[0:0]));
    assign limb_53_678[1:1] = '0;
    assign limb_53_679 = limb_53_678[0]; // decl: <none>; prim: <none>
    assign limb_53_680 = {limb_53_679, limb_53_674, limb_53_669, limb_53_664, limb_53_659}; // decl: <none>; prim: <none>
    assign limb_54_681 = ({1'h0, s8_norm_mul_42_v0}); // decl: <none>; prim: <none>
    assign limb_54_682 = ({1'h0, s8_norm_mul_46_v0}); // decl: <none>; prim: <none>
    assign limb_54_683 = limb_54_681[31:0]; // decl: <none>; prim: <none>
    assign limb_54_684 = limb_54_682[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_685Core rtlzz_owner_685(.a(32'(limb_54_683)), .b(32'(rtlzz_pipe_684_s4)), .cin(1'h0), .value(limb_54_685));
    assign limb_54_686 = limb_54_685[31:0]; // decl: <none>; prim: <none>
    assign limb_54_687 = limb_54_685[32]; // decl: <none>; prim: <none>
    assign limb_54_688 = limb_54_681[63:32]; // decl: <none>; prim: <none>
    assign limb_54_689 = limb_54_682[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_690Core rtlzz_owner_690(.a(32'(limb_54_688)), .b(32'(rtlzz_pipe_689_s4)), .cin(limb_54_687), .value(limb_54_690));
    assign limb_54_691 = limb_54_690[31:0]; // decl: <none>; prim: <none>
    assign limb_54_692 = limb_54_690[32]; // decl: <none>; prim: <none>
    assign limb_54_693 = limb_54_681[95:64]; // decl: <none>; prim: <none>
    assign limb_54_694 = limb_54_682[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_695Core rtlzz_owner_695(.a(32'(limb_54_693)), .b(32'(rtlzz_pipe_694_s4)), .cin(limb_54_692), .value(limb_54_695));
    assign limb_54_696 = limb_54_695[31:0]; // decl: <none>; prim: <none>
    assign limb_54_697 = limb_54_695[32]; // decl: <none>; prim: <none>
    assign limb_54_698 = limb_54_681[127:96]; // decl: <none>; prim: <none>
    assign limb_54_699 = limb_54_682[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_700Core rtlzz_owner_700(.a(32'(limb_54_698)), .b(32'(rtlzz_pipe_699_s4)), .cin(limb_54_697), .value(limb_54_700));
    assign limb_54_701 = limb_54_700[31:0]; // decl: <none>; prim: <none>
    assign limb_54_702 = limb_54_700[32]; // decl: <none>; prim: <none>
    assign limb_54_703 = limb_54_681[128]; // decl: <none>; prim: <none>
    assign limb_54_704 = limb_54_682[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_705Core rtlzz_owner_705(.a(1'(rtlzz_pipe_703_s6)), .b(1'(rtlzz_pipe_704_s6)), .cin(rtlzz_pipe_702_s6), .value(limb_54_705[0:0]));
    assign limb_54_705[1:1] = '0;
    assign limb_54_706 = limb_54_705[0]; // decl: <none>; prim: <none>
    assign limb_54_707 = {limb_54_706, rtlzz_pipe_701_s6, rtlzz_pipe_696_s6, rtlzz_pipe_691_s6, rtlzz_pipe_686_s6}; // decl: <none>; prim: <none>
    assign limb_55_708 = ({1'h0, s8_norm_mul_50_v0}); // decl: <none>; prim: <none>
    assign limb_55_709 = ({1'h0, s8_norm_mul_54_v0}); // decl: <none>; prim: <none>
    assign limb_55_710 = limb_55_708[31:0]; // decl: <none>; prim: <none>
    assign limb_55_711 = limb_55_709[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_712Core rtlzz_owner_712(.a(32'(rtlzz_pipe_710_s7)), .b(32'(limb_55_711)), .cin(1'h0), .value(limb_55_712));
    assign limb_55_713 = limb_55_712[31:0]; // decl: <none>; prim: <none>
    assign limb_55_714 = limb_55_712[32]; // decl: <none>; prim: <none>
    assign limb_55_715 = limb_55_708[63:32]; // decl: <none>; prim: <none>
    assign limb_55_716 = limb_55_709[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_717Core rtlzz_owner_717(.a(32'(rtlzz_pipe_715_s7)), .b(32'(limb_55_716)), .cin(limb_55_714), .value(limb_55_717));
    assign limb_55_718 = limb_55_717[31:0]; // decl: <none>; prim: <none>
    assign limb_55_719 = limb_55_717[32]; // decl: <none>; prim: <none>
    assign limb_55_720 = limb_55_708[95:64]; // decl: <none>; prim: <none>
    assign limb_55_721 = limb_55_709[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_722Core rtlzz_owner_722(.a(32'(rtlzz_pipe_720_s7)), .b(32'(limb_55_721)), .cin(limb_55_719), .value(limb_55_722));
    assign limb_55_723 = limb_55_722[31:0]; // decl: <none>; prim: <none>
    assign limb_55_724 = limb_55_722[32]; // decl: <none>; prim: <none>
    assign limb_55_725 = limb_55_708[127:96]; // decl: <none>; prim: <none>
    assign limb_55_726 = limb_55_709[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_727Core rtlzz_owner_727(.a(32'(rtlzz_pipe_725_s7)), .b(32'(limb_55_726)), .cin(limb_55_724), .value(limb_55_727));
    assign limb_55_728 = limb_55_727[31:0]; // decl: <none>; prim: <none>
    assign limb_55_729 = limb_55_727[32]; // decl: <none>; prim: <none>
    assign limb_55_730 = limb_55_708[128]; // decl: <none>; prim: <none>
    assign limb_55_731 = limb_55_709[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_732Core rtlzz_owner_732(.a(1'(rtlzz_pipe_730_s7)), .b(1'(limb_55_731)), .cin(limb_55_729), .value(limb_55_732[0:0]));
    assign limb_55_732[1:1] = '0;
    assign limb_55_733 = limb_55_732[0]; // decl: <none>; prim: <none>
    assign limb_55_734 = {limb_55_733, limb_55_728, limb_55_723, limb_55_718, limb_55_713}; // decl: <none>; prim: <none>
    assign limb_56_735 = ({1'h0, s8_norm_mul_58_v0}); // decl: <none>; prim: <none>
    assign limb_56_736 = ({1'h0, s8_norm_mul_62_v0}); // decl: <none>; prim: <none>
    assign limb_56_737 = limb_56_735[31:0]; // decl: <none>; prim: <none>
    assign limb_56_738 = limb_56_736[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_739Core rtlzz_owner_739(.a(32'(rtlzz_pipe_737_s4)), .b(32'(limb_56_738)), .cin(1'h0), .value(limb_56_739));
    assign limb_56_740 = limb_56_739[31:0]; // decl: <none>; prim: <none>
    assign limb_56_741 = limb_56_739[32]; // decl: <none>; prim: <none>
    assign limb_56_742 = limb_56_735[63:32]; // decl: <none>; prim: <none>
    assign limb_56_743 = limb_56_736[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_744Core rtlzz_owner_744(.a(32'(rtlzz_pipe_742_s5)), .b(32'(rtlzz_pipe_743_s5)), .cin(rtlzz_pipe_741_s5), .value(limb_56_744));
    assign limb_56_745 = limb_56_744[31:0]; // decl: <none>; prim: <none>
    assign limb_56_746 = limb_56_744[32]; // decl: <none>; prim: <none>
    assign limb_56_747 = limb_56_735[95:64]; // decl: <none>; prim: <none>
    assign limb_56_748 = limb_56_736[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_749Core rtlzz_owner_749(.a(32'(rtlzz_pipe_747_s6)), .b(32'(rtlzz_pipe_748_s6)), .cin(rtlzz_pipe_746_s6), .value(limb_56_749));
    assign limb_56_750 = limb_56_749[31:0]; // decl: <none>; prim: <none>
    assign limb_56_751 = limb_56_749[32]; // decl: <none>; prim: <none>
    assign limb_56_752 = limb_56_735[127:96]; // decl: <none>; prim: <none>
    assign limb_56_753 = limb_56_736[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_754Core rtlzz_owner_754(.a(32'(rtlzz_pipe_752_s6)), .b(32'(rtlzz_pipe_753_s6)), .cin(limb_56_751), .value(limb_56_754));
    assign limb_56_755 = limb_56_754[31:0]; // decl: <none>; prim: <none>
    assign limb_56_756 = limb_56_754[32]; // decl: <none>; prim: <none>
    assign limb_56_757 = limb_56_735[128]; // decl: <none>; prim: <none>
    assign limb_56_758 = limb_56_736[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_759Core rtlzz_owner_759(.a(1'(rtlzz_pipe_757_s6)), .b(1'(rtlzz_pipe_758_s6)), .cin(limb_56_756), .value(limb_56_759[0:0]));
    assign limb_56_759[1:1] = '0;
    assign limb_56_760 = limb_56_759[0]; // decl: <none>; prim: <none>
    assign limb_56_761 = {limb_56_760, limb_56_755, limb_56_750, rtlzz_pipe_745_s6, rtlzz_pipe_740_s6}; // decl: <none>; prim: <none>
    assign limb_57_762 = ({1'h0, s8_norm_add_64_v0}); // decl: <none>; prim: <none>
    assign limb_57_763 = ({1'h0, s8_norm_add_65_v0}); // decl: <none>; prim: <none>
    assign limb_57_764 = limb_57_762[31:0]; // decl: <none>; prim: <none>
    assign limb_57_765 = limb_57_763[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_766Core rtlzz_owner_766(.a(32'(rtlzz_pipe_764_s7)), .b(32'(limb_57_765)), .cin(1'h0), .value(limb_57_766));
    assign limb_57_767 = limb_57_766[31:0]; // decl: <none>; prim: <none>
    assign limb_57_768 = limb_57_766[32]; // decl: <none>; prim: <none>
    assign limb_57_769 = limb_57_762[63:32]; // decl: <none>; prim: <none>
    assign limb_57_770 = limb_57_763[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_771Core rtlzz_owner_771(.a(32'(rtlzz_pipe_769_s7)), .b(32'(limb_57_770)), .cin(limb_57_768), .value(limb_57_771));
    assign limb_57_772 = limb_57_771[31:0]; // decl: <none>; prim: <none>
    assign limb_57_773 = limb_57_771[32]; // decl: <none>; prim: <none>
    assign limb_57_774 = limb_57_762[95:64]; // decl: <none>; prim: <none>
    assign limb_57_775 = limb_57_763[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_776Core rtlzz_owner_776(.a(32'(rtlzz_pipe_774_s7)), .b(32'(limb_57_775)), .cin(limb_57_773), .value(limb_57_776));
    assign limb_57_777 = limb_57_776[31:0]; // decl: <none>; prim: <none>
    assign limb_57_778 = limb_57_776[32]; // decl: <none>; prim: <none>
    assign limb_57_779 = limb_57_762[127:96]; // decl: <none>; prim: <none>
    assign limb_57_780 = limb_57_763[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_781Core rtlzz_owner_781(.a(32'(rtlzz_pipe_779_s7)), .b(32'(limb_57_780)), .cin(limb_57_778), .value(limb_57_781));
    assign limb_57_782 = limb_57_781[31:0]; // decl: <none>; prim: <none>
    assign limb_57_783 = limb_57_781[32]; // decl: <none>; prim: <none>
    assign limb_57_784 = limb_57_762[129:128]; // decl: <none>; prim: <none>
    assign limb_57_785 = limb_57_763[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_786Core rtlzz_owner_786(.a(2'(rtlzz_pipe_784_s7)), .b(2'(limb_57_785)), .cin(limb_57_783), .value(limb_57_786[1:0]));
    assign limb_57_786[2:2] = '0;
    assign limb_57_787 = limb_57_786[1:0]; // decl: <none>; prim: <none>
    assign limb_57_788 = {limb_57_787, limb_57_782, limb_57_777, limb_57_772, limb_57_767}; // decl: <none>; prim: <none>
    assign limb_58_789 = ({1'h0, s8_norm_add_66_v0}); // decl: <none>; prim: <none>
    assign limb_58_790 = ({1'h0, s8_norm_add_67_v0}); // decl: <none>; prim: <none>
    assign limb_58_791 = limb_58_789[31:0]; // decl: <none>; prim: <none>
    assign limb_58_792 = limb_58_790[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_793Core rtlzz_owner_793(.a(32'(limb_58_791)), .b(32'(rtlzz_pipe_792_s7)), .cin(1'h0), .value(limb_58_793));
    assign limb_58_794 = limb_58_793[31:0]; // decl: <none>; prim: <none>
    assign limb_58_795 = limb_58_793[32]; // decl: <none>; prim: <none>
    assign limb_58_796 = limb_58_789[63:32]; // decl: <none>; prim: <none>
    assign limb_58_797 = limb_58_790[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_798Core rtlzz_owner_798(.a(32'(limb_58_796)), .b(32'(rtlzz_pipe_797_s7)), .cin(limb_58_795), .value(limb_58_798));
    assign limb_58_799 = limb_58_798[31:0]; // decl: <none>; prim: <none>
    assign limb_58_800 = limb_58_798[32]; // decl: <none>; prim: <none>
    assign limb_58_801 = limb_58_789[95:64]; // decl: <none>; prim: <none>
    assign limb_58_802 = limb_58_790[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_803Core rtlzz_owner_803(.a(32'(limb_58_801)), .b(32'(rtlzz_pipe_802_s7)), .cin(limb_58_800), .value(limb_58_803));
    assign limb_58_804 = limb_58_803[31:0]; // decl: <none>; prim: <none>
    assign limb_58_805 = limb_58_803[32]; // decl: <none>; prim: <none>
    assign limb_58_806 = limb_58_789[127:96]; // decl: <none>; prim: <none>
    assign limb_58_807 = limb_58_790[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_808Core rtlzz_owner_808(.a(32'(limb_58_806)), .b(32'(rtlzz_pipe_807_s7)), .cin(limb_58_805), .value(limb_58_808));
    assign limb_58_809 = limb_58_808[31:0]; // decl: <none>; prim: <none>
    assign limb_58_810 = limb_58_808[32]; // decl: <none>; prim: <none>
    assign limb_58_811 = limb_58_789[129:128]; // decl: <none>; prim: <none>
    assign limb_58_812 = limb_58_790[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_813Core rtlzz_owner_813(.a(2'(limb_58_811)), .b(2'(rtlzz_pipe_812_s7)), .cin(limb_58_810), .value(limb_58_813[1:0]));
    assign limb_58_813[2:2] = '0;
    assign limb_58_814 = limb_58_813[1:0]; // decl: <none>; prim: <none>
    assign limb_58_815 = {limb_58_814, limb_58_809, limb_58_804, limb_58_799, limb_58_794}; // decl: <none>; prim: <none>
    assign limb_59_816 = ({1'h0, s8_norm_add_68_v0}); // decl: <none>; prim: <none>
    assign limb_59_817 = ({1'h0, s8_norm_add_69_v0}); // decl: <none>; prim: <none>
    assign limb_59_818 = limb_59_816[31:0]; // decl: <none>; prim: <none>
    assign limb_59_819 = limb_59_817[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_820Core rtlzz_owner_820(.a(32'(limb_59_818)), .b(32'(rtlzz_pipe_819_s7)), .cin(1'h0), .value(limb_59_820));
    assign limb_59_821 = limb_59_820[31:0]; // decl: <none>; prim: <none>
    assign limb_59_822 = limb_59_820[32]; // decl: <none>; prim: <none>
    assign limb_59_823 = limb_59_816[63:32]; // decl: <none>; prim: <none>
    assign limb_59_824 = limb_59_817[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_825Core rtlzz_owner_825(.a(32'(limb_59_823)), .b(32'(rtlzz_pipe_824_s7)), .cin(limb_59_822), .value(limb_59_825));
    assign limb_59_826 = limb_59_825[31:0]; // decl: <none>; prim: <none>
    assign limb_59_827 = limb_59_825[32]; // decl: <none>; prim: <none>
    assign limb_59_828 = limb_59_816[95:64]; // decl: <none>; prim: <none>
    assign limb_59_829 = limb_59_817[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_830Core rtlzz_owner_830(.a(32'(limb_59_828)), .b(32'(rtlzz_pipe_829_s7)), .cin(limb_59_827), .value(limb_59_830));
    assign limb_59_831 = limb_59_830[31:0]; // decl: <none>; prim: <none>
    assign limb_59_832 = limb_59_830[32]; // decl: <none>; prim: <none>
    assign limb_59_833 = limb_59_816[127:96]; // decl: <none>; prim: <none>
    assign limb_59_834 = limb_59_817[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_835Core rtlzz_owner_835(.a(32'(limb_59_833)), .b(32'(rtlzz_pipe_834_s7)), .cin(limb_59_832), .value(limb_59_835));
    assign limb_59_836 = limb_59_835[31:0]; // decl: <none>; prim: <none>
    assign limb_59_837 = limb_59_835[32]; // decl: <none>; prim: <none>
    assign limb_59_838 = limb_59_816[129:128]; // decl: <none>; prim: <none>
    assign limb_59_839 = limb_59_817[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_840Core rtlzz_owner_840(.a(2'(limb_59_838)), .b(2'(rtlzz_pipe_839_s7)), .cin(limb_59_837), .value(limb_59_840[1:0]));
    assign limb_59_840[2:2] = '0;
    assign limb_59_841 = limb_59_840[1:0]; // decl: <none>; prim: <none>
    assign limb_59_842 = {limb_59_841, limb_59_836, limb_59_831, limb_59_826, limb_59_821}; // decl: <none>; prim: <none>
    assign limb_60_843 = ({1'h0, s8_norm_add_70_v0}); // decl: <none>; prim: <none>
    assign limb_60_844 = ({1'h0, s8_norm_add_71_v0}); // decl: <none>; prim: <none>
    assign limb_60_845 = limb_60_843[31:0]; // decl: <none>; prim: <none>
    assign limb_60_846 = limb_60_844[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_847Core rtlzz_owner_847(.a(32'(limb_60_845)), .b(32'(rtlzz_pipe_846_s7)), .cin(1'h0), .value(limb_60_847));
    assign limb_60_848 = limb_60_847[31:0]; // decl: <none>; prim: <none>
    assign limb_60_849 = limb_60_847[32]; // decl: <none>; prim: <none>
    assign limb_60_850 = limb_60_843[63:32]; // decl: <none>; prim: <none>
    assign limb_60_851 = limb_60_844[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_852Core rtlzz_owner_852(.a(32'(limb_60_850)), .b(32'(rtlzz_pipe_851_s7)), .cin(limb_60_849), .value(limb_60_852));
    assign limb_60_853 = limb_60_852[31:0]; // decl: <none>; prim: <none>
    assign limb_60_854 = limb_60_852[32]; // decl: <none>; prim: <none>
    assign limb_60_855 = limb_60_843[95:64]; // decl: <none>; prim: <none>
    assign limb_60_856 = limb_60_844[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_857Core rtlzz_owner_857(.a(32'(limb_60_855)), .b(32'(rtlzz_pipe_856_s7)), .cin(limb_60_854), .value(limb_60_857));
    assign limb_60_858 = limb_60_857[31:0]; // decl: <none>; prim: <none>
    assign limb_60_859 = limb_60_857[32]; // decl: <none>; prim: <none>
    assign limb_60_860 = limb_60_843[127:96]; // decl: <none>; prim: <none>
    assign limb_60_861 = limb_60_844[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_862Core rtlzz_owner_862(.a(32'(limb_60_860)), .b(32'(rtlzz_pipe_861_s7)), .cin(limb_60_859), .value(limb_60_862));
    assign limb_60_863 = limb_60_862[31:0]; // decl: <none>; prim: <none>
    assign limb_60_864 = limb_60_862[32]; // decl: <none>; prim: <none>
    assign limb_60_865 = limb_60_843[129:128]; // decl: <none>; prim: <none>
    assign limb_60_866 = limb_60_844[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_867Core rtlzz_owner_867(.a(2'(limb_60_865)), .b(2'(rtlzz_pipe_866_s7)), .cin(limb_60_864), .value(limb_60_867[1:0]));
    assign limb_60_867[2:2] = '0;
    assign limb_60_868 = limb_60_867[1:0]; // decl: <none>; prim: <none>
    assign limb_60_869 = {limb_60_868, limb_60_863, limb_60_858, limb_60_853, limb_60_848}; // decl: <none>; prim: <none>
    assign limb_61_870 = ({1'h0, s8_norm_add_72_v0}); // decl: <none>; prim: <none>
    assign limb_61_871 = ({1'h0, s8_norm_add_73_v0}); // decl: <none>; prim: <none>
    assign limb_61_872 = limb_61_870[31:0]; // decl: <none>; prim: <none>
    assign limb_61_873 = limb_61_871[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_874Core rtlzz_owner_874(.a(32'(limb_61_872)), .b(32'(limb_61_873)), .cin(1'h0), .value(limb_61_874));
    assign limb_61_875 = limb_61_874[31:0]; // decl: <none>; prim: <none>
    assign limb_61_876 = limb_61_874[32]; // decl: <none>; prim: <none>
    assign limb_61_877 = limb_61_870[63:32]; // decl: <none>; prim: <none>
    assign limb_61_878 = limb_61_871[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_879Core rtlzz_owner_879(.a(32'(limb_61_877)), .b(32'(limb_61_878)), .cin(limb_61_876), .value(limb_61_879));
    assign limb_61_880 = limb_61_879[31:0]; // decl: <none>; prim: <none>
    assign limb_61_881 = limb_61_879[32]; // decl: <none>; prim: <none>
    assign limb_61_882 = limb_61_870[95:64]; // decl: <none>; prim: <none>
    assign limb_61_883 = limb_61_871[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_884Core rtlzz_owner_884(.a(32'(limb_61_882)), .b(32'(limb_61_883)), .cin(limb_61_881), .value(limb_61_884));
    assign limb_61_885 = limb_61_884[31:0]; // decl: <none>; prim: <none>
    assign limb_61_886 = limb_61_884[32]; // decl: <none>; prim: <none>
    assign limb_61_887 = limb_61_870[127:96]; // decl: <none>; prim: <none>
    assign limb_61_888 = limb_61_871[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_889Core rtlzz_owner_889(.a(32'(limb_61_887)), .b(32'(limb_61_888)), .cin(limb_61_886), .value(limb_61_889));
    assign limb_61_890 = limb_61_889[31:0]; // decl: <none>; prim: <none>
    assign limb_61_891 = limb_61_889[32]; // decl: <none>; prim: <none>
    assign limb_61_892 = limb_61_870[130:128]; // decl: <none>; prim: <none>
    assign limb_61_893 = limb_61_871[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_894Core rtlzz_owner_894(.a(3'(limb_61_892)), .b(3'(limb_61_893)), .cin(limb_61_891), .value(limb_61_894[2:0]));
    assign limb_61_894[3:3] = '0;
    assign limb_61_895 = limb_61_894[2:0]; // decl: <none>; prim: <none>
    assign limb_61_896 = {limb_61_895, limb_61_890, limb_61_885, limb_61_880, limb_61_875}; // decl: <none>; prim: <none>
    assign limb_62_897 = ({1'h0, s8_norm_add_74_v0}); // decl: <none>; prim: <none>
    assign limb_62_898 = ({1'h0, s8_norm_add_75_v0}); // decl: <none>; prim: <none>
    assign limb_62_899 = limb_62_897[31:0]; // decl: <none>; prim: <none>
    assign limb_62_900 = limb_62_898[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_901Core rtlzz_owner_901(.a(32'(limb_62_899)), .b(32'(limb_62_900)), .cin(1'h0), .value(limb_62_901));
    assign limb_62_902 = limb_62_901[31:0]; // decl: <none>; prim: <none>
    assign limb_62_903 = limb_62_901[32]; // decl: <none>; prim: <none>
    assign limb_62_904 = limb_62_897[63:32]; // decl: <none>; prim: <none>
    assign limb_62_905 = limb_62_898[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_906Core rtlzz_owner_906(.a(32'(limb_62_904)), .b(32'(limb_62_905)), .cin(limb_62_903), .value(limb_62_906));
    assign limb_62_907 = limb_62_906[31:0]; // decl: <none>; prim: <none>
    assign limb_62_908 = limb_62_906[32]; // decl: <none>; prim: <none>
    assign limb_62_909 = limb_62_897[95:64]; // decl: <none>; prim: <none>
    assign limb_62_910 = limb_62_898[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_911Core rtlzz_owner_911(.a(32'(limb_62_909)), .b(32'(limb_62_910)), .cin(limb_62_908), .value(limb_62_911));
    assign limb_62_912 = limb_62_911[31:0]; // decl: <none>; prim: <none>
    assign limb_62_913 = limb_62_911[32]; // decl: <none>; prim: <none>
    assign limb_62_914 = limb_62_897[127:96]; // decl: <none>; prim: <none>
    assign limb_62_915 = limb_62_898[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_916Core rtlzz_owner_916(.a(32'(limb_62_914)), .b(32'(limb_62_915)), .cin(limb_62_913), .value(limb_62_916));
    assign limb_62_917 = limb_62_916[31:0]; // decl: <none>; prim: <none>
    assign limb_62_918 = limb_62_916[32]; // decl: <none>; prim: <none>
    assign limb_62_919 = limb_62_897[130:128]; // decl: <none>; prim: <none>
    assign limb_62_920 = limb_62_898[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_921Core rtlzz_owner_921(.a(3'(limb_62_919)), .b(3'(limb_62_920)), .cin(limb_62_918), .value(limb_62_921[2:0]));
    assign limb_62_921[3:3] = '0;
    assign limb_62_922 = limb_62_921[2:0]; // decl: <none>; prim: <none>
    assign limb_62_923 = {limb_62_922, limb_62_917, limb_62_912, limb_62_907, limb_62_902}; // decl: <none>; prim: <none>
    assign limb_63_924 = ({1'h0, s8_norm_add_76_v0}); // decl: <none>; prim: <none>
    assign limb_63_925 = ({1'h0, s8_norm_add_77_v0}); // decl: <none>; prim: <none>
    assign limb_63_926 = limb_63_924[31:0]; // decl: <none>; prim: <none>
    assign limb_63_927 = limb_63_925[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_928Core rtlzz_owner_928(.a(32'(limb_63_926)), .b(32'(limb_63_927)), .cin(1'h0), .value(limb_63_928));
    assign limb_63_929 = limb_63_928[31:0]; // decl: <none>; prim: <none>
    assign limb_63_930 = limb_63_928[32]; // decl: <none>; prim: <none>
    assign limb_63_931 = limb_63_924[63:32]; // decl: <none>; prim: <none>
    assign limb_63_932 = limb_63_925[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_933Core rtlzz_owner_933(.a(32'(limb_63_931)), .b(32'(limb_63_932)), .cin(limb_63_930), .value(limb_63_933));
    assign limb_63_934 = limb_63_933[31:0]; // decl: <none>; prim: <none>
    assign limb_63_935 = limb_63_933[32]; // decl: <none>; prim: <none>
    assign limb_63_936 = limb_63_924[95:64]; // decl: <none>; prim: <none>
    assign limb_63_937 = limb_63_925[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_938Core rtlzz_owner_938(.a(32'(limb_63_936)), .b(32'(limb_63_937)), .cin(limb_63_935), .value(limb_63_938));
    assign limb_63_939 = limb_63_938[31:0]; // decl: <none>; prim: <none>
    assign limb_63_940 = limb_63_938[32]; // decl: <none>; prim: <none>
    assign limb_63_941 = limb_63_924[127:96]; // decl: <none>; prim: <none>
    assign limb_63_942 = limb_63_925[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_943Core rtlzz_owner_943(.a(32'(limb_63_941)), .b(32'(limb_63_942)), .cin(limb_63_940), .value(limb_63_943));
    assign limb_63_944 = limb_63_943[31:0]; // decl: <none>; prim: <none>
    assign limb_63_945 = limb_63_943[32]; // decl: <none>; prim: <none>
    assign limb_63_946 = limb_63_924[131:128]; // decl: <none>; prim: <none>
    assign limb_63_947 = limb_63_925[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_948Core rtlzz_owner_948(.a(4'(limb_63_946)), .b(4'(limb_63_947)), .cin(limb_63_945), .value(limb_63_948[3:0]));
    assign limb_63_948[4:4] = '0;
    assign limb_63_949 = limb_63_948[3:0]; // decl: <none>; prim: <none>
    assign limb_63_950 = {limb_63_949, limb_63_944, limb_63_939, limb_63_934, limb_63_929}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_100_s2 <= 64'h0;
            rtlzz_pipe_100_s3 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_101_s2 <= 64'h0;
            rtlzz_pipe_101_s3 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_102_s3 <= 64'h0;
            rtlzz_pipe_102_s4 <= 64'h0;
            rtlzz_pipe_102_s5 <= 64'h0;
            rtlzz_pipe_102_s6 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_103_s3 <= 64'h0;
            rtlzz_pipe_103_s4 <= 64'h0;
            rtlzz_pipe_103_s5 <= 64'h0;
            rtlzz_pipe_103_s6 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_108_s1 <= 64'h0;
            rtlzz_pipe_108_s2 <= 64'h0;
            rtlzz_pipe_108_s3 <= 64'h0;
            rtlzz_pipe_108_s4 <= 64'h0;
            rtlzz_pipe_108_s5 <= 64'h0;
            rtlzz_pipe_109_s1 <= 64'h0;
            rtlzz_pipe_109_s2 <= 64'h0;
            rtlzz_pipe_109_s3 <= 64'h0;
            rtlzz_pipe_109_s4 <= 64'h0;
            rtlzz_pipe_109_s5 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_112_s3 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_113_s3 <= 64'h0;
            rtlzz_pipe_114_s1 <= 64'h0;
            rtlzz_pipe_114_s2 <= 64'h0;
            rtlzz_pipe_114_s3 <= 64'h0;
            rtlzz_pipe_114_s4 <= 64'h0;
            rtlzz_pipe_114_s5 <= 64'h0;
            rtlzz_pipe_114_s6 <= 64'h0;
            rtlzz_pipe_115_s1 <= 64'h0;
            rtlzz_pipe_115_s2 <= 64'h0;
            rtlzz_pipe_115_s3 <= 64'h0;
            rtlzz_pipe_115_s4 <= 64'h0;
            rtlzz_pipe_115_s5 <= 64'h0;
            rtlzz_pipe_115_s6 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_118_s2 <= 64'h0;
            rtlzz_pipe_118_s3 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_119_s2 <= 64'h0;
            rtlzz_pipe_119_s3 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_122_s4 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_123_s4 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_124_s6 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_125_s6 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_128_s2 <= 64'h0;
            rtlzz_pipe_128_s3 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_129_s2 <= 64'h0;
            rtlzz_pipe_129_s3 <= 64'h0;
            rtlzz_pipe_148_s1 <= 64'h0;
            rtlzz_pipe_152_s1 <= 96'h0;
            rtlzz_pipe_156_s1 <= 96'h0;
            rtlzz_pipe_160_s1 <= 128'h0;
            rtlzz_pipe_163_s2 <= 97'h0;
            rtlzz_pipe_166_s2 <= 129'h0;
            rtlzz_pipe_173_s4 <= 64'h0;
            rtlzz_pipe_177_s4 <= 96'h0;
            rtlzz_pipe_181_s4 <= 96'h0;
            rtlzz_pipe_185_s4 <= 128'h0;
            rtlzz_pipe_188_s5 <= 97'h0;
            rtlzz_pipe_191_s5 <= 129'h0;
            rtlzz_pipe_213_s7 <= 97'h0;
            rtlzz_pipe_216_s7 <= 129'h0;
            rtlzz_pipe_223_s1 <= 64'h0;
            rtlzz_pipe_227_s1 <= 96'h0;
            rtlzz_pipe_231_s1 <= 96'h0;
            rtlzz_pipe_235_s1 <= 128'h0;
            rtlzz_pipe_238_s2 <= 97'h0;
            rtlzz_pipe_241_s2 <= 129'h0;
            rtlzz_pipe_248_s4 <= 64'h0;
            rtlzz_pipe_252_s4 <= 96'h0;
            rtlzz_pipe_256_s4 <= 96'h0;
            rtlzz_pipe_260_s4 <= 128'h0;
            rtlzz_pipe_273_s6 <= 64'h0;
            rtlzz_pipe_273_s7 <= 64'h0;
            rtlzz_pipe_277_s6 <= 96'h0;
            rtlzz_pipe_277_s7 <= 96'h0;
            rtlzz_pipe_281_s6 <= 96'h0;
            rtlzz_pipe_281_s7 <= 96'h0;
            rtlzz_pipe_285_s6 <= 128'h0;
            rtlzz_pipe_285_s7 <= 128'h0;
            rtlzz_pipe_298_s1 <= 64'h0;
            rtlzz_pipe_302_s1 <= 96'h0;
            rtlzz_pipe_306_s1 <= 96'h0;
            rtlzz_pipe_310_s1 <= 128'h0;
            rtlzz_pipe_313_s2 <= 97'h0;
            rtlzz_pipe_316_s2 <= 129'h0;
            rtlzz_pipe_323_s4 <= 64'h0;
            rtlzz_pipe_323_s5 <= 64'h0;
            rtlzz_pipe_327_s4 <= 96'h0;
            rtlzz_pipe_327_s5 <= 96'h0;
            rtlzz_pipe_331_s4 <= 96'h0;
            rtlzz_pipe_331_s5 <= 96'h0;
            rtlzz_pipe_335_s4 <= 128'h0;
            rtlzz_pipe_335_s5 <= 128'h0;
            rtlzz_pipe_363_s7 <= 97'h0;
            rtlzz_pipe_366_s7 <= 129'h0;
            rtlzz_pipe_373_s1 <= 64'h0;
            rtlzz_pipe_377_s1 <= 96'h0;
            rtlzz_pipe_381_s1 <= 96'h0;
            rtlzz_pipe_385_s1 <= 128'h0;
            rtlzz_pipe_388_s2 <= 97'h0;
            rtlzz_pipe_391_s2 <= 129'h0;
            rtlzz_pipe_413_s4 <= 97'h0;
            rtlzz_pipe_416_s4 <= 129'h0;
            rtlzz_pipe_423_s1 <= 64'h0;
            rtlzz_pipe_427_s1 <= 96'h0;
            rtlzz_pipe_431_s1 <= 96'h0;
            rtlzz_pipe_435_s1 <= 128'h0;
            rtlzz_pipe_438_s2 <= 97'h0;
            rtlzz_pipe_441_s2 <= 129'h0;
            rtlzz_pipe_448_s5 <= 64'h0;
            rtlzz_pipe_452_s5 <= 96'h0;
            rtlzz_pipe_456_s5 <= 96'h0;
            rtlzz_pipe_460_s5 <= 128'h0;
            rtlzz_pipe_473_s7 <= 64'h0;
            rtlzz_pipe_477_s7 <= 96'h0;
            rtlzz_pipe_481_s7 <= 96'h0;
            rtlzz_pipe_485_s7 <= 128'h0;
            rtlzz_pipe_498_s1 <= 64'h0;
            rtlzz_pipe_502_s1 <= 96'h0;
            rtlzz_pipe_506_s1 <= 96'h0;
            rtlzz_pipe_510_s1 <= 128'h0;
            rtlzz_pipe_513_s2 <= 97'h0;
            rtlzz_pipe_516_s2 <= 129'h0;
            rtlzz_pipe_523_s4 <= 64'h0;
            rtlzz_pipe_527_s4 <= 96'h0;
            rtlzz_pipe_531_s4 <= 96'h0;
            rtlzz_pipe_535_s4 <= 128'h0;
            rtlzz_pipe_548_s3 <= 32'h0;
            rtlzz_pipe_548_s4 <= 32'h0;
            rtlzz_pipe_548_s5 <= 32'h0;
            rtlzz_pipe_548_s6 <= 32'h0;
            rtlzz_pipe_549_s6 <= 32'h0;
            rtlzz_pipe_553_s3 <= 32'h0;
            rtlzz_pipe_553_s4 <= 32'h0;
            rtlzz_pipe_553_s5 <= 32'h0;
            rtlzz_pipe_553_s6 <= 32'h0;
            rtlzz_pipe_554_s6 <= 32'h0;
            rtlzz_pipe_558_s3 <= 32'h0;
            rtlzz_pipe_558_s4 <= 32'h0;
            rtlzz_pipe_558_s5 <= 32'h0;
            rtlzz_pipe_558_s6 <= 32'h0;
            rtlzz_pipe_559_s6 <= 32'h0;
            rtlzz_pipe_563_s3 <= 32'h0;
            rtlzz_pipe_563_s4 <= 32'h0;
            rtlzz_pipe_563_s5 <= 32'h0;
            rtlzz_pipe_563_s6 <= 32'h0;
            rtlzz_pipe_564_s6 <= 32'h0;
            rtlzz_pipe_568_s3 <= 1'h0;
            rtlzz_pipe_568_s4 <= 1'h0;
            rtlzz_pipe_568_s5 <= 1'h0;
            rtlzz_pipe_568_s6 <= 1'h0;
            rtlzz_pipe_569_s6 <= 1'h0;
            rtlzz_pipe_576_s3 <= 32'h0;
            rtlzz_pipe_576_s4 <= 32'h0;
            rtlzz_pipe_576_s5 <= 32'h0;
            rtlzz_pipe_576_s6 <= 32'h0;
            rtlzz_pipe_576_s7 <= 32'h0;
            rtlzz_pipe_581_s3 <= 32'h0;
            rtlzz_pipe_581_s4 <= 32'h0;
            rtlzz_pipe_581_s5 <= 32'h0;
            rtlzz_pipe_581_s6 <= 32'h0;
            rtlzz_pipe_581_s7 <= 32'h0;
            rtlzz_pipe_586_s3 <= 32'h0;
            rtlzz_pipe_586_s4 <= 32'h0;
            rtlzz_pipe_586_s5 <= 32'h0;
            rtlzz_pipe_586_s6 <= 32'h0;
            rtlzz_pipe_586_s7 <= 32'h0;
            rtlzz_pipe_591_s3 <= 32'h0;
            rtlzz_pipe_591_s4 <= 32'h0;
            rtlzz_pipe_591_s5 <= 32'h0;
            rtlzz_pipe_591_s6 <= 32'h0;
            rtlzz_pipe_591_s7 <= 32'h0;
            rtlzz_pipe_596_s3 <= 1'h0;
            rtlzz_pipe_596_s4 <= 1'h0;
            rtlzz_pipe_596_s5 <= 1'h0;
            rtlzz_pipe_596_s6 <= 1'h0;
            rtlzz_pipe_596_s7 <= 1'h0;
            rtlzz_pipe_602_s5 <= 32'h0;
            rtlzz_pipe_602_s6 <= 32'h0;
            rtlzz_pipe_602_s7 <= 32'h0;
            rtlzz_pipe_607_s5 <= 32'h0;
            rtlzz_pipe_607_s6 <= 32'h0;
            rtlzz_pipe_607_s7 <= 32'h0;
            rtlzz_pipe_612_s5 <= 32'h0;
            rtlzz_pipe_612_s6 <= 32'h0;
            rtlzz_pipe_612_s7 <= 32'h0;
            rtlzz_pipe_617_s5 <= 32'h0;
            rtlzz_pipe_617_s6 <= 32'h0;
            rtlzz_pipe_617_s7 <= 32'h0;
            rtlzz_pipe_622_s5 <= 1'h0;
            rtlzz_pipe_622_s6 <= 1'h0;
            rtlzz_pipe_622_s7 <= 1'h0;
            rtlzz_pipe_629_s3 <= 32'h0;
            rtlzz_pipe_629_s4 <= 32'h0;
            rtlzz_pipe_629_s5 <= 32'h0;
            rtlzz_pipe_634_s3 <= 32'h0;
            rtlzz_pipe_634_s4 <= 32'h0;
            rtlzz_pipe_634_s5 <= 32'h0;
            rtlzz_pipe_639_s3 <= 32'h0;
            rtlzz_pipe_639_s4 <= 32'h0;
            rtlzz_pipe_639_s5 <= 32'h0;
            rtlzz_pipe_644_s3 <= 32'h0;
            rtlzz_pipe_644_s4 <= 32'h0;
            rtlzz_pipe_644_s5 <= 32'h0;
            rtlzz_pipe_649_s3 <= 1'h0;
            rtlzz_pipe_649_s4 <= 1'h0;
            rtlzz_pipe_649_s5 <= 1'h0;
            rtlzz_pipe_657_s3 <= 32'h0;
            rtlzz_pipe_657_s4 <= 32'h0;
            rtlzz_pipe_657_s5 <= 32'h0;
            rtlzz_pipe_657_s6 <= 32'h0;
            rtlzz_pipe_657_s7 <= 32'h0;
            rtlzz_pipe_662_s3 <= 32'h0;
            rtlzz_pipe_662_s4 <= 32'h0;
            rtlzz_pipe_662_s5 <= 32'h0;
            rtlzz_pipe_662_s6 <= 32'h0;
            rtlzz_pipe_662_s7 <= 32'h0;
            rtlzz_pipe_667_s3 <= 32'h0;
            rtlzz_pipe_667_s4 <= 32'h0;
            rtlzz_pipe_667_s5 <= 32'h0;
            rtlzz_pipe_667_s6 <= 32'h0;
            rtlzz_pipe_667_s7 <= 32'h0;
            rtlzz_pipe_672_s3 <= 32'h0;
            rtlzz_pipe_672_s4 <= 32'h0;
            rtlzz_pipe_672_s5 <= 32'h0;
            rtlzz_pipe_672_s6 <= 32'h0;
            rtlzz_pipe_672_s7 <= 32'h0;
            rtlzz_pipe_677_s3 <= 1'h0;
            rtlzz_pipe_677_s4 <= 1'h0;
            rtlzz_pipe_677_s5 <= 1'h0;
            rtlzz_pipe_677_s6 <= 1'h0;
            rtlzz_pipe_677_s7 <= 1'h0;
            rtlzz_pipe_684_s3 <= 32'h0;
            rtlzz_pipe_684_s4 <= 32'h0;
            rtlzz_pipe_686_s5 <= 32'h0;
            rtlzz_pipe_686_s6 <= 32'h0;
            rtlzz_pipe_689_s3 <= 32'h0;
            rtlzz_pipe_689_s4 <= 32'h0;
            rtlzz_pipe_691_s5 <= 32'h0;
            rtlzz_pipe_691_s6 <= 32'h0;
            rtlzz_pipe_694_s3 <= 32'h0;
            rtlzz_pipe_694_s4 <= 32'h0;
            rtlzz_pipe_696_s5 <= 32'h0;
            rtlzz_pipe_696_s6 <= 32'h0;
            rtlzz_pipe_699_s3 <= 32'h0;
            rtlzz_pipe_699_s4 <= 32'h0;
            rtlzz_pipe_701_s5 <= 32'h0;
            rtlzz_pipe_701_s6 <= 32'h0;
            rtlzz_pipe_702_s5 <= 1'h0;
            rtlzz_pipe_702_s6 <= 1'h0;
            rtlzz_pipe_703_s5 <= 1'h0;
            rtlzz_pipe_703_s6 <= 1'h0;
            rtlzz_pipe_704_s3 <= 1'h0;
            rtlzz_pipe_704_s4 <= 1'h0;
            rtlzz_pipe_704_s5 <= 1'h0;
            rtlzz_pipe_704_s6 <= 1'h0;
            rtlzz_pipe_710_s6 <= 32'h0;
            rtlzz_pipe_710_s7 <= 32'h0;
            rtlzz_pipe_715_s6 <= 32'h0;
            rtlzz_pipe_715_s7 <= 32'h0;
            rtlzz_pipe_720_s6 <= 32'h0;
            rtlzz_pipe_720_s7 <= 32'h0;
            rtlzz_pipe_725_s6 <= 32'h0;
            rtlzz_pipe_725_s7 <= 32'h0;
            rtlzz_pipe_730_s6 <= 1'h0;
            rtlzz_pipe_730_s7 <= 1'h0;
            rtlzz_pipe_737_s3 <= 32'h0;
            rtlzz_pipe_737_s4 <= 32'h0;
            rtlzz_pipe_740_s5 <= 32'h0;
            rtlzz_pipe_740_s6 <= 32'h0;
            rtlzz_pipe_741_s5 <= 1'h0;
            rtlzz_pipe_742_s3 <= 32'h0;
            rtlzz_pipe_742_s4 <= 32'h0;
            rtlzz_pipe_742_s5 <= 32'h0;
            rtlzz_pipe_743_s5 <= 32'h0;
            rtlzz_pipe_745_s6 <= 32'h0;
            rtlzz_pipe_746_s6 <= 1'h0;
            rtlzz_pipe_747_s3 <= 32'h0;
            rtlzz_pipe_747_s4 <= 32'h0;
            rtlzz_pipe_747_s5 <= 32'h0;
            rtlzz_pipe_747_s6 <= 32'h0;
            rtlzz_pipe_748_s5 <= 32'h0;
            rtlzz_pipe_748_s6 <= 32'h0;
            rtlzz_pipe_752_s3 <= 32'h0;
            rtlzz_pipe_752_s4 <= 32'h0;
            rtlzz_pipe_752_s5 <= 32'h0;
            rtlzz_pipe_752_s6 <= 32'h0;
            rtlzz_pipe_753_s5 <= 32'h0;
            rtlzz_pipe_753_s6 <= 32'h0;
            rtlzz_pipe_757_s3 <= 1'h0;
            rtlzz_pipe_757_s4 <= 1'h0;
            rtlzz_pipe_757_s5 <= 1'h0;
            rtlzz_pipe_757_s6 <= 1'h0;
            rtlzz_pipe_758_s5 <= 1'h0;
            rtlzz_pipe_758_s6 <= 1'h0;
            rtlzz_pipe_764_s7 <= 32'h0;
            rtlzz_pipe_769_s7 <= 32'h0;
            rtlzz_pipe_774_s7 <= 32'h0;
            rtlzz_pipe_779_s7 <= 32'h0;
            rtlzz_pipe_784_s7 <= 2'h0;
            rtlzz_pipe_792_s6 <= 32'h0;
            rtlzz_pipe_792_s7 <= 32'h0;
            rtlzz_pipe_797_s6 <= 32'h0;
            rtlzz_pipe_797_s7 <= 32'h0;
            rtlzz_pipe_802_s6 <= 32'h0;
            rtlzz_pipe_802_s7 <= 32'h0;
            rtlzz_pipe_807_s6 <= 32'h0;
            rtlzz_pipe_807_s7 <= 32'h0;
            rtlzz_pipe_812_s6 <= 2'h0;
            rtlzz_pipe_812_s7 <= 2'h0;
            rtlzz_pipe_819_s7 <= 32'h0;
            rtlzz_pipe_824_s7 <= 32'h0;
            rtlzz_pipe_829_s7 <= 32'h0;
            rtlzz_pipe_834_s7 <= 32'h0;
            rtlzz_pipe_839_s7 <= 2'h0;
            rtlzz_pipe_846_s7 <= 32'h0;
            rtlzz_pipe_851_s7 <= 32'h0;
            rtlzz_pipe_856_s7 <= 32'h0;
            rtlzz_pipe_861_s7 <= 32'h0;
            rtlzz_pipe_866_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_100_s2 <= rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_101_s2 <= rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_101_s3 <= rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_102_s3 <= rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_102_s4 <= rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_102_s6 <= rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_103_s4 <= rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_103_s5 <= rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_108_s1 <= mul_precision_108; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_108_s2 <= rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_108_s3 <= rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_108_s4 <= rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_108_s5 <= rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_precision_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_109_s4 <= rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_109_s5 <= rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_113_s3 <= rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_114_s1 <= mul_precision_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_114_s3 <= rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_114_s4 <= rtlzz_pipe_114_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_114_s5 <= rtlzz_pipe_114_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_114_s6 <= rtlzz_pipe_114_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_115_s1 <= mul_precision_115; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_115_s3 <= rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_115_s4 <= rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_115_s5 <= rtlzz_pipe_115_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_115_s6 <= rtlzz_pipe_115_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_118_s2 <= rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_118_s3 <= rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_119_s2 <= rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_119_s3 <= rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_122_s4 <= rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_123_s4 <= rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_124_s6 <= rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_125_s6 <= rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_128_s2 <= rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_128_s3 <= rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_129_s2 <= rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_129_s3 <= rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_130_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= mul_tree_130_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= mul_tree_130_156; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_160_s1 <= mul_tree_130_160; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= mul_tree_130_163; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_166_s2 <= mul_tree_130_166; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_173_s4 <= mul_tree_131_173; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_177_s4 <= mul_tree_131_177; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_181_s4 <= mul_tree_131_181; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_185_s4 <= mul_tree_131_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_188_s5 <= mul_tree_131_188; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_191_s5 <= mul_tree_131_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_213_s7 <= mul_tree_132_213; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_216_s7 <= mul_tree_132_216; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_223_s1 <= mul_tree_133_223; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_227_s1 <= mul_tree_133_227; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_231_s1 <= mul_tree_133_231; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= mul_tree_133_235; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_238_s2 <= mul_tree_133_238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_241_s2 <= mul_tree_133_241; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_248_s4 <= mul_tree_134_248; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_252_s4 <= mul_tree_134_252; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_256_s4 <= mul_tree_134_256; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_260_s4 <= mul_tree_134_260; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_273_s6 <= mul_tree_135_273; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_273_s7 <= rtlzz_pipe_273_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_277_s6 <= mul_tree_135_277; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_277_s7 <= rtlzz_pipe_277_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_281_s6 <= mul_tree_135_281; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_281_s7 <= rtlzz_pipe_281_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_285_s6 <= mul_tree_135_285; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_285_s7 <= rtlzz_pipe_285_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_298_s1 <= mul_tree_136_298; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_302_s1 <= mul_tree_136_302; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_306_s1 <= mul_tree_136_306; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_310_s1 <= mul_tree_136_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_313_s2 <= mul_tree_136_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_316_s2 <= mul_tree_136_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_323_s4 <= mul_tree_137_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_323_s5 <= rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_327_s4 <= mul_tree_137_327; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_327_s5 <= rtlzz_pipe_327_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= mul_tree_137_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_331_s5 <= rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= mul_tree_137_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_335_s5 <= rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_363_s7 <= mul_tree_138_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_366_s7 <= mul_tree_138_366; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_373_s1 <= mul_tree_139_373; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_377_s1 <= mul_tree_139_377; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_381_s1 <= mul_tree_139_381; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_385_s1 <= mul_tree_139_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_139_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_139_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_413_s4 <= mul_tree_140_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_416_s4 <= mul_tree_140_416; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_423_s1 <= mul_tree_141_423; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_427_s1 <= mul_tree_141_427; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_431_s1 <= mul_tree_141_431; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_435_s1 <= mul_tree_141_435; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_438_s2 <= mul_tree_141_438; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_441_s2 <= mul_tree_141_441; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_448_s5 <= mul_tree_142_448; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_452_s5 <= mul_tree_142_452; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_456_s5 <= mul_tree_142_456; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_460_s5 <= mul_tree_142_460; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_473_s7 <= mul_tree_143_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_477_s7 <= mul_tree_143_477; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_481_s7 <= mul_tree_143_481; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_485_s7 <= mul_tree_143_485; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_498_s1 <= mul_tree_144_498; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_502_s1 <= mul_tree_144_502; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_506_s1 <= mul_tree_144_506; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_510_s1 <= mul_tree_144_510; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_513_s2 <= mul_tree_144_513; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_516_s2 <= mul_tree_144_516; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_523_s4 <= mul_tree_145_523; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_527_s4 <= mul_tree_145_527; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_531_s4 <= mul_tree_145_531; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_535_s4 <= mul_tree_145_535; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_548_s3 <= limb_49_548; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_548_s4 <= rtlzz_pipe_548_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_548_s5 <= rtlzz_pipe_548_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_548_s6 <= rtlzz_pipe_548_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_549_s6 <= limb_49_549; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_553_s3 <= limb_49_553; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_553_s4 <= rtlzz_pipe_553_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_553_s5 <= rtlzz_pipe_553_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_553_s6 <= rtlzz_pipe_553_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_554_s6 <= limb_49_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_558_s3 <= limb_49_558; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_558_s4 <= rtlzz_pipe_558_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_558_s5 <= rtlzz_pipe_558_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_558_s6 <= rtlzz_pipe_558_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_559_s6 <= limb_49_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_563_s3 <= limb_49_563; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_563_s4 <= rtlzz_pipe_563_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_563_s5 <= rtlzz_pipe_563_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_563_s6 <= rtlzz_pipe_563_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_564_s6 <= limb_49_564; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_568_s3 <= limb_49_568; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_568_s4 <= rtlzz_pipe_568_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_568_s5 <= rtlzz_pipe_568_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_568_s6 <= rtlzz_pipe_568_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_569_s6 <= limb_49_569; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_576_s3 <= limb_50_576; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_576_s4 <= rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_576_s5 <= rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_576_s6 <= rtlzz_pipe_576_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_576_s7 <= rtlzz_pipe_576_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_581_s3 <= limb_50_581; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_581_s4 <= rtlzz_pipe_581_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_581_s5 <= rtlzz_pipe_581_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_581_s6 <= rtlzz_pipe_581_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_581_s7 <= rtlzz_pipe_581_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_586_s3 <= limb_50_586; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_586_s4 <= rtlzz_pipe_586_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_586_s5 <= rtlzz_pipe_586_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_586_s6 <= rtlzz_pipe_586_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_586_s7 <= rtlzz_pipe_586_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_591_s3 <= limb_50_591; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_591_s4 <= rtlzz_pipe_591_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_591_s5 <= rtlzz_pipe_591_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_591_s6 <= rtlzz_pipe_591_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_591_s7 <= rtlzz_pipe_591_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_596_s3 <= limb_50_596; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_596_s4 <= rtlzz_pipe_596_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_596_s5 <= rtlzz_pipe_596_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_596_s6 <= rtlzz_pipe_596_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_596_s7 <= rtlzz_pipe_596_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_602_s5 <= limb_51_602; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_602_s6 <= rtlzz_pipe_602_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_602_s7 <= rtlzz_pipe_602_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_607_s5 <= limb_51_607; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_607_s6 <= rtlzz_pipe_607_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_607_s7 <= rtlzz_pipe_607_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_612_s5 <= limb_51_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_612_s6 <= rtlzz_pipe_612_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_612_s7 <= rtlzz_pipe_612_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_617_s5 <= limb_51_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_617_s6 <= rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_617_s7 <= rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_622_s5 <= limb_51_622; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_622_s6 <= rtlzz_pipe_622_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_622_s7 <= rtlzz_pipe_622_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_629_s3 <= limb_52_629; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_629_s4 <= rtlzz_pipe_629_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_629_s5 <= rtlzz_pipe_629_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_634_s3 <= limb_52_634; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_634_s4 <= rtlzz_pipe_634_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_634_s5 <= rtlzz_pipe_634_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_639_s3 <= limb_52_639; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_639_s4 <= rtlzz_pipe_639_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_639_s5 <= rtlzz_pipe_639_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_644_s3 <= limb_52_644; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_644_s4 <= rtlzz_pipe_644_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_644_s5 <= rtlzz_pipe_644_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_649_s3 <= limb_52_649; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_649_s4 <= rtlzz_pipe_649_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_649_s5 <= rtlzz_pipe_649_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_657_s3 <= limb_53_657; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_657_s4 <= rtlzz_pipe_657_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_657_s5 <= rtlzz_pipe_657_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_657_s6 <= rtlzz_pipe_657_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_657_s7 <= rtlzz_pipe_657_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_662_s3 <= limb_53_662; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_662_s4 <= rtlzz_pipe_662_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_662_s5 <= rtlzz_pipe_662_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_662_s6 <= rtlzz_pipe_662_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_662_s7 <= rtlzz_pipe_662_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_667_s3 <= limb_53_667; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_667_s4 <= rtlzz_pipe_667_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_667_s5 <= rtlzz_pipe_667_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_667_s6 <= rtlzz_pipe_667_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_667_s7 <= rtlzz_pipe_667_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_672_s3 <= limb_53_672; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_672_s4 <= rtlzz_pipe_672_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_672_s5 <= rtlzz_pipe_672_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_672_s6 <= rtlzz_pipe_672_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_672_s7 <= rtlzz_pipe_672_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_677_s3 <= limb_53_677; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_677_s4 <= rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_677_s5 <= rtlzz_pipe_677_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_677_s6 <= rtlzz_pipe_677_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_677_s7 <= rtlzz_pipe_677_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_684_s3 <= limb_54_684; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_684_s4 <= rtlzz_pipe_684_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_686_s5 <= limb_54_686; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_686_s6 <= rtlzz_pipe_686_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_689_s3 <= limb_54_689; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_689_s4 <= rtlzz_pipe_689_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_691_s5 <= limb_54_691; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_691_s6 <= rtlzz_pipe_691_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_694_s3 <= limb_54_694; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_694_s4 <= rtlzz_pipe_694_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_696_s5 <= limb_54_696; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_696_s6 <= rtlzz_pipe_696_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_699_s3 <= limb_54_699; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_699_s4 <= rtlzz_pipe_699_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_701_s5 <= limb_54_701; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_701_s6 <= rtlzz_pipe_701_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_702_s5 <= limb_54_702; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_702_s6 <= rtlzz_pipe_702_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_703_s5 <= limb_54_703; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_703_s6 <= rtlzz_pipe_703_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_704_s3 <= limb_54_704; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_704_s4 <= rtlzz_pipe_704_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_704_s5 <= rtlzz_pipe_704_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_704_s6 <= rtlzz_pipe_704_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_710_s6 <= limb_55_710; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_710_s7 <= rtlzz_pipe_710_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_715_s6 <= limb_55_715; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_715_s7 <= rtlzz_pipe_715_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_720_s6 <= limb_55_720; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_720_s7 <= rtlzz_pipe_720_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_725_s6 <= limb_55_725; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_725_s7 <= rtlzz_pipe_725_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_730_s6 <= limb_55_730; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_730_s7 <= rtlzz_pipe_730_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_737_s3 <= limb_56_737; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_737_s4 <= rtlzz_pipe_737_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_740_s5 <= limb_56_740; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_740_s6 <= rtlzz_pipe_740_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_741_s5 <= limb_56_741; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_742_s3 <= limb_56_742; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_742_s4 <= rtlzz_pipe_742_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_742_s5 <= rtlzz_pipe_742_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_743_s5 <= limb_56_743; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_745_s6 <= limb_56_745; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_746_s6 <= limb_56_746; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_747_s3 <= limb_56_747; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_747_s4 <= rtlzz_pipe_747_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_747_s5 <= rtlzz_pipe_747_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_747_s6 <= rtlzz_pipe_747_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_748_s5 <= limb_56_748; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_748_s6 <= rtlzz_pipe_748_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_752_s3 <= limb_56_752; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_752_s4 <= rtlzz_pipe_752_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_752_s5 <= rtlzz_pipe_752_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_752_s6 <= rtlzz_pipe_752_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_753_s5 <= limb_56_753; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_753_s6 <= rtlzz_pipe_753_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_757_s3 <= limb_56_757; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_757_s4 <= rtlzz_pipe_757_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_757_s5 <= rtlzz_pipe_757_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_757_s6 <= rtlzz_pipe_757_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_758_s5 <= limb_56_758; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_758_s6 <= rtlzz_pipe_758_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_764_s7 <= limb_57_764; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_769_s7 <= limb_57_769; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_774_s7 <= limb_57_774; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_779_s7 <= limb_57_779; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_784_s7 <= limb_57_784; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_792_s6 <= limb_58_792; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_792_s7 <= rtlzz_pipe_792_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_797_s6 <= limb_58_797; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_797_s7 <= rtlzz_pipe_797_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_802_s6 <= limb_58_802; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_802_s7 <= rtlzz_pipe_802_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_807_s6 <= limb_58_807; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_807_s7 <= rtlzz_pipe_807_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_812_s6 <= limb_58_812; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_812_s7 <= rtlzz_pipe_812_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_819_s7 <= limb_59_819; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_824_s7 <= limb_59_824; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_829_s7 <= limb_59_829; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_834_s7 <= limb_59_834; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_839_s7 <= limb_59_839; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_846_s7 <= limb_60_846; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_851_s7 <= limb_60_851; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_856_s7 <= limb_60_856; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_861_s7 <= limb_60_861; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_866_s7 <= limb_60_866; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269_reduce(input wire [63:0] i1055, input wire [95:0] i1056, input wire [95:0] i1057, input wire [127:0] i1058, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1055[63], i1055[62], i1055[61], i1055[60], i1055[59], i1055[58], i1055[57], i1055[56], i1055[55], i1055[54], i1055[53], i1055[52], i1055[51], i1055[50], i1055[49], i1055[48], i1055[47], i1055[46], i1055[45], i1055[44], i1055[43], i1055[42], i1055[41], i1055[40], i1055[39], i1055[38], i1055[37], i1055[36], i1055[35], i1055[34], i1055[33], i1055[32], i1055[31], i1055[30], i1055[29], i1055[28], i1055[27], i1055[26], i1055[25], i1055[24], i1055[23], i1055[22], i1055[21], i1055[20], i1055[19], i1055[18], i1055[17], i1055[16], i1055[15], i1055[14], i1055[13], i1055[12], i1055[11], i1055[10], i1055[9], i1055[8], i1055[7], i1055[6], i1055[5], i1055[4], i1055[3], i1055[2], i1055[1], i1055[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1056[95], i1056[94], i1056[93], i1056[92], i1056[91], i1056[90], i1056[89], i1056[88], i1056[87], i1056[86], i1056[85], i1056[84], i1056[83], i1056[82], i1056[81], i1056[80], i1056[79], i1056[78], i1056[77], i1056[76], i1056[75], i1056[74], i1056[73], i1056[72], i1056[71], i1056[70], i1056[69], i1056[68], i1056[67], i1056[66], i1056[65], i1056[64], i1056[63], i1056[62], i1056[61], i1056[60], i1056[59], i1056[58], i1056[57], i1056[56], i1056[55], i1056[54], i1056[53], i1056[52], i1056[51], i1056[50], i1056[49], i1056[48], i1056[47], i1056[46], i1056[45], i1056[44], i1056[43], i1056[42], i1056[41], i1056[40], i1056[39], i1056[38], i1056[37], i1056[36], i1056[35], i1056[34], i1056[33], i1056[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1057[95], i1057[94], i1057[93], i1057[92], i1057[91], i1057[90], i1057[89], i1057[88], i1057[87], i1057[86], i1057[85], i1057[84], i1057[83], i1057[82], i1057[81], i1057[80], i1057[79], i1057[78], i1057[77], i1057[76], i1057[75], i1057[74], i1057[73], i1057[72], i1057[71], i1057[70], i1057[69], i1057[68], i1057[67], i1057[66], i1057[65], i1057[64], i1057[63], i1057[62], i1057[61], i1057[60], i1057[59], i1057[58], i1057[57], i1057[56], i1057[55], i1057[54], i1057[53], i1057[52], i1057[51], i1057[50], i1057[49], i1057[48], i1057[47], i1057[46], i1057[45], i1057[44], i1057[43], i1057[42], i1057[41], i1057[40], i1057[39], i1057[38], i1057[37], i1057[36], i1057[35], i1057[34], i1057[33], i1057[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1058[127], i1058[126], i1058[125], i1058[124], i1058[123], i1058[122], i1058[121], i1058[120], i1058[119], i1058[118], i1058[117], i1058[116], i1058[115], i1058[114], i1058[113], i1058[112], i1058[111], i1058[110], i1058[109], i1058[108], i1058[107], i1058[106], i1058[105], i1058[104], i1058[103], i1058[102], i1058[101], i1058[100], i1058[99], i1058[98], i1058[97], i1058[96], i1058[95], i1058[94], i1058[93], i1058[92], i1058[91], i1058[90], i1058[89], i1058[88], i1058[87], i1058[86], i1058[85], i1058[84], i1058[83], i1058[82], i1058[81], i1058[80], i1058[79], i1058[78], i1058[77], i1058[76], i1058[75], i1058[74], i1058[73], i1058[72], i1058[71], i1058[70], i1058[69], i1058[68], i1058[67], i1058[66], i1058[65], i1058[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294_reduce(input wire [63:0] i1060, input wire [95:0] i1062, input wire [95:0] i1064, input wire [127:0] i1066, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1060[63], i1060[62], i1060[61], i1060[60], i1060[59], i1060[58], i1060[57], i1060[56], i1060[55], i1060[54], i1060[53], i1060[52], i1060[51], i1060[50], i1060[49], i1060[48], i1060[47], i1060[46], i1060[45], i1060[44], i1060[43], i1060[42], i1060[41], i1060[40], i1060[39], i1060[38], i1060[37], i1060[36], i1060[35], i1060[34], i1060[33], i1060[32], i1060[31], i1060[30], i1060[29], i1060[28], i1060[27], i1060[26], i1060[25], i1060[24], i1060[23], i1060[22], i1060[21], i1060[20], i1060[19], i1060[18], i1060[17], i1060[16], i1060[15], i1060[14], i1060[13], i1060[12], i1060[11], i1060[10], i1060[9], i1060[8], i1060[7], i1060[6], i1060[5], i1060[4], i1060[3], i1060[2], i1060[1], i1060[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1062[95], i1062[94], i1062[93], i1062[92], i1062[91], i1062[90], i1062[89], i1062[88], i1062[87], i1062[86], i1062[85], i1062[84], i1062[83], i1062[82], i1062[81], i1062[80], i1062[79], i1062[78], i1062[77], i1062[76], i1062[75], i1062[74], i1062[73], i1062[72], i1062[71], i1062[70], i1062[69], i1062[68], i1062[67], i1062[66], i1062[65], i1062[64], i1062[63], i1062[62], i1062[61], i1062[60], i1062[59], i1062[58], i1062[57], i1062[56], i1062[55], i1062[54], i1062[53], i1062[52], i1062[51], i1062[50], i1062[49], i1062[48], i1062[47], i1062[46], i1062[45], i1062[44], i1062[43], i1062[42], i1062[41], i1062[40], i1062[39], i1062[38], i1062[37], i1062[36], i1062[35], i1062[34], i1062[33], i1062[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1064[95], i1064[94], i1064[93], i1064[92], i1064[91], i1064[90], i1064[89], i1064[88], i1064[87], i1064[86], i1064[85], i1064[84], i1064[83], i1064[82], i1064[81], i1064[80], i1064[79], i1064[78], i1064[77], i1064[76], i1064[75], i1064[74], i1064[73], i1064[72], i1064[71], i1064[70], i1064[69], i1064[68], i1064[67], i1064[66], i1064[65], i1064[64], i1064[63], i1064[62], i1064[61], i1064[60], i1064[59], i1064[58], i1064[57], i1064[56], i1064[55], i1064[54], i1064[53], i1064[52], i1064[51], i1064[50], i1064[49], i1064[48], i1064[47], i1064[46], i1064[45], i1064[44], i1064[43], i1064[42], i1064[41], i1064[40], i1064[39], i1064[38], i1064[37], i1064[36], i1064[35], i1064[34], i1064[33], i1064[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1066[127], i1066[126], i1066[125], i1066[124], i1066[123], i1066[122], i1066[121], i1066[120], i1066[119], i1066[118], i1066[117], i1066[116], i1066[115], i1066[114], i1066[113], i1066[112], i1066[111], i1066[110], i1066[109], i1066[108], i1066[107], i1066[106], i1066[105], i1066[104], i1066[103], i1066[102], i1066[101], i1066[100], i1066[99], i1066[98], i1066[97], i1066[96], i1066[95], i1066[94], i1066[93], i1066[92], i1066[91], i1066[90], i1066[89], i1066[88], i1066[87], i1066[86], i1066[85], i1066[84], i1066[83], i1066[82], i1066[81], i1066[80], i1066[79], i1066[78], i1066[77], i1066[76], i1066[75], i1066[74], i1066[73], i1066[72], i1066[71], i1066[70], i1066[69], i1066[68], i1066[67], i1066[66], i1066[65], i1066[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344_reduce(input wire [63:0] i1074, input wire [95:0] i1076, input wire [95:0] i1078, input wire [127:0] i1080, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1074[63], i1074[62], i1074[61], i1074[60], i1074[59], i1074[58], i1074[57], i1074[56], i1074[55], i1074[54], i1074[53], i1074[52], i1074[51], i1074[50], i1074[49], i1074[48], i1074[47], i1074[46], i1074[45], i1074[44], i1074[43], i1074[42], i1074[41], i1074[40], i1074[39], i1074[38], i1074[37], i1074[36], i1074[35], i1074[34], i1074[33], i1074[32], i1074[31], i1074[30], i1074[29], i1074[28], i1074[27], i1074[26], i1074[25], i1074[24], i1074[23], i1074[22], i1074[21], i1074[20], i1074[19], i1074[18], i1074[17], i1074[16], i1074[15], i1074[14], i1074[13], i1074[12], i1074[11], i1074[10], i1074[9], i1074[8], i1074[7], i1074[6], i1074[5], i1074[4], i1074[3], i1074[2], i1074[1], i1074[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1076[95], i1076[94], i1076[93], i1076[92], i1076[91], i1076[90], i1076[89], i1076[88], i1076[87], i1076[86], i1076[85], i1076[84], i1076[83], i1076[82], i1076[81], i1076[80], i1076[79], i1076[78], i1076[77], i1076[76], i1076[75], i1076[74], i1076[73], i1076[72], i1076[71], i1076[70], i1076[69], i1076[68], i1076[67], i1076[66], i1076[65], i1076[64], i1076[63], i1076[62], i1076[61], i1076[60], i1076[59], i1076[58], i1076[57], i1076[56], i1076[55], i1076[54], i1076[53], i1076[52], i1076[51], i1076[50], i1076[49], i1076[48], i1076[47], i1076[46], i1076[45], i1076[44], i1076[43], i1076[42], i1076[41], i1076[40], i1076[39], i1076[38], i1076[37], i1076[36], i1076[35], i1076[34], i1076[33], i1076[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1078[95], i1078[94], i1078[93], i1078[92], i1078[91], i1078[90], i1078[89], i1078[88], i1078[87], i1078[86], i1078[85], i1078[84], i1078[83], i1078[82], i1078[81], i1078[80], i1078[79], i1078[78], i1078[77], i1078[76], i1078[75], i1078[74], i1078[73], i1078[72], i1078[71], i1078[70], i1078[69], i1078[68], i1078[67], i1078[66], i1078[65], i1078[64], i1078[63], i1078[62], i1078[61], i1078[60], i1078[59], i1078[58], i1078[57], i1078[56], i1078[55], i1078[54], i1078[53], i1078[52], i1078[51], i1078[50], i1078[49], i1078[48], i1078[47], i1078[46], i1078[45], i1078[44], i1078[43], i1078[42], i1078[41], i1078[40], i1078[39], i1078[38], i1078[37], i1078[36], i1078[35], i1078[34], i1078[33], i1078[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1080[127], i1080[126], i1080[125], i1080[124], i1080[123], i1080[122], i1080[121], i1080[120], i1080[119], i1080[118], i1080[117], i1080[116], i1080[115], i1080[114], i1080[113], i1080[112], i1080[111], i1080[110], i1080[109], i1080[108], i1080[107], i1080[106], i1080[105], i1080[104], i1080[103], i1080[102], i1080[101], i1080[100], i1080[99], i1080[98], i1080[97], i1080[96], i1080[95], i1080[94], i1080[93], i1080[92], i1080[91], i1080[90], i1080[89], i1080[88], i1080[87], i1080[86], i1080[85], i1080[84], i1080[83], i1080[82], i1080[81], i1080[80], i1080[79], i1080[78], i1080[77], i1080[76], i1080[75], i1080[74], i1080[73], i1080[72], i1080[71], i1080[70], i1080[69], i1080[68], i1080[67], i1080[66], i1080[65], i1080[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_469_reduce(input wire [63:0] i1097, input wire [95:0] i1098, input wire [95:0] i1099, input wire [127:0] i1100, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1097[63], i1097[62], i1097[61], i1097[60], i1097[59], i1097[58], i1097[57], i1097[56], i1097[55], i1097[54], i1097[53], i1097[52], i1097[51], i1097[50], i1097[49], i1097[48], i1097[47], i1097[46], i1097[45], i1097[44], i1097[43], i1097[42], i1097[41], i1097[40], i1097[39], i1097[38], i1097[37], i1097[36], i1097[35], i1097[34], i1097[33], i1097[32], i1097[31], i1097[30], i1097[29], i1097[28], i1097[27], i1097[26], i1097[25], i1097[24], i1097[23], i1097[22], i1097[21], i1097[20], i1097[19], i1097[18], i1097[17], i1097[16], i1097[15], i1097[14], i1097[13], i1097[12], i1097[11], i1097[10], i1097[9], i1097[8], i1097[7], i1097[6], i1097[5], i1097[4], i1097[3], i1097[2], i1097[1], i1097[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1098[95], i1098[94], i1098[93], i1098[92], i1098[91], i1098[90], i1098[89], i1098[88], i1098[87], i1098[86], i1098[85], i1098[84], i1098[83], i1098[82], i1098[81], i1098[80], i1098[79], i1098[78], i1098[77], i1098[76], i1098[75], i1098[74], i1098[73], i1098[72], i1098[71], i1098[70], i1098[69], i1098[68], i1098[67], i1098[66], i1098[65], i1098[64], i1098[63], i1098[62], i1098[61], i1098[60], i1098[59], i1098[58], i1098[57], i1098[56], i1098[55], i1098[54], i1098[53], i1098[52], i1098[51], i1098[50], i1098[49], i1098[48], i1098[47], i1098[46], i1098[45], i1098[44], i1098[43], i1098[42], i1098[41], i1098[40], i1098[39], i1098[38], i1098[37], i1098[36], i1098[35], i1098[34], i1098[33], i1098[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1099[95], i1099[94], i1099[93], i1099[92], i1099[91], i1099[90], i1099[89], i1099[88], i1099[87], i1099[86], i1099[85], i1099[84], i1099[83], i1099[82], i1099[81], i1099[80], i1099[79], i1099[78], i1099[77], i1099[76], i1099[75], i1099[74], i1099[73], i1099[72], i1099[71], i1099[70], i1099[69], i1099[68], i1099[67], i1099[66], i1099[65], i1099[64], i1099[63], i1099[62], i1099[61], i1099[60], i1099[59], i1099[58], i1099[57], i1099[56], i1099[55], i1099[54], i1099[53], i1099[52], i1099[51], i1099[50], i1099[49], i1099[48], i1099[47], i1099[46], i1099[45], i1099[44], i1099[43], i1099[42], i1099[41], i1099[40], i1099[39], i1099[38], i1099[37], i1099[36], i1099[35], i1099[34], i1099[33], i1099[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1100[127], i1100[126], i1100[125], i1100[124], i1100[123], i1100[122], i1100[121], i1100[120], i1100[119], i1100[118], i1100[117], i1100[116], i1100[115], i1100[114], i1100[113], i1100[112], i1100[111], i1100[110], i1100[109], i1100[108], i1100[107], i1100[106], i1100[105], i1100[104], i1100[103], i1100[102], i1100[101], i1100[100], i1100[99], i1100[98], i1100[97], i1100[96], i1100[95], i1100[94], i1100[93], i1100[92], i1100[91], i1100[90], i1100[89], i1100[88], i1100[87], i1100[86], i1100[85], i1100[84], i1100[83], i1100[82], i1100[81], i1100[80], i1100[79], i1100[78], i1100[77], i1100[76], i1100[75], i1100[74], i1100[73], i1100[72], i1100[71], i1100[70], i1100[69], i1100[68], i1100[67], i1100[66], i1100[65], i1100[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494_reduce(input wire [63:0] i1101, input wire [95:0] i1102, input wire [95:0] i1103, input wire [127:0] i1104, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1101[63], i1101[62], i1101[61], i1101[60], i1101[59], i1101[58], i1101[57], i1101[56], i1101[55], i1101[54], i1101[53], i1101[52], i1101[51], i1101[50], i1101[49], i1101[48], i1101[47], i1101[46], i1101[45], i1101[44], i1101[43], i1101[42], i1101[41], i1101[40], i1101[39], i1101[38], i1101[37], i1101[36], i1101[35], i1101[34], i1101[33], i1101[32], i1101[31], i1101[30], i1101[29], i1101[28], i1101[27], i1101[26], i1101[25], i1101[24], i1101[23], i1101[22], i1101[21], i1101[20], i1101[19], i1101[18], i1101[17], i1101[16], i1101[15], i1101[14], i1101[13], i1101[12], i1101[11], i1101[10], i1101[9], i1101[8], i1101[7], i1101[6], i1101[5], i1101[4], i1101[3], i1101[2], i1101[1], i1101[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1102[95], i1102[94], i1102[93], i1102[92], i1102[91], i1102[90], i1102[89], i1102[88], i1102[87], i1102[86], i1102[85], i1102[84], i1102[83], i1102[82], i1102[81], i1102[80], i1102[79], i1102[78], i1102[77], i1102[76], i1102[75], i1102[74], i1102[73], i1102[72], i1102[71], i1102[70], i1102[69], i1102[68], i1102[67], i1102[66], i1102[65], i1102[64], i1102[63], i1102[62], i1102[61], i1102[60], i1102[59], i1102[58], i1102[57], i1102[56], i1102[55], i1102[54], i1102[53], i1102[52], i1102[51], i1102[50], i1102[49], i1102[48], i1102[47], i1102[46], i1102[45], i1102[44], i1102[43], i1102[42], i1102[41], i1102[40], i1102[39], i1102[38], i1102[37], i1102[36], i1102[35], i1102[34], i1102[33], i1102[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1103[95], i1103[94], i1103[93], i1103[92], i1103[91], i1103[90], i1103[89], i1103[88], i1103[87], i1103[86], i1103[85], i1103[84], i1103[83], i1103[82], i1103[81], i1103[80], i1103[79], i1103[78], i1103[77], i1103[76], i1103[75], i1103[74], i1103[73], i1103[72], i1103[71], i1103[70], i1103[69], i1103[68], i1103[67], i1103[66], i1103[65], i1103[64], i1103[63], i1103[62], i1103[61], i1103[60], i1103[59], i1103[58], i1103[57], i1103[56], i1103[55], i1103[54], i1103[53], i1103[52], i1103[51], i1103[50], i1103[49], i1103[48], i1103[47], i1103[46], i1103[45], i1103[44], i1103[43], i1103[42], i1103[41], i1103[40], i1103[39], i1103[38], i1103[37], i1103[36], i1103[35], i1103[34], i1103[33], i1103[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1104[127], i1104[126], i1104[125], i1104[124], i1104[123], i1104[122], i1104[121], i1104[120], i1104[119], i1104[118], i1104[117], i1104[116], i1104[115], i1104[114], i1104[113], i1104[112], i1104[111], i1104[110], i1104[109], i1104[108], i1104[107], i1104[106], i1104[105], i1104[104], i1104[103], i1104[102], i1104[101], i1104[100], i1104[99], i1104[98], i1104[97], i1104[96], i1104[95], i1104[94], i1104[93], i1104[92], i1104[91], i1104[90], i1104[89], i1104[88], i1104[87], i1104[86], i1104[85], i1104[84], i1104[83], i1104[82], i1104[81], i1104[80], i1104[79], i1104[78], i1104[77], i1104[76], i1104[75], i1104[74], i1104[73], i1104[72], i1104[71], i1104[70], i1104[69], i1104[68], i1104[67], i1104[66], i1104[65], i1104[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544_reduce(input wire [63:0] i1111, input wire [95:0] i1112, input wire [95:0] i1113, input wire [127:0] i1114, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1111[63], i1111[62], i1111[61], i1111[60], i1111[59], i1111[58], i1111[57], i1111[56], i1111[55], i1111[54], i1111[53], i1111[52], i1111[51], i1111[50], i1111[49], i1111[48], i1111[47], i1111[46], i1111[45], i1111[44], i1111[43], i1111[42], i1111[41], i1111[40], i1111[39], i1111[38], i1111[37], i1111[36], i1111[35], i1111[34], i1111[33], i1111[32], i1111[31], i1111[30], i1111[29], i1111[28], i1111[27], i1111[26], i1111[25], i1111[24], i1111[23], i1111[22], i1111[21], i1111[20], i1111[19], i1111[18], i1111[17], i1111[16], i1111[15], i1111[14], i1111[13], i1111[12], i1111[11], i1111[10], i1111[9], i1111[8], i1111[7], i1111[6], i1111[5], i1111[4], i1111[3], i1111[2], i1111[1], i1111[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1112[95], i1112[94], i1112[93], i1112[92], i1112[91], i1112[90], i1112[89], i1112[88], i1112[87], i1112[86], i1112[85], i1112[84], i1112[83], i1112[82], i1112[81], i1112[80], i1112[79], i1112[78], i1112[77], i1112[76], i1112[75], i1112[74], i1112[73], i1112[72], i1112[71], i1112[70], i1112[69], i1112[68], i1112[67], i1112[66], i1112[65], i1112[64], i1112[63], i1112[62], i1112[61], i1112[60], i1112[59], i1112[58], i1112[57], i1112[56], i1112[55], i1112[54], i1112[53], i1112[52], i1112[51], i1112[50], i1112[49], i1112[48], i1112[47], i1112[46], i1112[45], i1112[44], i1112[43], i1112[42], i1112[41], i1112[40], i1112[39], i1112[38], i1112[37], i1112[36], i1112[35], i1112[34], i1112[33], i1112[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1113[95], i1113[94], i1113[93], i1113[92], i1113[91], i1113[90], i1113[89], i1113[88], i1113[87], i1113[86], i1113[85], i1113[84], i1113[83], i1113[82], i1113[81], i1113[80], i1113[79], i1113[78], i1113[77], i1113[76], i1113[75], i1113[74], i1113[73], i1113[72], i1113[71], i1113[70], i1113[69], i1113[68], i1113[67], i1113[66], i1113[65], i1113[64], i1113[63], i1113[62], i1113[61], i1113[60], i1113[59], i1113[58], i1113[57], i1113[56], i1113[55], i1113[54], i1113[53], i1113[52], i1113[51], i1113[50], i1113[49], i1113[48], i1113[47], i1113[46], i1113[45], i1113[44], i1113[43], i1113[42], i1113[41], i1113[40], i1113[39], i1113[38], i1113[37], i1113[36], i1113[35], i1113[34], i1113[33], i1113[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1114[127], i1114[126], i1114[125], i1114[124], i1114[123], i1114[122], i1114[121], i1114[120], i1114[119], i1114[118], i1114[117], i1114[116], i1114[115], i1114[114], i1114[113], i1114[112], i1114[111], i1114[110], i1114[109], i1114[108], i1114[107], i1114[106], i1114[105], i1114[104], i1114[103], i1114[102], i1114[101], i1114[100], i1114[99], i1114[98], i1114[97], i1114[96], i1114[95], i1114[94], i1114[93], i1114[92], i1114[91], i1114[90], i1114[89], i1114[88], i1114[87], i1114[86], i1114[85], i1114[84], i1114[83], i1114[82], i1114[81], i1114[80], i1114[79], i1114[78], i1114[77], i1114[76], i1114[75], i1114[74], i1114[73], i1114[72], i1114[71], i1114[70], i1114[69], i1114[68], i1114[67], i1114[66], i1114[65], i1114[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_555Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_555();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_560Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_560();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_565Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_565();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_570Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_570();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_582Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_582();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_587Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_587();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_592Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_592();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_597Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_597();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_604Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_604();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_609Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_609();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_614Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_614();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_619Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_619();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_636Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_636();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_641Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_641();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_651Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_651();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_658Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_658();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_663Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_663();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_668Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_668();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_673Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_673();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_685Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_685();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_690Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_690();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_695Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_695();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_700Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_700();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_705Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_705();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_712Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_712();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_717Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_717();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_722Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_722();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_727Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_727();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_732Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_732();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_739Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_739();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_744Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_744();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_749Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_749();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_759Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_759();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_771Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_771();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_776Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_776();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_781Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_781();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_786Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_786();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_793Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_793();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_798Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_798();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_803Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_803();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_808Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_808();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_813Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_813();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_820Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_820();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_825Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_825();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_830Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_830();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_847Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_847();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_852Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_852();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_857Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_857();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_867Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_867();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_879Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_879();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_884Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_884();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_894Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_894();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_906Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_906();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_911Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_911();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_916Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_916();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_921Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_921();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_928Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_928();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_933Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_933();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_938Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_938();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_943Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_943();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_948Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h7)|4'h0);
wire [3:0] masked_b=((b&4'h7)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_948();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
