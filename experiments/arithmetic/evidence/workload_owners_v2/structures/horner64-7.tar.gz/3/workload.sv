`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [31:0] mul_tree_17_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_25; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_26; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_28; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_29; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_30; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_32; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_33; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_34; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_17_35; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_36; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_37; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_38; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_39; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_40; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_41; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_42; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_43; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_50; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_51; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_52; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_54; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_55; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_58; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_59; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_18_60; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_61; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_62; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_63; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_64; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_65; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_66; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_67; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_68; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_72; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_74; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_75; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_76; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_77; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_78; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_79; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_80; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_81; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_82; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_83; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_84; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_19_85; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_86; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_87; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_88; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_89; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_90; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_91; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_92; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_93; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_94; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_96; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_97; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_98; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_100; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_101; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_102; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_104; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_105; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_106; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_108; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_109; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_20_110; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_113; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_114; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_115; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_116; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_119; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_120; // decl: <none>; prim: <none>
    logic [15:0] limb_8_121; // decl: <none>; prim: <none>
    logic [15:0] limb_8_122; // decl: <none>; prim: <none>
    logic [16:0] limb_8_123; // decl: <none>; prim: <none>
    logic [15:0] limb_8_124; // decl: <none>; prim: <none>
    logic limb_8_125; // decl: <none>; prim: <none>
    logic [15:0] limb_8_126; // decl: <none>; prim: <none>
    logic [15:0] limb_8_127; // decl: <none>; prim: <none>
    logic [16:0] limb_8_128; // decl: <none>; prim: <none>
    logic [15:0] limb_8_129; // decl: <none>; prim: <none>
    logic limb_8_130; // decl: <none>; prim: <none>
    logic [15:0] limb_8_131; // decl: <none>; prim: <none>
    logic [15:0] limb_8_132; // decl: <none>; prim: <none>
    logic [16:0] limb_8_133; // decl: <none>; prim: <none>
    logic [15:0] limb_8_134; // decl: <none>; prim: <none>
    logic limb_8_135; // decl: <none>; prim: <none>
    logic [15:0] limb_8_136; // decl: <none>; prim: <none>
    logic [15:0] limb_8_137; // decl: <none>; prim: <none>
    logic [16:0] limb_8_138; // decl: <none>; prim: <none>
    logic [15:0] limb_8_139; // decl: <none>; prim: <none>
    logic [63:0] limb_8_140; // decl: <none>; prim: <none>
    logic [15:0] limb_10_141; // decl: <none>; prim: <none>
    logic [15:0] limb_10_142; // decl: <none>; prim: <none>
    logic [16:0] limb_10_143; // decl: <none>; prim: <none>
    logic [15:0] limb_10_144; // decl: <none>; prim: <none>
    logic limb_10_145; // decl: <none>; prim: <none>
    logic [15:0] limb_10_146; // decl: <none>; prim: <none>
    logic [15:0] limb_10_147; // decl: <none>; prim: <none>
    logic [16:0] limb_10_148; // decl: <none>; prim: <none>
    logic [15:0] limb_10_149; // decl: <none>; prim: <none>
    logic limb_10_150; // decl: <none>; prim: <none>
    logic [15:0] limb_10_151; // decl: <none>; prim: <none>
    logic [15:0] limb_10_152; // decl: <none>; prim: <none>
    logic [16:0] limb_10_153; // decl: <none>; prim: <none>
    logic [15:0] limb_10_154; // decl: <none>; prim: <none>
    logic limb_10_155; // decl: <none>; prim: <none>
    logic [15:0] limb_10_156; // decl: <none>; prim: <none>
    logic [15:0] limb_10_157; // decl: <none>; prim: <none>
    logic [16:0] limb_10_158; // decl: <none>; prim: <none>
    logic [15:0] limb_10_159; // decl: <none>; prim: <none>
    logic [63:0] limb_10_160; // decl: <none>; prim: <none>
    logic [15:0] limb_12_161; // decl: <none>; prim: <none>
    logic [15:0] limb_12_162; // decl: <none>; prim: <none>
    logic [16:0] limb_12_163; // decl: <none>; prim: <none>
    logic [15:0] limb_12_164; // decl: <none>; prim: <none>
    logic limb_12_165; // decl: <none>; prim: <none>
    logic [15:0] limb_12_166; // decl: <none>; prim: <none>
    logic [15:0] limb_12_167; // decl: <none>; prim: <none>
    logic [16:0] limb_12_168; // decl: <none>; prim: <none>
    logic [15:0] limb_12_169; // decl: <none>; prim: <none>
    logic limb_12_170; // decl: <none>; prim: <none>
    logic [15:0] limb_12_171; // decl: <none>; prim: <none>
    logic [15:0] limb_12_172; // decl: <none>; prim: <none>
    logic [16:0] limb_12_173; // decl: <none>; prim: <none>
    logic [15:0] limb_12_174; // decl: <none>; prim: <none>
    logic limb_12_175; // decl: <none>; prim: <none>
    logic [15:0] limb_12_176; // decl: <none>; prim: <none>
    logic [15:0] limb_12_177; // decl: <none>; prim: <none>
    logic [16:0] limb_12_178; // decl: <none>; prim: <none>
    logic [15:0] limb_12_179; // decl: <none>; prim: <none>
    logic [63:0] limb_12_180; // decl: <none>; prim: <none>
    logic [15:0] limb_14_181; // decl: <none>; prim: <none>
    logic [15:0] limb_14_182; // decl: <none>; prim: <none>
    logic [16:0] limb_14_183; // decl: <none>; prim: <none>
    logic [15:0] limb_14_184; // decl: <none>; prim: <none>
    logic limb_14_185; // decl: <none>; prim: <none>
    logic [15:0] limb_14_186; // decl: <none>; prim: <none>
    logic [15:0] limb_14_187; // decl: <none>; prim: <none>
    logic [16:0] limb_14_188; // decl: <none>; prim: <none>
    logic [15:0] limb_14_189; // decl: <none>; prim: <none>
    logic limb_14_190; // decl: <none>; prim: <none>
    logic [15:0] limb_14_191; // decl: <none>; prim: <none>
    logic [15:0] limb_14_192; // decl: <none>; prim: <none>
    logic [16:0] limb_14_193; // decl: <none>; prim: <none>
    logic [15:0] limb_14_194; // decl: <none>; prim: <none>
    logic limb_14_195; // decl: <none>; prim: <none>
    logic [15:0] limb_14_196; // decl: <none>; prim: <none>
    logic [15:0] limb_14_197; // decl: <none>; prim: <none>
    logic [16:0] limb_14_198; // decl: <none>; prim: <none>
    logic [15:0] limb_14_199; // decl: <none>; prim: <none>
    logic [63:0] limb_14_200; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_121_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_126_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_127_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_129_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_130_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_131_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_131_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_131_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_132_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_132_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_132_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_132_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_132_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_136_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_136_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_136_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_137_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_137_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_137_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_137_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_137_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_8_s6; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [96:0] rtlzz_pipe_63_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_66_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_142_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_147_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_152_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_157_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_162_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_167_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_177_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_182_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_187_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_192_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_197_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = limb_8_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_add_5_v0 = limb_10_160; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    assign s8_norm_add_8_v0 = limb_12_180; // decl: <none>; prim: <none>
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_add_11_v0 = limb_14_200; // decl: <none>; prim: <none>
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign arith_original_17 = mul_tree_17_45; // decl: <none>; prim: <none>
    assign arith_original_18 = mul_tree_18_70; // decl: <none>; prim: <none>
    assign arith_original_19 = mul_tree_19_95; // decl: <none>; prim: <none>
    assign arith_original_20 = mul_tree_20_120; // decl: <none>; prim: <none>
    assign mul_tree_17_21 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_22 = x[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(32'(mul_tree_17_21)), .b(32'(mul_tree_17_22)), .cin(1'b0), .value(mul_tree_17_23));
    assign mul_tree_17_24 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_25 = x[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(32'(mul_tree_17_24)), .b(32'(mul_tree_17_25)), .cin(1'b0), .value(mul_tree_17_26[31:0]));
    assign mul_tree_17_26[63:32] = '0;
    assign mul_tree_17_27 = {mul_tree_17_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_28 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_29 = x[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(32'(mul_tree_17_28)), .b(32'(mul_tree_17_29)), .cin(1'b0), .value(mul_tree_17_30[31:0]));
    assign mul_tree_17_30[63:32] = '0;
    assign mul_tree_17_31 = {mul_tree_17_30, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_32 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_33 = x[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_34 = 64'(($unsigned(64'($unsigned(mul_tree_17_32))) * $unsigned(64'($unsigned(mul_tree_17_33))))); // decl: <none>; prim: <none>
    assign mul_tree_17_35 = {mul_tree_17_34, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_36 = ({33'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_37 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(64'(mul_tree_17_36)), .b(96'(mul_tree_17_37)), .cin(1'h0), .value(mul_tree_17_38[63:0]));
    assign mul_tree_17_38[96:64] = '0;
    assign mul_tree_17_39 = ({33'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_40 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_41Core rtlzz_owner_41(.a(96'(mul_tree_17_39)), .b(128'(mul_tree_17_40)), .cin(1'h0), .value(mul_tree_17_41[63:0]));
    assign mul_tree_17_41[128:64] = '0;
    assign mul_tree_17_42 = ({33'h0, rtlzz_pipe_38_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_43 = ({1'h0, rtlzz_pipe_41_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(97'(mul_tree_17_42)), .b(129'(mul_tree_17_43)), .cin(1'h0), .value(mul_tree_17_44[63:0]));
    assign mul_tree_17_44[129:64] = '0;
    assign mul_tree_17_45 = mul_tree_17_44[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_46 = rtlzz_pipe_8_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_47 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_18_46)), .b(32'(mul_tree_18_47)), .cin(1'b0), .value(mul_tree_18_48));
    assign mul_tree_18_49 = rtlzz_pipe_8_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_50 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(32'(mul_tree_18_49)), .b(32'(mul_tree_18_50)), .cin(1'b0), .value(mul_tree_18_51[31:0]));
    assign mul_tree_18_51[63:32] = '0;
    assign mul_tree_18_52 = {mul_tree_18_51, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_53 = rtlzz_pipe_8_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_54 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_55Core rtlzz_owner_55(.a(32'(mul_tree_18_53)), .b(32'(mul_tree_18_54)), .cin(1'b0), .value(mul_tree_18_55[31:0]));
    assign mul_tree_18_55[63:32] = '0;
    assign mul_tree_18_56 = {mul_tree_18_55, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_57 = rtlzz_pipe_8_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_58 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_59 = 64'(($unsigned(64'($unsigned(mul_tree_18_57))) * $unsigned(64'($unsigned(mul_tree_18_58))))); // decl: <none>; prim: <none>
    assign mul_tree_18_60 = {mul_tree_18_59, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_61 = ({33'h0, mul_tree_18_48}); // decl: <none>; prim: <none>
    assign mul_tree_18_62 = ({1'h0, mul_tree_18_52}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(64'(mul_tree_18_61)), .b(96'(mul_tree_18_62)), .cin(1'h0), .value(mul_tree_18_63[63:0]));
    assign mul_tree_18_63[96:64] = '0;
    assign mul_tree_18_64 = ({33'h0, mul_tree_18_56}); // decl: <none>; prim: <none>
    assign mul_tree_18_65 = ({1'h0, mul_tree_18_60}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_66Core rtlzz_owner_66(.a(96'(mul_tree_18_64)), .b(128'(mul_tree_18_65)), .cin(1'h0), .value(mul_tree_18_66[63:0]));
    assign mul_tree_18_66[128:64] = '0;
    assign mul_tree_18_67 = ({33'h0, rtlzz_pipe_63_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_68 = ({1'h0, rtlzz_pipe_66_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_69Core rtlzz_owner_69(.a(97'(mul_tree_18_67)), .b(129'(mul_tree_18_68)), .cin(1'h0), .value(mul_tree_18_69[63:0]));
    assign mul_tree_18_69[129:64] = '0;
    assign mul_tree_18_70 = mul_tree_18_69[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_71 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_72 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(32'(mul_tree_19_71)), .b(32'(mul_tree_19_72)), .cin(1'b0), .value(mul_tree_19_73));
    assign mul_tree_19_74 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_75 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(32'(mul_tree_19_74)), .b(32'(mul_tree_19_75)), .cin(1'b0), .value(mul_tree_19_76[31:0]));
    assign mul_tree_19_76[63:32] = '0;
    assign mul_tree_19_77 = {mul_tree_19_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_78 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_79 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(32'(mul_tree_19_78)), .b(32'(mul_tree_19_79)), .cin(1'b0), .value(mul_tree_19_80[31:0]));
    assign mul_tree_19_80[63:32] = '0;
    assign mul_tree_19_81 = {mul_tree_19_80, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_82 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_83 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_84 = 64'(($unsigned(64'($unsigned(mul_tree_19_82))) * $unsigned(64'($unsigned(mul_tree_19_83))))); // decl: <none>; prim: <none>
    assign mul_tree_19_85 = {mul_tree_19_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_86 = ({33'h0, mul_tree_19_73}); // decl: <none>; prim: <none>
    assign mul_tree_19_87 = ({1'h0, mul_tree_19_77}); // decl: <none>; prim: <none>
    assign mul_tree_19_89 = ({33'h0, mul_tree_19_81}); // decl: <none>; prim: <none>
    assign mul_tree_19_90 = ({1'h0, mul_tree_19_85}); // decl: <none>; prim: <none>
    assign mul_tree_19_92 = ({33'h0, mul_tree_19_88}); // decl: <none>; prim: <none>
    assign mul_tree_19_93 = ({1'h0, mul_tree_19_91}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94_reduce rtlzz_reduce_94(.i73(mul_tree_19_73), .i76(mul_tree_19_76), .i80(mul_tree_19_80), .y(mul_tree_19_94));
    assign mul_tree_19_95 = mul_tree_19_94[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_96 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_97 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_20_96)), .b(32'(mul_tree_20_97)), .cin(1'b0), .value(mul_tree_20_98));
    assign mul_tree_20_99 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_100 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_101Core rtlzz_owner_101(.a(32'(mul_tree_20_99)), .b(32'(mul_tree_20_100)), .cin(1'b0), .value(mul_tree_20_101[31:0]));
    assign mul_tree_20_101[63:32] = '0;
    assign mul_tree_20_102 = {mul_tree_20_101, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_103 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_104 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105Core rtlzz_owner_105(.a(32'(mul_tree_20_103)), .b(32'(mul_tree_20_104)), .cin(1'b0), .value(mul_tree_20_105[31:0]));
    assign mul_tree_20_105[63:32] = '0;
    assign mul_tree_20_106 = {mul_tree_20_105, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_107 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_108 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_109 = 64'(($unsigned(64'($unsigned(mul_tree_20_107))) * $unsigned(64'($unsigned(mul_tree_20_108))))); // decl: <none>; prim: <none>
    assign mul_tree_20_110 = {mul_tree_20_109, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_111 = ({33'h0, mul_tree_20_98}); // decl: <none>; prim: <none>
    assign mul_tree_20_112 = ({1'h0, mul_tree_20_102}); // decl: <none>; prim: <none>
    assign mul_tree_20_114 = ({33'h0, mul_tree_20_106}); // decl: <none>; prim: <none>
    assign mul_tree_20_115 = ({1'h0, mul_tree_20_110}); // decl: <none>; prim: <none>
    assign mul_tree_20_117 = ({33'h0, mul_tree_20_113}); // decl: <none>; prim: <none>
    assign mul_tree_20_118 = ({1'h0, mul_tree_20_116}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_119_reduce rtlzz_reduce_119(.i98(mul_tree_20_98), .i101(mul_tree_20_101), .i105(mul_tree_20_105), .y(mul_tree_20_119));
    assign mul_tree_20_120 = mul_tree_20_119[63:0]; // decl: <none>; prim: <none>
    assign limb_8_121 = s8_norm_mul_0_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_8_122 = c3[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(16'(rtlzz_pipe_121_s3)), .b(16'(rtlzz_pipe_122_s3)), .cin(1'h0), .value(limb_8_123));
    assign limb_8_124 = limb_8_123[15:0]; // decl: <none>; prim: <none>
    assign limb_8_125 = limb_8_123[16]; // decl: <none>; prim: <none>
    assign limb_8_126 = s8_norm_mul_0_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_8_127 = c3[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(rtlzz_pipe_126_s4)), .b(16'(rtlzz_pipe_127_s4)), .cin(rtlzz_pipe_125_s4), .value(limb_8_128));
    assign limb_8_129 = limb_8_128[15:0]; // decl: <none>; prim: <none>
    assign limb_8_130 = limb_8_128[16]; // decl: <none>; prim: <none>
    assign limb_8_131 = s8_norm_mul_0_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_8_132 = c3[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_133Core rtlzz_owner_133(.a(16'(rtlzz_pipe_131_s5)), .b(16'(rtlzz_pipe_132_s5)), .cin(rtlzz_pipe_130_s5), .value(limb_8_133));
    assign limb_8_134 = limb_8_133[15:0]; // decl: <none>; prim: <none>
    assign limb_8_135 = limb_8_133[16]; // decl: <none>; prim: <none>
    assign limb_8_136 = s8_norm_mul_0_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_8_137 = c3[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(16'(rtlzz_pipe_136_s5)), .b(16'(rtlzz_pipe_137_s5)), .cin(limb_8_135), .value(limb_8_138[15:0]));
    assign limb_8_138[16:16] = '0;
    assign limb_8_139 = limb_8_138[15:0]; // decl: <none>; prim: <none>
    assign limb_8_140 = {limb_8_139, limb_8_134, rtlzz_pipe_129_s5, rtlzz_pipe_124_s5}; // decl: <none>; prim: <none>
    assign limb_10_141 = s8_norm_mul_3_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_10_142 = c2[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(16'(limb_10_141)), .b(16'(rtlzz_pipe_142_s7)), .cin(1'h0), .value(limb_10_143));
    assign limb_10_144 = limb_10_143[15:0]; // decl: <none>; prim: <none>
    assign limb_10_145 = limb_10_143[16]; // decl: <none>; prim: <none>
    assign limb_10_146 = s8_norm_mul_3_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_10_147 = c2[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(limb_10_146)), .b(16'(rtlzz_pipe_147_s7)), .cin(limb_10_145), .value(limb_10_148));
    assign limb_10_149 = limb_10_148[15:0]; // decl: <none>; prim: <none>
    assign limb_10_150 = limb_10_148[16]; // decl: <none>; prim: <none>
    assign limb_10_151 = s8_norm_mul_3_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_10_152 = c2[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_153Core rtlzz_owner_153(.a(16'(limb_10_151)), .b(16'(rtlzz_pipe_152_s7)), .cin(limb_10_150), .value(limb_10_153));
    assign limb_10_154 = limb_10_153[15:0]; // decl: <none>; prim: <none>
    assign limb_10_155 = limb_10_153[16]; // decl: <none>; prim: <none>
    assign limb_10_156 = s8_norm_mul_3_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_10_157 = c2[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_158Core rtlzz_owner_158(.a(16'(limb_10_156)), .b(16'(rtlzz_pipe_157_s7)), .cin(limb_10_155), .value(limb_10_158[15:0]));
    assign limb_10_158[16:16] = '0;
    assign limb_10_159 = limb_10_158[15:0]; // decl: <none>; prim: <none>
    assign limb_10_160 = {limb_10_159, limb_10_154, limb_10_149, limb_10_144}; // decl: <none>; prim: <none>
    assign limb_12_161 = s8_norm_mul_6_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_12_162 = c1[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(16'(limb_12_161)), .b(16'(rtlzz_pipe_162_s7)), .cin(1'h0), .value(limb_12_163));
    assign limb_12_164 = limb_12_163[15:0]; // decl: <none>; prim: <none>
    assign limb_12_165 = limb_12_163[16]; // decl: <none>; prim: <none>
    assign limb_12_166 = s8_norm_mul_6_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_12_167 = c1[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(limb_12_166)), .b(16'(rtlzz_pipe_167_s7)), .cin(limb_12_165), .value(limb_12_168));
    assign limb_12_169 = limb_12_168[15:0]; // decl: <none>; prim: <none>
    assign limb_12_170 = limb_12_168[16]; // decl: <none>; prim: <none>
    assign limb_12_171 = s8_norm_mul_6_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_12_172 = c1[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_173Core rtlzz_owner_173(.a(16'(limb_12_171)), .b(16'(rtlzz_pipe_172_s7)), .cin(limb_12_170), .value(limb_12_173));
    assign limb_12_174 = limb_12_173[15:0]; // decl: <none>; prim: <none>
    assign limb_12_175 = limb_12_173[16]; // decl: <none>; prim: <none>
    assign limb_12_176 = s8_norm_mul_6_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_12_177 = c1[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_178Core rtlzz_owner_178(.a(16'(limb_12_176)), .b(16'(rtlzz_pipe_177_s7)), .cin(limb_12_175), .value(limb_12_178[15:0]));
    assign limb_12_178[16:16] = '0;
    assign limb_12_179 = limb_12_178[15:0]; // decl: <none>; prim: <none>
    assign limb_12_180 = {limb_12_179, limb_12_174, limb_12_169, limb_12_164}; // decl: <none>; prim: <none>
    assign limb_14_181 = s8_norm_mul_9_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_14_182 = c0[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_183Core rtlzz_owner_183(.a(16'(limb_14_181)), .b(16'(rtlzz_pipe_182_s7)), .cin(1'h0), .value(limb_14_183));
    assign limb_14_184 = limb_14_183[15:0]; // decl: <none>; prim: <none>
    assign limb_14_185 = limb_14_183[16]; // decl: <none>; prim: <none>
    assign limb_14_186 = s8_norm_mul_9_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_14_187 = c0[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(limb_14_186)), .b(16'(rtlzz_pipe_187_s7)), .cin(limb_14_185), .value(limb_14_188));
    assign limb_14_189 = limb_14_188[15:0]; // decl: <none>; prim: <none>
    assign limb_14_190 = limb_14_188[16]; // decl: <none>; prim: <none>
    assign limb_14_191 = s8_norm_mul_9_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_14_192 = c0[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_193Core rtlzz_owner_193(.a(16'(limb_14_191)), .b(16'(rtlzz_pipe_192_s7)), .cin(limb_14_190), .value(limb_14_193));
    assign limb_14_194 = limb_14_193[15:0]; // decl: <none>; prim: <none>
    assign limb_14_195 = limb_14_193[16]; // decl: <none>; prim: <none>
    assign limb_14_196 = s8_norm_mul_9_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_14_197 = c0[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(16'(limb_14_196)), .b(16'(rtlzz_pipe_197_s7)), .cin(limb_14_195), .value(limb_14_198[15:0]));
    assign limb_14_198[16:16] = '0;
    assign limb_14_199 = limb_14_198[15:0]; // decl: <none>; prim: <none>
    assign limb_14_200 = {limb_14_199, limb_14_194, limb_14_189, limb_14_184}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_23_s1 <= 64'h0;
            rtlzz_pipe_27_s1 <= 96'h0;
            rtlzz_pipe_31_s1 <= 96'h0;
            rtlzz_pipe_35_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 97'h0;
            rtlzz_pipe_41_s2 <= 129'h0;
            rtlzz_pipe_121_s3 <= 16'h0;
            rtlzz_pipe_122_s1 <= 16'h0;
            rtlzz_pipe_122_s2 <= 16'h0;
            rtlzz_pipe_122_s3 <= 16'h0;
            rtlzz_pipe_124_s4 <= 16'h0;
            rtlzz_pipe_124_s5 <= 16'h0;
            rtlzz_pipe_125_s4 <= 1'h0;
            rtlzz_pipe_126_s3 <= 16'h0;
            rtlzz_pipe_126_s4 <= 16'h0;
            rtlzz_pipe_127_s1 <= 16'h0;
            rtlzz_pipe_127_s2 <= 16'h0;
            rtlzz_pipe_127_s3 <= 16'h0;
            rtlzz_pipe_127_s4 <= 16'h0;
            rtlzz_pipe_129_s5 <= 16'h0;
            rtlzz_pipe_130_s5 <= 1'h0;
            rtlzz_pipe_131_s3 <= 16'h0;
            rtlzz_pipe_131_s4 <= 16'h0;
            rtlzz_pipe_131_s5 <= 16'h0;
            rtlzz_pipe_132_s1 <= 16'h0;
            rtlzz_pipe_132_s2 <= 16'h0;
            rtlzz_pipe_132_s3 <= 16'h0;
            rtlzz_pipe_132_s4 <= 16'h0;
            rtlzz_pipe_132_s5 <= 16'h0;
            rtlzz_pipe_136_s3 <= 16'h0;
            rtlzz_pipe_136_s4 <= 16'h0;
            rtlzz_pipe_136_s5 <= 16'h0;
            rtlzz_pipe_137_s1 <= 16'h0;
            rtlzz_pipe_137_s2 <= 16'h0;
            rtlzz_pipe_137_s3 <= 16'h0;
            rtlzz_pipe_137_s4 <= 16'h0;
            rtlzz_pipe_137_s5 <= 16'h0;
            rtlzz_pipe_8_s6 <= 64'h0;
            rtlzz_pipe_63_s7 <= 97'h0;
            rtlzz_pipe_66_s7 <= 129'h0;
            rtlzz_pipe_142_s1 <= 16'h0;
            rtlzz_pipe_142_s2 <= 16'h0;
            rtlzz_pipe_142_s3 <= 16'h0;
            rtlzz_pipe_142_s4 <= 16'h0;
            rtlzz_pipe_142_s5 <= 16'h0;
            rtlzz_pipe_142_s6 <= 16'h0;
            rtlzz_pipe_142_s7 <= 16'h0;
            rtlzz_pipe_147_s1 <= 16'h0;
            rtlzz_pipe_147_s2 <= 16'h0;
            rtlzz_pipe_147_s3 <= 16'h0;
            rtlzz_pipe_147_s4 <= 16'h0;
            rtlzz_pipe_147_s5 <= 16'h0;
            rtlzz_pipe_147_s6 <= 16'h0;
            rtlzz_pipe_147_s7 <= 16'h0;
            rtlzz_pipe_152_s1 <= 16'h0;
            rtlzz_pipe_152_s2 <= 16'h0;
            rtlzz_pipe_152_s3 <= 16'h0;
            rtlzz_pipe_152_s4 <= 16'h0;
            rtlzz_pipe_152_s5 <= 16'h0;
            rtlzz_pipe_152_s6 <= 16'h0;
            rtlzz_pipe_152_s7 <= 16'h0;
            rtlzz_pipe_157_s1 <= 16'h0;
            rtlzz_pipe_157_s2 <= 16'h0;
            rtlzz_pipe_157_s3 <= 16'h0;
            rtlzz_pipe_157_s4 <= 16'h0;
            rtlzz_pipe_157_s5 <= 16'h0;
            rtlzz_pipe_157_s6 <= 16'h0;
            rtlzz_pipe_157_s7 <= 16'h0;
            rtlzz_pipe_162_s1 <= 16'h0;
            rtlzz_pipe_162_s2 <= 16'h0;
            rtlzz_pipe_162_s3 <= 16'h0;
            rtlzz_pipe_162_s4 <= 16'h0;
            rtlzz_pipe_162_s5 <= 16'h0;
            rtlzz_pipe_162_s6 <= 16'h0;
            rtlzz_pipe_162_s7 <= 16'h0;
            rtlzz_pipe_167_s1 <= 16'h0;
            rtlzz_pipe_167_s2 <= 16'h0;
            rtlzz_pipe_167_s3 <= 16'h0;
            rtlzz_pipe_167_s4 <= 16'h0;
            rtlzz_pipe_167_s5 <= 16'h0;
            rtlzz_pipe_167_s6 <= 16'h0;
            rtlzz_pipe_167_s7 <= 16'h0;
            rtlzz_pipe_172_s1 <= 16'h0;
            rtlzz_pipe_172_s2 <= 16'h0;
            rtlzz_pipe_172_s3 <= 16'h0;
            rtlzz_pipe_172_s4 <= 16'h0;
            rtlzz_pipe_172_s5 <= 16'h0;
            rtlzz_pipe_172_s6 <= 16'h0;
            rtlzz_pipe_172_s7 <= 16'h0;
            rtlzz_pipe_177_s1 <= 16'h0;
            rtlzz_pipe_177_s2 <= 16'h0;
            rtlzz_pipe_177_s3 <= 16'h0;
            rtlzz_pipe_177_s4 <= 16'h0;
            rtlzz_pipe_177_s5 <= 16'h0;
            rtlzz_pipe_177_s6 <= 16'h0;
            rtlzz_pipe_177_s7 <= 16'h0;
            rtlzz_pipe_182_s1 <= 16'h0;
            rtlzz_pipe_182_s2 <= 16'h0;
            rtlzz_pipe_182_s3 <= 16'h0;
            rtlzz_pipe_182_s4 <= 16'h0;
            rtlzz_pipe_182_s5 <= 16'h0;
            rtlzz_pipe_182_s6 <= 16'h0;
            rtlzz_pipe_182_s7 <= 16'h0;
            rtlzz_pipe_187_s1 <= 16'h0;
            rtlzz_pipe_187_s2 <= 16'h0;
            rtlzz_pipe_187_s3 <= 16'h0;
            rtlzz_pipe_187_s4 <= 16'h0;
            rtlzz_pipe_187_s5 <= 16'h0;
            rtlzz_pipe_187_s6 <= 16'h0;
            rtlzz_pipe_187_s7 <= 16'h0;
            rtlzz_pipe_192_s1 <= 16'h0;
            rtlzz_pipe_192_s2 <= 16'h0;
            rtlzz_pipe_192_s3 <= 16'h0;
            rtlzz_pipe_192_s4 <= 16'h0;
            rtlzz_pipe_192_s5 <= 16'h0;
            rtlzz_pipe_192_s6 <= 16'h0;
            rtlzz_pipe_192_s7 <= 16'h0;
            rtlzz_pipe_197_s1 <= 16'h0;
            rtlzz_pipe_197_s2 <= 16'h0;
            rtlzz_pipe_197_s3 <= 16'h0;
            rtlzz_pipe_197_s4 <= 16'h0;
            rtlzz_pipe_197_s5 <= 16'h0;
            rtlzz_pipe_197_s6 <= 16'h0;
            rtlzz_pipe_197_s7 <= 16'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_17_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_17_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_17_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_17_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= mul_tree_17_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= mul_tree_17_41; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_121_s3 <= limb_8_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= limb_8_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= limb_8_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= limb_8_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_126_s3 <= limb_8_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_126_s4 <= rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_127_s1 <= limb_8_127; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_127_s2 <= rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_127_s3 <= rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_127_s4 <= rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_129_s5 <= limb_8_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_130_s5 <= limb_8_130; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_131_s3 <= limb_8_131; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_131_s4 <= rtlzz_pipe_131_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_131_s5 <= rtlzz_pipe_131_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_132_s1 <= limb_8_132; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_132_s2 <= rtlzz_pipe_132_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_132_s3 <= rtlzz_pipe_132_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_132_s4 <= rtlzz_pipe_132_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_132_s5 <= rtlzz_pipe_132_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_136_s3 <= limb_8_136; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_136_s4 <= rtlzz_pipe_136_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_136_s5 <= rtlzz_pipe_136_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_137_s1 <= limb_8_137; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_137_s2 <= rtlzz_pipe_137_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_137_s3 <= rtlzz_pipe_137_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_137_s4 <= rtlzz_pipe_137_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_137_s5 <= rtlzz_pipe_137_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_8_s6 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_63_s7 <= mul_tree_18_63; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_66_s7 <= mul_tree_18_66; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_142_s1 <= limb_10_142; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_142_s2 <= rtlzz_pipe_142_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_142_s3 <= rtlzz_pipe_142_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_142_s4 <= rtlzz_pipe_142_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_142_s5 <= rtlzz_pipe_142_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_142_s6 <= rtlzz_pipe_142_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_142_s7 <= rtlzz_pipe_142_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_147_s1 <= limb_10_147; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_147_s2 <= rtlzz_pipe_147_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_147_s3 <= rtlzz_pipe_147_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_147_s4 <= rtlzz_pipe_147_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_147_s5 <= rtlzz_pipe_147_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_147_s6 <= rtlzz_pipe_147_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_147_s7 <= rtlzz_pipe_147_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= limb_10_152; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_152_s2 <= rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_152_s3 <= rtlzz_pipe_152_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_152_s4 <= rtlzz_pipe_152_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_152_s5 <= rtlzz_pipe_152_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_152_s6 <= rtlzz_pipe_152_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_152_s7 <= rtlzz_pipe_152_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_157_s1 <= limb_10_157; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_157_s2 <= rtlzz_pipe_157_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_157_s3 <= rtlzz_pipe_157_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_157_s4 <= rtlzz_pipe_157_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_157_s5 <= rtlzz_pipe_157_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_157_s6 <= rtlzz_pipe_157_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_157_s7 <= rtlzz_pipe_157_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= limb_12_162; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_162_s3 <= rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_162_s4 <= rtlzz_pipe_162_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_162_s5 <= rtlzz_pipe_162_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_162_s6 <= rtlzz_pipe_162_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_162_s7 <= rtlzz_pipe_162_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_167_s1 <= limb_12_167; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_167_s2 <= rtlzz_pipe_167_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_167_s3 <= rtlzz_pipe_167_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_167_s4 <= rtlzz_pipe_167_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_167_s5 <= rtlzz_pipe_167_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_167_s6 <= rtlzz_pipe_167_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_167_s7 <= rtlzz_pipe_167_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_172_s1 <= limb_12_172; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_172_s2 <= rtlzz_pipe_172_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_172_s3 <= rtlzz_pipe_172_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_172_s4 <= rtlzz_pipe_172_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_172_s5 <= rtlzz_pipe_172_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_172_s6 <= rtlzz_pipe_172_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= rtlzz_pipe_172_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_177_s1 <= limb_12_177; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_177_s2 <= rtlzz_pipe_177_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_177_s3 <= rtlzz_pipe_177_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_177_s4 <= rtlzz_pipe_177_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_177_s5 <= rtlzz_pipe_177_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_177_s6 <= rtlzz_pipe_177_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_177_s7 <= rtlzz_pipe_177_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_182_s1 <= limb_14_182; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_182_s2 <= rtlzz_pipe_182_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_182_s3 <= rtlzz_pipe_182_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_182_s4 <= rtlzz_pipe_182_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_182_s5 <= rtlzz_pipe_182_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_182_s6 <= rtlzz_pipe_182_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_182_s7 <= rtlzz_pipe_182_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_187_s1 <= limb_14_187; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_187_s2 <= rtlzz_pipe_187_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_187_s3 <= rtlzz_pipe_187_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_187_s4 <= rtlzz_pipe_187_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_187_s5 <= rtlzz_pipe_187_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_187_s6 <= rtlzz_pipe_187_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_187_s7 <= rtlzz_pipe_187_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_192_s1 <= limb_14_192; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_192_s2 <= rtlzz_pipe_192_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_192_s3 <= rtlzz_pipe_192_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_192_s4 <= rtlzz_pipe_192_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_192_s5 <= rtlzz_pipe_192_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_192_s6 <= rtlzz_pipe_192_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_192_s7 <= rtlzz_pipe_192_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_197_s1 <= limb_14_197; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_197_s2 <= rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_197_s3 <= rtlzz_pipe_197_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_197_s4 <= rtlzz_pipe_197_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_197_s5 <= rtlzz_pipe_197_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_197_s6 <= rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_197_s7 <= rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94_reduce(input wire [63:0] i73, input wire [63:0] i76, input wire [63:0] i80, output wire [129:0] y);
wire [63:0] t0 = {i73[63], i73[62], i73[61], i73[60], i73[59], i73[58], i73[57], i73[56], i73[55], i73[54], i73[53], i73[52], i73[51], i73[50], i73[49], i73[48], i73[47], i73[46], i73[45], i73[44], i73[43], i73[42], i73[41], i73[40], i73[39], i73[38], i73[37], i73[36], i73[35], i73[34], i73[33], i73[32], i73[31], i73[30], i73[29], i73[28], i73[27], i73[26], i73[25], i73[24], i73[23], i73[22], i73[21], i73[20], i73[19], i73[18], i73[17], i73[16], i73[15], i73[14], i73[13], i73[12], i73[11], i73[10], i73[9], i73[8], i73[7], i73[6], i73[5], i73[4], i73[3], i73[2], i73[1], i73[0]};
wire [63:0] t1 = {i76[31], i76[30], i76[29], i76[28], i76[27], i76[26], i76[25], i76[24], i76[23], i76[22], i76[21], i76[20], i76[19], i76[18], i76[17], i76[16], i76[15], i76[14], i76[13], i76[12], i76[11], i76[10], i76[9], i76[8], i76[7], i76[6], i76[5], i76[4], i76[3], i76[2], i76[1], i76[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i80[31], i80[30], i80[29], i80[28], i80[27], i80[26], i80[25], i80[24], i80[23], i80[22], i80[21], i80[20], i80[19], i80[18], i80[17], i80[16], i80[15], i80[14], i80[13], i80[12], i80[11], i80[10], i80[9], i80[8], i80[7], i80[6], i80[5], i80[4], i80[3], i80[2], i80[1], i80[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_119_reduce(input wire [63:0] i98, input wire [63:0] i101, input wire [63:0] i105, output wire [129:0] y);
wire [63:0] t0 = {i98[63], i98[62], i98[61], i98[60], i98[59], i98[58], i98[57], i98[56], i98[55], i98[54], i98[53], i98[52], i98[51], i98[50], i98[49], i98[48], i98[47], i98[46], i98[45], i98[44], i98[43], i98[42], i98[41], i98[40], i98[39], i98[38], i98[37], i98[36], i98[35], i98[34], i98[33], i98[32], i98[31], i98[30], i98[29], i98[28], i98[27], i98[26], i98[25], i98[24], i98[23], i98[22], i98[21], i98[20], i98[19], i98[18], i98[17], i98[16], i98[15], i98[14], i98[13], i98[12], i98[11], i98[10], i98[9], i98[8], i98[7], i98[6], i98[5], i98[4], i98[3], i98[2], i98[1], i98[0]};
wire [63:0] t1 = {i101[31], i101[30], i101[29], i101[28], i101[27], i101[26], i101[25], i101[24], i101[23], i101[22], i101[21], i101[20], i101[19], i101[18], i101[17], i101[16], i101[15], i101[14], i101[13], i101[12], i101[11], i101[10], i101[9], i101[8], i101[7], i101[6], i101[5], i101[4], i101[3], i101[2], i101[1], i101[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i105[31], i105[30], i105[29], i105[28], i105[27], i105[26], i105[25], i105[24], i105[23], i105[22], i105[21], i105[20], i105[19], i105[18], i105[17], i105[16], i105[15], i105[14], i105[13], i105[12], i105[11], i105[10], i105[9], i105[8], i105[7], i105[6], i105[5], i105[4], i105[3], i105[2], i105[1], i105[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [63:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [63:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_153Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_153();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
