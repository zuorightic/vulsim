`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [15:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [31:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5Core rtlzz_owner_5(.a(64'(rtlzz_pipe_4_s2)), .b(64'(rtlzz_pipe_2_s2)), .cin(1'b0), .value(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_37; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(16'(mul_tree_12_13)), .b(16'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(16'(mul_tree_12_16)), .b(16'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(16'(mul_tree_12_20)), .b(16'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(16'(mul_tree_12_24)), .b(16'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = ({17'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_29 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = ({17'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_32 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_34 = ({17'h0, mul_tree_12_30}); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = ({1'h0, mul_tree_12_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36_reduce rtlzz_reduce_36(.i40(rtlzz_pipe_15_s1), .i41(rtlzz_pipe_19_s1), .i42(rtlzz_pipe_23_s1), .i43(rtlzz_pipe_27_s1), .y(mul_tree_12_36));
    assign mul_tree_12_37 = mul_tree_12_36[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_15_s1 <= 32'h0;
            rtlzz_pipe_19_s1 <= 48'h0;
            rtlzz_pipe_23_s1 <= 48'h0;
            rtlzz_pipe_27_s1 <= 64'h0;
            rtlzz_pipe_4_s2 <= 64'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36_reduce(input wire [31:0] i40, input wire [47:0] i41, input wire [47:0] i42, input wire [63:0] i43, output wire [65:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i40[31], i40[30], i40[29], i40[28], i40[27], i40[26], i40[25], i40[24], i40[23], i40[22], i40[21], i40[20], i40[19], i40[18], i40[17], i40[16], i40[15], i40[14], i40[13], i40[12], i40[11], i40[10], i40[9], i40[8], i40[7], i40[6], i40[5], i40[4], i40[3], i40[2], i40[1], i40[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i41[47], i41[46], i41[45], i41[44], i41[43], i41[42], i41[41], i41[40], i41[39], i41[38], i41[37], i41[36], i41[35], i41[34], i41[33], i41[32], i41[31], i41[30], i41[29], i41[28], i41[27], i41[26], i41[25], i41[24], i41[23], i41[22], i41[21], i41[20], i41[19], i41[18], i41[17], i41[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i42[47], i42[46], i42[45], i42[44], i42[43], i42[42], i42[41], i42[40], i42[39], i42[38], i42[37], i42[36], i42[35], i42[34], i42[33], i42[32], i42[31], i42[30], i42[29], i42[28], i42[27], i42[26], i42[25], i42[24], i42[23], i42[22], i42[21], i42[20], i42[19], i42[18], i42[17], i42[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i43[63], i43[62], i43[61], i43[60], i43[59], i43[58], i43[57], i43[56], i43[55], i43[54], i43[53], i43[52], i43[51], i43[50], i43[49], i43[48], i43[47], i43[46], i43[45], i43[44], i43[43], i43[42], i43[41], i43[40], i43[39], i43[38], i43[37], i43[36], i43[35], i43[34], i43[33], i43[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
