`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [15:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [48:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_33_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5_reduce rtlzz_reduce_5(.i39(rtlzz_pipe_2_s2), .i41(rtlzz_pipe_30_s2), .i43(rtlzz_pipe_33_s2), .y(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_37; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(16'(mul_tree_12_13)), .b(16'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(16'(mul_tree_12_16)), .b(16'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(16'(mul_tree_12_20)), .b(16'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(16'(mul_tree_12_24)), .b(16'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = ({17'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_29 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(32'(mul_tree_12_28)), .b(48'(mul_tree_12_29)), .cin(1'h0), .value(mul_tree_12_30));
    assign mul_tree_12_31 = ({17'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_32 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_33Core rtlzz_owner_33(.a(48'(mul_tree_12_31)), .b(64'(mul_tree_12_32)), .cin(1'h0), .value(mul_tree_12_33[63:0]));
    assign mul_tree_12_33[64:64] = '0;
    assign mul_tree_12_34 = ({17'h0, rtlzz_pipe_30_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = ({1'h0, rtlzz_pipe_33_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_tree_12_36[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_30_s1 <= 49'h0;
            rtlzz_pipe_30_s2 <= 49'h0;
            rtlzz_pipe_33_s1 <= 65'h0;
            rtlzz_pipe_33_s2 <= 65'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_12_30; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_12_33; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5_reduce(input wire [63:0] i39, input wire [48:0] i41, input wire [64:0] i43, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i41[48], i41[47], i41[46], i41[45], i41[44], i41[43], i41[42], i41[41], i41[40], i41[39], i41[38], i41[37], i41[36], i41[35], i41[34], i41[33], i41[32], i41[31], i41[30], i41[29], i41[28], i41[27], i41[26], i41[25], i41[24], i41[23], i41[22], i41[21], i41[20], i41[19], i41[18], i41[17], i41[16], i41[15], i41[14], i41[13], i41[12], i41[11], i41[10], i41[9], i41[8], i41[7], i41[6], i41[5], i41[4], i41[3], i41[2], i41[1], i41[0]};
wire [63:0] t1 = {i43[63], i43[62], i43[61], i43[60], i43[59], i43[58], i43[57], i43[56], i43[55], i43[54], i43[53], i43[52], i43[51], i43[50], i43[49], i43[48], i43[47], i43[46], i43[45], i43[44], i43[43], i43[42], i43[41], i43[40], i43[39], i43[38], i43[37], i43[36], i43[35], i43[34], i43[33], i43[32], i43[31], i43[30], i43[29], i43[28], i43[27], i43[26], i43[25], i43[24], i43[23], i43[22], i43[21], i43[20], i43[19], i43[18], i43[17], i43[16], i43[15], i43[14], i43[13], i43[12], i43[11], i43[10], i43[9], i43[8], i43[7], i43[6], i43[5], i43[4], i43[3], i43[2], i43[1], i43[0]};
wire [63:0] t2 = {i39[63], i39[62], i39[61], i39[60], i39[59], i39[58], i39[57], i39[56], i39[55], i39[54], i39[53], i39[52], i39[51], i39[50], i39[49], i39[48], i39[47], i39[46], i39[45], i39[44], i39[43], i39[42], i39[41], i39[40], i39[39], i39[38], i39[37], i39[36], i39[35], i39[34], i39[33], i39[32], i39[31], i39[30], i39[29], i39[28], i39[27], i39[26], i39[25], i39[24], i39[23], i39[22], i39[21], i39[20], i39[19], i39[18], i39[17], i39[16], i39[15], i39[14], i39[13], i39[12], i39[11], i39[10], i39[9], i39[8], i39[7], i39[6], i39[5], i39[4], i39[3], i39[2], i39[1], i39[0]};
wire [63:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_33Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_33();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
