`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [512:0] rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s7; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_84_s1; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_234_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_164_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] rtlzz_pipe_165_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_238_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] rtlzz_pipe_239_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [65:0] rtlzz_pipe_180_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [128:0] rtlzz_pipe_248_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [33:0] rtlzz_pipe_198_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_94_s3; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_206_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_249_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [33:0] rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_114_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [63:0] rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] rtlzz_pipe_284_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_256_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_113_s4; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [33:0] rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_210_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_211_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_288_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_290_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_260_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] rtlzz_pipe_291_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_261_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_299_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_305_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_319_s7; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_323_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s5; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_37_s2; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s3; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [255:0] rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_44_s5; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] rtlzz_pipe_45_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [129:0] rtlzz_pipe_39_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [255:0] rtlzz_pipe_222_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [67:0] rtlzz_pipe_28_s7; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_79_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [129:0] rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] rtlzz_pipe_75_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [255:0] rtlzz_pipe_82_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] rtlzz_pipe_82_s4; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [255:0] rtlzz_pipe_83_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [129:0] rtlzz_pipe_77_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [255:0] rtlzz_pipe_220_s7; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [67:0] rtlzz_pipe_102_s4; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] rtlzz_pipe_102_s5; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [129:0] rtlzz_pipe_202_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_106_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_203_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_108_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [131:0] rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] rtlzz_pipe_139_s6; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [257:0] rtlzz_pipe_145_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] rtlzz_pipe_145_s6; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [131:0] rtlzz_pipe_132_s5; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] rtlzz_pipe_132_s6; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [67:0] rtlzz_pipe_128_s5; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [131:0] rtlzz_pipe_119_s6; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [67:0] rtlzz_pipe_130_s6; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] rtlzz_pipe_129_s6; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [257:0] rtlzz_pipe_219_s7; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(65'(rtlzz_pipe_12_s5)), .b(65'(rtlzz_pipe_234_s5)), .cin(1'b0), .value(s8_norm_add_18_v0));
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(65'(tmp_workload_top_int_65__23_v0)), .b(65'(rtlzz_pipe_235_s4)), .cin(1'b0), .value(s8_norm_add_21_v0));
    assign tmp_workload_top_int_66__32_v0 = (rtlzz_pipe_164_s6 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (rtlzz_pipe_165_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_21Core rtlzz_owner_21(.a(34'(tmp_workload_top_int_34__42_v0)), .b(34'(rtlzz_pipe_238_s7)), .cin(1'b0), .value(s8_norm_add_36_v0));
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(34'(tmp_workload_top_int_34__47_v0)), .b(34'(rtlzz_pipe_239_s6)), .cin(1'b0), .value(s8_norm_add_39_v0));
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_29Core rtlzz_owner_29(.a(68'(n20_v0)), .b(68'(rtlzz_pipe_28_s7)), .cin(1'b0), .value(s8_norm_sub_45_v0));
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_31Core rtlzz_owner_31(.a(68'(s8_norm_sub_45_v0)), .b(68'(tmp_workload_top_int_68__60_v0)), .cin(1'b0), .value(s8_norm_sub_47_v0));
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (__beopt_width_560 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (__beopt_width_561 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(130'(__beopt_width_317)), .b(130'(rtlzz_pipe_37_s7)), .cin(1'b0), .value(s8_norm_sub_56_v0));
    assign tmp_workload_top_int_130__76_v0 = (__beopt_width_562 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(130'(s8_norm_sub_56_v0)), .b(130'(rtlzz_pipe_39_s7)), .cin(1'b0), .value(s8_norm_sub_58_v0));
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s6 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s4 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_44_s5 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(65'(tmp_workload_top_int_65__103_v0)), .b(65'(rtlzz_pipe_242_s6)), .cin(1'b0), .value(s8_norm_add_80_v0));
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(65'(tmp_workload_top_int_65__108_v0)), .b(65'(rtlzz_pipe_243_s7)), .cin(1'b0), .value(s8_norm_add_83_v0));
    assign tmp_workload_top_int_66__117_v0 = (rtlzz_pipe_180_s7 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (__beopt_width_579 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_59Core rtlzz_owner_59(.a(34'(tmp_workload_top_int_34__127_v0)), .b(34'(__beopt_width_367)), .cin(1'b0), .value(s8_norm_add_98_v0));
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(34'(tmp_workload_top_int_34__132_v0)), .b(34'(__beopt_width_370)), .cin(1'b0), .value(s8_norm_add_101_v0));
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(68'(n41_v0)), .b(68'(tmp_workload_top_int_68__142_v0)), .cin(1'b0), .value(s8_norm_sub_107_v0));
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_69Core rtlzz_owner_69(.a(68'(s8_norm_sub_107_v0)), .b(68'(tmp_workload_top_int_68__145_v0)), .cin(1'b0), .value(s8_norm_sub_109_v0));
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(130'(__beopt_width_313)), .b(130'(rtlzz_pipe_75_s7)), .cin(1'b0), .value(s8_norm_sub_118_v0));
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(130'(s8_norm_sub_118_v0)), .b(130'(rtlzz_pipe_77_s7)), .cin(1'b0), .value(s8_norm_sub_120_v0));
    assign tmp_workload_top_int_256__164_v0 = (s8_norm_mul_72_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_82_s4 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(129'(rtlzz_pipe_84_s1)), .b(129'(rtlzz_pipe_248_s1)), .cin(1'b0), .value(s8_norm_add_130_v0));
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_87Core rtlzz_owner_87(.a(129'(tmp_workload_top_int_129__179_v0)), .b(129'(rtlzz_pipe_249_s1)), .cin(1'b0), .value(s8_norm_add_133_v0));
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (rtlzz_pipe_114_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s2 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(34'(rtlzz_pipe_94_s3)), .b(34'(__beopt_width_388)), .cin(1'b0), .value(s8_norm_add_152_v0));
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(34'(tmp_workload_top_int_34__207_v0)), .b(34'(rtlzz_pipe_253_s5)), .cin(1'b0), .value(s8_norm_add_155_v0));
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (__beopt_width_609 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(68'(n60_v0)), .b(68'(rtlzz_pipe_102_s5)), .cin(1'b0), .value(s8_norm_sub_161_v0));
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105Core rtlzz_owner_105(.a(68'(s8_norm_sub_161_v0)), .b(68'(tmp_workload_top_int_68__220_v0)), .cin(1'b0), .value(s8_norm_sub_163_v0));
    assign tmp_workload_top_int_130__223_v0 = (rtlzz_pipe_202_s4 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s6 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (rtlzz_pipe_206_s3 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_113Core rtlzz_owner_113(.a(66'(tmp_workload_top_int_66__238_v0)), .b(66'(rtlzz_pipe_256_s3)), .cin(1'b0), .value(s8_norm_add_177_v0));
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115Core rtlzz_owner_115(.a(66'(tmp_workload_top_int_66__243_v0)), .b(66'(__beopt_width_404)), .cin(1'b0), .value(s8_norm_add_180_v0));
    assign tmp_workload_top_int_66__252_v0 = (rtlzz_pipe_113_s4 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (rtlzz_pipe_210_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_121Core rtlzz_owner_121(.a(34'(tmp_workload_top_int_34__262_v0)), .b(34'(rtlzz_pipe_260_s5)), .cin(1'b0), .value(s8_norm_add_195_v0));
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(34'(tmp_workload_top_int_34__267_v0)), .b(34'(rtlzz_pipe_261_s3)), .cin(1'b0), .value(s8_norm_add_198_v0));
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(68'(n74_v0)), .b(68'(rtlzz_pipe_128_s5)), .cin(1'b0), .value(s8_norm_sub_204_v0));
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(68'(rtlzz_pipe_129_s6)), .b(68'(rtlzz_pipe_130_s6)), .cin(1'b0), .value(s8_norm_sub_206_v0));
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (rtlzz_pipe_119_s6 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(132'(__beopt_width_307)), .b(130'(tmp_workload_top_int_132__293_v0)), .cin(1'b0), .value(s8_norm_sub_215_v0));
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(132'(s8_norm_sub_215_v0)), .b(132'(rtlzz_pipe_139_s6)), .cin(1'b0), .value(s8_norm_sub_217_v0));
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__305_v0 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_147Core rtlzz_owner_147(.a(258'(rtlzz_pipe_219_s7)), .b(256'(tmp_workload_top_int_258__309_v0)), .cin(1'b0), .value(s8_norm_sub_226_v0));
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_149Core rtlzz_owner_149(.a(258'(s8_norm_sub_226_v0)), .b(256'(tmp_workload_top_int_258__312_v0)), .cin(1'b0), .value(s8_norm_sub_228_v0));
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_157Core rtlzz_owner_157(.a(512'(tmp_workload_top_int_513__325_v0)), .b(512'(rtlzz_pipe_156_s7)), .cin(1'b0), .value(s8_norm_add_238_v0));
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_217_reduce rtlzz_reduce_217(.i152(s8_norm_shift_231_v0), .i154(s8_norm_shift_234_v0), .i223(__beopt_width_303), .y(__beopt_width_294));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_219_reduce rtlzz_reduce_219(.i143(s8_norm_shift_220_v0), .i227(__beopt_width_310), .i555(rtlzz_pipe_145_s6), .y(__beopt_width_297));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(256'(rtlzz_pipe_79_s6)), .b(256'(rtlzz_pipe_83_s6)), .cin(1'b0), .value(__beopt_width_299));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_221Core rtlzz_owner_221(.a(256'(rtlzz_pipe_220_s7)), .b(256'(s8_norm_shift_123_v0)), .cin(1'b0), .value(__beopt_width_301));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_222Core rtlzz_owner_222(.a(256'(tmp_workload_top_int_256__79_v0)), .b(256'(rtlzz_pipe_45_s6)), .cin(1'b0), .value(__beopt_width_302));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223Core rtlzz_owner_223(.a(256'(rtlzz_pipe_222_s7)), .b(256'(s8_norm_shift_61_v0)), .cin(1'b0), .value(__beopt_width_303));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_225_reduce rtlzz_reduce_225(.i134(s8_norm_shift_209_v0), .i136(s8_norm_shift_212_v0), .i557(rtlzz_pipe_132_s6), .y(__beopt_width_307));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_227_reduce rtlzz_reduce_227(.i110(s8_norm_shift_169_v0), .i549(rtlzz_pipe_106_s6), .i551(rtlzz_pipe_108_s6), .y(__beopt_width_310));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_229_reduce rtlzz_reduce_229(.i72(s8_norm_shift_112_v0), .i74(s8_norm_shift_115_v0), .i350(arith_original_350), .y(__beopt_width_313));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_231_reduce rtlzz_reduce_231(.i34(s8_norm_shift_50_v0), .i36(s8_norm_shift_53_v0), .i530(rtlzz_pipe_28_s7), .y(__beopt_width_317));
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (__beopt_width_325 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (__beopt_width_337 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (__beopt_width_340 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s1 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (rtlzz_pipe_272_s3 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s2 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (__beopt_width_362 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (__beopt_width_380 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (__beopt_width_386 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (__beopt_width_399 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (rtlzz_pipe_285_s4 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s2 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (__beopt_width_413 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (rtlzz_pipe_288_s4 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s5 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (rtlzz_pipe_290_s4 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s2 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(64'(rtlzz_pipe_292_s1)), .b(64'(mul_precision_293)), .cin(1'b0), .value(arith_original_343));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_344Core rtlzz_owner_344(.a(64'(rtlzz_pipe_295_s3)), .b(64'(mul_precision_296)), .cin(1'b0), .value(arith_original_344));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_345Core rtlzz_owner_345(.a(33'(mul_precision_298)), .b(33'(rtlzz_pipe_299_s6)), .cin(1'b0), .value(arith_original_345));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_346Core rtlzz_owner_346(.a(32'(mul_precision_301)), .b(32'(rtlzz_pipe_302_s7)), .cin(1'b0), .value(arith_original_346));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_347Core rtlzz_owner_347(.a(34'(mul_precision_304)), .b(34'(rtlzz_pipe_305_s7)), .cin(1'b0), .value(arith_original_347));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(64'(rtlzz_pipe_307_s5)), .b(64'(mul_precision_308)), .cin(1'b0), .value(arith_original_348));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_349Core rtlzz_owner_349(.a(64'(rtlzz_pipe_310_s2)), .b(64'(mul_precision_311)), .cin(1'b0), .value(arith_original_349));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_350Core rtlzz_owner_350(.a(33'(mul_precision_313)), .b(33'(mul_precision_314)), .cin(1'b0), .value(arith_original_350));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(32'(rtlzz_pipe_316_s7)), .b(32'(mul_precision_317)), .cin(1'b0), .value(arith_original_351));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_352Core rtlzz_owner_352(.a(34'(rtlzz_pipe_319_s7)), .b(34'(mul_precision_320)), .cin(1'b0), .value(arith_original_352));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_353Core rtlzz_owner_353(.a(33'(mul_precision_322)), .b(33'(rtlzz_pipe_323_s3)), .cin(1'b0), .value(arith_original_353));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(32'(rtlzz_pipe_325_s5)), .b(32'(mul_precision_326)), .cin(1'b0), .value(arith_original_354));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(34'(rtlzz_pipe_328_s5)), .b(34'(mul_precision_329)), .cin(1'b0), .value(arith_original_355));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_356Core rtlzz_owner_356(.a(64'(rtlzz_pipe_331_s4)), .b(64'(mul_precision_332)), .cin(1'b0), .value(arith_original_356));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_357Core rtlzz_owner_357(.a(33'(mul_precision_334)), .b(33'(rtlzz_pipe_335_s4)), .cin(1'b0), .value(arith_original_357));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(33'(rtlzz_pipe_337_s5)), .b(33'(mul_precision_338)), .cin(1'b0), .value(arith_original_358));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(34'(mul_precision_340)), .b(34'(rtlzz_pipe_341_s5)), .cin(1'b0), .value(arith_original_359));
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_156_s1 <= 513'h0;
            rtlzz_pipe_156_s2 <= 513'h0;
            rtlzz_pipe_156_s3 <= 513'h0;
            rtlzz_pipe_156_s4 <= 513'h0;
            rtlzz_pipe_156_s5 <= 513'h0;
            rtlzz_pipe_156_s6 <= 513'h0;
            rtlzz_pipe_156_s7 <= 513'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_12_s3 <= 65'h0;
            rtlzz_pipe_12_s4 <= 65'h0;
            rtlzz_pipe_12_s5 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_84_s1 <= 129'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_234_s5 <= 65'h0;
            rtlzz_pipe_164_s6 <= 66'h0;
            rtlzz_pipe_168_s6 <= 34'h0;
            rtlzz_pipe_168_s7 <= 34'h0;
            rtlzz_pipe_235_s1 <= 65'h0;
            rtlzz_pipe_235_s2 <= 65'h0;
            rtlzz_pipe_235_s3 <= 65'h0;
            rtlzz_pipe_235_s4 <= 65'h0;
            rtlzz_pipe_165_s5 <= 66'h0;
            rtlzz_pipe_169_s5 <= 34'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_266_s6 <= 64'h0;
            rtlzz_pipe_266_s7 <= 64'h0;
            rtlzz_pipe_238_s6 <= 34'h0;
            rtlzz_pipe_238_s7 <= 34'h0;
            rtlzz_pipe_239_s5 <= 34'h0;
            rtlzz_pipe_239_s6 <= 34'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_272_s1 <= 65'h0;
            rtlzz_pipe_272_s2 <= 65'h0;
            rtlzz_pipe_272_s3 <= 65'h0;
            rtlzz_pipe_242_s4 <= 65'h0;
            rtlzz_pipe_242_s5 <= 65'h0;
            rtlzz_pipe_242_s6 <= 65'h0;
            rtlzz_pipe_180_s7 <= 66'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_273_s2 <= 65'h0;
            rtlzz_pipe_243_s3 <= 65'h0;
            rtlzz_pipe_243_s4 <= 65'h0;
            rtlzz_pipe_243_s5 <= 65'h0;
            rtlzz_pipe_243_s6 <= 65'h0;
            rtlzz_pipe_243_s7 <= 65'h0;
            rtlzz_pipe_248_s1 <= 129'h0;
            rtlzz_pipe_198_s2 <= 34'h0;
            rtlzz_pipe_94_s3 <= 34'h0;
            rtlzz_pipe_206_s2 <= 66'h0;
            rtlzz_pipe_206_s3 <= 66'h0;
            rtlzz_pipe_249_s1 <= 129'h0;
            rtlzz_pipe_199_s2 <= 34'h0;
            rtlzz_pipe_199_s3 <= 34'h0;
            rtlzz_pipe_199_s4 <= 34'h0;
            rtlzz_pipe_199_s5 <= 34'h0;
            rtlzz_pipe_114_s2 <= 66'h0;
            rtlzz_pipe_280_s2 <= 64'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_280_s4 <= 64'h0;
            rtlzz_pipe_281_s2 <= 64'h0;
            rtlzz_pipe_281_s3 <= 64'h0;
            rtlzz_pipe_281_s4 <= 64'h0;
            rtlzz_pipe_281_s5 <= 64'h0;
            rtlzz_pipe_282_s2 <= 34'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_253_s2 <= 34'h0;
            rtlzz_pipe_253_s3 <= 34'h0;
            rtlzz_pipe_253_s4 <= 34'h0;
            rtlzz_pipe_253_s5 <= 34'h0;
            rtlzz_pipe_284_s2 <= 128'h0;
            rtlzz_pipe_285_s2 <= 128'h0;
            rtlzz_pipe_285_s3 <= 128'h0;
            rtlzz_pipe_285_s4 <= 128'h0;
            rtlzz_pipe_286_s2 <= 66'h0;
            rtlzz_pipe_256_s3 <= 66'h0;
            rtlzz_pipe_113_s4 <= 66'h0;
            rtlzz_pipe_210_s4 <= 34'h0;
            rtlzz_pipe_210_s5 <= 34'h0;
            rtlzz_pipe_115_s2 <= 66'h0;
            rtlzz_pipe_211_s2 <= 34'h0;
            rtlzz_pipe_211_s3 <= 34'h0;
            rtlzz_pipe_288_s4 <= 66'h0;
            rtlzz_pipe_289_s2 <= 66'h0;
            rtlzz_pipe_289_s3 <= 66'h0;
            rtlzz_pipe_289_s4 <= 66'h0;
            rtlzz_pipe_289_s5 <= 66'h0;
            rtlzz_pipe_290_s4 <= 34'h0;
            rtlzz_pipe_260_s5 <= 34'h0;
            rtlzz_pipe_291_s2 <= 34'h0;
            rtlzz_pipe_261_s3 <= 34'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_299_s6 <= 33'h0;
            rtlzz_pipe_302_s5 <= 32'h0;
            rtlzz_pipe_302_s6 <= 32'h0;
            rtlzz_pipe_302_s7 <= 32'h0;
            rtlzz_pipe_305_s7 <= 34'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s2 <= 64'h0;
            rtlzz_pipe_316_s7 <= 32'h0;
            rtlzz_pipe_319_s7 <= 34'h0;
            rtlzz_pipe_323_s3 <= 33'h0;
            rtlzz_pipe_325_s5 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_328_s5 <= 34'h0;
            rtlzz_pipe_331_s3 <= 64'h0;
            rtlzz_pipe_331_s4 <= 64'h0;
            rtlzz_pipe_335_s3 <= 33'h0;
            rtlzz_pipe_335_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_341_s4 <= 34'h0;
            rtlzz_pipe_341_s5 <= 34'h0;
            rtlzz_pipe_10_s2 <= 256'h0;
            rtlzz_pipe_10_s3 <= 256'h0;
            rtlzz_pipe_10_s4 <= 256'h0;
            rtlzz_pipe_10_s5 <= 256'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_37_s2 <= 130'h0;
            rtlzz_pipe_37_s3 <= 130'h0;
            rtlzz_pipe_37_s4 <= 130'h0;
            rtlzz_pipe_37_s5 <= 130'h0;
            rtlzz_pipe_37_s6 <= 130'h0;
            rtlzz_pipe_37_s7 <= 130'h0;
            rtlzz_pipe_11_s4 <= 256'h0;
            rtlzz_pipe_44_s5 <= 256'h0;
            rtlzz_pipe_45_s6 <= 256'h0;
            rtlzz_pipe_39_s4 <= 130'h0;
            rtlzz_pipe_39_s5 <= 130'h0;
            rtlzz_pipe_39_s6 <= 130'h0;
            rtlzz_pipe_39_s7 <= 130'h0;
            rtlzz_pipe_222_s7 <= 256'h0;
            rtlzz_pipe_28_s7 <= 68'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_79_s6 <= 256'h0;
            rtlzz_pipe_75_s6 <= 130'h0;
            rtlzz_pipe_75_s7 <= 130'h0;
            rtlzz_pipe_82_s3 <= 256'h0;
            rtlzz_pipe_82_s4 <= 256'h0;
            rtlzz_pipe_83_s5 <= 256'h0;
            rtlzz_pipe_83_s6 <= 256'h0;
            rtlzz_pipe_77_s3 <= 130'h0;
            rtlzz_pipe_77_s4 <= 130'h0;
            rtlzz_pipe_77_s5 <= 130'h0;
            rtlzz_pipe_77_s6 <= 130'h0;
            rtlzz_pipe_77_s7 <= 130'h0;
            rtlzz_pipe_220_s7 <= 256'h0;
            rtlzz_pipe_102_s4 <= 68'h0;
            rtlzz_pipe_102_s5 <= 68'h0;
            rtlzz_pipe_202_s4 <= 130'h0;
            rtlzz_pipe_106_s5 <= 130'h0;
            rtlzz_pipe_106_s6 <= 130'h0;
            rtlzz_pipe_203_s6 <= 130'h0;
            rtlzz_pipe_108_s6 <= 130'h0;
            rtlzz_pipe_139_s5 <= 132'h0;
            rtlzz_pipe_139_s6 <= 132'h0;
            rtlzz_pipe_145_s5 <= 258'h0;
            rtlzz_pipe_145_s6 <= 258'h0;
            rtlzz_pipe_132_s5 <= 132'h0;
            rtlzz_pipe_132_s6 <= 132'h0;
            rtlzz_pipe_128_s5 <= 68'h0;
            rtlzz_pipe_119_s6 <= 132'h0;
            rtlzz_pipe_130_s6 <= 68'h0;
            rtlzz_pipe_129_s6 <= 68'h0;
            rtlzz_pipe_219_s7 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_156_s2 <= rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_156_s3 <= rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_156_s4 <= rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_156_s5 <= rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_156_s6 <= rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_156_s7 <= rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_84_s1 <= tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_234_s5 <= __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_164_s6 <= __beopt_width_545; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_168_s6 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_168_s7 <= rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_235_s2 <= rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_235_s3 <= rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_235_s4 <= rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_165_s5 <= __beopt_width_546; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_169_s5 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_266_s6 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_266_s7 <= rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_238_s6 <= __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_238_s7 <= rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_239_s5 <= __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_239_s6 <= rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_272_s1 <= __beopt_width_353; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_272_s2 <= rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_272_s3 <= rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_242_s4 <= __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_242_s5 <= rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_242_s6 <= rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_180_s7 <= __beopt_width_573; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_273_s2 <= rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_243_s3 <= __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_243_s4 <= rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_243_s5 <= rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_243_s6 <= rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_243_s7 <= rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_248_s1 <= __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_198_s2 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_94_s3 <= tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_206_s2 <= __beopt_width_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_206_s3 <= rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_199_s2 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_199_s3 <= rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_199_s4 <= rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_199_s5 <= rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_280_s2 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_280_s4 <= rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_281_s2 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_281_s3 <= rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_281_s4 <= rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_281_s5 <= rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_282_s2 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_253_s2 <= __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_253_s3 <= rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_253_s4 <= rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_253_s5 <= rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_284_s2 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_285_s2 <= __beopt_width_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_285_s3 <= rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_285_s4 <= rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_286_s2 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_256_s3 <= __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_113_s4 <= s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_210_s4 <= __beopt_width_627; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_210_s5 <= rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_211_s2 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_211_s3 <= rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_288_s4 <= __beopt_width_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_289_s2 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_289_s3 <= rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_289_s4 <= rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_290_s4 <= __beopt_width_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_260_s5 <= __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_291_s2 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_261_s3 <= __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_299_s6 <= mul_precision_299; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_302_s5 <= mul_precision_302; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_302_s6 <= rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_302_s7 <= rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_305_s7 <= mul_precision_305; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_310_s2 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_316_s7 <= mul_precision_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_319_s7 <= mul_precision_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_323_s3 <= mul_precision_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_325_s5 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_328_s5 <= rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_331_s3 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_335_s3 <= mul_precision_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_341_s4 <= mul_precision_341; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_341_s5 <= rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_10_s3 <= rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_10_s4 <= rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_10_s5 <= rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_37_s3 <= rtlzz_pipe_37_s2; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_37_s4 <= rtlzz_pipe_37_s3; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_37_s5 <= rtlzz_pipe_37_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_37_s6 <= rtlzz_pipe_37_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_37_s7 <= rtlzz_pipe_37_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_11_s4 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_39_s4 <= tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_39_s5 <= rtlzz_pipe_39_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_39_s6 <= rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_39_s7 <= rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_222_s7 <= __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_28_s7 <= tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_75_s7 <= rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_82_s3 <= tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_82_s4 <= rtlzz_pipe_82_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_83_s5 <= s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_77_s3 <= tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_77_s4 <= rtlzz_pipe_77_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_77_s5 <= rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_77_s6 <= rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_77_s7 <= rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_220_s7 <= __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_102_s4 <= tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= rtlzz_pipe_102_s4; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_202_s4 <= __beopt_width_611; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_106_s6 <= rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_203_s6 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_108_s6 <= s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_139_s5 <= tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_139_s6 <= rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_145_s5 <= s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_145_s6 <= rtlzz_pipe_145_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_132_s5 <= tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_132_s6 <= rtlzz_pipe_132_s5; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_128_s5 <= tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_119_s6 <= s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_130_s6 <= tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_129_s6 <= s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_219_s7 <= __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_217_reduce(input wire [511:0] i152, input wire [511:0] i154, input wire [255:0] i223, output wire [511:0] y);
wire [511:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i223[255], i223[254], i223[253], i223[252], i223[251], i223[250], i223[249], i223[248], i223[247], i223[246], i223[245], i223[244], i223[243], i223[242], i223[241], i223[240], i223[239], i223[238], i223[237], i223[236], i223[235], i223[234], i223[233], i223[232], i223[231], i223[230], i223[229], i223[228], i223[227], i223[226], i223[225], i223[224], i223[223], i223[222], i223[221], i223[220], i223[219], i223[218], i223[217], i223[216], i223[215], i223[214], i223[213], i223[212], i223[211], i223[210], i223[209], i223[208], i223[207], i223[206], i223[205], i223[204], i223[203], i223[202], i223[201], i223[200], i223[199], i223[198], i223[197], i223[196], i223[195], i223[194], i223[193], i223[192], i223[191], i223[190], i223[189], i223[188], i223[187], i223[186], i223[185], i223[184], i223[183], i223[182], i223[181], i223[180], i223[179], i223[178], i223[177], i223[176], i223[175], i223[174], i223[173], i223[172], i223[171], i223[170], i223[169], i223[168], i223[167], i223[166], i223[165], i223[164], i223[163], i223[162], i223[161], i223[160], i223[159], i223[158], i223[157], i223[156], i223[155], i223[154], i223[153], i223[152], i223[151], i223[150], i223[149], i223[148], i223[147], i223[146], i223[145], i223[144], i223[143], i223[142], i223[141], i223[140], i223[139], i223[138], i223[137], i223[136], i223[135], i223[134], i223[133], i223[132], i223[131], i223[130], i223[129], i223[128], i223[127], i223[126], i223[125], i223[124], i223[123], i223[122], i223[121], i223[120], i223[119], i223[118], i223[117], i223[116], i223[115], i223[114], i223[113], i223[112], i223[111], i223[110], i223[109], i223[108], i223[107], i223[106], i223[105], i223[104], i223[103], i223[102], i223[101], i223[100], i223[99], i223[98], i223[97], i223[96], i223[95], i223[94], i223[93], i223[92], i223[91], i223[90], i223[89], i223[88], i223[87], i223[86], i223[85], i223[84], i223[83], i223[82], i223[81], i223[80], i223[79], i223[78], i223[77], i223[76], i223[75], i223[74], i223[73], i223[72], i223[71], i223[70], i223[69], i223[68], i223[67], i223[66], i223[65], i223[64], i223[63], i223[62], i223[61], i223[60], i223[59], i223[58], i223[57], i223[56], i223[55], i223[54], i223[53], i223[52], i223[51], i223[50], i223[49], i223[48], i223[47], i223[46], i223[45], i223[44], i223[43], i223[42], i223[41], i223[40], i223[39], i223[38], i223[37], i223[36], i223[35], i223[34], i223[33], i223[32], i223[31], i223[30], i223[29], i223[28], i223[27], i223[26], i223[25], i223[24], i223[23], i223[22], i223[21], i223[20], i223[19], i223[18], i223[17], i223[16], i223[15], i223[14], i223[13], i223[12], i223[11], i223[10], i223[9], i223[8], i223[7], i223[6], i223[5], i223[4], i223[3], i223[2], i223[1], i223[0]};
wire [511:0] t1 = {i154[511], i154[510], i154[509], i154[508], i154[507], i154[506], i154[505], i154[504], i154[503], i154[502], i154[501], i154[500], i154[499], i154[498], i154[497], i154[496], i154[495], i154[494], i154[493], i154[492], i154[491], i154[490], i154[489], i154[488], i154[487], i154[486], i154[485], i154[484], i154[483], i154[482], i154[481], i154[480], i154[479], i154[478], i154[477], i154[476], i154[475], i154[474], i154[473], i154[472], i154[471], i154[470], i154[469], i154[468], i154[467], i154[466], i154[465], i154[464], i154[463], i154[462], i154[461], i154[460], i154[459], i154[458], i154[457], i154[456], i154[455], i154[454], i154[453], i154[452], i154[451], i154[450], i154[449], i154[448], i154[447], i154[446], i154[445], i154[444], i154[443], i154[442], i154[441], i154[440], i154[439], i154[438], i154[437], i154[436], i154[435], i154[434], i154[433], i154[432], i154[431], i154[430], i154[429], i154[428], i154[427], i154[426], i154[425], i154[424], i154[423], i154[422], i154[421], i154[420], i154[419], i154[418], i154[417], i154[416], i154[415], i154[414], i154[413], i154[412], i154[411], i154[410], i154[409], i154[408], i154[407], i154[406], i154[405], i154[404], i154[403], i154[402], i154[401], i154[400], i154[399], i154[398], i154[397], i154[396], i154[395], i154[394], i154[393], i154[392], i154[391], i154[390], i154[389], i154[388], i154[387], i154[386], i154[385], i154[384], i154[383], i154[382], i154[381], i154[380], i154[379], i154[378], i154[377], i154[376], i154[375], i154[374], i154[373], i154[372], i154[371], i154[370], i154[369], i154[368], i154[367], i154[366], i154[365], i154[364], i154[363], i154[362], i154[361], i154[360], i154[359], i154[358], i154[357], i154[356], i154[355], i154[354], i154[353], i154[352], i154[351], i154[350], i154[349], i154[348], i154[347], i154[346], i154[345], i154[344], i154[343], i154[342], i154[341], i154[340], i154[339], i154[338], i154[337], i154[336], i154[335], i154[334], i154[333], i154[332], i154[331], i154[330], i154[329], i154[328], i154[327], i154[326], i154[325], i154[324], i154[323], i154[322], i154[321], i154[320], i154[319], i154[318], i154[317], i154[316], i154[315], i154[314], i154[313], i154[312], i154[311], i154[310], i154[309], i154[308], i154[307], i154[306], i154[305], i154[304], i154[303], i154[302], i154[301], i154[300], i154[299], i154[298], i154[297], i154[296], i154[295], i154[294], i154[293], i154[292], i154[291], i154[290], i154[289], i154[288], i154[287], i154[286], i154[285], i154[284], i154[283], i154[282], i154[281], i154[280], i154[279], i154[278], i154[277], i154[276], i154[275], i154[274], i154[273], i154[272], i154[271], i154[270], i154[269], i154[268], i154[267], i154[266], i154[265], i154[264], i154[263], i154[262], i154[261], i154[260], i154[259], i154[258], i154[257], i154[256], i154[255], i154[254], i154[253], i154[252], i154[251], i154[250], i154[249], i154[248], i154[247], i154[246], i154[245], i154[244], i154[243], i154[242], i154[241], i154[240], i154[239], i154[238], i154[237], i154[236], i154[235], i154[234], i154[233], i154[232], i154[231], i154[230], i154[229], i154[228], i154[227], i154[226], i154[225], i154[224], i154[223], i154[222], i154[221], i154[220], i154[219], i154[218], i154[217], i154[216], i154[215], i154[214], i154[213], i154[212], i154[211], i154[210], i154[209], i154[208], i154[207], i154[206], i154[205], i154[204], i154[203], i154[202], i154[201], i154[200], i154[199], i154[198], i154[197], i154[196], i154[195], i154[194], i154[193], i154[192], i154[191], i154[190], i154[189], i154[188], i154[187], i154[186], i154[185], i154[184], i154[183], i154[182], i154[181], i154[180], i154[179], i154[178], i154[177], i154[176], i154[175], i154[174], i154[173], i154[172], i154[171], i154[170], i154[169], i154[168], i154[167], i154[166], i154[165], i154[164], i154[163], i154[162], i154[161], i154[160], i154[159], i154[158], i154[157], i154[156], i154[155], i154[154], i154[153], i154[152], i154[151], i154[150], i154[149], i154[148], i154[147], i154[146], i154[145], i154[144], i154[143], i154[142], i154[141], i154[140], i154[139], i154[138], i154[137], i154[136], i154[135], i154[134], i154[133], i154[132], i154[131], i154[130], i154[129], i154[128], i154[127], i154[126], i154[125], i154[124], i154[123], i154[122], i154[121], i154[120], i154[119], i154[118], i154[117], i154[116], i154[115], i154[114], i154[113], i154[112], i154[111], i154[110], i154[109], i154[108], i154[107], i154[106], i154[105], i154[104], i154[103], i154[102], i154[101], i154[100], i154[99], i154[98], i154[97], i154[96], i154[95], i154[94], i154[93], i154[92], i154[91], i154[90], i154[89], i154[88], i154[87], i154[86], i154[85], i154[84], i154[83], i154[82], i154[81], i154[80], i154[79], i154[78], i154[77], i154[76], i154[75], i154[74], i154[73], i154[72], i154[71], i154[70], i154[69], i154[68], i154[67], i154[66], i154[65], i154[64], i154[63], i154[62], i154[61], i154[60], i154[59], i154[58], i154[57], i154[56], i154[55], i154[54], i154[53], i154[52], i154[51], i154[50], i154[49], i154[48], i154[47], i154[46], i154[45], i154[44], i154[43], i154[42], i154[41], i154[40], i154[39], i154[38], i154[37], i154[36], i154[35], i154[34], i154[33], i154[32], i154[31], i154[30], i154[29], i154[28], i154[27], i154[26], i154[25], i154[24], i154[23], i154[22], i154[21], i154[20], i154[19], i154[18], i154[17], i154[16], i154[15], i154[14], i154[13], i154[12], i154[11], i154[10], i154[9], i154[8], i154[7], i154[6], i154[5], i154[4], i154[3], i154[2], i154[1], i154[0]};
wire [511:0] t2 = {i152[511], i152[510], i152[509], i152[508], i152[507], i152[506], i152[505], i152[504], i152[503], i152[502], i152[501], i152[500], i152[499], i152[498], i152[497], i152[496], i152[495], i152[494], i152[493], i152[492], i152[491], i152[490], i152[489], i152[488], i152[487], i152[486], i152[485], i152[484], i152[483], i152[482], i152[481], i152[480], i152[479], i152[478], i152[477], i152[476], i152[475], i152[474], i152[473], i152[472], i152[471], i152[470], i152[469], i152[468], i152[467], i152[466], i152[465], i152[464], i152[463], i152[462], i152[461], i152[460], i152[459], i152[458], i152[457], i152[456], i152[455], i152[454], i152[453], i152[452], i152[451], i152[450], i152[449], i152[448], i152[447], i152[446], i152[445], i152[444], i152[443], i152[442], i152[441], i152[440], i152[439], i152[438], i152[437], i152[436], i152[435], i152[434], i152[433], i152[432], i152[431], i152[430], i152[429], i152[428], i152[427], i152[426], i152[425], i152[424], i152[423], i152[422], i152[421], i152[420], i152[419], i152[418], i152[417], i152[416], i152[415], i152[414], i152[413], i152[412], i152[411], i152[410], i152[409], i152[408], i152[407], i152[406], i152[405], i152[404], i152[403], i152[402], i152[401], i152[400], i152[399], i152[398], i152[397], i152[396], i152[395], i152[394], i152[393], i152[392], i152[391], i152[390], i152[389], i152[388], i152[387], i152[386], i152[385], i152[384], i152[383], i152[382], i152[381], i152[380], i152[379], i152[378], i152[377], i152[376], i152[375], i152[374], i152[373], i152[372], i152[371], i152[370], i152[369], i152[368], i152[367], i152[366], i152[365], i152[364], i152[363], i152[362], i152[361], i152[360], i152[359], i152[358], i152[357], i152[356], i152[355], i152[354], i152[353], i152[352], i152[351], i152[350], i152[349], i152[348], i152[347], i152[346], i152[345], i152[344], i152[343], i152[342], i152[341], i152[340], i152[339], i152[338], i152[337], i152[336], i152[335], i152[334], i152[333], i152[332], i152[331], i152[330], i152[329], i152[328], i152[327], i152[326], i152[325], i152[324], i152[323], i152[322], i152[321], i152[320], i152[319], i152[318], i152[317], i152[316], i152[315], i152[314], i152[313], i152[312], i152[311], i152[310], i152[309], i152[308], i152[307], i152[306], i152[305], i152[304], i152[303], i152[302], i152[301], i152[300], i152[299], i152[298], i152[297], i152[296], i152[295], i152[294], i152[293], i152[292], i152[291], i152[290], i152[289], i152[288], i152[287], i152[286], i152[285], i152[284], i152[283], i152[282], i152[281], i152[280], i152[279], i152[278], i152[277], i152[276], i152[275], i152[274], i152[273], i152[272], i152[271], i152[270], i152[269], i152[268], i152[267], i152[266], i152[265], i152[264], i152[263], i152[262], i152[261], i152[260], i152[259], i152[258], i152[257], i152[256], i152[255], i152[254], i152[253], i152[252], i152[251], i152[250], i152[249], i152[248], i152[247], i152[246], i152[245], i152[244], i152[243], i152[242], i152[241], i152[240], i152[239], i152[238], i152[237], i152[236], i152[235], i152[234], i152[233], i152[232], i152[231], i152[230], i152[229], i152[228], i152[227], i152[226], i152[225], i152[224], i152[223], i152[222], i152[221], i152[220], i152[219], i152[218], i152[217], i152[216], i152[215], i152[214], i152[213], i152[212], i152[211], i152[210], i152[209], i152[208], i152[207], i152[206], i152[205], i152[204], i152[203], i152[202], i152[201], i152[200], i152[199], i152[198], i152[197], i152[196], i152[195], i152[194], i152[193], i152[192], i152[191], i152[190], i152[189], i152[188], i152[187], i152[186], i152[185], i152[184], i152[183], i152[182], i152[181], i152[180], i152[179], i152[178], i152[177], i152[176], i152[175], i152[174], i152[173], i152[172], i152[171], i152[170], i152[169], i152[168], i152[167], i152[166], i152[165], i152[164], i152[163], i152[162], i152[161], i152[160], i152[159], i152[158], i152[157], i152[156], i152[155], i152[154], i152[153], i152[152], i152[151], i152[150], i152[149], i152[148], i152[147], i152[146], i152[145], i152[144], i152[143], i152[142], i152[141], i152[140], i152[139], i152[138], i152[137], i152[136], i152[135], i152[134], i152[133], i152[132], i152[131], i152[130], i152[129], i152[128], i152[127], i152[126], i152[125], i152[124], i152[123], i152[122], i152[121], i152[120], i152[119], i152[118], i152[117], i152[116], i152[115], i152[114], i152[113], i152[112], i152[111], i152[110], i152[109], i152[108], i152[107], i152[106], i152[105], i152[104], i152[103], i152[102], i152[101], i152[100], i152[99], i152[98], i152[97], i152[96], i152[95], i152[94], i152[93], i152[92], i152[91], i152[90], i152[89], i152[88], i152[87], i152[86], i152[85], i152[84], i152[83], i152[82], i152[81], i152[80], i152[79], i152[78], i152[77], i152[76], i152[75], i152[74], i152[73], i152[72], i152[71], i152[70], i152[69], i152[68], i152[67], i152[66], i152[65], i152[64], i152[63], i152[62], i152[61], i152[60], i152[59], i152[58], i152[57], i152[56], i152[55], i152[54], i152[53], i152[52], i152[51], i152[50], i152[49], i152[48], i152[47], i152[46], i152[45], i152[44], i152[43], i152[42], i152[41], i152[40], i152[39], i152[38], i152[37], i152[36], i152[35], i152[34], i152[33], i152[32], i152[31], i152[30], i152[29], i152[28], i152[27], i152[26], i152[25], i152[24], i152[23], i152[22], i152[21], i152[20], i152[19], i152[18], i152[17], i152[16], i152[15], i152[14], i152[13], i152[12], i152[11], i152[10], i152[9], i152[8], i152[7], i152[6], i152[5], i152[4], i152[3], i152[2], i152[1], i152[0]};
wire [511:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219_reduce(input wire [257:0] i143, input wire [129:0] i227, input wire [257:0] i555, output wire [257:0] y);
wire [257:0] t0 = {i555[257], i555[256], i555[255], i555[254], i555[253], i555[252], i555[251], i555[250], i555[249], i555[248], i555[247], i555[246], i555[245], i555[244], i555[243], i555[242], i555[241], i555[240], i555[239], i555[238], i555[237], i555[236], i555[235], i555[234], i555[233], i555[232], i555[231], i555[230], i555[229], i555[228], i555[227], i555[226], i555[225], i555[224], i555[223], i555[222], i555[221], i555[220], i555[219], i555[218], i555[217], i555[216], i555[215], i555[214], i555[213], i555[212], i555[211], i555[210], i555[209], i555[208], i555[207], i555[206], i555[205], i555[204], i555[203], i555[202], i555[201], i555[200], i555[199], i555[198], i555[197], i555[196], i555[195], i555[194], i555[193], i555[192], i555[191], i555[190], i555[189], i555[188], i555[187], i555[186], i555[185], i555[184], i555[183], i555[182], i555[181], i555[180], i555[179], i555[178], i555[177], i555[176], i555[175], i555[174], i555[173], i555[172], i555[171], i555[170], i555[169], i555[168], i555[167], i555[166], i555[165], i555[164], i555[163], i555[162], i555[161], i555[160], i555[159], i555[158], i555[157], i555[156], i555[155], i555[154], i555[153], i555[152], i555[151], i555[150], i555[149], i555[148], i555[147], i555[146], i555[145], i555[144], i555[143], i555[142], i555[141], i555[140], i555[139], i555[138], i555[137], i555[136], i555[135], i555[134], i555[133], i555[132], i555[131], i555[130], i555[129], i555[128], i555[127], i555[126], i555[125], i555[124], i555[123], i555[122], i555[121], i555[120], i555[119], i555[118], i555[117], i555[116], i555[115], i555[114], i555[113], i555[112], i555[111], i555[110], i555[109], i555[108], i555[107], i555[106], i555[105], i555[104], i555[103], i555[102], i555[101], i555[100], i555[99], i555[98], i555[97], i555[96], i555[95], i555[94], i555[93], i555[92], i555[91], i555[90], i555[89], i555[88], i555[87], i555[86], i555[85], i555[84], i555[83], i555[82], i555[81], i555[80], i555[79], i555[78], i555[77], i555[76], i555[75], i555[74], i555[73], i555[72], i555[71], i555[70], i555[69], i555[68], i555[67], i555[66], i555[65], i555[64], i555[63], i555[62], i555[61], i555[60], i555[59], i555[58], i555[57], i555[56], i555[55], i555[54], i555[53], i555[52], i555[51], i555[50], i555[49], i555[48], i555[47], i555[46], i555[45], i555[44], i555[43], i555[42], i555[41], i555[40], i555[39], i555[38], i555[37], i555[36], i555[35], i555[34], i555[33], i555[32], i555[31], i555[30], i555[29], i555[28], i555[27], i555[26], i555[25], i555[24], i555[23], i555[22], i555[21], i555[20], i555[19], i555[18], i555[17], i555[16], i555[15], i555[14], i555[13], i555[12], i555[11], i555[10], i555[9], i555[8], i555[7], i555[6], i555[5], i555[4], i555[3], i555[2], i555[1], i555[0]};
wire [257:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i227[129], i227[128], i227[127], i227[126], i227[125], i227[124], i227[123], i227[122], i227[121], i227[120], i227[119], i227[118], i227[117], i227[116], i227[115], i227[114], i227[113], i227[112], i227[111], i227[110], i227[109], i227[108], i227[107], i227[106], i227[105], i227[104], i227[103], i227[102], i227[101], i227[100], i227[99], i227[98], i227[97], i227[96], i227[95], i227[94], i227[93], i227[92], i227[91], i227[90], i227[89], i227[88], i227[87], i227[86], i227[85], i227[84], i227[83], i227[82], i227[81], i227[80], i227[79], i227[78], i227[77], i227[76], i227[75], i227[74], i227[73], i227[72], i227[71], i227[70], i227[69], i227[68], i227[67], i227[66], i227[65], i227[64], i227[63], i227[62], i227[61], i227[60], i227[59], i227[58], i227[57], i227[56], i227[55], i227[54], i227[53], i227[52], i227[51], i227[50], i227[49], i227[48], i227[47], i227[46], i227[45], i227[44], i227[43], i227[42], i227[41], i227[40], i227[39], i227[38], i227[37], i227[36], i227[35], i227[34], i227[33], i227[32], i227[31], i227[30], i227[29], i227[28], i227[27], i227[26], i227[25], i227[24], i227[23], i227[22], i227[21], i227[20], i227[19], i227[18], i227[17], i227[16], i227[15], i227[14], i227[13], i227[12], i227[11], i227[10], i227[9], i227[8], i227[7], i227[6], i227[5], i227[4], i227[3], i227[2], i227[1], i227[0]};
wire [257:0] t2 = {i143[257], i143[256], i143[255], i143[254], i143[253], i143[252], i143[251], i143[250], i143[249], i143[248], i143[247], i143[246], i143[245], i143[244], i143[243], i143[242], i143[241], i143[240], i143[239], i143[238], i143[237], i143[236], i143[235], i143[234], i143[233], i143[232], i143[231], i143[230], i143[229], i143[228], i143[227], i143[226], i143[225], i143[224], i143[223], i143[222], i143[221], i143[220], i143[219], i143[218], i143[217], i143[216], i143[215], i143[214], i143[213], i143[212], i143[211], i143[210], i143[209], i143[208], i143[207], i143[206], i143[205], i143[204], i143[203], i143[202], i143[201], i143[200], i143[199], i143[198], i143[197], i143[196], i143[195], i143[194], i143[193], i143[192], i143[191], i143[190], i143[189], i143[188], i143[187], i143[186], i143[185], i143[184], i143[183], i143[182], i143[181], i143[180], i143[179], i143[178], i143[177], i143[176], i143[175], i143[174], i143[173], i143[172], i143[171], i143[170], i143[169], i143[168], i143[167], i143[166], i143[165], i143[164], i143[163], i143[162], i143[161], i143[160], i143[159], i143[158], i143[157], i143[156], i143[155], i143[154], i143[153], i143[152], i143[151], i143[150], i143[149], i143[148], i143[147], i143[146], i143[145], i143[144], i143[143], i143[142], i143[141], i143[140], i143[139], i143[138], i143[137], i143[136], i143[135], i143[134], i143[133], i143[132], i143[131], i143[130], i143[129], i143[128], i143[127], i143[126], i143[125], i143[124], i143[123], i143[122], i143[121], i143[120], i143[119], i143[118], i143[117], i143[116], i143[115], i143[114], i143[113], i143[112], i143[111], i143[110], i143[109], i143[108], i143[107], i143[106], i143[105], i143[104], i143[103], i143[102], i143[101], i143[100], i143[99], i143[98], i143[97], i143[96], i143[95], i143[94], i143[93], i143[92], i143[91], i143[90], i143[89], i143[88], i143[87], i143[86], i143[85], i143[84], i143[83], i143[82], i143[81], i143[80], i143[79], i143[78], i143[77], i143[76], i143[75], i143[74], i143[73], i143[72], i143[71], i143[70], i143[69], i143[68], i143[67], i143[66], i143[65], i143[64], i143[63], i143[62], i143[61], i143[60], i143[59], i143[58], i143[57], i143[56], i143[55], i143[54], i143[53], i143[52], i143[51], i143[50], i143[49], i143[48], i143[47], i143[46], i143[45], i143[44], i143[43], i143[42], i143[41], i143[40], i143[39], i143[38], i143[37], i143[36], i143[35], i143[34], i143[33], i143[32], i143[31], i143[30], i143[29], i143[28], i143[27], i143[26], i143[25], i143[24], i143[23], i143[22], i143[21], i143[20], i143[19], i143[18], i143[17], i143[16], i143[15], i143[14], i143[13], i143[12], i143[11], i143[10], i143[9], i143[8], i143[7], i143[6], i143[5], i143[4], i143[3], i143[2], i143[1], i143[0]};
wire [257:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_225_reduce(input wire [131:0] i134, input wire [131:0] i136, input wire [131:0] i557, output wire [131:0] y);
wire [131:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i557[65], i557[64], i557[63], i557[62], i557[61], i557[60], i557[59], i557[58], i557[57], i557[56], i557[55], i557[54], i557[53], i557[52], i557[51], i557[50], i557[49], i557[48], i557[47], i557[46], i557[45], i557[44], i557[43], i557[42], i557[41], i557[40], i557[39], i557[38], i557[37], i557[36], i557[35], i557[34], i557[33], i557[32], i557[31], i557[30], i557[29], i557[28], i557[27], i557[26], i557[25], i557[24], i557[23], i557[22], i557[21], i557[20], i557[19], i557[18], i557[17], i557[16], i557[15], i557[14], i557[13], i557[12], i557[11], i557[10], i557[9], i557[8], i557[7], i557[6], i557[5], i557[4], i557[3], i557[2], i557[1], i557[0]};
wire [131:0] t1 = {i136[131], i136[130], i136[129], i136[128], i136[127], i136[126], i136[125], i136[124], i136[123], i136[122], i136[121], i136[120], i136[119], i136[118], i136[117], i136[116], i136[115], i136[114], i136[113], i136[112], i136[111], i136[110], i136[109], i136[108], i136[107], i136[106], i136[105], i136[104], i136[103], i136[102], i136[101], i136[100], i136[99], i136[98], i136[97], i136[96], i136[95], i136[94], i136[93], i136[92], i136[91], i136[90], i136[89], i136[88], i136[87], i136[86], i136[85], i136[84], i136[83], i136[82], i136[81], i136[80], i136[79], i136[78], i136[77], i136[76], i136[75], i136[74], i136[73], i136[72], i136[71], i136[70], i136[69], i136[68], i136[67], i136[66], i136[65], i136[64], i136[63], i136[62], i136[61], i136[60], i136[59], i136[58], i136[57], i136[56], i136[55], i136[54], i136[53], i136[52], i136[51], i136[50], i136[49], i136[48], i136[47], i136[46], i136[45], i136[44], i136[43], i136[42], i136[41], i136[40], i136[39], i136[38], i136[37], i136[36], i136[35], i136[34], i136[33], i136[32], i136[31], i136[30], i136[29], i136[28], i136[27], i136[26], i136[25], i136[24], i136[23], i136[22], i136[21], i136[20], i136[19], i136[18], i136[17], i136[16], i136[15], i136[14], i136[13], i136[12], i136[11], i136[10], i136[9], i136[8], i136[7], i136[6], i136[5], i136[4], i136[3], i136[2], i136[1], i136[0]};
wire [131:0] t2 = {i134[131], i134[130], i134[129], i134[128], i134[127], i134[126], i134[125], i134[124], i134[123], i134[122], i134[121], i134[120], i134[119], i134[118], i134[117], i134[116], i134[115], i134[114], i134[113], i134[112], i134[111], i134[110], i134[109], i134[108], i134[107], i134[106], i134[105], i134[104], i134[103], i134[102], i134[101], i134[100], i134[99], i134[98], i134[97], i134[96], i134[95], i134[94], i134[93], i134[92], i134[91], i134[90], i134[89], i134[88], i134[87], i134[86], i134[85], i134[84], i134[83], i134[82], i134[81], i134[80], i134[79], i134[78], i134[77], i134[76], i134[75], i134[74], i134[73], i134[72], i134[71], i134[70], i134[69], i134[68], i134[67], i134[66], i134[65], i134[64], i134[63], i134[62], i134[61], i134[60], i134[59], i134[58], i134[57], i134[56], i134[55], i134[54], i134[53], i134[52], i134[51], i134[50], i134[49], i134[48], i134[47], i134[46], i134[45], i134[44], i134[43], i134[42], i134[41], i134[40], i134[39], i134[38], i134[37], i134[36], i134[35], i134[34], i134[33], i134[32], i134[31], i134[30], i134[29], i134[28], i134[27], i134[26], i134[25], i134[24], i134[23], i134[22], i134[21], i134[20], i134[19], i134[18], i134[17], i134[16], i134[15], i134[14], i134[13], i134[12], i134[11], i134[10], i134[9], i134[8], i134[7], i134[6], i134[5], i134[4], i134[3], i134[2], i134[1], i134[0]};
wire [131:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_227_reduce(input wire [129:0] i110, input wire [129:0] i549, input wire [129:0] i551, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i549[65], i549[64], i549[63], i549[62], i549[61], i549[60], i549[59], i549[58], i549[57], i549[56], i549[55], i549[54], i549[53], i549[52], i549[51], i549[50], i549[49], i549[48], i549[47], i549[46], i549[45], i549[44], i549[43], i549[42], i549[41], i549[40], i549[39], i549[38], i549[37], i549[36], i549[35], i549[34], i549[33], i549[32], i549[31], i549[30], i549[29], i549[28], i549[27], i549[26], i549[25], i549[24], i549[23], i549[22], i549[21], i549[20], i549[19], i549[18], i549[17], i549[16], i549[15], i549[14], i549[13], i549[12], i549[11], i549[10], i549[9], i549[8], i549[7], i549[6], i549[5], i549[4], i549[3], i549[2], i549[1], i549[0]};
wire [129:0] t1 = {i110[129], i110[128], i110[127], i110[126], i110[125], i110[124], i110[123], i110[122], i110[121], i110[120], i110[119], i110[118], i110[117], i110[116], i110[115], i110[114], i110[113], i110[112], i110[111], i110[110], i110[109], i110[108], i110[107], i110[106], i110[105], i110[104], i110[103], i110[102], i110[101], i110[100], i110[99], i110[98], i110[97], i110[96], i110[95], i110[94], i110[93], i110[92], i110[91], i110[90], i110[89], i110[88], i110[87], i110[86], i110[85], i110[84], i110[83], i110[82], i110[81], i110[80], i110[79], i110[78], i110[77], i110[76], i110[75], i110[74], i110[73], i110[72], i110[71], i110[70], i110[69], i110[68], i110[67], i110[66], i110[65], i110[64], i110[63], i110[62], i110[61], i110[60], i110[59], i110[58], i110[57], i110[56], i110[55], i110[54], i110[53], i110[52], i110[51], i110[50], i110[49], i110[48], i110[47], i110[46], i110[45], i110[44], i110[43], i110[42], i110[41], i110[40], i110[39], i110[38], i110[37], i110[36], i110[35], i110[34], i110[33], i110[32], i110[31], i110[30], i110[29], i110[28], i110[27], i110[26], i110[25], i110[24], i110[23], i110[22], i110[21], i110[20], i110[19], i110[18], i110[17], i110[16], i110[15], i110[14], i110[13], i110[12], i110[11], i110[10], i110[9], i110[8], i110[7], i110[6], i110[5], i110[4], i110[3], i110[2], i110[1], i110[0]};
wire [129:0] t2 = {i551[129], i551[128], i551[127], i551[126], i551[125], i551[124], i551[123], i551[122], i551[121], i551[120], i551[119], i551[118], i551[117], i551[116], i551[115], i551[114], i551[113], i551[112], i551[111], i551[110], i551[109], i551[108], i551[107], i551[106], i551[105], i551[104], i551[103], i551[102], i551[101], i551[100], i551[99], i551[98], i551[97], i551[96], i551[95], i551[94], i551[93], i551[92], i551[91], i551[90], i551[89], i551[88], i551[87], i551[86], i551[85], i551[84], i551[83], i551[82], i551[81], i551[80], i551[79], i551[78], i551[77], i551[76], i551[75], i551[74], i551[73], i551[72], i551[71], i551[70], i551[69], i551[68], i551[67], i551[66], i551[65], i551[64], i551[63], i551[62], i551[61], i551[60], i551[59], i551[58], i551[57], i551[56], i551[55], i551[54], i551[53], i551[52], i551[51], i551[50], i551[49], i551[48], i551[47], i551[46], i551[45], i551[44], i551[43], i551[42], i551[41], i551[40], i551[39], i551[38], i551[37], i551[36], i551[35], i551[34], i551[33], i551[32], i551[31], i551[30], i551[29], i551[28], i551[27], i551[26], i551[25], i551[24], i551[23], i551[22], i551[21], i551[20], i551[19], i551[18], i551[17], i551[16], i551[15], i551[14], i551[13], i551[12], i551[11], i551[10], i551[9], i551[8], i551[7], i551[6], i551[5], i551[4], i551[3], i551[2], i551[1], i551[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_229_reduce(input wire [129:0] i72, input wire [129:0] i74, input wire [65:0] i350, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i350[65], i350[64], i350[63], i350[62], i350[61], i350[60], i350[59], i350[58], i350[57], i350[56], i350[55], i350[54], i350[53], i350[52], i350[51], i350[50], i350[49], i350[48], i350[47], i350[46], i350[45], i350[44], i350[43], i350[42], i350[41], i350[40], i350[39], i350[38], i350[37], i350[36], i350[35], i350[34], i350[33], i350[32], i350[31], i350[30], i350[29], i350[28], i350[27], i350[26], i350[25], i350[24], i350[23], i350[22], i350[21], i350[20], i350[19], i350[18], i350[17], i350[16], i350[15], i350[14], i350[13], i350[12], i350[11], i350[10], i350[9], i350[8], i350[7], i350[6], i350[5], i350[4], i350[3], i350[2], i350[1], i350[0]};
wire [129:0] t1 = {i74[129], i74[128], i74[127], i74[126], i74[125], i74[124], i74[123], i74[122], i74[121], i74[120], i74[119], i74[118], i74[117], i74[116], i74[115], i74[114], i74[113], i74[112], i74[111], i74[110], i74[109], i74[108], i74[107], i74[106], i74[105], i74[104], i74[103], i74[102], i74[101], i74[100], i74[99], i74[98], i74[97], i74[96], i74[95], i74[94], i74[93], i74[92], i74[91], i74[90], i74[89], i74[88], i74[87], i74[86], i74[85], i74[84], i74[83], i74[82], i74[81], i74[80], i74[79], i74[78], i74[77], i74[76], i74[75], i74[74], i74[73], i74[72], i74[71], i74[70], i74[69], i74[68], i74[67], i74[66], i74[65], i74[64], i74[63], i74[62], i74[61], i74[60], i74[59], i74[58], i74[57], i74[56], i74[55], i74[54], i74[53], i74[52], i74[51], i74[50], i74[49], i74[48], i74[47], i74[46], i74[45], i74[44], i74[43], i74[42], i74[41], i74[40], i74[39], i74[38], i74[37], i74[36], i74[35], i74[34], i74[33], i74[32], i74[31], i74[30], i74[29], i74[28], i74[27], i74[26], i74[25], i74[24], i74[23], i74[22], i74[21], i74[20], i74[19], i74[18], i74[17], i74[16], i74[15], i74[14], i74[13], i74[12], i74[11], i74[10], i74[9], i74[8], i74[7], i74[6], i74[5], i74[4], i74[3], i74[2], i74[1], i74[0]};
wire [129:0] t2 = {i72[129], i72[128], i72[127], i72[126], i72[125], i72[124], i72[123], i72[122], i72[121], i72[120], i72[119], i72[118], i72[117], i72[116], i72[115], i72[114], i72[113], i72[112], i72[111], i72[110], i72[109], i72[108], i72[107], i72[106], i72[105], i72[104], i72[103], i72[102], i72[101], i72[100], i72[99], i72[98], i72[97], i72[96], i72[95], i72[94], i72[93], i72[92], i72[91], i72[90], i72[89], i72[88], i72[87], i72[86], i72[85], i72[84], i72[83], i72[82], i72[81], i72[80], i72[79], i72[78], i72[77], i72[76], i72[75], i72[74], i72[73], i72[72], i72[71], i72[70], i72[69], i72[68], i72[67], i72[66], i72[65], i72[64], i72[63], i72[62], i72[61], i72[60], i72[59], i72[58], i72[57], i72[56], i72[55], i72[54], i72[53], i72[52], i72[51], i72[50], i72[49], i72[48], i72[47], i72[46], i72[45], i72[44], i72[43], i72[42], i72[41], i72[40], i72[39], i72[38], i72[37], i72[36], i72[35], i72[34], i72[33], i72[32], i72[31], i72[30], i72[29], i72[28], i72[27], i72[26], i72[25], i72[24], i72[23], i72[22], i72[21], i72[20], i72[19], i72[18], i72[17], i72[16], i72[15], i72[14], i72[13], i72[12], i72[11], i72[10], i72[9], i72[8], i72[7], i72[6], i72[5], i72[4], i72[3], i72[2], i72[1], i72[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_231_reduce(input wire [129:0] i34, input wire [129:0] i36, input wire [67:0] i530, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i530[65], i530[64], i530[63], i530[62], i530[61], i530[60], i530[59], i530[58], i530[57], i530[56], i530[55], i530[54], i530[53], i530[52], i530[51], i530[50], i530[49], i530[48], i530[47], i530[46], i530[45], i530[44], i530[43], i530[42], i530[41], i530[40], i530[39], i530[38], i530[37], i530[36], i530[35], i530[34], i530[33], i530[32], i530[31], i530[30], i530[29], i530[28], i530[27], i530[26], i530[25], i530[24], i530[23], i530[22], i530[21], i530[20], i530[19], i530[18], i530[17], i530[16], i530[15], i530[14], i530[13], i530[12], i530[11], i530[10], i530[9], i530[8], i530[7], i530[6], i530[5], i530[4], i530[3], i530[2], i530[1], i530[0]};
wire [129:0] t1 = {i36[129], i36[128], i36[127], i36[126], i36[125], i36[124], i36[123], i36[122], i36[121], i36[120], i36[119], i36[118], i36[117], i36[116], i36[115], i36[114], i36[113], i36[112], i36[111], i36[110], i36[109], i36[108], i36[107], i36[106], i36[105], i36[104], i36[103], i36[102], i36[101], i36[100], i36[99], i36[98], i36[97], i36[96], i36[95], i36[94], i36[93], i36[92], i36[91], i36[90], i36[89], i36[88], i36[87], i36[86], i36[85], i36[84], i36[83], i36[82], i36[81], i36[80], i36[79], i36[78], i36[77], i36[76], i36[75], i36[74], i36[73], i36[72], i36[71], i36[70], i36[69], i36[68], i36[67], i36[66], i36[65], i36[64], i36[63], i36[62], i36[61], i36[60], i36[59], i36[58], i36[57], i36[56], i36[55], i36[54], i36[53], i36[52], i36[51], i36[50], i36[49], i36[48], i36[47], i36[46], i36[45], i36[44], i36[43], i36[42], i36[41], i36[40], i36[39], i36[38], i36[37], i36[36], i36[35], i36[34], i36[33], i36[32], i36[31], i36[30], i36[29], i36[28], i36[27], i36[26], i36[25], i36[24], i36[23], i36[22], i36[21], i36[20], i36[19], i36[18], i36[17], i36[16], i36[15], i36[14], i36[13], i36[12], i36[11], i36[10], i36[9], i36[8], i36[7], i36[6], i36[5], i36[4], i36[3], i36[2], i36[1], i36[0]};
wire [129:0] t2 = {i34[129], i34[128], i34[127], i34[126], i34[125], i34[124], i34[123], i34[122], i34[121], i34[120], i34[119], i34[118], i34[117], i34[116], i34[115], i34[114], i34[113], i34[112], i34[111], i34[110], i34[109], i34[108], i34[107], i34[106], i34[105], i34[104], i34[103], i34[102], i34[101], i34[100], i34[99], i34[98], i34[97], i34[96], i34[95], i34[94], i34[93], i34[92], i34[91], i34[90], i34[89], i34[88], i34[87], i34[86], i34[85], i34[84], i34[83], i34[82], i34[81], i34[80], i34[79], i34[78], i34[77], i34[76], i34[75], i34[74], i34[73], i34[72], i34[71], i34[70], i34[69], i34[68], i34[67], i34[66], i34[65], i34[64], i34[63], i34[62], i34[61], i34[60], i34[59], i34[58], i34[57], i34[56], i34[55], i34[54], i34[53], i34[52], i34[51], i34[50], i34[49], i34[48], i34[47], i34[46], i34[45], i34[44], i34[43], i34[42], i34[41], i34[40], i34[39], i34[38], i34[37], i34[36], i34[35], i34[34], i34[33], i34[32], i34[31], i34[30], i34[29], i34[28], i34[27], i34[26], i34[25], i34[24], i34[23], i34[22], i34[21], i34[20], i34[19], i34[18], i34[17], i34[16], i34[15], i34[14], i34[13], i34[12], i34[11], i34[10], i34[9], i34[8], i34[7], i34[6], i34[5], i34[4], i34[3], i34[2], i34[1], i34[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_29Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_29();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_31Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_31();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_87Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_87();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113Core(input wire [65:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h1ffffffffffffffff)|66'h0);
wire [65:0] masked_b=((b&66'hffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115Core(input wire [65:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h1ffffffffffffffff)|66'h0);
wire [65:0] masked_b=((b&66'hffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [131:0] a,input wire [129:0] b,input wire cin,output wire [131:0] value);
wire [131:0] masked_a=((a&132'hfffffffffffffffffffffffffffffffff)|132'h0);
wire [129:0] masked_b=((b&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [131:0] aa=132'(masked_a);
wire [131:0] bb=132'(masked_b);
wire [132:0] extended={1'b0,aa}-{1'b0,bb}-133'(1'b0);
wire [131:0] native_value=extended[131:0];
assign value=native_value[0+:132];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [131:0] a,input wire [131:0] b,input wire cin,output wire [131:0] value);
wire [131:0] masked_a=((a&132'hfffffffffffffffffffffffffffffffff)|132'h0);
wire [131:0] masked_b=((b&132'hffffffffffffffffffffffffffffffff)|132'h0);
wire [131:0] aa=132'(masked_a);
wire [131:0] bb=132'(masked_b);
wire [132:0] extended={1'b0,aa}-{1'b0,bb}-133'(1'b0);
wire [131:0] native_value=extended[131:0];
assign value=native_value[0+:132];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147Core(input wire [257:0] a,input wire [255:0] b,input wire cin,output wire [257:0] value);
wire [257:0] masked_a=((a&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [257:0] aa=258'(masked_a);
wire [257:0] bb=258'(masked_b);
wire [258:0] extended={1'b0,aa}-{1'b0,bb}-259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:258];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149Core(input wire [257:0] a,input wire [255:0] b,input wire cin,output wire [257:0] value);
wire [257:0] masked_a=((a&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [257:0] aa=258'(masked_a);
wire [257:0] bb=258'(masked_b);
wire [258:0] extended={1'b0,aa}-{1'b0,bb}-259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:258];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_157Core(input wire [511:0] a,input wire [511:0] b,input wire cin,output wire [512:0] value);
wire [511:0] masked_a=((a&512'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|512'h0);
wire [511:0] masked_b=((b&512'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|512'h0);
wire [512:0] aa=513'(masked_a);
wire [512:0] bb=513'(masked_b);
wire [513:0] extended={1'b0,aa}+{1'b0,bb}+514'(1'b0);
wire [512:0] native_value=extended[512:0];
assign value=native_value[0+:513];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_157();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_221Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_a);
wire [255:0] bb=256'(masked_b);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_221();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_a);
wire [255:0] bb=256'(masked_b);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_356Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_356();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
