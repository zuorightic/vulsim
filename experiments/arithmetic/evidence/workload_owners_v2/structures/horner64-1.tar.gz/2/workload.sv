`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [15:0] limb_8_21; // decl: <none>; prim: <none>
    logic [15:0] limb_8_22; // decl: <none>; prim: <none>
    logic [16:0] limb_8_23; // decl: <none>; prim: <none>
    logic [15:0] limb_8_24; // decl: <none>; prim: <none>
    logic limb_8_25; // decl: <none>; prim: <none>
    logic [15:0] limb_8_26; // decl: <none>; prim: <none>
    logic [15:0] limb_8_27; // decl: <none>; prim: <none>
    logic [16:0] limb_8_28; // decl: <none>; prim: <none>
    logic [15:0] limb_8_29; // decl: <none>; prim: <none>
    logic limb_8_30; // decl: <none>; prim: <none>
    logic [15:0] limb_8_31; // decl: <none>; prim: <none>
    logic [15:0] limb_8_32; // decl: <none>; prim: <none>
    logic [16:0] limb_8_33; // decl: <none>; prim: <none>
    logic [15:0] limb_8_34; // decl: <none>; prim: <none>
    logic limb_8_35; // decl: <none>; prim: <none>
    logic [15:0] limb_8_36; // decl: <none>; prim: <none>
    logic [15:0] limb_8_37; // decl: <none>; prim: <none>
    logic [16:0] limb_8_38; // decl: <none>; prim: <none>
    logic [15:0] limb_8_39; // decl: <none>; prim: <none>
    logic [63:0] limb_8_40; // decl: <none>; prim: <none>
    logic [15:0] limb_10_41; // decl: <none>; prim: <none>
    logic [15:0] limb_10_42; // decl: <none>; prim: <none>
    logic [16:0] limb_10_43; // decl: <none>; prim: <none>
    logic [15:0] limb_10_44; // decl: <none>; prim: <none>
    logic limb_10_45; // decl: <none>; prim: <none>
    logic [15:0] limb_10_46; // decl: <none>; prim: <none>
    logic [15:0] limb_10_47; // decl: <none>; prim: <none>
    logic [16:0] limb_10_48; // decl: <none>; prim: <none>
    logic [15:0] limb_10_49; // decl: <none>; prim: <none>
    logic limb_10_50; // decl: <none>; prim: <none>
    logic [15:0] limb_10_51; // decl: <none>; prim: <none>
    logic [15:0] limb_10_52; // decl: <none>; prim: <none>
    logic [16:0] limb_10_53; // decl: <none>; prim: <none>
    logic [15:0] limb_10_54; // decl: <none>; prim: <none>
    logic limb_10_55; // decl: <none>; prim: <none>
    logic [15:0] limb_10_56; // decl: <none>; prim: <none>
    logic [15:0] limb_10_57; // decl: <none>; prim: <none>
    logic [16:0] limb_10_58; // decl: <none>; prim: <none>
    logic [15:0] limb_10_59; // decl: <none>; prim: <none>
    logic [63:0] limb_10_60; // decl: <none>; prim: <none>
    logic [15:0] limb_12_61; // decl: <none>; prim: <none>
    logic [15:0] limb_12_62; // decl: <none>; prim: <none>
    logic [16:0] limb_12_63; // decl: <none>; prim: <none>
    logic [15:0] limb_12_64; // decl: <none>; prim: <none>
    logic limb_12_65; // decl: <none>; prim: <none>
    logic [15:0] limb_12_66; // decl: <none>; prim: <none>
    logic [15:0] limb_12_67; // decl: <none>; prim: <none>
    logic [16:0] limb_12_68; // decl: <none>; prim: <none>
    logic [15:0] limb_12_69; // decl: <none>; prim: <none>
    logic limb_12_70; // decl: <none>; prim: <none>
    logic [15:0] limb_12_71; // decl: <none>; prim: <none>
    logic [15:0] limb_12_72; // decl: <none>; prim: <none>
    logic [16:0] limb_12_73; // decl: <none>; prim: <none>
    logic [15:0] limb_12_74; // decl: <none>; prim: <none>
    logic limb_12_75; // decl: <none>; prim: <none>
    logic [15:0] limb_12_76; // decl: <none>; prim: <none>
    logic [15:0] limb_12_77; // decl: <none>; prim: <none>
    logic [16:0] limb_12_78; // decl: <none>; prim: <none>
    logic [15:0] limb_12_79; // decl: <none>; prim: <none>
    logic [63:0] limb_12_80; // decl: <none>; prim: <none>
    logic [15:0] limb_14_81; // decl: <none>; prim: <none>
    logic [15:0] limb_14_82; // decl: <none>; prim: <none>
    logic [16:0] limb_14_83; // decl: <none>; prim: <none>
    logic [15:0] limb_14_84; // decl: <none>; prim: <none>
    logic limb_14_85; // decl: <none>; prim: <none>
    logic [15:0] limb_14_86; // decl: <none>; prim: <none>
    logic [15:0] limb_14_87; // decl: <none>; prim: <none>
    logic [16:0] limb_14_88; // decl: <none>; prim: <none>
    logic [15:0] limb_14_89; // decl: <none>; prim: <none>
    logic limb_14_90; // decl: <none>; prim: <none>
    logic [15:0] limb_14_91; // decl: <none>; prim: <none>
    logic [15:0] limb_14_92; // decl: <none>; prim: <none>
    logic [16:0] limb_14_93; // decl: <none>; prim: <none>
    logic [15:0] limb_14_94; // decl: <none>; prim: <none>
    logic limb_14_95; // decl: <none>; prim: <none>
    logic [15:0] limb_14_96; // decl: <none>; prim: <none>
    logic [15:0] limb_14_97; // decl: <none>; prim: <none>
    logic [16:0] limb_14_98; // decl: <none>; prim: <none>
    logic [15:0] limb_14_99; // decl: <none>; prim: <none>
    logic [63:0] limb_14_100; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [15:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_24_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_29_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_29_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_30_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_31_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_34_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_36_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_36_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_37_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_37_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_8_s5; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [15:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_42_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_42_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_44_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_45_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_46_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_47_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_51_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_52_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_56_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_57_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [15:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_62_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_67_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_72_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_77_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_82_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_87_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_92_s7; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s3; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s4; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s5; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s6; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_97_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = limb_8_40; // decl: <none>; prim: <none>
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_add_5_v0 = limb_10_60; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    assign s8_norm_add_8_v0 = limb_12_80; // decl: <none>; prim: <none>
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_add_11_v0 = limb_14_100; // decl: <none>; prim: <none>
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(64'(c4)), .b(64'(x)), .cin(1'b0), .value(arith_original_17));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(64'(rtlzz_pipe_8_s5)), .b(64'(rtlzz_pipe_0_s5)), .cin(1'b0), .value(arith_original_18));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(64'(rtlzz_pipe_10_s7)), .b(64'(rtlzz_pipe_0_s7)), .cin(1'b0), .value(arith_original_19));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(64'(s8_norm_add_8_v0)), .b(64'(rtlzz_pipe_0_s7)), .cin(1'b0), .value(arith_original_20));
    assign limb_8_21 = s8_norm_mul_0_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_8_22 = c3[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(16'(rtlzz_pipe_21_s1)), .b(16'(rtlzz_pipe_22_s1)), .cin(1'h0), .value(limb_8_23));
    assign limb_8_24 = limb_8_23[15:0]; // decl: <none>; prim: <none>
    assign limb_8_25 = limb_8_23[16]; // decl: <none>; prim: <none>
    assign limb_8_26 = s8_norm_mul_0_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_8_27 = c3[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(rtlzz_pipe_26_s2)), .b(16'(rtlzz_pipe_27_s2)), .cin(rtlzz_pipe_25_s2), .value(limb_8_28));
    assign limb_8_29 = limb_8_28[15:0]; // decl: <none>; prim: <none>
    assign limb_8_30 = limb_8_28[16]; // decl: <none>; prim: <none>
    assign limb_8_31 = s8_norm_mul_0_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_8_32 = c3[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_33Core rtlzz_owner_33(.a(16'(rtlzz_pipe_31_s3)), .b(16'(rtlzz_pipe_32_s3)), .cin(rtlzz_pipe_30_s3), .value(limb_8_33));
    assign limb_8_34 = limb_8_33[15:0]; // decl: <none>; prim: <none>
    assign limb_8_35 = limb_8_33[16]; // decl: <none>; prim: <none>
    assign limb_8_36 = s8_norm_mul_0_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_8_37 = c3[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(16'(rtlzz_pipe_36_s4)), .b(16'(rtlzz_pipe_37_s4)), .cin(rtlzz_pipe_35_s4), .value(limb_8_38[15:0]));
    assign limb_8_38[16:16] = '0;
    assign limb_8_39 = limb_8_38[15:0]; // decl: <none>; prim: <none>
    assign limb_8_40 = {limb_8_39, rtlzz_pipe_34_s4, rtlzz_pipe_29_s4, rtlzz_pipe_24_s4}; // decl: <none>; prim: <none>
    assign limb_10_41 = s8_norm_mul_3_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_10_42 = c2[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_43Core rtlzz_owner_43(.a(16'(limb_10_41)), .b(16'(rtlzz_pipe_42_s5)), .cin(1'h0), .value(limb_10_43));
    assign limb_10_44 = limb_10_43[15:0]; // decl: <none>; prim: <none>
    assign limb_10_45 = limb_10_43[16]; // decl: <none>; prim: <none>
    assign limb_10_46 = s8_norm_mul_3_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_10_47 = c2[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(rtlzz_pipe_46_s6)), .b(16'(rtlzz_pipe_47_s6)), .cin(rtlzz_pipe_45_s6), .value(limb_10_48));
    assign limb_10_49 = limb_10_48[15:0]; // decl: <none>; prim: <none>
    assign limb_10_50 = limb_10_48[16]; // decl: <none>; prim: <none>
    assign limb_10_51 = s8_norm_mul_3_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_10_52 = c2[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(16'(rtlzz_pipe_51_s6)), .b(16'(rtlzz_pipe_52_s6)), .cin(limb_10_50), .value(limb_10_53));
    assign limb_10_54 = limb_10_53[15:0]; // decl: <none>; prim: <none>
    assign limb_10_55 = limb_10_53[16]; // decl: <none>; prim: <none>
    assign limb_10_56 = s8_norm_mul_3_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_10_57 = c2[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(16'(rtlzz_pipe_56_s6)), .b(16'(rtlzz_pipe_57_s6)), .cin(limb_10_55), .value(limb_10_58[15:0]));
    assign limb_10_58[16:16] = '0;
    assign limb_10_59 = limb_10_58[15:0]; // decl: <none>; prim: <none>
    assign limb_10_60 = {limb_10_59, limb_10_54, limb_10_49, rtlzz_pipe_44_s6}; // decl: <none>; prim: <none>
    assign limb_12_61 = s8_norm_mul_6_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_12_62 = c1[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(16'(limb_12_61)), .b(16'(rtlzz_pipe_62_s7)), .cin(1'h0), .value(limb_12_63));
    assign limb_12_64 = limb_12_63[15:0]; // decl: <none>; prim: <none>
    assign limb_12_65 = limb_12_63[16]; // decl: <none>; prim: <none>
    assign limb_12_66 = s8_norm_mul_6_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_12_67 = c1[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(limb_12_66)), .b(16'(rtlzz_pipe_67_s7)), .cin(limb_12_65), .value(limb_12_68));
    assign limb_12_69 = limb_12_68[15:0]; // decl: <none>; prim: <none>
    assign limb_12_70 = limb_12_68[16]; // decl: <none>; prim: <none>
    assign limb_12_71 = s8_norm_mul_6_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_12_72 = c1[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(16'(limb_12_71)), .b(16'(rtlzz_pipe_72_s7)), .cin(limb_12_70), .value(limb_12_73));
    assign limb_12_74 = limb_12_73[15:0]; // decl: <none>; prim: <none>
    assign limb_12_75 = limb_12_73[16]; // decl: <none>; prim: <none>
    assign limb_12_76 = s8_norm_mul_6_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_12_77 = c1[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(16'(limb_12_76)), .b(16'(rtlzz_pipe_77_s7)), .cin(limb_12_75), .value(limb_12_78[15:0]));
    assign limb_12_78[16:16] = '0;
    assign limb_12_79 = limb_12_78[15:0]; // decl: <none>; prim: <none>
    assign limb_12_80 = {limb_12_79, limb_12_74, limb_12_69, limb_12_64}; // decl: <none>; prim: <none>
    assign limb_14_81 = s8_norm_mul_9_v0[15:0]; // decl: <none>; prim: <none>
    assign limb_14_82 = c0[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_83Core rtlzz_owner_83(.a(16'(limb_14_81)), .b(16'(rtlzz_pipe_82_s7)), .cin(1'h0), .value(limb_14_83));
    assign limb_14_84 = limb_14_83[15:0]; // decl: <none>; prim: <none>
    assign limb_14_85 = limb_14_83[16]; // decl: <none>; prim: <none>
    assign limb_14_86 = s8_norm_mul_9_v0[31:16]; // decl: <none>; prim: <none>
    assign limb_14_87 = c0[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(limb_14_86)), .b(16'(rtlzz_pipe_87_s7)), .cin(limb_14_85), .value(limb_14_88));
    assign limb_14_89 = limb_14_88[15:0]; // decl: <none>; prim: <none>
    assign limb_14_90 = limb_14_88[16]; // decl: <none>; prim: <none>
    assign limb_14_91 = s8_norm_mul_9_v0[47:32]; // decl: <none>; prim: <none>
    assign limb_14_92 = c0[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_93Core rtlzz_owner_93(.a(16'(limb_14_91)), .b(16'(rtlzz_pipe_92_s7)), .cin(limb_14_90), .value(limb_14_93));
    assign limb_14_94 = limb_14_93[15:0]; // decl: <none>; prim: <none>
    assign limb_14_95 = limb_14_93[16]; // decl: <none>; prim: <none>
    assign limb_14_96 = s8_norm_mul_9_v0[63:48]; // decl: <none>; prim: <none>
    assign limb_14_97 = c0[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(16'(limb_14_96)), .b(16'(rtlzz_pipe_97_s7)), .cin(limb_14_95), .value(limb_14_98[15:0]));
    assign limb_14_98[16:16] = '0;
    assign limb_14_99 = limb_14_98[15:0]; // decl: <none>; prim: <none>
    assign limb_14_100 = {limb_14_99, limb_14_94, limb_14_89, limb_14_84}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_21_s1 <= 16'h0;
            rtlzz_pipe_22_s1 <= 16'h0;
            rtlzz_pipe_24_s2 <= 16'h0;
            rtlzz_pipe_24_s3 <= 16'h0;
            rtlzz_pipe_24_s4 <= 16'h0;
            rtlzz_pipe_25_s2 <= 1'h0;
            rtlzz_pipe_26_s1 <= 16'h0;
            rtlzz_pipe_26_s2 <= 16'h0;
            rtlzz_pipe_27_s1 <= 16'h0;
            rtlzz_pipe_27_s2 <= 16'h0;
            rtlzz_pipe_29_s3 <= 16'h0;
            rtlzz_pipe_29_s4 <= 16'h0;
            rtlzz_pipe_30_s3 <= 1'h0;
            rtlzz_pipe_31_s1 <= 16'h0;
            rtlzz_pipe_31_s2 <= 16'h0;
            rtlzz_pipe_31_s3 <= 16'h0;
            rtlzz_pipe_32_s1 <= 16'h0;
            rtlzz_pipe_32_s2 <= 16'h0;
            rtlzz_pipe_32_s3 <= 16'h0;
            rtlzz_pipe_34_s4 <= 16'h0;
            rtlzz_pipe_35_s4 <= 1'h0;
            rtlzz_pipe_36_s1 <= 16'h0;
            rtlzz_pipe_36_s2 <= 16'h0;
            rtlzz_pipe_36_s3 <= 16'h0;
            rtlzz_pipe_36_s4 <= 16'h0;
            rtlzz_pipe_37_s1 <= 16'h0;
            rtlzz_pipe_37_s2 <= 16'h0;
            rtlzz_pipe_37_s3 <= 16'h0;
            rtlzz_pipe_37_s4 <= 16'h0;
            rtlzz_pipe_8_s5 <= 64'h0;
            rtlzz_pipe_42_s1 <= 16'h0;
            rtlzz_pipe_42_s2 <= 16'h0;
            rtlzz_pipe_42_s3 <= 16'h0;
            rtlzz_pipe_42_s4 <= 16'h0;
            rtlzz_pipe_42_s5 <= 16'h0;
            rtlzz_pipe_44_s6 <= 16'h0;
            rtlzz_pipe_45_s6 <= 1'h0;
            rtlzz_pipe_46_s6 <= 16'h0;
            rtlzz_pipe_47_s1 <= 16'h0;
            rtlzz_pipe_47_s2 <= 16'h0;
            rtlzz_pipe_47_s3 <= 16'h0;
            rtlzz_pipe_47_s4 <= 16'h0;
            rtlzz_pipe_47_s5 <= 16'h0;
            rtlzz_pipe_47_s6 <= 16'h0;
            rtlzz_pipe_51_s6 <= 16'h0;
            rtlzz_pipe_52_s1 <= 16'h0;
            rtlzz_pipe_52_s2 <= 16'h0;
            rtlzz_pipe_52_s3 <= 16'h0;
            rtlzz_pipe_52_s4 <= 16'h0;
            rtlzz_pipe_52_s5 <= 16'h0;
            rtlzz_pipe_52_s6 <= 16'h0;
            rtlzz_pipe_56_s6 <= 16'h0;
            rtlzz_pipe_57_s1 <= 16'h0;
            rtlzz_pipe_57_s2 <= 16'h0;
            rtlzz_pipe_57_s3 <= 16'h0;
            rtlzz_pipe_57_s4 <= 16'h0;
            rtlzz_pipe_57_s5 <= 16'h0;
            rtlzz_pipe_57_s6 <= 16'h0;
            rtlzz_pipe_10_s7 <= 64'h0;
            rtlzz_pipe_62_s1 <= 16'h0;
            rtlzz_pipe_62_s2 <= 16'h0;
            rtlzz_pipe_62_s3 <= 16'h0;
            rtlzz_pipe_62_s4 <= 16'h0;
            rtlzz_pipe_62_s5 <= 16'h0;
            rtlzz_pipe_62_s6 <= 16'h0;
            rtlzz_pipe_62_s7 <= 16'h0;
            rtlzz_pipe_67_s1 <= 16'h0;
            rtlzz_pipe_67_s2 <= 16'h0;
            rtlzz_pipe_67_s3 <= 16'h0;
            rtlzz_pipe_67_s4 <= 16'h0;
            rtlzz_pipe_67_s5 <= 16'h0;
            rtlzz_pipe_67_s6 <= 16'h0;
            rtlzz_pipe_67_s7 <= 16'h0;
            rtlzz_pipe_72_s1 <= 16'h0;
            rtlzz_pipe_72_s2 <= 16'h0;
            rtlzz_pipe_72_s3 <= 16'h0;
            rtlzz_pipe_72_s4 <= 16'h0;
            rtlzz_pipe_72_s5 <= 16'h0;
            rtlzz_pipe_72_s6 <= 16'h0;
            rtlzz_pipe_72_s7 <= 16'h0;
            rtlzz_pipe_77_s1 <= 16'h0;
            rtlzz_pipe_77_s2 <= 16'h0;
            rtlzz_pipe_77_s3 <= 16'h0;
            rtlzz_pipe_77_s4 <= 16'h0;
            rtlzz_pipe_77_s5 <= 16'h0;
            rtlzz_pipe_77_s6 <= 16'h0;
            rtlzz_pipe_77_s7 <= 16'h0;
            rtlzz_pipe_82_s1 <= 16'h0;
            rtlzz_pipe_82_s2 <= 16'h0;
            rtlzz_pipe_82_s3 <= 16'h0;
            rtlzz_pipe_82_s4 <= 16'h0;
            rtlzz_pipe_82_s5 <= 16'h0;
            rtlzz_pipe_82_s6 <= 16'h0;
            rtlzz_pipe_82_s7 <= 16'h0;
            rtlzz_pipe_87_s1 <= 16'h0;
            rtlzz_pipe_87_s2 <= 16'h0;
            rtlzz_pipe_87_s3 <= 16'h0;
            rtlzz_pipe_87_s4 <= 16'h0;
            rtlzz_pipe_87_s5 <= 16'h0;
            rtlzz_pipe_87_s6 <= 16'h0;
            rtlzz_pipe_87_s7 <= 16'h0;
            rtlzz_pipe_92_s1 <= 16'h0;
            rtlzz_pipe_92_s2 <= 16'h0;
            rtlzz_pipe_92_s3 <= 16'h0;
            rtlzz_pipe_92_s4 <= 16'h0;
            rtlzz_pipe_92_s5 <= 16'h0;
            rtlzz_pipe_92_s6 <= 16'h0;
            rtlzz_pipe_92_s7 <= 16'h0;
            rtlzz_pipe_97_s1 <= 16'h0;
            rtlzz_pipe_97_s2 <= 16'h0;
            rtlzz_pipe_97_s3 <= 16'h0;
            rtlzz_pipe_97_s4 <= 16'h0;
            rtlzz_pipe_97_s5 <= 16'h0;
            rtlzz_pipe_97_s6 <= 16'h0;
            rtlzz_pipe_97_s7 <= 16'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_8_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_8_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= limb_8_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_24_s4 <= rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= limb_8_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_8_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_8_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_27_s2 <= rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_29_s3 <= limb_8_29; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_29_s4 <= rtlzz_pipe_29_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_30_s3 <= limb_8_30; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= limb_8_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_31_s3 <= rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= limb_8_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_34_s4 <= limb_8_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= limb_8_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_36_s1 <= limb_8_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_36_s3 <= rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_36_s4 <= rtlzz_pipe_36_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_8_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_37_s3 <= rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_37_s4 <= rtlzz_pipe_37_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_8_s5 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_10_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_42_s4 <= rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_42_s5 <= rtlzz_pipe_42_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_44_s6 <= limb_10_44; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= limb_10_45; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_46_s6 <= limb_10_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= limb_10_47; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_47_s3 <= rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_47_s4 <= rtlzz_pipe_47_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_47_s5 <= rtlzz_pipe_47_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_47_s6 <= rtlzz_pipe_47_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_51_s6 <= limb_10_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_52_s1 <= limb_10_52; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_52_s2 <= rtlzz_pipe_52_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_52_s3 <= rtlzz_pipe_52_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= rtlzz_pipe_52_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_56_s6 <= limb_10_56; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= limb_10_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_57_s3 <= rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_57_s4 <= rtlzz_pipe_57_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_57_s5 <= rtlzz_pipe_57_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_57_s6 <= rtlzz_pipe_57_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= limb_12_62; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_62_s2 <= rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_62_s3 <= rtlzz_pipe_62_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_62_s4 <= rtlzz_pipe_62_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_62_s5 <= rtlzz_pipe_62_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_62_s6 <= rtlzz_pipe_62_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_62_s7 <= rtlzz_pipe_62_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= limb_12_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_67_s2 <= rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_67_s3 <= rtlzz_pipe_67_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_67_s4 <= rtlzz_pipe_67_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_67_s5 <= rtlzz_pipe_67_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= rtlzz_pipe_67_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_67_s7 <= rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_72_s1 <= limb_12_72; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_72_s2 <= rtlzz_pipe_72_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_72_s3 <= rtlzz_pipe_72_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_72_s4 <= rtlzz_pipe_72_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_72_s5 <= rtlzz_pipe_72_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_72_s6 <= rtlzz_pipe_72_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_72_s7 <= rtlzz_pipe_72_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= limb_12_77; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_77_s2 <= rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_77_s3 <= rtlzz_pipe_77_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_77_s4 <= rtlzz_pipe_77_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_77_s5 <= rtlzz_pipe_77_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_77_s6 <= rtlzz_pipe_77_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_77_s7 <= rtlzz_pipe_77_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= limb_14_82; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_82_s2 <= rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_82_s3 <= rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_82_s4 <= rtlzz_pipe_82_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_82_s5 <= rtlzz_pipe_82_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_82_s6 <= rtlzz_pipe_82_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_82_s7 <= rtlzz_pipe_82_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_87_s1 <= limb_14_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_87_s2 <= rtlzz_pipe_87_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_87_s3 <= rtlzz_pipe_87_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_87_s4 <= rtlzz_pipe_87_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_87_s5 <= rtlzz_pipe_87_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= rtlzz_pipe_87_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_87_s7 <= rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_92_s1 <= limb_14_92; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_92_s2 <= rtlzz_pipe_92_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_92_s3 <= rtlzz_pipe_92_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_92_s4 <= rtlzz_pipe_92_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_92_s5 <= rtlzz_pipe_92_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_92_s6 <= rtlzz_pipe_92_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_92_s7 <= rtlzz_pipe_92_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= limb_14_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_97_s3 <= rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_97_s4 <= rtlzz_pipe_97_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_97_s5 <= rtlzz_pipe_97_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_97_s6 <= rtlzz_pipe_97_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_97_s7 <= rtlzz_pipe_97_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_33Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_33();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_43Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_43();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_83Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_83();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_93Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [16:0] aa=17'(masked_a);
wire [16:0] bb=17'(masked_b);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(cin);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_93();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [15:0] aa=16'(masked_a);
wire [15:0] bb=16'(masked_b);
wire [16:0] extended={1'b0,aa}+{1'b0,bb}+17'(cin);
wire [15:0] native_value=extended[15:0];
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
