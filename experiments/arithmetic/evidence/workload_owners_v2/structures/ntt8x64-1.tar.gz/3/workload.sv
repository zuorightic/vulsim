`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] x1, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] x2, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] x3, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] x4, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] x5, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] x6, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] x7, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    output logic [63:0] y0, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    output logic [63:0] y1, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    output logic [63:0] y2, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    output logic [63:0] y3, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    output logic [63:0] y4, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    output logic [63:0] y5, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    output logic [63:0] y6, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    output logic [63:0] y7, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:8; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [64:0] tmp_workload_top_int_65__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] tmp_workload_top_int_65__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    logic [64:0] s8_norm_add_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_sub_20_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:18-44:62; prim: /home/zyrv/vulsim/workload.cpp:44:18-44:62
    logic [64:0] tmp_workload_top_int_65__41_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] tmp_workload_top_int_65__43_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    logic [64:0] s8_norm_add_34_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic s8_norm_cmp_38_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_sub_40_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_mux_41_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:19-50:66; prim: /home/zyrv/vulsim/workload.cpp:50:19-50:66
    logic [64:0] tmp_workload_top_int_65__74_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] tmp_workload_top_int_65__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] s8_norm_add_54_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic s8_norm_cmp_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_sub_60_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_mux_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    logic [64:0] tmp_workload_top_int_65__107_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] tmp_workload_top_int_65__109_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_mux_71_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
    logic [64:0] s8_norm_add_74_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic s8_norm_cmp_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_mux_81_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:19-62:66; prim: /home/zyrv/vulsim/workload.cpp:62:19-62:66
    logic [64:0] tmp_workload_top_int_65__140_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] tmp_workload_top_int_65__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    logic [64:0] s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic s8_norm_cmp_88_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_sub_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_mux_91_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
    logic [64:0] s8_norm_add_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic s8_norm_cmp_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_mux_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
    logic [127:0] tmp_workload_top_int_128__175_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    logic [255:0] s8_norm_mul_106_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:49; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:31
    logic [192:0] tmp_workload_top_int_193__180_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    logic [385:0] s8_norm_mul_110_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n34_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    logic [257:0] s8_norm_mul_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:20-75:48; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:22
    logic [128:0] n36_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    logic [128:0] tmp_workload_top_int_129__191_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:39
    logic s8_norm_cmp_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:21-77:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_122_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:50-77:68; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_mux_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:69; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:69
    logic [64:0] tmp_workload_top_int_65__204_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] tmp_workload_top_int_65__206_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    logic [64:0] s8_norm_add_127_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:45; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:45
    logic s8_norm_cmp_129_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:20-80:37; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_sub_131_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:48-80:65; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_mux_132_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:66; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:66
    logic [64:0] s8_norm_add_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] s8_norm_sub_137_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:59; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:59
    logic s8_norm_cmp_139_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:20-82:37; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_sub_141_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:48-82:65; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_mux_142_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:19-82:66; prim: /home/zyrv/vulsim/workload.cpp:82:19-82:66
    logic [64:0] tmp_workload_top_int_65__237_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] tmp_workload_top_int_65__239_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    logic [64:0] s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_sub_151_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_mux_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
    logic [64:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic s8_norm_cmp_159_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_mux_162_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:66; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:66
    logic [127:0] tmp_workload_top_int_128__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    logic [255:0] s8_norm_mul_167_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:49; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:31
    logic [192:0] tmp_workload_top_int_193__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [385:0] s8_norm_mul_171_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n54_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    logic [257:0] s8_norm_mul_176_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:48; prim: /home/zyrv/vulsim/workload.cpp:94:19-94:22
    logic [128:0] n56_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    logic [128:0] tmp_workload_top_int_129__288_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_179_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:39
    logic s8_norm_cmp_181_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:21-97:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_183_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:50-97:68; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_mux_184_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:20-97:69; prim: /home/zyrv/vulsim/workload.cpp:97:20-97:69
    logic [64:0] tmp_workload_top_int_65__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] tmp_workload_top_int_65__303_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    logic [64:0] s8_norm_add_188_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:46; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:46
    logic s8_norm_cmp_190_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:20-100:37; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_sub_192_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:48-100:65; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_mux_193_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:19-100:66; prim: /home/zyrv/vulsim/workload.cpp:100:19-100:66
    logic [64:0] s8_norm_add_196_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] s8_norm_sub_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
    logic s8_norm_cmp_200_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_sub_202_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:48-102:65; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_mux_203_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:19-102:66; prim: /home/zyrv/vulsim/workload.cpp:102:19-102:66
    logic [64:0] tmp_workload_top_int_65__334_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    logic [64:0] tmp_workload_top_int_65__336_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    logic [64:0] s8_norm_add_208_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    logic s8_norm_cmp_210_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_sub_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:48-106:65; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_mux_213_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:19-106:66; prim: /home/zyrv/vulsim/workload.cpp:106:19-106:66
    logic [64:0] s8_norm_add_216_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:45; prim: /home/zyrv/vulsim/workload.cpp:69:19-69:31
    logic [64:0] s8_norm_sub_218_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
    logic s8_norm_cmp_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:20-108:37; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_sub_222_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:48-108:65; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_mux_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:19-108:66; prim: /home/zyrv/vulsim/workload.cpp:108:19-108:66
    logic [63:0] tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [127:0] tmp_workload_top_int_128__369_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    logic [255:0] s8_norm_mul_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:49; prim: /home/zyrv/vulsim/workload.cpp:103:19-103:31
    logic [192:0] tmp_workload_top_int_193__374_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    logic [385:0] s8_norm_mul_232_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    logic [257:0] s8_norm_mul_237_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:20-115:48; prim: /home/zyrv/vulsim/workload.cpp:114:19-114:22
    logic [128:0] n76_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    logic [128:0] tmp_workload_top_int_129__385_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_240_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:39
    logic s8_norm_cmp_242_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:21-117:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_244_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:50-117:68; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_mux_245_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:20-117:69; prim: /home/zyrv/vulsim/workload.cpp:117:20-117:69
    logic [64:0] tmp_workload_top_int_65__398_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    logic [64:0] tmp_workload_top_int_65__400_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    logic [64:0] s8_norm_add_249_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:46; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:46
    logic s8_norm_cmp_251_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:20-120:37; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_sub_253_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:48-120:65; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_mux_254_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:19-120:66; prim: /home/zyrv/vulsim/workload.cpp:120:19-120:66
    logic [64:0] s8_norm_add_257_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:45; prim: /home/zyrv/vulsim/workload.cpp:83:19-83:31
    logic [64:0] s8_norm_sub_259_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:60; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:60
    logic s8_norm_cmp_261_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:20-122:37; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_sub_263_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:48-122:65; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_mux_264_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:19-122:66; prim: /home/zyrv/vulsim/workload.cpp:122:19-122:66
    logic [63:0] tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    logic [63:0] tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    logic [127:0] tmp_workload_top_int_128__433_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    logic [255:0] s8_norm_mul_269_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:49; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:31
    logic [192:0] tmp_workload_top_int_193__438_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    logic [385:0] s8_norm_mul_273_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n88_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    logic [257:0] s8_norm_mul_278_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:20-129:48; prim: /home/zyrv/vulsim/workload.cpp:128:19-128:22
    logic [128:0] n90_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    logic [128:0] tmp_workload_top_int_129__449_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_281_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
    logic s8_norm_cmp_283_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:21-131:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_285_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:50-131:68; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_mux_286_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:20-131:69; prim: /home/zyrv/vulsim/workload.cpp:131:20-131:69
    logic [64:0] tmp_workload_top_int_65__462_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    logic [64:0] tmp_workload_top_int_65__464_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    logic [64:0] s8_norm_add_290_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:46; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:46
    logic s8_norm_cmp_292_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:20-134:37; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_sub_294_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:48-134:65; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_mux_295_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:19-134:66; prim: /home/zyrv/vulsim/workload.cpp:134:19-134:66
    logic [64:0] s8_norm_add_298_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:45; prim: /home/zyrv/vulsim/workload.cpp:70:19-70:31
    logic [64:0] s8_norm_sub_300_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
    logic s8_norm_cmp_302_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_sub_304_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:48-136:65; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_mux_305_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:19-136:66; prim: /home/zyrv/vulsim/workload.cpp:136:19-136:66
    logic [63:0] tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    logic [63:0] tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    logic [127:0] tmp_workload_top_int_128__497_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    logic [255:0] s8_norm_mul_310_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:51; prim: /home/zyrv/vulsim/workload.cpp:104:19-104:31
    logic [192:0] tmp_workload_top_int_193__502_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    logic [385:0] s8_norm_mul_314_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:50; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n102_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    logic [257:0] s8_norm_mul_319_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:21-143:50; prim: /home/zyrv/vulsim/workload.cpp:142:20-142:24
    logic [128:0] n104_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    logic [128:0] tmp_workload_top_int_129__513_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_322_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:42; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:42
    logic s8_norm_cmp_324_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:22-145:41; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_326_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:53-145:72; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_mux_327_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:21-145:73; prim: /home/zyrv/vulsim/workload.cpp:145:21-145:73
    logic [64:0] tmp_workload_top_int_65__526_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    logic [64:0] tmp_workload_top_int_65__528_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    logic [64:0] s8_norm_add_331_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:48; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:48
    logic s8_norm_cmp_333_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:21-148:39; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_sub_335_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:51-148:69; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_mux_336_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:20-148:70; prim: /home/zyrv/vulsim/workload.cpp:148:20-148:70
    logic [64:0] s8_norm_add_339_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:46; prim: /home/zyrv/vulsim/workload.cpp:84:19-84:31
    logic [64:0] s8_norm_sub_341_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:62; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:62
    logic s8_norm_cmp_343_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:21-150:39; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_sub_345_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:51-150:69; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_mux_346_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:20-150:70; prim: /home/zyrv/vulsim/workload.cpp:150:20-150:70
    logic [63:0] tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    logic [63:0] tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    logic [127:0] __beopt_width_858; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_859; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_860; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_862; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_863; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_865; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_866; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_867; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_869; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_870; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_872; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_873; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_874; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_876; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_877; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_879; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_880; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_881; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_883; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_884; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_886; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_887; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_888; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_890; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_891; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_255; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    logic [128:0] __beopt_width_259; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    logic [128:0] __beopt_width_263; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    logic [128:0] __beopt_width_268; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    logic [128:0] __beopt_width_272; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    logic [128:0] __beopt_width_256; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_260; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_264; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_267; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_253; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_254; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_255; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_256; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_257; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_258; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_259; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_260; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_261; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_262; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_263; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_264; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_265; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_266; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_267; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_268; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_269; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_270; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_272; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_273; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_274; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_275; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_276; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_277; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_278; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_279; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_280; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_281; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_282; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_283; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_284; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_285; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_286; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_287; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_288; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_289; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_290; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_291; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [112:0] arith_original_298; // decl: <none>; prim: <none>
    logic [192:0] arith_original_299; // decl: <none>; prim: <none>
    logic [128:0] arith_original_300; // decl: <none>; prim: <none>
    logic [112:0] arith_original_301; // decl: <none>; prim: <none>
    logic [192:0] arith_original_302; // decl: <none>; prim: <none>
    logic [128:0] arith_original_303; // decl: <none>; prim: <none>
    logic [127:0] arith_original_304; // decl: <none>; prim: <none>
    logic [192:0] arith_original_305; // decl: <none>; prim: <none>
    logic [128:0] arith_original_306; // decl: <none>; prim: <none>
    logic [112:0] arith_original_307; // decl: <none>; prim: <none>
    logic [192:0] arith_original_308; // decl: <none>; prim: <none>
    logic [128:0] arith_original_309; // decl: <none>; prim: <none>
    logic [127:0] arith_original_310; // decl: <none>; prim: <none>
    logic [192:0] arith_original_311; // decl: <none>; prim: <none>
    logic [128:0] arith_original_312; // decl: <none>; prim: <none>
    logic [31:0] limb_11_313; // decl: <none>; prim: <none>
    logic [31:0] limb_11_314; // decl: <none>; prim: <none>
    logic [32:0] limb_11_315; // decl: <none>; prim: <none>
    logic [31:0] limb_11_316; // decl: <none>; prim: <none>
    logic limb_11_317; // decl: <none>; prim: <none>
    logic [31:0] limb_11_318; // decl: <none>; prim: <none>
    logic [31:0] limb_11_319; // decl: <none>; prim: <none>
    logic [32:0] limb_11_320; // decl: <none>; prim: <none>
    logic [31:0] limb_11_321; // decl: <none>; prim: <none>
    logic limb_11_322; // decl: <none>; prim: <none>
    logic limb_11_323; // decl: <none>; prim: <none>
    logic limb_11_324; // decl: <none>; prim: <none>
    logic [1:0] limb_11_325; // decl: <none>; prim: <none>
    logic limb_11_326; // decl: <none>; prim: <none>
    logic [64:0] limb_11_327; // decl: <none>; prim: <none>
    logic [31:0] limb_13_328; // decl: <none>; prim: <none>
    logic [31:0] limb_13_329; // decl: <none>; prim: <none>
    logic [31:0] limb_13_330; // decl: <none>; prim: <none>
    logic [32:0] limb_13_331; // decl: <none>; prim: <none>
    logic [31:0] limb_13_332; // decl: <none>; prim: <none>
    logic limb_13_333; // decl: <none>; prim: <none>
    logic [31:0] limb_13_334; // decl: <none>; prim: <none>
    logic [31:0] limb_13_335; // decl: <none>; prim: <none>
    logic [31:0] limb_13_336; // decl: <none>; prim: <none>
    logic [32:0] limb_13_337; // decl: <none>; prim: <none>
    logic [31:0] limb_13_338; // decl: <none>; prim: <none>
    logic limb_13_339; // decl: <none>; prim: <none>
    logic limb_13_340; // decl: <none>; prim: <none>
    logic limb_13_341; // decl: <none>; prim: <none>
    logic limb_13_342; // decl: <none>; prim: <none>
    logic [1:0] limb_13_343; // decl: <none>; prim: <none>
    logic limb_13_344; // decl: <none>; prim: <none>
    logic [64:0] limb_13_345; // decl: <none>; prim: <none>
    logic [31:0] limb_15_346; // decl: <none>; prim: <none>
    logic [31:0] limb_15_347; // decl: <none>; prim: <none>
    logic [32:0] limb_15_348; // decl: <none>; prim: <none>
    logic [31:0] limb_15_349; // decl: <none>; prim: <none>
    logic limb_15_350; // decl: <none>; prim: <none>
    logic [31:0] limb_15_351; // decl: <none>; prim: <none>
    logic [31:0] limb_15_352; // decl: <none>; prim: <none>
    logic [32:0] limb_15_353; // decl: <none>; prim: <none>
    logic [31:0] limb_15_354; // decl: <none>; prim: <none>
    logic limb_15_355; // decl: <none>; prim: <none>
    logic limb_15_356; // decl: <none>; prim: <none>
    logic limb_15_357; // decl: <none>; prim: <none>
    logic [1:0] limb_15_358; // decl: <none>; prim: <none>
    logic limb_15_359; // decl: <none>; prim: <none>
    logic [64:0] limb_15_360; // decl: <none>; prim: <none>
    logic [31:0] limb_16_361; // decl: <none>; prim: <none>
    logic [31:0] limb_16_362; // decl: <none>; prim: <none>
    logic [31:0] limb_16_363; // decl: <none>; prim: <none>
    logic [32:0] limb_16_364; // decl: <none>; prim: <none>
    logic [31:0] limb_16_365; // decl: <none>; prim: <none>
    logic limb_16_366; // decl: <none>; prim: <none>
    logic [31:0] limb_16_367; // decl: <none>; prim: <none>
    logic [31:0] limb_16_368; // decl: <none>; prim: <none>
    logic [31:0] limb_16_369; // decl: <none>; prim: <none>
    logic [32:0] limb_16_370; // decl: <none>; prim: <none>
    logic [31:0] limb_16_371; // decl: <none>; prim: <none>
    logic limb_16_372; // decl: <none>; prim: <none>
    logic limb_16_373; // decl: <none>; prim: <none>
    logic limb_16_374; // decl: <none>; prim: <none>
    logic limb_16_375; // decl: <none>; prim: <none>
    logic [1:0] limb_16_376; // decl: <none>; prim: <none>
    logic limb_16_377; // decl: <none>; prim: <none>
    logic [64:0] limb_16_378; // decl: <none>; prim: <none>
    logic [31:0] limb_18_379; // decl: <none>; prim: <none>
    logic [31:0] limb_18_380; // decl: <none>; prim: <none>
    logic [31:0] limb_18_381; // decl: <none>; prim: <none>
    logic [32:0] limb_18_382; // decl: <none>; prim: <none>
    logic [31:0] limb_18_383; // decl: <none>; prim: <none>
    logic limb_18_384; // decl: <none>; prim: <none>
    logic [31:0] limb_18_385; // decl: <none>; prim: <none>
    logic [31:0] limb_18_386; // decl: <none>; prim: <none>
    logic [31:0] limb_18_387; // decl: <none>; prim: <none>
    logic [32:0] limb_18_388; // decl: <none>; prim: <none>
    logic [31:0] limb_18_389; // decl: <none>; prim: <none>
    logic limb_18_390; // decl: <none>; prim: <none>
    logic limb_18_391; // decl: <none>; prim: <none>
    logic limb_18_392; // decl: <none>; prim: <none>
    logic limb_18_393; // decl: <none>; prim: <none>
    logic [1:0] limb_18_394; // decl: <none>; prim: <none>
    logic limb_18_395; // decl: <none>; prim: <none>
    logic [64:0] limb_18_396; // decl: <none>; prim: <none>
    logic [31:0] limb_22_397; // decl: <none>; prim: <none>
    logic [31:0] limb_22_398; // decl: <none>; prim: <none>
    logic [32:0] limb_22_399; // decl: <none>; prim: <none>
    logic [31:0] limb_22_400; // decl: <none>; prim: <none>
    logic limb_22_401; // decl: <none>; prim: <none>
    logic [31:0] limb_22_402; // decl: <none>; prim: <none>
    logic [31:0] limb_22_403; // decl: <none>; prim: <none>
    logic [32:0] limb_22_404; // decl: <none>; prim: <none>
    logic [31:0] limb_22_405; // decl: <none>; prim: <none>
    logic limb_22_406; // decl: <none>; prim: <none>
    logic limb_22_407; // decl: <none>; prim: <none>
    logic limb_22_408; // decl: <none>; prim: <none>
    logic [1:0] limb_22_409; // decl: <none>; prim: <none>
    logic limb_22_410; // decl: <none>; prim: <none>
    logic [64:0] limb_22_411; // decl: <none>; prim: <none>
    logic [31:0] limb_24_412; // decl: <none>; prim: <none>
    logic [31:0] limb_24_413; // decl: <none>; prim: <none>
    logic [31:0] limb_24_414; // decl: <none>; prim: <none>
    logic [32:0] limb_24_415; // decl: <none>; prim: <none>
    logic [31:0] limb_24_416; // decl: <none>; prim: <none>
    logic limb_24_417; // decl: <none>; prim: <none>
    logic [31:0] limb_24_418; // decl: <none>; prim: <none>
    logic [31:0] limb_24_419; // decl: <none>; prim: <none>
    logic [31:0] limb_24_420; // decl: <none>; prim: <none>
    logic [32:0] limb_24_421; // decl: <none>; prim: <none>
    logic [31:0] limb_24_422; // decl: <none>; prim: <none>
    logic limb_24_423; // decl: <none>; prim: <none>
    logic limb_24_424; // decl: <none>; prim: <none>
    logic limb_24_425; // decl: <none>; prim: <none>
    logic limb_24_426; // decl: <none>; prim: <none>
    logic [1:0] limb_24_427; // decl: <none>; prim: <none>
    logic limb_24_428; // decl: <none>; prim: <none>
    logic [64:0] limb_24_429; // decl: <none>; prim: <none>
    logic [31:0] limb_26_430; // decl: <none>; prim: <none>
    logic [31:0] limb_26_431; // decl: <none>; prim: <none>
    logic [32:0] limb_26_432; // decl: <none>; prim: <none>
    logic [31:0] limb_26_433; // decl: <none>; prim: <none>
    logic limb_26_434; // decl: <none>; prim: <none>
    logic [31:0] limb_26_435; // decl: <none>; prim: <none>
    logic [31:0] limb_26_436; // decl: <none>; prim: <none>
    logic [32:0] limb_26_437; // decl: <none>; prim: <none>
    logic [31:0] limb_26_438; // decl: <none>; prim: <none>
    logic limb_26_439; // decl: <none>; prim: <none>
    logic limb_26_440; // decl: <none>; prim: <none>
    logic limb_26_441; // decl: <none>; prim: <none>
    logic [1:0] limb_26_442; // decl: <none>; prim: <none>
    logic limb_26_443; // decl: <none>; prim: <none>
    logic [64:0] limb_26_444; // decl: <none>; prim: <none>
    logic [31:0] limb_27_445; // decl: <none>; prim: <none>
    logic [31:0] limb_27_446; // decl: <none>; prim: <none>
    logic [31:0] limb_27_447; // decl: <none>; prim: <none>
    logic [32:0] limb_27_448; // decl: <none>; prim: <none>
    logic [31:0] limb_27_449; // decl: <none>; prim: <none>
    logic limb_27_450; // decl: <none>; prim: <none>
    logic [31:0] limb_27_451; // decl: <none>; prim: <none>
    logic [31:0] limb_27_452; // decl: <none>; prim: <none>
    logic [31:0] limb_27_453; // decl: <none>; prim: <none>
    logic [32:0] limb_27_454; // decl: <none>; prim: <none>
    logic [31:0] limb_27_455; // decl: <none>; prim: <none>
    logic limb_27_456; // decl: <none>; prim: <none>
    logic limb_27_457; // decl: <none>; prim: <none>
    logic limb_27_458; // decl: <none>; prim: <none>
    logic limb_27_459; // decl: <none>; prim: <none>
    logic [1:0] limb_27_460; // decl: <none>; prim: <none>
    logic limb_27_461; // decl: <none>; prim: <none>
    logic [64:0] limb_27_462; // decl: <none>; prim: <none>
    logic [31:0] limb_29_463; // decl: <none>; prim: <none>
    logic [31:0] limb_29_464; // decl: <none>; prim: <none>
    logic [31:0] limb_29_465; // decl: <none>; prim: <none>
    logic [32:0] limb_29_466; // decl: <none>; prim: <none>
    logic [31:0] limb_29_467; // decl: <none>; prim: <none>
    logic limb_29_468; // decl: <none>; prim: <none>
    logic [31:0] limb_29_469; // decl: <none>; prim: <none>
    logic [31:0] limb_29_470; // decl: <none>; prim: <none>
    logic [31:0] limb_29_471; // decl: <none>; prim: <none>
    logic [32:0] limb_29_472; // decl: <none>; prim: <none>
    logic [31:0] limb_29_473; // decl: <none>; prim: <none>
    logic limb_29_474; // decl: <none>; prim: <none>
    logic limb_29_475; // decl: <none>; prim: <none>
    logic limb_29_476; // decl: <none>; prim: <none>
    logic limb_29_477; // decl: <none>; prim: <none>
    logic [1:0] limb_29_478; // decl: <none>; prim: <none>
    logic limb_29_479; // decl: <none>; prim: <none>
    logic [64:0] limb_29_480; // decl: <none>; prim: <none>
    logic [31:0] limb_33_481; // decl: <none>; prim: <none>
    logic [31:0] limb_33_482; // decl: <none>; prim: <none>
    logic [32:0] limb_33_483; // decl: <none>; prim: <none>
    logic [31:0] limb_33_484; // decl: <none>; prim: <none>
    logic limb_33_485; // decl: <none>; prim: <none>
    logic [31:0] limb_33_486; // decl: <none>; prim: <none>
    logic [31:0] limb_33_487; // decl: <none>; prim: <none>
    logic [32:0] limb_33_488; // decl: <none>; prim: <none>
    logic [31:0] limb_33_489; // decl: <none>; prim: <none>
    logic limb_33_490; // decl: <none>; prim: <none>
    logic limb_33_491; // decl: <none>; prim: <none>
    logic limb_33_492; // decl: <none>; prim: <none>
    logic [1:0] limb_33_493; // decl: <none>; prim: <none>
    logic limb_33_494; // decl: <none>; prim: <none>
    logic [64:0] limb_33_495; // decl: <none>; prim: <none>
    logic [31:0] limb_35_496; // decl: <none>; prim: <none>
    logic [31:0] limb_35_497; // decl: <none>; prim: <none>
    logic [31:0] limb_35_498; // decl: <none>; prim: <none>
    logic [32:0] limb_35_499; // decl: <none>; prim: <none>
    logic [31:0] limb_35_500; // decl: <none>; prim: <none>
    logic limb_35_501; // decl: <none>; prim: <none>
    logic [31:0] limb_35_502; // decl: <none>; prim: <none>
    logic [31:0] limb_35_503; // decl: <none>; prim: <none>
    logic [31:0] limb_35_504; // decl: <none>; prim: <none>
    logic [32:0] limb_35_505; // decl: <none>; prim: <none>
    logic [31:0] limb_35_506; // decl: <none>; prim: <none>
    logic limb_35_507; // decl: <none>; prim: <none>
    logic limb_35_508; // decl: <none>; prim: <none>
    logic limb_35_509; // decl: <none>; prim: <none>
    logic limb_35_510; // decl: <none>; prim: <none>
    logic [1:0] limb_35_511; // decl: <none>; prim: <none>
    logic limb_35_512; // decl: <none>; prim: <none>
    logic [64:0] limb_35_513; // decl: <none>; prim: <none>
    logic [31:0] limb_37_514; // decl: <none>; prim: <none>
    logic [31:0] limb_37_515; // decl: <none>; prim: <none>
    logic [32:0] limb_37_516; // decl: <none>; prim: <none>
    logic [31:0] limb_37_517; // decl: <none>; prim: <none>
    logic limb_37_518; // decl: <none>; prim: <none>
    logic [31:0] limb_37_519; // decl: <none>; prim: <none>
    logic [31:0] limb_37_520; // decl: <none>; prim: <none>
    logic [32:0] limb_37_521; // decl: <none>; prim: <none>
    logic [31:0] limb_37_522; // decl: <none>; prim: <none>
    logic limb_37_523; // decl: <none>; prim: <none>
    logic limb_37_524; // decl: <none>; prim: <none>
    logic limb_37_525; // decl: <none>; prim: <none>
    logic [1:0] limb_37_526; // decl: <none>; prim: <none>
    logic limb_37_527; // decl: <none>; prim: <none>
    logic [64:0] limb_37_528; // decl: <none>; prim: <none>
    logic [31:0] limb_38_529; // decl: <none>; prim: <none>
    logic [31:0] limb_38_530; // decl: <none>; prim: <none>
    logic [31:0] limb_38_531; // decl: <none>; prim: <none>
    logic [32:0] limb_38_532; // decl: <none>; prim: <none>
    logic [31:0] limb_38_533; // decl: <none>; prim: <none>
    logic limb_38_534; // decl: <none>; prim: <none>
    logic [31:0] limb_38_535; // decl: <none>; prim: <none>
    logic [31:0] limb_38_536; // decl: <none>; prim: <none>
    logic [31:0] limb_38_537; // decl: <none>; prim: <none>
    logic [32:0] limb_38_538; // decl: <none>; prim: <none>
    logic [31:0] limb_38_539; // decl: <none>; prim: <none>
    logic limb_38_540; // decl: <none>; prim: <none>
    logic limb_38_541; // decl: <none>; prim: <none>
    logic limb_38_542; // decl: <none>; prim: <none>
    logic limb_38_543; // decl: <none>; prim: <none>
    logic [1:0] limb_38_544; // decl: <none>; prim: <none>
    logic limb_38_545; // decl: <none>; prim: <none>
    logic [64:0] limb_38_546; // decl: <none>; prim: <none>
    logic [31:0] limb_40_547; // decl: <none>; prim: <none>
    logic [31:0] limb_40_548; // decl: <none>; prim: <none>
    logic [31:0] limb_40_549; // decl: <none>; prim: <none>
    logic [32:0] limb_40_550; // decl: <none>; prim: <none>
    logic [31:0] limb_40_551; // decl: <none>; prim: <none>
    logic limb_40_552; // decl: <none>; prim: <none>
    logic [31:0] limb_40_553; // decl: <none>; prim: <none>
    logic [31:0] limb_40_554; // decl: <none>; prim: <none>
    logic [31:0] limb_40_555; // decl: <none>; prim: <none>
    logic [32:0] limb_40_556; // decl: <none>; prim: <none>
    logic [31:0] limb_40_557; // decl: <none>; prim: <none>
    logic limb_40_558; // decl: <none>; prim: <none>
    logic limb_40_559; // decl: <none>; prim: <none>
    logic limb_40_560; // decl: <none>; prim: <none>
    logic limb_40_561; // decl: <none>; prim: <none>
    logic [1:0] limb_40_562; // decl: <none>; prim: <none>
    logic limb_40_563; // decl: <none>; prim: <none>
    logic [64:0] limb_40_564; // decl: <none>; prim: <none>
    logic [31:0] limb_44_565; // decl: <none>; prim: <none>
    logic [31:0] limb_44_566; // decl: <none>; prim: <none>
    logic [32:0] limb_44_567; // decl: <none>; prim: <none>
    logic [31:0] limb_44_568; // decl: <none>; prim: <none>
    logic limb_44_569; // decl: <none>; prim: <none>
    logic [31:0] limb_44_570; // decl: <none>; prim: <none>
    logic [31:0] limb_44_571; // decl: <none>; prim: <none>
    logic [32:0] limb_44_572; // decl: <none>; prim: <none>
    logic [31:0] limb_44_573; // decl: <none>; prim: <none>
    logic limb_44_574; // decl: <none>; prim: <none>
    logic limb_44_575; // decl: <none>; prim: <none>
    logic limb_44_576; // decl: <none>; prim: <none>
    logic [1:0] limb_44_577; // decl: <none>; prim: <none>
    logic limb_44_578; // decl: <none>; prim: <none>
    logic [64:0] limb_44_579; // decl: <none>; prim: <none>
    logic [31:0] limb_46_580; // decl: <none>; prim: <none>
    logic [31:0] limb_46_581; // decl: <none>; prim: <none>
    logic [31:0] limb_46_582; // decl: <none>; prim: <none>
    logic [32:0] limb_46_583; // decl: <none>; prim: <none>
    logic [31:0] limb_46_584; // decl: <none>; prim: <none>
    logic limb_46_585; // decl: <none>; prim: <none>
    logic [31:0] limb_46_586; // decl: <none>; prim: <none>
    logic [31:0] limb_46_587; // decl: <none>; prim: <none>
    logic [31:0] limb_46_588; // decl: <none>; prim: <none>
    logic [32:0] limb_46_589; // decl: <none>; prim: <none>
    logic [31:0] limb_46_590; // decl: <none>; prim: <none>
    logic limb_46_591; // decl: <none>; prim: <none>
    logic limb_46_592; // decl: <none>; prim: <none>
    logic limb_46_593; // decl: <none>; prim: <none>
    logic limb_46_594; // decl: <none>; prim: <none>
    logic [1:0] limb_46_595; // decl: <none>; prim: <none>
    logic limb_46_596; // decl: <none>; prim: <none>
    logic [64:0] limb_46_597; // decl: <none>; prim: <none>
    logic [31:0] limb_48_598; // decl: <none>; prim: <none>
    logic [31:0] limb_48_599; // decl: <none>; prim: <none>
    logic [32:0] limb_48_600; // decl: <none>; prim: <none>
    logic [31:0] limb_48_601; // decl: <none>; prim: <none>
    logic limb_48_602; // decl: <none>; prim: <none>
    logic [31:0] limb_48_603; // decl: <none>; prim: <none>
    logic [31:0] limb_48_604; // decl: <none>; prim: <none>
    logic [32:0] limb_48_605; // decl: <none>; prim: <none>
    logic [31:0] limb_48_606; // decl: <none>; prim: <none>
    logic limb_48_607; // decl: <none>; prim: <none>
    logic limb_48_608; // decl: <none>; prim: <none>
    logic limb_48_609; // decl: <none>; prim: <none>
    logic [1:0] limb_48_610; // decl: <none>; prim: <none>
    logic limb_48_611; // decl: <none>; prim: <none>
    logic [64:0] limb_48_612; // decl: <none>; prim: <none>
    logic [31:0] limb_49_613; // decl: <none>; prim: <none>
    logic [31:0] limb_49_614; // decl: <none>; prim: <none>
    logic [31:0] limb_49_615; // decl: <none>; prim: <none>
    logic [32:0] limb_49_616; // decl: <none>; prim: <none>
    logic [31:0] limb_49_617; // decl: <none>; prim: <none>
    logic limb_49_618; // decl: <none>; prim: <none>
    logic [31:0] limb_49_619; // decl: <none>; prim: <none>
    logic [31:0] limb_49_620; // decl: <none>; prim: <none>
    logic [31:0] limb_49_621; // decl: <none>; prim: <none>
    logic [32:0] limb_49_622; // decl: <none>; prim: <none>
    logic [31:0] limb_49_623; // decl: <none>; prim: <none>
    logic limb_49_624; // decl: <none>; prim: <none>
    logic limb_49_625; // decl: <none>; prim: <none>
    logic limb_49_626; // decl: <none>; prim: <none>
    logic limb_49_627; // decl: <none>; prim: <none>
    logic [1:0] limb_49_628; // decl: <none>; prim: <none>
    logic limb_49_629; // decl: <none>; prim: <none>
    logic [64:0] limb_49_630; // decl: <none>; prim: <none>
    logic [31:0] limb_51_631; // decl: <none>; prim: <none>
    logic [31:0] limb_51_632; // decl: <none>; prim: <none>
    logic [31:0] limb_51_633; // decl: <none>; prim: <none>
    logic [32:0] limb_51_634; // decl: <none>; prim: <none>
    logic [31:0] limb_51_635; // decl: <none>; prim: <none>
    logic limb_51_636; // decl: <none>; prim: <none>
    logic [31:0] limb_51_637; // decl: <none>; prim: <none>
    logic [31:0] limb_51_638; // decl: <none>; prim: <none>
    logic [31:0] limb_51_639; // decl: <none>; prim: <none>
    logic [32:0] limb_51_640; // decl: <none>; prim: <none>
    logic [31:0] limb_51_641; // decl: <none>; prim: <none>
    logic limb_51_642; // decl: <none>; prim: <none>
    logic limb_51_643; // decl: <none>; prim: <none>
    logic limb_51_644; // decl: <none>; prim: <none>
    logic limb_51_645; // decl: <none>; prim: <none>
    logic [1:0] limb_51_646; // decl: <none>; prim: <none>
    logic limb_51_647; // decl: <none>; prim: <none>
    logic [64:0] limb_51_648; // decl: <none>; prim: <none>
    logic [31:0] limb_55_649; // decl: <none>; prim: <none>
    logic [31:0] limb_55_650; // decl: <none>; prim: <none>
    logic [32:0] limb_55_651; // decl: <none>; prim: <none>
    logic [31:0] limb_55_652; // decl: <none>; prim: <none>
    logic limb_55_653; // decl: <none>; prim: <none>
    logic [31:0] limb_55_654; // decl: <none>; prim: <none>
    logic [31:0] limb_55_655; // decl: <none>; prim: <none>
    logic [32:0] limb_55_656; // decl: <none>; prim: <none>
    logic [31:0] limb_55_657; // decl: <none>; prim: <none>
    logic limb_55_658; // decl: <none>; prim: <none>
    logic limb_55_659; // decl: <none>; prim: <none>
    logic limb_55_660; // decl: <none>; prim: <none>
    logic [1:0] limb_55_661; // decl: <none>; prim: <none>
    logic limb_55_662; // decl: <none>; prim: <none>
    logic [64:0] limb_55_663; // decl: <none>; prim: <none>
    logic [31:0] limb_57_664; // decl: <none>; prim: <none>
    logic [31:0] limb_57_665; // decl: <none>; prim: <none>
    logic [31:0] limb_57_666; // decl: <none>; prim: <none>
    logic [32:0] limb_57_667; // decl: <none>; prim: <none>
    logic [31:0] limb_57_668; // decl: <none>; prim: <none>
    logic limb_57_669; // decl: <none>; prim: <none>
    logic [31:0] limb_57_670; // decl: <none>; prim: <none>
    logic [31:0] limb_57_671; // decl: <none>; prim: <none>
    logic [31:0] limb_57_672; // decl: <none>; prim: <none>
    logic [32:0] limb_57_673; // decl: <none>; prim: <none>
    logic [31:0] limb_57_674; // decl: <none>; prim: <none>
    logic limb_57_675; // decl: <none>; prim: <none>
    logic limb_57_676; // decl: <none>; prim: <none>
    logic limb_57_677; // decl: <none>; prim: <none>
    logic limb_57_678; // decl: <none>; prim: <none>
    logic [1:0] limb_57_679; // decl: <none>; prim: <none>
    logic limb_57_680; // decl: <none>; prim: <none>
    logic [64:0] limb_57_681; // decl: <none>; prim: <none>
    logic [31:0] limb_59_682; // decl: <none>; prim: <none>
    logic [31:0] limb_59_683; // decl: <none>; prim: <none>
    logic [32:0] limb_59_684; // decl: <none>; prim: <none>
    logic [31:0] limb_59_685; // decl: <none>; prim: <none>
    logic limb_59_686; // decl: <none>; prim: <none>
    logic [31:0] limb_59_687; // decl: <none>; prim: <none>
    logic [31:0] limb_59_688; // decl: <none>; prim: <none>
    logic [32:0] limb_59_689; // decl: <none>; prim: <none>
    logic [31:0] limb_59_690; // decl: <none>; prim: <none>
    logic limb_59_691; // decl: <none>; prim: <none>
    logic limb_59_692; // decl: <none>; prim: <none>
    logic limb_59_693; // decl: <none>; prim: <none>
    logic [1:0] limb_59_694; // decl: <none>; prim: <none>
    logic limb_59_695; // decl: <none>; prim: <none>
    logic [64:0] limb_59_696; // decl: <none>; prim: <none>
    logic [31:0] limb_60_697; // decl: <none>; prim: <none>
    logic [31:0] limb_60_698; // decl: <none>; prim: <none>
    logic [31:0] limb_60_699; // decl: <none>; prim: <none>
    logic [32:0] limb_60_700; // decl: <none>; prim: <none>
    logic [31:0] limb_60_701; // decl: <none>; prim: <none>
    logic limb_60_702; // decl: <none>; prim: <none>
    logic [31:0] limb_60_703; // decl: <none>; prim: <none>
    logic [31:0] limb_60_704; // decl: <none>; prim: <none>
    logic [31:0] limb_60_705; // decl: <none>; prim: <none>
    logic [32:0] limb_60_706; // decl: <none>; prim: <none>
    logic [31:0] limb_60_707; // decl: <none>; prim: <none>
    logic limb_60_708; // decl: <none>; prim: <none>
    logic limb_60_709; // decl: <none>; prim: <none>
    logic limb_60_710; // decl: <none>; prim: <none>
    logic limb_60_711; // decl: <none>; prim: <none>
    logic [1:0] limb_60_712; // decl: <none>; prim: <none>
    logic limb_60_713; // decl: <none>; prim: <none>
    logic [64:0] limb_60_714; // decl: <none>; prim: <none>
    logic [31:0] limb_62_715; // decl: <none>; prim: <none>
    logic [31:0] limb_62_716; // decl: <none>; prim: <none>
    logic [31:0] limb_62_717; // decl: <none>; prim: <none>
    logic [32:0] limb_62_718; // decl: <none>; prim: <none>
    logic [31:0] limb_62_719; // decl: <none>; prim: <none>
    logic limb_62_720; // decl: <none>; prim: <none>
    logic [31:0] limb_62_721; // decl: <none>; prim: <none>
    logic [31:0] limb_62_722; // decl: <none>; prim: <none>
    logic [31:0] limb_62_723; // decl: <none>; prim: <none>
    logic [32:0] limb_62_724; // decl: <none>; prim: <none>
    logic [31:0] limb_62_725; // decl: <none>; prim: <none>
    logic limb_62_726; // decl: <none>; prim: <none>
    logic limb_62_727; // decl: <none>; prim: <none>
    logic limb_62_728; // decl: <none>; prim: <none>
    logic limb_62_729; // decl: <none>; prim: <none>
    logic [1:0] limb_62_730; // decl: <none>; prim: <none>
    logic limb_62_731; // decl: <none>; prim: <none>
    logic [64:0] limb_62_732; // decl: <none>; prim: <none>
    logic [31:0] limb_72_733; // decl: <none>; prim: <none>
    logic [31:0] limb_72_734; // decl: <none>; prim: <none>
    logic [31:0] limb_72_735; // decl: <none>; prim: <none>
    logic [32:0] limb_72_736; // decl: <none>; prim: <none>
    logic [31:0] limb_72_737; // decl: <none>; prim: <none>
    logic limb_72_738; // decl: <none>; prim: <none>
    logic [31:0] limb_72_739; // decl: <none>; prim: <none>
    logic [31:0] limb_72_740; // decl: <none>; prim: <none>
    logic [31:0] limb_72_741; // decl: <none>; prim: <none>
    logic [32:0] limb_72_742; // decl: <none>; prim: <none>
    logic [31:0] limb_72_743; // decl: <none>; prim: <none>
    logic limb_72_744; // decl: <none>; prim: <none>
    logic [31:0] limb_72_745; // decl: <none>; prim: <none>
    logic [31:0] limb_72_746; // decl: <none>; prim: <none>
    logic [31:0] limb_72_747; // decl: <none>; prim: <none>
    logic [32:0] limb_72_748; // decl: <none>; prim: <none>
    logic [31:0] limb_72_749; // decl: <none>; prim: <none>
    logic limb_72_750; // decl: <none>; prim: <none>
    logic [31:0] limb_72_751; // decl: <none>; prim: <none>
    logic [31:0] limb_72_752; // decl: <none>; prim: <none>
    logic [31:0] limb_72_753; // decl: <none>; prim: <none>
    logic [32:0] limb_72_754; // decl: <none>; prim: <none>
    logic [31:0] limb_72_755; // decl: <none>; prim: <none>
    logic limb_72_756; // decl: <none>; prim: <none>
    logic limb_72_757; // decl: <none>; prim: <none>
    logic limb_72_758; // decl: <none>; prim: <none>
    logic limb_72_759; // decl: <none>; prim: <none>
    logic [1:0] limb_72_760; // decl: <none>; prim: <none>
    logic limb_72_761; // decl: <none>; prim: <none>
    logic [128:0] limb_72_762; // decl: <none>; prim: <none>
    logic [31:0] limb_74_763; // decl: <none>; prim: <none>
    logic [31:0] limb_74_764; // decl: <none>; prim: <none>
    logic [31:0] limb_74_765; // decl: <none>; prim: <none>
    logic [32:0] limb_74_766; // decl: <none>; prim: <none>
    logic [31:0] limb_74_767; // decl: <none>; prim: <none>
    logic limb_74_768; // decl: <none>; prim: <none>
    logic [31:0] limb_74_769; // decl: <none>; prim: <none>
    logic [31:0] limb_74_770; // decl: <none>; prim: <none>
    logic [31:0] limb_74_771; // decl: <none>; prim: <none>
    logic [32:0] limb_74_772; // decl: <none>; prim: <none>
    logic [31:0] limb_74_773; // decl: <none>; prim: <none>
    logic limb_74_774; // decl: <none>; prim: <none>
    logic [31:0] limb_74_775; // decl: <none>; prim: <none>
    logic [31:0] limb_74_776; // decl: <none>; prim: <none>
    logic [31:0] limb_74_777; // decl: <none>; prim: <none>
    logic [32:0] limb_74_778; // decl: <none>; prim: <none>
    logic [31:0] limb_74_779; // decl: <none>; prim: <none>
    logic limb_74_780; // decl: <none>; prim: <none>
    logic [31:0] limb_74_781; // decl: <none>; prim: <none>
    logic [31:0] limb_74_782; // decl: <none>; prim: <none>
    logic [31:0] limb_74_783; // decl: <none>; prim: <none>
    logic [32:0] limb_74_784; // decl: <none>; prim: <none>
    logic [31:0] limb_74_785; // decl: <none>; prim: <none>
    logic limb_74_786; // decl: <none>; prim: <none>
    logic limb_74_787; // decl: <none>; prim: <none>
    logic limb_74_788; // decl: <none>; prim: <none>
    logic limb_74_789; // decl: <none>; prim: <none>
    logic [1:0] limb_74_790; // decl: <none>; prim: <none>
    logic limb_74_791; // decl: <none>; prim: <none>
    logic [128:0] limb_74_792; // decl: <none>; prim: <none>
    logic [31:0] limb_78_793; // decl: <none>; prim: <none>
    logic [31:0] limb_78_794; // decl: <none>; prim: <none>
    logic [32:0] limb_78_795; // decl: <none>; prim: <none>
    logic [31:0] limb_78_796; // decl: <none>; prim: <none>
    logic limb_78_797; // decl: <none>; prim: <none>
    logic [31:0] limb_78_798; // decl: <none>; prim: <none>
    logic [31:0] limb_78_799; // decl: <none>; prim: <none>
    logic [32:0] limb_78_800; // decl: <none>; prim: <none>
    logic [31:0] limb_78_801; // decl: <none>; prim: <none>
    logic limb_78_802; // decl: <none>; prim: <none>
    logic limb_78_803; // decl: <none>; prim: <none>
    logic limb_78_804; // decl: <none>; prim: <none>
    logic [1:0] limb_78_805; // decl: <none>; prim: <none>
    logic limb_78_806; // decl: <none>; prim: <none>
    logic [64:0] limb_78_807; // decl: <none>; prim: <none>
    logic [31:0] limb_80_808; // decl: <none>; prim: <none>
    logic [31:0] limb_80_809; // decl: <none>; prim: <none>
    logic [31:0] limb_80_810; // decl: <none>; prim: <none>
    logic [32:0] limb_80_811; // decl: <none>; prim: <none>
    logic [31:0] limb_80_812; // decl: <none>; prim: <none>
    logic limb_80_813; // decl: <none>; prim: <none>
    logic [31:0] limb_80_814; // decl: <none>; prim: <none>
    logic [31:0] limb_80_815; // decl: <none>; prim: <none>
    logic [31:0] limb_80_816; // decl: <none>; prim: <none>
    logic [32:0] limb_80_817; // decl: <none>; prim: <none>
    logic [31:0] limb_80_818; // decl: <none>; prim: <none>
    logic limb_80_819; // decl: <none>; prim: <none>
    logic limb_80_820; // decl: <none>; prim: <none>
    logic limb_80_821; // decl: <none>; prim: <none>
    logic limb_80_822; // decl: <none>; prim: <none>
    logic [1:0] limb_80_823; // decl: <none>; prim: <none>
    logic limb_80_824; // decl: <none>; prim: <none>
    logic [64:0] limb_80_825; // decl: <none>; prim: <none>
    logic [31:0] limb_82_826; // decl: <none>; prim: <none>
    logic [31:0] limb_82_827; // decl: <none>; prim: <none>
    logic [32:0] limb_82_828; // decl: <none>; prim: <none>
    logic [31:0] limb_82_829; // decl: <none>; prim: <none>
    logic limb_82_830; // decl: <none>; prim: <none>
    logic [31:0] limb_82_831; // decl: <none>; prim: <none>
    logic [31:0] limb_82_832; // decl: <none>; prim: <none>
    logic [32:0] limb_82_833; // decl: <none>; prim: <none>
    logic [31:0] limb_82_834; // decl: <none>; prim: <none>
    logic limb_82_835; // decl: <none>; prim: <none>
    logic limb_82_836; // decl: <none>; prim: <none>
    logic limb_82_837; // decl: <none>; prim: <none>
    logic [1:0] limb_82_838; // decl: <none>; prim: <none>
    logic limb_82_839; // decl: <none>; prim: <none>
    logic [64:0] limb_82_840; // decl: <none>; prim: <none>
    logic [31:0] limb_83_841; // decl: <none>; prim: <none>
    logic [31:0] limb_83_842; // decl: <none>; prim: <none>
    logic [31:0] limb_83_843; // decl: <none>; prim: <none>
    logic [32:0] limb_83_844; // decl: <none>; prim: <none>
    logic [31:0] limb_83_845; // decl: <none>; prim: <none>
    logic limb_83_846; // decl: <none>; prim: <none>
    logic [31:0] limb_83_847; // decl: <none>; prim: <none>
    logic [31:0] limb_83_848; // decl: <none>; prim: <none>
    logic [31:0] limb_83_849; // decl: <none>; prim: <none>
    logic [32:0] limb_83_850; // decl: <none>; prim: <none>
    logic [31:0] limb_83_851; // decl: <none>; prim: <none>
    logic limb_83_852; // decl: <none>; prim: <none>
    logic limb_83_853; // decl: <none>; prim: <none>
    logic limb_83_854; // decl: <none>; prim: <none>
    logic limb_83_855; // decl: <none>; prim: <none>
    logic [1:0] limb_83_856; // decl: <none>; prim: <none>
    logic limb_83_857; // decl: <none>; prim: <none>
    logic [64:0] limb_83_858; // decl: <none>; prim: <none>
    logic [31:0] limb_85_859; // decl: <none>; prim: <none>
    logic [31:0] limb_85_860; // decl: <none>; prim: <none>
    logic [31:0] limb_85_861; // decl: <none>; prim: <none>
    logic [32:0] limb_85_862; // decl: <none>; prim: <none>
    logic [31:0] limb_85_863; // decl: <none>; prim: <none>
    logic limb_85_864; // decl: <none>; prim: <none>
    logic [31:0] limb_85_865; // decl: <none>; prim: <none>
    logic [31:0] limb_85_866; // decl: <none>; prim: <none>
    logic [31:0] limb_85_867; // decl: <none>; prim: <none>
    logic [32:0] limb_85_868; // decl: <none>; prim: <none>
    logic [31:0] limb_85_869; // decl: <none>; prim: <none>
    logic limb_85_870; // decl: <none>; prim: <none>
    logic limb_85_871; // decl: <none>; prim: <none>
    logic limb_85_872; // decl: <none>; prim: <none>
    logic limb_85_873; // decl: <none>; prim: <none>
    logic [1:0] limb_85_874; // decl: <none>; prim: <none>
    logic limb_85_875; // decl: <none>; prim: <none>
    logic [64:0] limb_85_876; // decl: <none>; prim: <none>
    logic [31:0] limb_89_877; // decl: <none>; prim: <none>
    logic [31:0] limb_89_878; // decl: <none>; prim: <none>
    logic [32:0] limb_89_879; // decl: <none>; prim: <none>
    logic [31:0] limb_89_880; // decl: <none>; prim: <none>
    logic limb_89_881; // decl: <none>; prim: <none>
    logic [31:0] limb_89_882; // decl: <none>; prim: <none>
    logic [31:0] limb_89_883; // decl: <none>; prim: <none>
    logic [32:0] limb_89_884; // decl: <none>; prim: <none>
    logic [31:0] limb_89_885; // decl: <none>; prim: <none>
    logic limb_89_886; // decl: <none>; prim: <none>
    logic limb_89_887; // decl: <none>; prim: <none>
    logic limb_89_888; // decl: <none>; prim: <none>
    logic [1:0] limb_89_889; // decl: <none>; prim: <none>
    logic limb_89_890; // decl: <none>; prim: <none>
    logic [64:0] limb_89_891; // decl: <none>; prim: <none>
    logic [31:0] limb_91_892; // decl: <none>; prim: <none>
    logic [31:0] limb_91_893; // decl: <none>; prim: <none>
    logic [31:0] limb_91_894; // decl: <none>; prim: <none>
    logic [32:0] limb_91_895; // decl: <none>; prim: <none>
    logic [31:0] limb_91_896; // decl: <none>; prim: <none>
    logic limb_91_897; // decl: <none>; prim: <none>
    logic [31:0] limb_91_898; // decl: <none>; prim: <none>
    logic [31:0] limb_91_899; // decl: <none>; prim: <none>
    logic [31:0] limb_91_900; // decl: <none>; prim: <none>
    logic [32:0] limb_91_901; // decl: <none>; prim: <none>
    logic [31:0] limb_91_902; // decl: <none>; prim: <none>
    logic limb_91_903; // decl: <none>; prim: <none>
    logic limb_91_904; // decl: <none>; prim: <none>
    logic limb_91_905; // decl: <none>; prim: <none>
    logic limb_91_906; // decl: <none>; prim: <none>
    logic [1:0] limb_91_907; // decl: <none>; prim: <none>
    logic limb_91_908; // decl: <none>; prim: <none>
    logic [64:0] limb_91_909; // decl: <none>; prim: <none>
    logic [31:0] limb_93_910; // decl: <none>; prim: <none>
    logic [31:0] limb_93_911; // decl: <none>; prim: <none>
    logic [32:0] limb_93_912; // decl: <none>; prim: <none>
    logic [31:0] limb_93_913; // decl: <none>; prim: <none>
    logic limb_93_914; // decl: <none>; prim: <none>
    logic [31:0] limb_93_915; // decl: <none>; prim: <none>
    logic [31:0] limb_93_916; // decl: <none>; prim: <none>
    logic [32:0] limb_93_917; // decl: <none>; prim: <none>
    logic [31:0] limb_93_918; // decl: <none>; prim: <none>
    logic limb_93_919; // decl: <none>; prim: <none>
    logic limb_93_920; // decl: <none>; prim: <none>
    logic limb_93_921; // decl: <none>; prim: <none>
    logic [1:0] limb_93_922; // decl: <none>; prim: <none>
    logic limb_93_923; // decl: <none>; prim: <none>
    logic [64:0] limb_93_924; // decl: <none>; prim: <none>
    logic [31:0] limb_94_925; // decl: <none>; prim: <none>
    logic [31:0] limb_94_926; // decl: <none>; prim: <none>
    logic [31:0] limb_94_927; // decl: <none>; prim: <none>
    logic [32:0] limb_94_928; // decl: <none>; prim: <none>
    logic [31:0] limb_94_929; // decl: <none>; prim: <none>
    logic limb_94_930; // decl: <none>; prim: <none>
    logic [31:0] limb_94_931; // decl: <none>; prim: <none>
    logic [31:0] limb_94_932; // decl: <none>; prim: <none>
    logic [31:0] limb_94_933; // decl: <none>; prim: <none>
    logic [32:0] limb_94_934; // decl: <none>; prim: <none>
    logic [31:0] limb_94_935; // decl: <none>; prim: <none>
    logic limb_94_936; // decl: <none>; prim: <none>
    logic limb_94_937; // decl: <none>; prim: <none>
    logic limb_94_938; // decl: <none>; prim: <none>
    logic limb_94_939; // decl: <none>; prim: <none>
    logic [1:0] limb_94_940; // decl: <none>; prim: <none>
    logic limb_94_941; // decl: <none>; prim: <none>
    logic [64:0] limb_94_942; // decl: <none>; prim: <none>
    logic [31:0] limb_96_943; // decl: <none>; prim: <none>
    logic [31:0] limb_96_944; // decl: <none>; prim: <none>
    logic [31:0] limb_96_945; // decl: <none>; prim: <none>
    logic [32:0] limb_96_946; // decl: <none>; prim: <none>
    logic [31:0] limb_96_947; // decl: <none>; prim: <none>
    logic limb_96_948; // decl: <none>; prim: <none>
    logic [31:0] limb_96_949; // decl: <none>; prim: <none>
    logic [31:0] limb_96_950; // decl: <none>; prim: <none>
    logic [31:0] limb_96_951; // decl: <none>; prim: <none>
    logic [32:0] limb_96_952; // decl: <none>; prim: <none>
    logic [31:0] limb_96_953; // decl: <none>; prim: <none>
    logic limb_96_954; // decl: <none>; prim: <none>
    logic limb_96_955; // decl: <none>; prim: <none>
    logic limb_96_956; // decl: <none>; prim: <none>
    logic limb_96_957; // decl: <none>; prim: <none>
    logic [1:0] limb_96_958; // decl: <none>; prim: <none>
    logic limb_96_959; // decl: <none>; prim: <none>
    logic [64:0] limb_96_960; // decl: <none>; prim: <none>
    logic [31:0] limb_106_961; // decl: <none>; prim: <none>
    logic [31:0] limb_106_962; // decl: <none>; prim: <none>
    logic [31:0] limb_106_963; // decl: <none>; prim: <none>
    logic [32:0] limb_106_964; // decl: <none>; prim: <none>
    logic [31:0] limb_106_965; // decl: <none>; prim: <none>
    logic limb_106_966; // decl: <none>; prim: <none>
    logic [31:0] limb_106_967; // decl: <none>; prim: <none>
    logic [31:0] limb_106_968; // decl: <none>; prim: <none>
    logic [31:0] limb_106_969; // decl: <none>; prim: <none>
    logic [32:0] limb_106_970; // decl: <none>; prim: <none>
    logic [31:0] limb_106_971; // decl: <none>; prim: <none>
    logic limb_106_972; // decl: <none>; prim: <none>
    logic [31:0] limb_106_973; // decl: <none>; prim: <none>
    logic [31:0] limb_106_974; // decl: <none>; prim: <none>
    logic [31:0] limb_106_975; // decl: <none>; prim: <none>
    logic [32:0] limb_106_976; // decl: <none>; prim: <none>
    logic [31:0] limb_106_977; // decl: <none>; prim: <none>
    logic limb_106_978; // decl: <none>; prim: <none>
    logic [31:0] limb_106_979; // decl: <none>; prim: <none>
    logic [31:0] limb_106_980; // decl: <none>; prim: <none>
    logic [31:0] limb_106_981; // decl: <none>; prim: <none>
    logic [32:0] limb_106_982; // decl: <none>; prim: <none>
    logic [31:0] limb_106_983; // decl: <none>; prim: <none>
    logic limb_106_984; // decl: <none>; prim: <none>
    logic limb_106_985; // decl: <none>; prim: <none>
    logic limb_106_986; // decl: <none>; prim: <none>
    logic limb_106_987; // decl: <none>; prim: <none>
    logic [1:0] limb_106_988; // decl: <none>; prim: <none>
    logic limb_106_989; // decl: <none>; prim: <none>
    logic [128:0] limb_106_990; // decl: <none>; prim: <none>
    logic [31:0] limb_108_991; // decl: <none>; prim: <none>
    logic [31:0] limb_108_992; // decl: <none>; prim: <none>
    logic [31:0] limb_108_993; // decl: <none>; prim: <none>
    logic [32:0] limb_108_994; // decl: <none>; prim: <none>
    logic [31:0] limb_108_995; // decl: <none>; prim: <none>
    logic limb_108_996; // decl: <none>; prim: <none>
    logic [31:0] limb_108_997; // decl: <none>; prim: <none>
    logic [31:0] limb_108_998; // decl: <none>; prim: <none>
    logic [31:0] limb_108_999; // decl: <none>; prim: <none>
    logic [32:0] limb_108_1000; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1001; // decl: <none>; prim: <none>
    logic limb_108_1002; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1003; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1004; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1005; // decl: <none>; prim: <none>
    logic [32:0] limb_108_1006; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1007; // decl: <none>; prim: <none>
    logic limb_108_1008; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1009; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1010; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1011; // decl: <none>; prim: <none>
    logic [32:0] limb_108_1012; // decl: <none>; prim: <none>
    logic [31:0] limb_108_1013; // decl: <none>; prim: <none>
    logic limb_108_1014; // decl: <none>; prim: <none>
    logic limb_108_1015; // decl: <none>; prim: <none>
    logic limb_108_1016; // decl: <none>; prim: <none>
    logic limb_108_1017; // decl: <none>; prim: <none>
    logic [1:0] limb_108_1018; // decl: <none>; prim: <none>
    logic limb_108_1019; // decl: <none>; prim: <none>
    logic [128:0] limb_108_1020; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1021; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1022; // decl: <none>; prim: <none>
    logic [32:0] limb_112_1023; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1024; // decl: <none>; prim: <none>
    logic limb_112_1025; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1026; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1027; // decl: <none>; prim: <none>
    logic [32:0] limb_112_1028; // decl: <none>; prim: <none>
    logic [31:0] limb_112_1029; // decl: <none>; prim: <none>
    logic limb_112_1030; // decl: <none>; prim: <none>
    logic limb_112_1031; // decl: <none>; prim: <none>
    logic limb_112_1032; // decl: <none>; prim: <none>
    logic [1:0] limb_112_1033; // decl: <none>; prim: <none>
    logic limb_112_1034; // decl: <none>; prim: <none>
    logic [64:0] limb_112_1035; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1036; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1037; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1038; // decl: <none>; prim: <none>
    logic [32:0] limb_114_1039; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1040; // decl: <none>; prim: <none>
    logic limb_114_1041; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1042; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1043; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1044; // decl: <none>; prim: <none>
    logic [32:0] limb_114_1045; // decl: <none>; prim: <none>
    logic [31:0] limb_114_1046; // decl: <none>; prim: <none>
    logic limb_114_1047; // decl: <none>; prim: <none>
    logic limb_114_1048; // decl: <none>; prim: <none>
    logic limb_114_1049; // decl: <none>; prim: <none>
    logic limb_114_1050; // decl: <none>; prim: <none>
    logic [1:0] limb_114_1051; // decl: <none>; prim: <none>
    logic limb_114_1052; // decl: <none>; prim: <none>
    logic [64:0] limb_114_1053; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1054; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1055; // decl: <none>; prim: <none>
    logic [32:0] limb_116_1056; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1057; // decl: <none>; prim: <none>
    logic limb_116_1058; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1059; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1060; // decl: <none>; prim: <none>
    logic [32:0] limb_116_1061; // decl: <none>; prim: <none>
    logic [31:0] limb_116_1062; // decl: <none>; prim: <none>
    logic limb_116_1063; // decl: <none>; prim: <none>
    logic limb_116_1064; // decl: <none>; prim: <none>
    logic limb_116_1065; // decl: <none>; prim: <none>
    logic [1:0] limb_116_1066; // decl: <none>; prim: <none>
    logic limb_116_1067; // decl: <none>; prim: <none>
    logic [64:0] limb_116_1068; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1069; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1070; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1071; // decl: <none>; prim: <none>
    logic [32:0] limb_117_1072; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1073; // decl: <none>; prim: <none>
    logic limb_117_1074; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1075; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1076; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1077; // decl: <none>; prim: <none>
    logic [32:0] limb_117_1078; // decl: <none>; prim: <none>
    logic [31:0] limb_117_1079; // decl: <none>; prim: <none>
    logic limb_117_1080; // decl: <none>; prim: <none>
    logic limb_117_1081; // decl: <none>; prim: <none>
    logic limb_117_1082; // decl: <none>; prim: <none>
    logic limb_117_1083; // decl: <none>; prim: <none>
    logic [1:0] limb_117_1084; // decl: <none>; prim: <none>
    logic limb_117_1085; // decl: <none>; prim: <none>
    logic [64:0] limb_117_1086; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1087; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1088; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1089; // decl: <none>; prim: <none>
    logic [32:0] limb_119_1090; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1091; // decl: <none>; prim: <none>
    logic limb_119_1092; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1093; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1094; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1095; // decl: <none>; prim: <none>
    logic [32:0] limb_119_1096; // decl: <none>; prim: <none>
    logic [31:0] limb_119_1097; // decl: <none>; prim: <none>
    logic limb_119_1098; // decl: <none>; prim: <none>
    logic limb_119_1099; // decl: <none>; prim: <none>
    logic limb_119_1100; // decl: <none>; prim: <none>
    logic limb_119_1101; // decl: <none>; prim: <none>
    logic [1:0] limb_119_1102; // decl: <none>; prim: <none>
    logic limb_119_1103; // decl: <none>; prim: <none>
    logic [64:0] limb_119_1104; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1105; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1106; // decl: <none>; prim: <none>
    logic [32:0] limb_123_1107; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1108; // decl: <none>; prim: <none>
    logic limb_123_1109; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1110; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1111; // decl: <none>; prim: <none>
    logic [32:0] limb_123_1112; // decl: <none>; prim: <none>
    logic [31:0] limb_123_1113; // decl: <none>; prim: <none>
    logic limb_123_1114; // decl: <none>; prim: <none>
    logic limb_123_1115; // decl: <none>; prim: <none>
    logic limb_123_1116; // decl: <none>; prim: <none>
    logic [1:0] limb_123_1117; // decl: <none>; prim: <none>
    logic limb_123_1118; // decl: <none>; prim: <none>
    logic [64:0] limb_123_1119; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1120; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1121; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1122; // decl: <none>; prim: <none>
    logic [32:0] limb_125_1123; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1124; // decl: <none>; prim: <none>
    logic limb_125_1125; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1126; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1127; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1128; // decl: <none>; prim: <none>
    logic [32:0] limb_125_1129; // decl: <none>; prim: <none>
    logic [31:0] limb_125_1130; // decl: <none>; prim: <none>
    logic limb_125_1131; // decl: <none>; prim: <none>
    logic limb_125_1132; // decl: <none>; prim: <none>
    logic limb_125_1133; // decl: <none>; prim: <none>
    logic limb_125_1134; // decl: <none>; prim: <none>
    logic [1:0] limb_125_1135; // decl: <none>; prim: <none>
    logic limb_125_1136; // decl: <none>; prim: <none>
    logic [64:0] limb_125_1137; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1138; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1139; // decl: <none>; prim: <none>
    logic [32:0] limb_127_1140; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1141; // decl: <none>; prim: <none>
    logic limb_127_1142; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1143; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1144; // decl: <none>; prim: <none>
    logic [32:0] limb_127_1145; // decl: <none>; prim: <none>
    logic [31:0] limb_127_1146; // decl: <none>; prim: <none>
    logic limb_127_1147; // decl: <none>; prim: <none>
    logic limb_127_1148; // decl: <none>; prim: <none>
    logic limb_127_1149; // decl: <none>; prim: <none>
    logic [1:0] limb_127_1150; // decl: <none>; prim: <none>
    logic limb_127_1151; // decl: <none>; prim: <none>
    logic [64:0] limb_127_1152; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1153; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1154; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1155; // decl: <none>; prim: <none>
    logic [32:0] limb_128_1156; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1157; // decl: <none>; prim: <none>
    logic limb_128_1158; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1159; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1160; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1161; // decl: <none>; prim: <none>
    logic [32:0] limb_128_1162; // decl: <none>; prim: <none>
    logic [31:0] limb_128_1163; // decl: <none>; prim: <none>
    logic limb_128_1164; // decl: <none>; prim: <none>
    logic limb_128_1165; // decl: <none>; prim: <none>
    logic limb_128_1166; // decl: <none>; prim: <none>
    logic limb_128_1167; // decl: <none>; prim: <none>
    logic [1:0] limb_128_1168; // decl: <none>; prim: <none>
    logic limb_128_1169; // decl: <none>; prim: <none>
    logic [64:0] limb_128_1170; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1171; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1172; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1173; // decl: <none>; prim: <none>
    logic [32:0] limb_130_1174; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1175; // decl: <none>; prim: <none>
    logic limb_130_1176; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1177; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1178; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1179; // decl: <none>; prim: <none>
    logic [32:0] limb_130_1180; // decl: <none>; prim: <none>
    logic [31:0] limb_130_1181; // decl: <none>; prim: <none>
    logic limb_130_1182; // decl: <none>; prim: <none>
    logic limb_130_1183; // decl: <none>; prim: <none>
    logic limb_130_1184; // decl: <none>; prim: <none>
    logic limb_130_1185; // decl: <none>; prim: <none>
    logic [1:0] limb_130_1186; // decl: <none>; prim: <none>
    logic limb_130_1187; // decl: <none>; prim: <none>
    logic [64:0] limb_130_1188; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1189; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1190; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1191; // decl: <none>; prim: <none>
    logic [32:0] limb_142_1192; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1193; // decl: <none>; prim: <none>
    logic limb_142_1194; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1195; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1196; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1197; // decl: <none>; prim: <none>
    logic [32:0] limb_142_1198; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1199; // decl: <none>; prim: <none>
    logic limb_142_1200; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1201; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1202; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1203; // decl: <none>; prim: <none>
    logic [32:0] limb_142_1204; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1205; // decl: <none>; prim: <none>
    logic limb_142_1206; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1207; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1208; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1209; // decl: <none>; prim: <none>
    logic [32:0] limb_142_1210; // decl: <none>; prim: <none>
    logic [31:0] limb_142_1211; // decl: <none>; prim: <none>
    logic limb_142_1212; // decl: <none>; prim: <none>
    logic limb_142_1213; // decl: <none>; prim: <none>
    logic limb_142_1214; // decl: <none>; prim: <none>
    logic limb_142_1215; // decl: <none>; prim: <none>
    logic [1:0] limb_142_1216; // decl: <none>; prim: <none>
    logic limb_142_1217; // decl: <none>; prim: <none>
    logic [128:0] limb_142_1218; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1219; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1220; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1221; // decl: <none>; prim: <none>
    logic [32:0] limb_144_1222; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1223; // decl: <none>; prim: <none>
    logic limb_144_1224; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1225; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1226; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1227; // decl: <none>; prim: <none>
    logic [32:0] limb_144_1228; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1229; // decl: <none>; prim: <none>
    logic limb_144_1230; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1231; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1232; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1233; // decl: <none>; prim: <none>
    logic [32:0] limb_144_1234; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1235; // decl: <none>; prim: <none>
    logic limb_144_1236; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1237; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1238; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1239; // decl: <none>; prim: <none>
    logic [32:0] limb_144_1240; // decl: <none>; prim: <none>
    logic [31:0] limb_144_1241; // decl: <none>; prim: <none>
    logic limb_144_1242; // decl: <none>; prim: <none>
    logic limb_144_1243; // decl: <none>; prim: <none>
    logic limb_144_1244; // decl: <none>; prim: <none>
    logic limb_144_1245; // decl: <none>; prim: <none>
    logic [1:0] limb_144_1246; // decl: <none>; prim: <none>
    logic limb_144_1247; // decl: <none>; prim: <none>
    logic [128:0] limb_144_1248; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1249; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1250; // decl: <none>; prim: <none>
    logic [32:0] limb_148_1251; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1252; // decl: <none>; prim: <none>
    logic limb_148_1253; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1254; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1255; // decl: <none>; prim: <none>
    logic [32:0] limb_148_1256; // decl: <none>; prim: <none>
    logic [31:0] limb_148_1257; // decl: <none>; prim: <none>
    logic limb_148_1258; // decl: <none>; prim: <none>
    logic limb_148_1259; // decl: <none>; prim: <none>
    logic limb_148_1260; // decl: <none>; prim: <none>
    logic [1:0] limb_148_1261; // decl: <none>; prim: <none>
    logic limb_148_1262; // decl: <none>; prim: <none>
    logic [64:0] limb_148_1263; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1264; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1265; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1266; // decl: <none>; prim: <none>
    logic [32:0] limb_150_1267; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1268; // decl: <none>; prim: <none>
    logic limb_150_1269; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1270; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1271; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1272; // decl: <none>; prim: <none>
    logic [32:0] limb_150_1273; // decl: <none>; prim: <none>
    logic [31:0] limb_150_1274; // decl: <none>; prim: <none>
    logic limb_150_1275; // decl: <none>; prim: <none>
    logic limb_150_1276; // decl: <none>; prim: <none>
    logic limb_150_1277; // decl: <none>; prim: <none>
    logic limb_150_1278; // decl: <none>; prim: <none>
    logic [1:0] limb_150_1279; // decl: <none>; prim: <none>
    logic limb_150_1280; // decl: <none>; prim: <none>
    logic [64:0] limb_150_1281; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1282; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1283; // decl: <none>; prim: <none>
    logic [32:0] limb_152_1284; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1285; // decl: <none>; prim: <none>
    logic limb_152_1286; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1287; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1288; // decl: <none>; prim: <none>
    logic [32:0] limb_152_1289; // decl: <none>; prim: <none>
    logic [31:0] limb_152_1290; // decl: <none>; prim: <none>
    logic limb_152_1291; // decl: <none>; prim: <none>
    logic limb_152_1292; // decl: <none>; prim: <none>
    logic limb_152_1293; // decl: <none>; prim: <none>
    logic [1:0] limb_152_1294; // decl: <none>; prim: <none>
    logic limb_152_1295; // decl: <none>; prim: <none>
    logic [64:0] limb_152_1296; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1297; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1298; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1299; // decl: <none>; prim: <none>
    logic [32:0] limb_153_1300; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1301; // decl: <none>; prim: <none>
    logic limb_153_1302; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1303; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1304; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1305; // decl: <none>; prim: <none>
    logic [32:0] limb_153_1306; // decl: <none>; prim: <none>
    logic [31:0] limb_153_1307; // decl: <none>; prim: <none>
    logic limb_153_1308; // decl: <none>; prim: <none>
    logic limb_153_1309; // decl: <none>; prim: <none>
    logic limb_153_1310; // decl: <none>; prim: <none>
    logic limb_153_1311; // decl: <none>; prim: <none>
    logic [1:0] limb_153_1312; // decl: <none>; prim: <none>
    logic limb_153_1313; // decl: <none>; prim: <none>
    logic [64:0] limb_153_1314; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1315; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1316; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1317; // decl: <none>; prim: <none>
    logic [32:0] limb_155_1318; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1319; // decl: <none>; prim: <none>
    logic limb_155_1320; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1321; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1322; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1323; // decl: <none>; prim: <none>
    logic [32:0] limb_155_1324; // decl: <none>; prim: <none>
    logic [31:0] limb_155_1325; // decl: <none>; prim: <none>
    logic limb_155_1326; // decl: <none>; prim: <none>
    logic limb_155_1327; // decl: <none>; prim: <none>
    logic limb_155_1328; // decl: <none>; prim: <none>
    logic limb_155_1329; // decl: <none>; prim: <none>
    logic [1:0] limb_155_1330; // decl: <none>; prim: <none>
    logic limb_155_1331; // decl: <none>; prim: <none>
    logic [64:0] limb_155_1332; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1333; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1334; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1335; // decl: <none>; prim: <none>
    logic [32:0] limb_167_1336; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1337; // decl: <none>; prim: <none>
    logic limb_167_1338; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1339; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1340; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1341; // decl: <none>; prim: <none>
    logic [32:0] limb_167_1342; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1343; // decl: <none>; prim: <none>
    logic limb_167_1344; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1345; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1346; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1347; // decl: <none>; prim: <none>
    logic [32:0] limb_167_1348; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1349; // decl: <none>; prim: <none>
    logic limb_167_1350; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1351; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1352; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1353; // decl: <none>; prim: <none>
    logic [32:0] limb_167_1354; // decl: <none>; prim: <none>
    logic [31:0] limb_167_1355; // decl: <none>; prim: <none>
    logic limb_167_1356; // decl: <none>; prim: <none>
    logic limb_167_1357; // decl: <none>; prim: <none>
    logic limb_167_1358; // decl: <none>; prim: <none>
    logic limb_167_1359; // decl: <none>; prim: <none>
    logic [1:0] limb_167_1360; // decl: <none>; prim: <none>
    logic limb_167_1361; // decl: <none>; prim: <none>
    logic [128:0] limb_167_1362; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1363; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1364; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1365; // decl: <none>; prim: <none>
    logic [32:0] limb_169_1366; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1367; // decl: <none>; prim: <none>
    logic limb_169_1368; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1369; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1370; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1371; // decl: <none>; prim: <none>
    logic [32:0] limb_169_1372; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1373; // decl: <none>; prim: <none>
    logic limb_169_1374; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1375; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1376; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1377; // decl: <none>; prim: <none>
    logic [32:0] limb_169_1378; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1379; // decl: <none>; prim: <none>
    logic limb_169_1380; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1381; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1382; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1383; // decl: <none>; prim: <none>
    logic [32:0] limb_169_1384; // decl: <none>; prim: <none>
    logic [31:0] limb_169_1385; // decl: <none>; prim: <none>
    logic limb_169_1386; // decl: <none>; prim: <none>
    logic limb_169_1387; // decl: <none>; prim: <none>
    logic limb_169_1388; // decl: <none>; prim: <none>
    logic limb_169_1389; // decl: <none>; prim: <none>
    logic [1:0] limb_169_1390; // decl: <none>; prim: <none>
    logic limb_169_1391; // decl: <none>; prim: <none>
    logic [128:0] limb_169_1392; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1393; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1394; // decl: <none>; prim: <none>
    logic [32:0] limb_173_1395; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1396; // decl: <none>; prim: <none>
    logic limb_173_1397; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1398; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1399; // decl: <none>; prim: <none>
    logic [32:0] limb_173_1400; // decl: <none>; prim: <none>
    logic [31:0] limb_173_1401; // decl: <none>; prim: <none>
    logic limb_173_1402; // decl: <none>; prim: <none>
    logic limb_173_1403; // decl: <none>; prim: <none>
    logic limb_173_1404; // decl: <none>; prim: <none>
    logic [1:0] limb_173_1405; // decl: <none>; prim: <none>
    logic limb_173_1406; // decl: <none>; prim: <none>
    logic [64:0] limb_173_1407; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1408; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1409; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1410; // decl: <none>; prim: <none>
    logic [32:0] limb_175_1411; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1412; // decl: <none>; prim: <none>
    logic limb_175_1413; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1414; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1415; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1416; // decl: <none>; prim: <none>
    logic [32:0] limb_175_1417; // decl: <none>; prim: <none>
    logic [31:0] limb_175_1418; // decl: <none>; prim: <none>
    logic limb_175_1419; // decl: <none>; prim: <none>
    logic limb_175_1420; // decl: <none>; prim: <none>
    logic limb_175_1421; // decl: <none>; prim: <none>
    logic limb_175_1422; // decl: <none>; prim: <none>
    logic [1:0] limb_175_1423; // decl: <none>; prim: <none>
    logic limb_175_1424; // decl: <none>; prim: <none>
    logic [64:0] limb_175_1425; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1426; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1427; // decl: <none>; prim: <none>
    logic [32:0] limb_177_1428; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1429; // decl: <none>; prim: <none>
    logic limb_177_1430; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1431; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1432; // decl: <none>; prim: <none>
    logic [32:0] limb_177_1433; // decl: <none>; prim: <none>
    logic [31:0] limb_177_1434; // decl: <none>; prim: <none>
    logic limb_177_1435; // decl: <none>; prim: <none>
    logic limb_177_1436; // decl: <none>; prim: <none>
    logic limb_177_1437; // decl: <none>; prim: <none>
    logic [1:0] limb_177_1438; // decl: <none>; prim: <none>
    logic limb_177_1439; // decl: <none>; prim: <none>
    logic [64:0] limb_177_1440; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1441; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1442; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1443; // decl: <none>; prim: <none>
    logic [32:0] limb_178_1444; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1445; // decl: <none>; prim: <none>
    logic limb_178_1446; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1447; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1448; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1449; // decl: <none>; prim: <none>
    logic [32:0] limb_178_1450; // decl: <none>; prim: <none>
    logic [31:0] limb_178_1451; // decl: <none>; prim: <none>
    logic limb_178_1452; // decl: <none>; prim: <none>
    logic limb_178_1453; // decl: <none>; prim: <none>
    logic limb_178_1454; // decl: <none>; prim: <none>
    logic limb_178_1455; // decl: <none>; prim: <none>
    logic [1:0] limb_178_1456; // decl: <none>; prim: <none>
    logic limb_178_1457; // decl: <none>; prim: <none>
    logic [64:0] limb_178_1458; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1459; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1460; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1461; // decl: <none>; prim: <none>
    logic [32:0] limb_180_1462; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1463; // decl: <none>; prim: <none>
    logic limb_180_1464; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1465; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1466; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1467; // decl: <none>; prim: <none>
    logic [32:0] limb_180_1468; // decl: <none>; prim: <none>
    logic [31:0] limb_180_1469; // decl: <none>; prim: <none>
    logic limb_180_1470; // decl: <none>; prim: <none>
    logic limb_180_1471; // decl: <none>; prim: <none>
    logic limb_180_1472; // decl: <none>; prim: <none>
    logic limb_180_1473; // decl: <none>; prim: <none>
    logic [1:0] limb_180_1474; // decl: <none>; prim: <none>
    logic limb_180_1475; // decl: <none>; prim: <none>
    logic [64:0] limb_180_1476; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1477; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1478; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1479; // decl: <none>; prim: <none>
    logic [32:0] limb_192_1480; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1481; // decl: <none>; prim: <none>
    logic limb_192_1482; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1483; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1484; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1485; // decl: <none>; prim: <none>
    logic [32:0] limb_192_1486; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1487; // decl: <none>; prim: <none>
    logic limb_192_1488; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1489; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1490; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1491; // decl: <none>; prim: <none>
    logic [32:0] limb_192_1492; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1493; // decl: <none>; prim: <none>
    logic limb_192_1494; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1495; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1496; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1497; // decl: <none>; prim: <none>
    logic [32:0] limb_192_1498; // decl: <none>; prim: <none>
    logic [31:0] limb_192_1499; // decl: <none>; prim: <none>
    logic limb_192_1500; // decl: <none>; prim: <none>
    logic limb_192_1501; // decl: <none>; prim: <none>
    logic limb_192_1502; // decl: <none>; prim: <none>
    logic limb_192_1503; // decl: <none>; prim: <none>
    logic [1:0] limb_192_1504; // decl: <none>; prim: <none>
    logic limb_192_1505; // decl: <none>; prim: <none>
    logic [128:0] limb_192_1506; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1507; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1508; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1509; // decl: <none>; prim: <none>
    logic [32:0] limb_194_1510; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1511; // decl: <none>; prim: <none>
    logic limb_194_1512; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1513; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1514; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1515; // decl: <none>; prim: <none>
    logic [32:0] limb_194_1516; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1517; // decl: <none>; prim: <none>
    logic limb_194_1518; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1519; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1520; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1521; // decl: <none>; prim: <none>
    logic [32:0] limb_194_1522; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1523; // decl: <none>; prim: <none>
    logic limb_194_1524; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1525; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1526; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1527; // decl: <none>; prim: <none>
    logic [32:0] limb_194_1528; // decl: <none>; prim: <none>
    logic [31:0] limb_194_1529; // decl: <none>; prim: <none>
    logic limb_194_1530; // decl: <none>; prim: <none>
    logic limb_194_1531; // decl: <none>; prim: <none>
    logic limb_194_1532; // decl: <none>; prim: <none>
    logic limb_194_1533; // decl: <none>; prim: <none>
    logic [1:0] limb_194_1534; // decl: <none>; prim: <none>
    logic limb_194_1535; // decl: <none>; prim: <none>
    logic [128:0] limb_194_1536; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1537; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1538; // decl: <none>; prim: <none>
    logic [32:0] limb_198_1539; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1540; // decl: <none>; prim: <none>
    logic limb_198_1541; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1542; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1543; // decl: <none>; prim: <none>
    logic [32:0] limb_198_1544; // decl: <none>; prim: <none>
    logic [31:0] limb_198_1545; // decl: <none>; prim: <none>
    logic limb_198_1546; // decl: <none>; prim: <none>
    logic limb_198_1547; // decl: <none>; prim: <none>
    logic limb_198_1548; // decl: <none>; prim: <none>
    logic [1:0] limb_198_1549; // decl: <none>; prim: <none>
    logic limb_198_1550; // decl: <none>; prim: <none>
    logic [64:0] limb_198_1551; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1552; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1553; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1554; // decl: <none>; prim: <none>
    logic [32:0] limb_200_1555; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1556; // decl: <none>; prim: <none>
    logic limb_200_1557; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1558; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1559; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1560; // decl: <none>; prim: <none>
    logic [32:0] limb_200_1561; // decl: <none>; prim: <none>
    logic [31:0] limb_200_1562; // decl: <none>; prim: <none>
    logic limb_200_1563; // decl: <none>; prim: <none>
    logic limb_200_1564; // decl: <none>; prim: <none>
    logic limb_200_1565; // decl: <none>; prim: <none>
    logic limb_200_1566; // decl: <none>; prim: <none>
    logic [1:0] limb_200_1567; // decl: <none>; prim: <none>
    logic limb_200_1568; // decl: <none>; prim: <none>
    logic [64:0] limb_200_1569; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1570; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1571; // decl: <none>; prim: <none>
    logic [32:0] limb_202_1572; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1573; // decl: <none>; prim: <none>
    logic limb_202_1574; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1575; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1576; // decl: <none>; prim: <none>
    logic [32:0] limb_202_1577; // decl: <none>; prim: <none>
    logic [31:0] limb_202_1578; // decl: <none>; prim: <none>
    logic limb_202_1579; // decl: <none>; prim: <none>
    logic limb_202_1580; // decl: <none>; prim: <none>
    logic limb_202_1581; // decl: <none>; prim: <none>
    logic [1:0] limb_202_1582; // decl: <none>; prim: <none>
    logic limb_202_1583; // decl: <none>; prim: <none>
    logic [64:0] limb_202_1584; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1585; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1586; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1587; // decl: <none>; prim: <none>
    logic [32:0] limb_203_1588; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1589; // decl: <none>; prim: <none>
    logic limb_203_1590; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1591; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1592; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1593; // decl: <none>; prim: <none>
    logic [32:0] limb_203_1594; // decl: <none>; prim: <none>
    logic [31:0] limb_203_1595; // decl: <none>; prim: <none>
    logic limb_203_1596; // decl: <none>; prim: <none>
    logic limb_203_1597; // decl: <none>; prim: <none>
    logic limb_203_1598; // decl: <none>; prim: <none>
    logic limb_203_1599; // decl: <none>; prim: <none>
    logic [1:0] limb_203_1600; // decl: <none>; prim: <none>
    logic limb_203_1601; // decl: <none>; prim: <none>
    logic [64:0] limb_203_1602; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1603; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1604; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1605; // decl: <none>; prim: <none>
    logic [32:0] limb_205_1606; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1607; // decl: <none>; prim: <none>
    logic limb_205_1608; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1609; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1610; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1611; // decl: <none>; prim: <none>
    logic [32:0] limb_205_1612; // decl: <none>; prim: <none>
    logic [31:0] limb_205_1613; // decl: <none>; prim: <none>
    logic limb_205_1614; // decl: <none>; prim: <none>
    logic limb_205_1615; // decl: <none>; prim: <none>
    logic limb_205_1616; // decl: <none>; prim: <none>
    logic limb_205_1617; // decl: <none>; prim: <none>
    logic [1:0] limb_205_1618; // decl: <none>; prim: <none>
    logic limb_205_1619; // decl: <none>; prim: <none>
    logic [64:0] limb_205_1620; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_317_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_318_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_319_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_321_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_322_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_323_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_323_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_324_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_324_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_11_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s7; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [31:0] rtlzz_pipe_328_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_332_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_332_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_333_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_334_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_338_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_339_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_13_s7; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_14_s8; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    logic [31:0] rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_346_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_349_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_349_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_350_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_351_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_354_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_355_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_356_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_361_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_361_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_362_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_363_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_365_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_365_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_366_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_367_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_367_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_367_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_368_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_371_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_372_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_373_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_373_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_373_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_373_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_400_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_400_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_401_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_402_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_403_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_405_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_406_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_22_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s7; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic rtlzz_pipe_23_s4; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s5; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s6; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s7; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [31:0] rtlzz_pipe_412_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_412_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_416_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_416_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_417_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_418_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_418_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_418_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_422_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_423_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_424_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_424_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_424_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_424_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_24_s7; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_25_s8; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    logic [31:0] rtlzz_pipe_430_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_433_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_433_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_434_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_435_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_438_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_439_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_445_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_446_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_449_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_449_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_450_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_451_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_451_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_452_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_455_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_457_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_457_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_457_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_459_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_253_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_481_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_482_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_484_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_484_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_485_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_486_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_486_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_487_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_487_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_489_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_490_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_491_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_491_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_491_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_492_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_492_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_492_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_33_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s5; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s6; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s7; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s8; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic rtlzz_pipe_34_s5; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s6; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s7; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s8; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [31:0] rtlzz_pipe_496_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_496_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_500_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_500_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_501_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_502_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_502_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_502_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_506_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_507_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_35_s8; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_36_s9; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] rtlzz_pipe_36_s10; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] rtlzz_pipe_36_s11; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [31:0] rtlzz_pipe_514_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_514_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_517_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_518_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_519_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_524_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_529_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_531_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_533_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_533_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_534_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_535_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_535_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_536_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_537_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_539_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_540_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_541_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_541_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_541_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_542_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_542_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_565_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_565_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_565_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_566_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_566_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_566_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_568_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_568_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_569_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_570_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_570_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_570_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_570_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_571_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_571_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_571_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_571_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_573_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_574_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s9; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic rtlzz_pipe_45_s7; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s8; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s9; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [31:0] rtlzz_pipe_580_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_580_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_584_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_585_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_586_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s8; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_46_s9; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [31:0] rtlzz_pipe_601_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_601_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_602_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_603_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_606_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_607_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_608_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_608_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_613_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_613_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_614_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_614_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_614_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_615_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_617_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_618_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_618_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_619_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_619_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_619_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_619_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_620_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_620_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_620_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_620_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_620_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_621_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_623_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_623_s8; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_623_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_623_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_624_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_624_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_624_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_624_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_625_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_626_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s10; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_49_s11; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [64:0] rtlzz_pipe_49_s12; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [31:0] rtlzz_pipe_631_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_637_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_643_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_51_s12; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [128:0] rtlzz_pipe_226_s13; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_226_s14; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_268_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_652_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_653_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_654_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_655_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_659_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_660_s9; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_55_s10; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic [31:0] rtlzz_pipe_668_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_669_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_670_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_676_s10; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_58_s11; // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
    logic [31:0] rtlzz_pipe_697_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_698_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_701_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_701_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_702_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_702_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_703_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_703_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_703_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_704_s9; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_704_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_704_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_709_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_709_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_709_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_711_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_711_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_711_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_60_s12; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [64:0] rtlzz_pipe_60_s13; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [64:0] rtlzz_pipe_60_s14; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [31:0] rtlzz_pipe_719_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_719_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_720_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_721_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_725_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_726_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_727_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_727_s13; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_62_s14; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [31:0] rtlzz_pipe_878_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_878_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_880_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_883_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_883_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_885_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_886_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_887_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_888_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_888_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_888_s12; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_89_s13; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [64:0] rtlzz_pipe_89_s14; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic rtlzz_pipe_90_s13; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic rtlzz_pipe_90_s14; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [31:0] rtlzz_pipe_892_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_898_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_904_s13; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_91_s14; // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [31:0] rtlzz_pipe_913_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_918_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_919_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_920_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_926_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_927_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_927_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_929_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_930_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_931_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_933_s10; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_933_s11; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_933_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_933_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_937_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_938_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_939_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_939_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_939_s13; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_94_s14; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic [31:0] rtlzz_pipe_947_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_953_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_954_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_955_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_963_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_969_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_975_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_981_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_987_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1021_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1026_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1031_s14; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_231_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1069_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1075_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1081_s14; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_117_s15; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
    logic rtlzz_pipe_118_s15; // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [31:0] rtlzz_pipe_1091_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1092_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1093_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1099_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1105_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1105_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1105_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1110_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1110_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1110_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1115_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1115_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1115_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_132_s15; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [31:0] rtlzz_pipe_1141_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1146_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1147_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1148_s12; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1153_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1153_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1153_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1154_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1159_s13; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1159_s14; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1159_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1161_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1165_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1165_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1165_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1167_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1191_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1197_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1203_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1209_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1215_s15; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_182_s15; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    logic [64:0] rtlzz_pipe_178_s15; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
    logic rtlzz_pipe_179_s15; // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [31:0] rtlzz_pipe_1463_s15; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1469_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1470_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1471_s15; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s15; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8


    assign tmp_workload_top_int_65__8_v0 = ({1'h0, x0}); // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    assign tmp_workload_top_int_65__10_v0 = ({1'h0, x4}); // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    assign s8_norm_add_6_v0 = limb_11_327; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_12Core rtlzz_owner_12(.a(65'(rtlzz_pipe_11_s3)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_8_v0));
    assign s8_norm_sub_10_v0 = limb_13_345; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_14Core rtlzz_owner_14(.a(65'(rtlzz_pipe_13_s7)), .b(65'(rtlzz_pipe_11_s7)), .cin(rtlzz_pipe_12_s7), .value(s8_norm_mux_11_v0));
    assign s8_norm_add_14_v0 = limb_15_360; // decl: <none>; prim: <none>
    assign s8_norm_sub_16_v0 = limb_16_378; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(65'(s8_norm_sub_16_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_18_v0));
    assign s8_norm_sub_20_v0 = limb_18_396; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(65'(s8_norm_sub_20_v0)), .b(65'(s8_norm_sub_16_v0)), .cin(s8_norm_cmp_18_v0), .value(s8_norm_mux_21_v0));
    assign tmp_workload_top_int_65__41_v0 = ({1'h0, x2}); // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    assign tmp_workload_top_int_65__43_v0 = ({1'h0, x6}); // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    assign s8_norm_add_26_v0 = limb_22_411; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(65'(rtlzz_pipe_22_s3)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_28_v0));
    assign s8_norm_sub_30_v0 = limb_24_429; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_25Core rtlzz_owner_25(.a(65'(rtlzz_pipe_24_s7)), .b(65'(rtlzz_pipe_22_s7)), .cin(rtlzz_pipe_23_s7), .value(s8_norm_mux_31_v0));
    assign s8_norm_add_34_v0 = limb_26_444; // decl: <none>; prim: <none>
    assign s8_norm_sub_36_v0 = limb_27_462; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(65'(s8_norm_sub_36_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_38_v0));
    assign s8_norm_sub_40_v0 = limb_29_480; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(65'(s8_norm_sub_40_v0)), .b(65'(s8_norm_sub_36_v0)), .cin(s8_norm_cmp_38_v0), .value(s8_norm_mux_41_v0));
    assign tmp_workload_top_int_65__74_v0 = ({1'h0, x1}); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    assign tmp_workload_top_int_65__76_v0 = ({1'h0, x5}); // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    assign s8_norm_add_46_v0 = limb_33_495; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(65'(rtlzz_pipe_33_s4)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_48_v0));
    assign s8_norm_sub_50_v0 = limb_35_513; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(65'(rtlzz_pipe_35_s8)), .b(65'(rtlzz_pipe_33_s8)), .cin(rtlzz_pipe_34_s8), .value(s8_norm_mux_51_v0));
    assign s8_norm_add_54_v0 = limb_37_528; // decl: <none>; prim: <none>
    assign s8_norm_sub_56_v0 = limb_38_546; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_39Core rtlzz_owner_39(.a(65'(s8_norm_sub_56_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_58_v0));
    assign s8_norm_sub_60_v0 = limb_40_564; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_41Core rtlzz_owner_41(.a(65'(s8_norm_sub_60_v0)), .b(65'(s8_norm_sub_56_v0)), .cin(s8_norm_cmp_58_v0), .value(s8_norm_mux_61_v0));
    assign tmp_workload_top_int_65__107_v0 = ({1'h0, x3}); // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    assign tmp_workload_top_int_65__109_v0 = ({1'h0, x7}); // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    assign s8_norm_add_66_v0 = limb_44_579; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(65'(rtlzz_pipe_44_s6)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_68_v0));
    assign s8_norm_sub_70_v0 = limb_46_597; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_47Core rtlzz_owner_47(.a(65'(rtlzz_pipe_46_s9)), .b(65'(rtlzz_pipe_44_s9)), .cin(rtlzz_pipe_45_s9), .value(s8_norm_mux_71_v0));
    assign s8_norm_add_74_v0 = limb_48_612; // decl: <none>; prim: <none>
    assign s8_norm_sub_76_v0 = limb_49_630; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(65'(rtlzz_pipe_49_s12)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_78_v0));
    assign s8_norm_sub_80_v0 = limb_51_648; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(65'(rtlzz_pipe_51_s12)), .b(65'(rtlzz_pipe_49_s12)), .cin(s8_norm_cmp_78_v0), .value(s8_norm_mux_81_v0));
    assign tmp_workload_top_int_65__140_v0 = (rtlzz_pipe_14_s8 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    assign tmp_workload_top_int_65__142_v0 = (rtlzz_pipe_25_s8 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    assign s8_norm_add_86_v0 = limb_55_663; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(65'(rtlzz_pipe_55_s10)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_88_v0));
    assign s8_norm_sub_90_v0 = limb_57_681; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(65'(s8_norm_sub_90_v0)), .b(65'(rtlzz_pipe_55_s10)), .cin(s8_norm_cmp_88_v0), .value(s8_norm_mux_91_v0));
    assign s8_norm_add_94_v0 = limb_59_696; // decl: <none>; prim: <none>
    assign s8_norm_sub_96_v0 = limb_60_714; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(65'(rtlzz_pipe_60_s14)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_98_v0));
    assign s8_norm_sub_100_v0 = limb_62_732; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(65'(rtlzz_pipe_62_s14)), .b(65'(rtlzz_pipe_60_s14)), .cin(s8_norm_cmp_98_v0), .value(s8_norm_mux_101_v0));
    assign tmp_workload_top_int_128__175_v0 = (__beopt_width_858 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    assign s8_norm_mul_106_v0 = ({143'h0, mul_precision_255}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__180_v0 = (__beopt_width_859 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    assign s8_norm_mul_110_v0 = ({193'h0, mul_precision_258}); // decl: <none>; prim: <none>
    assign n34_v0 = s8_norm_mul_110_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    assign s8_norm_mul_115_v0 = ({129'h0, mul_precision_261}); // decl: <none>; prim: <none>
    assign n36_v0 = s8_norm_mul_115_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    assign tmp_workload_top_int_129__191_v0 = (__beopt_width_862 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    assign s8_norm_sub_118_v0 = limb_72_762; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(129'(s8_norm_sub_118_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_120_v0));
    assign s8_norm_sub_122_v0 = limb_74_792; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_75Core rtlzz_owner_75(.a(129'(s8_norm_sub_122_v0)), .b(129'(s8_norm_sub_118_v0)), .cin(s8_norm_cmp_120_v0), .value(s8_norm_mux_123_v0[64:0]));
    assign s8_norm_mux_123_v0[128:65] = '0;
    assign tmp_workload_top_int_65__204_v0 = (s8_norm_mux_21_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    assign tmp_workload_top_int_65__206_v0 = (__beopt_width_863 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    assign s8_norm_add_127_v0 = limb_78_807; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(65'(s8_norm_add_127_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_129_v0));
    assign s8_norm_sub_131_v0 = limb_80_825; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_81Core rtlzz_owner_81(.a(65'(s8_norm_sub_131_v0)), .b(65'(s8_norm_add_127_v0)), .cin(s8_norm_cmp_129_v0), .value(s8_norm_mux_132_v0));
    assign s8_norm_add_135_v0 = limb_82_840; // decl: <none>; prim: <none>
    assign s8_norm_sub_137_v0 = limb_83_858; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(65'(s8_norm_sub_137_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_139_v0));
    assign s8_norm_sub_141_v0 = limb_85_876; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(65'(s8_norm_sub_141_v0)), .b(65'(s8_norm_sub_137_v0)), .cin(s8_norm_cmp_139_v0), .value(s8_norm_mux_142_v0));
    assign tmp_workload_top_int_65__237_v0 = (rtlzz_pipe_36_s11 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    assign tmp_workload_top_int_65__239_v0 = (s8_norm_mux_71_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    assign s8_norm_add_147_v0 = limb_89_891; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(65'(s8_norm_add_147_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_149_v0));
    assign s8_norm_sub_151_v0 = limb_91_909; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(65'(rtlzz_pipe_91_s14)), .b(65'(rtlzz_pipe_89_s14)), .cin(rtlzz_pipe_90_s14), .value(s8_norm_mux_152_v0));
    assign s8_norm_add_155_v0 = limb_93_924; // decl: <none>; prim: <none>
    assign s8_norm_sub_157_v0 = limb_94_942; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(65'(rtlzz_pipe_94_s14)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_159_v0));
    assign s8_norm_sub_161_v0 = limb_96_960; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(65'(s8_norm_sub_161_v0)), .b(65'(rtlzz_pipe_94_s14)), .cin(s8_norm_cmp_159_v0), .value(s8_norm_mux_162_v0));
    assign tmp_workload_top_int_128__272_v0 = (__beopt_width_865 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    assign s8_norm_mul_167_v0 = ({143'h0, mul_precision_264}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__277_v0 = (__beopt_width_866 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign s8_norm_mul_171_v0 = ({193'h0, mul_precision_267}); // decl: <none>; prim: <none>
    assign n54_v0 = s8_norm_mul_171_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    assign s8_norm_mul_176_v0 = ({129'h0, mul_precision_270}); // decl: <none>; prim: <none>
    assign n56_v0 = s8_norm_mul_176_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    assign tmp_workload_top_int_129__288_v0 = (rtlzz_pipe_226_s14 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign s8_norm_sub_179_v0 = limb_106_990; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_107Core rtlzz_owner_107(.a(129'(s8_norm_sub_179_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_181_v0));
    assign s8_norm_sub_183_v0 = limb_108_1020; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(129'(s8_norm_sub_183_v0)), .b(129'(s8_norm_sub_179_v0)), .cin(s8_norm_cmp_181_v0), .value(s8_norm_mux_184_v0[64:0]));
    assign s8_norm_mux_184_v0[128:65] = '0;
    assign tmp_workload_top_int_65__301_v0 = (s8_norm_mux_61_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    assign tmp_workload_top_int_65__303_v0 = (__beopt_width_870 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    assign s8_norm_add_188_v0 = limb_112_1035; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_113Core rtlzz_owner_113(.a(65'(s8_norm_add_188_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_190_v0));
    assign s8_norm_sub_192_v0 = limb_114_1053; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115Core rtlzz_owner_115(.a(65'(s8_norm_sub_192_v0)), .b(65'(s8_norm_add_188_v0)), .cin(s8_norm_cmp_190_v0), .value(s8_norm_mux_193_v0));
    assign s8_norm_add_196_v0 = limb_116_1068; // decl: <none>; prim: <none>
    assign s8_norm_sub_198_v0 = limb_117_1086; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(65'(s8_norm_sub_198_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_200_v0));
    assign s8_norm_sub_202_v0 = limb_119_1104; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(65'(s8_norm_sub_202_v0)), .b(65'(rtlzz_pipe_117_s15)), .cin(rtlzz_pipe_118_s15), .value(s8_norm_mux_203_v0));
    assign tmp_workload_top_int_65__334_v0 = (rtlzz_pipe_58_s11 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    assign tmp_workload_top_int_65__336_v0 = (s8_norm_mux_152_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    assign s8_norm_add_208_v0 = limb_123_1119; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(65'(s8_norm_add_208_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_210_v0));
    assign s8_norm_sub_212_v0 = limb_125_1137; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(65'(s8_norm_sub_212_v0)), .b(65'(s8_norm_add_208_v0)), .cin(s8_norm_cmp_210_v0), .value(s8_norm_mux_213_v0[63:0]));
    assign s8_norm_mux_213_v0[64:64] = '0;
    assign s8_norm_add_216_v0 = limb_127_1152; // decl: <none>; prim: <none>
    assign s8_norm_sub_218_v0 = limb_128_1170; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(65'(s8_norm_sub_218_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_220_v0));
    assign s8_norm_sub_222_v0 = limb_130_1188; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(65'(s8_norm_sub_222_v0)), .b(65'(s8_norm_sub_218_v0)), .cin(s8_norm_cmp_220_v0), .value(s8_norm_mux_223_v0[63:0]));
    assign s8_norm_mux_223_v0[64:64] = '0;
    assign tmp_workload_top_int_64__363_v0 = s8_norm_mux_213_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    assign tmp_workload_top_int_64__365_v0 = s8_norm_mux_223_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    assign tmp_workload_top_int_128__369_v0 = (__beopt_width_872 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    assign s8_norm_mul_228_v0 = ({128'h0, mul_precision_273}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__374_v0 = (__beopt_width_873 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    assign s8_norm_mul_232_v0 = ({193'h0, mul_precision_276}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_232_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    assign s8_norm_mul_237_v0 = ({129'h0, mul_precision_279}); // decl: <none>; prim: <none>
    assign n76_v0 = s8_norm_mul_237_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    assign tmp_workload_top_int_129__385_v0 = (rtlzz_pipe_231_s15 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    assign s8_norm_sub_240_v0 = limb_142_1218; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(129'(s8_norm_sub_240_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_242_v0));
    assign s8_norm_sub_244_v0 = limb_144_1248; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_145Core rtlzz_owner_145(.a(129'(s8_norm_sub_244_v0)), .b(129'(s8_norm_sub_240_v0)), .cin(s8_norm_cmp_242_v0), .value(s8_norm_mux_245_v0[64:0]));
    assign s8_norm_mux_245_v0[128:65] = '0;
    assign tmp_workload_top_int_65__398_v0 = (s8_norm_mux_132_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    assign tmp_workload_top_int_65__400_v0 = (__beopt_width_877 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    assign s8_norm_add_249_v0 = limb_148_1263; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_149Core rtlzz_owner_149(.a(65'(s8_norm_add_249_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_251_v0));
    assign s8_norm_sub_253_v0 = limb_150_1281; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(65'(s8_norm_sub_253_v0)), .b(65'(s8_norm_add_249_v0)), .cin(s8_norm_cmp_251_v0), .value(s8_norm_mux_254_v0[63:0]));
    assign s8_norm_mux_254_v0[64:64] = '0;
    assign s8_norm_add_257_v0 = limb_152_1296; // decl: <none>; prim: <none>
    assign s8_norm_sub_259_v0 = limb_153_1314; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(65'(s8_norm_sub_259_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_261_v0));
    assign s8_norm_sub_263_v0 = limb_155_1332; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(65'(s8_norm_sub_263_v0)), .b(65'(s8_norm_sub_259_v0)), .cin(s8_norm_cmp_261_v0), .value(s8_norm_mux_264_v0[63:0]));
    assign s8_norm_mux_264_v0[64:64] = '0;
    assign tmp_workload_top_int_64__427_v0 = s8_norm_mux_254_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    assign tmp_workload_top_int_64__429_v0 = s8_norm_mux_264_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    assign tmp_workload_top_int_128__433_v0 = (__beopt_width_879 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    assign s8_norm_mul_269_v0 = ({143'h0, mul_precision_282}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__438_v0 = (__beopt_width_880 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    assign s8_norm_mul_273_v0 = ({193'h0, mul_precision_285}); // decl: <none>; prim: <none>
    assign n88_v0 = s8_norm_mul_273_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    assign s8_norm_mul_278_v0 = ({129'h0, mul_precision_288}); // decl: <none>; prim: <none>
    assign n90_v0 = s8_norm_mul_278_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    assign tmp_workload_top_int_129__449_v0 = (__beopt_width_883 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    assign s8_norm_sub_281_v0 = limb_167_1362; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(129'(s8_norm_sub_281_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_283_v0));
    assign s8_norm_sub_285_v0 = limb_169_1392; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(129'(s8_norm_sub_285_v0)), .b(129'(s8_norm_sub_281_v0)), .cin(s8_norm_cmp_283_v0), .value(s8_norm_mux_286_v0[64:0]));
    assign s8_norm_mux_286_v0[128:65] = '0;
    assign tmp_workload_top_int_65__462_v0 = (s8_norm_mux_101_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    assign tmp_workload_top_int_65__464_v0 = (__beopt_width_884 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    assign s8_norm_add_290_v0 = limb_173_1407; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(65'(s8_norm_add_290_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_292_v0));
    assign s8_norm_sub_294_v0 = limb_175_1425; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(65'(s8_norm_sub_294_v0)), .b(65'(s8_norm_add_290_v0)), .cin(s8_norm_cmp_292_v0), .value(s8_norm_mux_295_v0[63:0]));
    assign s8_norm_mux_295_v0[64:64] = '0;
    assign s8_norm_add_298_v0 = limb_177_1440; // decl: <none>; prim: <none>
    assign s8_norm_sub_300_v0 = limb_178_1458; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_179Core rtlzz_owner_179(.a(65'(s8_norm_sub_300_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_302_v0));
    assign s8_norm_sub_304_v0 = limb_180_1476; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_181Core rtlzz_owner_181(.a(65'(s8_norm_sub_304_v0)), .b(65'(rtlzz_pipe_178_s15)), .cin(rtlzz_pipe_179_s15), .value(s8_norm_mux_305_v0[63:0]));
    assign s8_norm_mux_305_v0[64:64] = '0;
    assign tmp_workload_top_int_64__491_v0 = s8_norm_mux_295_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    assign tmp_workload_top_int_64__493_v0 = s8_norm_mux_305_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    assign tmp_workload_top_int_128__497_v0 = (__beopt_width_886 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    assign s8_norm_mul_310_v0 = ({128'h0, mul_precision_291}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__502_v0 = (__beopt_width_887 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    assign s8_norm_mul_314_v0 = ({193'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign n102_v0 = s8_norm_mul_314_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    assign s8_norm_mul_319_v0 = ({129'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign n104_v0 = s8_norm_mul_319_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    assign tmp_workload_top_int_129__513_v0 = (__beopt_width_890 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    assign s8_norm_sub_322_v0 = limb_192_1506; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_193Core rtlzz_owner_193(.a(129'(s8_norm_sub_322_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_324_v0));
    assign s8_norm_sub_326_v0 = limb_194_1536; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_195Core rtlzz_owner_195(.a(129'(s8_norm_sub_326_v0)), .b(129'(s8_norm_sub_322_v0)), .cin(s8_norm_cmp_324_v0), .value(s8_norm_mux_327_v0[64:0]));
    assign s8_norm_mux_327_v0[128:65] = '0;
    assign tmp_workload_top_int_65__526_v0 = (s8_norm_mux_142_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    assign tmp_workload_top_int_65__528_v0 = (__beopt_width_891 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    assign s8_norm_add_331_v0 = limb_198_1551; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_199Core rtlzz_owner_199(.a(65'(s8_norm_add_331_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_333_v0));
    assign s8_norm_sub_335_v0 = limb_200_1569; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(65'(s8_norm_sub_335_v0)), .b(65'(s8_norm_add_331_v0)), .cin(s8_norm_cmp_333_v0), .value(s8_norm_mux_336_v0[63:0]));
    assign s8_norm_mux_336_v0[64:64] = '0;
    assign s8_norm_add_339_v0 = limb_202_1584; // decl: <none>; prim: <none>
    assign s8_norm_sub_341_v0 = limb_203_1602; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(65'(s8_norm_sub_341_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_343_v0));
    assign s8_norm_sub_345_v0 = limb_205_1620; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(65'(s8_norm_sub_345_v0)), .b(65'(s8_norm_sub_341_v0)), .cin(s8_norm_cmp_343_v0), .value(s8_norm_mux_346_v0[63:0]));
    assign s8_norm_mux_346_v0[64:64] = '0;
    assign tmp_workload_top_int_64__555_v0 = s8_norm_mux_336_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    assign tmp_workload_top_int_64__557_v0 = s8_norm_mux_346_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    assign y0 = rtlzz_pipe_132_s15; // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    assign y1 = tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    assign y2 = rtlzz_pipe_182_s15; // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    assign y3 = tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    assign y4 = tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    assign y5 = tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    assign y6 = tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    assign y7 = tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    assign ov = rtlzz_valid_s15; // decl: <none>; prim: <none>
    assign __beopt_width_858 = ({63'h0, s8_norm_mux_41_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_859 = s8_norm_mul_106_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_860 = n34_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_862 = s8_norm_mul_106_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_863 = s8_norm_mux_123_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_865 = ({63'h0, s8_norm_mux_81_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_866 = s8_norm_mul_167_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_867 = n54_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_869 = s8_norm_mul_167_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_870 = s8_norm_mux_184_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_872 = ({63'h0, s8_norm_mux_193_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_873 = s8_norm_mul_228_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_874 = n74_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_876 = s8_norm_mul_228_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_877 = s8_norm_mux_245_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_879 = ({63'h0, s8_norm_mux_162_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_880 = s8_norm_mul_269_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_881 = n88_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_883 = s8_norm_mul_269_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_884 = s8_norm_mux_286_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_886 = ({63'h0, s8_norm_mux_203_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_887 = s8_norm_mul_310_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_888 = n102_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_890 = s8_norm_mul_310_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_891 = s8_norm_mux_327_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_255 = (__beopt_width_256 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    assign __beopt_width_259 = (__beopt_width_260 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    assign __beopt_width_263 = (__beopt_width_264 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    assign __beopt_width_268 = (__beopt_width_267 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    assign __beopt_width_272 = (__beopt_width_271 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    assign __beopt_width_256 = ({64'h0, __beopt_width_860}); // decl: <none>; prim: <none>
    assign __beopt_width_260 = ({64'h0, __beopt_width_867}); // decl: <none>; prim: <none>
    assign __beopt_width_264 = ({64'h0, __beopt_width_874}); // decl: <none>; prim: <none>
    assign __beopt_width_267 = ({64'h0, __beopt_width_881}); // decl: <none>; prim: <none>
    assign __beopt_width_271 = ({64'h0, __beopt_width_888}); // decl: <none>; prim: <none>
    assign mul_precision_253 = tmp_workload_top_int_128__175_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_254 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_255 = arith_original_298; // decl: <none>; prim: <none>
    assign mul_precision_256 = tmp_workload_top_int_193__180_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_257 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_258 = arith_original_299; // decl: <none>; prim: <none>
    assign mul_precision_259 = __beopt_width_255[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_260 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_261 = arith_original_300; // decl: <none>; prim: <none>
    assign mul_precision_262 = tmp_workload_top_int_128__272_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_263 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_264 = arith_original_301; // decl: <none>; prim: <none>
    assign mul_precision_265 = tmp_workload_top_int_193__277_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_266 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_267 = arith_original_302; // decl: <none>; prim: <none>
    assign mul_precision_268 = __beopt_width_259[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_269 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_270 = arith_original_303; // decl: <none>; prim: <none>
    assign mul_precision_271 = tmp_workload_top_int_128__369_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_272 = 64'((128'hfffffffeff000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_273 = arith_original_304; // decl: <none>; prim: <none>
    assign mul_precision_274 = tmp_workload_top_int_193__374_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_275 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_276 = arith_original_305; // decl: <none>; prim: <none>
    assign mul_precision_277 = __beopt_width_263[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_278 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_279 = arith_original_306; // decl: <none>; prim: <none>
    assign mul_precision_280 = tmp_workload_top_int_128__433_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_281 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_282 = arith_original_307; // decl: <none>; prim: <none>
    assign mul_precision_283 = tmp_workload_top_int_193__438_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_284 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_285 = arith_original_308; // decl: <none>; prim: <none>
    assign mul_precision_286 = __beopt_width_268[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_287 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_288 = arith_original_309; // decl: <none>; prim: <none>
    assign mul_precision_289 = tmp_workload_top_int_128__497_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_290 = 64'((128'hfffffeff00000101) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_291 = arith_original_310; // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_193__502_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_311; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_272[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_312; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(64'(rtlzz_pipe_253_s15)), .b(49'(mul_precision_254)), .cin(1'b0), .value(arith_original_298));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_299Core rtlzz_owner_299(.a(128'(mul_precision_256)), .b(65'(mul_precision_257)), .cin(1'b0), .value(arith_original_299));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_300Core rtlzz_owner_300(.a(65'(mul_precision_259)), .b(64'(mul_precision_260)), .cin(1'b0), .value(arith_original_300));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(64'(mul_precision_262)), .b(49'(mul_precision_263)), .cin(1'b0), .value(arith_original_301));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_302Core rtlzz_owner_302(.a(128'(mul_precision_265)), .b(65'(mul_precision_266)), .cin(1'b0), .value(arith_original_302));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_303Core rtlzz_owner_303(.a(65'(rtlzz_pipe_268_s13)), .b(64'(mul_precision_269)), .cin(1'b0), .value(arith_original_303));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_304Core rtlzz_owner_304(.a(64'(mul_precision_271)), .b(64'(mul_precision_272)), .cin(1'b0), .value(arith_original_304));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_305Core rtlzz_owner_305(.a(128'(mul_precision_274)), .b(65'(mul_precision_275)), .cin(1'b0), .value(arith_original_305));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_306Core rtlzz_owner_306(.a(65'(mul_precision_277)), .b(64'(mul_precision_278)), .cin(1'b0), .value(arith_original_306));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_307Core rtlzz_owner_307(.a(64'(mul_precision_280)), .b(49'(mul_precision_281)), .cin(1'b0), .value(arith_original_307));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_308Core rtlzz_owner_308(.a(128'(mul_precision_283)), .b(65'(mul_precision_284)), .cin(1'b0), .value(arith_original_308));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(65'(mul_precision_286)), .b(64'(mul_precision_287)), .cin(1'b0), .value(arith_original_309));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_310Core rtlzz_owner_310(.a(64'(mul_precision_289)), .b(64'(mul_precision_290)), .cin(1'b0), .value(arith_original_310));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_311Core rtlzz_owner_311(.a(128'(mul_precision_292)), .b(65'(mul_precision_293)), .cin(1'b0), .value(arith_original_311));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_312Core rtlzz_owner_312(.a(65'(mul_precision_295)), .b(64'(mul_precision_296)), .cin(1'b0), .value(arith_original_312));
    assign limb_11_313 = tmp_workload_top_int_65__8_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_11_314 = tmp_workload_top_int_65__10_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_315Core rtlzz_owner_315(.a(32'(limb_11_313)), .b(32'(limb_11_314)), .cin(1'h0), .value(limb_11_315));
    assign limb_11_316 = limb_11_315[31:0]; // decl: <none>; prim: <none>
    assign limb_11_317 = limb_11_315[32]; // decl: <none>; prim: <none>
    assign limb_11_318 = tmp_workload_top_int_65__8_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_11_319 = tmp_workload_top_int_65__10_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_320Core rtlzz_owner_320(.a(32'(rtlzz_pipe_318_s1)), .b(32'(rtlzz_pipe_319_s1)), .cin(rtlzz_pipe_317_s1), .value(limb_11_320));
    assign limb_11_321 = limb_11_320[31:0]; // decl: <none>; prim: <none>
    assign limb_11_322 = limb_11_320[32]; // decl: <none>; prim: <none>
    assign limb_11_323 = tmp_workload_top_int_65__8_v0[64]; // decl: <none>; prim: <none>
    assign limb_11_324 = tmp_workload_top_int_65__10_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_325Core rtlzz_owner_325(.a(1'(rtlzz_pipe_323_s2)), .b(1'(rtlzz_pipe_324_s2)), .cin(rtlzz_pipe_322_s2), .value(limb_11_325[0:0]));
    assign limb_11_325[1:1] = '0;
    assign limb_11_326 = limb_11_325[0]; // decl: <none>; prim: <none>
    assign limb_11_327 = {limb_11_326, rtlzz_pipe_321_s2, rtlzz_pipe_316_s2}; // decl: <none>; prim: <none>
    assign limb_13_328 = s8_norm_add_6_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_13_329 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_13_330 = (~limb_13_329); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_331Core rtlzz_owner_331(.a(32'(rtlzz_pipe_328_s4)), .b(32'(limb_13_330)), .cin(1'h1), .value(limb_13_331));
    assign limb_13_332 = limb_13_331[31:0]; // decl: <none>; prim: <none>
    assign limb_13_333 = limb_13_331[32]; // decl: <none>; prim: <none>
    assign limb_13_334 = s8_norm_add_6_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_13_335 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_13_336 = (~limb_13_335); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(32'(rtlzz_pipe_334_s5)), .b(32'(limb_13_336)), .cin(rtlzz_pipe_333_s5), .value(limb_13_337));
    assign limb_13_338 = limb_13_337[31:0]; // decl: <none>; prim: <none>
    assign limb_13_339 = limb_13_337[32]; // decl: <none>; prim: <none>
    assign limb_13_340 = s8_norm_add_6_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_341 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_13_342 = (~limb_13_341); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(1'(rtlzz_pipe_340_s6)), .b(1'(limb_13_342)), .cin(rtlzz_pipe_339_s6), .value(limb_13_343[0:0]));
    assign limb_13_343[1:1] = '0;
    assign limb_13_344 = limb_13_343[0]; // decl: <none>; prim: <none>
    assign limb_13_345 = {limb_13_344, rtlzz_pipe_338_s6, rtlzz_pipe_332_s6}; // decl: <none>; prim: <none>
    assign limb_15_346 = tmp_workload_top_int_65__8_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_15_347 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(32'(rtlzz_pipe_346_s9)), .b(32'(limb_15_347)), .cin(1'h0), .value(limb_15_348));
    assign limb_15_349 = limb_15_348[31:0]; // decl: <none>; prim: <none>
    assign limb_15_350 = limb_15_348[32]; // decl: <none>; prim: <none>
    assign limb_15_351 = tmp_workload_top_int_65__8_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_15_352 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_353Core rtlzz_owner_353(.a(32'(rtlzz_pipe_351_s10)), .b(32'(limb_15_352)), .cin(rtlzz_pipe_350_s10), .value(limb_15_353));
    assign limb_15_354 = limb_15_353[31:0]; // decl: <none>; prim: <none>
    assign limb_15_355 = limb_15_353[32]; // decl: <none>; prim: <none>
    assign limb_15_356 = tmp_workload_top_int_65__8_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_357 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(1'(rtlzz_pipe_356_s11)), .b(1'(limb_15_357)), .cin(rtlzz_pipe_355_s11), .value(limb_15_358[0:0]));
    assign limb_15_358[1:1] = '0;
    assign limb_15_359 = limb_15_358[0]; // decl: <none>; prim: <none>
    assign limb_15_360 = {limb_15_359, rtlzz_pipe_354_s11, rtlzz_pipe_349_s11}; // decl: <none>; prim: <none>
    assign limb_16_361 = s8_norm_add_14_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_16_362 = tmp_workload_top_int_65__10_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_16_363 = (~rtlzz_pipe_362_s12); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364Core rtlzz_owner_364(.a(32'(rtlzz_pipe_361_s13)), .b(32'(rtlzz_pipe_363_s13)), .cin(1'h1), .value(limb_16_364));
    assign limb_16_365 = limb_16_364[31:0]; // decl: <none>; prim: <none>
    assign limb_16_366 = limb_16_364[32]; // decl: <none>; prim: <none>
    assign limb_16_367 = s8_norm_add_14_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_16_368 = tmp_workload_top_int_65__10_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_16_369 = (~rtlzz_pipe_368_s14); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370Core rtlzz_owner_370(.a(32'(rtlzz_pipe_367_s14)), .b(32'(limb_16_369)), .cin(rtlzz_pipe_366_s14), .value(limb_16_370));
    assign limb_16_371 = limb_16_370[31:0]; // decl: <none>; prim: <none>
    assign limb_16_372 = limb_16_370[32]; // decl: <none>; prim: <none>
    assign limb_16_373 = s8_norm_add_14_v0[64]; // decl: <none>; prim: <none>
    assign limb_16_374 = tmp_workload_top_int_65__10_v0[64]; // decl: <none>; prim: <none>
    assign limb_16_375 = (~rtlzz_pipe_374_s15); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(1'(rtlzz_pipe_373_s15)), .b(1'(limb_16_375)), .cin(rtlzz_pipe_372_s15), .value(limb_16_376[0:0]));
    assign limb_16_376[1:1] = '0;
    assign limb_16_377 = limb_16_376[0]; // decl: <none>; prim: <none>
    assign limb_16_378 = {limb_16_377, rtlzz_pipe_371_s15, rtlzz_pipe_365_s15}; // decl: <none>; prim: <none>
    assign limb_18_379 = s8_norm_sub_16_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_18_380 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_18_381 = (~limb_18_380); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382Core rtlzz_owner_382(.a(32'(limb_18_379)), .b(32'(limb_18_381)), .cin(1'h1), .value(limb_18_382));
    assign limb_18_383 = limb_18_382[31:0]; // decl: <none>; prim: <none>
    assign limb_18_384 = limb_18_382[32]; // decl: <none>; prim: <none>
    assign limb_18_385 = s8_norm_sub_16_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_18_386 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_18_387 = (~limb_18_386); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(32'(limb_18_385)), .b(32'(limb_18_387)), .cin(limb_18_384), .value(limb_18_388));
    assign limb_18_389 = limb_18_388[31:0]; // decl: <none>; prim: <none>
    assign limb_18_390 = limb_18_388[32]; // decl: <none>; prim: <none>
    assign limb_18_391 = s8_norm_sub_16_v0[64]; // decl: <none>; prim: <none>
    assign limb_18_392 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_18_393 = (~limb_18_392); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(1'(limb_18_391)), .b(1'(limb_18_393)), .cin(limb_18_390), .value(limb_18_394[0:0]));
    assign limb_18_394[1:1] = '0;
    assign limb_18_395 = limb_18_394[0]; // decl: <none>; prim: <none>
    assign limb_18_396 = {limb_18_395, limb_18_389, limb_18_383}; // decl: <none>; prim: <none>
    assign limb_22_397 = tmp_workload_top_int_65__41_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_22_398 = tmp_workload_top_int_65__43_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_399Core rtlzz_owner_399(.a(32'(limb_22_397)), .b(32'(limb_22_398)), .cin(1'h0), .value(limb_22_399));
    assign limb_22_400 = limb_22_399[31:0]; // decl: <none>; prim: <none>
    assign limb_22_401 = limb_22_399[32]; // decl: <none>; prim: <none>
    assign limb_22_402 = tmp_workload_top_int_65__41_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_22_403 = tmp_workload_top_int_65__43_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_404Core rtlzz_owner_404(.a(32'(rtlzz_pipe_402_s1)), .b(32'(rtlzz_pipe_403_s1)), .cin(rtlzz_pipe_401_s1), .value(limb_22_404));
    assign limb_22_405 = limb_22_404[31:0]; // decl: <none>; prim: <none>
    assign limb_22_406 = limb_22_404[32]; // decl: <none>; prim: <none>
    assign limb_22_407 = tmp_workload_top_int_65__41_v0[64]; // decl: <none>; prim: <none>
    assign limb_22_408 = tmp_workload_top_int_65__43_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(1'(rtlzz_pipe_407_s2)), .b(1'(rtlzz_pipe_408_s2)), .cin(rtlzz_pipe_406_s2), .value(limb_22_409[0:0]));
    assign limb_22_409[1:1] = '0;
    assign limb_22_410 = limb_22_409[0]; // decl: <none>; prim: <none>
    assign limb_22_411 = {limb_22_410, rtlzz_pipe_405_s2, rtlzz_pipe_400_s2}; // decl: <none>; prim: <none>
    assign limb_24_412 = s8_norm_add_26_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_24_413 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_24_414 = (~limb_24_413); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(32'(rtlzz_pipe_412_s4)), .b(32'(limb_24_414)), .cin(1'h1), .value(limb_24_415));
    assign limb_24_416 = limb_24_415[31:0]; // decl: <none>; prim: <none>
    assign limb_24_417 = limb_24_415[32]; // decl: <none>; prim: <none>
    assign limb_24_418 = s8_norm_add_26_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_24_419 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_24_420 = (~limb_24_419); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_421Core rtlzz_owner_421(.a(32'(rtlzz_pipe_418_s5)), .b(32'(limb_24_420)), .cin(rtlzz_pipe_417_s5), .value(limb_24_421));
    assign limb_24_422 = limb_24_421[31:0]; // decl: <none>; prim: <none>
    assign limb_24_423 = limb_24_421[32]; // decl: <none>; prim: <none>
    assign limb_24_424 = s8_norm_add_26_v0[64]; // decl: <none>; prim: <none>
    assign limb_24_425 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_24_426 = (~limb_24_425); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427Core rtlzz_owner_427(.a(1'(rtlzz_pipe_424_s6)), .b(1'(limb_24_426)), .cin(rtlzz_pipe_423_s6), .value(limb_24_427[0:0]));
    assign limb_24_427[1:1] = '0;
    assign limb_24_428 = limb_24_427[0]; // decl: <none>; prim: <none>
    assign limb_24_429 = {limb_24_428, rtlzz_pipe_422_s6, rtlzz_pipe_416_s6}; // decl: <none>; prim: <none>
    assign limb_26_430 = tmp_workload_top_int_65__41_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_26_431 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_432Core rtlzz_owner_432(.a(32'(rtlzz_pipe_430_s9)), .b(32'(limb_26_431)), .cin(1'h0), .value(limb_26_432));
    assign limb_26_433 = limb_26_432[31:0]; // decl: <none>; prim: <none>
    assign limb_26_434 = limb_26_432[32]; // decl: <none>; prim: <none>
    assign limb_26_435 = tmp_workload_top_int_65__41_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_26_436 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_437Core rtlzz_owner_437(.a(32'(rtlzz_pipe_435_s10)), .b(32'(limb_26_436)), .cin(rtlzz_pipe_434_s10), .value(limb_26_437));
    assign limb_26_438 = limb_26_437[31:0]; // decl: <none>; prim: <none>
    assign limb_26_439 = limb_26_437[32]; // decl: <none>; prim: <none>
    assign limb_26_440 = tmp_workload_top_int_65__41_v0[64]; // decl: <none>; prim: <none>
    assign limb_26_441 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_442Core rtlzz_owner_442(.a(1'(rtlzz_pipe_440_s11)), .b(1'(limb_26_441)), .cin(rtlzz_pipe_439_s11), .value(limb_26_442[0:0]));
    assign limb_26_442[1:1] = '0;
    assign limb_26_443 = limb_26_442[0]; // decl: <none>; prim: <none>
    assign limb_26_444 = {limb_26_443, rtlzz_pipe_438_s11, rtlzz_pipe_433_s11}; // decl: <none>; prim: <none>
    assign limb_27_445 = s8_norm_add_34_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_27_446 = tmp_workload_top_int_65__43_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_27_447 = (~rtlzz_pipe_446_s12); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_448Core rtlzz_owner_448(.a(32'(rtlzz_pipe_445_s12)), .b(32'(limb_27_447)), .cin(1'h1), .value(limb_27_448));
    assign limb_27_449 = limb_27_448[31:0]; // decl: <none>; prim: <none>
    assign limb_27_450 = limb_27_448[32]; // decl: <none>; prim: <none>
    assign limb_27_451 = s8_norm_add_34_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_27_452 = tmp_workload_top_int_65__43_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_27_453 = (~rtlzz_pipe_452_s13); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454Core rtlzz_owner_454(.a(32'(rtlzz_pipe_451_s13)), .b(32'(limb_27_453)), .cin(rtlzz_pipe_450_s13), .value(limb_27_454));
    assign limb_27_455 = limb_27_454[31:0]; // decl: <none>; prim: <none>
    assign limb_27_456 = limb_27_454[32]; // decl: <none>; prim: <none>
    assign limb_27_457 = s8_norm_add_34_v0[64]; // decl: <none>; prim: <none>
    assign limb_27_458 = tmp_workload_top_int_65__43_v0[64]; // decl: <none>; prim: <none>
    assign limb_27_459 = (~limb_27_458); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_460Core rtlzz_owner_460(.a(1'(rtlzz_pipe_457_s14)), .b(1'(rtlzz_pipe_459_s14)), .cin(rtlzz_pipe_456_s14), .value(limb_27_460[0:0]));
    assign limb_27_460[1:1] = '0;
    assign limb_27_461 = limb_27_460[0]; // decl: <none>; prim: <none>
    assign limb_27_462 = {limb_27_461, rtlzz_pipe_455_s14, rtlzz_pipe_449_s14}; // decl: <none>; prim: <none>
    assign limb_29_463 = s8_norm_sub_36_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_29_464 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_29_465 = (~limb_29_464); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_466Core rtlzz_owner_466(.a(32'(limb_29_463)), .b(32'(limb_29_465)), .cin(1'h1), .value(limb_29_466));
    assign limb_29_467 = limb_29_466[31:0]; // decl: <none>; prim: <none>
    assign limb_29_468 = limb_29_466[32]; // decl: <none>; prim: <none>
    assign limb_29_469 = s8_norm_sub_36_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_29_470 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_29_471 = (~limb_29_470); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_472Core rtlzz_owner_472(.a(32'(limb_29_469)), .b(32'(limb_29_471)), .cin(limb_29_468), .value(limb_29_472));
    assign limb_29_473 = limb_29_472[31:0]; // decl: <none>; prim: <none>
    assign limb_29_474 = limb_29_472[32]; // decl: <none>; prim: <none>
    assign limb_29_475 = s8_norm_sub_36_v0[64]; // decl: <none>; prim: <none>
    assign limb_29_476 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_29_477 = (~limb_29_476); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_478Core rtlzz_owner_478(.a(1'(limb_29_475)), .b(1'(limb_29_477)), .cin(limb_29_474), .value(limb_29_478[0:0]));
    assign limb_29_478[1:1] = '0;
    assign limb_29_479 = limb_29_478[0]; // decl: <none>; prim: <none>
    assign limb_29_480 = {limb_29_479, limb_29_473, limb_29_467}; // decl: <none>; prim: <none>
    assign limb_33_481 = tmp_workload_top_int_65__74_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_33_482 = tmp_workload_top_int_65__76_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_483Core rtlzz_owner_483(.a(32'(rtlzz_pipe_481_s1)), .b(32'(rtlzz_pipe_482_s1)), .cin(1'h0), .value(limb_33_483));
    assign limb_33_484 = limb_33_483[31:0]; // decl: <none>; prim: <none>
    assign limb_33_485 = limb_33_483[32]; // decl: <none>; prim: <none>
    assign limb_33_486 = tmp_workload_top_int_65__74_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_33_487 = tmp_workload_top_int_65__76_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_488Core rtlzz_owner_488(.a(32'(rtlzz_pipe_486_s2)), .b(32'(rtlzz_pipe_487_s2)), .cin(rtlzz_pipe_485_s2), .value(limb_33_488));
    assign limb_33_489 = limb_33_488[31:0]; // decl: <none>; prim: <none>
    assign limb_33_490 = limb_33_488[32]; // decl: <none>; prim: <none>
    assign limb_33_491 = tmp_workload_top_int_65__74_v0[64]; // decl: <none>; prim: <none>
    assign limb_33_492 = tmp_workload_top_int_65__76_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_493Core rtlzz_owner_493(.a(1'(rtlzz_pipe_491_s3)), .b(1'(rtlzz_pipe_492_s3)), .cin(rtlzz_pipe_490_s3), .value(limb_33_493[0:0]));
    assign limb_33_493[1:1] = '0;
    assign limb_33_494 = limb_33_493[0]; // decl: <none>; prim: <none>
    assign limb_33_495 = {limb_33_494, rtlzz_pipe_489_s3, rtlzz_pipe_484_s3}; // decl: <none>; prim: <none>
    assign limb_35_496 = s8_norm_add_46_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_35_497 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_35_498 = (~limb_35_497); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_499Core rtlzz_owner_499(.a(32'(rtlzz_pipe_496_s5)), .b(32'(limb_35_498)), .cin(1'h1), .value(limb_35_499));
    assign limb_35_500 = limb_35_499[31:0]; // decl: <none>; prim: <none>
    assign limb_35_501 = limb_35_499[32]; // decl: <none>; prim: <none>
    assign limb_35_502 = s8_norm_add_46_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_35_503 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_35_504 = (~limb_35_503); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(32'(rtlzz_pipe_502_s6)), .b(32'(limb_35_504)), .cin(rtlzz_pipe_501_s6), .value(limb_35_505));
    assign limb_35_506 = limb_35_505[31:0]; // decl: <none>; prim: <none>
    assign limb_35_507 = limb_35_505[32]; // decl: <none>; prim: <none>
    assign limb_35_508 = s8_norm_add_46_v0[64]; // decl: <none>; prim: <none>
    assign limb_35_509 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_35_510 = (~limb_35_509); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_511Core rtlzz_owner_511(.a(1'(rtlzz_pipe_508_s7)), .b(1'(limb_35_510)), .cin(rtlzz_pipe_507_s7), .value(limb_35_511[0:0]));
    assign limb_35_511[1:1] = '0;
    assign limb_35_512 = limb_35_511[0]; // decl: <none>; prim: <none>
    assign limb_35_513 = {limb_35_512, rtlzz_pipe_506_s7, rtlzz_pipe_500_s7}; // decl: <none>; prim: <none>
    assign limb_37_514 = tmp_workload_top_int_65__74_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_37_515 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_516Core rtlzz_owner_516(.a(32'(rtlzz_pipe_514_s9)), .b(32'(limb_37_515)), .cin(1'h0), .value(limb_37_516));
    assign limb_37_517 = limb_37_516[31:0]; // decl: <none>; prim: <none>
    assign limb_37_518 = limb_37_516[32]; // decl: <none>; prim: <none>
    assign limb_37_519 = tmp_workload_top_int_65__74_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_37_520 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_521Core rtlzz_owner_521(.a(32'(rtlzz_pipe_519_s10)), .b(32'(limb_37_520)), .cin(rtlzz_pipe_518_s10), .value(limb_37_521));
    assign limb_37_522 = limb_37_521[31:0]; // decl: <none>; prim: <none>
    assign limb_37_523 = limb_37_521[32]; // decl: <none>; prim: <none>
    assign limb_37_524 = tmp_workload_top_int_65__74_v0[64]; // decl: <none>; prim: <none>
    assign limb_37_525 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(1'(rtlzz_pipe_524_s10)), .b(1'(limb_37_525)), .cin(limb_37_523), .value(limb_37_526[0:0]));
    assign limb_37_526[1:1] = '0;
    assign limb_37_527 = limb_37_526[0]; // decl: <none>; prim: <none>
    assign limb_37_528 = {limb_37_527, limb_37_522, rtlzz_pipe_517_s10}; // decl: <none>; prim: <none>
    assign limb_38_529 = s8_norm_add_54_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_38_530 = tmp_workload_top_int_65__76_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_38_531 = (~limb_38_530); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_532Core rtlzz_owner_532(.a(32'(rtlzz_pipe_529_s11)), .b(32'(rtlzz_pipe_531_s11)), .cin(1'h1), .value(limb_38_532));
    assign limb_38_533 = limb_38_532[31:0]; // decl: <none>; prim: <none>
    assign limb_38_534 = limb_38_532[32]; // decl: <none>; prim: <none>
    assign limb_38_535 = s8_norm_add_54_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_38_536 = tmp_workload_top_int_65__76_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_38_537 = (~rtlzz_pipe_536_s1); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_538Core rtlzz_owner_538(.a(32'(rtlzz_pipe_535_s12)), .b(32'(rtlzz_pipe_537_s12)), .cin(rtlzz_pipe_534_s12), .value(limb_38_538));
    assign limb_38_539 = limb_38_538[31:0]; // decl: <none>; prim: <none>
    assign limb_38_540 = limb_38_538[32]; // decl: <none>; prim: <none>
    assign limb_38_541 = s8_norm_add_54_v0[64]; // decl: <none>; prim: <none>
    assign limb_38_542 = tmp_workload_top_int_65__76_v0[64]; // decl: <none>; prim: <none>
    assign limb_38_543 = (~rtlzz_pipe_542_s2); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_544Core rtlzz_owner_544(.a(1'(rtlzz_pipe_541_s13)), .b(1'(rtlzz_pipe_543_s13)), .cin(rtlzz_pipe_540_s13), .value(limb_38_544[0:0]));
    assign limb_38_544[1:1] = '0;
    assign limb_38_545 = limb_38_544[0]; // decl: <none>; prim: <none>
    assign limb_38_546 = {limb_38_545, rtlzz_pipe_539_s13, rtlzz_pipe_533_s13}; // decl: <none>; prim: <none>
    assign limb_40_547 = s8_norm_sub_56_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_40_548 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_40_549 = (~limb_40_548); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(32'(limb_40_547)), .b(32'(limb_40_549)), .cin(1'h1), .value(limb_40_550));
    assign limb_40_551 = limb_40_550[31:0]; // decl: <none>; prim: <none>
    assign limb_40_552 = limb_40_550[32]; // decl: <none>; prim: <none>
    assign limb_40_553 = s8_norm_sub_56_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_40_554 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_40_555 = (~limb_40_554); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_556Core rtlzz_owner_556(.a(32'(limb_40_553)), .b(32'(limb_40_555)), .cin(limb_40_552), .value(limb_40_556));
    assign limb_40_557 = limb_40_556[31:0]; // decl: <none>; prim: <none>
    assign limb_40_558 = limb_40_556[32]; // decl: <none>; prim: <none>
    assign limb_40_559 = s8_norm_sub_56_v0[64]; // decl: <none>; prim: <none>
    assign limb_40_560 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_40_561 = (~limb_40_560); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_562Core rtlzz_owner_562(.a(1'(limb_40_559)), .b(1'(limb_40_561)), .cin(limb_40_558), .value(limb_40_562[0:0]));
    assign limb_40_562[1:1] = '0;
    assign limb_40_563 = limb_40_562[0]; // decl: <none>; prim: <none>
    assign limb_40_564 = {limb_40_563, limb_40_557, limb_40_551}; // decl: <none>; prim: <none>
    assign limb_44_565 = tmp_workload_top_int_65__107_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_44_566 = tmp_workload_top_int_65__109_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_567Core rtlzz_owner_567(.a(32'(rtlzz_pipe_565_s3)), .b(32'(rtlzz_pipe_566_s3)), .cin(1'h0), .value(limb_44_567));
    assign limb_44_568 = limb_44_567[31:0]; // decl: <none>; prim: <none>
    assign limb_44_569 = limb_44_567[32]; // decl: <none>; prim: <none>
    assign limb_44_570 = tmp_workload_top_int_65__107_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_44_571 = tmp_workload_top_int_65__109_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_572Core rtlzz_owner_572(.a(32'(rtlzz_pipe_570_s4)), .b(32'(rtlzz_pipe_571_s4)), .cin(rtlzz_pipe_569_s4), .value(limb_44_572));
    assign limb_44_573 = limb_44_572[31:0]; // decl: <none>; prim: <none>
    assign limb_44_574 = limb_44_572[32]; // decl: <none>; prim: <none>
    assign limb_44_575 = tmp_workload_top_int_65__107_v0[64]; // decl: <none>; prim: <none>
    assign limb_44_576 = tmp_workload_top_int_65__109_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_577Core rtlzz_owner_577(.a(1'(rtlzz_pipe_575_s5)), .b(1'(rtlzz_pipe_576_s5)), .cin(rtlzz_pipe_574_s5), .value(limb_44_577[0:0]));
    assign limb_44_577[1:1] = '0;
    assign limb_44_578 = limb_44_577[0]; // decl: <none>; prim: <none>
    assign limb_44_579 = {limb_44_578, rtlzz_pipe_573_s5, rtlzz_pipe_568_s5}; // decl: <none>; prim: <none>
    assign limb_46_580 = s8_norm_add_66_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_46_581 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_46_582 = (~limb_46_581); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_583Core rtlzz_owner_583(.a(32'(rtlzz_pipe_580_s7)), .b(32'(limb_46_582)), .cin(1'h1), .value(limb_46_583));
    assign limb_46_584 = limb_46_583[31:0]; // decl: <none>; prim: <none>
    assign limb_46_585 = limb_46_583[32]; // decl: <none>; prim: <none>
    assign limb_46_586 = s8_norm_add_66_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_46_587 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_46_588 = (~limb_46_587); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589Core rtlzz_owner_589(.a(32'(rtlzz_pipe_586_s8)), .b(32'(limb_46_588)), .cin(rtlzz_pipe_585_s8), .value(limb_46_589));
    assign limb_46_590 = limb_46_589[31:0]; // decl: <none>; prim: <none>
    assign limb_46_591 = limb_46_589[32]; // decl: <none>; prim: <none>
    assign limb_46_592 = s8_norm_add_66_v0[64]; // decl: <none>; prim: <none>
    assign limb_46_593 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_46_594 = (~limb_46_593); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_595Core rtlzz_owner_595(.a(1'(rtlzz_pipe_592_s8)), .b(1'(limb_46_594)), .cin(limb_46_591), .value(limb_46_595[0:0]));
    assign limb_46_595[1:1] = '0;
    assign limb_46_596 = limb_46_595[0]; // decl: <none>; prim: <none>
    assign limb_46_597 = {limb_46_596, limb_46_590, rtlzz_pipe_584_s8}; // decl: <none>; prim: <none>
    assign limb_48_598 = tmp_workload_top_int_65__107_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_48_599 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_600Core rtlzz_owner_600(.a(32'(limb_48_598)), .b(32'(limb_48_599)), .cin(1'h0), .value(limb_48_600));
    assign limb_48_601 = limb_48_600[31:0]; // decl: <none>; prim: <none>
    assign limb_48_602 = limb_48_600[32]; // decl: <none>; prim: <none>
    assign limb_48_603 = tmp_workload_top_int_65__107_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_48_604 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_605Core rtlzz_owner_605(.a(32'(rtlzz_pipe_603_s1)), .b(32'(limb_48_604)), .cin(rtlzz_pipe_602_s1), .value(limb_48_605));
    assign limb_48_606 = limb_48_605[31:0]; // decl: <none>; prim: <none>
    assign limb_48_607 = limb_48_605[32]; // decl: <none>; prim: <none>
    assign limb_48_608 = tmp_workload_top_int_65__107_v0[64]; // decl: <none>; prim: <none>
    assign limb_48_609 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_610Core rtlzz_owner_610(.a(1'(rtlzz_pipe_608_s2)), .b(1'(limb_48_609)), .cin(rtlzz_pipe_607_s2), .value(limb_48_610[0:0]));
    assign limb_48_610[1:1] = '0;
    assign limb_48_611 = limb_48_610[0]; // decl: <none>; prim: <none>
    assign limb_48_612 = {limb_48_611, rtlzz_pipe_606_s2, rtlzz_pipe_601_s2}; // decl: <none>; prim: <none>
    assign limb_49_613 = s8_norm_add_74_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_49_614 = tmp_workload_top_int_65__109_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_49_615 = (~rtlzz_pipe_614_s3); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_616Core rtlzz_owner_616(.a(32'(rtlzz_pipe_613_s4)), .b(32'(rtlzz_pipe_615_s4)), .cin(1'h1), .value(limb_49_616));
    assign limb_49_617 = limb_49_616[31:0]; // decl: <none>; prim: <none>
    assign limb_49_618 = limb_49_616[32]; // decl: <none>; prim: <none>
    assign limb_49_619 = s8_norm_add_74_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_49_620 = tmp_workload_top_int_65__109_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_49_621 = (~rtlzz_pipe_620_s5); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_622Core rtlzz_owner_622(.a(32'(rtlzz_pipe_619_s6)), .b(32'(rtlzz_pipe_621_s6)), .cin(rtlzz_pipe_618_s6), .value(limb_49_622));
    assign limb_49_623 = limb_49_622[31:0]; // decl: <none>; prim: <none>
    assign limb_49_624 = limb_49_622[32]; // decl: <none>; prim: <none>
    assign limb_49_625 = s8_norm_add_74_v0[64]; // decl: <none>; prim: <none>
    assign limb_49_626 = tmp_workload_top_int_65__109_v0[64]; // decl: <none>; prim: <none>
    assign limb_49_627 = (~rtlzz_pipe_626_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_628Core rtlzz_owner_628(.a(1'(rtlzz_pipe_625_s10)), .b(1'(rtlzz_pipe_627_s10)), .cin(rtlzz_pipe_624_s10), .value(limb_49_628[0:0]));
    assign limb_49_628[1:1] = '0;
    assign limb_49_629 = limb_49_628[0]; // decl: <none>; prim: <none>
    assign limb_49_630 = {limb_49_629, rtlzz_pipe_623_s10, rtlzz_pipe_617_s10}; // decl: <none>; prim: <none>
    assign limb_51_631 = s8_norm_sub_76_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_51_632 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_51_633 = (~limb_51_632); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_634Core rtlzz_owner_634(.a(32'(rtlzz_pipe_631_s11)), .b(32'(limb_51_633)), .cin(1'h1), .value(limb_51_634));
    assign limb_51_635 = limb_51_634[31:0]; // decl: <none>; prim: <none>
    assign limb_51_636 = limb_51_634[32]; // decl: <none>; prim: <none>
    assign limb_51_637 = s8_norm_sub_76_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_51_638 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_51_639 = (~limb_51_638); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_640Core rtlzz_owner_640(.a(32'(rtlzz_pipe_637_s11)), .b(32'(limb_51_639)), .cin(limb_51_636), .value(limb_51_640));
    assign limb_51_641 = limb_51_640[31:0]; // decl: <none>; prim: <none>
    assign limb_51_642 = limb_51_640[32]; // decl: <none>; prim: <none>
    assign limb_51_643 = s8_norm_sub_76_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_644 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_51_645 = (~limb_51_644); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_646Core rtlzz_owner_646(.a(1'(rtlzz_pipe_643_s11)), .b(1'(limb_51_645)), .cin(limb_51_642), .value(limb_51_646[0:0]));
    assign limb_51_646[1:1] = '0;
    assign limb_51_647 = limb_51_646[0]; // decl: <none>; prim: <none>
    assign limb_51_648 = {limb_51_647, limb_51_641, limb_51_635}; // decl: <none>; prim: <none>
    assign limb_55_649 = tmp_workload_top_int_65__140_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_55_650 = tmp_workload_top_int_65__142_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_651Core rtlzz_owner_651(.a(32'(limb_55_649)), .b(32'(limb_55_650)), .cin(1'h0), .value(limb_55_651));
    assign limb_55_652 = limb_55_651[31:0]; // decl: <none>; prim: <none>
    assign limb_55_653 = limb_55_651[32]; // decl: <none>; prim: <none>
    assign limb_55_654 = tmp_workload_top_int_65__140_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_55_655 = tmp_workload_top_int_65__142_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_656Core rtlzz_owner_656(.a(32'(rtlzz_pipe_654_s9)), .b(32'(rtlzz_pipe_655_s9)), .cin(rtlzz_pipe_653_s9), .value(limb_55_656));
    assign limb_55_657 = limb_55_656[31:0]; // decl: <none>; prim: <none>
    assign limb_55_658 = limb_55_656[32]; // decl: <none>; prim: <none>
    assign limb_55_659 = tmp_workload_top_int_65__140_v0[64]; // decl: <none>; prim: <none>
    assign limb_55_660 = tmp_workload_top_int_65__142_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_661Core rtlzz_owner_661(.a(1'(rtlzz_pipe_659_s9)), .b(1'(rtlzz_pipe_660_s9)), .cin(limb_55_658), .value(limb_55_661[0:0]));
    assign limb_55_661[1:1] = '0;
    assign limb_55_662 = limb_55_661[0]; // decl: <none>; prim: <none>
    assign limb_55_663 = {limb_55_662, limb_55_657, rtlzz_pipe_652_s9}; // decl: <none>; prim: <none>
    assign limb_57_664 = s8_norm_add_86_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_57_665 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_57_666 = (~limb_57_665); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_667Core rtlzz_owner_667(.a(32'(limb_57_664)), .b(32'(limb_57_666)), .cin(1'h1), .value(limb_57_667));
    assign limb_57_668 = limb_57_667[31:0]; // decl: <none>; prim: <none>
    assign limb_57_669 = limb_57_667[32]; // decl: <none>; prim: <none>
    assign limb_57_670 = s8_norm_add_86_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_57_671 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_57_672 = (~limb_57_671); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_673Core rtlzz_owner_673(.a(32'(rtlzz_pipe_670_s10)), .b(32'(limb_57_672)), .cin(rtlzz_pipe_669_s10), .value(limb_57_673));
    assign limb_57_674 = limb_57_673[31:0]; // decl: <none>; prim: <none>
    assign limb_57_675 = limb_57_673[32]; // decl: <none>; prim: <none>
    assign limb_57_676 = s8_norm_add_86_v0[64]; // decl: <none>; prim: <none>
    assign limb_57_677 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_57_678 = (~limb_57_677); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_679Core rtlzz_owner_679(.a(1'(rtlzz_pipe_676_s10)), .b(1'(limb_57_678)), .cin(limb_57_675), .value(limb_57_679[0:0]));
    assign limb_57_679[1:1] = '0;
    assign limb_57_680 = limb_57_679[0]; // decl: <none>; prim: <none>
    assign limb_57_681 = {limb_57_680, limb_57_674, rtlzz_pipe_668_s10}; // decl: <none>; prim: <none>
    assign limb_59_682 = tmp_workload_top_int_65__140_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_59_683 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_684Core rtlzz_owner_684(.a(32'(limb_59_682)), .b(32'(limb_59_683)), .cin(1'h0), .value(limb_59_684));
    assign limb_59_685 = limb_59_684[31:0]; // decl: <none>; prim: <none>
    assign limb_59_686 = limb_59_684[32]; // decl: <none>; prim: <none>
    assign limb_59_687 = tmp_workload_top_int_65__140_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_59_688 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_689Core rtlzz_owner_689(.a(32'(limb_59_687)), .b(32'(limb_59_688)), .cin(limb_59_686), .value(limb_59_689));
    assign limb_59_690 = limb_59_689[31:0]; // decl: <none>; prim: <none>
    assign limb_59_691 = limb_59_689[32]; // decl: <none>; prim: <none>
    assign limb_59_692 = tmp_workload_top_int_65__140_v0[64]; // decl: <none>; prim: <none>
    assign limb_59_693 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_694Core rtlzz_owner_694(.a(1'(limb_59_692)), .b(1'(limb_59_693)), .cin(limb_59_691), .value(limb_59_694[0:0]));
    assign limb_59_694[1:1] = '0;
    assign limb_59_695 = limb_59_694[0]; // decl: <none>; prim: <none>
    assign limb_59_696 = {limb_59_695, limb_59_690, limb_59_685}; // decl: <none>; prim: <none>
    assign limb_60_697 = s8_norm_add_94_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_60_698 = tmp_workload_top_int_65__142_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_60_699 = (~rtlzz_pipe_698_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_700Core rtlzz_owner_700(.a(32'(rtlzz_pipe_697_s9)), .b(32'(limb_60_699)), .cin(1'h1), .value(limb_60_700));
    assign limb_60_701 = limb_60_700[31:0]; // decl: <none>; prim: <none>
    assign limb_60_702 = limb_60_700[32]; // decl: <none>; prim: <none>
    assign limb_60_703 = s8_norm_add_94_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_60_704 = tmp_workload_top_int_65__142_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_60_705 = (~rtlzz_pipe_704_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_706Core rtlzz_owner_706(.a(32'(rtlzz_pipe_703_s11)), .b(32'(limb_60_705)), .cin(rtlzz_pipe_702_s11), .value(limb_60_706));
    assign limb_60_707 = limb_60_706[31:0]; // decl: <none>; prim: <none>
    assign limb_60_708 = limb_60_706[32]; // decl: <none>; prim: <none>
    assign limb_60_709 = s8_norm_add_94_v0[64]; // decl: <none>; prim: <none>
    assign limb_60_710 = tmp_workload_top_int_65__142_v0[64]; // decl: <none>; prim: <none>
    assign limb_60_711 = (~limb_60_710); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_712Core rtlzz_owner_712(.a(1'(rtlzz_pipe_709_s11)), .b(1'(rtlzz_pipe_711_s11)), .cin(limb_60_708), .value(limb_60_712[0:0]));
    assign limb_60_712[1:1] = '0;
    assign limb_60_713 = limb_60_712[0]; // decl: <none>; prim: <none>
    assign limb_60_714 = {limb_60_713, limb_60_707, rtlzz_pipe_701_s11}; // decl: <none>; prim: <none>
    assign limb_62_715 = s8_norm_sub_96_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_62_716 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_62_717 = (~limb_62_716); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_718Core rtlzz_owner_718(.a(32'(limb_62_715)), .b(32'(limb_62_717)), .cin(1'h1), .value(limb_62_718));
    assign limb_62_719 = limb_62_718[31:0]; // decl: <none>; prim: <none>
    assign limb_62_720 = limb_62_718[32]; // decl: <none>; prim: <none>
    assign limb_62_721 = s8_norm_sub_96_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_62_722 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_62_723 = (~limb_62_722); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_724Core rtlzz_owner_724(.a(32'(rtlzz_pipe_721_s12)), .b(32'(limb_62_723)), .cin(rtlzz_pipe_720_s12), .value(limb_62_724));
    assign limb_62_725 = limb_62_724[31:0]; // decl: <none>; prim: <none>
    assign limb_62_726 = limb_62_724[32]; // decl: <none>; prim: <none>
    assign limb_62_727 = s8_norm_sub_96_v0[64]; // decl: <none>; prim: <none>
    assign limb_62_728 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_62_729 = (~limb_62_728); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_730Core rtlzz_owner_730(.a(1'(rtlzz_pipe_727_s13)), .b(1'(limb_62_729)), .cin(rtlzz_pipe_726_s13), .value(limb_62_730[0:0]));
    assign limb_62_730[1:1] = '0;
    assign limb_62_731 = limb_62_730[0]; // decl: <none>; prim: <none>
    assign limb_62_732 = {limb_62_731, rtlzz_pipe_725_s13, rtlzz_pipe_719_s13}; // decl: <none>; prim: <none>
    assign limb_72_733 = tmp_workload_top_int_129__191_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_72_734 = n36_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_72_735 = (~limb_72_734); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_736Core rtlzz_owner_736(.a(32'(limb_72_733)), .b(32'(limb_72_735)), .cin(1'h1), .value(limb_72_736));
    assign limb_72_737 = limb_72_736[31:0]; // decl: <none>; prim: <none>
    assign limb_72_738 = limb_72_736[32]; // decl: <none>; prim: <none>
    assign limb_72_739 = tmp_workload_top_int_129__191_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_72_740 = n36_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_72_741 = (~limb_72_740); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_742Core rtlzz_owner_742(.a(32'(limb_72_739)), .b(32'(limb_72_741)), .cin(limb_72_738), .value(limb_72_742));
    assign limb_72_743 = limb_72_742[31:0]; // decl: <none>; prim: <none>
    assign limb_72_744 = limb_72_742[32]; // decl: <none>; prim: <none>
    assign limb_72_745 = tmp_workload_top_int_129__191_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_72_746 = n36_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_72_747 = (~limb_72_746); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_748Core rtlzz_owner_748(.a(32'(limb_72_745)), .b(32'(limb_72_747)), .cin(limb_72_744), .value(limb_72_748));
    assign limb_72_749 = limb_72_748[31:0]; // decl: <none>; prim: <none>
    assign limb_72_750 = limb_72_748[32]; // decl: <none>; prim: <none>
    assign limb_72_751 = tmp_workload_top_int_129__191_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_72_752 = n36_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_72_753 = (~limb_72_752); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_754Core rtlzz_owner_754(.a(32'(limb_72_751)), .b(32'(limb_72_753)), .cin(limb_72_750), .value(limb_72_754));
    assign limb_72_755 = limb_72_754[31:0]; // decl: <none>; prim: <none>
    assign limb_72_756 = limb_72_754[32]; // decl: <none>; prim: <none>
    assign limb_72_757 = tmp_workload_top_int_129__191_v0[128]; // decl: <none>; prim: <none>
    assign limb_72_758 = n36_v0[128]; // decl: <none>; prim: <none>
    assign limb_72_759 = (~limb_72_758); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_760Core rtlzz_owner_760(.a(1'(limb_72_757)), .b(1'(limb_72_759)), .cin(limb_72_756), .value(limb_72_760[0:0]));
    assign limb_72_760[1:1] = '0;
    assign limb_72_761 = limb_72_760[0]; // decl: <none>; prim: <none>
    assign limb_72_762 = {limb_72_761, limb_72_755, limb_72_749, limb_72_743, limb_72_737}; // decl: <none>; prim: <none>
    assign limb_74_763 = s8_norm_sub_118_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_74_764 = 32'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_74_765 = (~limb_74_764); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_766Core rtlzz_owner_766(.a(32'(limb_74_763)), .b(32'(limb_74_765)), .cin(1'h1), .value(limb_74_766));
    assign limb_74_767 = limb_74_766[31:0]; // decl: <none>; prim: <none>
    assign limb_74_768 = limb_74_766[32]; // decl: <none>; prim: <none>
    assign limb_74_769 = s8_norm_sub_118_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_74_770 = 32'((129'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_74_771 = (~limb_74_770); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_772Core rtlzz_owner_772(.a(32'(limb_74_769)), .b(32'(limb_74_771)), .cin(limb_74_768), .value(limb_74_772));
    assign limb_74_773 = limb_74_772[31:0]; // decl: <none>; prim: <none>
    assign limb_74_774 = limb_74_772[32]; // decl: <none>; prim: <none>
    assign limb_74_775 = s8_norm_sub_118_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_74_776 = 32'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_74_777 = (~limb_74_776); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_778Core rtlzz_owner_778(.a(32'(limb_74_775)), .b(32'(limb_74_777)), .cin(limb_74_774), .value(limb_74_778[0:0]));
    assign limb_74_778[32:1] = '0;
    assign limb_74_779 = limb_74_778[31:0]; // decl: <none>; prim: <none>
    assign limb_74_780 = limb_74_778[32]; // decl: <none>; prim: <none>
    assign limb_74_781 = s8_norm_sub_118_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_74_782 = 32'((129'hffffffff00000001) >> 96); // decl: <none>; prim: <none>
    assign limb_74_783 = (~limb_74_782); // decl: <none>; prim: <none>
    assign limb_74_784 = 33'((({1'h0, limb_74_781}) + ({1'h0, limb_74_783}) + ({32'h0, limb_74_780}))); // decl: <none>; prim: <none>
    assign limb_74_785 = limb_74_784[31:0]; // decl: <none>; prim: <none>
    assign limb_74_786 = limb_74_784[32]; // decl: <none>; prim: <none>
    assign limb_74_787 = s8_norm_sub_118_v0[128]; // decl: <none>; prim: <none>
    assign limb_74_788 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_74_789 = (~limb_74_788); // decl: <none>; prim: <none>
    assign limb_74_790 = 2'((({1'h0, limb_74_787}) + ({1'h0, limb_74_789}) + ({1'h0, limb_74_786}))); // decl: <none>; prim: <none>
    assign limb_74_791 = limb_74_790[0]; // decl: <none>; prim: <none>
    assign limb_74_792 = {limb_74_791, limb_74_785, limb_74_779, limb_74_773, limb_74_767}; // decl: <none>; prim: <none>
    assign limb_78_793 = tmp_workload_top_int_65__204_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_78_794 = tmp_workload_top_int_65__206_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_795Core rtlzz_owner_795(.a(32'(limb_78_793)), .b(32'(limb_78_794)), .cin(1'h0), .value(limb_78_795));
    assign limb_78_796 = limb_78_795[31:0]; // decl: <none>; prim: <none>
    assign limb_78_797 = limb_78_795[32]; // decl: <none>; prim: <none>
    assign limb_78_798 = tmp_workload_top_int_65__204_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_78_799 = tmp_workload_top_int_65__206_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_800Core rtlzz_owner_800(.a(32'(limb_78_798)), .b(32'(limb_78_799)), .cin(limb_78_797), .value(limb_78_800));
    assign limb_78_801 = limb_78_800[31:0]; // decl: <none>; prim: <none>
    assign limb_78_802 = limb_78_800[32]; // decl: <none>; prim: <none>
    assign limb_78_803 = tmp_workload_top_int_65__204_v0[64]; // decl: <none>; prim: <none>
    assign limb_78_804 = tmp_workload_top_int_65__206_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_805Core rtlzz_owner_805(.a(1'(limb_78_803)), .b(1'(limb_78_804)), .cin(limb_78_802), .value(limb_78_805[0:0]));
    assign limb_78_805[1:1] = '0;
    assign limb_78_806 = limb_78_805[0]; // decl: <none>; prim: <none>
    assign limb_78_807 = {limb_78_806, limb_78_801, limb_78_796}; // decl: <none>; prim: <none>
    assign limb_80_808 = s8_norm_add_127_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_80_809 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_80_810 = (~limb_80_809); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_811Core rtlzz_owner_811(.a(32'(limb_80_808)), .b(32'(limb_80_810)), .cin(1'h1), .value(limb_80_811));
    assign limb_80_812 = limb_80_811[31:0]; // decl: <none>; prim: <none>
    assign limb_80_813 = limb_80_811[32]; // decl: <none>; prim: <none>
    assign limb_80_814 = s8_norm_add_127_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_80_815 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_80_816 = (~limb_80_815); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_817Core rtlzz_owner_817(.a(32'(limb_80_814)), .b(32'(limb_80_816)), .cin(limb_80_813), .value(limb_80_817));
    assign limb_80_818 = limb_80_817[31:0]; // decl: <none>; prim: <none>
    assign limb_80_819 = limb_80_817[32]; // decl: <none>; prim: <none>
    assign limb_80_820 = s8_norm_add_127_v0[64]; // decl: <none>; prim: <none>
    assign limb_80_821 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_80_822 = (~limb_80_821); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_823Core rtlzz_owner_823(.a(1'(limb_80_820)), .b(1'(limb_80_822)), .cin(limb_80_819), .value(limb_80_823[0:0]));
    assign limb_80_823[1:1] = '0;
    assign limb_80_824 = limb_80_823[0]; // decl: <none>; prim: <none>
    assign limb_80_825 = {limb_80_824, limb_80_818, limb_80_812}; // decl: <none>; prim: <none>
    assign limb_82_826 = tmp_workload_top_int_65__204_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_82_827 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_828Core rtlzz_owner_828(.a(32'(limb_82_826)), .b(32'(limb_82_827)), .cin(1'h0), .value(limb_82_828));
    assign limb_82_829 = limb_82_828[31:0]; // decl: <none>; prim: <none>
    assign limb_82_830 = limb_82_828[32]; // decl: <none>; prim: <none>
    assign limb_82_831 = tmp_workload_top_int_65__204_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_82_832 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_833Core rtlzz_owner_833(.a(32'(limb_82_831)), .b(32'(limb_82_832)), .cin(limb_82_830), .value(limb_82_833));
    assign limb_82_834 = limb_82_833[31:0]; // decl: <none>; prim: <none>
    assign limb_82_835 = limb_82_833[32]; // decl: <none>; prim: <none>
    assign limb_82_836 = tmp_workload_top_int_65__204_v0[64]; // decl: <none>; prim: <none>
    assign limb_82_837 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_838Core rtlzz_owner_838(.a(1'(limb_82_836)), .b(1'(limb_82_837)), .cin(limb_82_835), .value(limb_82_838[0:0]));
    assign limb_82_838[1:1] = '0;
    assign limb_82_839 = limb_82_838[0]; // decl: <none>; prim: <none>
    assign limb_82_840 = {limb_82_839, limb_82_834, limb_82_829}; // decl: <none>; prim: <none>
    assign limb_83_841 = s8_norm_add_135_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_83_842 = tmp_workload_top_int_65__206_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_83_843 = (~limb_83_842); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_844Core rtlzz_owner_844(.a(32'(limb_83_841)), .b(32'(limb_83_843)), .cin(1'h1), .value(limb_83_844));
    assign limb_83_845 = limb_83_844[31:0]; // decl: <none>; prim: <none>
    assign limb_83_846 = limb_83_844[32]; // decl: <none>; prim: <none>
    assign limb_83_847 = s8_norm_add_135_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_83_848 = tmp_workload_top_int_65__206_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_83_849 = (~limb_83_848); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_850Core rtlzz_owner_850(.a(32'(limb_83_847)), .b(32'(limb_83_849)), .cin(limb_83_846), .value(limb_83_850));
    assign limb_83_851 = limb_83_850[31:0]; // decl: <none>; prim: <none>
    assign limb_83_852 = limb_83_850[32]; // decl: <none>; prim: <none>
    assign limb_83_853 = s8_norm_add_135_v0[64]; // decl: <none>; prim: <none>
    assign limb_83_854 = tmp_workload_top_int_65__206_v0[64]; // decl: <none>; prim: <none>
    assign limb_83_855 = (~limb_83_854); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_856Core rtlzz_owner_856(.a(1'(limb_83_853)), .b(1'(limb_83_855)), .cin(limb_83_852), .value(limb_83_856[0:0]));
    assign limb_83_856[1:1] = '0;
    assign limb_83_857 = limb_83_856[0]; // decl: <none>; prim: <none>
    assign limb_83_858 = {limb_83_857, limb_83_851, limb_83_845}; // decl: <none>; prim: <none>
    assign limb_85_859 = s8_norm_sub_137_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_85_860 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_85_861 = (~limb_85_860); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_862Core rtlzz_owner_862(.a(32'(limb_85_859)), .b(32'(limb_85_861)), .cin(1'h1), .value(limb_85_862));
    assign limb_85_863 = limb_85_862[31:0]; // decl: <none>; prim: <none>
    assign limb_85_864 = limb_85_862[32]; // decl: <none>; prim: <none>
    assign limb_85_865 = s8_norm_sub_137_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_85_866 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_85_867 = (~limb_85_866); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_868Core rtlzz_owner_868(.a(32'(limb_85_865)), .b(32'(limb_85_867)), .cin(limb_85_864), .value(limb_85_868));
    assign limb_85_869 = limb_85_868[31:0]; // decl: <none>; prim: <none>
    assign limb_85_870 = limb_85_868[32]; // decl: <none>; prim: <none>
    assign limb_85_871 = s8_norm_sub_137_v0[64]; // decl: <none>; prim: <none>
    assign limb_85_872 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_85_873 = (~limb_85_872); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_874Core rtlzz_owner_874(.a(1'(limb_85_871)), .b(1'(limb_85_873)), .cin(limb_85_870), .value(limb_85_874[0:0]));
    assign limb_85_874[1:1] = '0;
    assign limb_85_875 = limb_85_874[0]; // decl: <none>; prim: <none>
    assign limb_85_876 = {limb_85_875, limb_85_869, limb_85_863}; // decl: <none>; prim: <none>
    assign limb_89_877 = tmp_workload_top_int_65__237_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_89_878 = tmp_workload_top_int_65__239_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_879Core rtlzz_owner_879(.a(32'(limb_89_877)), .b(32'(rtlzz_pipe_878_s11)), .cin(1'h0), .value(limb_89_879));
    assign limb_89_880 = limb_89_879[31:0]; // decl: <none>; prim: <none>
    assign limb_89_881 = limb_89_879[32]; // decl: <none>; prim: <none>
    assign limb_89_882 = tmp_workload_top_int_65__237_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_89_883 = tmp_workload_top_int_65__239_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_884Core rtlzz_owner_884(.a(32'(limb_89_882)), .b(32'(rtlzz_pipe_883_s11)), .cin(limb_89_881), .value(limb_89_884));
    assign limb_89_885 = limb_89_884[31:0]; // decl: <none>; prim: <none>
    assign limb_89_886 = limb_89_884[32]; // decl: <none>; prim: <none>
    assign limb_89_887 = tmp_workload_top_int_65__237_v0[64]; // decl: <none>; prim: <none>
    assign limb_89_888 = tmp_workload_top_int_65__239_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_889Core rtlzz_owner_889(.a(1'(rtlzz_pipe_887_s12)), .b(1'(rtlzz_pipe_888_s12)), .cin(rtlzz_pipe_886_s12), .value(limb_89_889[0:0]));
    assign limb_89_889[1:1] = '0;
    assign limb_89_890 = limb_89_889[0]; // decl: <none>; prim: <none>
    assign limb_89_891 = {limb_89_890, rtlzz_pipe_885_s12, rtlzz_pipe_880_s12}; // decl: <none>; prim: <none>
    assign limb_91_892 = s8_norm_add_147_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_91_893 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_91_894 = (~limb_91_893); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_895Core rtlzz_owner_895(.a(32'(rtlzz_pipe_892_s13)), .b(32'(limb_91_894)), .cin(1'h1), .value(limb_91_895));
    assign limb_91_896 = limb_91_895[31:0]; // decl: <none>; prim: <none>
    assign limb_91_897 = limb_91_895[32]; // decl: <none>; prim: <none>
    assign limb_91_898 = s8_norm_add_147_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_91_899 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_91_900 = (~limb_91_899); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_901Core rtlzz_owner_901(.a(32'(rtlzz_pipe_898_s13)), .b(32'(limb_91_900)), .cin(limb_91_897), .value(limb_91_901));
    assign limb_91_902 = limb_91_901[31:0]; // decl: <none>; prim: <none>
    assign limb_91_903 = limb_91_901[32]; // decl: <none>; prim: <none>
    assign limb_91_904 = s8_norm_add_147_v0[64]; // decl: <none>; prim: <none>
    assign limb_91_905 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_91_906 = (~limb_91_905); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_907Core rtlzz_owner_907(.a(1'(rtlzz_pipe_904_s13)), .b(1'(limb_91_906)), .cin(limb_91_903), .value(limb_91_907[0:0]));
    assign limb_91_907[1:1] = '0;
    assign limb_91_908 = limb_91_907[0]; // decl: <none>; prim: <none>
    assign limb_91_909 = {limb_91_908, limb_91_902, limb_91_896}; // decl: <none>; prim: <none>
    assign limb_93_910 = tmp_workload_top_int_65__237_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_93_911 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_912Core rtlzz_owner_912(.a(32'(limb_93_910)), .b(32'(limb_93_911)), .cin(1'h0), .value(limb_93_912));
    assign limb_93_913 = limb_93_912[31:0]; // decl: <none>; prim: <none>
    assign limb_93_914 = limb_93_912[32]; // decl: <none>; prim: <none>
    assign limb_93_915 = tmp_workload_top_int_65__237_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_93_916 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_917Core rtlzz_owner_917(.a(32'(limb_93_915)), .b(32'(limb_93_916)), .cin(limb_93_914), .value(limb_93_917));
    assign limb_93_918 = limb_93_917[31:0]; // decl: <none>; prim: <none>
    assign limb_93_919 = limb_93_917[32]; // decl: <none>; prim: <none>
    assign limb_93_920 = tmp_workload_top_int_65__237_v0[64]; // decl: <none>; prim: <none>
    assign limb_93_921 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_922Core rtlzz_owner_922(.a(1'(rtlzz_pipe_920_s12)), .b(1'(limb_93_921)), .cin(rtlzz_pipe_919_s12), .value(limb_93_922[0:0]));
    assign limb_93_922[1:1] = '0;
    assign limb_93_923 = limb_93_922[0]; // decl: <none>; prim: <none>
    assign limb_93_924 = {limb_93_923, rtlzz_pipe_918_s12, rtlzz_pipe_913_s12}; // decl: <none>; prim: <none>
    assign limb_94_925 = s8_norm_add_155_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_94_926 = tmp_workload_top_int_65__239_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_94_927 = (~rtlzz_pipe_926_s10); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_928Core rtlzz_owner_928(.a(32'(limb_94_925)), .b(32'(rtlzz_pipe_927_s12)), .cin(1'h1), .value(limb_94_928));
    assign limb_94_929 = limb_94_928[31:0]; // decl: <none>; prim: <none>
    assign limb_94_930 = limb_94_928[32]; // decl: <none>; prim: <none>
    assign limb_94_931 = s8_norm_add_155_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_94_932 = tmp_workload_top_int_65__239_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_94_933 = (~limb_94_932); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_934Core rtlzz_owner_934(.a(32'(rtlzz_pipe_931_s13)), .b(32'(rtlzz_pipe_933_s13)), .cin(rtlzz_pipe_930_s13), .value(limb_94_934));
    assign limb_94_935 = limb_94_934[31:0]; // decl: <none>; prim: <none>
    assign limb_94_936 = limb_94_934[32]; // decl: <none>; prim: <none>
    assign limb_94_937 = s8_norm_add_155_v0[64]; // decl: <none>; prim: <none>
    assign limb_94_938 = tmp_workload_top_int_65__239_v0[64]; // decl: <none>; prim: <none>
    assign limb_94_939 = (~rtlzz_pipe_938_s10); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_940Core rtlzz_owner_940(.a(1'(rtlzz_pipe_937_s13)), .b(1'(rtlzz_pipe_939_s13)), .cin(limb_94_936), .value(limb_94_940[0:0]));
    assign limb_94_940[1:1] = '0;
    assign limb_94_941 = limb_94_940[0]; // decl: <none>; prim: <none>
    assign limb_94_942 = {limb_94_941, limb_94_935, rtlzz_pipe_929_s13}; // decl: <none>; prim: <none>
    assign limb_96_943 = s8_norm_sub_157_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_96_944 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_96_945 = (~limb_96_944); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_946Core rtlzz_owner_946(.a(32'(limb_96_943)), .b(32'(limb_96_945)), .cin(1'h1), .value(limb_96_946));
    assign limb_96_947 = limb_96_946[31:0]; // decl: <none>; prim: <none>
    assign limb_96_948 = limb_96_946[32]; // decl: <none>; prim: <none>
    assign limb_96_949 = s8_norm_sub_157_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_96_950 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_96_951 = (~limb_96_950); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_952Core rtlzz_owner_952(.a(32'(limb_96_949)), .b(32'(limb_96_951)), .cin(limb_96_948), .value(limb_96_952));
    assign limb_96_953 = limb_96_952[31:0]; // decl: <none>; prim: <none>
    assign limb_96_954 = limb_96_952[32]; // decl: <none>; prim: <none>
    assign limb_96_955 = s8_norm_sub_157_v0[64]; // decl: <none>; prim: <none>
    assign limb_96_956 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_96_957 = (~limb_96_956); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_958Core rtlzz_owner_958(.a(1'(rtlzz_pipe_955_s14)), .b(1'(limb_96_957)), .cin(rtlzz_pipe_954_s14), .value(limb_96_958[0:0]));
    assign limb_96_958[1:1] = '0;
    assign limb_96_959 = limb_96_958[0]; // decl: <none>; prim: <none>
    assign limb_96_960 = {limb_96_959, rtlzz_pipe_953_s14, rtlzz_pipe_947_s14}; // decl: <none>; prim: <none>
    assign limb_106_961 = tmp_workload_top_int_129__288_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_106_962 = n56_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_106_963 = (~limb_106_962); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_964Core rtlzz_owner_964(.a(32'(limb_106_961)), .b(32'(rtlzz_pipe_963_s14)), .cin(1'h1), .value(limb_106_964));
    assign limb_106_965 = limb_106_964[31:0]; // decl: <none>; prim: <none>
    assign limb_106_966 = limb_106_964[32]; // decl: <none>; prim: <none>
    assign limb_106_967 = tmp_workload_top_int_129__288_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_106_968 = n56_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_106_969 = (~limb_106_968); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_970Core rtlzz_owner_970(.a(32'(limb_106_967)), .b(32'(rtlzz_pipe_969_s14)), .cin(limb_106_966), .value(limb_106_970));
    assign limb_106_971 = limb_106_970[31:0]; // decl: <none>; prim: <none>
    assign limb_106_972 = limb_106_970[32]; // decl: <none>; prim: <none>
    assign limb_106_973 = tmp_workload_top_int_129__288_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_106_974 = n56_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_106_975 = (~limb_106_974); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_976Core rtlzz_owner_976(.a(32'(limb_106_973)), .b(32'(rtlzz_pipe_975_s14)), .cin(limb_106_972), .value(limb_106_976));
    assign limb_106_977 = limb_106_976[31:0]; // decl: <none>; prim: <none>
    assign limb_106_978 = limb_106_976[32]; // decl: <none>; prim: <none>
    assign limb_106_979 = tmp_workload_top_int_129__288_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_106_980 = n56_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_106_981 = (~limb_106_980); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_982Core rtlzz_owner_982(.a(32'(limb_106_979)), .b(32'(rtlzz_pipe_981_s14)), .cin(limb_106_978), .value(limb_106_982));
    assign limb_106_983 = limb_106_982[31:0]; // decl: <none>; prim: <none>
    assign limb_106_984 = limb_106_982[32]; // decl: <none>; prim: <none>
    assign limb_106_985 = tmp_workload_top_int_129__288_v0[128]; // decl: <none>; prim: <none>
    assign limb_106_986 = n56_v0[128]; // decl: <none>; prim: <none>
    assign limb_106_987 = (~limb_106_986); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_988Core rtlzz_owner_988(.a(1'(limb_106_985)), .b(1'(rtlzz_pipe_987_s14)), .cin(limb_106_984), .value(limb_106_988[0:0]));
    assign limb_106_988[1:1] = '0;
    assign limb_106_989 = limb_106_988[0]; // decl: <none>; prim: <none>
    assign limb_106_990 = {limb_106_989, limb_106_983, limb_106_977, limb_106_971, limb_106_965}; // decl: <none>; prim: <none>
    assign limb_108_991 = s8_norm_sub_179_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_108_992 = 32'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_108_993 = (~limb_108_992); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_994Core rtlzz_owner_994(.a(32'(limb_108_991)), .b(32'(limb_108_993)), .cin(1'h1), .value(limb_108_994));
    assign limb_108_995 = limb_108_994[31:0]; // decl: <none>; prim: <none>
    assign limb_108_996 = limb_108_994[32]; // decl: <none>; prim: <none>
    assign limb_108_997 = s8_norm_sub_179_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_108_998 = 32'((129'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_108_999 = (~limb_108_998); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1000Core rtlzz_owner_1000(.a(32'(limb_108_997)), .b(32'(limb_108_999)), .cin(limb_108_996), .value(limb_108_1000));
    assign limb_108_1001 = limb_108_1000[31:0]; // decl: <none>; prim: <none>
    assign limb_108_1002 = limb_108_1000[32]; // decl: <none>; prim: <none>
    assign limb_108_1003 = s8_norm_sub_179_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_108_1004 = 32'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_108_1005 = (~limb_108_1004); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1006Core rtlzz_owner_1006(.a(32'(limb_108_1003)), .b(32'(limb_108_1005)), .cin(limb_108_1002), .value(limb_108_1006[0:0]));
    assign limb_108_1006[32:1] = '0;
    assign limb_108_1007 = limb_108_1006[31:0]; // decl: <none>; prim: <none>
    assign limb_108_1008 = limb_108_1006[32]; // decl: <none>; prim: <none>
    assign limb_108_1009 = s8_norm_sub_179_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_108_1010 = 32'((129'hffffffff00000001) >> 96); // decl: <none>; prim: <none>
    assign limb_108_1011 = (~limb_108_1010); // decl: <none>; prim: <none>
    assign limb_108_1012 = 33'((({1'h0, limb_108_1009}) + ({1'h0, limb_108_1011}) + ({32'h0, limb_108_1008}))); // decl: <none>; prim: <none>
    assign limb_108_1013 = limb_108_1012[31:0]; // decl: <none>; prim: <none>
    assign limb_108_1014 = limb_108_1012[32]; // decl: <none>; prim: <none>
    assign limb_108_1015 = s8_norm_sub_179_v0[128]; // decl: <none>; prim: <none>
    assign limb_108_1016 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_108_1017 = (~limb_108_1016); // decl: <none>; prim: <none>
    assign limb_108_1018 = 2'((({1'h0, limb_108_1015}) + ({1'h0, limb_108_1017}) + ({1'h0, limb_108_1014}))); // decl: <none>; prim: <none>
    assign limb_108_1019 = limb_108_1018[0]; // decl: <none>; prim: <none>
    assign limb_108_1020 = {limb_108_1019, limb_108_1013, limb_108_1007, limb_108_1001, limb_108_995}; // decl: <none>; prim: <none>
    assign limb_112_1021 = tmp_workload_top_int_65__301_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_112_1022 = tmp_workload_top_int_65__303_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1023Core rtlzz_owner_1023(.a(32'(rtlzz_pipe_1021_s14)), .b(32'(limb_112_1022)), .cin(1'h0), .value(limb_112_1023));
    assign limb_112_1024 = limb_112_1023[31:0]; // decl: <none>; prim: <none>
    assign limb_112_1025 = limb_112_1023[32]; // decl: <none>; prim: <none>
    assign limb_112_1026 = tmp_workload_top_int_65__301_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_112_1027 = tmp_workload_top_int_65__303_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1028Core rtlzz_owner_1028(.a(32'(rtlzz_pipe_1026_s14)), .b(32'(limb_112_1027)), .cin(limb_112_1025), .value(limb_112_1028));
    assign limb_112_1029 = limb_112_1028[31:0]; // decl: <none>; prim: <none>
    assign limb_112_1030 = limb_112_1028[32]; // decl: <none>; prim: <none>
    assign limb_112_1031 = tmp_workload_top_int_65__301_v0[64]; // decl: <none>; prim: <none>
    assign limb_112_1032 = tmp_workload_top_int_65__303_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1033Core rtlzz_owner_1033(.a(1'(rtlzz_pipe_1031_s14)), .b(1'(limb_112_1032)), .cin(limb_112_1030), .value(limb_112_1033[0:0]));
    assign limb_112_1033[1:1] = '0;
    assign limb_112_1034 = limb_112_1033[0]; // decl: <none>; prim: <none>
    assign limb_112_1035 = {limb_112_1034, limb_112_1029, limb_112_1024}; // decl: <none>; prim: <none>
    assign limb_114_1036 = s8_norm_add_188_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_114_1037 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_114_1038 = (~limb_114_1037); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1039Core rtlzz_owner_1039(.a(32'(limb_114_1036)), .b(32'(limb_114_1038)), .cin(1'h1), .value(limb_114_1039));
    assign limb_114_1040 = limb_114_1039[31:0]; // decl: <none>; prim: <none>
    assign limb_114_1041 = limb_114_1039[32]; // decl: <none>; prim: <none>
    assign limb_114_1042 = s8_norm_add_188_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_114_1043 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_114_1044 = (~limb_114_1043); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1045Core rtlzz_owner_1045(.a(32'(limb_114_1042)), .b(32'(limb_114_1044)), .cin(limb_114_1041), .value(limb_114_1045));
    assign limb_114_1046 = limb_114_1045[31:0]; // decl: <none>; prim: <none>
    assign limb_114_1047 = limb_114_1045[32]; // decl: <none>; prim: <none>
    assign limb_114_1048 = s8_norm_add_188_v0[64]; // decl: <none>; prim: <none>
    assign limb_114_1049 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_114_1050 = (~limb_114_1049); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1051Core rtlzz_owner_1051(.a(1'(limb_114_1048)), .b(1'(limb_114_1050)), .cin(limb_114_1047), .value(limb_114_1051[0:0]));
    assign limb_114_1051[1:1] = '0;
    assign limb_114_1052 = limb_114_1051[0]; // decl: <none>; prim: <none>
    assign limb_114_1053 = {limb_114_1052, limb_114_1046, limb_114_1040}; // decl: <none>; prim: <none>
    assign limb_116_1054 = tmp_workload_top_int_65__301_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_116_1055 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1056Core rtlzz_owner_1056(.a(32'(limb_116_1054)), .b(32'(limb_116_1055)), .cin(1'h0), .value(limb_116_1056));
    assign limb_116_1057 = limb_116_1056[31:0]; // decl: <none>; prim: <none>
    assign limb_116_1058 = limb_116_1056[32]; // decl: <none>; prim: <none>
    assign limb_116_1059 = tmp_workload_top_int_65__301_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_116_1060 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1061Core rtlzz_owner_1061(.a(32'(limb_116_1059)), .b(32'(limb_116_1060)), .cin(limb_116_1058), .value(limb_116_1061));
    assign limb_116_1062 = limb_116_1061[31:0]; // decl: <none>; prim: <none>
    assign limb_116_1063 = limb_116_1061[32]; // decl: <none>; prim: <none>
    assign limb_116_1064 = tmp_workload_top_int_65__301_v0[64]; // decl: <none>; prim: <none>
    assign limb_116_1065 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1066Core rtlzz_owner_1066(.a(1'(limb_116_1064)), .b(1'(limb_116_1065)), .cin(limb_116_1063), .value(limb_116_1066[0:0]));
    assign limb_116_1066[1:1] = '0;
    assign limb_116_1067 = limb_116_1066[0]; // decl: <none>; prim: <none>
    assign limb_116_1068 = {limb_116_1067, limb_116_1062, limb_116_1057}; // decl: <none>; prim: <none>
    assign limb_117_1069 = s8_norm_add_196_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_117_1070 = tmp_workload_top_int_65__303_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_117_1071 = (~limb_117_1070); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1072Core rtlzz_owner_1072(.a(32'(rtlzz_pipe_1069_s14)), .b(32'(limb_117_1071)), .cin(1'h1), .value(limb_117_1072));
    assign limb_117_1073 = limb_117_1072[31:0]; // decl: <none>; prim: <none>
    assign limb_117_1074 = limb_117_1072[32]; // decl: <none>; prim: <none>
    assign limb_117_1075 = s8_norm_add_196_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_117_1076 = tmp_workload_top_int_65__303_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_117_1077 = (~limb_117_1076); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1078Core rtlzz_owner_1078(.a(32'(rtlzz_pipe_1075_s14)), .b(32'(limb_117_1077)), .cin(limb_117_1074), .value(limb_117_1078));
    assign limb_117_1079 = limb_117_1078[31:0]; // decl: <none>; prim: <none>
    assign limb_117_1080 = limb_117_1078[32]; // decl: <none>; prim: <none>
    assign limb_117_1081 = s8_norm_add_196_v0[64]; // decl: <none>; prim: <none>
    assign limb_117_1082 = tmp_workload_top_int_65__303_v0[64]; // decl: <none>; prim: <none>
    assign limb_117_1083 = (~limb_117_1082); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1084Core rtlzz_owner_1084(.a(1'(rtlzz_pipe_1081_s14)), .b(1'(limb_117_1083)), .cin(limb_117_1080), .value(limb_117_1084[0:0]));
    assign limb_117_1084[1:1] = '0;
    assign limb_117_1085 = limb_117_1084[0]; // decl: <none>; prim: <none>
    assign limb_117_1086 = {limb_117_1085, limb_117_1079, limb_117_1073}; // decl: <none>; prim: <none>
    assign limb_119_1087 = s8_norm_sub_198_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_119_1088 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_119_1089 = (~limb_119_1088); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1090Core rtlzz_owner_1090(.a(32'(limb_119_1087)), .b(32'(limb_119_1089)), .cin(1'h1), .value(limb_119_1090));
    assign limb_119_1091 = limb_119_1090[31:0]; // decl: <none>; prim: <none>
    assign limb_119_1092 = limb_119_1090[32]; // decl: <none>; prim: <none>
    assign limb_119_1093 = s8_norm_sub_198_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_119_1094 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_119_1095 = (~limb_119_1094); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1096Core rtlzz_owner_1096(.a(32'(rtlzz_pipe_1093_s15)), .b(32'(limb_119_1095)), .cin(rtlzz_pipe_1092_s15), .value(limb_119_1096));
    assign limb_119_1097 = limb_119_1096[31:0]; // decl: <none>; prim: <none>
    assign limb_119_1098 = limb_119_1096[32]; // decl: <none>; prim: <none>
    assign limb_119_1099 = s8_norm_sub_198_v0[64]; // decl: <none>; prim: <none>
    assign limb_119_1100 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_119_1101 = (~limb_119_1100); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1102Core rtlzz_owner_1102(.a(1'(rtlzz_pipe_1099_s15)), .b(1'(limb_119_1101)), .cin(limb_119_1098), .value(limb_119_1102[0:0]));
    assign limb_119_1102[1:1] = '0;
    assign limb_119_1103 = limb_119_1102[0]; // decl: <none>; prim: <none>
    assign limb_119_1104 = {limb_119_1103, limb_119_1097, rtlzz_pipe_1091_s15}; // decl: <none>; prim: <none>
    assign limb_123_1105 = tmp_workload_top_int_65__334_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_123_1106 = tmp_workload_top_int_65__336_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1107Core rtlzz_owner_1107(.a(32'(rtlzz_pipe_1105_s14)), .b(32'(limb_123_1106)), .cin(1'h0), .value(limb_123_1107));
    assign limb_123_1108 = limb_123_1107[31:0]; // decl: <none>; prim: <none>
    assign limb_123_1109 = limb_123_1107[32]; // decl: <none>; prim: <none>
    assign limb_123_1110 = tmp_workload_top_int_65__334_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_123_1111 = tmp_workload_top_int_65__336_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1112Core rtlzz_owner_1112(.a(32'(rtlzz_pipe_1110_s14)), .b(32'(limb_123_1111)), .cin(limb_123_1109), .value(limb_123_1112));
    assign limb_123_1113 = limb_123_1112[31:0]; // decl: <none>; prim: <none>
    assign limb_123_1114 = limb_123_1112[32]; // decl: <none>; prim: <none>
    assign limb_123_1115 = tmp_workload_top_int_65__334_v0[64]; // decl: <none>; prim: <none>
    assign limb_123_1116 = tmp_workload_top_int_65__336_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1117Core rtlzz_owner_1117(.a(1'(rtlzz_pipe_1115_s14)), .b(1'(limb_123_1116)), .cin(limb_123_1114), .value(limb_123_1117[0:0]));
    assign limb_123_1117[1:1] = '0;
    assign limb_123_1118 = limb_123_1117[0]; // decl: <none>; prim: <none>
    assign limb_123_1119 = {limb_123_1118, limb_123_1113, limb_123_1108}; // decl: <none>; prim: <none>
    assign limb_125_1120 = s8_norm_add_208_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_125_1121 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_125_1122 = (~limb_125_1121); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1123Core rtlzz_owner_1123(.a(32'(limb_125_1120)), .b(32'(limb_125_1122)), .cin(1'h1), .value(limb_125_1123));
    assign limb_125_1124 = limb_125_1123[31:0]; // decl: <none>; prim: <none>
    assign limb_125_1125 = limb_125_1123[32]; // decl: <none>; prim: <none>
    assign limb_125_1126 = s8_norm_add_208_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_125_1127 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_125_1128 = (~limb_125_1127); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1129Core rtlzz_owner_1129(.a(32'(limb_125_1126)), .b(32'(limb_125_1128)), .cin(limb_125_1125), .value(limb_125_1129[31:0]));
    assign limb_125_1129[32:32] = '0;
    assign limb_125_1130 = limb_125_1129[31:0]; // decl: <none>; prim: <none>
    assign limb_125_1131 = limb_125_1129[32]; // decl: <none>; prim: <none>
    assign limb_125_1132 = s8_norm_add_208_v0[64]; // decl: <none>; prim: <none>
    assign limb_125_1133 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_125_1134 = (~limb_125_1133); // decl: <none>; prim: <none>
    assign limb_125_1135 = 2'((({1'h0, limb_125_1132}) + ({1'h0, limb_125_1134}) + ({1'h0, limb_125_1131}))); // decl: <none>; prim: <none>
    assign limb_125_1136 = limb_125_1135[0]; // decl: <none>; prim: <none>
    assign limb_125_1137 = {limb_125_1136, limb_125_1130, limb_125_1124}; // decl: <none>; prim: <none>
    assign limb_127_1138 = tmp_workload_top_int_65__334_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_127_1139 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1140Core rtlzz_owner_1140(.a(32'(limb_127_1138)), .b(32'(limb_127_1139)), .cin(1'h0), .value(limb_127_1140));
    assign limb_127_1141 = limb_127_1140[31:0]; // decl: <none>; prim: <none>
    assign limb_127_1142 = limb_127_1140[32]; // decl: <none>; prim: <none>
    assign limb_127_1143 = tmp_workload_top_int_65__334_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_127_1144 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1145Core rtlzz_owner_1145(.a(32'(limb_127_1143)), .b(32'(limb_127_1144)), .cin(limb_127_1142), .value(limb_127_1145));
    assign limb_127_1146 = limb_127_1145[31:0]; // decl: <none>; prim: <none>
    assign limb_127_1147 = limb_127_1145[32]; // decl: <none>; prim: <none>
    assign limb_127_1148 = tmp_workload_top_int_65__334_v0[64]; // decl: <none>; prim: <none>
    assign limb_127_1149 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1150Core rtlzz_owner_1150(.a(1'(rtlzz_pipe_1148_s12)), .b(1'(limb_127_1149)), .cin(rtlzz_pipe_1147_s12), .value(limb_127_1150[0:0]));
    assign limb_127_1150[1:1] = '0;
    assign limb_127_1151 = limb_127_1150[0]; // decl: <none>; prim: <none>
    assign limb_127_1152 = {limb_127_1151, rtlzz_pipe_1146_s12, rtlzz_pipe_1141_s12}; // decl: <none>; prim: <none>
    assign limb_128_1153 = s8_norm_add_216_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_128_1154 = tmp_workload_top_int_65__336_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_128_1155 = (~rtlzz_pipe_1154_s15); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1156Core rtlzz_owner_1156(.a(32'(rtlzz_pipe_1153_s15)), .b(32'(limb_128_1155)), .cin(1'h1), .value(limb_128_1156));
    assign limb_128_1157 = limb_128_1156[31:0]; // decl: <none>; prim: <none>
    assign limb_128_1158 = limb_128_1156[32]; // decl: <none>; prim: <none>
    assign limb_128_1159 = s8_norm_add_216_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_128_1160 = tmp_workload_top_int_65__336_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_128_1161 = (~limb_128_1160); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1162Core rtlzz_owner_1162(.a(32'(rtlzz_pipe_1159_s15)), .b(32'(rtlzz_pipe_1161_s15)), .cin(limb_128_1158), .value(limb_128_1162));
    assign limb_128_1163 = limb_128_1162[31:0]; // decl: <none>; prim: <none>
    assign limb_128_1164 = limb_128_1162[32]; // decl: <none>; prim: <none>
    assign limb_128_1165 = s8_norm_add_216_v0[64]; // decl: <none>; prim: <none>
    assign limb_128_1166 = tmp_workload_top_int_65__336_v0[64]; // decl: <none>; prim: <none>
    assign limb_128_1167 = (~limb_128_1166); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1168Core rtlzz_owner_1168(.a(1'(rtlzz_pipe_1165_s15)), .b(1'(rtlzz_pipe_1167_s15)), .cin(limb_128_1164), .value(limb_128_1168[0:0]));
    assign limb_128_1168[1:1] = '0;
    assign limb_128_1169 = limb_128_1168[0]; // decl: <none>; prim: <none>
    assign limb_128_1170 = {limb_128_1169, limb_128_1163, limb_128_1157}; // decl: <none>; prim: <none>
    assign limb_130_1171 = s8_norm_sub_218_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_130_1172 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_130_1173 = (~limb_130_1172); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1174Core rtlzz_owner_1174(.a(32'(limb_130_1171)), .b(32'(limb_130_1173)), .cin(1'h1), .value(limb_130_1174));
    assign limb_130_1175 = limb_130_1174[31:0]; // decl: <none>; prim: <none>
    assign limb_130_1176 = limb_130_1174[32]; // decl: <none>; prim: <none>
    assign limb_130_1177 = s8_norm_sub_218_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_130_1178 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_130_1179 = (~limb_130_1178); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1180Core rtlzz_owner_1180(.a(32'(limb_130_1177)), .b(32'(limb_130_1179)), .cin(limb_130_1176), .value(limb_130_1180[31:0]));
    assign limb_130_1180[32:32] = '0;
    assign limb_130_1181 = limb_130_1180[31:0]; // decl: <none>; prim: <none>
    assign limb_130_1182 = limb_130_1180[32]; // decl: <none>; prim: <none>
    assign limb_130_1183 = s8_norm_sub_218_v0[64]; // decl: <none>; prim: <none>
    assign limb_130_1184 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_130_1185 = (~limb_130_1184); // decl: <none>; prim: <none>
    assign limb_130_1186 = 2'((({1'h0, limb_130_1183}) + ({1'h0, limb_130_1185}) + ({1'h0, limb_130_1182}))); // decl: <none>; prim: <none>
    assign limb_130_1187 = limb_130_1186[0]; // decl: <none>; prim: <none>
    assign limb_130_1188 = {limb_130_1187, limb_130_1181, limb_130_1175}; // decl: <none>; prim: <none>
    assign limb_142_1189 = tmp_workload_top_int_129__385_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1190 = n76_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1191 = (~limb_142_1190); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1192Core rtlzz_owner_1192(.a(32'(limb_142_1189)), .b(32'(rtlzz_pipe_1191_s15)), .cin(1'h1), .value(limb_142_1192));
    assign limb_142_1193 = limb_142_1192[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1194 = limb_142_1192[32]; // decl: <none>; prim: <none>
    assign limb_142_1195 = tmp_workload_top_int_129__385_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_142_1196 = n76_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_142_1197 = (~limb_142_1196); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1198Core rtlzz_owner_1198(.a(32'(limb_142_1195)), .b(32'(rtlzz_pipe_1197_s15)), .cin(limb_142_1194), .value(limb_142_1198));
    assign limb_142_1199 = limb_142_1198[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1200 = limb_142_1198[32]; // decl: <none>; prim: <none>
    assign limb_142_1201 = tmp_workload_top_int_129__385_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_142_1202 = n76_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_142_1203 = (~limb_142_1202); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1204Core rtlzz_owner_1204(.a(32'(limb_142_1201)), .b(32'(rtlzz_pipe_1203_s15)), .cin(limb_142_1200), .value(limb_142_1204));
    assign limb_142_1205 = limb_142_1204[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1206 = limb_142_1204[32]; // decl: <none>; prim: <none>
    assign limb_142_1207 = tmp_workload_top_int_129__385_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_142_1208 = n76_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_142_1209 = (~limb_142_1208); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1210Core rtlzz_owner_1210(.a(32'(limb_142_1207)), .b(32'(rtlzz_pipe_1209_s15)), .cin(limb_142_1206), .value(limb_142_1210));
    assign limb_142_1211 = limb_142_1210[31:0]; // decl: <none>; prim: <none>
    assign limb_142_1212 = limb_142_1210[32]; // decl: <none>; prim: <none>
    assign limb_142_1213 = tmp_workload_top_int_129__385_v0[128]; // decl: <none>; prim: <none>
    assign limb_142_1214 = n76_v0[128]; // decl: <none>; prim: <none>
    assign limb_142_1215 = (~limb_142_1214); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1216Core rtlzz_owner_1216(.a(1'(limb_142_1213)), .b(1'(rtlzz_pipe_1215_s15)), .cin(limb_142_1212), .value(limb_142_1216[0:0]));
    assign limb_142_1216[1:1] = '0;
    assign limb_142_1217 = limb_142_1216[0]; // decl: <none>; prim: <none>
    assign limb_142_1218 = {limb_142_1217, limb_142_1211, limb_142_1205, limb_142_1199, limb_142_1193}; // decl: <none>; prim: <none>
    assign limb_144_1219 = s8_norm_sub_240_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_144_1220 = 32'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_144_1221 = (~limb_144_1220); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1222Core rtlzz_owner_1222(.a(32'(limb_144_1219)), .b(32'(limb_144_1221)), .cin(1'h1), .value(limb_144_1222));
    assign limb_144_1223 = limb_144_1222[31:0]; // decl: <none>; prim: <none>
    assign limb_144_1224 = limb_144_1222[32]; // decl: <none>; prim: <none>
    assign limb_144_1225 = s8_norm_sub_240_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_144_1226 = 32'((129'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_144_1227 = (~limb_144_1226); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1228Core rtlzz_owner_1228(.a(32'(limb_144_1225)), .b(32'(limb_144_1227)), .cin(limb_144_1224), .value(limb_144_1228));
    assign limb_144_1229 = limb_144_1228[31:0]; // decl: <none>; prim: <none>
    assign limb_144_1230 = limb_144_1228[32]; // decl: <none>; prim: <none>
    assign limb_144_1231 = s8_norm_sub_240_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_144_1232 = 32'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_144_1233 = (~limb_144_1232); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1234Core rtlzz_owner_1234(.a(32'(limb_144_1231)), .b(32'(limb_144_1233)), .cin(limb_144_1230), .value(limb_144_1234[0:0]));
    assign limb_144_1234[32:1] = '0;
    assign limb_144_1235 = limb_144_1234[31:0]; // decl: <none>; prim: <none>
    assign limb_144_1236 = limb_144_1234[32]; // decl: <none>; prim: <none>
    assign limb_144_1237 = s8_norm_sub_240_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_144_1238 = 32'((129'hffffffff00000001) >> 96); // decl: <none>; prim: <none>
    assign limb_144_1239 = (~limb_144_1238); // decl: <none>; prim: <none>
    assign limb_144_1240 = 33'((({1'h0, limb_144_1237}) + ({1'h0, limb_144_1239}) + ({32'h0, limb_144_1236}))); // decl: <none>; prim: <none>
    assign limb_144_1241 = limb_144_1240[31:0]; // decl: <none>; prim: <none>
    assign limb_144_1242 = limb_144_1240[32]; // decl: <none>; prim: <none>
    assign limb_144_1243 = s8_norm_sub_240_v0[128]; // decl: <none>; prim: <none>
    assign limb_144_1244 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_144_1245 = (~limb_144_1244); // decl: <none>; prim: <none>
    assign limb_144_1246 = 2'((({1'h0, limb_144_1243}) + ({1'h0, limb_144_1245}) + ({1'h0, limb_144_1242}))); // decl: <none>; prim: <none>
    assign limb_144_1247 = limb_144_1246[0]; // decl: <none>; prim: <none>
    assign limb_144_1248 = {limb_144_1247, limb_144_1241, limb_144_1235, limb_144_1229, limb_144_1223}; // decl: <none>; prim: <none>
    assign limb_148_1249 = tmp_workload_top_int_65__398_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_148_1250 = tmp_workload_top_int_65__400_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1251Core rtlzz_owner_1251(.a(32'(limb_148_1249)), .b(32'(limb_148_1250)), .cin(1'h0), .value(limb_148_1251));
    assign limb_148_1252 = limb_148_1251[31:0]; // decl: <none>; prim: <none>
    assign limb_148_1253 = limb_148_1251[32]; // decl: <none>; prim: <none>
    assign limb_148_1254 = tmp_workload_top_int_65__398_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_148_1255 = tmp_workload_top_int_65__400_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1256Core rtlzz_owner_1256(.a(32'(limb_148_1254)), .b(32'(limb_148_1255)), .cin(limb_148_1253), .value(limb_148_1256));
    assign limb_148_1257 = limb_148_1256[31:0]; // decl: <none>; prim: <none>
    assign limb_148_1258 = limb_148_1256[32]; // decl: <none>; prim: <none>
    assign limb_148_1259 = tmp_workload_top_int_65__398_v0[64]; // decl: <none>; prim: <none>
    assign limb_148_1260 = tmp_workload_top_int_65__400_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1261Core rtlzz_owner_1261(.a(1'(limb_148_1259)), .b(1'(limb_148_1260)), .cin(limb_148_1258), .value(limb_148_1261[0:0]));
    assign limb_148_1261[1:1] = '0;
    assign limb_148_1262 = limb_148_1261[0]; // decl: <none>; prim: <none>
    assign limb_148_1263 = {limb_148_1262, limb_148_1257, limb_148_1252}; // decl: <none>; prim: <none>
    assign limb_150_1264 = s8_norm_add_249_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_150_1265 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_150_1266 = (~limb_150_1265); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1267Core rtlzz_owner_1267(.a(32'(limb_150_1264)), .b(32'(limb_150_1266)), .cin(1'h1), .value(limb_150_1267));
    assign limb_150_1268 = limb_150_1267[31:0]; // decl: <none>; prim: <none>
    assign limb_150_1269 = limb_150_1267[32]; // decl: <none>; prim: <none>
    assign limb_150_1270 = s8_norm_add_249_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_150_1271 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_150_1272 = (~limb_150_1271); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1273Core rtlzz_owner_1273(.a(32'(limb_150_1270)), .b(32'(limb_150_1272)), .cin(limb_150_1269), .value(limb_150_1273[31:0]));
    assign limb_150_1273[32:32] = '0;
    assign limb_150_1274 = limb_150_1273[31:0]; // decl: <none>; prim: <none>
    assign limb_150_1275 = limb_150_1273[32]; // decl: <none>; prim: <none>
    assign limb_150_1276 = s8_norm_add_249_v0[64]; // decl: <none>; prim: <none>
    assign limb_150_1277 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_150_1278 = (~limb_150_1277); // decl: <none>; prim: <none>
    assign limb_150_1279 = 2'((({1'h0, limb_150_1276}) + ({1'h0, limb_150_1278}) + ({1'h0, limb_150_1275}))); // decl: <none>; prim: <none>
    assign limb_150_1280 = limb_150_1279[0]; // decl: <none>; prim: <none>
    assign limb_150_1281 = {limb_150_1280, limb_150_1274, limb_150_1268}; // decl: <none>; prim: <none>
    assign limb_152_1282 = tmp_workload_top_int_65__398_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_152_1283 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1284Core rtlzz_owner_1284(.a(32'(limb_152_1282)), .b(32'(limb_152_1283)), .cin(1'h0), .value(limb_152_1284));
    assign limb_152_1285 = limb_152_1284[31:0]; // decl: <none>; prim: <none>
    assign limb_152_1286 = limb_152_1284[32]; // decl: <none>; prim: <none>
    assign limb_152_1287 = tmp_workload_top_int_65__398_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_152_1288 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1289Core rtlzz_owner_1289(.a(32'(limb_152_1287)), .b(32'(limb_152_1288)), .cin(limb_152_1286), .value(limb_152_1289));
    assign limb_152_1290 = limb_152_1289[31:0]; // decl: <none>; prim: <none>
    assign limb_152_1291 = limb_152_1289[32]; // decl: <none>; prim: <none>
    assign limb_152_1292 = tmp_workload_top_int_65__398_v0[64]; // decl: <none>; prim: <none>
    assign limb_152_1293 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1294Core rtlzz_owner_1294(.a(1'(limb_152_1292)), .b(1'(limb_152_1293)), .cin(limb_152_1291), .value(limb_152_1294[0:0]));
    assign limb_152_1294[1:1] = '0;
    assign limb_152_1295 = limb_152_1294[0]; // decl: <none>; prim: <none>
    assign limb_152_1296 = {limb_152_1295, limb_152_1290, limb_152_1285}; // decl: <none>; prim: <none>
    assign limb_153_1297 = s8_norm_add_257_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_153_1298 = tmp_workload_top_int_65__400_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_153_1299 = (~limb_153_1298); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1300Core rtlzz_owner_1300(.a(32'(limb_153_1297)), .b(32'(limb_153_1299)), .cin(1'h1), .value(limb_153_1300));
    assign limb_153_1301 = limb_153_1300[31:0]; // decl: <none>; prim: <none>
    assign limb_153_1302 = limb_153_1300[32]; // decl: <none>; prim: <none>
    assign limb_153_1303 = s8_norm_add_257_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_153_1304 = tmp_workload_top_int_65__400_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_153_1305 = (~limb_153_1304); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1306Core rtlzz_owner_1306(.a(32'(limb_153_1303)), .b(32'(limb_153_1305)), .cin(limb_153_1302), .value(limb_153_1306));
    assign limb_153_1307 = limb_153_1306[31:0]; // decl: <none>; prim: <none>
    assign limb_153_1308 = limb_153_1306[32]; // decl: <none>; prim: <none>
    assign limb_153_1309 = s8_norm_add_257_v0[64]; // decl: <none>; prim: <none>
    assign limb_153_1310 = tmp_workload_top_int_65__400_v0[64]; // decl: <none>; prim: <none>
    assign limb_153_1311 = (~limb_153_1310); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1312Core rtlzz_owner_1312(.a(1'(limb_153_1309)), .b(1'(limb_153_1311)), .cin(limb_153_1308), .value(limb_153_1312[0:0]));
    assign limb_153_1312[1:1] = '0;
    assign limb_153_1313 = limb_153_1312[0]; // decl: <none>; prim: <none>
    assign limb_153_1314 = {limb_153_1313, limb_153_1307, limb_153_1301}; // decl: <none>; prim: <none>
    assign limb_155_1315 = s8_norm_sub_259_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_155_1316 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_155_1317 = (~limb_155_1316); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1318Core rtlzz_owner_1318(.a(32'(limb_155_1315)), .b(32'(limb_155_1317)), .cin(1'h1), .value(limb_155_1318));
    assign limb_155_1319 = limb_155_1318[31:0]; // decl: <none>; prim: <none>
    assign limb_155_1320 = limb_155_1318[32]; // decl: <none>; prim: <none>
    assign limb_155_1321 = s8_norm_sub_259_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_155_1322 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_155_1323 = (~limb_155_1322); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1324Core rtlzz_owner_1324(.a(32'(limb_155_1321)), .b(32'(limb_155_1323)), .cin(limb_155_1320), .value(limb_155_1324[31:0]));
    assign limb_155_1324[32:32] = '0;
    assign limb_155_1325 = limb_155_1324[31:0]; // decl: <none>; prim: <none>
    assign limb_155_1326 = limb_155_1324[32]; // decl: <none>; prim: <none>
    assign limb_155_1327 = s8_norm_sub_259_v0[64]; // decl: <none>; prim: <none>
    assign limb_155_1328 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_155_1329 = (~limb_155_1328); // decl: <none>; prim: <none>
    assign limb_155_1330 = 2'((({1'h0, limb_155_1327}) + ({1'h0, limb_155_1329}) + ({1'h0, limb_155_1326}))); // decl: <none>; prim: <none>
    assign limb_155_1331 = limb_155_1330[0]; // decl: <none>; prim: <none>
    assign limb_155_1332 = {limb_155_1331, limb_155_1325, limb_155_1319}; // decl: <none>; prim: <none>
    assign limb_167_1333 = tmp_workload_top_int_129__449_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1334 = n90_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1335 = (~limb_167_1334); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1336Core rtlzz_owner_1336(.a(32'(limb_167_1333)), .b(32'(limb_167_1335)), .cin(1'h1), .value(limb_167_1336));
    assign limb_167_1337 = limb_167_1336[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1338 = limb_167_1336[32]; // decl: <none>; prim: <none>
    assign limb_167_1339 = tmp_workload_top_int_129__449_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_167_1340 = n90_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_167_1341 = (~limb_167_1340); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1342Core rtlzz_owner_1342(.a(32'(limb_167_1339)), .b(32'(limb_167_1341)), .cin(limb_167_1338), .value(limb_167_1342));
    assign limb_167_1343 = limb_167_1342[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1344 = limb_167_1342[32]; // decl: <none>; prim: <none>
    assign limb_167_1345 = tmp_workload_top_int_129__449_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_167_1346 = n90_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_167_1347 = (~limb_167_1346); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1348Core rtlzz_owner_1348(.a(32'(limb_167_1345)), .b(32'(limb_167_1347)), .cin(limb_167_1344), .value(limb_167_1348));
    assign limb_167_1349 = limb_167_1348[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1350 = limb_167_1348[32]; // decl: <none>; prim: <none>
    assign limb_167_1351 = tmp_workload_top_int_129__449_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_167_1352 = n90_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_167_1353 = (~limb_167_1352); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1354Core rtlzz_owner_1354(.a(32'(limb_167_1351)), .b(32'(limb_167_1353)), .cin(limb_167_1350), .value(limb_167_1354));
    assign limb_167_1355 = limb_167_1354[31:0]; // decl: <none>; prim: <none>
    assign limb_167_1356 = limb_167_1354[32]; // decl: <none>; prim: <none>
    assign limb_167_1357 = tmp_workload_top_int_129__449_v0[128]; // decl: <none>; prim: <none>
    assign limb_167_1358 = n90_v0[128]; // decl: <none>; prim: <none>
    assign limb_167_1359 = (~limb_167_1358); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1360Core rtlzz_owner_1360(.a(1'(limb_167_1357)), .b(1'(limb_167_1359)), .cin(limb_167_1356), .value(limb_167_1360[0:0]));
    assign limb_167_1360[1:1] = '0;
    assign limb_167_1361 = limb_167_1360[0]; // decl: <none>; prim: <none>
    assign limb_167_1362 = {limb_167_1361, limb_167_1355, limb_167_1349, limb_167_1343, limb_167_1337}; // decl: <none>; prim: <none>
    assign limb_169_1363 = s8_norm_sub_281_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_169_1364 = 32'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_169_1365 = (~limb_169_1364); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1366Core rtlzz_owner_1366(.a(32'(limb_169_1363)), .b(32'(limb_169_1365)), .cin(1'h1), .value(limb_169_1366));
    assign limb_169_1367 = limb_169_1366[31:0]; // decl: <none>; prim: <none>
    assign limb_169_1368 = limb_169_1366[32]; // decl: <none>; prim: <none>
    assign limb_169_1369 = s8_norm_sub_281_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_169_1370 = 32'((129'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_169_1371 = (~limb_169_1370); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1372Core rtlzz_owner_1372(.a(32'(limb_169_1369)), .b(32'(limb_169_1371)), .cin(limb_169_1368), .value(limb_169_1372));
    assign limb_169_1373 = limb_169_1372[31:0]; // decl: <none>; prim: <none>
    assign limb_169_1374 = limb_169_1372[32]; // decl: <none>; prim: <none>
    assign limb_169_1375 = s8_norm_sub_281_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_169_1376 = 32'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_169_1377 = (~limb_169_1376); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1378Core rtlzz_owner_1378(.a(32'(limb_169_1375)), .b(32'(limb_169_1377)), .cin(limb_169_1374), .value(limb_169_1378[0:0]));
    assign limb_169_1378[32:1] = '0;
    assign limb_169_1379 = limb_169_1378[31:0]; // decl: <none>; prim: <none>
    assign limb_169_1380 = limb_169_1378[32]; // decl: <none>; prim: <none>
    assign limb_169_1381 = s8_norm_sub_281_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_169_1382 = 32'((129'hffffffff00000001) >> 96); // decl: <none>; prim: <none>
    assign limb_169_1383 = (~limb_169_1382); // decl: <none>; prim: <none>
    assign limb_169_1384 = 33'((({1'h0, limb_169_1381}) + ({1'h0, limb_169_1383}) + ({32'h0, limb_169_1380}))); // decl: <none>; prim: <none>
    assign limb_169_1385 = limb_169_1384[31:0]; // decl: <none>; prim: <none>
    assign limb_169_1386 = limb_169_1384[32]; // decl: <none>; prim: <none>
    assign limb_169_1387 = s8_norm_sub_281_v0[128]; // decl: <none>; prim: <none>
    assign limb_169_1388 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_169_1389 = (~limb_169_1388); // decl: <none>; prim: <none>
    assign limb_169_1390 = 2'((({1'h0, limb_169_1387}) + ({1'h0, limb_169_1389}) + ({1'h0, limb_169_1386}))); // decl: <none>; prim: <none>
    assign limb_169_1391 = limb_169_1390[0]; // decl: <none>; prim: <none>
    assign limb_169_1392 = {limb_169_1391, limb_169_1385, limb_169_1379, limb_169_1373, limb_169_1367}; // decl: <none>; prim: <none>
    assign limb_173_1393 = tmp_workload_top_int_65__462_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_173_1394 = tmp_workload_top_int_65__464_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1395Core rtlzz_owner_1395(.a(32'(limb_173_1393)), .b(32'(limb_173_1394)), .cin(1'h0), .value(limb_173_1395));
    assign limb_173_1396 = limb_173_1395[31:0]; // decl: <none>; prim: <none>
    assign limb_173_1397 = limb_173_1395[32]; // decl: <none>; prim: <none>
    assign limb_173_1398 = tmp_workload_top_int_65__462_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_173_1399 = tmp_workload_top_int_65__464_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1400Core rtlzz_owner_1400(.a(32'(limb_173_1398)), .b(32'(limb_173_1399)), .cin(limb_173_1397), .value(limb_173_1400));
    assign limb_173_1401 = limb_173_1400[31:0]; // decl: <none>; prim: <none>
    assign limb_173_1402 = limb_173_1400[32]; // decl: <none>; prim: <none>
    assign limb_173_1403 = tmp_workload_top_int_65__462_v0[64]; // decl: <none>; prim: <none>
    assign limb_173_1404 = tmp_workload_top_int_65__464_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1405Core rtlzz_owner_1405(.a(1'(limb_173_1403)), .b(1'(limb_173_1404)), .cin(limb_173_1402), .value(limb_173_1405[0:0]));
    assign limb_173_1405[1:1] = '0;
    assign limb_173_1406 = limb_173_1405[0]; // decl: <none>; prim: <none>
    assign limb_173_1407 = {limb_173_1406, limb_173_1401, limb_173_1396}; // decl: <none>; prim: <none>
    assign limb_175_1408 = s8_norm_add_290_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_175_1409 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_175_1410 = (~limb_175_1409); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1411Core rtlzz_owner_1411(.a(32'(limb_175_1408)), .b(32'(limb_175_1410)), .cin(1'h1), .value(limb_175_1411));
    assign limb_175_1412 = limb_175_1411[31:0]; // decl: <none>; prim: <none>
    assign limb_175_1413 = limb_175_1411[32]; // decl: <none>; prim: <none>
    assign limb_175_1414 = s8_norm_add_290_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_175_1415 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_175_1416 = (~limb_175_1415); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1417Core rtlzz_owner_1417(.a(32'(limb_175_1414)), .b(32'(limb_175_1416)), .cin(limb_175_1413), .value(limb_175_1417[31:0]));
    assign limb_175_1417[32:32] = '0;
    assign limb_175_1418 = limb_175_1417[31:0]; // decl: <none>; prim: <none>
    assign limb_175_1419 = limb_175_1417[32]; // decl: <none>; prim: <none>
    assign limb_175_1420 = s8_norm_add_290_v0[64]; // decl: <none>; prim: <none>
    assign limb_175_1421 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_175_1422 = (~limb_175_1421); // decl: <none>; prim: <none>
    assign limb_175_1423 = 2'((({1'h0, limb_175_1420}) + ({1'h0, limb_175_1422}) + ({1'h0, limb_175_1419}))); // decl: <none>; prim: <none>
    assign limb_175_1424 = limb_175_1423[0]; // decl: <none>; prim: <none>
    assign limb_175_1425 = {limb_175_1424, limb_175_1418, limb_175_1412}; // decl: <none>; prim: <none>
    assign limb_177_1426 = tmp_workload_top_int_65__462_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_177_1427 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1428Core rtlzz_owner_1428(.a(32'(limb_177_1426)), .b(32'(limb_177_1427)), .cin(1'h0), .value(limb_177_1428));
    assign limb_177_1429 = limb_177_1428[31:0]; // decl: <none>; prim: <none>
    assign limb_177_1430 = limb_177_1428[32]; // decl: <none>; prim: <none>
    assign limb_177_1431 = tmp_workload_top_int_65__462_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_177_1432 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1433Core rtlzz_owner_1433(.a(32'(limb_177_1431)), .b(32'(limb_177_1432)), .cin(limb_177_1430), .value(limb_177_1433));
    assign limb_177_1434 = limb_177_1433[31:0]; // decl: <none>; prim: <none>
    assign limb_177_1435 = limb_177_1433[32]; // decl: <none>; prim: <none>
    assign limb_177_1436 = tmp_workload_top_int_65__462_v0[64]; // decl: <none>; prim: <none>
    assign limb_177_1437 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1438Core rtlzz_owner_1438(.a(1'(limb_177_1436)), .b(1'(limb_177_1437)), .cin(limb_177_1435), .value(limb_177_1438[0:0]));
    assign limb_177_1438[1:1] = '0;
    assign limb_177_1439 = limb_177_1438[0]; // decl: <none>; prim: <none>
    assign limb_177_1440 = {limb_177_1439, limb_177_1434, limb_177_1429}; // decl: <none>; prim: <none>
    assign limb_178_1441 = s8_norm_add_298_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_178_1442 = tmp_workload_top_int_65__464_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_178_1443 = (~limb_178_1442); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1444Core rtlzz_owner_1444(.a(32'(limb_178_1441)), .b(32'(limb_178_1443)), .cin(1'h1), .value(limb_178_1444));
    assign limb_178_1445 = limb_178_1444[31:0]; // decl: <none>; prim: <none>
    assign limb_178_1446 = limb_178_1444[32]; // decl: <none>; prim: <none>
    assign limb_178_1447 = s8_norm_add_298_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_178_1448 = tmp_workload_top_int_65__464_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_178_1449 = (~limb_178_1448); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1450Core rtlzz_owner_1450(.a(32'(limb_178_1447)), .b(32'(limb_178_1449)), .cin(limb_178_1446), .value(limb_178_1450));
    assign limb_178_1451 = limb_178_1450[31:0]; // decl: <none>; prim: <none>
    assign limb_178_1452 = limb_178_1450[32]; // decl: <none>; prim: <none>
    assign limb_178_1453 = s8_norm_add_298_v0[64]; // decl: <none>; prim: <none>
    assign limb_178_1454 = tmp_workload_top_int_65__464_v0[64]; // decl: <none>; prim: <none>
    assign limb_178_1455 = (~limb_178_1454); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1456Core rtlzz_owner_1456(.a(1'(limb_178_1453)), .b(1'(limb_178_1455)), .cin(limb_178_1452), .value(limb_178_1456[0:0]));
    assign limb_178_1456[1:1] = '0;
    assign limb_178_1457 = limb_178_1456[0]; // decl: <none>; prim: <none>
    assign limb_178_1458 = {limb_178_1457, limb_178_1451, limb_178_1445}; // decl: <none>; prim: <none>
    assign limb_180_1459 = s8_norm_sub_300_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_180_1460 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_180_1461 = (~limb_180_1460); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1462Core rtlzz_owner_1462(.a(32'(limb_180_1459)), .b(32'(limb_180_1461)), .cin(1'h1), .value(limb_180_1462));
    assign limb_180_1463 = limb_180_1462[31:0]; // decl: <none>; prim: <none>
    assign limb_180_1464 = limb_180_1462[32]; // decl: <none>; prim: <none>
    assign limb_180_1465 = s8_norm_sub_300_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_180_1466 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_180_1467 = (~limb_180_1466); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1468Core rtlzz_owner_1468(.a(32'(limb_180_1465)), .b(32'(limb_180_1467)), .cin(limb_180_1464), .value(limb_180_1468[31:0]));
    assign limb_180_1468[32:32] = '0;
    assign limb_180_1469 = limb_180_1468[31:0]; // decl: <none>; prim: <none>
    assign limb_180_1470 = limb_180_1468[32]; // decl: <none>; prim: <none>
    assign limb_180_1471 = s8_norm_sub_300_v0[64]; // decl: <none>; prim: <none>
    assign limb_180_1472 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_180_1473 = (~limb_180_1472); // decl: <none>; prim: <none>
    assign limb_180_1474 = 2'((({1'h0, rtlzz_pipe_1471_s15}) + ({1'h0, limb_180_1473}) + ({1'h0, rtlzz_pipe_1470_s15}))); // decl: <none>; prim: <none>
    assign limb_180_1475 = limb_180_1474[0]; // decl: <none>; prim: <none>
    assign limb_180_1476 = {limb_180_1475, rtlzz_pipe_1469_s15, rtlzz_pipe_1463_s15}; // decl: <none>; prim: <none>
    assign limb_192_1477 = tmp_workload_top_int_129__513_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1478 = n104_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1479 = (~limb_192_1478); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1480Core rtlzz_owner_1480(.a(32'(limb_192_1477)), .b(32'(limb_192_1479)), .cin(1'h1), .value(limb_192_1480));
    assign limb_192_1481 = limb_192_1480[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1482 = limb_192_1480[32]; // decl: <none>; prim: <none>
    assign limb_192_1483 = tmp_workload_top_int_129__513_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_192_1484 = n104_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_192_1485 = (~limb_192_1484); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1486Core rtlzz_owner_1486(.a(32'(limb_192_1483)), .b(32'(limb_192_1485)), .cin(limb_192_1482), .value(limb_192_1486));
    assign limb_192_1487 = limb_192_1486[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1488 = limb_192_1486[32]; // decl: <none>; prim: <none>
    assign limb_192_1489 = tmp_workload_top_int_129__513_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_192_1490 = n104_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_192_1491 = (~limb_192_1490); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1492Core rtlzz_owner_1492(.a(32'(limb_192_1489)), .b(32'(limb_192_1491)), .cin(limb_192_1488), .value(limb_192_1492));
    assign limb_192_1493 = limb_192_1492[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1494 = limb_192_1492[32]; // decl: <none>; prim: <none>
    assign limb_192_1495 = tmp_workload_top_int_129__513_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_192_1496 = n104_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_192_1497 = (~limb_192_1496); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1498Core rtlzz_owner_1498(.a(32'(limb_192_1495)), .b(32'(limb_192_1497)), .cin(limb_192_1494), .value(limb_192_1498));
    assign limb_192_1499 = limb_192_1498[31:0]; // decl: <none>; prim: <none>
    assign limb_192_1500 = limb_192_1498[32]; // decl: <none>; prim: <none>
    assign limb_192_1501 = tmp_workload_top_int_129__513_v0[128]; // decl: <none>; prim: <none>
    assign limb_192_1502 = n104_v0[128]; // decl: <none>; prim: <none>
    assign limb_192_1503 = (~limb_192_1502); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1504Core rtlzz_owner_1504(.a(1'(limb_192_1501)), .b(1'(limb_192_1503)), .cin(limb_192_1500), .value(limb_192_1504[0:0]));
    assign limb_192_1504[1:1] = '0;
    assign limb_192_1505 = limb_192_1504[0]; // decl: <none>; prim: <none>
    assign limb_192_1506 = {limb_192_1505, limb_192_1499, limb_192_1493, limb_192_1487, limb_192_1481}; // decl: <none>; prim: <none>
    assign limb_194_1507 = s8_norm_sub_322_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_194_1508 = 32'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_194_1509 = (~limb_194_1508); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1510Core rtlzz_owner_1510(.a(32'(limb_194_1507)), .b(32'(limb_194_1509)), .cin(1'h1), .value(limb_194_1510));
    assign limb_194_1511 = limb_194_1510[31:0]; // decl: <none>; prim: <none>
    assign limb_194_1512 = limb_194_1510[32]; // decl: <none>; prim: <none>
    assign limb_194_1513 = s8_norm_sub_322_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_194_1514 = 32'((129'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_194_1515 = (~limb_194_1514); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1516Core rtlzz_owner_1516(.a(32'(limb_194_1513)), .b(32'(limb_194_1515)), .cin(limb_194_1512), .value(limb_194_1516));
    assign limb_194_1517 = limb_194_1516[31:0]; // decl: <none>; prim: <none>
    assign limb_194_1518 = limb_194_1516[32]; // decl: <none>; prim: <none>
    assign limb_194_1519 = s8_norm_sub_322_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_194_1520 = 32'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_194_1521 = (~limb_194_1520); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1522Core rtlzz_owner_1522(.a(32'(limb_194_1519)), .b(32'(limb_194_1521)), .cin(limb_194_1518), .value(limb_194_1522[0:0]));
    assign limb_194_1522[32:1] = '0;
    assign limb_194_1523 = limb_194_1522[31:0]; // decl: <none>; prim: <none>
    assign limb_194_1524 = limb_194_1522[32]; // decl: <none>; prim: <none>
    assign limb_194_1525 = s8_norm_sub_322_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_194_1526 = 32'((129'hffffffff00000001) >> 96); // decl: <none>; prim: <none>
    assign limb_194_1527 = (~limb_194_1526); // decl: <none>; prim: <none>
    assign limb_194_1528 = 33'((({1'h0, limb_194_1525}) + ({1'h0, limb_194_1527}) + ({32'h0, limb_194_1524}))); // decl: <none>; prim: <none>
    assign limb_194_1529 = limb_194_1528[31:0]; // decl: <none>; prim: <none>
    assign limb_194_1530 = limb_194_1528[32]; // decl: <none>; prim: <none>
    assign limb_194_1531 = s8_norm_sub_322_v0[128]; // decl: <none>; prim: <none>
    assign limb_194_1532 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_194_1533 = (~limb_194_1532); // decl: <none>; prim: <none>
    assign limb_194_1534 = 2'((({1'h0, limb_194_1531}) + ({1'h0, limb_194_1533}) + ({1'h0, limb_194_1530}))); // decl: <none>; prim: <none>
    assign limb_194_1535 = limb_194_1534[0]; // decl: <none>; prim: <none>
    assign limb_194_1536 = {limb_194_1535, limb_194_1529, limb_194_1523, limb_194_1517, limb_194_1511}; // decl: <none>; prim: <none>
    assign limb_198_1537 = tmp_workload_top_int_65__526_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_198_1538 = tmp_workload_top_int_65__528_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1539Core rtlzz_owner_1539(.a(32'(limb_198_1537)), .b(32'(limb_198_1538)), .cin(1'h0), .value(limb_198_1539));
    assign limb_198_1540 = limb_198_1539[31:0]; // decl: <none>; prim: <none>
    assign limb_198_1541 = limb_198_1539[32]; // decl: <none>; prim: <none>
    assign limb_198_1542 = tmp_workload_top_int_65__526_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_198_1543 = tmp_workload_top_int_65__528_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1544Core rtlzz_owner_1544(.a(32'(limb_198_1542)), .b(32'(limb_198_1543)), .cin(limb_198_1541), .value(limb_198_1544));
    assign limb_198_1545 = limb_198_1544[31:0]; // decl: <none>; prim: <none>
    assign limb_198_1546 = limb_198_1544[32]; // decl: <none>; prim: <none>
    assign limb_198_1547 = tmp_workload_top_int_65__526_v0[64]; // decl: <none>; prim: <none>
    assign limb_198_1548 = tmp_workload_top_int_65__528_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1549Core rtlzz_owner_1549(.a(1'(limb_198_1547)), .b(1'(limb_198_1548)), .cin(limb_198_1546), .value(limb_198_1549[0:0]));
    assign limb_198_1549[1:1] = '0;
    assign limb_198_1550 = limb_198_1549[0]; // decl: <none>; prim: <none>
    assign limb_198_1551 = {limb_198_1550, limb_198_1545, limb_198_1540}; // decl: <none>; prim: <none>
    assign limb_200_1552 = s8_norm_add_331_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_200_1553 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_200_1554 = (~limb_200_1553); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1555Core rtlzz_owner_1555(.a(32'(limb_200_1552)), .b(32'(limb_200_1554)), .cin(1'h1), .value(limb_200_1555));
    assign limb_200_1556 = limb_200_1555[31:0]; // decl: <none>; prim: <none>
    assign limb_200_1557 = limb_200_1555[32]; // decl: <none>; prim: <none>
    assign limb_200_1558 = s8_norm_add_331_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_200_1559 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_200_1560 = (~limb_200_1559); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1561Core rtlzz_owner_1561(.a(32'(limb_200_1558)), .b(32'(limb_200_1560)), .cin(limb_200_1557), .value(limb_200_1561[31:0]));
    assign limb_200_1561[32:32] = '0;
    assign limb_200_1562 = limb_200_1561[31:0]; // decl: <none>; prim: <none>
    assign limb_200_1563 = limb_200_1561[32]; // decl: <none>; prim: <none>
    assign limb_200_1564 = s8_norm_add_331_v0[64]; // decl: <none>; prim: <none>
    assign limb_200_1565 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_200_1566 = (~limb_200_1565); // decl: <none>; prim: <none>
    assign limb_200_1567 = 2'((({1'h0, limb_200_1564}) + ({1'h0, limb_200_1566}) + ({1'h0, limb_200_1563}))); // decl: <none>; prim: <none>
    assign limb_200_1568 = limb_200_1567[0]; // decl: <none>; prim: <none>
    assign limb_200_1569 = {limb_200_1568, limb_200_1562, limb_200_1556}; // decl: <none>; prim: <none>
    assign limb_202_1570 = tmp_workload_top_int_65__526_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_202_1571 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1572Core rtlzz_owner_1572(.a(32'(limb_202_1570)), .b(32'(limb_202_1571)), .cin(1'h0), .value(limb_202_1572));
    assign limb_202_1573 = limb_202_1572[31:0]; // decl: <none>; prim: <none>
    assign limb_202_1574 = limb_202_1572[32]; // decl: <none>; prim: <none>
    assign limb_202_1575 = tmp_workload_top_int_65__526_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_202_1576 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1577Core rtlzz_owner_1577(.a(32'(limb_202_1575)), .b(32'(limb_202_1576)), .cin(limb_202_1574), .value(limb_202_1577));
    assign limb_202_1578 = limb_202_1577[31:0]; // decl: <none>; prim: <none>
    assign limb_202_1579 = limb_202_1577[32]; // decl: <none>; prim: <none>
    assign limb_202_1580 = tmp_workload_top_int_65__526_v0[64]; // decl: <none>; prim: <none>
    assign limb_202_1581 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1582Core rtlzz_owner_1582(.a(1'(limb_202_1580)), .b(1'(limb_202_1581)), .cin(limb_202_1579), .value(limb_202_1582[0:0]));
    assign limb_202_1582[1:1] = '0;
    assign limb_202_1583 = limb_202_1582[0]; // decl: <none>; prim: <none>
    assign limb_202_1584 = {limb_202_1583, limb_202_1578, limb_202_1573}; // decl: <none>; prim: <none>
    assign limb_203_1585 = s8_norm_add_339_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_203_1586 = tmp_workload_top_int_65__528_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_203_1587 = (~limb_203_1586); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1588Core rtlzz_owner_1588(.a(32'(limb_203_1585)), .b(32'(limb_203_1587)), .cin(1'h1), .value(limb_203_1588));
    assign limb_203_1589 = limb_203_1588[31:0]; // decl: <none>; prim: <none>
    assign limb_203_1590 = limb_203_1588[32]; // decl: <none>; prim: <none>
    assign limb_203_1591 = s8_norm_add_339_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_203_1592 = tmp_workload_top_int_65__528_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_203_1593 = (~limb_203_1592); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1594Core rtlzz_owner_1594(.a(32'(limb_203_1591)), .b(32'(limb_203_1593)), .cin(limb_203_1590), .value(limb_203_1594));
    assign limb_203_1595 = limb_203_1594[31:0]; // decl: <none>; prim: <none>
    assign limb_203_1596 = limb_203_1594[32]; // decl: <none>; prim: <none>
    assign limb_203_1597 = s8_norm_add_339_v0[64]; // decl: <none>; prim: <none>
    assign limb_203_1598 = tmp_workload_top_int_65__528_v0[64]; // decl: <none>; prim: <none>
    assign limb_203_1599 = (~limb_203_1598); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1600Core rtlzz_owner_1600(.a(1'(limb_203_1597)), .b(1'(limb_203_1599)), .cin(limb_203_1596), .value(limb_203_1600[0:0]));
    assign limb_203_1600[1:1] = '0;
    assign limb_203_1601 = limb_203_1600[0]; // decl: <none>; prim: <none>
    assign limb_203_1602 = {limb_203_1601, limb_203_1595, limb_203_1589}; // decl: <none>; prim: <none>
    assign limb_205_1603 = s8_norm_sub_341_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_205_1604 = 32'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_205_1605 = (~limb_205_1604); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1606Core rtlzz_owner_1606(.a(32'(limb_205_1603)), .b(32'(limb_205_1605)), .cin(1'h1), .value(limb_205_1606));
    assign limb_205_1607 = limb_205_1606[31:0]; // decl: <none>; prim: <none>
    assign limb_205_1608 = limb_205_1606[32]; // decl: <none>; prim: <none>
    assign limb_205_1609 = s8_norm_sub_341_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_205_1610 = 32'((65'hffffffff00000001) >> 32); // decl: <none>; prim: <none>
    assign limb_205_1611 = (~limb_205_1610); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1612Core rtlzz_owner_1612(.a(32'(limb_205_1609)), .b(32'(limb_205_1611)), .cin(limb_205_1608), .value(limb_205_1612[31:0]));
    assign limb_205_1612[32:32] = '0;
    assign limb_205_1613 = limb_205_1612[31:0]; // decl: <none>; prim: <none>
    assign limb_205_1614 = limb_205_1612[32]; // decl: <none>; prim: <none>
    assign limb_205_1615 = s8_norm_sub_341_v0[64]; // decl: <none>; prim: <none>
    assign limb_205_1616 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_205_1617 = (~limb_205_1616); // decl: <none>; prim: <none>
    assign limb_205_1618 = 2'((({1'h0, limb_205_1615}) + ({1'h0, limb_205_1617}) + ({1'h0, limb_205_1614}))); // decl: <none>; prim: <none>
    assign limb_205_1619 = limb_205_1618[0]; // decl: <none>; prim: <none>
    assign limb_205_1620 = {limb_205_1619, limb_205_1613, limb_205_1607}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_316_s1 <= 32'h0;
            rtlzz_pipe_316_s2 <= 32'h0;
            rtlzz_pipe_317_s1 <= 1'h0;
            rtlzz_pipe_318_s1 <= 32'h0;
            rtlzz_pipe_319_s1 <= 32'h0;
            rtlzz_pipe_321_s2 <= 32'h0;
            rtlzz_pipe_322_s2 <= 1'h0;
            rtlzz_pipe_323_s1 <= 1'h0;
            rtlzz_pipe_323_s2 <= 1'h0;
            rtlzz_pipe_324_s1 <= 1'h0;
            rtlzz_pipe_324_s2 <= 1'h0;
            rtlzz_pipe_11_s3 <= 65'h0;
            rtlzz_pipe_11_s4 <= 65'h0;
            rtlzz_pipe_11_s5 <= 65'h0;
            rtlzz_pipe_11_s6 <= 65'h0;
            rtlzz_pipe_11_s7 <= 65'h0;
            rtlzz_pipe_12_s4 <= 1'h1;
            rtlzz_pipe_12_s5 <= 1'h1;
            rtlzz_pipe_12_s6 <= 1'h1;
            rtlzz_pipe_12_s7 <= 1'h1;
            rtlzz_pipe_328_s3 <= 32'h0;
            rtlzz_pipe_328_s4 <= 32'h0;
            rtlzz_pipe_332_s5 <= 32'hffffffff;
            rtlzz_pipe_332_s6 <= 32'hffffffff;
            rtlzz_pipe_333_s5 <= 1'h0;
            rtlzz_pipe_334_s3 <= 32'h0;
            rtlzz_pipe_334_s4 <= 32'h0;
            rtlzz_pipe_334_s5 <= 32'h0;
            rtlzz_pipe_338_s6 <= 32'h0;
            rtlzz_pipe_339_s6 <= 1'h0;
            rtlzz_pipe_340_s3 <= 1'h0;
            rtlzz_pipe_340_s4 <= 1'h0;
            rtlzz_pipe_340_s5 <= 1'h0;
            rtlzz_pipe_340_s6 <= 1'h0;
            rtlzz_pipe_13_s7 <= 65'h100000000ffffffff;
            rtlzz_pipe_14_s8 <= 65'h0;
            rtlzz_pipe_346_s1 <= 32'h0;
            rtlzz_pipe_346_s2 <= 32'h0;
            rtlzz_pipe_346_s3 <= 32'h0;
            rtlzz_pipe_346_s4 <= 32'h0;
            rtlzz_pipe_346_s5 <= 32'h0;
            rtlzz_pipe_346_s6 <= 32'h0;
            rtlzz_pipe_346_s7 <= 32'h0;
            rtlzz_pipe_346_s8 <= 32'h0;
            rtlzz_pipe_346_s9 <= 32'h0;
            rtlzz_pipe_349_s10 <= 32'h1;
            rtlzz_pipe_349_s11 <= 32'h1;
            rtlzz_pipe_350_s10 <= 1'h0;
            rtlzz_pipe_351_s1 <= 32'h0;
            rtlzz_pipe_351_s2 <= 32'h0;
            rtlzz_pipe_351_s3 <= 32'h0;
            rtlzz_pipe_351_s4 <= 32'h0;
            rtlzz_pipe_351_s5 <= 32'h0;
            rtlzz_pipe_351_s6 <= 32'h0;
            rtlzz_pipe_351_s7 <= 32'h0;
            rtlzz_pipe_351_s8 <= 32'h0;
            rtlzz_pipe_351_s9 <= 32'h0;
            rtlzz_pipe_351_s10 <= 32'h0;
            rtlzz_pipe_354_s11 <= 32'hffffffff;
            rtlzz_pipe_355_s11 <= 1'h0;
            rtlzz_pipe_356_s1 <= 1'h0;
            rtlzz_pipe_356_s2 <= 1'h0;
            rtlzz_pipe_356_s3 <= 1'h0;
            rtlzz_pipe_356_s4 <= 1'h0;
            rtlzz_pipe_356_s5 <= 1'h0;
            rtlzz_pipe_356_s6 <= 1'h0;
            rtlzz_pipe_356_s7 <= 1'h0;
            rtlzz_pipe_356_s8 <= 1'h0;
            rtlzz_pipe_356_s9 <= 1'h0;
            rtlzz_pipe_356_s10 <= 1'h0;
            rtlzz_pipe_356_s11 <= 1'h0;
            rtlzz_pipe_361_s12 <= 32'h1;
            rtlzz_pipe_361_s13 <= 32'h1;
            rtlzz_pipe_362_s1 <= 32'h0;
            rtlzz_pipe_362_s2 <= 32'h0;
            rtlzz_pipe_362_s3 <= 32'h0;
            rtlzz_pipe_362_s4 <= 32'h0;
            rtlzz_pipe_362_s5 <= 32'h0;
            rtlzz_pipe_362_s6 <= 32'h0;
            rtlzz_pipe_362_s7 <= 32'h0;
            rtlzz_pipe_362_s8 <= 32'h0;
            rtlzz_pipe_362_s9 <= 32'h0;
            rtlzz_pipe_362_s10 <= 32'h0;
            rtlzz_pipe_362_s11 <= 32'h0;
            rtlzz_pipe_362_s12 <= 32'h0;
            rtlzz_pipe_363_s13 <= 32'hffffffff;
            rtlzz_pipe_365_s14 <= 32'h1;
            rtlzz_pipe_365_s15 <= 32'h1;
            rtlzz_pipe_366_s14 <= 1'h1;
            rtlzz_pipe_367_s12 <= 32'hffffffff;
            rtlzz_pipe_367_s13 <= 32'hffffffff;
            rtlzz_pipe_367_s14 <= 32'hffffffff;
            rtlzz_pipe_368_s1 <= 32'h0;
            rtlzz_pipe_368_s2 <= 32'h0;
            rtlzz_pipe_368_s3 <= 32'h0;
            rtlzz_pipe_368_s4 <= 32'h0;
            rtlzz_pipe_368_s5 <= 32'h0;
            rtlzz_pipe_368_s6 <= 32'h0;
            rtlzz_pipe_368_s7 <= 32'h0;
            rtlzz_pipe_368_s8 <= 32'h0;
            rtlzz_pipe_368_s9 <= 32'h0;
            rtlzz_pipe_368_s10 <= 32'h0;
            rtlzz_pipe_368_s11 <= 32'h0;
            rtlzz_pipe_368_s12 <= 32'h0;
            rtlzz_pipe_368_s13 <= 32'h0;
            rtlzz_pipe_368_s14 <= 32'h0;
            rtlzz_pipe_371_s15 <= 32'hffffffff;
            rtlzz_pipe_372_s15 <= 1'h1;
            rtlzz_pipe_373_s12 <= 1'h0;
            rtlzz_pipe_373_s13 <= 1'h0;
            rtlzz_pipe_373_s14 <= 1'h0;
            rtlzz_pipe_373_s15 <= 1'h0;
            rtlzz_pipe_374_s1 <= 1'h0;
            rtlzz_pipe_374_s2 <= 1'h0;
            rtlzz_pipe_374_s3 <= 1'h0;
            rtlzz_pipe_374_s4 <= 1'h0;
            rtlzz_pipe_374_s5 <= 1'h0;
            rtlzz_pipe_374_s6 <= 1'h0;
            rtlzz_pipe_374_s7 <= 1'h0;
            rtlzz_pipe_374_s8 <= 1'h0;
            rtlzz_pipe_374_s9 <= 1'h0;
            rtlzz_pipe_374_s10 <= 1'h0;
            rtlzz_pipe_374_s11 <= 1'h0;
            rtlzz_pipe_374_s12 <= 1'h0;
            rtlzz_pipe_374_s13 <= 1'h0;
            rtlzz_pipe_374_s14 <= 1'h0;
            rtlzz_pipe_374_s15 <= 1'h0;
            rtlzz_pipe_400_s1 <= 32'h0;
            rtlzz_pipe_400_s2 <= 32'h0;
            rtlzz_pipe_401_s1 <= 1'h0;
            rtlzz_pipe_402_s1 <= 32'h0;
            rtlzz_pipe_403_s1 <= 32'h0;
            rtlzz_pipe_405_s2 <= 32'h0;
            rtlzz_pipe_406_s2 <= 1'h0;
            rtlzz_pipe_407_s1 <= 1'h0;
            rtlzz_pipe_407_s2 <= 1'h0;
            rtlzz_pipe_408_s1 <= 1'h0;
            rtlzz_pipe_408_s2 <= 1'h0;
            rtlzz_pipe_22_s3 <= 65'h0;
            rtlzz_pipe_22_s4 <= 65'h0;
            rtlzz_pipe_22_s5 <= 65'h0;
            rtlzz_pipe_22_s6 <= 65'h0;
            rtlzz_pipe_22_s7 <= 65'h0;
            rtlzz_pipe_23_s4 <= 1'h1;
            rtlzz_pipe_23_s5 <= 1'h1;
            rtlzz_pipe_23_s6 <= 1'h1;
            rtlzz_pipe_23_s7 <= 1'h1;
            rtlzz_pipe_412_s3 <= 32'h0;
            rtlzz_pipe_412_s4 <= 32'h0;
            rtlzz_pipe_416_s5 <= 32'hffffffff;
            rtlzz_pipe_416_s6 <= 32'hffffffff;
            rtlzz_pipe_417_s5 <= 1'h0;
            rtlzz_pipe_418_s3 <= 32'h0;
            rtlzz_pipe_418_s4 <= 32'h0;
            rtlzz_pipe_418_s5 <= 32'h0;
            rtlzz_pipe_422_s6 <= 32'h0;
            rtlzz_pipe_423_s6 <= 1'h0;
            rtlzz_pipe_424_s3 <= 1'h0;
            rtlzz_pipe_424_s4 <= 1'h0;
            rtlzz_pipe_424_s5 <= 1'h0;
            rtlzz_pipe_424_s6 <= 1'h0;
            rtlzz_pipe_24_s7 <= 65'h100000000ffffffff;
            rtlzz_pipe_25_s8 <= 65'h0;
            rtlzz_pipe_430_s1 <= 32'h0;
            rtlzz_pipe_430_s2 <= 32'h0;
            rtlzz_pipe_430_s3 <= 32'h0;
            rtlzz_pipe_430_s4 <= 32'h0;
            rtlzz_pipe_430_s5 <= 32'h0;
            rtlzz_pipe_430_s6 <= 32'h0;
            rtlzz_pipe_430_s7 <= 32'h0;
            rtlzz_pipe_430_s8 <= 32'h0;
            rtlzz_pipe_430_s9 <= 32'h0;
            rtlzz_pipe_433_s10 <= 32'h1;
            rtlzz_pipe_433_s11 <= 32'h1;
            rtlzz_pipe_434_s10 <= 1'h0;
            rtlzz_pipe_435_s1 <= 32'h0;
            rtlzz_pipe_435_s2 <= 32'h0;
            rtlzz_pipe_435_s3 <= 32'h0;
            rtlzz_pipe_435_s4 <= 32'h0;
            rtlzz_pipe_435_s5 <= 32'h0;
            rtlzz_pipe_435_s6 <= 32'h0;
            rtlzz_pipe_435_s7 <= 32'h0;
            rtlzz_pipe_435_s8 <= 32'h0;
            rtlzz_pipe_435_s9 <= 32'h0;
            rtlzz_pipe_435_s10 <= 32'h0;
            rtlzz_pipe_438_s11 <= 32'hffffffff;
            rtlzz_pipe_439_s11 <= 1'h0;
            rtlzz_pipe_440_s1 <= 1'h0;
            rtlzz_pipe_440_s2 <= 1'h0;
            rtlzz_pipe_440_s3 <= 1'h0;
            rtlzz_pipe_440_s4 <= 1'h0;
            rtlzz_pipe_440_s5 <= 1'h0;
            rtlzz_pipe_440_s6 <= 1'h0;
            rtlzz_pipe_440_s7 <= 1'h0;
            rtlzz_pipe_440_s8 <= 1'h0;
            rtlzz_pipe_440_s9 <= 1'h0;
            rtlzz_pipe_440_s10 <= 1'h0;
            rtlzz_pipe_440_s11 <= 1'h0;
            rtlzz_pipe_445_s12 <= 32'h1;
            rtlzz_pipe_446_s1 <= 32'h0;
            rtlzz_pipe_446_s2 <= 32'h0;
            rtlzz_pipe_446_s3 <= 32'h0;
            rtlzz_pipe_446_s4 <= 32'h0;
            rtlzz_pipe_446_s5 <= 32'h0;
            rtlzz_pipe_446_s6 <= 32'h0;
            rtlzz_pipe_446_s7 <= 32'h0;
            rtlzz_pipe_446_s8 <= 32'h0;
            rtlzz_pipe_446_s9 <= 32'h0;
            rtlzz_pipe_446_s10 <= 32'h0;
            rtlzz_pipe_446_s11 <= 32'h0;
            rtlzz_pipe_446_s12 <= 32'h0;
            rtlzz_pipe_449_s13 <= 32'h1;
            rtlzz_pipe_449_s14 <= 32'h1;
            rtlzz_pipe_450_s13 <= 1'h1;
            rtlzz_pipe_451_s12 <= 32'hffffffff;
            rtlzz_pipe_451_s13 <= 32'hffffffff;
            rtlzz_pipe_452_s1 <= 32'h0;
            rtlzz_pipe_452_s2 <= 32'h0;
            rtlzz_pipe_452_s3 <= 32'h0;
            rtlzz_pipe_452_s4 <= 32'h0;
            rtlzz_pipe_452_s5 <= 32'h0;
            rtlzz_pipe_452_s6 <= 32'h0;
            rtlzz_pipe_452_s7 <= 32'h0;
            rtlzz_pipe_452_s8 <= 32'h0;
            rtlzz_pipe_452_s9 <= 32'h0;
            rtlzz_pipe_452_s10 <= 32'h0;
            rtlzz_pipe_452_s11 <= 32'h0;
            rtlzz_pipe_452_s12 <= 32'h0;
            rtlzz_pipe_452_s13 <= 32'h0;
            rtlzz_pipe_455_s14 <= 32'hffffffff;
            rtlzz_pipe_456_s14 <= 1'h1;
            rtlzz_pipe_457_s12 <= 1'h0;
            rtlzz_pipe_457_s13 <= 1'h0;
            rtlzz_pipe_457_s14 <= 1'h0;
            rtlzz_pipe_459_s1 <= 1'h1;
            rtlzz_pipe_459_s2 <= 1'h1;
            rtlzz_pipe_459_s3 <= 1'h1;
            rtlzz_pipe_459_s4 <= 1'h1;
            rtlzz_pipe_459_s5 <= 1'h1;
            rtlzz_pipe_459_s6 <= 1'h1;
            rtlzz_pipe_459_s7 <= 1'h1;
            rtlzz_pipe_459_s8 <= 1'h1;
            rtlzz_pipe_459_s9 <= 1'h1;
            rtlzz_pipe_459_s10 <= 1'h1;
            rtlzz_pipe_459_s11 <= 1'h1;
            rtlzz_pipe_459_s12 <= 1'h1;
            rtlzz_pipe_459_s13 <= 1'h1;
            rtlzz_pipe_459_s14 <= 1'h1;
            rtlzz_pipe_253_s15 <= 64'h0;
            rtlzz_pipe_481_s1 <= 32'h0;
            rtlzz_pipe_482_s1 <= 32'h0;
            rtlzz_pipe_484_s2 <= 32'h0;
            rtlzz_pipe_484_s3 <= 32'h0;
            rtlzz_pipe_485_s2 <= 1'h0;
            rtlzz_pipe_486_s1 <= 32'h0;
            rtlzz_pipe_486_s2 <= 32'h0;
            rtlzz_pipe_487_s1 <= 32'h0;
            rtlzz_pipe_487_s2 <= 32'h0;
            rtlzz_pipe_489_s3 <= 32'h0;
            rtlzz_pipe_490_s3 <= 1'h0;
            rtlzz_pipe_491_s1 <= 1'h0;
            rtlzz_pipe_491_s2 <= 1'h0;
            rtlzz_pipe_491_s3 <= 1'h0;
            rtlzz_pipe_492_s1 <= 1'h0;
            rtlzz_pipe_492_s2 <= 1'h0;
            rtlzz_pipe_492_s3 <= 1'h0;
            rtlzz_pipe_33_s4 <= 65'h0;
            rtlzz_pipe_33_s5 <= 65'h0;
            rtlzz_pipe_33_s6 <= 65'h0;
            rtlzz_pipe_33_s7 <= 65'h0;
            rtlzz_pipe_33_s8 <= 65'h0;
            rtlzz_pipe_34_s5 <= 1'h1;
            rtlzz_pipe_34_s6 <= 1'h1;
            rtlzz_pipe_34_s7 <= 1'h1;
            rtlzz_pipe_34_s8 <= 1'h1;
            rtlzz_pipe_496_s4 <= 32'h0;
            rtlzz_pipe_496_s5 <= 32'h0;
            rtlzz_pipe_500_s6 <= 32'hffffffff;
            rtlzz_pipe_500_s7 <= 32'hffffffff;
            rtlzz_pipe_501_s6 <= 1'h0;
            rtlzz_pipe_502_s4 <= 32'h0;
            rtlzz_pipe_502_s5 <= 32'h0;
            rtlzz_pipe_502_s6 <= 32'h0;
            rtlzz_pipe_506_s7 <= 32'h0;
            rtlzz_pipe_507_s7 <= 1'h0;
            rtlzz_pipe_508_s4 <= 1'h0;
            rtlzz_pipe_508_s5 <= 1'h0;
            rtlzz_pipe_508_s6 <= 1'h0;
            rtlzz_pipe_508_s7 <= 1'h0;
            rtlzz_pipe_35_s8 <= 65'h100000000ffffffff;
            rtlzz_pipe_36_s9 <= 65'h0;
            rtlzz_pipe_36_s10 <= 65'h0;
            rtlzz_pipe_36_s11 <= 65'h0;
            rtlzz_pipe_514_s1 <= 32'h0;
            rtlzz_pipe_514_s2 <= 32'h0;
            rtlzz_pipe_514_s3 <= 32'h0;
            rtlzz_pipe_514_s4 <= 32'h0;
            rtlzz_pipe_514_s5 <= 32'h0;
            rtlzz_pipe_514_s6 <= 32'h0;
            rtlzz_pipe_514_s7 <= 32'h0;
            rtlzz_pipe_514_s8 <= 32'h0;
            rtlzz_pipe_514_s9 <= 32'h0;
            rtlzz_pipe_517_s10 <= 32'h1;
            rtlzz_pipe_518_s10 <= 1'h0;
            rtlzz_pipe_519_s1 <= 32'h0;
            rtlzz_pipe_519_s2 <= 32'h0;
            rtlzz_pipe_519_s3 <= 32'h0;
            rtlzz_pipe_519_s4 <= 32'h0;
            rtlzz_pipe_519_s5 <= 32'h0;
            rtlzz_pipe_519_s6 <= 32'h0;
            rtlzz_pipe_519_s7 <= 32'h0;
            rtlzz_pipe_519_s8 <= 32'h0;
            rtlzz_pipe_519_s9 <= 32'h0;
            rtlzz_pipe_519_s10 <= 32'h0;
            rtlzz_pipe_524_s1 <= 1'h0;
            rtlzz_pipe_524_s2 <= 1'h0;
            rtlzz_pipe_524_s3 <= 1'h0;
            rtlzz_pipe_524_s4 <= 1'h0;
            rtlzz_pipe_524_s5 <= 1'h0;
            rtlzz_pipe_524_s6 <= 1'h0;
            rtlzz_pipe_524_s7 <= 1'h0;
            rtlzz_pipe_524_s8 <= 1'h0;
            rtlzz_pipe_524_s9 <= 1'h0;
            rtlzz_pipe_524_s10 <= 1'h0;
            rtlzz_pipe_529_s11 <= 32'h1;
            rtlzz_pipe_531_s1 <= 32'hffffffff;
            rtlzz_pipe_531_s2 <= 32'hffffffff;
            rtlzz_pipe_531_s3 <= 32'hffffffff;
            rtlzz_pipe_531_s4 <= 32'hffffffff;
            rtlzz_pipe_531_s5 <= 32'hffffffff;
            rtlzz_pipe_531_s6 <= 32'hffffffff;
            rtlzz_pipe_531_s7 <= 32'hffffffff;
            rtlzz_pipe_531_s8 <= 32'hffffffff;
            rtlzz_pipe_531_s9 <= 32'hffffffff;
            rtlzz_pipe_531_s10 <= 32'hffffffff;
            rtlzz_pipe_531_s11 <= 32'hffffffff;
            rtlzz_pipe_533_s12 <= 32'h1;
            rtlzz_pipe_533_s13 <= 32'h1;
            rtlzz_pipe_534_s12 <= 1'h1;
            rtlzz_pipe_535_s11 <= 32'hffffffff;
            rtlzz_pipe_535_s12 <= 32'hffffffff;
            rtlzz_pipe_536_s1 <= 32'h0;
            rtlzz_pipe_537_s2 <= 32'hffffffff;
            rtlzz_pipe_537_s3 <= 32'hffffffff;
            rtlzz_pipe_537_s4 <= 32'hffffffff;
            rtlzz_pipe_537_s5 <= 32'hffffffff;
            rtlzz_pipe_537_s6 <= 32'hffffffff;
            rtlzz_pipe_537_s7 <= 32'hffffffff;
            rtlzz_pipe_537_s8 <= 32'hffffffff;
            rtlzz_pipe_537_s9 <= 32'hffffffff;
            rtlzz_pipe_537_s10 <= 32'hffffffff;
            rtlzz_pipe_537_s11 <= 32'hffffffff;
            rtlzz_pipe_537_s12 <= 32'hffffffff;
            rtlzz_pipe_539_s13 <= 32'hffffffff;
            rtlzz_pipe_540_s13 <= 1'h1;
            rtlzz_pipe_541_s11 <= 1'h0;
            rtlzz_pipe_541_s12 <= 1'h0;
            rtlzz_pipe_541_s13 <= 1'h0;
            rtlzz_pipe_542_s1 <= 1'h0;
            rtlzz_pipe_542_s2 <= 1'h0;
            rtlzz_pipe_543_s3 <= 1'h1;
            rtlzz_pipe_543_s4 <= 1'h1;
            rtlzz_pipe_543_s5 <= 1'h1;
            rtlzz_pipe_543_s6 <= 1'h1;
            rtlzz_pipe_543_s7 <= 1'h1;
            rtlzz_pipe_543_s8 <= 1'h1;
            rtlzz_pipe_543_s9 <= 1'h1;
            rtlzz_pipe_543_s10 <= 1'h1;
            rtlzz_pipe_543_s11 <= 1'h1;
            rtlzz_pipe_543_s12 <= 1'h1;
            rtlzz_pipe_543_s13 <= 1'h1;
            rtlzz_pipe_565_s1 <= 32'h0;
            rtlzz_pipe_565_s2 <= 32'h0;
            rtlzz_pipe_565_s3 <= 32'h0;
            rtlzz_pipe_566_s1 <= 32'h0;
            rtlzz_pipe_566_s2 <= 32'h0;
            rtlzz_pipe_566_s3 <= 32'h0;
            rtlzz_pipe_568_s4 <= 32'h0;
            rtlzz_pipe_568_s5 <= 32'h0;
            rtlzz_pipe_569_s4 <= 1'h0;
            rtlzz_pipe_570_s1 <= 32'h0;
            rtlzz_pipe_570_s2 <= 32'h0;
            rtlzz_pipe_570_s3 <= 32'h0;
            rtlzz_pipe_570_s4 <= 32'h0;
            rtlzz_pipe_571_s1 <= 32'h0;
            rtlzz_pipe_571_s2 <= 32'h0;
            rtlzz_pipe_571_s3 <= 32'h0;
            rtlzz_pipe_571_s4 <= 32'h0;
            rtlzz_pipe_573_s5 <= 32'h0;
            rtlzz_pipe_574_s5 <= 1'h0;
            rtlzz_pipe_575_s1 <= 1'h0;
            rtlzz_pipe_575_s2 <= 1'h0;
            rtlzz_pipe_575_s3 <= 1'h0;
            rtlzz_pipe_575_s4 <= 1'h0;
            rtlzz_pipe_575_s5 <= 1'h0;
            rtlzz_pipe_576_s1 <= 1'h0;
            rtlzz_pipe_576_s2 <= 1'h0;
            rtlzz_pipe_576_s3 <= 1'h0;
            rtlzz_pipe_576_s4 <= 1'h0;
            rtlzz_pipe_576_s5 <= 1'h0;
            rtlzz_pipe_44_s6 <= 65'h0;
            rtlzz_pipe_44_s7 <= 65'h0;
            rtlzz_pipe_44_s8 <= 65'h0;
            rtlzz_pipe_44_s9 <= 65'h0;
            rtlzz_pipe_45_s7 <= 1'h1;
            rtlzz_pipe_45_s8 <= 1'h1;
            rtlzz_pipe_45_s9 <= 1'h1;
            rtlzz_pipe_580_s6 <= 32'h0;
            rtlzz_pipe_580_s7 <= 32'h0;
            rtlzz_pipe_584_s8 <= 32'hffffffff;
            rtlzz_pipe_585_s8 <= 1'h0;
            rtlzz_pipe_586_s6 <= 32'h0;
            rtlzz_pipe_586_s7 <= 32'h0;
            rtlzz_pipe_586_s8 <= 32'h0;
            rtlzz_pipe_592_s6 <= 1'h0;
            rtlzz_pipe_592_s7 <= 1'h0;
            rtlzz_pipe_592_s8 <= 1'h0;
            rtlzz_pipe_46_s9 <= 65'h100000000ffffffff;
            rtlzz_pipe_601_s1 <= 32'h1;
            rtlzz_pipe_601_s2 <= 32'h1;
            rtlzz_pipe_602_s1 <= 1'h0;
            rtlzz_pipe_603_s1 <= 32'h0;
            rtlzz_pipe_606_s2 <= 32'hffffffff;
            rtlzz_pipe_607_s2 <= 1'h0;
            rtlzz_pipe_608_s1 <= 1'h0;
            rtlzz_pipe_608_s2 <= 1'h0;
            rtlzz_pipe_613_s3 <= 32'h1;
            rtlzz_pipe_613_s4 <= 32'h1;
            rtlzz_pipe_614_s1 <= 32'h0;
            rtlzz_pipe_614_s2 <= 32'h0;
            rtlzz_pipe_614_s3 <= 32'h0;
            rtlzz_pipe_615_s4 <= 32'hffffffff;
            rtlzz_pipe_617_s5 <= 32'h1;
            rtlzz_pipe_617_s6 <= 32'h1;
            rtlzz_pipe_617_s7 <= 32'h1;
            rtlzz_pipe_617_s8 <= 32'h1;
            rtlzz_pipe_617_s9 <= 32'h1;
            rtlzz_pipe_617_s10 <= 32'h1;
            rtlzz_pipe_618_s5 <= 1'h1;
            rtlzz_pipe_618_s6 <= 1'h1;
            rtlzz_pipe_619_s3 <= 32'hffffffff;
            rtlzz_pipe_619_s4 <= 32'hffffffff;
            rtlzz_pipe_619_s5 <= 32'hffffffff;
            rtlzz_pipe_619_s6 <= 32'hffffffff;
            rtlzz_pipe_620_s1 <= 32'h0;
            rtlzz_pipe_620_s2 <= 32'h0;
            rtlzz_pipe_620_s3 <= 32'h0;
            rtlzz_pipe_620_s4 <= 32'h0;
            rtlzz_pipe_620_s5 <= 32'h0;
            rtlzz_pipe_621_s6 <= 32'hffffffff;
            rtlzz_pipe_623_s7 <= 32'hffffffff;
            rtlzz_pipe_623_s8 <= 32'hffffffff;
            rtlzz_pipe_623_s9 <= 32'hffffffff;
            rtlzz_pipe_623_s10 <= 32'hffffffff;
            rtlzz_pipe_624_s7 <= 1'h1;
            rtlzz_pipe_624_s8 <= 1'h1;
            rtlzz_pipe_624_s9 <= 1'h1;
            rtlzz_pipe_624_s10 <= 1'h1;
            rtlzz_pipe_625_s3 <= 1'h0;
            rtlzz_pipe_625_s4 <= 1'h0;
            rtlzz_pipe_625_s5 <= 1'h0;
            rtlzz_pipe_625_s6 <= 1'h0;
            rtlzz_pipe_625_s7 <= 1'h0;
            rtlzz_pipe_625_s8 <= 1'h0;
            rtlzz_pipe_625_s9 <= 1'h0;
            rtlzz_pipe_625_s10 <= 1'h0;
            rtlzz_pipe_626_s1 <= 1'h0;
            rtlzz_pipe_626_s2 <= 1'h0;
            rtlzz_pipe_626_s3 <= 1'h0;
            rtlzz_pipe_626_s4 <= 1'h0;
            rtlzz_pipe_626_s5 <= 1'h0;
            rtlzz_pipe_626_s6 <= 1'h0;
            rtlzz_pipe_626_s7 <= 1'h0;
            rtlzz_pipe_627_s8 <= 1'h1;
            rtlzz_pipe_627_s9 <= 1'h1;
            rtlzz_pipe_627_s10 <= 1'h1;
            rtlzz_pipe_49_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_49_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_631_s11 <= 32'h1;
            rtlzz_pipe_637_s11 <= 32'hffffffff;
            rtlzz_pipe_643_s11 <= 1'h0;
            rtlzz_pipe_51_s12 <= 65'h0;
            rtlzz_pipe_226_s13 <= 129'h0;
            rtlzz_pipe_226_s14 <= 129'h0;
            rtlzz_pipe_268_s13 <= 65'h0;
            rtlzz_pipe_652_s9 <= 32'h0;
            rtlzz_pipe_653_s9 <= 1'h0;
            rtlzz_pipe_654_s9 <= 32'h0;
            rtlzz_pipe_655_s9 <= 32'h0;
            rtlzz_pipe_659_s9 <= 1'h0;
            rtlzz_pipe_660_s9 <= 1'h0;
            rtlzz_pipe_55_s10 <= 65'h0;
            rtlzz_pipe_668_s10 <= 32'hffffffff;
            rtlzz_pipe_669_s10 <= 1'h0;
            rtlzz_pipe_670_s10 <= 32'h0;
            rtlzz_pipe_676_s10 <= 1'h0;
            rtlzz_pipe_58_s11 <= 65'h0;
            rtlzz_pipe_697_s9 <= 32'h1;
            rtlzz_pipe_698_s9 <= 32'h0;
            rtlzz_pipe_701_s10 <= 32'h1;
            rtlzz_pipe_701_s11 <= 32'h1;
            rtlzz_pipe_702_s10 <= 1'h1;
            rtlzz_pipe_702_s11 <= 1'h1;
            rtlzz_pipe_703_s9 <= 32'hffffffff;
            rtlzz_pipe_703_s10 <= 32'hffffffff;
            rtlzz_pipe_703_s11 <= 32'hffffffff;
            rtlzz_pipe_704_s9 <= 32'h0;
            rtlzz_pipe_704_s10 <= 32'h0;
            rtlzz_pipe_704_s11 <= 32'h0;
            rtlzz_pipe_709_s9 <= 1'h0;
            rtlzz_pipe_709_s10 <= 1'h0;
            rtlzz_pipe_709_s11 <= 1'h0;
            rtlzz_pipe_711_s9 <= 1'h1;
            rtlzz_pipe_711_s10 <= 1'h1;
            rtlzz_pipe_711_s11 <= 1'h1;
            rtlzz_pipe_60_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_719_s12 <= 32'h0;
            rtlzz_pipe_719_s13 <= 32'h0;
            rtlzz_pipe_720_s12 <= 1'h1;
            rtlzz_pipe_721_s12 <= 32'hffffffff;
            rtlzz_pipe_725_s13 <= 32'h0;
            rtlzz_pipe_726_s13 <= 1'h1;
            rtlzz_pipe_727_s12 <= 1'h0;
            rtlzz_pipe_727_s13 <= 1'h0;
            rtlzz_pipe_62_s14 <= 65'h0;
            rtlzz_pipe_878_s10 <= 32'h0;
            rtlzz_pipe_878_s11 <= 32'h0;
            rtlzz_pipe_880_s12 <= 32'h0;
            rtlzz_pipe_883_s10 <= 32'h0;
            rtlzz_pipe_883_s11 <= 32'h0;
            rtlzz_pipe_885_s12 <= 32'h0;
            rtlzz_pipe_886_s12 <= 1'h0;
            rtlzz_pipe_887_s12 <= 1'h0;
            rtlzz_pipe_888_s10 <= 1'h0;
            rtlzz_pipe_888_s11 <= 1'h0;
            rtlzz_pipe_888_s12 <= 1'h0;
            rtlzz_pipe_89_s13 <= 65'h0;
            rtlzz_pipe_89_s14 <= 65'h0;
            rtlzz_pipe_90_s13 <= 1'h1;
            rtlzz_pipe_90_s14 <= 1'h1;
            rtlzz_pipe_892_s13 <= 32'h0;
            rtlzz_pipe_898_s13 <= 32'h0;
            rtlzz_pipe_904_s13 <= 1'h0;
            rtlzz_pipe_91_s14 <= 65'h100000000ffffffff;
            rtlzz_pipe_913_s12 <= 32'h1;
            rtlzz_pipe_918_s12 <= 32'hffffffff;
            rtlzz_pipe_919_s12 <= 1'h0;
            rtlzz_pipe_920_s12 <= 1'h0;
            rtlzz_pipe_926_s10 <= 32'h0;
            rtlzz_pipe_927_s11 <= 32'hffffffff;
            rtlzz_pipe_927_s12 <= 32'hffffffff;
            rtlzz_pipe_929_s13 <= 32'h1;
            rtlzz_pipe_930_s13 <= 1'h1;
            rtlzz_pipe_931_s13 <= 32'hffffffff;
            rtlzz_pipe_933_s10 <= 32'hffffffff;
            rtlzz_pipe_933_s11 <= 32'hffffffff;
            rtlzz_pipe_933_s12 <= 32'hffffffff;
            rtlzz_pipe_933_s13 <= 32'hffffffff;
            rtlzz_pipe_937_s13 <= 1'h0;
            rtlzz_pipe_938_s10 <= 1'h0;
            rtlzz_pipe_939_s11 <= 1'h1;
            rtlzz_pipe_939_s12 <= 1'h1;
            rtlzz_pipe_939_s13 <= 1'h1;
            rtlzz_pipe_94_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_947_s14 <= 32'h0;
            rtlzz_pipe_953_s14 <= 32'h0;
            rtlzz_pipe_954_s14 <= 1'h1;
            rtlzz_pipe_955_s14 <= 1'h0;
            rtlzz_pipe_963_s14 <= 32'hffffffff;
            rtlzz_pipe_969_s14 <= 32'hffffffff;
            rtlzz_pipe_975_s14 <= 32'hffffffff;
            rtlzz_pipe_981_s14 <= 32'hffffffff;
            rtlzz_pipe_987_s14 <= 1'h1;
            rtlzz_pipe_1021_s14 <= 32'h0;
            rtlzz_pipe_1026_s14 <= 32'h0;
            rtlzz_pipe_1031_s14 <= 1'h0;
            rtlzz_pipe_231_s15 <= 129'h0;
            rtlzz_pipe_1069_s14 <= 32'h1;
            rtlzz_pipe_1075_s14 <= 32'hffffffff;
            rtlzz_pipe_1081_s14 <= 1'h0;
            rtlzz_pipe_117_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_118_s15 <= 1'h0;
            rtlzz_pipe_1091_s15 <= 32'h0;
            rtlzz_pipe_1092_s15 <= 1'h1;
            rtlzz_pipe_1093_s15 <= 32'hffffffff;
            rtlzz_pipe_1099_s15 <= 1'h0;
            rtlzz_pipe_1105_s12 <= 32'h0;
            rtlzz_pipe_1105_s13 <= 32'h0;
            rtlzz_pipe_1105_s14 <= 32'h0;
            rtlzz_pipe_1110_s12 <= 32'h0;
            rtlzz_pipe_1110_s13 <= 32'h0;
            rtlzz_pipe_1110_s14 <= 32'h0;
            rtlzz_pipe_1115_s12 <= 1'h0;
            rtlzz_pipe_1115_s13 <= 1'h0;
            rtlzz_pipe_1115_s14 <= 1'h0;
            rtlzz_pipe_132_s15 <= 64'h0;
            rtlzz_pipe_1141_s12 <= 32'h1;
            rtlzz_pipe_1146_s12 <= 32'hffffffff;
            rtlzz_pipe_1147_s12 <= 1'h0;
            rtlzz_pipe_1148_s12 <= 1'h0;
            rtlzz_pipe_1153_s13 <= 32'h1;
            rtlzz_pipe_1153_s14 <= 32'h1;
            rtlzz_pipe_1153_s15 <= 32'h1;
            rtlzz_pipe_1154_s15 <= 32'h0;
            rtlzz_pipe_1159_s13 <= 32'hffffffff;
            rtlzz_pipe_1159_s14 <= 32'hffffffff;
            rtlzz_pipe_1159_s15 <= 32'hffffffff;
            rtlzz_pipe_1161_s15 <= 32'hffffffff;
            rtlzz_pipe_1165_s13 <= 1'h0;
            rtlzz_pipe_1165_s14 <= 1'h0;
            rtlzz_pipe_1165_s15 <= 1'h0;
            rtlzz_pipe_1167_s15 <= 1'h1;
            rtlzz_pipe_1191_s15 <= 32'hffffffff;
            rtlzz_pipe_1197_s15 <= 32'hffffffff;
            rtlzz_pipe_1203_s15 <= 32'hffffffff;
            rtlzz_pipe_1209_s15 <= 32'hffffffff;
            rtlzz_pipe_1215_s15 <= 1'h1;
            rtlzz_pipe_182_s15 <= 64'h0;
            rtlzz_pipe_178_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_179_s15 <= 1'h0;
            rtlzz_pipe_1463_s15 <= 32'h0;
            rtlzz_pipe_1469_s15 <= 32'h0;
            rtlzz_pipe_1470_s15 <= 1'h1;
            rtlzz_pipe_1471_s15 <= 1'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
            rtlzz_valid_s8 <= 1'h0;
            rtlzz_valid_s9 <= 1'h0;
            rtlzz_valid_s10 <= 1'h0;
            rtlzz_valid_s11 <= 1'h0;
            rtlzz_valid_s12 <= 1'h0;
            rtlzz_valid_s13 <= 1'h0;
            rtlzz_valid_s14 <= 1'h0;
            rtlzz_valid_s15 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_316_s1 <= limb_11_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_316_s2 <= rtlzz_pipe_316_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_317_s1 <= limb_11_317; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_318_s1 <= limb_11_318; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_319_s1 <= limb_11_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_321_s2 <= limb_11_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_322_s2 <= limb_11_322; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_323_s1 <= limb_11_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_323_s2 <= rtlzz_pipe_323_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_324_s1 <= limb_11_324; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_324_s2 <= rtlzz_pipe_324_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_11_s3 <= s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_11_s4 <= rtlzz_pipe_11_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_11_s6 <= rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_11_s7 <= rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_328_s3 <= limb_13_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= rtlzz_pipe_328_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_332_s5 <= limb_13_332; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_332_s6 <= rtlzz_pipe_332_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_333_s5 <= limb_13_333; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_334_s3 <= limb_13_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_334_s4 <= rtlzz_pipe_334_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_338_s6 <= limb_13_338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_339_s6 <= limb_13_339; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_340_s3 <= limb_13_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_340_s4 <= rtlzz_pipe_340_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_340_s5 <= rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_13_s7 <= s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_14_s8 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
        end
        if (iv) begin
        rtlzz_pipe_346_s1 <= limb_15_346; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_346_s2 <= rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_346_s3 <= rtlzz_pipe_346_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_346_s4 <= rtlzz_pipe_346_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_346_s5 <= rtlzz_pipe_346_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_346_s6 <= rtlzz_pipe_346_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_346_s7 <= rtlzz_pipe_346_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_346_s8 <= rtlzz_pipe_346_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_346_s9 <= rtlzz_pipe_346_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_349_s10 <= limb_15_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_349_s11 <= rtlzz_pipe_349_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_350_s10 <= limb_15_350; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_351_s1 <= limb_15_351; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_351_s2 <= rtlzz_pipe_351_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_351_s3 <= rtlzz_pipe_351_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_351_s4 <= rtlzz_pipe_351_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_351_s5 <= rtlzz_pipe_351_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_351_s6 <= rtlzz_pipe_351_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_351_s7 <= rtlzz_pipe_351_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_351_s8 <= rtlzz_pipe_351_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_351_s9 <= rtlzz_pipe_351_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_351_s10 <= rtlzz_pipe_351_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_354_s11 <= limb_15_354; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_355_s11 <= limb_15_355; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_356_s1 <= limb_15_356; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_356_s2 <= rtlzz_pipe_356_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_356_s3 <= rtlzz_pipe_356_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_356_s4 <= rtlzz_pipe_356_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_356_s5 <= rtlzz_pipe_356_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_356_s6 <= rtlzz_pipe_356_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_356_s7 <= rtlzz_pipe_356_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_356_s8 <= rtlzz_pipe_356_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_356_s9 <= rtlzz_pipe_356_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_356_s10 <= rtlzz_pipe_356_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_356_s11 <= rtlzz_pipe_356_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_361_s12 <= limb_16_361; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_361_s13 <= rtlzz_pipe_361_s12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_362_s1 <= limb_16_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_362_s2 <= rtlzz_pipe_362_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_362_s3 <= rtlzz_pipe_362_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_362_s4 <= rtlzz_pipe_362_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_362_s5 <= rtlzz_pipe_362_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_362_s6 <= rtlzz_pipe_362_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_362_s7 <= rtlzz_pipe_362_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_362_s8 <= rtlzz_pipe_362_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_362_s9 <= rtlzz_pipe_362_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_362_s10 <= rtlzz_pipe_362_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_362_s11 <= rtlzz_pipe_362_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_362_s12 <= rtlzz_pipe_362_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_363_s13 <= limb_16_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_365_s14 <= limb_16_365; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_365_s15 <= rtlzz_pipe_365_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_366_s14 <= limb_16_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_367_s12 <= limb_16_367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_367_s13 <= rtlzz_pipe_367_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_367_s14 <= rtlzz_pipe_367_s13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_368_s1 <= limb_16_368; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_368_s2 <= rtlzz_pipe_368_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_368_s3 <= rtlzz_pipe_368_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_368_s4 <= rtlzz_pipe_368_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_368_s5 <= rtlzz_pipe_368_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_368_s6 <= rtlzz_pipe_368_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_368_s7 <= rtlzz_pipe_368_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_368_s8 <= rtlzz_pipe_368_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_368_s9 <= rtlzz_pipe_368_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_368_s10 <= rtlzz_pipe_368_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_368_s11 <= rtlzz_pipe_368_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_368_s12 <= rtlzz_pipe_368_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_368_s13 <= rtlzz_pipe_368_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_368_s14 <= rtlzz_pipe_368_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_371_s15 <= limb_16_371; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_372_s15 <= limb_16_372; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_373_s12 <= limb_16_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_373_s13 <= rtlzz_pipe_373_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_373_s14 <= rtlzz_pipe_373_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_373_s15 <= rtlzz_pipe_373_s14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_374_s1 <= limb_16_374; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_374_s2 <= rtlzz_pipe_374_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_374_s3 <= rtlzz_pipe_374_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_374_s4 <= rtlzz_pipe_374_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_374_s5 <= rtlzz_pipe_374_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_374_s6 <= rtlzz_pipe_374_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_374_s7 <= rtlzz_pipe_374_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_374_s8 <= rtlzz_pipe_374_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_374_s9 <= rtlzz_pipe_374_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_374_s10 <= rtlzz_pipe_374_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_374_s11 <= rtlzz_pipe_374_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_374_s12 <= rtlzz_pipe_374_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_374_s13 <= rtlzz_pipe_374_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_374_s14 <= rtlzz_pipe_374_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_374_s15 <= rtlzz_pipe_374_s14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_400_s1 <= limb_22_400; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_400_s2 <= rtlzz_pipe_400_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_401_s1 <= limb_22_401; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_402_s1 <= limb_22_402; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_403_s1 <= limb_22_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_405_s2 <= limb_22_405; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_406_s2 <= limb_22_406; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_407_s1 <= limb_22_407; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_407_s2 <= rtlzz_pipe_407_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_408_s1 <= limb_22_408; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_408_s2 <= rtlzz_pipe_408_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_22_s3 <= s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_22_s4 <= rtlzz_pipe_22_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_22_s5 <= rtlzz_pipe_22_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_22_s6 <= rtlzz_pipe_22_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_22_s7 <= rtlzz_pipe_22_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_23_s4 <= s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_23_s5 <= rtlzz_pipe_23_s4; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_23_s6 <= rtlzz_pipe_23_s5; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_23_s7 <= rtlzz_pipe_23_s6; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_412_s3 <= limb_24_412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_412_s4 <= rtlzz_pipe_412_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_416_s5 <= limb_24_416; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_416_s6 <= rtlzz_pipe_416_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_417_s5 <= limb_24_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_418_s3 <= limb_24_418; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_418_s4 <= rtlzz_pipe_418_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_418_s5 <= rtlzz_pipe_418_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_422_s6 <= limb_24_422; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_423_s6 <= limb_24_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_424_s3 <= limb_24_424; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_424_s4 <= rtlzz_pipe_424_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_424_s5 <= rtlzz_pipe_424_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_424_s6 <= rtlzz_pipe_424_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_24_s7 <= s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_25_s8 <= s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
        end
        if (iv) begin
        rtlzz_pipe_430_s1 <= limb_26_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_430_s2 <= rtlzz_pipe_430_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_430_s3 <= rtlzz_pipe_430_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_430_s4 <= rtlzz_pipe_430_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_430_s5 <= rtlzz_pipe_430_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_430_s6 <= rtlzz_pipe_430_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_430_s7 <= rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_430_s8 <= rtlzz_pipe_430_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_430_s9 <= rtlzz_pipe_430_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_433_s10 <= limb_26_433; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_433_s11 <= rtlzz_pipe_433_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_434_s10 <= limb_26_434; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_435_s1 <= limb_26_435; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_435_s2 <= rtlzz_pipe_435_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_435_s3 <= rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_435_s4 <= rtlzz_pipe_435_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_435_s5 <= rtlzz_pipe_435_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_435_s6 <= rtlzz_pipe_435_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_435_s7 <= rtlzz_pipe_435_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_435_s8 <= rtlzz_pipe_435_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_435_s9 <= rtlzz_pipe_435_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_435_s10 <= rtlzz_pipe_435_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_438_s11 <= limb_26_438; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_439_s11 <= limb_26_439; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_440_s1 <= limb_26_440; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_440_s2 <= rtlzz_pipe_440_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_440_s3 <= rtlzz_pipe_440_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_440_s4 <= rtlzz_pipe_440_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_440_s5 <= rtlzz_pipe_440_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_440_s6 <= rtlzz_pipe_440_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_440_s7 <= rtlzz_pipe_440_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_440_s8 <= rtlzz_pipe_440_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_440_s9 <= rtlzz_pipe_440_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_440_s10 <= rtlzz_pipe_440_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_440_s11 <= rtlzz_pipe_440_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_445_s12 <= limb_27_445; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_446_s1 <= limb_27_446; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_446_s2 <= rtlzz_pipe_446_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_446_s3 <= rtlzz_pipe_446_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_446_s4 <= rtlzz_pipe_446_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_446_s5 <= rtlzz_pipe_446_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_446_s6 <= rtlzz_pipe_446_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_446_s7 <= rtlzz_pipe_446_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_446_s8 <= rtlzz_pipe_446_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_446_s9 <= rtlzz_pipe_446_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_446_s10 <= rtlzz_pipe_446_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_446_s11 <= rtlzz_pipe_446_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_446_s12 <= rtlzz_pipe_446_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_449_s13 <= limb_27_449; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_449_s14 <= rtlzz_pipe_449_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_450_s13 <= limb_27_450; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_451_s12 <= limb_27_451; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_451_s13 <= rtlzz_pipe_451_s12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_452_s1 <= limb_27_452; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_452_s2 <= rtlzz_pipe_452_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_452_s3 <= rtlzz_pipe_452_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_452_s4 <= rtlzz_pipe_452_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_452_s5 <= rtlzz_pipe_452_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_452_s6 <= rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_452_s7 <= rtlzz_pipe_452_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_452_s8 <= rtlzz_pipe_452_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_452_s9 <= rtlzz_pipe_452_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_452_s10 <= rtlzz_pipe_452_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_452_s11 <= rtlzz_pipe_452_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_452_s12 <= rtlzz_pipe_452_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_452_s13 <= rtlzz_pipe_452_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_455_s14 <= limb_27_455; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_456_s14 <= limb_27_456; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_457_s12 <= limb_27_457; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_457_s13 <= rtlzz_pipe_457_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_457_s14 <= rtlzz_pipe_457_s13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_459_s1 <= limb_27_459; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_459_s2 <= rtlzz_pipe_459_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_459_s3 <= rtlzz_pipe_459_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_459_s4 <= rtlzz_pipe_459_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_459_s5 <= rtlzz_pipe_459_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_459_s6 <= rtlzz_pipe_459_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_459_s7 <= rtlzz_pipe_459_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_459_s8 <= rtlzz_pipe_459_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_459_s9 <= rtlzz_pipe_459_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_459_s10 <= rtlzz_pipe_459_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_459_s11 <= rtlzz_pipe_459_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_459_s12 <= rtlzz_pipe_459_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_459_s13 <= rtlzz_pipe_459_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_459_s14 <= rtlzz_pipe_459_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_253_s15 <= mul_precision_253; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_481_s1 <= limb_33_481; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_482_s1 <= limb_33_482; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_484_s2 <= limb_33_484; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_484_s3 <= rtlzz_pipe_484_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_485_s2 <= limb_33_485; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_486_s1 <= limb_33_486; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_486_s2 <= rtlzz_pipe_486_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_487_s1 <= limb_33_487; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_487_s2 <= rtlzz_pipe_487_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_489_s3 <= limb_33_489; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_490_s3 <= limb_33_490; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_491_s1 <= limb_33_491; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_491_s2 <= rtlzz_pipe_491_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_491_s3 <= rtlzz_pipe_491_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_492_s1 <= limb_33_492; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_492_s2 <= rtlzz_pipe_492_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_492_s3 <= rtlzz_pipe_492_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_33_s4 <= s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_33_s5 <= rtlzz_pipe_33_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_33_s6 <= rtlzz_pipe_33_s5; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_33_s7 <= rtlzz_pipe_33_s6; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_33_s8 <= rtlzz_pipe_33_s7; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_34_s5 <= s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_34_s6 <= rtlzz_pipe_34_s5; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_34_s7 <= rtlzz_pipe_34_s6; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_34_s8 <= rtlzz_pipe_34_s7; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_496_s4 <= limb_35_496; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_496_s5 <= rtlzz_pipe_496_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_500_s6 <= limb_35_500; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_500_s7 <= rtlzz_pipe_500_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_501_s6 <= limb_35_501; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_502_s4 <= limb_35_502; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_502_s5 <= rtlzz_pipe_502_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_502_s6 <= rtlzz_pipe_502_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_506_s7 <= limb_35_506; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_507_s7 <= limb_35_507; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_508_s4 <= limb_35_508; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_508_s5 <= rtlzz_pipe_508_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_508_s6 <= rtlzz_pipe_508_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_508_s7 <= rtlzz_pipe_508_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_35_s8 <= s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_36_s9 <= s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_36_s10 <= rtlzz_pipe_36_s9; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_36_s11 <= rtlzz_pipe_36_s10; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (iv) begin
        rtlzz_pipe_514_s1 <= limb_37_514; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_514_s2 <= rtlzz_pipe_514_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_514_s3 <= rtlzz_pipe_514_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_514_s4 <= rtlzz_pipe_514_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_514_s5 <= rtlzz_pipe_514_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_514_s6 <= rtlzz_pipe_514_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_514_s7 <= rtlzz_pipe_514_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_514_s8 <= rtlzz_pipe_514_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_514_s9 <= rtlzz_pipe_514_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_517_s10 <= limb_37_517; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_518_s10 <= limb_37_518; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_519_s1 <= limb_37_519; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_519_s2 <= rtlzz_pipe_519_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_519_s3 <= rtlzz_pipe_519_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_519_s4 <= rtlzz_pipe_519_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_519_s5 <= rtlzz_pipe_519_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_519_s6 <= rtlzz_pipe_519_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_519_s7 <= rtlzz_pipe_519_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_519_s8 <= rtlzz_pipe_519_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_519_s9 <= rtlzz_pipe_519_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_519_s10 <= rtlzz_pipe_519_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_524_s1 <= limb_37_524; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_524_s2 <= rtlzz_pipe_524_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_524_s3 <= rtlzz_pipe_524_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_524_s4 <= rtlzz_pipe_524_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_524_s5 <= rtlzz_pipe_524_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_524_s6 <= rtlzz_pipe_524_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_524_s7 <= rtlzz_pipe_524_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_524_s8 <= rtlzz_pipe_524_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_524_s9 <= rtlzz_pipe_524_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_524_s10 <= rtlzz_pipe_524_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_529_s11 <= limb_38_529; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_531_s1 <= limb_38_531; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_531_s2 <= rtlzz_pipe_531_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_531_s3 <= rtlzz_pipe_531_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_531_s4 <= rtlzz_pipe_531_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_531_s5 <= rtlzz_pipe_531_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_531_s6 <= rtlzz_pipe_531_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_531_s7 <= rtlzz_pipe_531_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_531_s8 <= rtlzz_pipe_531_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_531_s9 <= rtlzz_pipe_531_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_531_s10 <= rtlzz_pipe_531_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_531_s11 <= rtlzz_pipe_531_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_533_s12 <= limb_38_533; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_533_s13 <= rtlzz_pipe_533_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_534_s12 <= limb_38_534; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_535_s11 <= limb_38_535; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_535_s12 <= rtlzz_pipe_535_s11; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_536_s1 <= limb_38_536; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_537_s2 <= limb_38_537; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_537_s3 <= rtlzz_pipe_537_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_537_s4 <= rtlzz_pipe_537_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_537_s5 <= rtlzz_pipe_537_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_537_s6 <= rtlzz_pipe_537_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_537_s7 <= rtlzz_pipe_537_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_537_s8 <= rtlzz_pipe_537_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_537_s9 <= rtlzz_pipe_537_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_537_s10 <= rtlzz_pipe_537_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_537_s11 <= rtlzz_pipe_537_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_537_s12 <= rtlzz_pipe_537_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_539_s13 <= limb_38_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_540_s13 <= limb_38_540; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_541_s11 <= limb_38_541; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_541_s12 <= rtlzz_pipe_541_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_541_s13 <= rtlzz_pipe_541_s12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_542_s1 <= limb_38_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_542_s2 <= rtlzz_pipe_542_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_543_s3 <= limb_38_543; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_543_s4 <= rtlzz_pipe_543_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_543_s5 <= rtlzz_pipe_543_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_543_s6 <= rtlzz_pipe_543_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_543_s7 <= rtlzz_pipe_543_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_543_s8 <= rtlzz_pipe_543_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_543_s9 <= rtlzz_pipe_543_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_543_s10 <= rtlzz_pipe_543_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_543_s11 <= rtlzz_pipe_543_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_543_s12 <= rtlzz_pipe_543_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_543_s13 <= rtlzz_pipe_543_s12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_565_s1 <= limb_44_565; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_565_s2 <= rtlzz_pipe_565_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_565_s3 <= rtlzz_pipe_565_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_566_s1 <= limb_44_566; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_566_s2 <= rtlzz_pipe_566_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_566_s3 <= rtlzz_pipe_566_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_568_s4 <= limb_44_568; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_568_s5 <= rtlzz_pipe_568_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_569_s4 <= limb_44_569; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_570_s1 <= limb_44_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_570_s2 <= rtlzz_pipe_570_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_570_s3 <= rtlzz_pipe_570_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_570_s4 <= rtlzz_pipe_570_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_571_s1 <= limb_44_571; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_571_s2 <= rtlzz_pipe_571_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_571_s3 <= rtlzz_pipe_571_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_571_s4 <= rtlzz_pipe_571_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_573_s5 <= limb_44_573; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_574_s5 <= limb_44_574; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_575_s1 <= limb_44_575; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_575_s2 <= rtlzz_pipe_575_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_575_s3 <= rtlzz_pipe_575_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_575_s4 <= rtlzz_pipe_575_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_575_s5 <= rtlzz_pipe_575_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_576_s1 <= limb_44_576; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_576_s2 <= rtlzz_pipe_576_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_576_s3 <= rtlzz_pipe_576_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_576_s4 <= rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_576_s5 <= rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_44_s6 <= s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_44_s7 <= rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_44_s8 <= rtlzz_pipe_44_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_44_s9 <= rtlzz_pipe_44_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_45_s8 <= rtlzz_pipe_45_s7; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_45_s9 <= rtlzz_pipe_45_s8; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_580_s6 <= limb_46_580; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_580_s7 <= rtlzz_pipe_580_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_584_s8 <= limb_46_584; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_585_s8 <= limb_46_585; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_586_s6 <= limb_46_586; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_586_s7 <= rtlzz_pipe_586_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_586_s8 <= rtlzz_pipe_586_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_592_s6 <= limb_46_592; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_592_s7 <= rtlzz_pipe_592_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_592_s8 <= rtlzz_pipe_592_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_46_s9 <= s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (iv) begin
        rtlzz_pipe_601_s1 <= limb_48_601; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_601_s2 <= rtlzz_pipe_601_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_602_s1 <= limb_48_602; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_603_s1 <= limb_48_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_606_s2 <= limb_48_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_607_s2 <= limb_48_607; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_608_s1 <= limb_48_608; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_608_s2 <= rtlzz_pipe_608_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_613_s3 <= limb_49_613; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_613_s4 <= rtlzz_pipe_613_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_614_s1 <= limb_49_614; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_614_s2 <= rtlzz_pipe_614_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_614_s3 <= rtlzz_pipe_614_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_615_s4 <= limb_49_615; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_617_s5 <= limb_49_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_617_s6 <= rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_617_s7 <= rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_617_s8 <= rtlzz_pipe_617_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_617_s9 <= rtlzz_pipe_617_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_617_s10 <= rtlzz_pipe_617_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_618_s5 <= limb_49_618; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_618_s6 <= rtlzz_pipe_618_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_619_s3 <= limb_49_619; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_619_s4 <= rtlzz_pipe_619_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_619_s5 <= rtlzz_pipe_619_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_619_s6 <= rtlzz_pipe_619_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_620_s1 <= limb_49_620; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_620_s2 <= rtlzz_pipe_620_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_620_s3 <= rtlzz_pipe_620_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_620_s4 <= rtlzz_pipe_620_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_620_s5 <= rtlzz_pipe_620_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_621_s6 <= limb_49_621; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_623_s7 <= limb_49_623; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_623_s8 <= rtlzz_pipe_623_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_623_s9 <= rtlzz_pipe_623_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_623_s10 <= rtlzz_pipe_623_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_624_s7 <= limb_49_624; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_624_s8 <= rtlzz_pipe_624_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_624_s9 <= rtlzz_pipe_624_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_624_s10 <= rtlzz_pipe_624_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_625_s3 <= limb_49_625; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_625_s4 <= rtlzz_pipe_625_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_625_s5 <= rtlzz_pipe_625_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_625_s6 <= rtlzz_pipe_625_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_625_s7 <= rtlzz_pipe_625_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_625_s8 <= rtlzz_pipe_625_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_625_s9 <= rtlzz_pipe_625_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_625_s10 <= rtlzz_pipe_625_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_626_s1 <= limb_49_626; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_626_s2 <= rtlzz_pipe_626_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_626_s3 <= rtlzz_pipe_626_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_626_s4 <= rtlzz_pipe_626_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_626_s5 <= rtlzz_pipe_626_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_626_s6 <= rtlzz_pipe_626_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_626_s7 <= rtlzz_pipe_626_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_627_s8 <= limb_49_627; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_627_s9 <= rtlzz_pipe_627_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_627_s10 <= rtlzz_pipe_627_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_49_s11 <= s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_49_s12 <= rtlzz_pipe_49_s11; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_631_s11 <= limb_51_631; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_637_s11 <= limb_51_637; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_643_s11 <= limb_51_643; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_51_s12 <= s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_226_s13 <= __beopt_width_869; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_226_s14 <= rtlzz_pipe_226_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_268_s13 <= mul_precision_268; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_652_s9 <= limb_55_652; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_653_s9 <= limb_55_653; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_654_s9 <= limb_55_654; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_655_s9 <= limb_55_655; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_659_s9 <= limb_55_659; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_660_s9 <= limb_55_660; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_55_s10 <= s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_668_s10 <= limb_57_668; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_669_s10 <= limb_57_669; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_670_s10 <= limb_57_670; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_676_s10 <= limb_57_676; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_58_s11 <= s8_norm_mux_91_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_697_s9 <= limb_60_697; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_698_s9 <= limb_60_698; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_701_s10 <= limb_60_701; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_701_s11 <= rtlzz_pipe_701_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_702_s10 <= limb_60_702; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_702_s11 <= rtlzz_pipe_702_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_703_s9 <= limb_60_703; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_703_s10 <= rtlzz_pipe_703_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_703_s11 <= rtlzz_pipe_703_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_704_s9 <= limb_60_704; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_704_s10 <= rtlzz_pipe_704_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_704_s11 <= rtlzz_pipe_704_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_709_s9 <= limb_60_709; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_709_s10 <= rtlzz_pipe_709_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_709_s11 <= rtlzz_pipe_709_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_711_s9 <= limb_60_711; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_711_s10 <= rtlzz_pipe_711_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_711_s11 <= rtlzz_pipe_711_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_60_s12 <= s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_60_s13 <= rtlzz_pipe_60_s12; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_60_s14 <= rtlzz_pipe_60_s13; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_719_s12 <= limb_62_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_719_s13 <= rtlzz_pipe_719_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_720_s12 <= limb_62_720; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_721_s12 <= limb_62_721; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_725_s13 <= limb_62_725; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_726_s13 <= limb_62_726; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_727_s12 <= limb_62_727; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_727_s13 <= rtlzz_pipe_727_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_62_s14 <= s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_878_s10 <= limb_89_878; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_878_s11 <= rtlzz_pipe_878_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_880_s12 <= limb_89_880; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_883_s10 <= limb_89_883; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_883_s11 <= rtlzz_pipe_883_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_885_s12 <= limb_89_885; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_886_s12 <= limb_89_886; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_887_s12 <= limb_89_887; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_888_s10 <= limb_89_888; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_888_s11 <= rtlzz_pipe_888_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_888_s12 <= rtlzz_pipe_888_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_89_s13 <= s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_89_s14 <= rtlzz_pipe_89_s13; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_90_s13 <= s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_90_s14 <= rtlzz_pipe_90_s13; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_892_s13 <= limb_91_892; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_898_s13 <= limb_91_898; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_904_s13 <= limb_91_904; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_91_s14 <= s8_norm_sub_151_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_913_s12 <= limb_93_913; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_918_s12 <= limb_93_918; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_919_s12 <= limb_93_919; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_920_s12 <= limb_93_920; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_926_s10 <= limb_94_926; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_927_s11 <= limb_94_927; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_927_s12 <= rtlzz_pipe_927_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_929_s13 <= limb_94_929; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_930_s13 <= limb_94_930; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_931_s13 <= limb_94_931; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_933_s10 <= limb_94_933; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_933_s11 <= rtlzz_pipe_933_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_933_s12 <= rtlzz_pipe_933_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_933_s13 <= rtlzz_pipe_933_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_937_s13 <= limb_94_937; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_938_s10 <= limb_94_938; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_939_s11 <= limb_94_939; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_939_s12 <= rtlzz_pipe_939_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_939_s13 <= rtlzz_pipe_939_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_94_s14 <= s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_947_s14 <= limb_96_947; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_953_s14 <= limb_96_953; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_954_s14 <= limb_96_954; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_955_s14 <= limb_96_955; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_963_s14 <= limb_106_963; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_969_s14 <= limb_106_969; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_975_s14 <= limb_106_975; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_981_s14 <= limb_106_981; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_987_s14 <= limb_106_987; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1021_s14 <= limb_112_1021; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1026_s14 <= limb_112_1026; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1031_s14 <= limb_112_1031; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_231_s15 <= __beopt_width_876; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1069_s14 <= limb_117_1069; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1075_s14 <= limb_117_1075; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1081_s14 <= limb_117_1081; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_117_s15 <= s8_norm_sub_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_118_s15 <= s8_norm_cmp_200_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1091_s15 <= limb_119_1091; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1092_s15 <= limb_119_1092; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1093_s15 <= limb_119_1093; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1099_s15 <= limb_119_1099; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1105_s12 <= limb_123_1105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1105_s13 <= rtlzz_pipe_1105_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1105_s14 <= rtlzz_pipe_1105_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1110_s12 <= limb_123_1110; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1110_s13 <= rtlzz_pipe_1110_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1110_s14 <= rtlzz_pipe_1110_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1115_s12 <= limb_123_1115; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1115_s13 <= rtlzz_pipe_1115_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1115_s14 <= rtlzz_pipe_1115_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_132_s15 <= tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1141_s12 <= limb_127_1141; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1146_s12 <= limb_127_1146; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1147_s12 <= limb_127_1147; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_1148_s12 <= limb_127_1148; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1153_s13 <= limb_128_1153; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1153_s14 <= rtlzz_pipe_1153_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1153_s15 <= rtlzz_pipe_1153_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1154_s15 <= limb_128_1154; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1159_s13 <= limb_128_1159; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1159_s14 <= rtlzz_pipe_1159_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1159_s15 <= rtlzz_pipe_1159_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1161_s15 <= limb_128_1161; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_1165_s13 <= limb_128_1165; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1165_s14 <= rtlzz_pipe_1165_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1165_s15 <= rtlzz_pipe_1165_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1167_s15 <= limb_128_1167; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1191_s15 <= limb_142_1191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1197_s15 <= limb_142_1197; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1203_s15 <= limb_142_1203; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1209_s15 <= limb_142_1209; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1215_s15 <= limb_142_1215; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_182_s15 <= tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_178_s15 <= s8_norm_sub_300_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_179_s15 <= s8_norm_cmp_302_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1463_s15 <= limb_180_1463; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1469_s15 <= limb_180_1469; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1470_s15 <= limb_180_1470; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_1471_s15 <= limb_180_1471; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s8 <= rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s9 <= rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s10 <= rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s11 <= rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s12 <= rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s13 <= rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s14 <= rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s15 <= rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_47Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_47();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_75Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_75();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_181Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_181();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_199Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_199();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_299Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_299();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffeff000001);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffeff00000101);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_311Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_311();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_399Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_399();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_404Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_404();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_442Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_442();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_460Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_460();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_478Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_478();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_499Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_499();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_521Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_521();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_532Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_532();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_556Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_556();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_562Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_562();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_567Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_567();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_595Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_595();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_600Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_600();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_605Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_605();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_610Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_610();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_616Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_616();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_622Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_622();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_634Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_634();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_640Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_640();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_651Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_651();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_656Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_656();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_661Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_661();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_667Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_667();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_673Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_673();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_684Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_684();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_689Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_689();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_694Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_694();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_700Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_700();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_706Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_706();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_712Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_712();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_718Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_718();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_724Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_724();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_730Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_730();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_748Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_748();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h1ffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [0:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_795Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_795();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_800Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_800();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_805Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_805();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_817Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_817();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_823Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_823();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_828Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_828();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_833Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_833();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_838Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_838();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_844Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_844();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_850Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_850();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_856Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_856();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_868Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_868();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_879Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_879();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_884Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_884();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_895Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_895();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_917Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_917();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_922Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_922();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_928Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_928();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_934Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_934();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_940Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_940();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_946Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_946();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_952Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_952();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_958Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_958();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_964Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_964();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_970Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_970();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_976Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_976();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_982Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h1ffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_982();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_988Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_988();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_994Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_994();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1000Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1000();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1006Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [0:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1006();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1023Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1023();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1033Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1033();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1039Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1039();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1045Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1045();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1051Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1051();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1056Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1056();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1061Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1061();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1066Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1066();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1072Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1072();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1078Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1078();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1096Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1096();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1102Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1107Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1107();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1112Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1117Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1117();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1123Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1140Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1145Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1145();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1156Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1162Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1162();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1168Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1174Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1180Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1192Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1198Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1204Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1210Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1216Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1222Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1228Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1234Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [0:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1251Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1251();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1256Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1261Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1261();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1267Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1267();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1273Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1289Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1289();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1294Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1300Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1306Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1312Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1312();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1318Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1318();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1324Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1324();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1336Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1336();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1342Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1342();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1348Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1354Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h1ffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1360Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1360();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1366Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1372Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1372();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1378Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [0:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1378();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1395Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1395();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1400Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1400();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1405Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1411Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1411();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1417Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1417();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1428Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1428();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1433Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1433();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1438Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1444Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1450Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1450();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1456Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1456();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1462Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1462();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1468Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1468();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1480Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1480();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1486Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1486();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1492Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1492();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1498Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1498();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1504Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1504();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1510Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1510();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1516Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1522Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [0:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1522();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1539Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1539();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1544Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1544();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1549Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1549();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1555Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1555();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1561Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1561();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1572Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h1);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1572();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1577Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hffffffff);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1577();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1582Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1582();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1588Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1588();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1594Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1594();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1600Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1600();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1606Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'hfffffffe);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1606();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1612Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1612();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x0_data,input wire x0_wen,input wire [63:0] x1_data,input wire x1_wen,input wire [63:0] x2_data,input wire x2_wen,input wire [63:0] x3_data,input wire x3_wen,input wire [63:0] x4_data,input wire x4_wen,input wire [63:0] x5_data,input wire x5_wen,input wire [63:0] x6_data,input wire x6_wen,input wire [63:0] x7_data,input wire x7_wen,output reg [63:0] y0,output reg [63:0] y1,output reg [63:0] y2,output reg [63:0] y3,output reg [63:0] y4,output reg [63:0] y5,output reg [63:0] y6,output reg [63:0] y7);
reg liv;wire cov;
reg [63:0] l_x0;
reg [63:0] l_x1;
reg [63:0] l_x2;
reg [63:0] l_x3;
reg [63:0] l_x4;
reg [63:0] l_x5;
reg [63:0] l_x6;
reg [63:0] l_x7;
wire [63:0] c_y0;
wire [63:0] c_y1;
wire [63:0] c_y2;
wire [63:0] c_y3;
wire [63:0] c_y4;
wire [63:0] c_y5;
wire [63:0] c_y6;
wire [63:0] c_y7;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x0(l_x0),.x1(l_x1),.x2(l_x2),.x3(l_x3),.x4(l_x4),.x5(l_x5),.x6(l_x6),.x7(l_x7),.y0(c_y0),.y1(c_y1),.y2(c_y2),.y3(c_y3),.y4(c_y4),.y5(c_y5),.y6(c_y6),.y7(c_y7));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x0<=64'h0;l_x1<=64'h0;l_x2<=64'h0;l_x3<=64'h0;l_x4<=64'h0;l_x5<=64'h0;l_x6<=64'h0;l_x7<=64'h0;y0<=64'h0;y1<=64'h0;y2<=64'h0;y3<=64'h0;y4<=64'h0;y5<=64'h0;y6<=64'h0;y7<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x0_wen)l_x0<=x0_data;if(x1_wen)l_x1<=x1_data;if(x2_wen)l_x2<=x2_data;if(x3_wen)l_x3<=x3_data;if(x4_wen)l_x4<=x4_data;if(x5_wen)l_x5<=x5_data;if(x6_wen)l_x6<=x6_data;if(x7_wen)l_x7<=x7_data;y0<=c_y0;y1<=c_y1;y2<=c_y2;y3<=c_y3;y4<=c_y4;y5<=c_y5;y6<=c_y6;y7<=c_y7;end
endmodule
