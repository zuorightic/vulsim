`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(32'(mul_tree_10_11)), .b(32'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(32'(mul_tree_10_14)), .b(32'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(32'(mul_tree_10_18)), .b(32'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(32'(mul_tree_10_22)), .b(32'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(32'(mul_tree_10_26)), .b(32'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(32'(mul_tree_10_30)), .b(32'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(32'(mul_tree_10_34)), .b(32'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(32'(mul_tree_10_38)), .b(32'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(32'(mul_tree_10_42)), .b(32'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_10_46)), .b(32'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(32'(mul_tree_10_50)), .b(32'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(32'(mul_tree_10_54)), .b(32'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(32'(mul_tree_10_58)), .b(32'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(32'(mul_tree_10_62)), .b(32'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(32'(mul_tree_10_66)), .b(32'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(32'(mul_tree_10_70)), .b(32'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(64'(mul_tree_10_74)), .b(96'(mul_tree_10_75)), .cin(1'h0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = ({33'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(128'(mul_tree_10_77)), .b(160'(mul_tree_10_78)), .cin(1'h0), .value(mul_tree_10_79));
    assign mul_tree_10_80 = ({33'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(96'(mul_tree_10_80)), .b(128'(mul_tree_10_81)), .cin(1'h0), .value(mul_tree_10_82));
    assign mul_tree_10_83 = ({33'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(160'(mul_tree_10_83)), .b(192'(mul_tree_10_84)), .cin(1'h0), .value(mul_tree_10_85));
    assign mul_tree_10_86 = ({33'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(128'(mul_tree_10_86)), .b(160'(mul_tree_10_87)), .cin(1'h0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = ({33'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_91Core rtlzz_owner_91(.a(192'(mul_tree_10_89)), .b(224'(mul_tree_10_90)), .cin(1'h0), .value(mul_tree_10_91));
    assign mul_tree_10_92 = ({33'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(160'(mul_tree_10_92)), .b(192'(mul_tree_10_93)), .cin(1'h0), .value(mul_tree_10_94));
    assign mul_tree_10_95 = ({33'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(224'(mul_tree_10_95)), .b(256'(mul_tree_10_96)), .cin(1'h0), .value(mul_tree_10_97[255:0]));
    assign mul_tree_10_97[256:256] = '0;
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(97'(mul_tree_10_98)), .b(161'(mul_tree_10_99)), .cin(1'h0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(129'(mul_tree_10_101)), .b(193'(mul_tree_10_102)), .cin(1'h0), .value(mul_tree_10_103));
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(161'(mul_tree_10_104)), .b(225'(mul_tree_10_105)), .cin(1'h0), .value(mul_tree_10_106));
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(193'(mul_tree_10_107)), .b(257'(mul_tree_10_108)), .cin(1'h0), .value(mul_tree_10_109[255:0]));
    assign mul_tree_10_109[257:256] = '0;
    assign mul_tree_10_110 = ({33'h0, rtlzz_pipe_100_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, rtlzz_pipe_103_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({33'h0, rtlzz_pipe_106_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, rtlzz_pipe_109_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({65'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118_reduce rtlzz_reduce_118(.i144(rtlzz_pipe_100_s3), .i145(rtlzz_pipe_103_s3), .i146(rtlzz_pipe_106_s3), .i147(rtlzz_pipe_109_s3), .y(mul_tree_10_118));
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 64'h0;
            rtlzz_pipe_17_s1 <= 96'h0;
            rtlzz_pipe_21_s1 <= 128'h0;
            rtlzz_pipe_25_s1 <= 160'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_37_s1 <= 160'h0;
            rtlzz_pipe_41_s1 <= 192'h0;
            rtlzz_pipe_45_s1 <= 128'h0;
            rtlzz_pipe_49_s1 <= 160'h0;
            rtlzz_pipe_53_s1 <= 192'h0;
            rtlzz_pipe_57_s1 <= 224'h0;
            rtlzz_pipe_61_s1 <= 160'h0;
            rtlzz_pipe_65_s1 <= 192'h0;
            rtlzz_pipe_69_s1 <= 224'h0;
            rtlzz_pipe_73_s1 <= 256'h0;
            rtlzz_pipe_76_s2 <= 97'h0;
            rtlzz_pipe_79_s2 <= 161'h0;
            rtlzz_pipe_82_s2 <= 129'h0;
            rtlzz_pipe_85_s2 <= 193'h0;
            rtlzz_pipe_88_s2 <= 161'h0;
            rtlzz_pipe_91_s2 <= 225'h0;
            rtlzz_pipe_94_s2 <= 193'h0;
            rtlzz_pipe_97_s2 <= 257'h0;
            rtlzz_pipe_100_s3 <= 162'h0;
            rtlzz_pipe_103_s3 <= 194'h0;
            rtlzz_pipe_106_s3 <= 226'h0;
            rtlzz_pipe_109_s3 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_76_s2 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_79_s2 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_82_s2 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_85_s2 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_88_s2 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_91_s2 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_94_s2 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= mul_tree_10_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= mul_tree_10_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= mul_tree_10_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118_reduce(input wire [161:0] i144, input wire [193:0] i145, input wire [225:0] i146, input wire [257:0] i147, output wire [259:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i144[161], i144[160], i144[159], i144[158], i144[157], i144[156], i144[155], i144[154], i144[153], i144[152], i144[151], i144[150], i144[149], i144[148], i144[147], i144[146], i144[145], i144[144], i144[143], i144[142], i144[141], i144[140], i144[139], i144[138], i144[137], i144[136], i144[135], i144[134], i144[133], i144[132], i144[131], i144[130], i144[129], i144[128], i144[127], i144[126], i144[125], i144[124], i144[123], i144[122], i144[121], i144[120], i144[119], i144[118], i144[117], i144[116], i144[115], i144[114], i144[113], i144[112], i144[111], i144[110], i144[109], i144[108], i144[107], i144[106], i144[105], i144[104], i144[103], i144[102], i144[101], i144[100], i144[99], i144[98], i144[97], i144[96], i144[95], i144[94], i144[93], i144[92], i144[91], i144[90], i144[89], i144[88], i144[87], i144[86], i144[85], i144[84], i144[83], i144[82], i144[81], i144[80], i144[79], i144[78], i144[77], i144[76], i144[75], i144[74], i144[73], i144[72], i144[71], i144[70], i144[69], i144[68], i144[67], i144[66], i144[65], i144[64], i144[63], i144[62], i144[61], i144[60], i144[59], i144[58], i144[57], i144[56], i144[55], i144[54], i144[53], i144[52], i144[51], i144[50], i144[49], i144[48], i144[47], i144[46], i144[45], i144[44], i144[43], i144[42], i144[41], i144[40], i144[39], i144[38], i144[37], i144[36], i144[35], i144[34], i144[33], i144[32], i144[31], i144[30], i144[29], i144[28], i144[27], i144[26], i144[25], i144[24], i144[23], i144[22], i144[21], i144[20], i144[19], i144[18], i144[17], i144[16], i144[15], i144[14], i144[13], i144[12], i144[11], i144[10], i144[9], i144[8], i144[7], i144[6], i144[5], i144[4], i144[3], i144[2], i144[1], i144[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i145[193], i145[192], i145[191], i145[190], i145[189], i145[188], i145[187], i145[186], i145[185], i145[184], i145[183], i145[182], i145[181], i145[180], i145[179], i145[178], i145[177], i145[176], i145[175], i145[174], i145[173], i145[172], i145[171], i145[170], i145[169], i145[168], i145[167], i145[166], i145[165], i145[164], i145[163], i145[162], i145[161], i145[160], i145[159], i145[158], i145[157], i145[156], i145[155], i145[154], i145[153], i145[152], i145[151], i145[150], i145[149], i145[148], i145[147], i145[146], i145[145], i145[144], i145[143], i145[142], i145[141], i145[140], i145[139], i145[138], i145[137], i145[136], i145[135], i145[134], i145[133], i145[132], i145[131], i145[130], i145[129], i145[128], i145[127], i145[126], i145[125], i145[124], i145[123], i145[122], i145[121], i145[120], i145[119], i145[118], i145[117], i145[116], i145[115], i145[114], i145[113], i145[112], i145[111], i145[110], i145[109], i145[108], i145[107], i145[106], i145[105], i145[104], i145[103], i145[102], i145[101], i145[100], i145[99], i145[98], i145[97], i145[96], i145[95], i145[94], i145[93], i145[92], i145[91], i145[90], i145[89], i145[88], i145[87], i145[86], i145[85], i145[84], i145[83], i145[82], i145[81], i145[80], i145[79], i145[78], i145[77], i145[76], i145[75], i145[74], i145[73], i145[72], i145[71], i145[70], i145[69], i145[68], i145[67], i145[66], i145[65], i145[64], i145[63], i145[62], i145[61], i145[60], i145[59], i145[58], i145[57], i145[56], i145[55], i145[54], i145[53], i145[52], i145[51], i145[50], i145[49], i145[48], i145[47], i145[46], i145[45], i145[44], i145[43], i145[42], i145[41], i145[40], i145[39], i145[38], i145[37], i145[36], i145[35], i145[34], i145[33], i145[32], i145[31], i145[30], i145[29], i145[28], i145[27], i145[26], i145[25], i145[24], i145[23], i145[22], i145[21], i145[20], i145[19], i145[18], i145[17], i145[16], i145[15], i145[14], i145[13], i145[12], i145[11], i145[10], i145[9], i145[8], i145[7], i145[6], i145[5], i145[4], i145[3], i145[2], i145[1], i145[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i146[225], i146[224], i146[223], i146[222], i146[221], i146[220], i146[219], i146[218], i146[217], i146[216], i146[215], i146[214], i146[213], i146[212], i146[211], i146[210], i146[209], i146[208], i146[207], i146[206], i146[205], i146[204], i146[203], i146[202], i146[201], i146[200], i146[199], i146[198], i146[197], i146[196], i146[195], i146[194], i146[193], i146[192], i146[191], i146[190], i146[189], i146[188], i146[187], i146[186], i146[185], i146[184], i146[183], i146[182], i146[181], i146[180], i146[179], i146[178], i146[177], i146[176], i146[175], i146[174], i146[173], i146[172], i146[171], i146[170], i146[169], i146[168], i146[167], i146[166], i146[165], i146[164], i146[163], i146[162], i146[161], i146[160], i146[159], i146[158], i146[157], i146[156], i146[155], i146[154], i146[153], i146[152], i146[151], i146[150], i146[149], i146[148], i146[147], i146[146], i146[145], i146[144], i146[143], i146[142], i146[141], i146[140], i146[139], i146[138], i146[137], i146[136], i146[135], i146[134], i146[133], i146[132], i146[131], i146[130], i146[129], i146[128], i146[127], i146[126], i146[125], i146[124], i146[123], i146[122], i146[121], i146[120], i146[119], i146[118], i146[117], i146[116], i146[115], i146[114], i146[113], i146[112], i146[111], i146[110], i146[109], i146[108], i146[107], i146[106], i146[105], i146[104], i146[103], i146[102], i146[101], i146[100], i146[99], i146[98], i146[97], i146[96], i146[95], i146[94], i146[93], i146[92], i146[91], i146[90], i146[89], i146[88], i146[87], i146[86], i146[85], i146[84], i146[83], i146[82], i146[81], i146[80], i146[79], i146[78], i146[77], i146[76], i146[75], i146[74], i146[73], i146[72], i146[71], i146[70], i146[69], i146[68], i146[67], i146[66], i146[65], i146[64], i146[63], i146[62], i146[61], i146[60], i146[59], i146[58], i146[57], i146[56], i146[55], i146[54], i146[53], i146[52], i146[51], i146[50], i146[49], i146[48], i146[47], i146[46], i146[45], i146[44], i146[43], i146[42], i146[41], i146[40], i146[39], i146[38], i146[37], i146[36], i146[35], i146[34], i146[33], i146[32], i146[31], i146[30], i146[29], i146[28], i146[27], i146[26], i146[25], i146[24], i146[23], i146[22], i146[21], i146[20], i146[19], i146[18], i146[17], i146[16], i146[15], i146[14], i146[13], i146[12], i146[11], i146[10], i146[9], i146[8], i146[7], i146[6], i146[5], i146[4], i146[3], i146[2], i146[1], i146[0]};
wire [255:0] t3 = {i147[255], i147[254], i147[253], i147[252], i147[251], i147[250], i147[249], i147[248], i147[247], i147[246], i147[245], i147[244], i147[243], i147[242], i147[241], i147[240], i147[239], i147[238], i147[237], i147[236], i147[235], i147[234], i147[233], i147[232], i147[231], i147[230], i147[229], i147[228], i147[227], i147[226], i147[225], i147[224], i147[223], i147[222], i147[221], i147[220], i147[219], i147[218], i147[217], i147[216], i147[215], i147[214], i147[213], i147[212], i147[211], i147[210], i147[209], i147[208], i147[207], i147[206], i147[205], i147[204], i147[203], i147[202], i147[201], i147[200], i147[199], i147[198], i147[197], i147[196], i147[195], i147[194], i147[193], i147[192], i147[191], i147[190], i147[189], i147[188], i147[187], i147[186], i147[185], i147[184], i147[183], i147[182], i147[181], i147[180], i147[179], i147[178], i147[177], i147[176], i147[175], i147[174], i147[173], i147[172], i147[171], i147[170], i147[169], i147[168], i147[167], i147[166], i147[165], i147[164], i147[163], i147[162], i147[161], i147[160], i147[159], i147[158], i147[157], i147[156], i147[155], i147[154], i147[153], i147[152], i147[151], i147[150], i147[149], i147[148], i147[147], i147[146], i147[145], i147[144], i147[143], i147[142], i147[141], i147[140], i147[139], i147[138], i147[137], i147[136], i147[135], i147[134], i147[133], i147[132], i147[131], i147[130], i147[129], i147[128], i147[127], i147[126], i147[125], i147[124], i147[123], i147[122], i147[121], i147[120], i147[119], i147[118], i147[117], i147[116], i147[115], i147[114], i147[113], i147[112], i147[111], i147[110], i147[109], i147[108], i147[107], i147[106], i147[105], i147[104], i147[103], i147[102], i147[101], i147[100], i147[99], i147[98], i147[97], i147[96], i147[95], i147[94], i147[93], i147[92], i147[91], i147[90], i147[89], i147[88], i147[87], i147[86], i147[85], i147[84], i147[83], i147[82], i147[81], i147[80], i147[79], i147[78], i147[77], i147[76], i147[75], i147[74], i147[73], i147[72], i147[71], i147[70], i147[69], i147[68], i147[67], i147[66], i147[65], i147[64], i147[63], i147[62], i147[61], i147[60], i147[59], i147[58], i147[57], i147[56], i147[55], i147[54], i147[53], i147[52], i147[51], i147[50], i147[49], i147[48], i147[47], i147[46], i147[45], i147[44], i147[43], i147[42], i147[41], i147[40], i147[39], i147[38], i147[37], i147[36], i147[35], i147[34], i147[33], i147[32], i147[31], i147[30], i147[29], i147[28], i147[27], i147[26], i147[25], i147[24], i147[23], i147[22], i147[21], i147[20], i147[19], i147[18], i147[17], i147[16], i147[15], i147[14], i147[13], i147[12], i147[11], i147[10], i147[9], i147[8], i147[7], i147[6], i147[5], i147[4], i147[3], i147[2], i147[1], i147[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91Core(input wire [191:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [223:0] masked_b=((b&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [223:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [223:0] masked_a=((a&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffff000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [96:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [128:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [160:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [192:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
