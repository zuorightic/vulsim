`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
    logic [258:0] rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(32'(mul_tree_10_11)), .b(32'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(32'(mul_tree_10_14)), .b(32'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(32'(mul_tree_10_18)), .b(32'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(32'(mul_tree_10_22)), .b(32'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(32'(mul_tree_10_26)), .b(32'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(32'(mul_tree_10_30)), .b(32'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(32'(mul_tree_10_34)), .b(32'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(32'(mul_tree_10_38)), .b(32'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(32'(mul_tree_10_42)), .b(32'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_10_46)), .b(32'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(32'(mul_tree_10_50)), .b(32'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(32'(mul_tree_10_54)), .b(32'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(32'(mul_tree_10_58)), .b(32'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(32'(mul_tree_10_62)), .b(32'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(32'(mul_tree_10_66)), .b(32'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(32'(mul_tree_10_70)), .b(32'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(64'(mul_tree_10_74)), .b(96'(mul_tree_10_75)), .cin(1'h0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = ({33'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(128'(mul_tree_10_77)), .b(160'(mul_tree_10_78)), .cin(1'h0), .value(mul_tree_10_79));
    assign mul_tree_10_80 = ({33'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(96'(mul_tree_10_80)), .b(128'(mul_tree_10_81)), .cin(1'h0), .value(mul_tree_10_82));
    assign mul_tree_10_83 = ({33'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(160'(mul_tree_10_83)), .b(192'(mul_tree_10_84)), .cin(1'h0), .value(mul_tree_10_85));
    assign mul_tree_10_86 = ({33'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(128'(mul_tree_10_86)), .b(160'(mul_tree_10_87)), .cin(1'h0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = ({33'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_91Core rtlzz_owner_91(.a(192'(mul_tree_10_89)), .b(224'(mul_tree_10_90)), .cin(1'h0), .value(mul_tree_10_91));
    assign mul_tree_10_92 = ({33'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(160'(mul_tree_10_92)), .b(192'(mul_tree_10_93)), .cin(1'h0), .value(mul_tree_10_94));
    assign mul_tree_10_95 = ({33'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(224'(mul_tree_10_95)), .b(256'(mul_tree_10_96)), .cin(1'h0), .value(mul_tree_10_97[255:0]));
    assign mul_tree_10_97[256:256] = '0;
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(97'(mul_tree_10_98)), .b(161'(mul_tree_10_99)), .cin(1'h0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(129'(mul_tree_10_101)), .b(193'(mul_tree_10_102)), .cin(1'h0), .value(mul_tree_10_103));
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(161'(mul_tree_10_104)), .b(225'(mul_tree_10_105)), .cin(1'h0), .value(mul_tree_10_106));
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(193'(mul_tree_10_107)), .b(257'(mul_tree_10_108)), .cin(1'h0), .value(mul_tree_10_109[255:0]));
    assign mul_tree_10_109[257:256] = '0;
    assign mul_tree_10_110 = ({33'h0, rtlzz_pipe_100_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, rtlzz_pipe_103_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(162'(mul_tree_10_110)), .b(194'(mul_tree_10_111)), .cin(1'h0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = ({33'h0, rtlzz_pipe_106_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, rtlzz_pipe_109_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115Core rtlzz_owner_115(.a(226'(mul_tree_10_113)), .b(258'(mul_tree_10_114)), .cin(1'h0), .value(mul_tree_10_115[255:0]));
    assign mul_tree_10_115[258:256] = '0;
    assign mul_tree_10_116 = ({65'h0, rtlzz_pipe_112_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, rtlzz_pipe_115_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(195'(mul_tree_10_116)), .b(259'(mul_tree_10_117)), .cin(1'h0), .value(mul_tree_10_118[255:0]));
    assign mul_tree_10_118[259:256] = '0;
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_76_s1 <= 97'h0;
            rtlzz_pipe_79_s1 <= 161'h0;
            rtlzz_pipe_82_s1 <= 129'h0;
            rtlzz_pipe_85_s1 <= 193'h0;
            rtlzz_pipe_88_s1 <= 161'h0;
            rtlzz_pipe_91_s1 <= 225'h0;
            rtlzz_pipe_94_s1 <= 193'h0;
            rtlzz_pipe_97_s1 <= 257'h0;
            rtlzz_pipe_100_s2 <= 162'h0;
            rtlzz_pipe_103_s2 <= 194'h0;
            rtlzz_pipe_106_s2 <= 226'h0;
            rtlzz_pipe_109_s2 <= 258'h0;
            rtlzz_pipe_112_s3 <= 195'h0;
            rtlzz_pipe_115_s3 <= 259'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_100_s2 <= mul_tree_10_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= mul_tree_10_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= mul_tree_10_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= mul_tree_10_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_115_s3 <= mul_tree_10_115; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91Core(input wire [191:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [223:0] masked_b=((b&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [223:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [223:0] masked_a=((a&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffff000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [96:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [128:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [160:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [192:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [161:0] a,input wire [193:0] b,input wire cin,output wire [194:0] value);
wire [161:0] masked_a=((a&162'h3ffffffffffffffffffffffffffffffffffffffff)|162'h0);
wire [193:0] masked_b=((b&194'h3ffffffffffffffffffffffffffffffffffffffffffffffff)|194'h0);
wire [194:0] aa=195'(masked_b);
wire [194:0] bb=195'(masked_a);
wire [195:0] extended={1'b0,aa}+{1'b0,bb}+196'(1'b0);
wire [194:0] native_value=extended[194:0];
assign value=native_value[0+:195];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115Core(input wire [225:0] a,input wire [257:0] b,input wire cin,output wire [255:0] value);
wire [225:0] masked_a=((a&226'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|226'h0);
wire [257:0] masked_b=((b&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [257:0] aa=258'(masked_b);
wire [257:0] bb=258'(masked_a);
wire [258:0] extended={1'b0,aa}+{1'b0,bb}+259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [194:0] a,input wire [258:0] b,input wire cin,output wire [255:0] value);
wire [194:0] masked_a=((a&195'h7ffffffffffffffffffffffffffffffffffffffffffffffff)|195'h0);
wire [258:0] masked_b=((b&259'h7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|259'h0);
wire [258:0] aa=259'(masked_b);
wire [258:0] bb=259'(masked_a);
wire [259:0] extended={1'b0,aa}+{1'b0,bb}+260'(1'b0);
wire [258:0] native_value=extended[258:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
