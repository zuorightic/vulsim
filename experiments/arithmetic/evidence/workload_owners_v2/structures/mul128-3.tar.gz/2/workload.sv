`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
    logic [258:0] rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(32'(mul_tree_10_11)), .b(32'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(32'(mul_tree_10_14)), .b(32'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(32'(mul_tree_10_18)), .b(32'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(32'(mul_tree_10_22)), .b(32'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(32'(mul_tree_10_26)), .b(32'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(32'(mul_tree_10_30)), .b(32'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(32'(mul_tree_10_34)), .b(32'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(32'(mul_tree_10_38)), .b(32'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(32'(mul_tree_10_42)), .b(32'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_10_46)), .b(32'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(32'(mul_tree_10_50)), .b(32'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(32'(mul_tree_10_54)), .b(32'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(32'(mul_tree_10_58)), .b(32'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(32'(mul_tree_10_62)), .b(32'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(32'(mul_tree_10_66)), .b(32'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(32'(mul_tree_10_70)), .b(32'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(64'(mul_tree_10_74)), .b(96'(mul_tree_10_75)), .cin(1'h0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = ({33'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(128'(mul_tree_10_77)), .b(160'(mul_tree_10_78)), .cin(1'h0), .value(mul_tree_10_79));
    assign mul_tree_10_80 = ({33'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(96'(mul_tree_10_80)), .b(128'(mul_tree_10_81)), .cin(1'h0), .value(mul_tree_10_82));
    assign mul_tree_10_83 = ({33'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(160'(mul_tree_10_83)), .b(192'(mul_tree_10_84)), .cin(1'h0), .value(mul_tree_10_85));
    assign mul_tree_10_86 = ({33'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(128'(mul_tree_10_86)), .b(160'(mul_tree_10_87)), .cin(1'h0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = ({33'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_91Core rtlzz_owner_91(.a(192'(mul_tree_10_89)), .b(224'(mul_tree_10_90)), .cin(1'h0), .value(mul_tree_10_91));
    assign mul_tree_10_92 = ({33'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(160'(mul_tree_10_92)), .b(192'(mul_tree_10_93)), .cin(1'h0), .value(mul_tree_10_94));
    assign mul_tree_10_95 = ({33'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(224'(mul_tree_10_95)), .b(256'(mul_tree_10_96)), .cin(1'h0), .value(mul_tree_10_97[255:0]));
    assign mul_tree_10_97[256:256] = '0;
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({33'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112_reduce rtlzz_reduce_112(.i136(rtlzz_pipe_76_s2), .i137(rtlzz_pipe_79_s2), .i138(rtlzz_pipe_82_s2), .i139(rtlzz_pipe_85_s2), .y(mul_tree_10_112));
    assign mul_tree_10_113 = ({33'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115_reduce rtlzz_reduce_115(.i140(rtlzz_pipe_88_s2), .i141(rtlzz_pipe_91_s2), .i142(rtlzz_pipe_94_s2), .i143(rtlzz_pipe_97_s2), .y(mul_tree_10_115));
    assign mul_tree_10_116 = ({65'h0, rtlzz_pipe_112_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, rtlzz_pipe_115_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(195'(mul_tree_10_116)), .b(259'(mul_tree_10_117)), .cin(1'h0), .value(mul_tree_10_118[255:0]));
    assign mul_tree_10_118[259:256] = '0;
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 64'h0;
            rtlzz_pipe_17_s1 <= 96'h0;
            rtlzz_pipe_21_s1 <= 128'h0;
            rtlzz_pipe_25_s1 <= 160'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_37_s1 <= 160'h0;
            rtlzz_pipe_41_s1 <= 192'h0;
            rtlzz_pipe_45_s1 <= 128'h0;
            rtlzz_pipe_49_s1 <= 160'h0;
            rtlzz_pipe_53_s1 <= 192'h0;
            rtlzz_pipe_57_s1 <= 224'h0;
            rtlzz_pipe_61_s1 <= 160'h0;
            rtlzz_pipe_65_s1 <= 192'h0;
            rtlzz_pipe_69_s1 <= 224'h0;
            rtlzz_pipe_73_s1 <= 256'h0;
            rtlzz_pipe_76_s2 <= 97'h0;
            rtlzz_pipe_79_s2 <= 161'h0;
            rtlzz_pipe_82_s2 <= 129'h0;
            rtlzz_pipe_85_s2 <= 193'h0;
            rtlzz_pipe_88_s2 <= 161'h0;
            rtlzz_pipe_91_s2 <= 225'h0;
            rtlzz_pipe_94_s2 <= 193'h0;
            rtlzz_pipe_97_s2 <= 257'h0;
            rtlzz_pipe_112_s3 <= 195'h0;
            rtlzz_pipe_115_s3 <= 259'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_76_s2 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_79_s2 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_82_s2 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_85_s2 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_88_s2 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_91_s2 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_94_s2 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= mul_tree_10_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_115_s3 <= mul_tree_10_115; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112_reduce(input wire [96:0] i136, input wire [160:0] i137, input wire [128:0] i138, input wire [192:0] i139, output wire [194:0] y);
wire [194:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i136[96], i136[95], i136[94], i136[93], i136[92], i136[91], i136[90], i136[89], i136[88], i136[87], i136[86], i136[85], i136[84], i136[83], i136[82], i136[81], i136[80], i136[79], i136[78], i136[77], i136[76], i136[75], i136[74], i136[73], i136[72], i136[71], i136[70], i136[69], i136[68], i136[67], i136[66], i136[65], i136[64], i136[63], i136[62], i136[61], i136[60], i136[59], i136[58], i136[57], i136[56], i136[55], i136[54], i136[53], i136[52], i136[51], i136[50], i136[49], i136[48], i136[47], i136[46], i136[45], i136[44], i136[43], i136[42], i136[41], i136[40], i136[39], i136[38], i136[37], i136[36], i136[35], i136[34], i136[33], i136[32], i136[31], i136[30], i136[29], i136[28], i136[27], i136[26], i136[25], i136[24], i136[23], i136[22], i136[21], i136[20], i136[19], i136[18], i136[17], i136[16], i136[15], i136[14], i136[13], i136[12], i136[11], i136[10], i136[9], i136[8], i136[7], i136[6], i136[5], i136[4], i136[3], i136[2], i136[1], i136[0]};
wire [194:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i137[160], i137[159], i137[158], i137[157], i137[156], i137[155], i137[154], i137[153], i137[152], i137[151], i137[150], i137[149], i137[148], i137[147], i137[146], i137[145], i137[144], i137[143], i137[142], i137[141], i137[140], i137[139], i137[138], i137[137], i137[136], i137[135], i137[134], i137[133], i137[132], i137[131], i137[130], i137[129], i137[128], i137[127], i137[126], i137[125], i137[124], i137[123], i137[122], i137[121], i137[120], i137[119], i137[118], i137[117], i137[116], i137[115], i137[114], i137[113], i137[112], i137[111], i137[110], i137[109], i137[108], i137[107], i137[106], i137[105], i137[104], i137[103], i137[102], i137[101], i137[100], i137[99], i137[98], i137[97], i137[96], i137[95], i137[94], i137[93], i137[92], i137[91], i137[90], i137[89], i137[88], i137[87], i137[86], i137[85], i137[84], i137[83], i137[82], i137[81], i137[80], i137[79], i137[78], i137[77], i137[76], i137[75], i137[74], i137[73], i137[72], i137[71], i137[70], i137[69], i137[68], i137[67], i137[66], i137[65], i137[64], i137[63], i137[62], i137[61], i137[60], i137[59], i137[58], i137[57], i137[56], i137[55], i137[54], i137[53], i137[52], i137[51], i137[50], i137[49], i137[48], i137[47], i137[46], i137[45], i137[44], i137[43], i137[42], i137[41], i137[40], i137[39], i137[38], i137[37], i137[36], i137[35], i137[34], i137[33], i137[32], i137[31], i137[30], i137[29], i137[28], i137[27], i137[26], i137[25], i137[24], i137[23], i137[22], i137[21], i137[20], i137[19], i137[18], i137[17], i137[16], i137[15], i137[14], i137[13], i137[12], i137[11], i137[10], i137[9], i137[8], i137[7], i137[6], i137[5], i137[4], i137[3], i137[2], i137[1], i137[0]};
wire [194:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i138[128], i138[127], i138[126], i138[125], i138[124], i138[123], i138[122], i138[121], i138[120], i138[119], i138[118], i138[117], i138[116], i138[115], i138[114], i138[113], i138[112], i138[111], i138[110], i138[109], i138[108], i138[107], i138[106], i138[105], i138[104], i138[103], i138[102], i138[101], i138[100], i138[99], i138[98], i138[97], i138[96], i138[95], i138[94], i138[93], i138[92], i138[91], i138[90], i138[89], i138[88], i138[87], i138[86], i138[85], i138[84], i138[83], i138[82], i138[81], i138[80], i138[79], i138[78], i138[77], i138[76], i138[75], i138[74], i138[73], i138[72], i138[71], i138[70], i138[69], i138[68], i138[67], i138[66], i138[65], i138[64], i138[63], i138[62], i138[61], i138[60], i138[59], i138[58], i138[57], i138[56], i138[55], i138[54], i138[53], i138[52], i138[51], i138[50], i138[49], i138[48], i138[47], i138[46], i138[45], i138[44], i138[43], i138[42], i138[41], i138[40], i138[39], i138[38], i138[37], i138[36], i138[35], i138[34], i138[33], i138[32], i138[31], i138[30], i138[29], i138[28], i138[27], i138[26], i138[25], i138[24], i138[23], i138[22], i138[21], i138[20], i138[19], i138[18], i138[17], i138[16], i138[15], i138[14], i138[13], i138[12], i138[11], i138[10], i138[9], i138[8], i138[7], i138[6], i138[5], i138[4], i138[3], i138[2], i138[1], i138[0]};
wire [194:0] t3 = {1'b0, 1'b0, i139[192], i139[191], i139[190], i139[189], i139[188], i139[187], i139[186], i139[185], i139[184], i139[183], i139[182], i139[181], i139[180], i139[179], i139[178], i139[177], i139[176], i139[175], i139[174], i139[173], i139[172], i139[171], i139[170], i139[169], i139[168], i139[167], i139[166], i139[165], i139[164], i139[163], i139[162], i139[161], i139[160], i139[159], i139[158], i139[157], i139[156], i139[155], i139[154], i139[153], i139[152], i139[151], i139[150], i139[149], i139[148], i139[147], i139[146], i139[145], i139[144], i139[143], i139[142], i139[141], i139[140], i139[139], i139[138], i139[137], i139[136], i139[135], i139[134], i139[133], i139[132], i139[131], i139[130], i139[129], i139[128], i139[127], i139[126], i139[125], i139[124], i139[123], i139[122], i139[121], i139[120], i139[119], i139[118], i139[117], i139[116], i139[115], i139[114], i139[113], i139[112], i139[111], i139[110], i139[109], i139[108], i139[107], i139[106], i139[105], i139[104], i139[103], i139[102], i139[101], i139[100], i139[99], i139[98], i139[97], i139[96], i139[95], i139[94], i139[93], i139[92], i139[91], i139[90], i139[89], i139[88], i139[87], i139[86], i139[85], i139[84], i139[83], i139[82], i139[81], i139[80], i139[79], i139[78], i139[77], i139[76], i139[75], i139[74], i139[73], i139[72], i139[71], i139[70], i139[69], i139[68], i139[67], i139[66], i139[65], i139[64], i139[63], i139[62], i139[61], i139[60], i139[59], i139[58], i139[57], i139[56], i139[55], i139[54], i139[53], i139[52], i139[51], i139[50], i139[49], i139[48], i139[47], i139[46], i139[45], i139[44], i139[43], i139[42], i139[41], i139[40], i139[39], i139[38], i139[37], i139[36], i139[35], i139[34], i139[33], i139[32], i139[31], i139[30], i139[29], i139[28], i139[27], i139[26], i139[25], i139[24], i139[23], i139[22], i139[21], i139[20], i139[19], i139[18], i139[17], i139[16], i139[15], i139[14], i139[13], i139[12], i139[11], i139[10], i139[9], i139[8], i139[7], i139[6], i139[5], i139[4], i139[3], i139[2], i139[1], i139[0]};
wire [194:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115_reduce(input wire [160:0] i140, input wire [224:0] i141, input wire [192:0] i142, input wire [256:0] i143, output wire [258:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i140[160], i140[159], i140[158], i140[157], i140[156], i140[155], i140[154], i140[153], i140[152], i140[151], i140[150], i140[149], i140[148], i140[147], i140[146], i140[145], i140[144], i140[143], i140[142], i140[141], i140[140], i140[139], i140[138], i140[137], i140[136], i140[135], i140[134], i140[133], i140[132], i140[131], i140[130], i140[129], i140[128], i140[127], i140[126], i140[125], i140[124], i140[123], i140[122], i140[121], i140[120], i140[119], i140[118], i140[117], i140[116], i140[115], i140[114], i140[113], i140[112], i140[111], i140[110], i140[109], i140[108], i140[107], i140[106], i140[105], i140[104], i140[103], i140[102], i140[101], i140[100], i140[99], i140[98], i140[97], i140[96], i140[95], i140[94], i140[93], i140[92], i140[91], i140[90], i140[89], i140[88], i140[87], i140[86], i140[85], i140[84], i140[83], i140[82], i140[81], i140[80], i140[79], i140[78], i140[77], i140[76], i140[75], i140[74], i140[73], i140[72], i140[71], i140[70], i140[69], i140[68], i140[67], i140[66], i140[65], i140[64], i140[63], i140[62], i140[61], i140[60], i140[59], i140[58], i140[57], i140[56], i140[55], i140[54], i140[53], i140[52], i140[51], i140[50], i140[49], i140[48], i140[47], i140[46], i140[45], i140[44], i140[43], i140[42], i140[41], i140[40], i140[39], i140[38], i140[37], i140[36], i140[35], i140[34], i140[33], i140[32], i140[31], i140[30], i140[29], i140[28], i140[27], i140[26], i140[25], i140[24], i140[23], i140[22], i140[21], i140[20], i140[19], i140[18], i140[17], i140[16], i140[15], i140[14], i140[13], i140[12], i140[11], i140[10], i140[9], i140[8], i140[7], i140[6], i140[5], i140[4], i140[3], i140[2], i140[1], i140[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i141[224], i141[223], i141[222], i141[221], i141[220], i141[219], i141[218], i141[217], i141[216], i141[215], i141[214], i141[213], i141[212], i141[211], i141[210], i141[209], i141[208], i141[207], i141[206], i141[205], i141[204], i141[203], i141[202], i141[201], i141[200], i141[199], i141[198], i141[197], i141[196], i141[195], i141[194], i141[193], i141[192], i141[191], i141[190], i141[189], i141[188], i141[187], i141[186], i141[185], i141[184], i141[183], i141[182], i141[181], i141[180], i141[179], i141[178], i141[177], i141[176], i141[175], i141[174], i141[173], i141[172], i141[171], i141[170], i141[169], i141[168], i141[167], i141[166], i141[165], i141[164], i141[163], i141[162], i141[161], i141[160], i141[159], i141[158], i141[157], i141[156], i141[155], i141[154], i141[153], i141[152], i141[151], i141[150], i141[149], i141[148], i141[147], i141[146], i141[145], i141[144], i141[143], i141[142], i141[141], i141[140], i141[139], i141[138], i141[137], i141[136], i141[135], i141[134], i141[133], i141[132], i141[131], i141[130], i141[129], i141[128], i141[127], i141[126], i141[125], i141[124], i141[123], i141[122], i141[121], i141[120], i141[119], i141[118], i141[117], i141[116], i141[115], i141[114], i141[113], i141[112], i141[111], i141[110], i141[109], i141[108], i141[107], i141[106], i141[105], i141[104], i141[103], i141[102], i141[101], i141[100], i141[99], i141[98], i141[97], i141[96], i141[95], i141[94], i141[93], i141[92], i141[91], i141[90], i141[89], i141[88], i141[87], i141[86], i141[85], i141[84], i141[83], i141[82], i141[81], i141[80], i141[79], i141[78], i141[77], i141[76], i141[75], i141[74], i141[73], i141[72], i141[71], i141[70], i141[69], i141[68], i141[67], i141[66], i141[65], i141[64], i141[63], i141[62], i141[61], i141[60], i141[59], i141[58], i141[57], i141[56], i141[55], i141[54], i141[53], i141[52], i141[51], i141[50], i141[49], i141[48], i141[47], i141[46], i141[45], i141[44], i141[43], i141[42], i141[41], i141[40], i141[39], i141[38], i141[37], i141[36], i141[35], i141[34], i141[33], i141[32], i141[31], i141[30], i141[29], i141[28], i141[27], i141[26], i141[25], i141[24], i141[23], i141[22], i141[21], i141[20], i141[19], i141[18], i141[17], i141[16], i141[15], i141[14], i141[13], i141[12], i141[11], i141[10], i141[9], i141[8], i141[7], i141[6], i141[5], i141[4], i141[3], i141[2], i141[1], i141[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i142[192], i142[191], i142[190], i142[189], i142[188], i142[187], i142[186], i142[185], i142[184], i142[183], i142[182], i142[181], i142[180], i142[179], i142[178], i142[177], i142[176], i142[175], i142[174], i142[173], i142[172], i142[171], i142[170], i142[169], i142[168], i142[167], i142[166], i142[165], i142[164], i142[163], i142[162], i142[161], i142[160], i142[159], i142[158], i142[157], i142[156], i142[155], i142[154], i142[153], i142[152], i142[151], i142[150], i142[149], i142[148], i142[147], i142[146], i142[145], i142[144], i142[143], i142[142], i142[141], i142[140], i142[139], i142[138], i142[137], i142[136], i142[135], i142[134], i142[133], i142[132], i142[131], i142[130], i142[129], i142[128], i142[127], i142[126], i142[125], i142[124], i142[123], i142[122], i142[121], i142[120], i142[119], i142[118], i142[117], i142[116], i142[115], i142[114], i142[113], i142[112], i142[111], i142[110], i142[109], i142[108], i142[107], i142[106], i142[105], i142[104], i142[103], i142[102], i142[101], i142[100], i142[99], i142[98], i142[97], i142[96], i142[95], i142[94], i142[93], i142[92], i142[91], i142[90], i142[89], i142[88], i142[87], i142[86], i142[85], i142[84], i142[83], i142[82], i142[81], i142[80], i142[79], i142[78], i142[77], i142[76], i142[75], i142[74], i142[73], i142[72], i142[71], i142[70], i142[69], i142[68], i142[67], i142[66], i142[65], i142[64], i142[63], i142[62], i142[61], i142[60], i142[59], i142[58], i142[57], i142[56], i142[55], i142[54], i142[53], i142[52], i142[51], i142[50], i142[49], i142[48], i142[47], i142[46], i142[45], i142[44], i142[43], i142[42], i142[41], i142[40], i142[39], i142[38], i142[37], i142[36], i142[35], i142[34], i142[33], i142[32], i142[31], i142[30], i142[29], i142[28], i142[27], i142[26], i142[25], i142[24], i142[23], i142[22], i142[21], i142[20], i142[19], i142[18], i142[17], i142[16], i142[15], i142[14], i142[13], i142[12], i142[11], i142[10], i142[9], i142[8], i142[7], i142[6], i142[5], i142[4], i142[3], i142[2], i142[1], i142[0]};
wire [255:0] t3 = {i143[255], i143[254], i143[253], i143[252], i143[251], i143[250], i143[249], i143[248], i143[247], i143[246], i143[245], i143[244], i143[243], i143[242], i143[241], i143[240], i143[239], i143[238], i143[237], i143[236], i143[235], i143[234], i143[233], i143[232], i143[231], i143[230], i143[229], i143[228], i143[227], i143[226], i143[225], i143[224], i143[223], i143[222], i143[221], i143[220], i143[219], i143[218], i143[217], i143[216], i143[215], i143[214], i143[213], i143[212], i143[211], i143[210], i143[209], i143[208], i143[207], i143[206], i143[205], i143[204], i143[203], i143[202], i143[201], i143[200], i143[199], i143[198], i143[197], i143[196], i143[195], i143[194], i143[193], i143[192], i143[191], i143[190], i143[189], i143[188], i143[187], i143[186], i143[185], i143[184], i143[183], i143[182], i143[181], i143[180], i143[179], i143[178], i143[177], i143[176], i143[175], i143[174], i143[173], i143[172], i143[171], i143[170], i143[169], i143[168], i143[167], i143[166], i143[165], i143[164], i143[163], i143[162], i143[161], i143[160], i143[159], i143[158], i143[157], i143[156], i143[155], i143[154], i143[153], i143[152], i143[151], i143[150], i143[149], i143[148], i143[147], i143[146], i143[145], i143[144], i143[143], i143[142], i143[141], i143[140], i143[139], i143[138], i143[137], i143[136], i143[135], i143[134], i143[133], i143[132], i143[131], i143[130], i143[129], i143[128], i143[127], i143[126], i143[125], i143[124], i143[123], i143[122], i143[121], i143[120], i143[119], i143[118], i143[117], i143[116], i143[115], i143[114], i143[113], i143[112], i143[111], i143[110], i143[109], i143[108], i143[107], i143[106], i143[105], i143[104], i143[103], i143[102], i143[101], i143[100], i143[99], i143[98], i143[97], i143[96], i143[95], i143[94], i143[93], i143[92], i143[91], i143[90], i143[89], i143[88], i143[87], i143[86], i143[85], i143[84], i143[83], i143[82], i143[81], i143[80], i143[79], i143[78], i143[77], i143[76], i143[75], i143[74], i143[73], i143[72], i143[71], i143[70], i143[69], i143[68], i143[67], i143[66], i143[65], i143[64], i143[63], i143[62], i143[61], i143[60], i143[59], i143[58], i143[57], i143[56], i143[55], i143[54], i143[53], i143[52], i143[51], i143[50], i143[49], i143[48], i143[47], i143[46], i143[45], i143[44], i143[43], i143[42], i143[41], i143[40], i143[39], i143[38], i143[37], i143[36], i143[35], i143[34], i143[33], i143[32], i143[31], i143[30], i143[29], i143[28], i143[27], i143[26], i143[25], i143[24], i143[23], i143[22], i143[21], i143[20], i143[19], i143[18], i143[17], i143[16], i143[15], i143[14], i143[13], i143[12], i143[11], i143[10], i143[9], i143[8], i143[7], i143[6], i143[5], i143[4], i143[3], i143[2], i143[1], i143[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91Core(input wire [191:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [223:0] masked_b=((b&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [223:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [223:0] masked_a=((a&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffff000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [194:0] a,input wire [258:0] b,input wire cin,output wire [255:0] value);
wire [194:0] masked_a=((a&195'h7ffffffffffffffffffffffffffffffffffffffffffffffff)|195'h0);
wire [258:0] masked_b=((b&259'h7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|259'h0);
wire [258:0] aa=259'(masked_b);
wire [258:0] bb=259'(masked_a);
wire [259:0] extended={1'b0,aa}+{1'b0,bb}+260'(1'b0);
wire [258:0] native_value=extended[258:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
