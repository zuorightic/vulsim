`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_3_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(32'(mul_tree_10_11)), .b(32'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(32'(mul_tree_10_14)), .b(32'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(32'(mul_tree_10_18)), .b(32'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(32'(mul_tree_10_22)), .b(32'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(32'(mul_tree_10_26)), .b(32'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(32'(mul_tree_10_30)), .b(32'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(32'(mul_tree_10_34)), .b(32'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(32'(mul_tree_10_38)), .b(32'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(32'(mul_tree_10_42)), .b(32'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_10_46)), .b(32'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(32'(mul_tree_10_50)), .b(32'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(32'(mul_tree_10_54)), .b(32'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(32'(mul_tree_10_58)), .b(32'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(32'(mul_tree_10_62)), .b(32'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(32'(mul_tree_10_66)), .b(32'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(32'(mul_tree_10_70)), .b(32'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(64'(mul_tree_10_74)), .b(96'(mul_tree_10_75)), .cin(1'h0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = ({33'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(128'(mul_tree_10_77)), .b(160'(mul_tree_10_78)), .cin(1'h0), .value(mul_tree_10_79));
    assign mul_tree_10_80 = ({33'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(96'(mul_tree_10_80)), .b(128'(mul_tree_10_81)), .cin(1'h0), .value(mul_tree_10_82));
    assign mul_tree_10_83 = ({33'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(160'(mul_tree_10_83)), .b(192'(mul_tree_10_84)), .cin(1'h0), .value(mul_tree_10_85));
    assign mul_tree_10_86 = ({33'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(128'(mul_tree_10_86)), .b(160'(mul_tree_10_87)), .cin(1'h0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = ({33'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_91Core rtlzz_owner_91(.a(192'(mul_tree_10_89)), .b(224'(mul_tree_10_90)), .cin(1'h0), .value(mul_tree_10_91));
    assign mul_tree_10_92 = ({33'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(160'(mul_tree_10_92)), .b(192'(mul_tree_10_93)), .cin(1'h0), .value(mul_tree_10_94));
    assign mul_tree_10_95 = ({33'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(224'(mul_tree_10_95)), .b(256'(mul_tree_10_96)), .cin(1'h0), .value(mul_tree_10_97[255:0]));
    assign mul_tree_10_97[256:256] = '0;
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(97'(mul_tree_10_98)), .b(161'(mul_tree_10_99)), .cin(1'h0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(129'(mul_tree_10_101)), .b(193'(mul_tree_10_102)), .cin(1'h0), .value(mul_tree_10_103));
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(161'(mul_tree_10_104)), .b(225'(mul_tree_10_105)), .cin(1'h0), .value(mul_tree_10_106));
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(193'(mul_tree_10_107)), .b(257'(mul_tree_10_108)), .cin(1'h0), .value(mul_tree_10_109[255:0]));
    assign mul_tree_10_109[257:256] = '0;
    assign mul_tree_10_110 = ({33'h0, rtlzz_pipe_100_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, rtlzz_pipe_103_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({33'h0, rtlzz_pipe_106_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, rtlzz_pipe_109_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({65'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118_reduce rtlzz_reduce_118(.i128(rtlzz_pipe_100_s2), .i129(rtlzz_pipe_103_s2), .i130(rtlzz_pipe_106_s2), .i131(rtlzz_pipe_109_s2), .y(mul_tree_10_118));
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_76_s1 <= 97'h0;
            rtlzz_pipe_79_s1 <= 161'h0;
            rtlzz_pipe_82_s1 <= 129'h0;
            rtlzz_pipe_85_s1 <= 193'h0;
            rtlzz_pipe_88_s1 <= 161'h0;
            rtlzz_pipe_91_s1 <= 225'h0;
            rtlzz_pipe_94_s1 <= 193'h0;
            rtlzz_pipe_97_s1 <= 257'h0;
            rtlzz_pipe_100_s2 <= 162'h0;
            rtlzz_pipe_103_s2 <= 194'h0;
            rtlzz_pipe_106_s2 <= 226'h0;
            rtlzz_pipe_109_s2 <= 258'h0;
            rtlzz_pipe_3_s3 <= 256'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_100_s2 <= mul_tree_10_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= mul_tree_10_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= mul_tree_10_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118_reduce(input wire [161:0] i128, input wire [193:0] i129, input wire [225:0] i130, input wire [257:0] i131, output wire [259:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i128[161], i128[160], i128[159], i128[158], i128[157], i128[156], i128[155], i128[154], i128[153], i128[152], i128[151], i128[150], i128[149], i128[148], i128[147], i128[146], i128[145], i128[144], i128[143], i128[142], i128[141], i128[140], i128[139], i128[138], i128[137], i128[136], i128[135], i128[134], i128[133], i128[132], i128[131], i128[130], i128[129], i128[128], i128[127], i128[126], i128[125], i128[124], i128[123], i128[122], i128[121], i128[120], i128[119], i128[118], i128[117], i128[116], i128[115], i128[114], i128[113], i128[112], i128[111], i128[110], i128[109], i128[108], i128[107], i128[106], i128[105], i128[104], i128[103], i128[102], i128[101], i128[100], i128[99], i128[98], i128[97], i128[96], i128[95], i128[94], i128[93], i128[92], i128[91], i128[90], i128[89], i128[88], i128[87], i128[86], i128[85], i128[84], i128[83], i128[82], i128[81], i128[80], i128[79], i128[78], i128[77], i128[76], i128[75], i128[74], i128[73], i128[72], i128[71], i128[70], i128[69], i128[68], i128[67], i128[66], i128[65], i128[64], i128[63], i128[62], i128[61], i128[60], i128[59], i128[58], i128[57], i128[56], i128[55], i128[54], i128[53], i128[52], i128[51], i128[50], i128[49], i128[48], i128[47], i128[46], i128[45], i128[44], i128[43], i128[42], i128[41], i128[40], i128[39], i128[38], i128[37], i128[36], i128[35], i128[34], i128[33], i128[32], i128[31], i128[30], i128[29], i128[28], i128[27], i128[26], i128[25], i128[24], i128[23], i128[22], i128[21], i128[20], i128[19], i128[18], i128[17], i128[16], i128[15], i128[14], i128[13], i128[12], i128[11], i128[10], i128[9], i128[8], i128[7], i128[6], i128[5], i128[4], i128[3], i128[2], i128[1], i128[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i129[193], i129[192], i129[191], i129[190], i129[189], i129[188], i129[187], i129[186], i129[185], i129[184], i129[183], i129[182], i129[181], i129[180], i129[179], i129[178], i129[177], i129[176], i129[175], i129[174], i129[173], i129[172], i129[171], i129[170], i129[169], i129[168], i129[167], i129[166], i129[165], i129[164], i129[163], i129[162], i129[161], i129[160], i129[159], i129[158], i129[157], i129[156], i129[155], i129[154], i129[153], i129[152], i129[151], i129[150], i129[149], i129[148], i129[147], i129[146], i129[145], i129[144], i129[143], i129[142], i129[141], i129[140], i129[139], i129[138], i129[137], i129[136], i129[135], i129[134], i129[133], i129[132], i129[131], i129[130], i129[129], i129[128], i129[127], i129[126], i129[125], i129[124], i129[123], i129[122], i129[121], i129[120], i129[119], i129[118], i129[117], i129[116], i129[115], i129[114], i129[113], i129[112], i129[111], i129[110], i129[109], i129[108], i129[107], i129[106], i129[105], i129[104], i129[103], i129[102], i129[101], i129[100], i129[99], i129[98], i129[97], i129[96], i129[95], i129[94], i129[93], i129[92], i129[91], i129[90], i129[89], i129[88], i129[87], i129[86], i129[85], i129[84], i129[83], i129[82], i129[81], i129[80], i129[79], i129[78], i129[77], i129[76], i129[75], i129[74], i129[73], i129[72], i129[71], i129[70], i129[69], i129[68], i129[67], i129[66], i129[65], i129[64], i129[63], i129[62], i129[61], i129[60], i129[59], i129[58], i129[57], i129[56], i129[55], i129[54], i129[53], i129[52], i129[51], i129[50], i129[49], i129[48], i129[47], i129[46], i129[45], i129[44], i129[43], i129[42], i129[41], i129[40], i129[39], i129[38], i129[37], i129[36], i129[35], i129[34], i129[33], i129[32], i129[31], i129[30], i129[29], i129[28], i129[27], i129[26], i129[25], i129[24], i129[23], i129[22], i129[21], i129[20], i129[19], i129[18], i129[17], i129[16], i129[15], i129[14], i129[13], i129[12], i129[11], i129[10], i129[9], i129[8], i129[7], i129[6], i129[5], i129[4], i129[3], i129[2], i129[1], i129[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i130[225], i130[224], i130[223], i130[222], i130[221], i130[220], i130[219], i130[218], i130[217], i130[216], i130[215], i130[214], i130[213], i130[212], i130[211], i130[210], i130[209], i130[208], i130[207], i130[206], i130[205], i130[204], i130[203], i130[202], i130[201], i130[200], i130[199], i130[198], i130[197], i130[196], i130[195], i130[194], i130[193], i130[192], i130[191], i130[190], i130[189], i130[188], i130[187], i130[186], i130[185], i130[184], i130[183], i130[182], i130[181], i130[180], i130[179], i130[178], i130[177], i130[176], i130[175], i130[174], i130[173], i130[172], i130[171], i130[170], i130[169], i130[168], i130[167], i130[166], i130[165], i130[164], i130[163], i130[162], i130[161], i130[160], i130[159], i130[158], i130[157], i130[156], i130[155], i130[154], i130[153], i130[152], i130[151], i130[150], i130[149], i130[148], i130[147], i130[146], i130[145], i130[144], i130[143], i130[142], i130[141], i130[140], i130[139], i130[138], i130[137], i130[136], i130[135], i130[134], i130[133], i130[132], i130[131], i130[130], i130[129], i130[128], i130[127], i130[126], i130[125], i130[124], i130[123], i130[122], i130[121], i130[120], i130[119], i130[118], i130[117], i130[116], i130[115], i130[114], i130[113], i130[112], i130[111], i130[110], i130[109], i130[108], i130[107], i130[106], i130[105], i130[104], i130[103], i130[102], i130[101], i130[100], i130[99], i130[98], i130[97], i130[96], i130[95], i130[94], i130[93], i130[92], i130[91], i130[90], i130[89], i130[88], i130[87], i130[86], i130[85], i130[84], i130[83], i130[82], i130[81], i130[80], i130[79], i130[78], i130[77], i130[76], i130[75], i130[74], i130[73], i130[72], i130[71], i130[70], i130[69], i130[68], i130[67], i130[66], i130[65], i130[64], i130[63], i130[62], i130[61], i130[60], i130[59], i130[58], i130[57], i130[56], i130[55], i130[54], i130[53], i130[52], i130[51], i130[50], i130[49], i130[48], i130[47], i130[46], i130[45], i130[44], i130[43], i130[42], i130[41], i130[40], i130[39], i130[38], i130[37], i130[36], i130[35], i130[34], i130[33], i130[32], i130[31], i130[30], i130[29], i130[28], i130[27], i130[26], i130[25], i130[24], i130[23], i130[22], i130[21], i130[20], i130[19], i130[18], i130[17], i130[16], i130[15], i130[14], i130[13], i130[12], i130[11], i130[10], i130[9], i130[8], i130[7], i130[6], i130[5], i130[4], i130[3], i130[2], i130[1], i130[0]};
wire [255:0] t3 = {i131[255], i131[254], i131[253], i131[252], i131[251], i131[250], i131[249], i131[248], i131[247], i131[246], i131[245], i131[244], i131[243], i131[242], i131[241], i131[240], i131[239], i131[238], i131[237], i131[236], i131[235], i131[234], i131[233], i131[232], i131[231], i131[230], i131[229], i131[228], i131[227], i131[226], i131[225], i131[224], i131[223], i131[222], i131[221], i131[220], i131[219], i131[218], i131[217], i131[216], i131[215], i131[214], i131[213], i131[212], i131[211], i131[210], i131[209], i131[208], i131[207], i131[206], i131[205], i131[204], i131[203], i131[202], i131[201], i131[200], i131[199], i131[198], i131[197], i131[196], i131[195], i131[194], i131[193], i131[192], i131[191], i131[190], i131[189], i131[188], i131[187], i131[186], i131[185], i131[184], i131[183], i131[182], i131[181], i131[180], i131[179], i131[178], i131[177], i131[176], i131[175], i131[174], i131[173], i131[172], i131[171], i131[170], i131[169], i131[168], i131[167], i131[166], i131[165], i131[164], i131[163], i131[162], i131[161], i131[160], i131[159], i131[158], i131[157], i131[156], i131[155], i131[154], i131[153], i131[152], i131[151], i131[150], i131[149], i131[148], i131[147], i131[146], i131[145], i131[144], i131[143], i131[142], i131[141], i131[140], i131[139], i131[138], i131[137], i131[136], i131[135], i131[134], i131[133], i131[132], i131[131], i131[130], i131[129], i131[128], i131[127], i131[126], i131[125], i131[124], i131[123], i131[122], i131[121], i131[120], i131[119], i131[118], i131[117], i131[116], i131[115], i131[114], i131[113], i131[112], i131[111], i131[110], i131[109], i131[108], i131[107], i131[106], i131[105], i131[104], i131[103], i131[102], i131[101], i131[100], i131[99], i131[98], i131[97], i131[96], i131[95], i131[94], i131[93], i131[92], i131[91], i131[90], i131[89], i131[88], i131[87], i131[86], i131[85], i131[84], i131[83], i131[82], i131[81], i131[80], i131[79], i131[78], i131[77], i131[76], i131[75], i131[74], i131[73], i131[72], i131[71], i131[70], i131[69], i131[68], i131[67], i131[66], i131[65], i131[64], i131[63], i131[62], i131[61], i131[60], i131[59], i131[58], i131[57], i131[56], i131[55], i131[54], i131[53], i131[52], i131[51], i131[50], i131[49], i131[48], i131[47], i131[46], i131[45], i131[44], i131[43], i131[42], i131[41], i131[40], i131[39], i131[38], i131[37], i131[36], i131[35], i131[34], i131[33], i131[32], i131[31], i131[30], i131[29], i131[28], i131[27], i131[26], i131[25], i131[24], i131[23], i131[22], i131[21], i131[20], i131[19], i131[18], i131[17], i131[16], i131[15], i131[14], i131[13], i131[12], i131[11], i131[10], i131[9], i131[8], i131[7], i131[6], i131[5], i131[4], i131[3], i131[2], i131[1], i131[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91Core(input wire [191:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [223:0] masked_b=((b&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [223:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [223:0] masked_a=((a&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffff000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [96:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [128:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [160:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [192:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
