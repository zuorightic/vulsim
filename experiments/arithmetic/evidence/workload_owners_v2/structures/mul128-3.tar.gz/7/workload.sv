`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(32'(mul_tree_10_11)), .b(32'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(32'(mul_tree_10_14)), .b(32'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(32'(mul_tree_10_18)), .b(32'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(32'(mul_tree_10_22)), .b(32'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(32'(mul_tree_10_26)), .b(32'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(32'(mul_tree_10_30)), .b(32'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(32'(mul_tree_10_34)), .b(32'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(32'(mul_tree_10_38)), .b(32'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(32'(mul_tree_10_42)), .b(32'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(32'(mul_tree_10_46)), .b(32'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(32'(mul_tree_10_50)), .b(32'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(32'(mul_tree_10_54)), .b(32'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(32'(mul_tree_10_58)), .b(32'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(32'(mul_tree_10_62)), .b(32'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(32'(mul_tree_10_66)), .b(32'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(32'(mul_tree_10_70)), .b(32'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(64'(mul_tree_10_74)), .b(96'(mul_tree_10_75)), .cin(1'h0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = ({33'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(128'(mul_tree_10_77)), .b(160'(mul_tree_10_78)), .cin(1'h0), .value(mul_tree_10_79));
    assign mul_tree_10_80 = ({33'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(96'(mul_tree_10_80)), .b(128'(mul_tree_10_81)), .cin(1'h0), .value(mul_tree_10_82));
    assign mul_tree_10_83 = ({33'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(160'(mul_tree_10_83)), .b(192'(mul_tree_10_84)), .cin(1'h0), .value(mul_tree_10_85));
    assign mul_tree_10_86 = ({33'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(128'(mul_tree_10_86)), .b(160'(mul_tree_10_87)), .cin(1'h0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = ({33'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_91Core rtlzz_owner_91(.a(192'(mul_tree_10_89)), .b(224'(mul_tree_10_90)), .cin(1'h0), .value(mul_tree_10_91));
    assign mul_tree_10_92 = ({33'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(160'(mul_tree_10_92)), .b(192'(mul_tree_10_93)), .cin(1'h0), .value(mul_tree_10_94));
    assign mul_tree_10_95 = ({33'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(224'(mul_tree_10_95)), .b(256'(mul_tree_10_96)), .cin(1'h0), .value(mul_tree_10_97[255:0]));
    assign mul_tree_10_97[256:256] = '0;
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(97'(mul_tree_10_98)), .b(161'(mul_tree_10_99)), .cin(1'h0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(129'(mul_tree_10_101)), .b(193'(mul_tree_10_102)), .cin(1'h0), .value(mul_tree_10_103));
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(161'(mul_tree_10_104)), .b(225'(mul_tree_10_105)), .cin(1'h0), .value(mul_tree_10_106));
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(193'(mul_tree_10_107)), .b(257'(mul_tree_10_108)), .cin(1'h0), .value(mul_tree_10_109[255:0]));
    assign mul_tree_10_109[257:256] = '0;
    assign mul_tree_10_110 = ({33'h0, rtlzz_pipe_100_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, rtlzz_pipe_103_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({33'h0, rtlzz_pipe_106_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, rtlzz_pipe_109_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({65'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118_reduce rtlzz_reduce_118(.i136(rtlzz_pipe_100_s3), .i137(rtlzz_pipe_103_s3), .i138(rtlzz_pipe_106_s3), .i139(rtlzz_pipe_109_s3), .y(mul_tree_10_118));
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_76_s1 <= 97'h0;
            rtlzz_pipe_76_s2 <= 97'h0;
            rtlzz_pipe_79_s1 <= 161'h0;
            rtlzz_pipe_79_s2 <= 161'h0;
            rtlzz_pipe_82_s1 <= 129'h0;
            rtlzz_pipe_82_s2 <= 129'h0;
            rtlzz_pipe_85_s1 <= 193'h0;
            rtlzz_pipe_85_s2 <= 193'h0;
            rtlzz_pipe_88_s1 <= 161'h0;
            rtlzz_pipe_88_s2 <= 161'h0;
            rtlzz_pipe_91_s1 <= 225'h0;
            rtlzz_pipe_91_s2 <= 225'h0;
            rtlzz_pipe_94_s1 <= 193'h0;
            rtlzz_pipe_94_s2 <= 193'h0;
            rtlzz_pipe_97_s1 <= 257'h0;
            rtlzz_pipe_97_s2 <= 257'h0;
            rtlzz_pipe_100_s3 <= 162'h0;
            rtlzz_pipe_103_s3 <= 194'h0;
            rtlzz_pipe_106_s3 <= 226'h0;
            rtlzz_pipe_109_s3 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_76_s2 <= rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_79_s2 <= rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_82_s2 <= rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_85_s2 <= rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_88_s2 <= rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_91_s2 <= rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_94_s2 <= rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= mul_tree_10_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= mul_tree_10_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= mul_tree_10_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118_reduce(input wire [161:0] i136, input wire [193:0] i137, input wire [225:0] i138, input wire [257:0] i139, output wire [259:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i136[161], i136[160], i136[159], i136[158], i136[157], i136[156], i136[155], i136[154], i136[153], i136[152], i136[151], i136[150], i136[149], i136[148], i136[147], i136[146], i136[145], i136[144], i136[143], i136[142], i136[141], i136[140], i136[139], i136[138], i136[137], i136[136], i136[135], i136[134], i136[133], i136[132], i136[131], i136[130], i136[129], i136[128], i136[127], i136[126], i136[125], i136[124], i136[123], i136[122], i136[121], i136[120], i136[119], i136[118], i136[117], i136[116], i136[115], i136[114], i136[113], i136[112], i136[111], i136[110], i136[109], i136[108], i136[107], i136[106], i136[105], i136[104], i136[103], i136[102], i136[101], i136[100], i136[99], i136[98], i136[97], i136[96], i136[95], i136[94], i136[93], i136[92], i136[91], i136[90], i136[89], i136[88], i136[87], i136[86], i136[85], i136[84], i136[83], i136[82], i136[81], i136[80], i136[79], i136[78], i136[77], i136[76], i136[75], i136[74], i136[73], i136[72], i136[71], i136[70], i136[69], i136[68], i136[67], i136[66], i136[65], i136[64], i136[63], i136[62], i136[61], i136[60], i136[59], i136[58], i136[57], i136[56], i136[55], i136[54], i136[53], i136[52], i136[51], i136[50], i136[49], i136[48], i136[47], i136[46], i136[45], i136[44], i136[43], i136[42], i136[41], i136[40], i136[39], i136[38], i136[37], i136[36], i136[35], i136[34], i136[33], i136[32], i136[31], i136[30], i136[29], i136[28], i136[27], i136[26], i136[25], i136[24], i136[23], i136[22], i136[21], i136[20], i136[19], i136[18], i136[17], i136[16], i136[15], i136[14], i136[13], i136[12], i136[11], i136[10], i136[9], i136[8], i136[7], i136[6], i136[5], i136[4], i136[3], i136[2], i136[1], i136[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i137[193], i137[192], i137[191], i137[190], i137[189], i137[188], i137[187], i137[186], i137[185], i137[184], i137[183], i137[182], i137[181], i137[180], i137[179], i137[178], i137[177], i137[176], i137[175], i137[174], i137[173], i137[172], i137[171], i137[170], i137[169], i137[168], i137[167], i137[166], i137[165], i137[164], i137[163], i137[162], i137[161], i137[160], i137[159], i137[158], i137[157], i137[156], i137[155], i137[154], i137[153], i137[152], i137[151], i137[150], i137[149], i137[148], i137[147], i137[146], i137[145], i137[144], i137[143], i137[142], i137[141], i137[140], i137[139], i137[138], i137[137], i137[136], i137[135], i137[134], i137[133], i137[132], i137[131], i137[130], i137[129], i137[128], i137[127], i137[126], i137[125], i137[124], i137[123], i137[122], i137[121], i137[120], i137[119], i137[118], i137[117], i137[116], i137[115], i137[114], i137[113], i137[112], i137[111], i137[110], i137[109], i137[108], i137[107], i137[106], i137[105], i137[104], i137[103], i137[102], i137[101], i137[100], i137[99], i137[98], i137[97], i137[96], i137[95], i137[94], i137[93], i137[92], i137[91], i137[90], i137[89], i137[88], i137[87], i137[86], i137[85], i137[84], i137[83], i137[82], i137[81], i137[80], i137[79], i137[78], i137[77], i137[76], i137[75], i137[74], i137[73], i137[72], i137[71], i137[70], i137[69], i137[68], i137[67], i137[66], i137[65], i137[64], i137[63], i137[62], i137[61], i137[60], i137[59], i137[58], i137[57], i137[56], i137[55], i137[54], i137[53], i137[52], i137[51], i137[50], i137[49], i137[48], i137[47], i137[46], i137[45], i137[44], i137[43], i137[42], i137[41], i137[40], i137[39], i137[38], i137[37], i137[36], i137[35], i137[34], i137[33], i137[32], i137[31], i137[30], i137[29], i137[28], i137[27], i137[26], i137[25], i137[24], i137[23], i137[22], i137[21], i137[20], i137[19], i137[18], i137[17], i137[16], i137[15], i137[14], i137[13], i137[12], i137[11], i137[10], i137[9], i137[8], i137[7], i137[6], i137[5], i137[4], i137[3], i137[2], i137[1], i137[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i138[225], i138[224], i138[223], i138[222], i138[221], i138[220], i138[219], i138[218], i138[217], i138[216], i138[215], i138[214], i138[213], i138[212], i138[211], i138[210], i138[209], i138[208], i138[207], i138[206], i138[205], i138[204], i138[203], i138[202], i138[201], i138[200], i138[199], i138[198], i138[197], i138[196], i138[195], i138[194], i138[193], i138[192], i138[191], i138[190], i138[189], i138[188], i138[187], i138[186], i138[185], i138[184], i138[183], i138[182], i138[181], i138[180], i138[179], i138[178], i138[177], i138[176], i138[175], i138[174], i138[173], i138[172], i138[171], i138[170], i138[169], i138[168], i138[167], i138[166], i138[165], i138[164], i138[163], i138[162], i138[161], i138[160], i138[159], i138[158], i138[157], i138[156], i138[155], i138[154], i138[153], i138[152], i138[151], i138[150], i138[149], i138[148], i138[147], i138[146], i138[145], i138[144], i138[143], i138[142], i138[141], i138[140], i138[139], i138[138], i138[137], i138[136], i138[135], i138[134], i138[133], i138[132], i138[131], i138[130], i138[129], i138[128], i138[127], i138[126], i138[125], i138[124], i138[123], i138[122], i138[121], i138[120], i138[119], i138[118], i138[117], i138[116], i138[115], i138[114], i138[113], i138[112], i138[111], i138[110], i138[109], i138[108], i138[107], i138[106], i138[105], i138[104], i138[103], i138[102], i138[101], i138[100], i138[99], i138[98], i138[97], i138[96], i138[95], i138[94], i138[93], i138[92], i138[91], i138[90], i138[89], i138[88], i138[87], i138[86], i138[85], i138[84], i138[83], i138[82], i138[81], i138[80], i138[79], i138[78], i138[77], i138[76], i138[75], i138[74], i138[73], i138[72], i138[71], i138[70], i138[69], i138[68], i138[67], i138[66], i138[65], i138[64], i138[63], i138[62], i138[61], i138[60], i138[59], i138[58], i138[57], i138[56], i138[55], i138[54], i138[53], i138[52], i138[51], i138[50], i138[49], i138[48], i138[47], i138[46], i138[45], i138[44], i138[43], i138[42], i138[41], i138[40], i138[39], i138[38], i138[37], i138[36], i138[35], i138[34], i138[33], i138[32], i138[31], i138[30], i138[29], i138[28], i138[27], i138[26], i138[25], i138[24], i138[23], i138[22], i138[21], i138[20], i138[19], i138[18], i138[17], i138[16], i138[15], i138[14], i138[13], i138[12], i138[11], i138[10], i138[9], i138[8], i138[7], i138[6], i138[5], i138[4], i138[3], i138[2], i138[1], i138[0]};
wire [255:0] t3 = {i139[255], i139[254], i139[253], i139[252], i139[251], i139[250], i139[249], i139[248], i139[247], i139[246], i139[245], i139[244], i139[243], i139[242], i139[241], i139[240], i139[239], i139[238], i139[237], i139[236], i139[235], i139[234], i139[233], i139[232], i139[231], i139[230], i139[229], i139[228], i139[227], i139[226], i139[225], i139[224], i139[223], i139[222], i139[221], i139[220], i139[219], i139[218], i139[217], i139[216], i139[215], i139[214], i139[213], i139[212], i139[211], i139[210], i139[209], i139[208], i139[207], i139[206], i139[205], i139[204], i139[203], i139[202], i139[201], i139[200], i139[199], i139[198], i139[197], i139[196], i139[195], i139[194], i139[193], i139[192], i139[191], i139[190], i139[189], i139[188], i139[187], i139[186], i139[185], i139[184], i139[183], i139[182], i139[181], i139[180], i139[179], i139[178], i139[177], i139[176], i139[175], i139[174], i139[173], i139[172], i139[171], i139[170], i139[169], i139[168], i139[167], i139[166], i139[165], i139[164], i139[163], i139[162], i139[161], i139[160], i139[159], i139[158], i139[157], i139[156], i139[155], i139[154], i139[153], i139[152], i139[151], i139[150], i139[149], i139[148], i139[147], i139[146], i139[145], i139[144], i139[143], i139[142], i139[141], i139[140], i139[139], i139[138], i139[137], i139[136], i139[135], i139[134], i139[133], i139[132], i139[131], i139[130], i139[129], i139[128], i139[127], i139[126], i139[125], i139[124], i139[123], i139[122], i139[121], i139[120], i139[119], i139[118], i139[117], i139[116], i139[115], i139[114], i139[113], i139[112], i139[111], i139[110], i139[109], i139[108], i139[107], i139[106], i139[105], i139[104], i139[103], i139[102], i139[101], i139[100], i139[99], i139[98], i139[97], i139[96], i139[95], i139[94], i139[93], i139[92], i139[91], i139[90], i139[89], i139[88], i139[87], i139[86], i139[85], i139[84], i139[83], i139[82], i139[81], i139[80], i139[79], i139[78], i139[77], i139[76], i139[75], i139[74], i139[73], i139[72], i139[71], i139[70], i139[69], i139[68], i139[67], i139[66], i139[65], i139[64], i139[63], i139[62], i139[61], i139[60], i139[59], i139[58], i139[57], i139[56], i139[55], i139[54], i139[53], i139[52], i139[51], i139[50], i139[49], i139[48], i139[47], i139[46], i139[45], i139[44], i139[43], i139[42], i139[41], i139[40], i139[39], i139[38], i139[37], i139[36], i139[35], i139[34], i139[33], i139[32], i139[31], i139[30], i139[29], i139[28], i139[27], i139[26], i139[25], i139[24], i139[23], i139[22], i139[21], i139[20], i139[19], i139[18], i139[17], i139[16], i139[15], i139[14], i139[13], i139[12], i139[11], i139[10], i139[9], i139[8], i139[7], i139[6], i139[5], i139[4], i139[3], i139[2], i139[1], i139[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91Core(input wire [191:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [223:0] masked_b=((b&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_91();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [159:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [159:0] masked_a=((a&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [191:0] masked_b=((b&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [223:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [223:0] masked_a=((a&224'hffffffffffffffff0000000000000000000000000000000000000000)|224'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffff000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [96:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [128:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [160:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [192:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
