`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [15:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_132; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_134; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_136; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_138; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_140; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_142; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_144; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_146; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_148; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_150; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_152; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_154; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_156; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_158; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_160; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_162; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_164; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_166; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_168; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_170; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_172; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_174; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_176; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_178; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_180; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_182; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_184; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_186; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_188; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_190; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_191; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_192; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_193; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_194; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_196; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_197; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_200; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_201; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_202; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_204; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_205; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_206; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_208; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_209; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_210; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_211; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_212; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_213; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_215; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_216; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_217; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_219; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_220; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_221; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_222; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_224; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_225; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_226; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_228; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_229; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_232; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_234; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_235; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_236; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_237; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_239; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_240; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_244; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_248; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_252; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_256; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_260; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_264; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_265; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_266; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_267; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_268; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_269; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_270; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_271; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_272; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_273; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_274; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_275; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_276; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_277; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_278; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_279; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_280; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_281; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_282; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_283; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_284; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_285; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_286; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_287; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_288; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_289; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_290; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_291; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_292; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_293; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_294; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_295; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_296; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_297; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_298; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_299; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_300; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_301; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_302; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_303; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_304; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_305; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_306; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_307; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_308; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_309; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_310; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_311; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_312; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_313; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_314; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_315; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_316; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_317; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_318; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_319; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_320; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_321; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_322; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_323; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_324; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_325; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_326; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_327; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_328; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_329; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_330; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_331; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_332; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_333; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_334; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_335; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_336; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_337; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_338; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_339; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_340; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_341; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_342; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_343; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_344; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_345; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_346; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_347; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_348; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_349; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_350; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_351; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_352; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_353; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_354; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_355; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_356; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_357; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_358; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_359; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_360; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_361; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_362; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_363; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_364; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_365; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_366; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_367; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_368; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_369; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_370; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_371; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_372; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_373; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_374; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_375; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_376; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_377; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_378; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_379; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_382; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_383; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_384; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_385; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_386; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_387; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_388; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_389; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_390; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_391; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_392; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_393; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_394; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_395; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_396; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_397; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_398; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_399; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_400; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_401; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_402; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_403; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_404; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_405; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_406; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_407; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_408; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_409; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_410; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_411; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_412; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_413; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_414; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_415; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_416; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_417; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_418; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_419; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_420; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_421; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_422; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_423; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_424; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_425; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_426; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_427; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_428; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_429; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_430; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_431; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_432; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_433; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_434; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_435; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_436; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_437; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_438; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_439; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_440; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_441; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_442; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_443; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_444; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_445; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_446; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_447; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_448; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_449; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_450; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_451; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_452; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_453; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_454; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_455; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_81_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_93_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_133_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_137_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_141_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_145_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_149_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_153_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_157_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_161_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_165_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_169_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_173_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_177_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_181_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_185_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_189_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_193_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_201_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_205_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_209_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_213_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_217_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_221_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_225_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_229_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_233_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_237_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_241_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_245_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_249_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_253_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_257_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_261_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_364_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_367_s2; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_370_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_373_s2; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_376_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_382_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [209:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_394_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_397_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_400_s2; // decl: <none>; prim: <none>
    logic [241:0] rtlzz_pipe_403_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_406_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_409_s2; // decl: <none>; prim: <none>
    logic [163:0] rtlzz_pipe_436_s3; // decl: <none>; prim: <none>
    logic [195:0] rtlzz_pipe_439_s3; // decl: <none>; prim: <none>
    logic [227:0] rtlzz_pipe_442_s3; // decl: <none>; prim: <none>
    logic [259:0] rtlzz_pipe_445_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_455; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(16'(mul_tree_10_11)), .b(16'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(16'(mul_tree_10_14)), .b(16'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(16'(mul_tree_10_18)), .b(16'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(16'(mul_tree_10_22)), .b(16'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(mul_tree_10_26)), .b(16'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(16'(mul_tree_10_30)), .b(16'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(16'(mul_tree_10_34)), .b(16'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(16'(mul_tree_10_38)), .b(16'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(16'(mul_tree_10_42)), .b(16'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(mul_tree_10_46)), .b(16'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(16'(mul_tree_10_50)), .b(16'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(16'(mul_tree_10_54)), .b(16'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(16'(mul_tree_10_58)), .b(16'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(16'(mul_tree_10_62)), .b(16'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(mul_tree_10_66)), .b(16'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(16'(mul_tree_10_70)), .b(16'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(16'(mul_tree_10_74)), .b(16'(mul_tree_10_75)), .cin(1'b0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = {mul_tree_10_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(16'(mul_tree_10_78)), .b(16'(mul_tree_10_79)), .cin(1'b0), .value(mul_tree_10_80));
    assign mul_tree_10_81 = {mul_tree_10_80, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(16'(mul_tree_10_82)), .b(16'(mul_tree_10_83)), .cin(1'b0), .value(mul_tree_10_84));
    assign mul_tree_10_85 = {mul_tree_10_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(mul_tree_10_86)), .b(16'(mul_tree_10_87)), .cin(1'b0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = {mul_tree_10_88, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(16'(mul_tree_10_90)), .b(16'(mul_tree_10_91)), .cin(1'b0), .value(mul_tree_10_92));
    assign mul_tree_10_93 = {mul_tree_10_92, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_96Core rtlzz_owner_96(.a(16'(mul_tree_10_94)), .b(16'(mul_tree_10_95)), .cin(1'b0), .value(mul_tree_10_96));
    assign mul_tree_10_97 = {mul_tree_10_96, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(16'(mul_tree_10_98)), .b(16'(mul_tree_10_99)), .cin(1'b0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = {mul_tree_10_100, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(16'(mul_tree_10_102)), .b(16'(mul_tree_10_103)), .cin(1'b0), .value(mul_tree_10_104));
    assign mul_tree_10_105 = {mul_tree_10_104, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_107 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(16'(mul_tree_10_106)), .b(16'(mul_tree_10_107)), .cin(1'b0), .value(mul_tree_10_108));
    assign mul_tree_10_109 = {mul_tree_10_108, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_110 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_111 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(16'(mul_tree_10_110)), .b(16'(mul_tree_10_111)), .cin(1'b0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = {mul_tree_10_112, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_114 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_115 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(16'(mul_tree_10_114)), .b(16'(mul_tree_10_115)), .cin(1'b0), .value(mul_tree_10_116));
    assign mul_tree_10_117 = {mul_tree_10_116, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_118 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(16'(mul_tree_10_118)), .b(16'(mul_tree_10_119)), .cin(1'b0), .value(mul_tree_10_120));
    assign mul_tree_10_121 = {mul_tree_10_120, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_122 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_123 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(16'(mul_tree_10_122)), .b(16'(mul_tree_10_123)), .cin(1'b0), .value(mul_tree_10_124));
    assign mul_tree_10_125 = {mul_tree_10_124, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_126 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_127 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(mul_tree_10_126)), .b(16'(mul_tree_10_127)), .cin(1'b0), .value(mul_tree_10_128));
    assign mul_tree_10_129 = {mul_tree_10_128, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_131 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_10_130)), .b(16'(mul_tree_10_131)), .cin(1'b0), .value(mul_tree_10_132));
    assign mul_tree_10_133 = {mul_tree_10_132, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_134 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_135 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(16'(mul_tree_10_134)), .b(16'(mul_tree_10_135)), .cin(1'b0), .value(mul_tree_10_136));
    assign mul_tree_10_137 = {mul_tree_10_136, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_138 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_139 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(16'(mul_tree_10_138)), .b(16'(mul_tree_10_139)), .cin(1'b0), .value(mul_tree_10_140));
    assign mul_tree_10_141 = {mul_tree_10_140, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_142 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_143 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(16'(mul_tree_10_142)), .b(16'(mul_tree_10_143)), .cin(1'b0), .value(mul_tree_10_144));
    assign mul_tree_10_145 = {mul_tree_10_144, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_146 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_147 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(mul_tree_10_146)), .b(16'(mul_tree_10_147)), .cin(1'b0), .value(mul_tree_10_148));
    assign mul_tree_10_149 = {mul_tree_10_148, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_150 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_151 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_152Core rtlzz_owner_152(.a(16'(mul_tree_10_150)), .b(16'(mul_tree_10_151)), .cin(1'b0), .value(mul_tree_10_152));
    assign mul_tree_10_153 = {mul_tree_10_152, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_154 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_155 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(16'(mul_tree_10_154)), .b(16'(mul_tree_10_155)), .cin(1'b0), .value(mul_tree_10_156));
    assign mul_tree_10_157 = {mul_tree_10_156, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_158 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_159 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(16'(mul_tree_10_158)), .b(16'(mul_tree_10_159)), .cin(1'b0), .value(mul_tree_10_160));
    assign mul_tree_10_161 = {mul_tree_10_160, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_162 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_163 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_164Core rtlzz_owner_164(.a(16'(mul_tree_10_162)), .b(16'(mul_tree_10_163)), .cin(1'b0), .value(mul_tree_10_164));
    assign mul_tree_10_165 = {mul_tree_10_164, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_166 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_167 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(mul_tree_10_166)), .b(16'(mul_tree_10_167)), .cin(1'b0), .value(mul_tree_10_168));
    assign mul_tree_10_169 = {mul_tree_10_168, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_170 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_171 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(16'(mul_tree_10_170)), .b(16'(mul_tree_10_171)), .cin(1'b0), .value(mul_tree_10_172));
    assign mul_tree_10_173 = {mul_tree_10_172, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_174 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_175 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(16'(mul_tree_10_174)), .b(16'(mul_tree_10_175)), .cin(1'b0), .value(mul_tree_10_176));
    assign mul_tree_10_177 = {mul_tree_10_176, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_178 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_179 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(16'(mul_tree_10_178)), .b(16'(mul_tree_10_179)), .cin(1'b0), .value(mul_tree_10_180));
    assign mul_tree_10_181 = {mul_tree_10_180, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_182 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_183 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(16'(mul_tree_10_182)), .b(16'(mul_tree_10_183)), .cin(1'b0), .value(mul_tree_10_184));
    assign mul_tree_10_185 = {mul_tree_10_184, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_186 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_187 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(mul_tree_10_186)), .b(16'(mul_tree_10_187)), .cin(1'b0), .value(mul_tree_10_188));
    assign mul_tree_10_189 = {mul_tree_10_188, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_190 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_191 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_192Core rtlzz_owner_192(.a(16'(mul_tree_10_190)), .b(16'(mul_tree_10_191)), .cin(1'b0), .value(mul_tree_10_192));
    assign mul_tree_10_193 = {mul_tree_10_192, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_194 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_195 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_196Core rtlzz_owner_196(.a(16'(mul_tree_10_194)), .b(16'(mul_tree_10_195)), .cin(1'b0), .value(mul_tree_10_196));
    assign mul_tree_10_197 = {mul_tree_10_196, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_198 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_199 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(16'(mul_tree_10_198)), .b(16'(mul_tree_10_199)), .cin(1'b0), .value(mul_tree_10_200));
    assign mul_tree_10_201 = {mul_tree_10_200, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_202 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_203 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(16'(mul_tree_10_202)), .b(16'(mul_tree_10_203)), .cin(1'b0), .value(mul_tree_10_204));
    assign mul_tree_10_205 = {mul_tree_10_204, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_206 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_207 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_208Core rtlzz_owner_208(.a(16'(mul_tree_10_206)), .b(16'(mul_tree_10_207)), .cin(1'b0), .value(mul_tree_10_208));
    assign mul_tree_10_209 = {mul_tree_10_208, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_210 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_211 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(16'(mul_tree_10_210)), .b(16'(mul_tree_10_211)), .cin(1'b0), .value(mul_tree_10_212));
    assign mul_tree_10_213 = {mul_tree_10_212, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_214 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_215 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(16'(mul_tree_10_214)), .b(16'(mul_tree_10_215)), .cin(1'b0), .value(mul_tree_10_216));
    assign mul_tree_10_217 = {mul_tree_10_216, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_218 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_219 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(16'(mul_tree_10_218)), .b(16'(mul_tree_10_219)), .cin(1'b0), .value(mul_tree_10_220));
    assign mul_tree_10_221 = {mul_tree_10_220, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_222 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_223 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(16'(mul_tree_10_222)), .b(16'(mul_tree_10_223)), .cin(1'b0), .value(mul_tree_10_224));
    assign mul_tree_10_225 = {mul_tree_10_224, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_226 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_227 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(16'(mul_tree_10_226)), .b(16'(mul_tree_10_227)), .cin(1'b0), .value(mul_tree_10_228));
    assign mul_tree_10_229 = {mul_tree_10_228, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_230 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_231 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_232Core rtlzz_owner_232(.a(16'(mul_tree_10_230)), .b(16'(mul_tree_10_231)), .cin(1'b0), .value(mul_tree_10_232));
    assign mul_tree_10_233 = {mul_tree_10_232, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_234 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_235 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_236Core rtlzz_owner_236(.a(16'(mul_tree_10_234)), .b(16'(mul_tree_10_235)), .cin(1'b0), .value(mul_tree_10_236));
    assign mul_tree_10_237 = {mul_tree_10_236, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_238 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_239 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(16'(mul_tree_10_238)), .b(16'(mul_tree_10_239)), .cin(1'b0), .value(mul_tree_10_240));
    assign mul_tree_10_241 = {mul_tree_10_240, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_242 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_243 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_10_242)), .b(16'(mul_tree_10_243)), .cin(1'b0), .value(mul_tree_10_244));
    assign mul_tree_10_245 = {mul_tree_10_244, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_246 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_247 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_10_246)), .b(16'(mul_tree_10_247)), .cin(1'b0), .value(mul_tree_10_248));
    assign mul_tree_10_249 = {mul_tree_10_248, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_250 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_251 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_10_250)), .b(16'(mul_tree_10_251)), .cin(1'b0), .value(mul_tree_10_252));
    assign mul_tree_10_253 = {mul_tree_10_252, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_254 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_255 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_10_254)), .b(16'(mul_tree_10_255)), .cin(1'b0), .value(mul_tree_10_256));
    assign mul_tree_10_257 = {mul_tree_10_256, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_258 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_259 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_10_258)), .b(16'(mul_tree_10_259)), .cin(1'b0), .value(mul_tree_10_260));
    assign mul_tree_10_261 = {mul_tree_10_260, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_262 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_263 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_10_262)), .b(16'(mul_tree_10_263)), .cin(1'b0), .value(mul_tree_10_264));
    assign mul_tree_10_265 = {mul_tree_10_264, 224'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_266 = ({17'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_267 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_269 = ({17'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_270 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_272 = ({17'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_273 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_275 = ({17'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_276 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_278 = ({17'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_279 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_281 = ({17'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_282 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_284 = ({17'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_285 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_287 = ({17'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_288 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_290 = ({17'h0, rtlzz_pipe_77_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_291 = ({1'h0, rtlzz_pipe_81_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_293 = ({17'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_294 = ({1'h0, rtlzz_pipe_89_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_296 = ({17'h0, rtlzz_pipe_93_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_297 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_299 = ({17'h0, rtlzz_pipe_101_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_300 = ({1'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_302 = ({17'h0, rtlzz_pipe_109_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_303 = ({1'h0, rtlzz_pipe_113_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_305 = ({17'h0, rtlzz_pipe_117_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_306 = ({1'h0, rtlzz_pipe_121_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_308 = ({17'h0, rtlzz_pipe_125_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_309 = ({1'h0, rtlzz_pipe_129_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_311 = ({17'h0, rtlzz_pipe_133_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_312 = ({1'h0, rtlzz_pipe_137_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_314 = ({17'h0, rtlzz_pipe_141_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_315 = ({1'h0, rtlzz_pipe_145_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_317 = ({17'h0, rtlzz_pipe_149_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_318 = ({1'h0, rtlzz_pipe_153_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_320 = ({17'h0, rtlzz_pipe_157_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_321 = ({1'h0, rtlzz_pipe_161_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_323 = ({17'h0, rtlzz_pipe_165_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_324 = ({1'h0, rtlzz_pipe_169_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_326 = ({17'h0, rtlzz_pipe_173_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_327 = ({1'h0, rtlzz_pipe_177_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_329 = ({17'h0, rtlzz_pipe_181_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_330 = ({1'h0, rtlzz_pipe_185_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_332 = ({17'h0, rtlzz_pipe_189_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_333 = ({1'h0, rtlzz_pipe_193_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_335 = ({17'h0, rtlzz_pipe_197_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_336 = ({1'h0, rtlzz_pipe_201_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_338 = ({17'h0, rtlzz_pipe_205_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_339 = ({1'h0, rtlzz_pipe_209_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_341 = ({17'h0, rtlzz_pipe_213_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_342 = ({1'h0, rtlzz_pipe_217_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_344 = ({17'h0, rtlzz_pipe_221_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_345 = ({1'h0, rtlzz_pipe_225_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_347 = ({17'h0, rtlzz_pipe_229_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_348 = ({1'h0, rtlzz_pipe_233_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_350 = ({17'h0, rtlzz_pipe_237_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_351 = ({1'h0, rtlzz_pipe_241_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_353 = ({17'h0, rtlzz_pipe_245_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_354 = ({1'h0, rtlzz_pipe_249_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_356 = ({17'h0, rtlzz_pipe_253_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_357 = ({1'h0, rtlzz_pipe_257_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_359 = ({17'h0, rtlzz_pipe_261_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_360 = ({1'h0, rtlzz_pipe_265_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_362 = ({33'h0, mul_tree_10_268}); // decl: <none>; prim: <none>
    assign mul_tree_10_363 = ({1'h0, mul_tree_10_271}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364_reduce rtlzz_reduce_364(.i456(rtlzz_pipe_13_s1), .i457(rtlzz_pipe_17_s1), .i458(rtlzz_pipe_21_s1), .i459(rtlzz_pipe_25_s1), .y(mul_tree_10_364));
    assign mul_tree_10_365 = ({33'h0, mul_tree_10_274}); // decl: <none>; prim: <none>
    assign mul_tree_10_366 = ({1'h0, mul_tree_10_277}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_367_reduce rtlzz_reduce_367(.i460(rtlzz_pipe_29_s1), .i461(rtlzz_pipe_33_s1), .i462(rtlzz_pipe_37_s1), .i463(rtlzz_pipe_41_s1), .y(mul_tree_10_367));
    assign mul_tree_10_368 = ({33'h0, mul_tree_10_280}); // decl: <none>; prim: <none>
    assign mul_tree_10_369 = ({1'h0, mul_tree_10_283}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370_reduce rtlzz_reduce_370(.i464(rtlzz_pipe_45_s1), .i465(rtlzz_pipe_49_s1), .i466(rtlzz_pipe_53_s1), .i467(rtlzz_pipe_57_s1), .y(mul_tree_10_370));
    assign mul_tree_10_371 = ({33'h0, mul_tree_10_286}); // decl: <none>; prim: <none>
    assign mul_tree_10_372 = ({1'h0, mul_tree_10_289}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373_reduce rtlzz_reduce_373(.i468(rtlzz_pipe_61_s1), .i469(rtlzz_pipe_65_s1), .i470(rtlzz_pipe_69_s1), .i471(rtlzz_pipe_73_s1), .y(mul_tree_10_373));
    assign mul_tree_10_374 = ({33'h0, mul_tree_10_292}); // decl: <none>; prim: <none>
    assign mul_tree_10_375 = ({1'h0, mul_tree_10_295}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376_reduce rtlzz_reduce_376(.i472(rtlzz_pipe_77_s1), .i473(rtlzz_pipe_81_s1), .i474(rtlzz_pipe_85_s1), .i475(rtlzz_pipe_89_s1), .y(mul_tree_10_376));
    assign mul_tree_10_377 = ({33'h0, mul_tree_10_298}); // decl: <none>; prim: <none>
    assign mul_tree_10_378 = ({1'h0, mul_tree_10_301}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_379_reduce rtlzz_reduce_379(.i476(rtlzz_pipe_93_s1), .i477(rtlzz_pipe_97_s1), .i478(rtlzz_pipe_101_s1), .i479(rtlzz_pipe_105_s1), .y(mul_tree_10_379));
    assign mul_tree_10_380 = ({33'h0, mul_tree_10_304}); // decl: <none>; prim: <none>
    assign mul_tree_10_381 = ({1'h0, mul_tree_10_307}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382_reduce rtlzz_reduce_382(.i480(rtlzz_pipe_109_s1), .i481(rtlzz_pipe_113_s1), .i482(rtlzz_pipe_117_s1), .i483(rtlzz_pipe_121_s1), .y(mul_tree_10_382));
    assign mul_tree_10_383 = ({33'h0, mul_tree_10_310}); // decl: <none>; prim: <none>
    assign mul_tree_10_384 = ({1'h0, mul_tree_10_313}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385_reduce rtlzz_reduce_385(.i484(rtlzz_pipe_125_s1), .i485(rtlzz_pipe_129_s1), .i486(rtlzz_pipe_133_s1), .i487(rtlzz_pipe_137_s1), .y(mul_tree_10_385));
    assign mul_tree_10_386 = ({33'h0, mul_tree_10_316}); // decl: <none>; prim: <none>
    assign mul_tree_10_387 = ({1'h0, mul_tree_10_319}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388_reduce rtlzz_reduce_388(.i488(rtlzz_pipe_141_s1), .i489(rtlzz_pipe_145_s1), .i490(rtlzz_pipe_149_s1), .i491(rtlzz_pipe_153_s1), .y(mul_tree_10_388));
    assign mul_tree_10_389 = ({33'h0, mul_tree_10_322}); // decl: <none>; prim: <none>
    assign mul_tree_10_390 = ({1'h0, mul_tree_10_325}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391_reduce rtlzz_reduce_391(.i492(rtlzz_pipe_157_s1), .i493(rtlzz_pipe_161_s1), .i494(rtlzz_pipe_165_s1), .i495(rtlzz_pipe_169_s1), .y(mul_tree_10_391));
    assign mul_tree_10_392 = ({33'h0, mul_tree_10_328}); // decl: <none>; prim: <none>
    assign mul_tree_10_393 = ({1'h0, mul_tree_10_331}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394_reduce rtlzz_reduce_394(.i496(rtlzz_pipe_173_s1), .i497(rtlzz_pipe_177_s1), .i498(rtlzz_pipe_181_s1), .i499(rtlzz_pipe_185_s1), .y(mul_tree_10_394));
    assign mul_tree_10_395 = ({33'h0, mul_tree_10_334}); // decl: <none>; prim: <none>
    assign mul_tree_10_396 = ({1'h0, mul_tree_10_337}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397_reduce rtlzz_reduce_397(.i500(rtlzz_pipe_189_s1), .i501(rtlzz_pipe_193_s1), .i502(rtlzz_pipe_197_s1), .i503(rtlzz_pipe_201_s1), .y(mul_tree_10_397));
    assign mul_tree_10_398 = ({33'h0, mul_tree_10_340}); // decl: <none>; prim: <none>
    assign mul_tree_10_399 = ({1'h0, mul_tree_10_343}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_400_reduce rtlzz_reduce_400(.i504(rtlzz_pipe_205_s1), .i505(rtlzz_pipe_209_s1), .i506(rtlzz_pipe_213_s1), .i507(rtlzz_pipe_217_s1), .y(mul_tree_10_400));
    assign mul_tree_10_401 = ({33'h0, mul_tree_10_346}); // decl: <none>; prim: <none>
    assign mul_tree_10_402 = ({1'h0, mul_tree_10_349}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_403_reduce rtlzz_reduce_403(.i508(rtlzz_pipe_221_s1), .i509(rtlzz_pipe_225_s1), .i510(rtlzz_pipe_229_s1), .i511(rtlzz_pipe_233_s1), .y(mul_tree_10_403));
    assign mul_tree_10_404 = ({33'h0, mul_tree_10_352}); // decl: <none>; prim: <none>
    assign mul_tree_10_405 = ({1'h0, mul_tree_10_355}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_406_reduce rtlzz_reduce_406(.i512(rtlzz_pipe_237_s1), .i513(rtlzz_pipe_241_s1), .i514(rtlzz_pipe_245_s1), .i515(rtlzz_pipe_249_s1), .y(mul_tree_10_406));
    assign mul_tree_10_407 = ({33'h0, mul_tree_10_358}); // decl: <none>; prim: <none>
    assign mul_tree_10_408 = ({1'h0, mul_tree_10_361}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409_reduce rtlzz_reduce_409(.i516(rtlzz_pipe_253_s1), .i517(rtlzz_pipe_257_s1), .i518(rtlzz_pipe_261_s1), .i519(rtlzz_pipe_265_s1), .y(mul_tree_10_409));
    assign mul_tree_10_410 = ({65'h0, rtlzz_pipe_364_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_411 = ({1'h0, rtlzz_pipe_367_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_413 = ({65'h0, rtlzz_pipe_370_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_414 = ({1'h0, rtlzz_pipe_373_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_416 = ({65'h0, rtlzz_pipe_376_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_417 = ({1'h0, rtlzz_pipe_379_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_419 = ({65'h0, rtlzz_pipe_382_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_420 = ({1'h0, rtlzz_pipe_385_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_422 = ({65'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_423 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_425 = ({65'h0, rtlzz_pipe_394_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_426 = ({1'h0, rtlzz_pipe_397_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_428 = ({65'h0, rtlzz_pipe_400_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_429 = ({1'h0, rtlzz_pipe_403_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_431 = ({65'h0, rtlzz_pipe_406_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_432 = ({1'h0, rtlzz_pipe_409_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_434 = ({17'h0, mul_tree_10_412}); // decl: <none>; prim: <none>
    assign mul_tree_10_435 = ({1'h0, mul_tree_10_415}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_436_reduce rtlzz_reduce_436(.i520(rtlzz_pipe_364_s2), .i521(rtlzz_pipe_367_s2), .i522(rtlzz_pipe_370_s2), .i523(rtlzz_pipe_373_s2), .y(mul_tree_10_436));
    assign mul_tree_10_437 = ({17'h0, mul_tree_10_418}); // decl: <none>; prim: <none>
    assign mul_tree_10_438 = ({1'h0, mul_tree_10_421}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_439_reduce rtlzz_reduce_439(.i524(rtlzz_pipe_376_s2), .i525(rtlzz_pipe_379_s2), .i526(rtlzz_pipe_382_s2), .i527(rtlzz_pipe_385_s2), .y(mul_tree_10_439));
    assign mul_tree_10_440 = ({17'h0, mul_tree_10_424}); // decl: <none>; prim: <none>
    assign mul_tree_10_441 = ({1'h0, mul_tree_10_427}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_442_reduce rtlzz_reduce_442(.i528(rtlzz_pipe_388_s2), .i529(rtlzz_pipe_391_s2), .i530(rtlzz_pipe_394_s2), .i531(rtlzz_pipe_397_s2), .y(mul_tree_10_442));
    assign mul_tree_10_443 = ({17'h0, mul_tree_10_430}); // decl: <none>; prim: <none>
    assign mul_tree_10_444 = ({1'h0, mul_tree_10_433}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_445_reduce rtlzz_reduce_445(.i532(rtlzz_pipe_400_s2), .i533(rtlzz_pipe_403_s2), .i534(rtlzz_pipe_406_s2), .i535(rtlzz_pipe_409_s2), .y(mul_tree_10_445));
    assign mul_tree_10_446 = ({33'h0, rtlzz_pipe_436_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_447 = ({1'h0, rtlzz_pipe_439_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_449 = ({33'h0, rtlzz_pipe_442_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_450 = ({1'h0, rtlzz_pipe_445_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_452 = ({65'h0, mul_tree_10_448}); // decl: <none>; prim: <none>
    assign mul_tree_10_453 = ({1'h0, mul_tree_10_451}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454_reduce rtlzz_reduce_454(.i536(rtlzz_pipe_436_s3), .i537(rtlzz_pipe_439_s3), .i538(rtlzz_pipe_442_s3), .i539(rtlzz_pipe_445_s3), .y(mul_tree_10_454));
    assign mul_tree_10_455 = mul_tree_10_454[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 32'h0;
            rtlzz_pipe_17_s1 <= 48'h0;
            rtlzz_pipe_21_s1 <= 64'h0;
            rtlzz_pipe_25_s1 <= 80'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 112'h0;
            rtlzz_pipe_37_s1 <= 128'h0;
            rtlzz_pipe_41_s1 <= 144'h0;
            rtlzz_pipe_45_s1 <= 48'h0;
            rtlzz_pipe_49_s1 <= 64'h0;
            rtlzz_pipe_53_s1 <= 80'h0;
            rtlzz_pipe_57_s1 <= 96'h0;
            rtlzz_pipe_61_s1 <= 112'h0;
            rtlzz_pipe_65_s1 <= 128'h0;
            rtlzz_pipe_69_s1 <= 144'h0;
            rtlzz_pipe_73_s1 <= 160'h0;
            rtlzz_pipe_77_s1 <= 64'h0;
            rtlzz_pipe_81_s1 <= 80'h0;
            rtlzz_pipe_85_s1 <= 96'h0;
            rtlzz_pipe_89_s1 <= 112'h0;
            rtlzz_pipe_93_s1 <= 128'h0;
            rtlzz_pipe_97_s1 <= 144'h0;
            rtlzz_pipe_101_s1 <= 160'h0;
            rtlzz_pipe_105_s1 <= 176'h0;
            rtlzz_pipe_109_s1 <= 80'h0;
            rtlzz_pipe_113_s1 <= 96'h0;
            rtlzz_pipe_117_s1 <= 112'h0;
            rtlzz_pipe_121_s1 <= 128'h0;
            rtlzz_pipe_125_s1 <= 144'h0;
            rtlzz_pipe_129_s1 <= 160'h0;
            rtlzz_pipe_133_s1 <= 176'h0;
            rtlzz_pipe_137_s1 <= 192'h0;
            rtlzz_pipe_141_s1 <= 96'h0;
            rtlzz_pipe_145_s1 <= 112'h0;
            rtlzz_pipe_149_s1 <= 128'h0;
            rtlzz_pipe_153_s1 <= 144'h0;
            rtlzz_pipe_157_s1 <= 160'h0;
            rtlzz_pipe_161_s1 <= 176'h0;
            rtlzz_pipe_165_s1 <= 192'h0;
            rtlzz_pipe_169_s1 <= 208'h0;
            rtlzz_pipe_173_s1 <= 112'h0;
            rtlzz_pipe_177_s1 <= 128'h0;
            rtlzz_pipe_181_s1 <= 144'h0;
            rtlzz_pipe_185_s1 <= 160'h0;
            rtlzz_pipe_189_s1 <= 176'h0;
            rtlzz_pipe_193_s1 <= 192'h0;
            rtlzz_pipe_197_s1 <= 208'h0;
            rtlzz_pipe_201_s1 <= 224'h0;
            rtlzz_pipe_205_s1 <= 128'h0;
            rtlzz_pipe_209_s1 <= 144'h0;
            rtlzz_pipe_213_s1 <= 160'h0;
            rtlzz_pipe_217_s1 <= 176'h0;
            rtlzz_pipe_221_s1 <= 192'h0;
            rtlzz_pipe_225_s1 <= 208'h0;
            rtlzz_pipe_229_s1 <= 224'h0;
            rtlzz_pipe_233_s1 <= 240'h0;
            rtlzz_pipe_237_s1 <= 144'h0;
            rtlzz_pipe_241_s1 <= 160'h0;
            rtlzz_pipe_245_s1 <= 176'h0;
            rtlzz_pipe_249_s1 <= 192'h0;
            rtlzz_pipe_253_s1 <= 208'h0;
            rtlzz_pipe_257_s1 <= 224'h0;
            rtlzz_pipe_261_s1 <= 240'h0;
            rtlzz_pipe_265_s1 <= 256'h0;
            rtlzz_pipe_364_s2 <= 82'h0;
            rtlzz_pipe_367_s2 <= 146'h0;
            rtlzz_pipe_370_s2 <= 98'h0;
            rtlzz_pipe_373_s2 <= 162'h0;
            rtlzz_pipe_376_s2 <= 114'h0;
            rtlzz_pipe_379_s2 <= 178'h0;
            rtlzz_pipe_382_s2 <= 130'h0;
            rtlzz_pipe_385_s2 <= 194'h0;
            rtlzz_pipe_388_s2 <= 146'h0;
            rtlzz_pipe_391_s2 <= 210'h0;
            rtlzz_pipe_394_s2 <= 162'h0;
            rtlzz_pipe_397_s2 <= 226'h0;
            rtlzz_pipe_400_s2 <= 178'h0;
            rtlzz_pipe_403_s2 <= 242'h0;
            rtlzz_pipe_406_s2 <= 194'h0;
            rtlzz_pipe_409_s2 <= 258'h0;
            rtlzz_pipe_436_s3 <= 164'h0;
            rtlzz_pipe_439_s3 <= 196'h0;
            rtlzz_pipe_442_s3 <= 228'h0;
            rtlzz_pipe_445_s3 <= 260'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= mul_tree_10_77; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_81_s1 <= mul_tree_10_81; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= mul_tree_10_89; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_93_s1 <= mul_tree_10_93; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_tree_10_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_10_105; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_tree_10_113; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_tree_10_117; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_tree_10_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_tree_10_125; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_tree_10_129; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_133_s1 <= mul_tree_10_133; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_137_s1 <= mul_tree_10_137; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_141_s1 <= mul_tree_10_141; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_145_s1 <= mul_tree_10_145; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_149_s1 <= mul_tree_10_149; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_153_s1 <= mul_tree_10_153; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_157_s1 <= mul_tree_10_157; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_161_s1 <= mul_tree_10_161; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_165_s1 <= mul_tree_10_165; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_169_s1 <= mul_tree_10_169; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_173_s1 <= mul_tree_10_173; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_177_s1 <= mul_tree_10_177; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_181_s1 <= mul_tree_10_181; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_185_s1 <= mul_tree_10_185; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_189_s1 <= mul_tree_10_189; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_193_s1 <= mul_tree_10_193; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_197_s1 <= mul_tree_10_197; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_201_s1 <= mul_tree_10_201; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_205_s1 <= mul_tree_10_205; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_209_s1 <= mul_tree_10_209; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_213_s1 <= mul_tree_10_213; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_217_s1 <= mul_tree_10_217; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_221_s1 <= mul_tree_10_221; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_225_s1 <= mul_tree_10_225; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_229_s1 <= mul_tree_10_229; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_233_s1 <= mul_tree_10_233; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_237_s1 <= mul_tree_10_237; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_241_s1 <= mul_tree_10_241; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_245_s1 <= mul_tree_10_245; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= mul_tree_10_249; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_253_s1 <= mul_tree_10_253; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_257_s1 <= mul_tree_10_257; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_261_s1 <= mul_tree_10_261; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= mul_tree_10_265; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_364_s2 <= mul_tree_10_364; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_367_s2 <= mul_tree_10_367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_370_s2 <= mul_tree_10_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_373_s2 <= mul_tree_10_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_376_s2 <= mul_tree_10_376; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_379_s2 <= mul_tree_10_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_382_s2 <= mul_tree_10_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_385_s2 <= mul_tree_10_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_10_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_10_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_394_s2 <= mul_tree_10_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_397_s2 <= mul_tree_10_397; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_400_s2 <= mul_tree_10_400; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_403_s2 <= mul_tree_10_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_406_s2 <= mul_tree_10_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_409_s2 <= mul_tree_10_409; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_436_s3 <= mul_tree_10_436; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_439_s3 <= mul_tree_10_439; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_442_s3 <= mul_tree_10_442; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_445_s3 <= mul_tree_10_445; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364_reduce(input wire [31:0] i456, input wire [47:0] i457, input wire [63:0] i458, input wire [79:0] i459, output wire [81:0] y);
wire [81:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i456[31], i456[30], i456[29], i456[28], i456[27], i456[26], i456[25], i456[24], i456[23], i456[22], i456[21], i456[20], i456[19], i456[18], i456[17], i456[16], i456[15], i456[14], i456[13], i456[12], i456[11], i456[10], i456[9], i456[8], i456[7], i456[6], i456[5], i456[4], i456[3], i456[2], i456[1], i456[0]};
wire [81:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i457[47], i457[46], i457[45], i457[44], i457[43], i457[42], i457[41], i457[40], i457[39], i457[38], i457[37], i457[36], i457[35], i457[34], i457[33], i457[32], i457[31], i457[30], i457[29], i457[28], i457[27], i457[26], i457[25], i457[24], i457[23], i457[22], i457[21], i457[20], i457[19], i457[18], i457[17], i457[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i458[63], i458[62], i458[61], i458[60], i458[59], i458[58], i458[57], i458[56], i458[55], i458[54], i458[53], i458[52], i458[51], i458[50], i458[49], i458[48], i458[47], i458[46], i458[45], i458[44], i458[43], i458[42], i458[41], i458[40], i458[39], i458[38], i458[37], i458[36], i458[35], i458[34], i458[33], i458[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t3 = {1'b0, 1'b0, i459[79], i459[78], i459[77], i459[76], i459[75], i459[74], i459[73], i459[72], i459[71], i459[70], i459[69], i459[68], i459[67], i459[66], i459[65], i459[64], i459[63], i459[62], i459[61], i459[60], i459[59], i459[58], i459[57], i459[56], i459[55], i459[54], i459[53], i459[52], i459[51], i459[50], i459[49], i459[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367_reduce(input wire [95:0] i460, input wire [111:0] i461, input wire [127:0] i462, input wire [143:0] i463, output wire [145:0] y);
wire [145:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i460[95], i460[94], i460[93], i460[92], i460[91], i460[90], i460[89], i460[88], i460[87], i460[86], i460[85], i460[84], i460[83], i460[82], i460[81], i460[80], i460[79], i460[78], i460[77], i460[76], i460[75], i460[74], i460[73], i460[72], i460[71], i460[70], i460[69], i460[68], i460[67], i460[66], i460[65], i460[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i461[111], i461[110], i461[109], i461[108], i461[107], i461[106], i461[105], i461[104], i461[103], i461[102], i461[101], i461[100], i461[99], i461[98], i461[97], i461[96], i461[95], i461[94], i461[93], i461[92], i461[91], i461[90], i461[89], i461[88], i461[87], i461[86], i461[85], i461[84], i461[83], i461[82], i461[81], i461[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i462[127], i462[126], i462[125], i462[124], i462[123], i462[122], i462[121], i462[120], i462[119], i462[118], i462[117], i462[116], i462[115], i462[114], i462[113], i462[112], i462[111], i462[110], i462[109], i462[108], i462[107], i462[106], i462[105], i462[104], i462[103], i462[102], i462[101], i462[100], i462[99], i462[98], i462[97], i462[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t3 = {1'b0, 1'b0, i463[143], i463[142], i463[141], i463[140], i463[139], i463[138], i463[137], i463[136], i463[135], i463[134], i463[133], i463[132], i463[131], i463[130], i463[129], i463[128], i463[127], i463[126], i463[125], i463[124], i463[123], i463[122], i463[121], i463[120], i463[119], i463[118], i463[117], i463[116], i463[115], i463[114], i463[113], i463[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370_reduce(input wire [47:0] i464, input wire [63:0] i465, input wire [79:0] i466, input wire [95:0] i467, output wire [97:0] y);
wire [97:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i464[47], i464[46], i464[45], i464[44], i464[43], i464[42], i464[41], i464[40], i464[39], i464[38], i464[37], i464[36], i464[35], i464[34], i464[33], i464[32], i464[31], i464[30], i464[29], i464[28], i464[27], i464[26], i464[25], i464[24], i464[23], i464[22], i464[21], i464[20], i464[19], i464[18], i464[17], i464[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i465[63], i465[62], i465[61], i465[60], i465[59], i465[58], i465[57], i465[56], i465[55], i465[54], i465[53], i465[52], i465[51], i465[50], i465[49], i465[48], i465[47], i465[46], i465[45], i465[44], i465[43], i465[42], i465[41], i465[40], i465[39], i465[38], i465[37], i465[36], i465[35], i465[34], i465[33], i465[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i466[79], i466[78], i466[77], i466[76], i466[75], i466[74], i466[73], i466[72], i466[71], i466[70], i466[69], i466[68], i466[67], i466[66], i466[65], i466[64], i466[63], i466[62], i466[61], i466[60], i466[59], i466[58], i466[57], i466[56], i466[55], i466[54], i466[53], i466[52], i466[51], i466[50], i466[49], i466[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t3 = {1'b0, 1'b0, i467[95], i467[94], i467[93], i467[92], i467[91], i467[90], i467[89], i467[88], i467[87], i467[86], i467[85], i467[84], i467[83], i467[82], i467[81], i467[80], i467[79], i467[78], i467[77], i467[76], i467[75], i467[74], i467[73], i467[72], i467[71], i467[70], i467[69], i467[68], i467[67], i467[66], i467[65], i467[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373_reduce(input wire [111:0] i468, input wire [127:0] i469, input wire [143:0] i470, input wire [159:0] i471, output wire [161:0] y);
wire [161:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i468[111], i468[110], i468[109], i468[108], i468[107], i468[106], i468[105], i468[104], i468[103], i468[102], i468[101], i468[100], i468[99], i468[98], i468[97], i468[96], i468[95], i468[94], i468[93], i468[92], i468[91], i468[90], i468[89], i468[88], i468[87], i468[86], i468[85], i468[84], i468[83], i468[82], i468[81], i468[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i469[127], i469[126], i469[125], i469[124], i469[123], i469[122], i469[121], i469[120], i469[119], i469[118], i469[117], i469[116], i469[115], i469[114], i469[113], i469[112], i469[111], i469[110], i469[109], i469[108], i469[107], i469[106], i469[105], i469[104], i469[103], i469[102], i469[101], i469[100], i469[99], i469[98], i469[97], i469[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i470[143], i470[142], i470[141], i470[140], i470[139], i470[138], i470[137], i470[136], i470[135], i470[134], i470[133], i470[132], i470[131], i470[130], i470[129], i470[128], i470[127], i470[126], i470[125], i470[124], i470[123], i470[122], i470[121], i470[120], i470[119], i470[118], i470[117], i470[116], i470[115], i470[114], i470[113], i470[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t3 = {1'b0, 1'b0, i471[159], i471[158], i471[157], i471[156], i471[155], i471[154], i471[153], i471[152], i471[151], i471[150], i471[149], i471[148], i471[147], i471[146], i471[145], i471[144], i471[143], i471[142], i471[141], i471[140], i471[139], i471[138], i471[137], i471[136], i471[135], i471[134], i471[133], i471[132], i471[131], i471[130], i471[129], i471[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376_reduce(input wire [63:0] i472, input wire [79:0] i473, input wire [95:0] i474, input wire [111:0] i475, output wire [113:0] y);
wire [113:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i472[63], i472[62], i472[61], i472[60], i472[59], i472[58], i472[57], i472[56], i472[55], i472[54], i472[53], i472[52], i472[51], i472[50], i472[49], i472[48], i472[47], i472[46], i472[45], i472[44], i472[43], i472[42], i472[41], i472[40], i472[39], i472[38], i472[37], i472[36], i472[35], i472[34], i472[33], i472[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i473[79], i473[78], i473[77], i473[76], i473[75], i473[74], i473[73], i473[72], i473[71], i473[70], i473[69], i473[68], i473[67], i473[66], i473[65], i473[64], i473[63], i473[62], i473[61], i473[60], i473[59], i473[58], i473[57], i473[56], i473[55], i473[54], i473[53], i473[52], i473[51], i473[50], i473[49], i473[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i474[95], i474[94], i474[93], i474[92], i474[91], i474[90], i474[89], i474[88], i474[87], i474[86], i474[85], i474[84], i474[83], i474[82], i474[81], i474[80], i474[79], i474[78], i474[77], i474[76], i474[75], i474[74], i474[73], i474[72], i474[71], i474[70], i474[69], i474[68], i474[67], i474[66], i474[65], i474[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t3 = {1'b0, 1'b0, i475[111], i475[110], i475[109], i475[108], i475[107], i475[106], i475[105], i475[104], i475[103], i475[102], i475[101], i475[100], i475[99], i475[98], i475[97], i475[96], i475[95], i475[94], i475[93], i475[92], i475[91], i475[90], i475[89], i475[88], i475[87], i475[86], i475[85], i475[84], i475[83], i475[82], i475[81], i475[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379_reduce(input wire [127:0] i476, input wire [143:0] i477, input wire [159:0] i478, input wire [175:0] i479, output wire [177:0] y);
wire [177:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i476[127], i476[126], i476[125], i476[124], i476[123], i476[122], i476[121], i476[120], i476[119], i476[118], i476[117], i476[116], i476[115], i476[114], i476[113], i476[112], i476[111], i476[110], i476[109], i476[108], i476[107], i476[106], i476[105], i476[104], i476[103], i476[102], i476[101], i476[100], i476[99], i476[98], i476[97], i476[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i477[143], i477[142], i477[141], i477[140], i477[139], i477[138], i477[137], i477[136], i477[135], i477[134], i477[133], i477[132], i477[131], i477[130], i477[129], i477[128], i477[127], i477[126], i477[125], i477[124], i477[123], i477[122], i477[121], i477[120], i477[119], i477[118], i477[117], i477[116], i477[115], i477[114], i477[113], i477[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i478[159], i478[158], i478[157], i478[156], i478[155], i478[154], i478[153], i478[152], i478[151], i478[150], i478[149], i478[148], i478[147], i478[146], i478[145], i478[144], i478[143], i478[142], i478[141], i478[140], i478[139], i478[138], i478[137], i478[136], i478[135], i478[134], i478[133], i478[132], i478[131], i478[130], i478[129], i478[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t3 = {1'b0, 1'b0, i479[175], i479[174], i479[173], i479[172], i479[171], i479[170], i479[169], i479[168], i479[167], i479[166], i479[165], i479[164], i479[163], i479[162], i479[161], i479[160], i479[159], i479[158], i479[157], i479[156], i479[155], i479[154], i479[153], i479[152], i479[151], i479[150], i479[149], i479[148], i479[147], i479[146], i479[145], i479[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382_reduce(input wire [79:0] i480, input wire [95:0] i481, input wire [111:0] i482, input wire [127:0] i483, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i480[79], i480[78], i480[77], i480[76], i480[75], i480[74], i480[73], i480[72], i480[71], i480[70], i480[69], i480[68], i480[67], i480[66], i480[65], i480[64], i480[63], i480[62], i480[61], i480[60], i480[59], i480[58], i480[57], i480[56], i480[55], i480[54], i480[53], i480[52], i480[51], i480[50], i480[49], i480[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i481[95], i481[94], i481[93], i481[92], i481[91], i481[90], i481[89], i481[88], i481[87], i481[86], i481[85], i481[84], i481[83], i481[82], i481[81], i481[80], i481[79], i481[78], i481[77], i481[76], i481[75], i481[74], i481[73], i481[72], i481[71], i481[70], i481[69], i481[68], i481[67], i481[66], i481[65], i481[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i482[111], i482[110], i482[109], i482[108], i482[107], i482[106], i482[105], i482[104], i482[103], i482[102], i482[101], i482[100], i482[99], i482[98], i482[97], i482[96], i482[95], i482[94], i482[93], i482[92], i482[91], i482[90], i482[89], i482[88], i482[87], i482[86], i482[85], i482[84], i482[83], i482[82], i482[81], i482[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t3 = {1'b0, 1'b0, i483[127], i483[126], i483[125], i483[124], i483[123], i483[122], i483[121], i483[120], i483[119], i483[118], i483[117], i483[116], i483[115], i483[114], i483[113], i483[112], i483[111], i483[110], i483[109], i483[108], i483[107], i483[106], i483[105], i483[104], i483[103], i483[102], i483[101], i483[100], i483[99], i483[98], i483[97], i483[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385_reduce(input wire [143:0] i484, input wire [159:0] i485, input wire [175:0] i486, input wire [191:0] i487, output wire [193:0] y);
wire [193:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i484[143], i484[142], i484[141], i484[140], i484[139], i484[138], i484[137], i484[136], i484[135], i484[134], i484[133], i484[132], i484[131], i484[130], i484[129], i484[128], i484[127], i484[126], i484[125], i484[124], i484[123], i484[122], i484[121], i484[120], i484[119], i484[118], i484[117], i484[116], i484[115], i484[114], i484[113], i484[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i485[159], i485[158], i485[157], i485[156], i485[155], i485[154], i485[153], i485[152], i485[151], i485[150], i485[149], i485[148], i485[147], i485[146], i485[145], i485[144], i485[143], i485[142], i485[141], i485[140], i485[139], i485[138], i485[137], i485[136], i485[135], i485[134], i485[133], i485[132], i485[131], i485[130], i485[129], i485[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i486[175], i486[174], i486[173], i486[172], i486[171], i486[170], i486[169], i486[168], i486[167], i486[166], i486[165], i486[164], i486[163], i486[162], i486[161], i486[160], i486[159], i486[158], i486[157], i486[156], i486[155], i486[154], i486[153], i486[152], i486[151], i486[150], i486[149], i486[148], i486[147], i486[146], i486[145], i486[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t3 = {1'b0, 1'b0, i487[191], i487[190], i487[189], i487[188], i487[187], i487[186], i487[185], i487[184], i487[183], i487[182], i487[181], i487[180], i487[179], i487[178], i487[177], i487[176], i487[175], i487[174], i487[173], i487[172], i487[171], i487[170], i487[169], i487[168], i487[167], i487[166], i487[165], i487[164], i487[163], i487[162], i487[161], i487[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388_reduce(input wire [95:0] i488, input wire [111:0] i489, input wire [127:0] i490, input wire [143:0] i491, output wire [145:0] y);
wire [145:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i488[95], i488[94], i488[93], i488[92], i488[91], i488[90], i488[89], i488[88], i488[87], i488[86], i488[85], i488[84], i488[83], i488[82], i488[81], i488[80], i488[79], i488[78], i488[77], i488[76], i488[75], i488[74], i488[73], i488[72], i488[71], i488[70], i488[69], i488[68], i488[67], i488[66], i488[65], i488[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i489[111], i489[110], i489[109], i489[108], i489[107], i489[106], i489[105], i489[104], i489[103], i489[102], i489[101], i489[100], i489[99], i489[98], i489[97], i489[96], i489[95], i489[94], i489[93], i489[92], i489[91], i489[90], i489[89], i489[88], i489[87], i489[86], i489[85], i489[84], i489[83], i489[82], i489[81], i489[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[127], i490[126], i490[125], i490[124], i490[123], i490[122], i490[121], i490[120], i490[119], i490[118], i490[117], i490[116], i490[115], i490[114], i490[113], i490[112], i490[111], i490[110], i490[109], i490[108], i490[107], i490[106], i490[105], i490[104], i490[103], i490[102], i490[101], i490[100], i490[99], i490[98], i490[97], i490[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t3 = {1'b0, 1'b0, i491[143], i491[142], i491[141], i491[140], i491[139], i491[138], i491[137], i491[136], i491[135], i491[134], i491[133], i491[132], i491[131], i491[130], i491[129], i491[128], i491[127], i491[126], i491[125], i491[124], i491[123], i491[122], i491[121], i491[120], i491[119], i491[118], i491[117], i491[116], i491[115], i491[114], i491[113], i491[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391_reduce(input wire [159:0] i492, input wire [175:0] i493, input wire [191:0] i494, input wire [207:0] i495, output wire [209:0] y);
wire [209:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i492[159], i492[158], i492[157], i492[156], i492[155], i492[154], i492[153], i492[152], i492[151], i492[150], i492[149], i492[148], i492[147], i492[146], i492[145], i492[144], i492[143], i492[142], i492[141], i492[140], i492[139], i492[138], i492[137], i492[136], i492[135], i492[134], i492[133], i492[132], i492[131], i492[130], i492[129], i492[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[175], i493[174], i493[173], i493[172], i493[171], i493[170], i493[169], i493[168], i493[167], i493[166], i493[165], i493[164], i493[163], i493[162], i493[161], i493[160], i493[159], i493[158], i493[157], i493[156], i493[155], i493[154], i493[153], i493[152], i493[151], i493[150], i493[149], i493[148], i493[147], i493[146], i493[145], i493[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i494[191], i494[190], i494[189], i494[188], i494[187], i494[186], i494[185], i494[184], i494[183], i494[182], i494[181], i494[180], i494[179], i494[178], i494[177], i494[176], i494[175], i494[174], i494[173], i494[172], i494[171], i494[170], i494[169], i494[168], i494[167], i494[166], i494[165], i494[164], i494[163], i494[162], i494[161], i494[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t3 = {1'b0, 1'b0, i495[207], i495[206], i495[205], i495[204], i495[203], i495[202], i495[201], i495[200], i495[199], i495[198], i495[197], i495[196], i495[195], i495[194], i495[193], i495[192], i495[191], i495[190], i495[189], i495[188], i495[187], i495[186], i495[185], i495[184], i495[183], i495[182], i495[181], i495[180], i495[179], i495[178], i495[177], i495[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394_reduce(input wire [111:0] i496, input wire [127:0] i497, input wire [143:0] i498, input wire [159:0] i499, output wire [161:0] y);
wire [161:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i496[111], i496[110], i496[109], i496[108], i496[107], i496[106], i496[105], i496[104], i496[103], i496[102], i496[101], i496[100], i496[99], i496[98], i496[97], i496[96], i496[95], i496[94], i496[93], i496[92], i496[91], i496[90], i496[89], i496[88], i496[87], i496[86], i496[85], i496[84], i496[83], i496[82], i496[81], i496[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[127], i497[126], i497[125], i497[124], i497[123], i497[122], i497[121], i497[120], i497[119], i497[118], i497[117], i497[116], i497[115], i497[114], i497[113], i497[112], i497[111], i497[110], i497[109], i497[108], i497[107], i497[106], i497[105], i497[104], i497[103], i497[102], i497[101], i497[100], i497[99], i497[98], i497[97], i497[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i498[143], i498[142], i498[141], i498[140], i498[139], i498[138], i498[137], i498[136], i498[135], i498[134], i498[133], i498[132], i498[131], i498[130], i498[129], i498[128], i498[127], i498[126], i498[125], i498[124], i498[123], i498[122], i498[121], i498[120], i498[119], i498[118], i498[117], i498[116], i498[115], i498[114], i498[113], i498[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t3 = {1'b0, 1'b0, i499[159], i499[158], i499[157], i499[156], i499[155], i499[154], i499[153], i499[152], i499[151], i499[150], i499[149], i499[148], i499[147], i499[146], i499[145], i499[144], i499[143], i499[142], i499[141], i499[140], i499[139], i499[138], i499[137], i499[136], i499[135], i499[134], i499[133], i499[132], i499[131], i499[130], i499[129], i499[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397_reduce(input wire [175:0] i500, input wire [191:0] i501, input wire [207:0] i502, input wire [223:0] i503, output wire [225:0] y);
wire [225:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i500[175], i500[174], i500[173], i500[172], i500[171], i500[170], i500[169], i500[168], i500[167], i500[166], i500[165], i500[164], i500[163], i500[162], i500[161], i500[160], i500[159], i500[158], i500[157], i500[156], i500[155], i500[154], i500[153], i500[152], i500[151], i500[150], i500[149], i500[148], i500[147], i500[146], i500[145], i500[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i501[191], i501[190], i501[189], i501[188], i501[187], i501[186], i501[185], i501[184], i501[183], i501[182], i501[181], i501[180], i501[179], i501[178], i501[177], i501[176], i501[175], i501[174], i501[173], i501[172], i501[171], i501[170], i501[169], i501[168], i501[167], i501[166], i501[165], i501[164], i501[163], i501[162], i501[161], i501[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i502[207], i502[206], i502[205], i502[204], i502[203], i502[202], i502[201], i502[200], i502[199], i502[198], i502[197], i502[196], i502[195], i502[194], i502[193], i502[192], i502[191], i502[190], i502[189], i502[188], i502[187], i502[186], i502[185], i502[184], i502[183], i502[182], i502[181], i502[180], i502[179], i502[178], i502[177], i502[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t3 = {1'b0, 1'b0, i503[223], i503[222], i503[221], i503[220], i503[219], i503[218], i503[217], i503[216], i503[215], i503[214], i503[213], i503[212], i503[211], i503[210], i503[209], i503[208], i503[207], i503[206], i503[205], i503[204], i503[203], i503[202], i503[201], i503[200], i503[199], i503[198], i503[197], i503[196], i503[195], i503[194], i503[193], i503[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400_reduce(input wire [127:0] i504, input wire [143:0] i505, input wire [159:0] i506, input wire [175:0] i507, output wire [177:0] y);
wire [177:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i504[127], i504[126], i504[125], i504[124], i504[123], i504[122], i504[121], i504[120], i504[119], i504[118], i504[117], i504[116], i504[115], i504[114], i504[113], i504[112], i504[111], i504[110], i504[109], i504[108], i504[107], i504[106], i504[105], i504[104], i504[103], i504[102], i504[101], i504[100], i504[99], i504[98], i504[97], i504[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i505[143], i505[142], i505[141], i505[140], i505[139], i505[138], i505[137], i505[136], i505[135], i505[134], i505[133], i505[132], i505[131], i505[130], i505[129], i505[128], i505[127], i505[126], i505[125], i505[124], i505[123], i505[122], i505[121], i505[120], i505[119], i505[118], i505[117], i505[116], i505[115], i505[114], i505[113], i505[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i506[159], i506[158], i506[157], i506[156], i506[155], i506[154], i506[153], i506[152], i506[151], i506[150], i506[149], i506[148], i506[147], i506[146], i506[145], i506[144], i506[143], i506[142], i506[141], i506[140], i506[139], i506[138], i506[137], i506[136], i506[135], i506[134], i506[133], i506[132], i506[131], i506[130], i506[129], i506[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t3 = {1'b0, 1'b0, i507[175], i507[174], i507[173], i507[172], i507[171], i507[170], i507[169], i507[168], i507[167], i507[166], i507[165], i507[164], i507[163], i507[162], i507[161], i507[160], i507[159], i507[158], i507[157], i507[156], i507[155], i507[154], i507[153], i507[152], i507[151], i507[150], i507[149], i507[148], i507[147], i507[146], i507[145], i507[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403_reduce(input wire [191:0] i508, input wire [207:0] i509, input wire [223:0] i510, input wire [239:0] i511, output wire [241:0] y);
wire [241:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i508[191], i508[190], i508[189], i508[188], i508[187], i508[186], i508[185], i508[184], i508[183], i508[182], i508[181], i508[180], i508[179], i508[178], i508[177], i508[176], i508[175], i508[174], i508[173], i508[172], i508[171], i508[170], i508[169], i508[168], i508[167], i508[166], i508[165], i508[164], i508[163], i508[162], i508[161], i508[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i509[207], i509[206], i509[205], i509[204], i509[203], i509[202], i509[201], i509[200], i509[199], i509[198], i509[197], i509[196], i509[195], i509[194], i509[193], i509[192], i509[191], i509[190], i509[189], i509[188], i509[187], i509[186], i509[185], i509[184], i509[183], i509[182], i509[181], i509[180], i509[179], i509[178], i509[177], i509[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i510[223], i510[222], i510[221], i510[220], i510[219], i510[218], i510[217], i510[216], i510[215], i510[214], i510[213], i510[212], i510[211], i510[210], i510[209], i510[208], i510[207], i510[206], i510[205], i510[204], i510[203], i510[202], i510[201], i510[200], i510[199], i510[198], i510[197], i510[196], i510[195], i510[194], i510[193], i510[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t3 = {1'b0, 1'b0, i511[239], i511[238], i511[237], i511[236], i511[235], i511[234], i511[233], i511[232], i511[231], i511[230], i511[229], i511[228], i511[227], i511[226], i511[225], i511[224], i511[223], i511[222], i511[221], i511[220], i511[219], i511[218], i511[217], i511[216], i511[215], i511[214], i511[213], i511[212], i511[211], i511[210], i511[209], i511[208], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406_reduce(input wire [143:0] i512, input wire [159:0] i513, input wire [175:0] i514, input wire [191:0] i515, output wire [193:0] y);
wire [193:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i512[143], i512[142], i512[141], i512[140], i512[139], i512[138], i512[137], i512[136], i512[135], i512[134], i512[133], i512[132], i512[131], i512[130], i512[129], i512[128], i512[127], i512[126], i512[125], i512[124], i512[123], i512[122], i512[121], i512[120], i512[119], i512[118], i512[117], i512[116], i512[115], i512[114], i512[113], i512[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i513[159], i513[158], i513[157], i513[156], i513[155], i513[154], i513[153], i513[152], i513[151], i513[150], i513[149], i513[148], i513[147], i513[146], i513[145], i513[144], i513[143], i513[142], i513[141], i513[140], i513[139], i513[138], i513[137], i513[136], i513[135], i513[134], i513[133], i513[132], i513[131], i513[130], i513[129], i513[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i514[175], i514[174], i514[173], i514[172], i514[171], i514[170], i514[169], i514[168], i514[167], i514[166], i514[165], i514[164], i514[163], i514[162], i514[161], i514[160], i514[159], i514[158], i514[157], i514[156], i514[155], i514[154], i514[153], i514[152], i514[151], i514[150], i514[149], i514[148], i514[147], i514[146], i514[145], i514[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t3 = {1'b0, 1'b0, i515[191], i515[190], i515[189], i515[188], i515[187], i515[186], i515[185], i515[184], i515[183], i515[182], i515[181], i515[180], i515[179], i515[178], i515[177], i515[176], i515[175], i515[174], i515[173], i515[172], i515[171], i515[170], i515[169], i515[168], i515[167], i515[166], i515[165], i515[164], i515[163], i515[162], i515[161], i515[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409_reduce(input wire [207:0] i516, input wire [223:0] i517, input wire [239:0] i518, input wire [255:0] i519, output wire [257:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i516[207], i516[206], i516[205], i516[204], i516[203], i516[202], i516[201], i516[200], i516[199], i516[198], i516[197], i516[196], i516[195], i516[194], i516[193], i516[192], i516[191], i516[190], i516[189], i516[188], i516[187], i516[186], i516[185], i516[184], i516[183], i516[182], i516[181], i516[180], i516[179], i516[178], i516[177], i516[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i517[223], i517[222], i517[221], i517[220], i517[219], i517[218], i517[217], i517[216], i517[215], i517[214], i517[213], i517[212], i517[211], i517[210], i517[209], i517[208], i517[207], i517[206], i517[205], i517[204], i517[203], i517[202], i517[201], i517[200], i517[199], i517[198], i517[197], i517[196], i517[195], i517[194], i517[193], i517[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i518[239], i518[238], i518[237], i518[236], i518[235], i518[234], i518[233], i518[232], i518[231], i518[230], i518[229], i518[228], i518[227], i518[226], i518[225], i518[224], i518[223], i518[222], i518[221], i518[220], i518[219], i518[218], i518[217], i518[216], i518[215], i518[214], i518[213], i518[212], i518[211], i518[210], i518[209], i518[208], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t3 = {i519[255], i519[254], i519[253], i519[252], i519[251], i519[250], i519[249], i519[248], i519[247], i519[246], i519[245], i519[244], i519[243], i519[242], i519[241], i519[240], i519[239], i519[238], i519[237], i519[236], i519[235], i519[234], i519[233], i519[232], i519[231], i519[230], i519[229], i519[228], i519[227], i519[226], i519[225], i519[224], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_436_reduce(input wire [81:0] i520, input wire [145:0] i521, input wire [97:0] i522, input wire [161:0] i523, output wire [163:0] y);
wire [163:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i520[81], i520[80], i520[79], i520[78], i520[77], i520[76], i520[75], i520[74], i520[73], i520[72], i520[71], i520[70], i520[69], i520[68], i520[67], i520[66], i520[65], i520[64], i520[63], i520[62], i520[61], i520[60], i520[59], i520[58], i520[57], i520[56], i520[55], i520[54], i520[53], i520[52], i520[51], i520[50], i520[49], i520[48], i520[47], i520[46], i520[45], i520[44], i520[43], i520[42], i520[41], i520[40], i520[39], i520[38], i520[37], i520[36], i520[35], i520[34], i520[33], i520[32], i520[31], i520[30], i520[29], i520[28], i520[27], i520[26], i520[25], i520[24], i520[23], i520[22], i520[21], i520[20], i520[19], i520[18], i520[17], i520[16], i520[15], i520[14], i520[13], i520[12], i520[11], i520[10], i520[9], i520[8], i520[7], i520[6], i520[5], i520[4], i520[3], i520[2], i520[1], i520[0]};
wire [163:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i521[145], i521[144], i521[143], i521[142], i521[141], i521[140], i521[139], i521[138], i521[137], i521[136], i521[135], i521[134], i521[133], i521[132], i521[131], i521[130], i521[129], i521[128], i521[127], i521[126], i521[125], i521[124], i521[123], i521[122], i521[121], i521[120], i521[119], i521[118], i521[117], i521[116], i521[115], i521[114], i521[113], i521[112], i521[111], i521[110], i521[109], i521[108], i521[107], i521[106], i521[105], i521[104], i521[103], i521[102], i521[101], i521[100], i521[99], i521[98], i521[97], i521[96], i521[95], i521[94], i521[93], i521[92], i521[91], i521[90], i521[89], i521[88], i521[87], i521[86], i521[85], i521[84], i521[83], i521[82], i521[81], i521[80], i521[79], i521[78], i521[77], i521[76], i521[75], i521[74], i521[73], i521[72], i521[71], i521[70], i521[69], i521[68], i521[67], i521[66], i521[65], i521[64], i521[63], i521[62], i521[61], i521[60], i521[59], i521[58], i521[57], i521[56], i521[55], i521[54], i521[53], i521[52], i521[51], i521[50], i521[49], i521[48], i521[47], i521[46], i521[45], i521[44], i521[43], i521[42], i521[41], i521[40], i521[39], i521[38], i521[37], i521[36], i521[35], i521[34], i521[33], i521[32], i521[31], i521[30], i521[29], i521[28], i521[27], i521[26], i521[25], i521[24], i521[23], i521[22], i521[21], i521[20], i521[19], i521[18], i521[17], i521[16], i521[15], i521[14], i521[13], i521[12], i521[11], i521[10], i521[9], i521[8], i521[7], i521[6], i521[5], i521[4], i521[3], i521[2], i521[1], i521[0]};
wire [163:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i522[97], i522[96], i522[95], i522[94], i522[93], i522[92], i522[91], i522[90], i522[89], i522[88], i522[87], i522[86], i522[85], i522[84], i522[83], i522[82], i522[81], i522[80], i522[79], i522[78], i522[77], i522[76], i522[75], i522[74], i522[73], i522[72], i522[71], i522[70], i522[69], i522[68], i522[67], i522[66], i522[65], i522[64], i522[63], i522[62], i522[61], i522[60], i522[59], i522[58], i522[57], i522[56], i522[55], i522[54], i522[53], i522[52], i522[51], i522[50], i522[49], i522[48], i522[47], i522[46], i522[45], i522[44], i522[43], i522[42], i522[41], i522[40], i522[39], i522[38], i522[37], i522[36], i522[35], i522[34], i522[33], i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0]};
wire [163:0] t3 = {1'b0, 1'b0, i523[161], i523[160], i523[159], i523[158], i523[157], i523[156], i523[155], i523[154], i523[153], i523[152], i523[151], i523[150], i523[149], i523[148], i523[147], i523[146], i523[145], i523[144], i523[143], i523[142], i523[141], i523[140], i523[139], i523[138], i523[137], i523[136], i523[135], i523[134], i523[133], i523[132], i523[131], i523[130], i523[129], i523[128], i523[127], i523[126], i523[125], i523[124], i523[123], i523[122], i523[121], i523[120], i523[119], i523[118], i523[117], i523[116], i523[115], i523[114], i523[113], i523[112], i523[111], i523[110], i523[109], i523[108], i523[107], i523[106], i523[105], i523[104], i523[103], i523[102], i523[101], i523[100], i523[99], i523[98], i523[97], i523[96], i523[95], i523[94], i523[93], i523[92], i523[91], i523[90], i523[89], i523[88], i523[87], i523[86], i523[85], i523[84], i523[83], i523[82], i523[81], i523[80], i523[79], i523[78], i523[77], i523[76], i523[75], i523[74], i523[73], i523[72], i523[71], i523[70], i523[69], i523[68], i523[67], i523[66], i523[65], i523[64], i523[63], i523[62], i523[61], i523[60], i523[59], i523[58], i523[57], i523[56], i523[55], i523[54], i523[53], i523[52], i523[51], i523[50], i523[49], i523[48], i523[47], i523[46], i523[45], i523[44], i523[43], i523[42], i523[41], i523[40], i523[39], i523[38], i523[37], i523[36], i523[35], i523[34], i523[33], i523[32], i523[31], i523[30], i523[29], i523[28], i523[27], i523[26], i523[25], i523[24], i523[23], i523[22], i523[21], i523[20], i523[19], i523[18], i523[17], i523[16], i523[15], i523[14], i523[13], i523[12], i523[11], i523[10], i523[9], i523[8], i523[7], i523[6], i523[5], i523[4], i523[3], i523[2], i523[1], i523[0]};
wire [163:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_439_reduce(input wire [113:0] i524, input wire [177:0] i525, input wire [129:0] i526, input wire [193:0] i527, output wire [195:0] y);
wire [195:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i524[113], i524[112], i524[111], i524[110], i524[109], i524[108], i524[107], i524[106], i524[105], i524[104], i524[103], i524[102], i524[101], i524[100], i524[99], i524[98], i524[97], i524[96], i524[95], i524[94], i524[93], i524[92], i524[91], i524[90], i524[89], i524[88], i524[87], i524[86], i524[85], i524[84], i524[83], i524[82], i524[81], i524[80], i524[79], i524[78], i524[77], i524[76], i524[75], i524[74], i524[73], i524[72], i524[71], i524[70], i524[69], i524[68], i524[67], i524[66], i524[65], i524[64], i524[63], i524[62], i524[61], i524[60], i524[59], i524[58], i524[57], i524[56], i524[55], i524[54], i524[53], i524[52], i524[51], i524[50], i524[49], i524[48], i524[47], i524[46], i524[45], i524[44], i524[43], i524[42], i524[41], i524[40], i524[39], i524[38], i524[37], i524[36], i524[35], i524[34], i524[33], i524[32], i524[31], i524[30], i524[29], i524[28], i524[27], i524[26], i524[25], i524[24], i524[23], i524[22], i524[21], i524[20], i524[19], i524[18], i524[17], i524[16], i524[15], i524[14], i524[13], i524[12], i524[11], i524[10], i524[9], i524[8], i524[7], i524[6], i524[5], i524[4], i524[3], i524[2], i524[1], i524[0]};
wire [195:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i525[177], i525[176], i525[175], i525[174], i525[173], i525[172], i525[171], i525[170], i525[169], i525[168], i525[167], i525[166], i525[165], i525[164], i525[163], i525[162], i525[161], i525[160], i525[159], i525[158], i525[157], i525[156], i525[155], i525[154], i525[153], i525[152], i525[151], i525[150], i525[149], i525[148], i525[147], i525[146], i525[145], i525[144], i525[143], i525[142], i525[141], i525[140], i525[139], i525[138], i525[137], i525[136], i525[135], i525[134], i525[133], i525[132], i525[131], i525[130], i525[129], i525[128], i525[127], i525[126], i525[125], i525[124], i525[123], i525[122], i525[121], i525[120], i525[119], i525[118], i525[117], i525[116], i525[115], i525[114], i525[113], i525[112], i525[111], i525[110], i525[109], i525[108], i525[107], i525[106], i525[105], i525[104], i525[103], i525[102], i525[101], i525[100], i525[99], i525[98], i525[97], i525[96], i525[95], i525[94], i525[93], i525[92], i525[91], i525[90], i525[89], i525[88], i525[87], i525[86], i525[85], i525[84], i525[83], i525[82], i525[81], i525[80], i525[79], i525[78], i525[77], i525[76], i525[75], i525[74], i525[73], i525[72], i525[71], i525[70], i525[69], i525[68], i525[67], i525[66], i525[65], i525[64], i525[63], i525[62], i525[61], i525[60], i525[59], i525[58], i525[57], i525[56], i525[55], i525[54], i525[53], i525[52], i525[51], i525[50], i525[49], i525[48], i525[47], i525[46], i525[45], i525[44], i525[43], i525[42], i525[41], i525[40], i525[39], i525[38], i525[37], i525[36], i525[35], i525[34], i525[33], i525[32], i525[31], i525[30], i525[29], i525[28], i525[27], i525[26], i525[25], i525[24], i525[23], i525[22], i525[21], i525[20], i525[19], i525[18], i525[17], i525[16], i525[15], i525[14], i525[13], i525[12], i525[11], i525[10], i525[9], i525[8], i525[7], i525[6], i525[5], i525[4], i525[3], i525[2], i525[1], i525[0]};
wire [195:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i526[129], i526[128], i526[127], i526[126], i526[125], i526[124], i526[123], i526[122], i526[121], i526[120], i526[119], i526[118], i526[117], i526[116], i526[115], i526[114], i526[113], i526[112], i526[111], i526[110], i526[109], i526[108], i526[107], i526[106], i526[105], i526[104], i526[103], i526[102], i526[101], i526[100], i526[99], i526[98], i526[97], i526[96], i526[95], i526[94], i526[93], i526[92], i526[91], i526[90], i526[89], i526[88], i526[87], i526[86], i526[85], i526[84], i526[83], i526[82], i526[81], i526[80], i526[79], i526[78], i526[77], i526[76], i526[75], i526[74], i526[73], i526[72], i526[71], i526[70], i526[69], i526[68], i526[67], i526[66], i526[65], i526[64], i526[63], i526[62], i526[61], i526[60], i526[59], i526[58], i526[57], i526[56], i526[55], i526[54], i526[53], i526[52], i526[51], i526[50], i526[49], i526[48], i526[47], i526[46], i526[45], i526[44], i526[43], i526[42], i526[41], i526[40], i526[39], i526[38], i526[37], i526[36], i526[35], i526[34], i526[33], i526[32], i526[31], i526[30], i526[29], i526[28], i526[27], i526[26], i526[25], i526[24], i526[23], i526[22], i526[21], i526[20], i526[19], i526[18], i526[17], i526[16], i526[15], i526[14], i526[13], i526[12], i526[11], i526[10], i526[9], i526[8], i526[7], i526[6], i526[5], i526[4], i526[3], i526[2], i526[1], i526[0]};
wire [195:0] t3 = {1'b0, 1'b0, i527[193], i527[192], i527[191], i527[190], i527[189], i527[188], i527[187], i527[186], i527[185], i527[184], i527[183], i527[182], i527[181], i527[180], i527[179], i527[178], i527[177], i527[176], i527[175], i527[174], i527[173], i527[172], i527[171], i527[170], i527[169], i527[168], i527[167], i527[166], i527[165], i527[164], i527[163], i527[162], i527[161], i527[160], i527[159], i527[158], i527[157], i527[156], i527[155], i527[154], i527[153], i527[152], i527[151], i527[150], i527[149], i527[148], i527[147], i527[146], i527[145], i527[144], i527[143], i527[142], i527[141], i527[140], i527[139], i527[138], i527[137], i527[136], i527[135], i527[134], i527[133], i527[132], i527[131], i527[130], i527[129], i527[128], i527[127], i527[126], i527[125], i527[124], i527[123], i527[122], i527[121], i527[120], i527[119], i527[118], i527[117], i527[116], i527[115], i527[114], i527[113], i527[112], i527[111], i527[110], i527[109], i527[108], i527[107], i527[106], i527[105], i527[104], i527[103], i527[102], i527[101], i527[100], i527[99], i527[98], i527[97], i527[96], i527[95], i527[94], i527[93], i527[92], i527[91], i527[90], i527[89], i527[88], i527[87], i527[86], i527[85], i527[84], i527[83], i527[82], i527[81], i527[80], i527[79], i527[78], i527[77], i527[76], i527[75], i527[74], i527[73], i527[72], i527[71], i527[70], i527[69], i527[68], i527[67], i527[66], i527[65], i527[64], i527[63], i527[62], i527[61], i527[60], i527[59], i527[58], i527[57], i527[56], i527[55], i527[54], i527[53], i527[52], i527[51], i527[50], i527[49], i527[48], i527[47], i527[46], i527[45], i527[44], i527[43], i527[42], i527[41], i527[40], i527[39], i527[38], i527[37], i527[36], i527[35], i527[34], i527[33], i527[32], i527[31], i527[30], i527[29], i527[28], i527[27], i527[26], i527[25], i527[24], i527[23], i527[22], i527[21], i527[20], i527[19], i527[18], i527[17], i527[16], i527[15], i527[14], i527[13], i527[12], i527[11], i527[10], i527[9], i527[8], i527[7], i527[6], i527[5], i527[4], i527[3], i527[2], i527[1], i527[0]};
wire [195:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_442_reduce(input wire [145:0] i528, input wire [209:0] i529, input wire [161:0] i530, input wire [225:0] i531, output wire [227:0] y);
wire [227:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i528[145], i528[144], i528[143], i528[142], i528[141], i528[140], i528[139], i528[138], i528[137], i528[136], i528[135], i528[134], i528[133], i528[132], i528[131], i528[130], i528[129], i528[128], i528[127], i528[126], i528[125], i528[124], i528[123], i528[122], i528[121], i528[120], i528[119], i528[118], i528[117], i528[116], i528[115], i528[114], i528[113], i528[112], i528[111], i528[110], i528[109], i528[108], i528[107], i528[106], i528[105], i528[104], i528[103], i528[102], i528[101], i528[100], i528[99], i528[98], i528[97], i528[96], i528[95], i528[94], i528[93], i528[92], i528[91], i528[90], i528[89], i528[88], i528[87], i528[86], i528[85], i528[84], i528[83], i528[82], i528[81], i528[80], i528[79], i528[78], i528[77], i528[76], i528[75], i528[74], i528[73], i528[72], i528[71], i528[70], i528[69], i528[68], i528[67], i528[66], i528[65], i528[64], i528[63], i528[62], i528[61], i528[60], i528[59], i528[58], i528[57], i528[56], i528[55], i528[54], i528[53], i528[52], i528[51], i528[50], i528[49], i528[48], i528[47], i528[46], i528[45], i528[44], i528[43], i528[42], i528[41], i528[40], i528[39], i528[38], i528[37], i528[36], i528[35], i528[34], i528[33], i528[32], i528[31], i528[30], i528[29], i528[28], i528[27], i528[26], i528[25], i528[24], i528[23], i528[22], i528[21], i528[20], i528[19], i528[18], i528[17], i528[16], i528[15], i528[14], i528[13], i528[12], i528[11], i528[10], i528[9], i528[8], i528[7], i528[6], i528[5], i528[4], i528[3], i528[2], i528[1], i528[0]};
wire [227:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i529[209], i529[208], i529[207], i529[206], i529[205], i529[204], i529[203], i529[202], i529[201], i529[200], i529[199], i529[198], i529[197], i529[196], i529[195], i529[194], i529[193], i529[192], i529[191], i529[190], i529[189], i529[188], i529[187], i529[186], i529[185], i529[184], i529[183], i529[182], i529[181], i529[180], i529[179], i529[178], i529[177], i529[176], i529[175], i529[174], i529[173], i529[172], i529[171], i529[170], i529[169], i529[168], i529[167], i529[166], i529[165], i529[164], i529[163], i529[162], i529[161], i529[160], i529[159], i529[158], i529[157], i529[156], i529[155], i529[154], i529[153], i529[152], i529[151], i529[150], i529[149], i529[148], i529[147], i529[146], i529[145], i529[144], i529[143], i529[142], i529[141], i529[140], i529[139], i529[138], i529[137], i529[136], i529[135], i529[134], i529[133], i529[132], i529[131], i529[130], i529[129], i529[128], i529[127], i529[126], i529[125], i529[124], i529[123], i529[122], i529[121], i529[120], i529[119], i529[118], i529[117], i529[116], i529[115], i529[114], i529[113], i529[112], i529[111], i529[110], i529[109], i529[108], i529[107], i529[106], i529[105], i529[104], i529[103], i529[102], i529[101], i529[100], i529[99], i529[98], i529[97], i529[96], i529[95], i529[94], i529[93], i529[92], i529[91], i529[90], i529[89], i529[88], i529[87], i529[86], i529[85], i529[84], i529[83], i529[82], i529[81], i529[80], i529[79], i529[78], i529[77], i529[76], i529[75], i529[74], i529[73], i529[72], i529[71], i529[70], i529[69], i529[68], i529[67], i529[66], i529[65], i529[64], i529[63], i529[62], i529[61], i529[60], i529[59], i529[58], i529[57], i529[56], i529[55], i529[54], i529[53], i529[52], i529[51], i529[50], i529[49], i529[48], i529[47], i529[46], i529[45], i529[44], i529[43], i529[42], i529[41], i529[40], i529[39], i529[38], i529[37], i529[36], i529[35], i529[34], i529[33], i529[32], i529[31], i529[30], i529[29], i529[28], i529[27], i529[26], i529[25], i529[24], i529[23], i529[22], i529[21], i529[20], i529[19], i529[18], i529[17], i529[16], i529[15], i529[14], i529[13], i529[12], i529[11], i529[10], i529[9], i529[8], i529[7], i529[6], i529[5], i529[4], i529[3], i529[2], i529[1], i529[0]};
wire [227:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i530[161], i530[160], i530[159], i530[158], i530[157], i530[156], i530[155], i530[154], i530[153], i530[152], i530[151], i530[150], i530[149], i530[148], i530[147], i530[146], i530[145], i530[144], i530[143], i530[142], i530[141], i530[140], i530[139], i530[138], i530[137], i530[136], i530[135], i530[134], i530[133], i530[132], i530[131], i530[130], i530[129], i530[128], i530[127], i530[126], i530[125], i530[124], i530[123], i530[122], i530[121], i530[120], i530[119], i530[118], i530[117], i530[116], i530[115], i530[114], i530[113], i530[112], i530[111], i530[110], i530[109], i530[108], i530[107], i530[106], i530[105], i530[104], i530[103], i530[102], i530[101], i530[100], i530[99], i530[98], i530[97], i530[96], i530[95], i530[94], i530[93], i530[92], i530[91], i530[90], i530[89], i530[88], i530[87], i530[86], i530[85], i530[84], i530[83], i530[82], i530[81], i530[80], i530[79], i530[78], i530[77], i530[76], i530[75], i530[74], i530[73], i530[72], i530[71], i530[70], i530[69], i530[68], i530[67], i530[66], i530[65], i530[64], i530[63], i530[62], i530[61], i530[60], i530[59], i530[58], i530[57], i530[56], i530[55], i530[54], i530[53], i530[52], i530[51], i530[50], i530[49], i530[48], i530[47], i530[46], i530[45], i530[44], i530[43], i530[42], i530[41], i530[40], i530[39], i530[38], i530[37], i530[36], i530[35], i530[34], i530[33], i530[32], i530[31], i530[30], i530[29], i530[28], i530[27], i530[26], i530[25], i530[24], i530[23], i530[22], i530[21], i530[20], i530[19], i530[18], i530[17], i530[16], i530[15], i530[14], i530[13], i530[12], i530[11], i530[10], i530[9], i530[8], i530[7], i530[6], i530[5], i530[4], i530[3], i530[2], i530[1], i530[0]};
wire [227:0] t3 = {1'b0, 1'b0, i531[225], i531[224], i531[223], i531[222], i531[221], i531[220], i531[219], i531[218], i531[217], i531[216], i531[215], i531[214], i531[213], i531[212], i531[211], i531[210], i531[209], i531[208], i531[207], i531[206], i531[205], i531[204], i531[203], i531[202], i531[201], i531[200], i531[199], i531[198], i531[197], i531[196], i531[195], i531[194], i531[193], i531[192], i531[191], i531[190], i531[189], i531[188], i531[187], i531[186], i531[185], i531[184], i531[183], i531[182], i531[181], i531[180], i531[179], i531[178], i531[177], i531[176], i531[175], i531[174], i531[173], i531[172], i531[171], i531[170], i531[169], i531[168], i531[167], i531[166], i531[165], i531[164], i531[163], i531[162], i531[161], i531[160], i531[159], i531[158], i531[157], i531[156], i531[155], i531[154], i531[153], i531[152], i531[151], i531[150], i531[149], i531[148], i531[147], i531[146], i531[145], i531[144], i531[143], i531[142], i531[141], i531[140], i531[139], i531[138], i531[137], i531[136], i531[135], i531[134], i531[133], i531[132], i531[131], i531[130], i531[129], i531[128], i531[127], i531[126], i531[125], i531[124], i531[123], i531[122], i531[121], i531[120], i531[119], i531[118], i531[117], i531[116], i531[115], i531[114], i531[113], i531[112], i531[111], i531[110], i531[109], i531[108], i531[107], i531[106], i531[105], i531[104], i531[103], i531[102], i531[101], i531[100], i531[99], i531[98], i531[97], i531[96], i531[95], i531[94], i531[93], i531[92], i531[91], i531[90], i531[89], i531[88], i531[87], i531[86], i531[85], i531[84], i531[83], i531[82], i531[81], i531[80], i531[79], i531[78], i531[77], i531[76], i531[75], i531[74], i531[73], i531[72], i531[71], i531[70], i531[69], i531[68], i531[67], i531[66], i531[65], i531[64], i531[63], i531[62], i531[61], i531[60], i531[59], i531[58], i531[57], i531[56], i531[55], i531[54], i531[53], i531[52], i531[51], i531[50], i531[49], i531[48], i531[47], i531[46], i531[45], i531[44], i531[43], i531[42], i531[41], i531[40], i531[39], i531[38], i531[37], i531[36], i531[35], i531[34], i531[33], i531[32], i531[31], i531[30], i531[29], i531[28], i531[27], i531[26], i531[25], i531[24], i531[23], i531[22], i531[21], i531[20], i531[19], i531[18], i531[17], i531[16], i531[15], i531[14], i531[13], i531[12], i531[11], i531[10], i531[9], i531[8], i531[7], i531[6], i531[5], i531[4], i531[3], i531[2], i531[1], i531[0]};
wire [227:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_445_reduce(input wire [177:0] i532, input wire [241:0] i533, input wire [193:0] i534, input wire [257:0] i535, output wire [259:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i532[177], i532[176], i532[175], i532[174], i532[173], i532[172], i532[171], i532[170], i532[169], i532[168], i532[167], i532[166], i532[165], i532[164], i532[163], i532[162], i532[161], i532[160], i532[159], i532[158], i532[157], i532[156], i532[155], i532[154], i532[153], i532[152], i532[151], i532[150], i532[149], i532[148], i532[147], i532[146], i532[145], i532[144], i532[143], i532[142], i532[141], i532[140], i532[139], i532[138], i532[137], i532[136], i532[135], i532[134], i532[133], i532[132], i532[131], i532[130], i532[129], i532[128], i532[127], i532[126], i532[125], i532[124], i532[123], i532[122], i532[121], i532[120], i532[119], i532[118], i532[117], i532[116], i532[115], i532[114], i532[113], i532[112], i532[111], i532[110], i532[109], i532[108], i532[107], i532[106], i532[105], i532[104], i532[103], i532[102], i532[101], i532[100], i532[99], i532[98], i532[97], i532[96], i532[95], i532[94], i532[93], i532[92], i532[91], i532[90], i532[89], i532[88], i532[87], i532[86], i532[85], i532[84], i532[83], i532[82], i532[81], i532[80], i532[79], i532[78], i532[77], i532[76], i532[75], i532[74], i532[73], i532[72], i532[71], i532[70], i532[69], i532[68], i532[67], i532[66], i532[65], i532[64], i532[63], i532[62], i532[61], i532[60], i532[59], i532[58], i532[57], i532[56], i532[55], i532[54], i532[53], i532[52], i532[51], i532[50], i532[49], i532[48], i532[47], i532[46], i532[45], i532[44], i532[43], i532[42], i532[41], i532[40], i532[39], i532[38], i532[37], i532[36], i532[35], i532[34], i532[33], i532[32], i532[31], i532[30], i532[29], i532[28], i532[27], i532[26], i532[25], i532[24], i532[23], i532[22], i532[21], i532[20], i532[19], i532[18], i532[17], i532[16], i532[15], i532[14], i532[13], i532[12], i532[11], i532[10], i532[9], i532[8], i532[7], i532[6], i532[5], i532[4], i532[3], i532[2], i532[1], i532[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i533[241], i533[240], i533[239], i533[238], i533[237], i533[236], i533[235], i533[234], i533[233], i533[232], i533[231], i533[230], i533[229], i533[228], i533[227], i533[226], i533[225], i533[224], i533[223], i533[222], i533[221], i533[220], i533[219], i533[218], i533[217], i533[216], i533[215], i533[214], i533[213], i533[212], i533[211], i533[210], i533[209], i533[208], i533[207], i533[206], i533[205], i533[204], i533[203], i533[202], i533[201], i533[200], i533[199], i533[198], i533[197], i533[196], i533[195], i533[194], i533[193], i533[192], i533[191], i533[190], i533[189], i533[188], i533[187], i533[186], i533[185], i533[184], i533[183], i533[182], i533[181], i533[180], i533[179], i533[178], i533[177], i533[176], i533[175], i533[174], i533[173], i533[172], i533[171], i533[170], i533[169], i533[168], i533[167], i533[166], i533[165], i533[164], i533[163], i533[162], i533[161], i533[160], i533[159], i533[158], i533[157], i533[156], i533[155], i533[154], i533[153], i533[152], i533[151], i533[150], i533[149], i533[148], i533[147], i533[146], i533[145], i533[144], i533[143], i533[142], i533[141], i533[140], i533[139], i533[138], i533[137], i533[136], i533[135], i533[134], i533[133], i533[132], i533[131], i533[130], i533[129], i533[128], i533[127], i533[126], i533[125], i533[124], i533[123], i533[122], i533[121], i533[120], i533[119], i533[118], i533[117], i533[116], i533[115], i533[114], i533[113], i533[112], i533[111], i533[110], i533[109], i533[108], i533[107], i533[106], i533[105], i533[104], i533[103], i533[102], i533[101], i533[100], i533[99], i533[98], i533[97], i533[96], i533[95], i533[94], i533[93], i533[92], i533[91], i533[90], i533[89], i533[88], i533[87], i533[86], i533[85], i533[84], i533[83], i533[82], i533[81], i533[80], i533[79], i533[78], i533[77], i533[76], i533[75], i533[74], i533[73], i533[72], i533[71], i533[70], i533[69], i533[68], i533[67], i533[66], i533[65], i533[64], i533[63], i533[62], i533[61], i533[60], i533[59], i533[58], i533[57], i533[56], i533[55], i533[54], i533[53], i533[52], i533[51], i533[50], i533[49], i533[48], i533[47], i533[46], i533[45], i533[44], i533[43], i533[42], i533[41], i533[40], i533[39], i533[38], i533[37], i533[36], i533[35], i533[34], i533[33], i533[32], i533[31], i533[30], i533[29], i533[28], i533[27], i533[26], i533[25], i533[24], i533[23], i533[22], i533[21], i533[20], i533[19], i533[18], i533[17], i533[16], i533[15], i533[14], i533[13], i533[12], i533[11], i533[10], i533[9], i533[8], i533[7], i533[6], i533[5], i533[4], i533[3], i533[2], i533[1], i533[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i534[193], i534[192], i534[191], i534[190], i534[189], i534[188], i534[187], i534[186], i534[185], i534[184], i534[183], i534[182], i534[181], i534[180], i534[179], i534[178], i534[177], i534[176], i534[175], i534[174], i534[173], i534[172], i534[171], i534[170], i534[169], i534[168], i534[167], i534[166], i534[165], i534[164], i534[163], i534[162], i534[161], i534[160], i534[159], i534[158], i534[157], i534[156], i534[155], i534[154], i534[153], i534[152], i534[151], i534[150], i534[149], i534[148], i534[147], i534[146], i534[145], i534[144], i534[143], i534[142], i534[141], i534[140], i534[139], i534[138], i534[137], i534[136], i534[135], i534[134], i534[133], i534[132], i534[131], i534[130], i534[129], i534[128], i534[127], i534[126], i534[125], i534[124], i534[123], i534[122], i534[121], i534[120], i534[119], i534[118], i534[117], i534[116], i534[115], i534[114], i534[113], i534[112], i534[111], i534[110], i534[109], i534[108], i534[107], i534[106], i534[105], i534[104], i534[103], i534[102], i534[101], i534[100], i534[99], i534[98], i534[97], i534[96], i534[95], i534[94], i534[93], i534[92], i534[91], i534[90], i534[89], i534[88], i534[87], i534[86], i534[85], i534[84], i534[83], i534[82], i534[81], i534[80], i534[79], i534[78], i534[77], i534[76], i534[75], i534[74], i534[73], i534[72], i534[71], i534[70], i534[69], i534[68], i534[67], i534[66], i534[65], i534[64], i534[63], i534[62], i534[61], i534[60], i534[59], i534[58], i534[57], i534[56], i534[55], i534[54], i534[53], i534[52], i534[51], i534[50], i534[49], i534[48], i534[47], i534[46], i534[45], i534[44], i534[43], i534[42], i534[41], i534[40], i534[39], i534[38], i534[37], i534[36], i534[35], i534[34], i534[33], i534[32], i534[31], i534[30], i534[29], i534[28], i534[27], i534[26], i534[25], i534[24], i534[23], i534[22], i534[21], i534[20], i534[19], i534[18], i534[17], i534[16], i534[15], i534[14], i534[13], i534[12], i534[11], i534[10], i534[9], i534[8], i534[7], i534[6], i534[5], i534[4], i534[3], i534[2], i534[1], i534[0]};
wire [255:0] t3 = {i535[255], i535[254], i535[253], i535[252], i535[251], i535[250], i535[249], i535[248], i535[247], i535[246], i535[245], i535[244], i535[243], i535[242], i535[241], i535[240], i535[239], i535[238], i535[237], i535[236], i535[235], i535[234], i535[233], i535[232], i535[231], i535[230], i535[229], i535[228], i535[227], i535[226], i535[225], i535[224], i535[223], i535[222], i535[221], i535[220], i535[219], i535[218], i535[217], i535[216], i535[215], i535[214], i535[213], i535[212], i535[211], i535[210], i535[209], i535[208], i535[207], i535[206], i535[205], i535[204], i535[203], i535[202], i535[201], i535[200], i535[199], i535[198], i535[197], i535[196], i535[195], i535[194], i535[193], i535[192], i535[191], i535[190], i535[189], i535[188], i535[187], i535[186], i535[185], i535[184], i535[183], i535[182], i535[181], i535[180], i535[179], i535[178], i535[177], i535[176], i535[175], i535[174], i535[173], i535[172], i535[171], i535[170], i535[169], i535[168], i535[167], i535[166], i535[165], i535[164], i535[163], i535[162], i535[161], i535[160], i535[159], i535[158], i535[157], i535[156], i535[155], i535[154], i535[153], i535[152], i535[151], i535[150], i535[149], i535[148], i535[147], i535[146], i535[145], i535[144], i535[143], i535[142], i535[141], i535[140], i535[139], i535[138], i535[137], i535[136], i535[135], i535[134], i535[133], i535[132], i535[131], i535[130], i535[129], i535[128], i535[127], i535[126], i535[125], i535[124], i535[123], i535[122], i535[121], i535[120], i535[119], i535[118], i535[117], i535[116], i535[115], i535[114], i535[113], i535[112], i535[111], i535[110], i535[109], i535[108], i535[107], i535[106], i535[105], i535[104], i535[103], i535[102], i535[101], i535[100], i535[99], i535[98], i535[97], i535[96], i535[95], i535[94], i535[93], i535[92], i535[91], i535[90], i535[89], i535[88], i535[87], i535[86], i535[85], i535[84], i535[83], i535[82], i535[81], i535[80], i535[79], i535[78], i535[77], i535[76], i535[75], i535[74], i535[73], i535[72], i535[71], i535[70], i535[69], i535[68], i535[67], i535[66], i535[65], i535[64], i535[63], i535[62], i535[61], i535[60], i535[59], i535[58], i535[57], i535[56], i535[55], i535[54], i535[53], i535[52], i535[51], i535[50], i535[49], i535[48], i535[47], i535[46], i535[45], i535[44], i535[43], i535[42], i535[41], i535[40], i535[39], i535[38], i535[37], i535[36], i535[35], i535[34], i535[33], i535[32], i535[31], i535[30], i535[29], i535[28], i535[27], i535[26], i535[25], i535[24], i535[23], i535[22], i535[21], i535[20], i535[19], i535[18], i535[17], i535[16], i535[15], i535[14], i535[13], i535[12], i535[11], i535[10], i535[9], i535[8], i535[7], i535[6], i535[5], i535[4], i535[3], i535[2], i535[1], i535[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454_reduce(input wire [163:0] i536, input wire [195:0] i537, input wire [227:0] i538, input wire [259:0] i539, output wire [261:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i536[163], i536[162], i536[161], i536[160], i536[159], i536[158], i536[157], i536[156], i536[155], i536[154], i536[153], i536[152], i536[151], i536[150], i536[149], i536[148], i536[147], i536[146], i536[145], i536[144], i536[143], i536[142], i536[141], i536[140], i536[139], i536[138], i536[137], i536[136], i536[135], i536[134], i536[133], i536[132], i536[131], i536[130], i536[129], i536[128], i536[127], i536[126], i536[125], i536[124], i536[123], i536[122], i536[121], i536[120], i536[119], i536[118], i536[117], i536[116], i536[115], i536[114], i536[113], i536[112], i536[111], i536[110], i536[109], i536[108], i536[107], i536[106], i536[105], i536[104], i536[103], i536[102], i536[101], i536[100], i536[99], i536[98], i536[97], i536[96], i536[95], i536[94], i536[93], i536[92], i536[91], i536[90], i536[89], i536[88], i536[87], i536[86], i536[85], i536[84], i536[83], i536[82], i536[81], i536[80], i536[79], i536[78], i536[77], i536[76], i536[75], i536[74], i536[73], i536[72], i536[71], i536[70], i536[69], i536[68], i536[67], i536[66], i536[65], i536[64], i536[63], i536[62], i536[61], i536[60], i536[59], i536[58], i536[57], i536[56], i536[55], i536[54], i536[53], i536[52], i536[51], i536[50], i536[49], i536[48], i536[47], i536[46], i536[45], i536[44], i536[43], i536[42], i536[41], i536[40], i536[39], i536[38], i536[37], i536[36], i536[35], i536[34], i536[33], i536[32], i536[31], i536[30], i536[29], i536[28], i536[27], i536[26], i536[25], i536[24], i536[23], i536[22], i536[21], i536[20], i536[19], i536[18], i536[17], i536[16], i536[15], i536[14], i536[13], i536[12], i536[11], i536[10], i536[9], i536[8], i536[7], i536[6], i536[5], i536[4], i536[3], i536[2], i536[1], i536[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i537[195], i537[194], i537[193], i537[192], i537[191], i537[190], i537[189], i537[188], i537[187], i537[186], i537[185], i537[184], i537[183], i537[182], i537[181], i537[180], i537[179], i537[178], i537[177], i537[176], i537[175], i537[174], i537[173], i537[172], i537[171], i537[170], i537[169], i537[168], i537[167], i537[166], i537[165], i537[164], i537[163], i537[162], i537[161], i537[160], i537[159], i537[158], i537[157], i537[156], i537[155], i537[154], i537[153], i537[152], i537[151], i537[150], i537[149], i537[148], i537[147], i537[146], i537[145], i537[144], i537[143], i537[142], i537[141], i537[140], i537[139], i537[138], i537[137], i537[136], i537[135], i537[134], i537[133], i537[132], i537[131], i537[130], i537[129], i537[128], i537[127], i537[126], i537[125], i537[124], i537[123], i537[122], i537[121], i537[120], i537[119], i537[118], i537[117], i537[116], i537[115], i537[114], i537[113], i537[112], i537[111], i537[110], i537[109], i537[108], i537[107], i537[106], i537[105], i537[104], i537[103], i537[102], i537[101], i537[100], i537[99], i537[98], i537[97], i537[96], i537[95], i537[94], i537[93], i537[92], i537[91], i537[90], i537[89], i537[88], i537[87], i537[86], i537[85], i537[84], i537[83], i537[82], i537[81], i537[80], i537[79], i537[78], i537[77], i537[76], i537[75], i537[74], i537[73], i537[72], i537[71], i537[70], i537[69], i537[68], i537[67], i537[66], i537[65], i537[64], i537[63], i537[62], i537[61], i537[60], i537[59], i537[58], i537[57], i537[56], i537[55], i537[54], i537[53], i537[52], i537[51], i537[50], i537[49], i537[48], i537[47], i537[46], i537[45], i537[44], i537[43], i537[42], i537[41], i537[40], i537[39], i537[38], i537[37], i537[36], i537[35], i537[34], i537[33], i537[32], i537[31], i537[30], i537[29], i537[28], i537[27], i537[26], i537[25], i537[24], i537[23], i537[22], i537[21], i537[20], i537[19], i537[18], i537[17], i537[16], i537[15], i537[14], i537[13], i537[12], i537[11], i537[10], i537[9], i537[8], i537[7], i537[6], i537[5], i537[4], i537[3], i537[2], i537[1], i537[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i538[227], i538[226], i538[225], i538[224], i538[223], i538[222], i538[221], i538[220], i538[219], i538[218], i538[217], i538[216], i538[215], i538[214], i538[213], i538[212], i538[211], i538[210], i538[209], i538[208], i538[207], i538[206], i538[205], i538[204], i538[203], i538[202], i538[201], i538[200], i538[199], i538[198], i538[197], i538[196], i538[195], i538[194], i538[193], i538[192], i538[191], i538[190], i538[189], i538[188], i538[187], i538[186], i538[185], i538[184], i538[183], i538[182], i538[181], i538[180], i538[179], i538[178], i538[177], i538[176], i538[175], i538[174], i538[173], i538[172], i538[171], i538[170], i538[169], i538[168], i538[167], i538[166], i538[165], i538[164], i538[163], i538[162], i538[161], i538[160], i538[159], i538[158], i538[157], i538[156], i538[155], i538[154], i538[153], i538[152], i538[151], i538[150], i538[149], i538[148], i538[147], i538[146], i538[145], i538[144], i538[143], i538[142], i538[141], i538[140], i538[139], i538[138], i538[137], i538[136], i538[135], i538[134], i538[133], i538[132], i538[131], i538[130], i538[129], i538[128], i538[127], i538[126], i538[125], i538[124], i538[123], i538[122], i538[121], i538[120], i538[119], i538[118], i538[117], i538[116], i538[115], i538[114], i538[113], i538[112], i538[111], i538[110], i538[109], i538[108], i538[107], i538[106], i538[105], i538[104], i538[103], i538[102], i538[101], i538[100], i538[99], i538[98], i538[97], i538[96], i538[95], i538[94], i538[93], i538[92], i538[91], i538[90], i538[89], i538[88], i538[87], i538[86], i538[85], i538[84], i538[83], i538[82], i538[81], i538[80], i538[79], i538[78], i538[77], i538[76], i538[75], i538[74], i538[73], i538[72], i538[71], i538[70], i538[69], i538[68], i538[67], i538[66], i538[65], i538[64], i538[63], i538[62], i538[61], i538[60], i538[59], i538[58], i538[57], i538[56], i538[55], i538[54], i538[53], i538[52], i538[51], i538[50], i538[49], i538[48], i538[47], i538[46], i538[45], i538[44], i538[43], i538[42], i538[41], i538[40], i538[39], i538[38], i538[37], i538[36], i538[35], i538[34], i538[33], i538[32], i538[31], i538[30], i538[29], i538[28], i538[27], i538[26], i538[25], i538[24], i538[23], i538[22], i538[21], i538[20], i538[19], i538[18], i538[17], i538[16], i538[15], i538[14], i538[13], i538[12], i538[11], i538[10], i538[9], i538[8], i538[7], i538[6], i538[5], i538[4], i538[3], i538[2], i538[1], i538[0]};
wire [255:0] t3 = {i539[255], i539[254], i539[253], i539[252], i539[251], i539[250], i539[249], i539[248], i539[247], i539[246], i539[245], i539[244], i539[243], i539[242], i539[241], i539[240], i539[239], i539[238], i539[237], i539[236], i539[235], i539[234], i539[233], i539[232], i539[231], i539[230], i539[229], i539[228], i539[227], i539[226], i539[225], i539[224], i539[223], i539[222], i539[221], i539[220], i539[219], i539[218], i539[217], i539[216], i539[215], i539[214], i539[213], i539[212], i539[211], i539[210], i539[209], i539[208], i539[207], i539[206], i539[205], i539[204], i539[203], i539[202], i539[201], i539[200], i539[199], i539[198], i539[197], i539[196], i539[195], i539[194], i539[193], i539[192], i539[191], i539[190], i539[189], i539[188], i539[187], i539[186], i539[185], i539[184], i539[183], i539[182], i539[181], i539[180], i539[179], i539[178], i539[177], i539[176], i539[175], i539[174], i539[173], i539[172], i539[171], i539[170], i539[169], i539[168], i539[167], i539[166], i539[165], i539[164], i539[163], i539[162], i539[161], i539[160], i539[159], i539[158], i539[157], i539[156], i539[155], i539[154], i539[153], i539[152], i539[151], i539[150], i539[149], i539[148], i539[147], i539[146], i539[145], i539[144], i539[143], i539[142], i539[141], i539[140], i539[139], i539[138], i539[137], i539[136], i539[135], i539[134], i539[133], i539[132], i539[131], i539[130], i539[129], i539[128], i539[127], i539[126], i539[125], i539[124], i539[123], i539[122], i539[121], i539[120], i539[119], i539[118], i539[117], i539[116], i539[115], i539[114], i539[113], i539[112], i539[111], i539[110], i539[109], i539[108], i539[107], i539[106], i539[105], i539[104], i539[103], i539[102], i539[101], i539[100], i539[99], i539[98], i539[97], i539[96], i539[95], i539[94], i539[93], i539[92], i539[91], i539[90], i539[89], i539[88], i539[87], i539[86], i539[85], i539[84], i539[83], i539[82], i539[81], i539[80], i539[79], i539[78], i539[77], i539[76], i539[75], i539[74], i539[73], i539[72], i539[71], i539[70], i539[69], i539[68], i539[67], i539[66], i539[65], i539[64], i539[63], i539[62], i539[61], i539[60], i539[59], i539[58], i539[57], i539[56], i539[55], i539[54], i539[53], i539[52], i539[51], i539[50], i539[49], i539[48], i539[47], i539[46], i539[45], i539[44], i539[43], i539[42], i539[41], i539[40], i539[39], i539[38], i539[37], i539[36], i539[35], i539[34], i539[33], i539[32], i539[31], i539[30], i539[29], i539[28], i539[27], i539[26], i539[25], i539[24], i539[23], i539[22], i539[21], i539[20], i539[19], i539[18], i539[17], i539[16], i539[15], i539[14], i539[13], i539[12], i539[11], i539[10], i539[9], i539[8], i539[7], i539[6], i539[5], i539[4], i539[3], i539[2], i539[1], i539[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
