`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [15:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_132; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_134; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_136; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_138; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_140; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_142; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_144; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_146; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_148; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_150; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_152; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_154; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_156; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_158; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_160; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_162; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_164; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_166; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_168; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_170; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_172; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_174; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_176; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_178; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_180; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_182; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_184; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_186; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_188; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_190; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_191; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_192; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_193; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_194; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_196; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_197; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_200; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_201; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_202; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_204; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_205; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_206; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_208; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_209; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_210; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_211; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_212; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_213; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_215; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_216; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_217; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_219; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_220; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_221; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_222; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_224; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_225; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_226; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_228; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_229; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_232; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_234; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_235; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_236; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_237; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_239; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_240; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_244; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_248; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_252; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_256; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_260; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_264; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_265; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_266; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_267; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_268; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_269; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_270; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_271; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_272; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_273; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_274; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_275; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_276; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_277; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_278; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_279; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_280; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_281; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_282; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_283; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_284; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_285; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_286; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_287; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_288; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_289; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_290; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_291; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_292; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_293; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_294; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_295; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_296; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_297; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_298; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_299; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_300; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_301; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_302; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_303; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_304; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_305; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_306; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_307; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_308; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_309; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_310; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_311; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_312; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_313; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_314; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_315; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_316; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_317; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_318; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_319; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_320; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_321; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_322; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_323; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_324; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_325; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_326; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_327; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_328; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_329; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_330; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_331; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_332; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_333; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_334; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_335; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_336; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_337; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_338; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_339; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_340; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_341; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_342; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_343; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_344; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_345; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_346; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_347; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_348; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_349; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_350; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_351; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_352; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_353; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_354; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_355; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_356; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_357; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_358; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_359; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_360; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_361; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_362; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_363; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_364; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_365; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_366; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_367; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_368; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_369; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_370; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_371; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_372; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_373; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_374; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_375; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_376; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_377; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_378; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_379; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_382; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_383; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_384; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_385; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_386; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_387; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_388; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_389; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_390; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_391; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_392; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_393; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_394; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_395; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_396; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_397; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_398; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_399; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_400; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_401; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_402; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_403; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_404; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_405; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_406; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_407; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_408; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_409; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_410; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_411; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_412; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_413; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_414; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_415; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_416; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_417; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_418; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_419; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_420; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_421; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_422; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_423; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_424; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_425; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_426; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_427; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_428; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_429; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_430; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_431; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_432; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_433; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_434; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_435; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_436; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_437; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_438; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_439; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_440; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_441; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_442; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_443; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_444; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_445; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_446; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_447; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_448; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_449; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_450; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_451; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_452; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_453; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_454; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_455; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_268_s1; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_274_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_277_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_280_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_283_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_286_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_289_s1; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_295_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_298_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_301_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_304_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_307_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_310_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_313_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_316_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_319_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_322_s1; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_325_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_328_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_331_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_334_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_337_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_340_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_343_s1; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
    logic [240:0] rtlzz_pipe_349_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_352_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_355_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_358_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_361_s1; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_364_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_367_s2; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_370_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_373_s2; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_376_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_382_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [209:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_394_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_397_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_400_s2; // decl: <none>; prim: <none>
    logic [241:0] rtlzz_pipe_403_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_406_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_409_s2; // decl: <none>; prim: <none>
    logic [146:0] rtlzz_pipe_412_s3; // decl: <none>; prim: <none>
    logic [162:0] rtlzz_pipe_415_s3; // decl: <none>; prim: <none>
    logic [178:0] rtlzz_pipe_418_s3; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_421_s3; // decl: <none>; prim: <none>
    logic [210:0] rtlzz_pipe_424_s3; // decl: <none>; prim: <none>
    logic [226:0] rtlzz_pipe_427_s3; // decl: <none>; prim: <none>
    logic [242:0] rtlzz_pipe_430_s3; // decl: <none>; prim: <none>
    logic [258:0] rtlzz_pipe_433_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_455; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(16'(mul_tree_10_11)), .b(16'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(16'(mul_tree_10_14)), .b(16'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(16'(mul_tree_10_18)), .b(16'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(16'(mul_tree_10_22)), .b(16'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(mul_tree_10_26)), .b(16'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(16'(mul_tree_10_30)), .b(16'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(16'(mul_tree_10_34)), .b(16'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(16'(mul_tree_10_38)), .b(16'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(16'(mul_tree_10_42)), .b(16'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(mul_tree_10_46)), .b(16'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(16'(mul_tree_10_50)), .b(16'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(16'(mul_tree_10_54)), .b(16'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(16'(mul_tree_10_58)), .b(16'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(16'(mul_tree_10_62)), .b(16'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(mul_tree_10_66)), .b(16'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(16'(mul_tree_10_70)), .b(16'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(16'(mul_tree_10_74)), .b(16'(mul_tree_10_75)), .cin(1'b0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = {mul_tree_10_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(16'(mul_tree_10_78)), .b(16'(mul_tree_10_79)), .cin(1'b0), .value(mul_tree_10_80));
    assign mul_tree_10_81 = {mul_tree_10_80, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(16'(mul_tree_10_82)), .b(16'(mul_tree_10_83)), .cin(1'b0), .value(mul_tree_10_84));
    assign mul_tree_10_85 = {mul_tree_10_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(mul_tree_10_86)), .b(16'(mul_tree_10_87)), .cin(1'b0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = {mul_tree_10_88, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(16'(mul_tree_10_90)), .b(16'(mul_tree_10_91)), .cin(1'b0), .value(mul_tree_10_92));
    assign mul_tree_10_93 = {mul_tree_10_92, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_96Core rtlzz_owner_96(.a(16'(mul_tree_10_94)), .b(16'(mul_tree_10_95)), .cin(1'b0), .value(mul_tree_10_96));
    assign mul_tree_10_97 = {mul_tree_10_96, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(16'(mul_tree_10_98)), .b(16'(mul_tree_10_99)), .cin(1'b0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = {mul_tree_10_100, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(16'(mul_tree_10_102)), .b(16'(mul_tree_10_103)), .cin(1'b0), .value(mul_tree_10_104));
    assign mul_tree_10_105 = {mul_tree_10_104, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_107 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(16'(mul_tree_10_106)), .b(16'(mul_tree_10_107)), .cin(1'b0), .value(mul_tree_10_108));
    assign mul_tree_10_109 = {mul_tree_10_108, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_110 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_111 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(16'(mul_tree_10_110)), .b(16'(mul_tree_10_111)), .cin(1'b0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = {mul_tree_10_112, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_114 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_115 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(16'(mul_tree_10_114)), .b(16'(mul_tree_10_115)), .cin(1'b0), .value(mul_tree_10_116));
    assign mul_tree_10_117 = {mul_tree_10_116, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_118 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(16'(mul_tree_10_118)), .b(16'(mul_tree_10_119)), .cin(1'b0), .value(mul_tree_10_120));
    assign mul_tree_10_121 = {mul_tree_10_120, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_122 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_123 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(16'(mul_tree_10_122)), .b(16'(mul_tree_10_123)), .cin(1'b0), .value(mul_tree_10_124));
    assign mul_tree_10_125 = {mul_tree_10_124, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_126 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_127 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(mul_tree_10_126)), .b(16'(mul_tree_10_127)), .cin(1'b0), .value(mul_tree_10_128));
    assign mul_tree_10_129 = {mul_tree_10_128, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_131 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_10_130)), .b(16'(mul_tree_10_131)), .cin(1'b0), .value(mul_tree_10_132));
    assign mul_tree_10_133 = {mul_tree_10_132, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_134 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_135 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(16'(mul_tree_10_134)), .b(16'(mul_tree_10_135)), .cin(1'b0), .value(mul_tree_10_136));
    assign mul_tree_10_137 = {mul_tree_10_136, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_138 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_139 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(16'(mul_tree_10_138)), .b(16'(mul_tree_10_139)), .cin(1'b0), .value(mul_tree_10_140));
    assign mul_tree_10_141 = {mul_tree_10_140, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_142 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_143 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(16'(mul_tree_10_142)), .b(16'(mul_tree_10_143)), .cin(1'b0), .value(mul_tree_10_144));
    assign mul_tree_10_145 = {mul_tree_10_144, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_146 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_147 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(mul_tree_10_146)), .b(16'(mul_tree_10_147)), .cin(1'b0), .value(mul_tree_10_148));
    assign mul_tree_10_149 = {mul_tree_10_148, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_150 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_151 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_152Core rtlzz_owner_152(.a(16'(mul_tree_10_150)), .b(16'(mul_tree_10_151)), .cin(1'b0), .value(mul_tree_10_152));
    assign mul_tree_10_153 = {mul_tree_10_152, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_154 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_155 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(16'(mul_tree_10_154)), .b(16'(mul_tree_10_155)), .cin(1'b0), .value(mul_tree_10_156));
    assign mul_tree_10_157 = {mul_tree_10_156, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_158 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_159 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(16'(mul_tree_10_158)), .b(16'(mul_tree_10_159)), .cin(1'b0), .value(mul_tree_10_160));
    assign mul_tree_10_161 = {mul_tree_10_160, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_162 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_163 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_164Core rtlzz_owner_164(.a(16'(mul_tree_10_162)), .b(16'(mul_tree_10_163)), .cin(1'b0), .value(mul_tree_10_164));
    assign mul_tree_10_165 = {mul_tree_10_164, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_166 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_167 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(mul_tree_10_166)), .b(16'(mul_tree_10_167)), .cin(1'b0), .value(mul_tree_10_168));
    assign mul_tree_10_169 = {mul_tree_10_168, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_170 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_171 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(16'(mul_tree_10_170)), .b(16'(mul_tree_10_171)), .cin(1'b0), .value(mul_tree_10_172));
    assign mul_tree_10_173 = {mul_tree_10_172, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_174 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_175 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(16'(mul_tree_10_174)), .b(16'(mul_tree_10_175)), .cin(1'b0), .value(mul_tree_10_176));
    assign mul_tree_10_177 = {mul_tree_10_176, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_178 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_179 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(16'(mul_tree_10_178)), .b(16'(mul_tree_10_179)), .cin(1'b0), .value(mul_tree_10_180));
    assign mul_tree_10_181 = {mul_tree_10_180, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_182 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_183 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(16'(mul_tree_10_182)), .b(16'(mul_tree_10_183)), .cin(1'b0), .value(mul_tree_10_184));
    assign mul_tree_10_185 = {mul_tree_10_184, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_186 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_187 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(mul_tree_10_186)), .b(16'(mul_tree_10_187)), .cin(1'b0), .value(mul_tree_10_188));
    assign mul_tree_10_189 = {mul_tree_10_188, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_190 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_191 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_192Core rtlzz_owner_192(.a(16'(mul_tree_10_190)), .b(16'(mul_tree_10_191)), .cin(1'b0), .value(mul_tree_10_192));
    assign mul_tree_10_193 = {mul_tree_10_192, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_194 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_195 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_196Core rtlzz_owner_196(.a(16'(mul_tree_10_194)), .b(16'(mul_tree_10_195)), .cin(1'b0), .value(mul_tree_10_196));
    assign mul_tree_10_197 = {mul_tree_10_196, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_198 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_199 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(16'(mul_tree_10_198)), .b(16'(mul_tree_10_199)), .cin(1'b0), .value(mul_tree_10_200));
    assign mul_tree_10_201 = {mul_tree_10_200, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_202 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_203 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(16'(mul_tree_10_202)), .b(16'(mul_tree_10_203)), .cin(1'b0), .value(mul_tree_10_204));
    assign mul_tree_10_205 = {mul_tree_10_204, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_206 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_207 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_208Core rtlzz_owner_208(.a(16'(mul_tree_10_206)), .b(16'(mul_tree_10_207)), .cin(1'b0), .value(mul_tree_10_208));
    assign mul_tree_10_209 = {mul_tree_10_208, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_210 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_211 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(16'(mul_tree_10_210)), .b(16'(mul_tree_10_211)), .cin(1'b0), .value(mul_tree_10_212));
    assign mul_tree_10_213 = {mul_tree_10_212, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_214 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_215 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(16'(mul_tree_10_214)), .b(16'(mul_tree_10_215)), .cin(1'b0), .value(mul_tree_10_216));
    assign mul_tree_10_217 = {mul_tree_10_216, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_218 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_219 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(16'(mul_tree_10_218)), .b(16'(mul_tree_10_219)), .cin(1'b0), .value(mul_tree_10_220));
    assign mul_tree_10_221 = {mul_tree_10_220, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_222 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_223 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(16'(mul_tree_10_222)), .b(16'(mul_tree_10_223)), .cin(1'b0), .value(mul_tree_10_224));
    assign mul_tree_10_225 = {mul_tree_10_224, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_226 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_227 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(16'(mul_tree_10_226)), .b(16'(mul_tree_10_227)), .cin(1'b0), .value(mul_tree_10_228));
    assign mul_tree_10_229 = {mul_tree_10_228, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_230 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_231 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_232Core rtlzz_owner_232(.a(16'(mul_tree_10_230)), .b(16'(mul_tree_10_231)), .cin(1'b0), .value(mul_tree_10_232));
    assign mul_tree_10_233 = {mul_tree_10_232, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_234 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_235 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_236Core rtlzz_owner_236(.a(16'(mul_tree_10_234)), .b(16'(mul_tree_10_235)), .cin(1'b0), .value(mul_tree_10_236));
    assign mul_tree_10_237 = {mul_tree_10_236, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_238 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_239 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(16'(mul_tree_10_238)), .b(16'(mul_tree_10_239)), .cin(1'b0), .value(mul_tree_10_240));
    assign mul_tree_10_241 = {mul_tree_10_240, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_242 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_243 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_10_242)), .b(16'(mul_tree_10_243)), .cin(1'b0), .value(mul_tree_10_244));
    assign mul_tree_10_245 = {mul_tree_10_244, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_246 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_247 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_10_246)), .b(16'(mul_tree_10_247)), .cin(1'b0), .value(mul_tree_10_248));
    assign mul_tree_10_249 = {mul_tree_10_248, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_250 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_251 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_10_250)), .b(16'(mul_tree_10_251)), .cin(1'b0), .value(mul_tree_10_252));
    assign mul_tree_10_253 = {mul_tree_10_252, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_254 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_255 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_10_254)), .b(16'(mul_tree_10_255)), .cin(1'b0), .value(mul_tree_10_256));
    assign mul_tree_10_257 = {mul_tree_10_256, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_258 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_259 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_10_258)), .b(16'(mul_tree_10_259)), .cin(1'b0), .value(mul_tree_10_260));
    assign mul_tree_10_261 = {mul_tree_10_260, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_262 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_263 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_10_262)), .b(16'(mul_tree_10_263)), .cin(1'b0), .value(mul_tree_10_264));
    assign mul_tree_10_265 = {mul_tree_10_264, 224'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_266 = ({17'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_267 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_268Core rtlzz_owner_268(.a(32'(mul_tree_10_266)), .b(48'(mul_tree_10_267)), .cin(1'h0), .value(mul_tree_10_268));
    assign mul_tree_10_269 = ({17'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_270 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_271Core rtlzz_owner_271(.a(64'(mul_tree_10_269)), .b(80'(mul_tree_10_270)), .cin(1'h0), .value(mul_tree_10_271));
    assign mul_tree_10_272 = ({17'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_273 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_274Core rtlzz_owner_274(.a(96'(mul_tree_10_272)), .b(112'(mul_tree_10_273)), .cin(1'h0), .value(mul_tree_10_274));
    assign mul_tree_10_275 = ({17'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_276 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_277Core rtlzz_owner_277(.a(128'(mul_tree_10_275)), .b(144'(mul_tree_10_276)), .cin(1'h0), .value(mul_tree_10_277));
    assign mul_tree_10_278 = ({17'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_279 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(48'(mul_tree_10_278)), .b(64'(mul_tree_10_279)), .cin(1'h0), .value(mul_tree_10_280));
    assign mul_tree_10_281 = ({17'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_282 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_283Core rtlzz_owner_283(.a(80'(mul_tree_10_281)), .b(96'(mul_tree_10_282)), .cin(1'h0), .value(mul_tree_10_283));
    assign mul_tree_10_284 = ({17'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_285 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_286Core rtlzz_owner_286(.a(112'(mul_tree_10_284)), .b(128'(mul_tree_10_285)), .cin(1'h0), .value(mul_tree_10_286));
    assign mul_tree_10_287 = ({17'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_288 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_289Core rtlzz_owner_289(.a(144'(mul_tree_10_287)), .b(160'(mul_tree_10_288)), .cin(1'h0), .value(mul_tree_10_289));
    assign mul_tree_10_290 = ({17'h0, mul_tree_10_77}); // decl: <none>; prim: <none>
    assign mul_tree_10_291 = ({1'h0, mul_tree_10_81}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_292Core rtlzz_owner_292(.a(64'(mul_tree_10_290)), .b(80'(mul_tree_10_291)), .cin(1'h0), .value(mul_tree_10_292));
    assign mul_tree_10_293 = ({17'h0, mul_tree_10_85}); // decl: <none>; prim: <none>
    assign mul_tree_10_294 = ({1'h0, mul_tree_10_89}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_295Core rtlzz_owner_295(.a(96'(mul_tree_10_293)), .b(112'(mul_tree_10_294)), .cin(1'h0), .value(mul_tree_10_295));
    assign mul_tree_10_296 = ({17'h0, mul_tree_10_93}); // decl: <none>; prim: <none>
    assign mul_tree_10_297 = ({1'h0, mul_tree_10_97}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(128'(mul_tree_10_296)), .b(144'(mul_tree_10_297)), .cin(1'h0), .value(mul_tree_10_298));
    assign mul_tree_10_299 = ({17'h0, mul_tree_10_101}); // decl: <none>; prim: <none>
    assign mul_tree_10_300 = ({1'h0, mul_tree_10_105}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(160'(mul_tree_10_299)), .b(176'(mul_tree_10_300)), .cin(1'h0), .value(mul_tree_10_301));
    assign mul_tree_10_302 = ({17'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_303 = ({1'h0, mul_tree_10_113}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_304Core rtlzz_owner_304(.a(80'(mul_tree_10_302)), .b(96'(mul_tree_10_303)), .cin(1'h0), .value(mul_tree_10_304));
    assign mul_tree_10_305 = ({17'h0, mul_tree_10_117}); // decl: <none>; prim: <none>
    assign mul_tree_10_306 = ({1'h0, mul_tree_10_121}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_307Core rtlzz_owner_307(.a(112'(mul_tree_10_305)), .b(128'(mul_tree_10_306)), .cin(1'h0), .value(mul_tree_10_307));
    assign mul_tree_10_308 = ({17'h0, mul_tree_10_125}); // decl: <none>; prim: <none>
    assign mul_tree_10_309 = ({1'h0, mul_tree_10_129}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_310Core rtlzz_owner_310(.a(144'(mul_tree_10_308)), .b(160'(mul_tree_10_309)), .cin(1'h0), .value(mul_tree_10_310));
    assign mul_tree_10_311 = ({17'h0, mul_tree_10_133}); // decl: <none>; prim: <none>
    assign mul_tree_10_312 = ({1'h0, mul_tree_10_137}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(176'(mul_tree_10_311)), .b(192'(mul_tree_10_312)), .cin(1'h0), .value(mul_tree_10_313));
    assign mul_tree_10_314 = ({17'h0, mul_tree_10_141}); // decl: <none>; prim: <none>
    assign mul_tree_10_315 = ({1'h0, mul_tree_10_145}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_10_314)), .b(112'(mul_tree_10_315)), .cin(1'h0), .value(mul_tree_10_316));
    assign mul_tree_10_317 = ({17'h0, mul_tree_10_149}); // decl: <none>; prim: <none>
    assign mul_tree_10_318 = ({1'h0, mul_tree_10_153}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(128'(mul_tree_10_317)), .b(144'(mul_tree_10_318)), .cin(1'h0), .value(mul_tree_10_319));
    assign mul_tree_10_320 = ({17'h0, mul_tree_10_157}); // decl: <none>; prim: <none>
    assign mul_tree_10_321 = ({1'h0, mul_tree_10_161}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_322Core rtlzz_owner_322(.a(160'(mul_tree_10_320)), .b(176'(mul_tree_10_321)), .cin(1'h0), .value(mul_tree_10_322));
    assign mul_tree_10_323 = ({17'h0, mul_tree_10_165}); // decl: <none>; prim: <none>
    assign mul_tree_10_324 = ({1'h0, mul_tree_10_169}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_325Core rtlzz_owner_325(.a(192'(mul_tree_10_323)), .b(208'(mul_tree_10_324)), .cin(1'h0), .value(mul_tree_10_325));
    assign mul_tree_10_326 = ({17'h0, mul_tree_10_173}); // decl: <none>; prim: <none>
    assign mul_tree_10_327 = ({1'h0, mul_tree_10_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_328Core rtlzz_owner_328(.a(112'(mul_tree_10_326)), .b(128'(mul_tree_10_327)), .cin(1'h0), .value(mul_tree_10_328));
    assign mul_tree_10_329 = ({17'h0, mul_tree_10_181}); // decl: <none>; prim: <none>
    assign mul_tree_10_330 = ({1'h0, mul_tree_10_185}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_331Core rtlzz_owner_331(.a(144'(mul_tree_10_329)), .b(160'(mul_tree_10_330)), .cin(1'h0), .value(mul_tree_10_331));
    assign mul_tree_10_332 = ({17'h0, mul_tree_10_189}); // decl: <none>; prim: <none>
    assign mul_tree_10_333 = ({1'h0, mul_tree_10_193}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(176'(mul_tree_10_332)), .b(192'(mul_tree_10_333)), .cin(1'h0), .value(mul_tree_10_334));
    assign mul_tree_10_335 = ({17'h0, mul_tree_10_197}); // decl: <none>; prim: <none>
    assign mul_tree_10_336 = ({1'h0, mul_tree_10_201}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(208'(mul_tree_10_335)), .b(224'(mul_tree_10_336)), .cin(1'h0), .value(mul_tree_10_337));
    assign mul_tree_10_338 = ({17'h0, mul_tree_10_205}); // decl: <none>; prim: <none>
    assign mul_tree_10_339 = ({1'h0, mul_tree_10_209}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_340Core rtlzz_owner_340(.a(128'(mul_tree_10_338)), .b(144'(mul_tree_10_339)), .cin(1'h0), .value(mul_tree_10_340));
    assign mul_tree_10_341 = ({17'h0, mul_tree_10_213}); // decl: <none>; prim: <none>
    assign mul_tree_10_342 = ({1'h0, mul_tree_10_217}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(160'(mul_tree_10_341)), .b(176'(mul_tree_10_342)), .cin(1'h0), .value(mul_tree_10_343));
    assign mul_tree_10_344 = ({17'h0, mul_tree_10_221}); // decl: <none>; prim: <none>
    assign mul_tree_10_345 = ({1'h0, mul_tree_10_225}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_346Core rtlzz_owner_346(.a(192'(mul_tree_10_344)), .b(208'(mul_tree_10_345)), .cin(1'h0), .value(mul_tree_10_346));
    assign mul_tree_10_347 = ({17'h0, mul_tree_10_229}); // decl: <none>; prim: <none>
    assign mul_tree_10_348 = ({1'h0, mul_tree_10_233}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_349Core rtlzz_owner_349(.a(224'(mul_tree_10_347)), .b(240'(mul_tree_10_348)), .cin(1'h0), .value(mul_tree_10_349));
    assign mul_tree_10_350 = ({17'h0, mul_tree_10_237}); // decl: <none>; prim: <none>
    assign mul_tree_10_351 = ({1'h0, mul_tree_10_241}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_352Core rtlzz_owner_352(.a(144'(mul_tree_10_350)), .b(160'(mul_tree_10_351)), .cin(1'h0), .value(mul_tree_10_352));
    assign mul_tree_10_353 = ({17'h0, mul_tree_10_245}); // decl: <none>; prim: <none>
    assign mul_tree_10_354 = ({1'h0, mul_tree_10_249}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(176'(mul_tree_10_353)), .b(192'(mul_tree_10_354)), .cin(1'h0), .value(mul_tree_10_355));
    assign mul_tree_10_356 = ({17'h0, mul_tree_10_253}); // decl: <none>; prim: <none>
    assign mul_tree_10_357 = ({1'h0, mul_tree_10_257}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(208'(mul_tree_10_356)), .b(224'(mul_tree_10_357)), .cin(1'h0), .value(mul_tree_10_358));
    assign mul_tree_10_359 = ({17'h0, mul_tree_10_261}); // decl: <none>; prim: <none>
    assign mul_tree_10_360 = ({1'h0, mul_tree_10_265}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_361Core rtlzz_owner_361(.a(240'(mul_tree_10_359)), .b(256'(mul_tree_10_360)), .cin(1'h0), .value(mul_tree_10_361[255:0]));
    assign mul_tree_10_361[256:256] = '0;
    assign mul_tree_10_362 = ({33'h0, rtlzz_pipe_268_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_363 = ({1'h0, rtlzz_pipe_271_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364Core rtlzz_owner_364(.a(49'(mul_tree_10_362)), .b(81'(mul_tree_10_363)), .cin(1'h0), .value(mul_tree_10_364));
    assign mul_tree_10_365 = ({33'h0, rtlzz_pipe_274_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_366 = ({1'h0, rtlzz_pipe_277_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_367Core rtlzz_owner_367(.a(113'(mul_tree_10_365)), .b(145'(mul_tree_10_366)), .cin(1'h0), .value(mul_tree_10_367));
    assign mul_tree_10_368 = ({33'h0, rtlzz_pipe_280_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_369 = ({1'h0, rtlzz_pipe_283_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370Core rtlzz_owner_370(.a(65'(mul_tree_10_368)), .b(97'(mul_tree_10_369)), .cin(1'h0), .value(mul_tree_10_370));
    assign mul_tree_10_371 = ({33'h0, rtlzz_pipe_286_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_372 = ({1'h0, rtlzz_pipe_289_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(129'(mul_tree_10_371)), .b(161'(mul_tree_10_372)), .cin(1'h0), .value(mul_tree_10_373));
    assign mul_tree_10_374 = ({33'h0, rtlzz_pipe_292_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_375 = ({1'h0, rtlzz_pipe_295_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(81'(mul_tree_10_374)), .b(113'(mul_tree_10_375)), .cin(1'h0), .value(mul_tree_10_376));
    assign mul_tree_10_377 = ({33'h0, rtlzz_pipe_298_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_378 = ({1'h0, rtlzz_pipe_301_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_379Core rtlzz_owner_379(.a(145'(mul_tree_10_377)), .b(177'(mul_tree_10_378)), .cin(1'h0), .value(mul_tree_10_379));
    assign mul_tree_10_380 = ({33'h0, rtlzz_pipe_304_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_381 = ({1'h0, rtlzz_pipe_307_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382Core rtlzz_owner_382(.a(97'(mul_tree_10_380)), .b(129'(mul_tree_10_381)), .cin(1'h0), .value(mul_tree_10_382));
    assign mul_tree_10_383 = ({33'h0, rtlzz_pipe_310_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_384 = ({1'h0, rtlzz_pipe_313_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385Core rtlzz_owner_385(.a(161'(mul_tree_10_383)), .b(193'(mul_tree_10_384)), .cin(1'h0), .value(mul_tree_10_385));
    assign mul_tree_10_386 = ({33'h0, rtlzz_pipe_316_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_387 = ({1'h0, rtlzz_pipe_319_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(113'(mul_tree_10_386)), .b(145'(mul_tree_10_387)), .cin(1'h0), .value(mul_tree_10_388));
    assign mul_tree_10_389 = ({33'h0, rtlzz_pipe_322_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_390 = ({1'h0, rtlzz_pipe_325_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391Core rtlzz_owner_391(.a(177'(mul_tree_10_389)), .b(209'(mul_tree_10_390)), .cin(1'h0), .value(mul_tree_10_391));
    assign mul_tree_10_392 = ({33'h0, rtlzz_pipe_328_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_393 = ({1'h0, rtlzz_pipe_331_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(129'(mul_tree_10_392)), .b(161'(mul_tree_10_393)), .cin(1'h0), .value(mul_tree_10_394));
    assign mul_tree_10_395 = ({33'h0, rtlzz_pipe_334_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_396 = ({1'h0, rtlzz_pipe_337_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397Core rtlzz_owner_397(.a(193'(mul_tree_10_395)), .b(225'(mul_tree_10_396)), .cin(1'h0), .value(mul_tree_10_397));
    assign mul_tree_10_398 = ({33'h0, rtlzz_pipe_340_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_399 = ({1'h0, rtlzz_pipe_343_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_400Core rtlzz_owner_400(.a(145'(mul_tree_10_398)), .b(177'(mul_tree_10_399)), .cin(1'h0), .value(mul_tree_10_400));
    assign mul_tree_10_401 = ({33'h0, rtlzz_pipe_346_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_402 = ({1'h0, rtlzz_pipe_349_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_403Core rtlzz_owner_403(.a(209'(mul_tree_10_401)), .b(241'(mul_tree_10_402)), .cin(1'h0), .value(mul_tree_10_403));
    assign mul_tree_10_404 = ({33'h0, rtlzz_pipe_352_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_405 = ({1'h0, rtlzz_pipe_355_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_406Core rtlzz_owner_406(.a(161'(mul_tree_10_404)), .b(193'(mul_tree_10_405)), .cin(1'h0), .value(mul_tree_10_406));
    assign mul_tree_10_407 = ({33'h0, rtlzz_pipe_358_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_408 = ({1'h0, rtlzz_pipe_361_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(225'(mul_tree_10_407)), .b(257'(mul_tree_10_408)), .cin(1'h0), .value(mul_tree_10_409[255:0]));
    assign mul_tree_10_409[257:256] = '0;
    assign mul_tree_10_410 = ({65'h0, rtlzz_pipe_364_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_411 = ({1'h0, rtlzz_pipe_367_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412Core rtlzz_owner_412(.a(82'(mul_tree_10_410)), .b(146'(mul_tree_10_411)), .cin(1'h0), .value(mul_tree_10_412));
    assign mul_tree_10_413 = ({65'h0, rtlzz_pipe_370_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_414 = ({1'h0, rtlzz_pipe_373_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(98'(mul_tree_10_413)), .b(162'(mul_tree_10_414)), .cin(1'h0), .value(mul_tree_10_415));
    assign mul_tree_10_416 = ({65'h0, rtlzz_pipe_376_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_417 = ({1'h0, rtlzz_pipe_379_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_418Core rtlzz_owner_418(.a(114'(mul_tree_10_416)), .b(178'(mul_tree_10_417)), .cin(1'h0), .value(mul_tree_10_418));
    assign mul_tree_10_419 = ({65'h0, rtlzz_pipe_382_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_420 = ({1'h0, rtlzz_pipe_385_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_421Core rtlzz_owner_421(.a(130'(mul_tree_10_419)), .b(194'(mul_tree_10_420)), .cin(1'h0), .value(mul_tree_10_421));
    assign mul_tree_10_422 = ({65'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_423 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_424Core rtlzz_owner_424(.a(146'(mul_tree_10_422)), .b(210'(mul_tree_10_423)), .cin(1'h0), .value(mul_tree_10_424));
    assign mul_tree_10_425 = ({65'h0, rtlzz_pipe_394_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_426 = ({1'h0, rtlzz_pipe_397_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427Core rtlzz_owner_427(.a(162'(mul_tree_10_425)), .b(226'(mul_tree_10_426)), .cin(1'h0), .value(mul_tree_10_427));
    assign mul_tree_10_428 = ({65'h0, rtlzz_pipe_400_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_429 = ({1'h0, rtlzz_pipe_403_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(178'(mul_tree_10_428)), .b(242'(mul_tree_10_429)), .cin(1'h0), .value(mul_tree_10_430));
    assign mul_tree_10_431 = ({65'h0, rtlzz_pipe_406_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_432 = ({1'h0, rtlzz_pipe_409_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433Core rtlzz_owner_433(.a(194'(mul_tree_10_431)), .b(258'(mul_tree_10_432)), .cin(1'h0), .value(mul_tree_10_433[255:0]));
    assign mul_tree_10_433[258:256] = '0;
    assign mul_tree_10_434 = ({17'h0, rtlzz_pipe_412_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_435 = ({1'h0, rtlzz_pipe_415_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_437 = ({17'h0, rtlzz_pipe_418_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_438 = ({1'h0, rtlzz_pipe_421_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_440 = ({17'h0, rtlzz_pipe_424_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_441 = ({1'h0, rtlzz_pipe_427_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_443 = ({17'h0, rtlzz_pipe_430_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_444 = ({1'h0, rtlzz_pipe_433_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_446 = ({33'h0, mul_tree_10_436}); // decl: <none>; prim: <none>
    assign mul_tree_10_447 = ({1'h0, mul_tree_10_439}); // decl: <none>; prim: <none>
    assign mul_tree_10_449 = ({33'h0, mul_tree_10_442}); // decl: <none>; prim: <none>
    assign mul_tree_10_450 = ({1'h0, mul_tree_10_445}); // decl: <none>; prim: <none>
    assign mul_tree_10_452 = ({65'h0, mul_tree_10_448}); // decl: <none>; prim: <none>
    assign mul_tree_10_453 = ({1'h0, mul_tree_10_451}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454_reduce rtlzz_reduce_454(.i504(rtlzz_pipe_412_s3), .i505(rtlzz_pipe_415_s3), .i506(rtlzz_pipe_418_s3), .i507(rtlzz_pipe_421_s3), .i508(rtlzz_pipe_424_s3), .i509(rtlzz_pipe_427_s3), .i510(rtlzz_pipe_430_s3), .i511(rtlzz_pipe_433_s3), .y(mul_tree_10_454));
    assign mul_tree_10_455 = mul_tree_10_454[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_268_s1 <= 49'h0;
            rtlzz_pipe_271_s1 <= 81'h0;
            rtlzz_pipe_274_s1 <= 113'h0;
            rtlzz_pipe_277_s1 <= 145'h0;
            rtlzz_pipe_280_s1 <= 65'h0;
            rtlzz_pipe_283_s1 <= 97'h0;
            rtlzz_pipe_286_s1 <= 129'h0;
            rtlzz_pipe_289_s1 <= 161'h0;
            rtlzz_pipe_292_s1 <= 81'h0;
            rtlzz_pipe_295_s1 <= 113'h0;
            rtlzz_pipe_298_s1 <= 145'h0;
            rtlzz_pipe_301_s1 <= 177'h0;
            rtlzz_pipe_304_s1 <= 97'h0;
            rtlzz_pipe_307_s1 <= 129'h0;
            rtlzz_pipe_310_s1 <= 161'h0;
            rtlzz_pipe_313_s1 <= 193'h0;
            rtlzz_pipe_316_s1 <= 113'h0;
            rtlzz_pipe_319_s1 <= 145'h0;
            rtlzz_pipe_322_s1 <= 177'h0;
            rtlzz_pipe_325_s1 <= 209'h0;
            rtlzz_pipe_328_s1 <= 129'h0;
            rtlzz_pipe_331_s1 <= 161'h0;
            rtlzz_pipe_334_s1 <= 193'h0;
            rtlzz_pipe_337_s1 <= 225'h0;
            rtlzz_pipe_340_s1 <= 145'h0;
            rtlzz_pipe_343_s1 <= 177'h0;
            rtlzz_pipe_346_s1 <= 209'h0;
            rtlzz_pipe_349_s1 <= 241'h0;
            rtlzz_pipe_352_s1 <= 161'h0;
            rtlzz_pipe_355_s1 <= 193'h0;
            rtlzz_pipe_358_s1 <= 225'h0;
            rtlzz_pipe_361_s1 <= 257'h0;
            rtlzz_pipe_364_s2 <= 82'h0;
            rtlzz_pipe_367_s2 <= 146'h0;
            rtlzz_pipe_370_s2 <= 98'h0;
            rtlzz_pipe_373_s2 <= 162'h0;
            rtlzz_pipe_376_s2 <= 114'h0;
            rtlzz_pipe_379_s2 <= 178'h0;
            rtlzz_pipe_382_s2 <= 130'h0;
            rtlzz_pipe_385_s2 <= 194'h0;
            rtlzz_pipe_388_s2 <= 146'h0;
            rtlzz_pipe_391_s2 <= 210'h0;
            rtlzz_pipe_394_s2 <= 162'h0;
            rtlzz_pipe_397_s2 <= 226'h0;
            rtlzz_pipe_400_s2 <= 178'h0;
            rtlzz_pipe_403_s2 <= 242'h0;
            rtlzz_pipe_406_s2 <= 194'h0;
            rtlzz_pipe_409_s2 <= 258'h0;
            rtlzz_pipe_412_s3 <= 147'h0;
            rtlzz_pipe_415_s3 <= 163'h0;
            rtlzz_pipe_418_s3 <= 179'h0;
            rtlzz_pipe_421_s3 <= 195'h0;
            rtlzz_pipe_424_s3 <= 211'h0;
            rtlzz_pipe_427_s3 <= 227'h0;
            rtlzz_pipe_430_s3 <= 243'h0;
            rtlzz_pipe_433_s3 <= 259'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_268_s1 <= mul_tree_10_268; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= mul_tree_10_271; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_274_s1 <= mul_tree_10_274; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_277_s1 <= mul_tree_10_277; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_280_s1 <= mul_tree_10_280; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_283_s1 <= mul_tree_10_283; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_286_s1 <= mul_tree_10_286; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_289_s1 <= mul_tree_10_289; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_tree_10_292; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_295_s1 <= mul_tree_10_295; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_298_s1 <= mul_tree_10_298; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_301_s1 <= mul_tree_10_301; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_304_s1 <= mul_tree_10_304; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_307_s1 <= mul_tree_10_307; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_310_s1 <= mul_tree_10_310; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_313_s1 <= mul_tree_10_313; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_316_s1 <= mul_tree_10_316; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_319_s1 <= mul_tree_10_319; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_322_s1 <= mul_tree_10_322; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_325_s1 <= mul_tree_10_325; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_328_s1 <= mul_tree_10_328; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_331_s1 <= mul_tree_10_331; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_334_s1 <= mul_tree_10_334; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_337_s1 <= mul_tree_10_337; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_340_s1 <= mul_tree_10_340; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_343_s1 <= mul_tree_10_343; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_346_s1 <= mul_tree_10_346; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_349_s1 <= mul_tree_10_349; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_352_s1 <= mul_tree_10_352; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_355_s1 <= mul_tree_10_355; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_358_s1 <= mul_tree_10_358; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_361_s1 <= mul_tree_10_361; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_364_s2 <= mul_tree_10_364; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_367_s2 <= mul_tree_10_367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_370_s2 <= mul_tree_10_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_373_s2 <= mul_tree_10_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_376_s2 <= mul_tree_10_376; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_379_s2 <= mul_tree_10_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_382_s2 <= mul_tree_10_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_385_s2 <= mul_tree_10_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_10_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_10_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_394_s2 <= mul_tree_10_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_397_s2 <= mul_tree_10_397; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_400_s2 <= mul_tree_10_400; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_403_s2 <= mul_tree_10_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_406_s2 <= mul_tree_10_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_409_s2 <= mul_tree_10_409; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_412_s3 <= mul_tree_10_412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_415_s3 <= mul_tree_10_415; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_418_s3 <= mul_tree_10_418; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_421_s3 <= mul_tree_10_421; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_424_s3 <= mul_tree_10_424; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_427_s3 <= mul_tree_10_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_430_s3 <= mul_tree_10_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_433_s3 <= mul_tree_10_433; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454_reduce(input wire [146:0] i504, input wire [162:0] i505, input wire [178:0] i506, input wire [194:0] i507, input wire [210:0] i508, input wire [226:0] i509, input wire [242:0] i510, input wire [258:0] i511, output wire [261:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i504[146], i504[145], i504[144], i504[143], i504[142], i504[141], i504[140], i504[139], i504[138], i504[137], i504[136], i504[135], i504[134], i504[133], i504[132], i504[131], i504[130], i504[129], i504[128], i504[127], i504[126], i504[125], i504[124], i504[123], i504[122], i504[121], i504[120], i504[119], i504[118], i504[117], i504[116], i504[115], i504[114], i504[113], i504[112], i504[111], i504[110], i504[109], i504[108], i504[107], i504[106], i504[105], i504[104], i504[103], i504[102], i504[101], i504[100], i504[99], i504[98], i504[97], i504[96], i504[95], i504[94], i504[93], i504[92], i504[91], i504[90], i504[89], i504[88], i504[87], i504[86], i504[85], i504[84], i504[83], i504[82], i504[81], i504[80], i504[79], i504[78], i504[77], i504[76], i504[75], i504[74], i504[73], i504[72], i504[71], i504[70], i504[69], i504[68], i504[67], i504[66], i504[65], i504[64], i504[63], i504[62], i504[61], i504[60], i504[59], i504[58], i504[57], i504[56], i504[55], i504[54], i504[53], i504[52], i504[51], i504[50], i504[49], i504[48], i504[47], i504[46], i504[45], i504[44], i504[43], i504[42], i504[41], i504[40], i504[39], i504[38], i504[37], i504[36], i504[35], i504[34], i504[33], i504[32], i504[31], i504[30], i504[29], i504[28], i504[27], i504[26], i504[25], i504[24], i504[23], i504[22], i504[21], i504[20], i504[19], i504[18], i504[17], i504[16], i504[15], i504[14], i504[13], i504[12], i504[11], i504[10], i504[9], i504[8], i504[7], i504[6], i504[5], i504[4], i504[3], i504[2], i504[1], i504[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i505[162], i505[161], i505[160], i505[159], i505[158], i505[157], i505[156], i505[155], i505[154], i505[153], i505[152], i505[151], i505[150], i505[149], i505[148], i505[147], i505[146], i505[145], i505[144], i505[143], i505[142], i505[141], i505[140], i505[139], i505[138], i505[137], i505[136], i505[135], i505[134], i505[133], i505[132], i505[131], i505[130], i505[129], i505[128], i505[127], i505[126], i505[125], i505[124], i505[123], i505[122], i505[121], i505[120], i505[119], i505[118], i505[117], i505[116], i505[115], i505[114], i505[113], i505[112], i505[111], i505[110], i505[109], i505[108], i505[107], i505[106], i505[105], i505[104], i505[103], i505[102], i505[101], i505[100], i505[99], i505[98], i505[97], i505[96], i505[95], i505[94], i505[93], i505[92], i505[91], i505[90], i505[89], i505[88], i505[87], i505[86], i505[85], i505[84], i505[83], i505[82], i505[81], i505[80], i505[79], i505[78], i505[77], i505[76], i505[75], i505[74], i505[73], i505[72], i505[71], i505[70], i505[69], i505[68], i505[67], i505[66], i505[65], i505[64], i505[63], i505[62], i505[61], i505[60], i505[59], i505[58], i505[57], i505[56], i505[55], i505[54], i505[53], i505[52], i505[51], i505[50], i505[49], i505[48], i505[47], i505[46], i505[45], i505[44], i505[43], i505[42], i505[41], i505[40], i505[39], i505[38], i505[37], i505[36], i505[35], i505[34], i505[33], i505[32], i505[31], i505[30], i505[29], i505[28], i505[27], i505[26], i505[25], i505[24], i505[23], i505[22], i505[21], i505[20], i505[19], i505[18], i505[17], i505[16], i505[15], i505[14], i505[13], i505[12], i505[11], i505[10], i505[9], i505[8], i505[7], i505[6], i505[5], i505[4], i505[3], i505[2], i505[1], i505[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i506[178], i506[177], i506[176], i506[175], i506[174], i506[173], i506[172], i506[171], i506[170], i506[169], i506[168], i506[167], i506[166], i506[165], i506[164], i506[163], i506[162], i506[161], i506[160], i506[159], i506[158], i506[157], i506[156], i506[155], i506[154], i506[153], i506[152], i506[151], i506[150], i506[149], i506[148], i506[147], i506[146], i506[145], i506[144], i506[143], i506[142], i506[141], i506[140], i506[139], i506[138], i506[137], i506[136], i506[135], i506[134], i506[133], i506[132], i506[131], i506[130], i506[129], i506[128], i506[127], i506[126], i506[125], i506[124], i506[123], i506[122], i506[121], i506[120], i506[119], i506[118], i506[117], i506[116], i506[115], i506[114], i506[113], i506[112], i506[111], i506[110], i506[109], i506[108], i506[107], i506[106], i506[105], i506[104], i506[103], i506[102], i506[101], i506[100], i506[99], i506[98], i506[97], i506[96], i506[95], i506[94], i506[93], i506[92], i506[91], i506[90], i506[89], i506[88], i506[87], i506[86], i506[85], i506[84], i506[83], i506[82], i506[81], i506[80], i506[79], i506[78], i506[77], i506[76], i506[75], i506[74], i506[73], i506[72], i506[71], i506[70], i506[69], i506[68], i506[67], i506[66], i506[65], i506[64], i506[63], i506[62], i506[61], i506[60], i506[59], i506[58], i506[57], i506[56], i506[55], i506[54], i506[53], i506[52], i506[51], i506[50], i506[49], i506[48], i506[47], i506[46], i506[45], i506[44], i506[43], i506[42], i506[41], i506[40], i506[39], i506[38], i506[37], i506[36], i506[35], i506[34], i506[33], i506[32], i506[31], i506[30], i506[29], i506[28], i506[27], i506[26], i506[25], i506[24], i506[23], i506[22], i506[21], i506[20], i506[19], i506[18], i506[17], i506[16], i506[15], i506[14], i506[13], i506[12], i506[11], i506[10], i506[9], i506[8], i506[7], i506[6], i506[5], i506[4], i506[3], i506[2], i506[1], i506[0]};
wire [255:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i507[194], i507[193], i507[192], i507[191], i507[190], i507[189], i507[188], i507[187], i507[186], i507[185], i507[184], i507[183], i507[182], i507[181], i507[180], i507[179], i507[178], i507[177], i507[176], i507[175], i507[174], i507[173], i507[172], i507[171], i507[170], i507[169], i507[168], i507[167], i507[166], i507[165], i507[164], i507[163], i507[162], i507[161], i507[160], i507[159], i507[158], i507[157], i507[156], i507[155], i507[154], i507[153], i507[152], i507[151], i507[150], i507[149], i507[148], i507[147], i507[146], i507[145], i507[144], i507[143], i507[142], i507[141], i507[140], i507[139], i507[138], i507[137], i507[136], i507[135], i507[134], i507[133], i507[132], i507[131], i507[130], i507[129], i507[128], i507[127], i507[126], i507[125], i507[124], i507[123], i507[122], i507[121], i507[120], i507[119], i507[118], i507[117], i507[116], i507[115], i507[114], i507[113], i507[112], i507[111], i507[110], i507[109], i507[108], i507[107], i507[106], i507[105], i507[104], i507[103], i507[102], i507[101], i507[100], i507[99], i507[98], i507[97], i507[96], i507[95], i507[94], i507[93], i507[92], i507[91], i507[90], i507[89], i507[88], i507[87], i507[86], i507[85], i507[84], i507[83], i507[82], i507[81], i507[80], i507[79], i507[78], i507[77], i507[76], i507[75], i507[74], i507[73], i507[72], i507[71], i507[70], i507[69], i507[68], i507[67], i507[66], i507[65], i507[64], i507[63], i507[62], i507[61], i507[60], i507[59], i507[58], i507[57], i507[56], i507[55], i507[54], i507[53], i507[52], i507[51], i507[50], i507[49], i507[48], i507[47], i507[46], i507[45], i507[44], i507[43], i507[42], i507[41], i507[40], i507[39], i507[38], i507[37], i507[36], i507[35], i507[34], i507[33], i507[32], i507[31], i507[30], i507[29], i507[28], i507[27], i507[26], i507[25], i507[24], i507[23], i507[22], i507[21], i507[20], i507[19], i507[18], i507[17], i507[16], i507[15], i507[14], i507[13], i507[12], i507[11], i507[10], i507[9], i507[8], i507[7], i507[6], i507[5], i507[4], i507[3], i507[2], i507[1], i507[0]};
wire [255:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i508[210], i508[209], i508[208], i508[207], i508[206], i508[205], i508[204], i508[203], i508[202], i508[201], i508[200], i508[199], i508[198], i508[197], i508[196], i508[195], i508[194], i508[193], i508[192], i508[191], i508[190], i508[189], i508[188], i508[187], i508[186], i508[185], i508[184], i508[183], i508[182], i508[181], i508[180], i508[179], i508[178], i508[177], i508[176], i508[175], i508[174], i508[173], i508[172], i508[171], i508[170], i508[169], i508[168], i508[167], i508[166], i508[165], i508[164], i508[163], i508[162], i508[161], i508[160], i508[159], i508[158], i508[157], i508[156], i508[155], i508[154], i508[153], i508[152], i508[151], i508[150], i508[149], i508[148], i508[147], i508[146], i508[145], i508[144], i508[143], i508[142], i508[141], i508[140], i508[139], i508[138], i508[137], i508[136], i508[135], i508[134], i508[133], i508[132], i508[131], i508[130], i508[129], i508[128], i508[127], i508[126], i508[125], i508[124], i508[123], i508[122], i508[121], i508[120], i508[119], i508[118], i508[117], i508[116], i508[115], i508[114], i508[113], i508[112], i508[111], i508[110], i508[109], i508[108], i508[107], i508[106], i508[105], i508[104], i508[103], i508[102], i508[101], i508[100], i508[99], i508[98], i508[97], i508[96], i508[95], i508[94], i508[93], i508[92], i508[91], i508[90], i508[89], i508[88], i508[87], i508[86], i508[85], i508[84], i508[83], i508[82], i508[81], i508[80], i508[79], i508[78], i508[77], i508[76], i508[75], i508[74], i508[73], i508[72], i508[71], i508[70], i508[69], i508[68], i508[67], i508[66], i508[65], i508[64], i508[63], i508[62], i508[61], i508[60], i508[59], i508[58], i508[57], i508[56], i508[55], i508[54], i508[53], i508[52], i508[51], i508[50], i508[49], i508[48], i508[47], i508[46], i508[45], i508[44], i508[43], i508[42], i508[41], i508[40], i508[39], i508[38], i508[37], i508[36], i508[35], i508[34], i508[33], i508[32], i508[31], i508[30], i508[29], i508[28], i508[27], i508[26], i508[25], i508[24], i508[23], i508[22], i508[21], i508[20], i508[19], i508[18], i508[17], i508[16], i508[15], i508[14], i508[13], i508[12], i508[11], i508[10], i508[9], i508[8], i508[7], i508[6], i508[5], i508[4], i508[3], i508[2], i508[1], i508[0]};
wire [255:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i509[226], i509[225], i509[224], i509[223], i509[222], i509[221], i509[220], i509[219], i509[218], i509[217], i509[216], i509[215], i509[214], i509[213], i509[212], i509[211], i509[210], i509[209], i509[208], i509[207], i509[206], i509[205], i509[204], i509[203], i509[202], i509[201], i509[200], i509[199], i509[198], i509[197], i509[196], i509[195], i509[194], i509[193], i509[192], i509[191], i509[190], i509[189], i509[188], i509[187], i509[186], i509[185], i509[184], i509[183], i509[182], i509[181], i509[180], i509[179], i509[178], i509[177], i509[176], i509[175], i509[174], i509[173], i509[172], i509[171], i509[170], i509[169], i509[168], i509[167], i509[166], i509[165], i509[164], i509[163], i509[162], i509[161], i509[160], i509[159], i509[158], i509[157], i509[156], i509[155], i509[154], i509[153], i509[152], i509[151], i509[150], i509[149], i509[148], i509[147], i509[146], i509[145], i509[144], i509[143], i509[142], i509[141], i509[140], i509[139], i509[138], i509[137], i509[136], i509[135], i509[134], i509[133], i509[132], i509[131], i509[130], i509[129], i509[128], i509[127], i509[126], i509[125], i509[124], i509[123], i509[122], i509[121], i509[120], i509[119], i509[118], i509[117], i509[116], i509[115], i509[114], i509[113], i509[112], i509[111], i509[110], i509[109], i509[108], i509[107], i509[106], i509[105], i509[104], i509[103], i509[102], i509[101], i509[100], i509[99], i509[98], i509[97], i509[96], i509[95], i509[94], i509[93], i509[92], i509[91], i509[90], i509[89], i509[88], i509[87], i509[86], i509[85], i509[84], i509[83], i509[82], i509[81], i509[80], i509[79], i509[78], i509[77], i509[76], i509[75], i509[74], i509[73], i509[72], i509[71], i509[70], i509[69], i509[68], i509[67], i509[66], i509[65], i509[64], i509[63], i509[62], i509[61], i509[60], i509[59], i509[58], i509[57], i509[56], i509[55], i509[54], i509[53], i509[52], i509[51], i509[50], i509[49], i509[48], i509[47], i509[46], i509[45], i509[44], i509[43], i509[42], i509[41], i509[40], i509[39], i509[38], i509[37], i509[36], i509[35], i509[34], i509[33], i509[32], i509[31], i509[30], i509[29], i509[28], i509[27], i509[26], i509[25], i509[24], i509[23], i509[22], i509[21], i509[20], i509[19], i509[18], i509[17], i509[16], i509[15], i509[14], i509[13], i509[12], i509[11], i509[10], i509[9], i509[8], i509[7], i509[6], i509[5], i509[4], i509[3], i509[2], i509[1], i509[0]};
wire [255:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i510[242], i510[241], i510[240], i510[239], i510[238], i510[237], i510[236], i510[235], i510[234], i510[233], i510[232], i510[231], i510[230], i510[229], i510[228], i510[227], i510[226], i510[225], i510[224], i510[223], i510[222], i510[221], i510[220], i510[219], i510[218], i510[217], i510[216], i510[215], i510[214], i510[213], i510[212], i510[211], i510[210], i510[209], i510[208], i510[207], i510[206], i510[205], i510[204], i510[203], i510[202], i510[201], i510[200], i510[199], i510[198], i510[197], i510[196], i510[195], i510[194], i510[193], i510[192], i510[191], i510[190], i510[189], i510[188], i510[187], i510[186], i510[185], i510[184], i510[183], i510[182], i510[181], i510[180], i510[179], i510[178], i510[177], i510[176], i510[175], i510[174], i510[173], i510[172], i510[171], i510[170], i510[169], i510[168], i510[167], i510[166], i510[165], i510[164], i510[163], i510[162], i510[161], i510[160], i510[159], i510[158], i510[157], i510[156], i510[155], i510[154], i510[153], i510[152], i510[151], i510[150], i510[149], i510[148], i510[147], i510[146], i510[145], i510[144], i510[143], i510[142], i510[141], i510[140], i510[139], i510[138], i510[137], i510[136], i510[135], i510[134], i510[133], i510[132], i510[131], i510[130], i510[129], i510[128], i510[127], i510[126], i510[125], i510[124], i510[123], i510[122], i510[121], i510[120], i510[119], i510[118], i510[117], i510[116], i510[115], i510[114], i510[113], i510[112], i510[111], i510[110], i510[109], i510[108], i510[107], i510[106], i510[105], i510[104], i510[103], i510[102], i510[101], i510[100], i510[99], i510[98], i510[97], i510[96], i510[95], i510[94], i510[93], i510[92], i510[91], i510[90], i510[89], i510[88], i510[87], i510[86], i510[85], i510[84], i510[83], i510[82], i510[81], i510[80], i510[79], i510[78], i510[77], i510[76], i510[75], i510[74], i510[73], i510[72], i510[71], i510[70], i510[69], i510[68], i510[67], i510[66], i510[65], i510[64], i510[63], i510[62], i510[61], i510[60], i510[59], i510[58], i510[57], i510[56], i510[55], i510[54], i510[53], i510[52], i510[51], i510[50], i510[49], i510[48], i510[47], i510[46], i510[45], i510[44], i510[43], i510[42], i510[41], i510[40], i510[39], i510[38], i510[37], i510[36], i510[35], i510[34], i510[33], i510[32], i510[31], i510[30], i510[29], i510[28], i510[27], i510[26], i510[25], i510[24], i510[23], i510[22], i510[21], i510[20], i510[19], i510[18], i510[17], i510[16], i510[15], i510[14], i510[13], i510[12], i510[11], i510[10], i510[9], i510[8], i510[7], i510[6], i510[5], i510[4], i510[3], i510[2], i510[1], i510[0]};
wire [255:0] t7 = {i511[255], i511[254], i511[253], i511[252], i511[251], i511[250], i511[249], i511[248], i511[247], i511[246], i511[245], i511[244], i511[243], i511[242], i511[241], i511[240], i511[239], i511[238], i511[237], i511[236], i511[235], i511[234], i511[233], i511[232], i511[231], i511[230], i511[229], i511[228], i511[227], i511[226], i511[225], i511[224], i511[223], i511[222], i511[221], i511[220], i511[219], i511[218], i511[217], i511[216], i511[215], i511[214], i511[213], i511[212], i511[211], i511[210], i511[209], i511[208], i511[207], i511[206], i511[205], i511[204], i511[203], i511[202], i511[201], i511[200], i511[199], i511[198], i511[197], i511[196], i511[195], i511[194], i511[193], i511[192], i511[191], i511[190], i511[189], i511[188], i511[187], i511[186], i511[185], i511[184], i511[183], i511[182], i511[181], i511[180], i511[179], i511[178], i511[177], i511[176], i511[175], i511[174], i511[173], i511[172], i511[171], i511[170], i511[169], i511[168], i511[167], i511[166], i511[165], i511[164], i511[163], i511[162], i511[161], i511[160], i511[159], i511[158], i511[157], i511[156], i511[155], i511[154], i511[153], i511[152], i511[151], i511[150], i511[149], i511[148], i511[147], i511[146], i511[145], i511[144], i511[143], i511[142], i511[141], i511[140], i511[139], i511[138], i511[137], i511[136], i511[135], i511[134], i511[133], i511[132], i511[131], i511[130], i511[129], i511[128], i511[127], i511[126], i511[125], i511[124], i511[123], i511[122], i511[121], i511[120], i511[119], i511[118], i511[117], i511[116], i511[115], i511[114], i511[113], i511[112], i511[111], i511[110], i511[109], i511[108], i511[107], i511[106], i511[105], i511[104], i511[103], i511[102], i511[101], i511[100], i511[99], i511[98], i511[97], i511[96], i511[95], i511[94], i511[93], i511[92], i511[91], i511[90], i511[89], i511[88], i511[87], i511[86], i511[85], i511[84], i511[83], i511[82], i511[81], i511[80], i511[79], i511[78], i511[77], i511[76], i511[75], i511[74], i511[73], i511[72], i511[71], i511[70], i511[69], i511[68], i511[67], i511[66], i511[65], i511[64], i511[63], i511[62], i511[61], i511[60], i511[59], i511[58], i511[57], i511[56], i511[55], i511[54], i511[53], i511[52], i511[51], i511[50], i511[49], i511[48], i511[47], i511[46], i511[45], i511[44], i511[43], i511[42], i511[41], i511[40], i511[39], i511[38], i511[37], i511[36], i511[35], i511[34], i511[33], i511[32], i511[31], i511[30], i511[29], i511[28], i511[27], i511[26], i511[25], i511[24], i511[23], i511[22], i511[21], i511[20], i511[19], i511[18], i511[17], i511[16], i511[15], i511[14], i511[13], i511[12], i511[11], i511[10], i511[9], i511[8], i511[7], i511[6], i511[5], i511[4], i511[3], i511[2], i511[1], i511[0]};
wire [255:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349Core(input wire [223:0] a,input wire [239:0] b,input wire cin,output wire [240:0] value);
wire [223:0] masked_a=((a&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [239:0] masked_b=((b&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [240:0] aa=241'(masked_b);
wire [240:0] bb=241'(masked_a);
wire [241:0] extended={1'b0,aa}+{1'b0,bb}+242'(1'b0);
wire [240:0] native_value=extended[240:0];
assign value=native_value[0+:241];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361Core(input wire [239:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [239:0] masked_a=((a&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [255:0] masked_b=((b&256'hffffffff00000000000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364Core(input wire [48:0] a,input wire [80:0] b,input wire cin,output wire [81:0] value);
wire [48:0] masked_a=((a&49'h1ffffffffffff)|49'h0);
wire [80:0] masked_b=((b&81'h1ffffffffffffffffffff)|81'h0);
wire [81:0] aa=82'(masked_b);
wire [81:0] bb=82'(masked_a);
wire [82:0] extended={1'b0,aa}+{1'b0,bb}+83'(1'b0);
wire [81:0] native_value=extended[81:0];
assign value=native_value[0+:82];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367Core(input wire [112:0] a,input wire [144:0] b,input wire cin,output wire [145:0] value);
wire [112:0] masked_a=((a&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [144:0] masked_b=((b&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [145:0] aa=146'(masked_b);
wire [145:0] bb=146'(masked_a);
wire [146:0] extended={1'b0,aa}+{1'b0,bb}+147'(1'b0);
wire [145:0] native_value=extended[145:0];
assign value=native_value[0+:146];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370Core(input wire [64:0] a,input wire [96:0] b,input wire cin,output wire [97:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [96:0] masked_b=((b&97'h1ffffffffffffffffffffffff)|97'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:98];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [128:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [80:0] a,input wire [112:0] b,input wire cin,output wire [113:0] value);
wire [80:0] masked_a=((a&81'h1ffffffffffffffffffff)|81'h0);
wire [112:0] masked_b=((b&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [113:0] aa=114'(masked_b);
wire [113:0] bb=114'(masked_a);
wire [114:0] extended={1'b0,aa}+{1'b0,bb}+115'(1'b0);
wire [113:0] native_value=extended[113:0];
assign value=native_value[0+:114];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379Core(input wire [144:0] a,input wire [176:0] b,input wire cin,output wire [177:0] value);
wire [144:0] masked_a=((a&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [176:0] masked_b=((b&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [177:0] aa=178'(masked_b);
wire [177:0] bb=178'(masked_a);
wire [178:0] extended={1'b0,aa}+{1'b0,bb}+179'(1'b0);
wire [177:0] native_value=extended[177:0];
assign value=native_value[0+:178];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_b);
wire [129:0] bb=130'(masked_a);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385Core(input wire [160:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [112:0] a,input wire [144:0] b,input wire cin,output wire [145:0] value);
wire [112:0] masked_a=((a&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [144:0] masked_b=((b&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [145:0] aa=146'(masked_b);
wire [145:0] bb=146'(masked_a);
wire [146:0] extended={1'b0,aa}+{1'b0,bb}+147'(1'b0);
wire [145:0] native_value=extended[145:0];
assign value=native_value[0+:146];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391Core(input wire [176:0] a,input wire [208:0] b,input wire cin,output wire [209:0] value);
wire [176:0] masked_a=((a&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [208:0] masked_b=((b&209'h1ffffffffffffffffffffffffffffffffffffffffffffffffffff)|209'h0);
wire [209:0] aa=210'(masked_b);
wire [209:0] bb=210'(masked_a);
wire [210:0] extended={1'b0,aa}+{1'b0,bb}+211'(1'b0);
wire [209:0] native_value=extended[209:0];
assign value=native_value[0+:210];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [128:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397Core(input wire [192:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400Core(input wire [144:0] a,input wire [176:0] b,input wire cin,output wire [177:0] value);
wire [144:0] masked_a=((a&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [176:0] masked_b=((b&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [177:0] aa=178'(masked_b);
wire [177:0] bb=178'(masked_a);
wire [178:0] extended={1'b0,aa}+{1'b0,bb}+179'(1'b0);
wire [177:0] native_value=extended[177:0];
assign value=native_value[0+:178];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403Core(input wire [208:0] a,input wire [240:0] b,input wire cin,output wire [241:0] value);
wire [208:0] masked_a=((a&209'h1ffffffffffffffffffffffffffffffffffffffffffffffffffff)|209'h0);
wire [240:0] masked_b=((b&241'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|241'h0);
wire [241:0] aa=242'(masked_b);
wire [241:0] bb=242'(masked_a);
wire [242:0] extended={1'b0,aa}+{1'b0,bb}+243'(1'b0);
wire [241:0] native_value=extended[241:0];
assign value=native_value[0+:242];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406Core(input wire [160:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [224:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [224:0] masked_a=((a&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412Core(input wire [81:0] a,input wire [145:0] b,input wire cin,output wire [146:0] value);
wire [81:0] masked_a=((a&82'h3ffffffffffffffffffff)|82'h0);
wire [145:0] masked_b=((b&146'h3ffffffffffffffffffffffffffffffffffff)|146'h0);
wire [146:0] aa=147'(masked_b);
wire [146:0] bb=147'(masked_a);
wire [147:0] extended={1'b0,aa}+{1'b0,bb}+148'(1'b0);
wire [146:0] native_value=extended[146:0];
assign value=native_value[0+:147];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [97:0] a,input wire [161:0] b,input wire cin,output wire [162:0] value);
wire [97:0] masked_a=((a&98'h3ffffffffffffffffffffffff)|98'h0);
wire [161:0] masked_b=((b&162'h3ffffffffffffffffffffffffffffffffffffffff)|162'h0);
wire [162:0] aa=163'(masked_b);
wire [162:0] bb=163'(masked_a);
wire [163:0] extended={1'b0,aa}+{1'b0,bb}+164'(1'b0);
wire [162:0] native_value=extended[162:0];
assign value=native_value[0+:163];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_418Core(input wire [113:0] a,input wire [177:0] b,input wire cin,output wire [178:0] value);
wire [113:0] masked_a=((a&114'h3ffffffffffffffffffffffffffff)|114'h0);
wire [177:0] masked_b=((b&178'h3ffffffffffffffffffffffffffffffffffffffffffff)|178'h0);
wire [178:0] aa=179'(masked_b);
wire [178:0] bb=179'(masked_a);
wire [179:0] extended={1'b0,aa}+{1'b0,bb}+180'(1'b0);
wire [178:0] native_value=extended[178:0];
assign value=native_value[0+:179];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_418();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421Core(input wire [129:0] a,input wire [193:0] b,input wire cin,output wire [194:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [193:0] masked_b=((b&194'h3ffffffffffffffffffffffffffffffffffffffffffffffff)|194'h0);
wire [194:0] aa=195'(masked_b);
wire [194:0] bb=195'(masked_a);
wire [195:0] extended={1'b0,aa}+{1'b0,bb}+196'(1'b0);
wire [194:0] native_value=extended[194:0];
assign value=native_value[0+:195];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424Core(input wire [145:0] a,input wire [209:0] b,input wire cin,output wire [210:0] value);
wire [145:0] masked_a=((a&146'h3ffffffffffffffffffffffffffffffffffff)|146'h0);
wire [209:0] masked_b=((b&210'h3ffffffffffffffffffffffffffffffffffffffffffffffffffff)|210'h0);
wire [210:0] aa=211'(masked_b);
wire [210:0] bb=211'(masked_a);
wire [211:0] extended={1'b0,aa}+{1'b0,bb}+212'(1'b0);
wire [210:0] native_value=extended[210:0];
assign value=native_value[0+:211];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427Core(input wire [161:0] a,input wire [225:0] b,input wire cin,output wire [226:0] value);
wire [161:0] masked_a=((a&162'h3ffffffffffffffffffffffffffffffffffffffff)|162'h0);
wire [225:0] masked_b=((b&226'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|226'h0);
wire [226:0] aa=227'(masked_b);
wire [226:0] bb=227'(masked_a);
wire [227:0] extended={1'b0,aa}+{1'b0,bb}+228'(1'b0);
wire [226:0] native_value=extended[226:0];
assign value=native_value[0+:227];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [177:0] a,input wire [241:0] b,input wire cin,output wire [242:0] value);
wire [177:0] masked_a=((a&178'h3ffffffffffffffffffffffffffffffffffffffffffff)|178'h0);
wire [241:0] masked_b=((b&242'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|242'h0);
wire [242:0] aa=243'(masked_b);
wire [242:0] bb=243'(masked_a);
wire [243:0] extended={1'b0,aa}+{1'b0,bb}+244'(1'b0);
wire [242:0] native_value=extended[242:0];
assign value=native_value[0+:243];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433Core(input wire [193:0] a,input wire [257:0] b,input wire cin,output wire [255:0] value);
wire [193:0] masked_a=((a&194'h3ffffffffffffffffffffffffffffffffffffffffffffffff)|194'h0);
wire [257:0] masked_b=((b&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [257:0] aa=258'(masked_b);
wire [257:0] bb=258'(masked_a);
wire [258:0] extended={1'b0,aa}+{1'b0,bb}+259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
