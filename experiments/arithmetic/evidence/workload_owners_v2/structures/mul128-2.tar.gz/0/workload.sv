`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [15:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_132; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_134; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_136; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_138; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_140; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_142; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_144; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_146; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_148; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_150; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_152; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_154; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_156; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_158; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_160; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_162; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_164; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_166; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_168; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_170; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_172; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_174; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_176; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_178; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_180; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_182; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_184; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_186; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_188; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_190; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_191; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_192; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_193; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_194; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_196; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_197; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_200; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_201; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_202; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_204; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_205; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_206; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_208; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_209; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_210; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_211; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_212; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_213; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_215; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_216; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_217; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_219; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_220; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_221; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_222; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_224; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_225; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_226; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_228; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_229; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_232; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_234; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_235; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_236; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_237; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_239; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_240; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_244; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_248; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_252; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_256; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_260; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_264; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_265; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_266; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_267; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_268; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_269; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_270; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_271; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_272; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_273; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_274; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_275; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_276; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_277; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_278; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_279; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_280; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_281; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_282; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_283; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_284; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_285; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_286; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_287; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_288; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_289; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_290; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_291; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_292; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_293; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_294; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_295; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_296; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_297; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_298; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_299; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_300; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_301; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_302; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_303; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_304; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_305; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_306; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_307; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_308; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_309; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_310; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_311; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_312; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_313; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_314; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_315; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_316; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_317; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_318; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_319; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_320; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_321; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_322; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_323; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_324; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_325; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_326; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_327; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_328; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_329; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_330; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_331; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_332; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_333; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_334; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_335; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_336; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_337; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_338; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_339; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_340; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_341; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_342; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_343; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_344; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_345; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_346; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_347; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_348; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_349; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_350; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_351; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_352; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_353; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_354; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_355; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_356; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_357; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_358; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_359; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_360; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_361; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_362; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_363; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_364; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_365; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_366; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_367; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_368; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_369; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_370; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_371; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_372; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_373; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_374; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_375; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_376; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_377; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_378; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_379; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_382; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_383; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_384; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_385; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_386; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_387; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_388; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_389; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_390; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_391; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_392; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_393; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_394; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_395; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_396; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_397; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_398; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_399; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_400; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_401; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_402; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_403; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_404; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_405; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_406; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_407; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_408; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_409; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_410; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_411; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_412; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_413; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_414; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_415; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_416; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_417; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_418; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_419; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_420; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_421; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_422; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_423; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_424; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_425; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_426; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_427; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_428; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_429; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_430; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_431; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_432; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_433; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_434; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_435; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_436; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_437; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_438; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_439; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_440; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_441; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_442; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_443; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_444; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_445; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_446; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_447; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_448; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_449; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_450; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_451; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_452; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_453; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_454; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_455; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_268_s1; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_274_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_277_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_280_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_283_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_286_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_289_s1; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_295_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_298_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_301_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_304_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_307_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_310_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_313_s1; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_316_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_319_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_322_s1; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_325_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_328_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_331_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_334_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_337_s1; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_340_s1; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_343_s1; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
    logic [240:0] rtlzz_pipe_349_s1; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_352_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_355_s1; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_358_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_361_s1; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_364_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_367_s2; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_370_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_373_s2; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_376_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_382_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [209:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_394_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_397_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_400_s2; // decl: <none>; prim: <none>
    logic [241:0] rtlzz_pipe_403_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_406_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_409_s2; // decl: <none>; prim: <none>
    logic [163:0] rtlzz_pipe_436_s3; // decl: <none>; prim: <none>
    logic [195:0] rtlzz_pipe_439_s3; // decl: <none>; prim: <none>
    logic [227:0] rtlzz_pipe_442_s3; // decl: <none>; prim: <none>
    logic [259:0] rtlzz_pipe_445_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_455; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(16'(mul_tree_10_11)), .b(16'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(16'(mul_tree_10_14)), .b(16'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(16'(mul_tree_10_18)), .b(16'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(16'(mul_tree_10_22)), .b(16'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(mul_tree_10_26)), .b(16'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(16'(mul_tree_10_30)), .b(16'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(16'(mul_tree_10_34)), .b(16'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(16'(mul_tree_10_38)), .b(16'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(16'(mul_tree_10_42)), .b(16'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(mul_tree_10_46)), .b(16'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(16'(mul_tree_10_50)), .b(16'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(16'(mul_tree_10_54)), .b(16'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(16'(mul_tree_10_58)), .b(16'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(16'(mul_tree_10_62)), .b(16'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(mul_tree_10_66)), .b(16'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(16'(mul_tree_10_70)), .b(16'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(16'(mul_tree_10_74)), .b(16'(mul_tree_10_75)), .cin(1'b0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = {mul_tree_10_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(16'(mul_tree_10_78)), .b(16'(mul_tree_10_79)), .cin(1'b0), .value(mul_tree_10_80));
    assign mul_tree_10_81 = {mul_tree_10_80, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(16'(mul_tree_10_82)), .b(16'(mul_tree_10_83)), .cin(1'b0), .value(mul_tree_10_84));
    assign mul_tree_10_85 = {mul_tree_10_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(mul_tree_10_86)), .b(16'(mul_tree_10_87)), .cin(1'b0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = {mul_tree_10_88, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(16'(mul_tree_10_90)), .b(16'(mul_tree_10_91)), .cin(1'b0), .value(mul_tree_10_92));
    assign mul_tree_10_93 = {mul_tree_10_92, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_96Core rtlzz_owner_96(.a(16'(mul_tree_10_94)), .b(16'(mul_tree_10_95)), .cin(1'b0), .value(mul_tree_10_96));
    assign mul_tree_10_97 = {mul_tree_10_96, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(16'(mul_tree_10_98)), .b(16'(mul_tree_10_99)), .cin(1'b0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = {mul_tree_10_100, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(16'(mul_tree_10_102)), .b(16'(mul_tree_10_103)), .cin(1'b0), .value(mul_tree_10_104));
    assign mul_tree_10_105 = {mul_tree_10_104, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_107 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(16'(mul_tree_10_106)), .b(16'(mul_tree_10_107)), .cin(1'b0), .value(mul_tree_10_108));
    assign mul_tree_10_109 = {mul_tree_10_108, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_110 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_111 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(16'(mul_tree_10_110)), .b(16'(mul_tree_10_111)), .cin(1'b0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = {mul_tree_10_112, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_114 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_115 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(16'(mul_tree_10_114)), .b(16'(mul_tree_10_115)), .cin(1'b0), .value(mul_tree_10_116));
    assign mul_tree_10_117 = {mul_tree_10_116, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_118 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(16'(mul_tree_10_118)), .b(16'(mul_tree_10_119)), .cin(1'b0), .value(mul_tree_10_120));
    assign mul_tree_10_121 = {mul_tree_10_120, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_122 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_123 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(16'(mul_tree_10_122)), .b(16'(mul_tree_10_123)), .cin(1'b0), .value(mul_tree_10_124));
    assign mul_tree_10_125 = {mul_tree_10_124, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_126 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_127 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(mul_tree_10_126)), .b(16'(mul_tree_10_127)), .cin(1'b0), .value(mul_tree_10_128));
    assign mul_tree_10_129 = {mul_tree_10_128, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_131 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_10_130)), .b(16'(mul_tree_10_131)), .cin(1'b0), .value(mul_tree_10_132));
    assign mul_tree_10_133 = {mul_tree_10_132, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_134 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_135 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(16'(mul_tree_10_134)), .b(16'(mul_tree_10_135)), .cin(1'b0), .value(mul_tree_10_136));
    assign mul_tree_10_137 = {mul_tree_10_136, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_138 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_139 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(16'(mul_tree_10_138)), .b(16'(mul_tree_10_139)), .cin(1'b0), .value(mul_tree_10_140));
    assign mul_tree_10_141 = {mul_tree_10_140, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_142 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_143 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(16'(mul_tree_10_142)), .b(16'(mul_tree_10_143)), .cin(1'b0), .value(mul_tree_10_144));
    assign mul_tree_10_145 = {mul_tree_10_144, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_146 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_147 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(mul_tree_10_146)), .b(16'(mul_tree_10_147)), .cin(1'b0), .value(mul_tree_10_148));
    assign mul_tree_10_149 = {mul_tree_10_148, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_150 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_151 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_152Core rtlzz_owner_152(.a(16'(mul_tree_10_150)), .b(16'(mul_tree_10_151)), .cin(1'b0), .value(mul_tree_10_152));
    assign mul_tree_10_153 = {mul_tree_10_152, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_154 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_155 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(16'(mul_tree_10_154)), .b(16'(mul_tree_10_155)), .cin(1'b0), .value(mul_tree_10_156));
    assign mul_tree_10_157 = {mul_tree_10_156, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_158 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_159 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(16'(mul_tree_10_158)), .b(16'(mul_tree_10_159)), .cin(1'b0), .value(mul_tree_10_160));
    assign mul_tree_10_161 = {mul_tree_10_160, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_162 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_163 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_164Core rtlzz_owner_164(.a(16'(mul_tree_10_162)), .b(16'(mul_tree_10_163)), .cin(1'b0), .value(mul_tree_10_164));
    assign mul_tree_10_165 = {mul_tree_10_164, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_166 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_167 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(mul_tree_10_166)), .b(16'(mul_tree_10_167)), .cin(1'b0), .value(mul_tree_10_168));
    assign mul_tree_10_169 = {mul_tree_10_168, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_170 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_171 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(16'(mul_tree_10_170)), .b(16'(mul_tree_10_171)), .cin(1'b0), .value(mul_tree_10_172));
    assign mul_tree_10_173 = {mul_tree_10_172, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_174 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_175 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(16'(mul_tree_10_174)), .b(16'(mul_tree_10_175)), .cin(1'b0), .value(mul_tree_10_176));
    assign mul_tree_10_177 = {mul_tree_10_176, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_178 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_179 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(16'(mul_tree_10_178)), .b(16'(mul_tree_10_179)), .cin(1'b0), .value(mul_tree_10_180));
    assign mul_tree_10_181 = {mul_tree_10_180, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_182 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_183 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(16'(mul_tree_10_182)), .b(16'(mul_tree_10_183)), .cin(1'b0), .value(mul_tree_10_184));
    assign mul_tree_10_185 = {mul_tree_10_184, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_186 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_187 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(mul_tree_10_186)), .b(16'(mul_tree_10_187)), .cin(1'b0), .value(mul_tree_10_188));
    assign mul_tree_10_189 = {mul_tree_10_188, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_190 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_191 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_192Core rtlzz_owner_192(.a(16'(mul_tree_10_190)), .b(16'(mul_tree_10_191)), .cin(1'b0), .value(mul_tree_10_192));
    assign mul_tree_10_193 = {mul_tree_10_192, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_194 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_195 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_196Core rtlzz_owner_196(.a(16'(mul_tree_10_194)), .b(16'(mul_tree_10_195)), .cin(1'b0), .value(mul_tree_10_196));
    assign mul_tree_10_197 = {mul_tree_10_196, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_198 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_199 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(16'(mul_tree_10_198)), .b(16'(mul_tree_10_199)), .cin(1'b0), .value(mul_tree_10_200));
    assign mul_tree_10_201 = {mul_tree_10_200, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_202 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_203 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(16'(mul_tree_10_202)), .b(16'(mul_tree_10_203)), .cin(1'b0), .value(mul_tree_10_204));
    assign mul_tree_10_205 = {mul_tree_10_204, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_206 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_207 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_208Core rtlzz_owner_208(.a(16'(mul_tree_10_206)), .b(16'(mul_tree_10_207)), .cin(1'b0), .value(mul_tree_10_208));
    assign mul_tree_10_209 = {mul_tree_10_208, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_210 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_211 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(16'(mul_tree_10_210)), .b(16'(mul_tree_10_211)), .cin(1'b0), .value(mul_tree_10_212));
    assign mul_tree_10_213 = {mul_tree_10_212, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_214 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_215 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(16'(mul_tree_10_214)), .b(16'(mul_tree_10_215)), .cin(1'b0), .value(mul_tree_10_216));
    assign mul_tree_10_217 = {mul_tree_10_216, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_218 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_219 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(16'(mul_tree_10_218)), .b(16'(mul_tree_10_219)), .cin(1'b0), .value(mul_tree_10_220));
    assign mul_tree_10_221 = {mul_tree_10_220, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_222 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_223 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(16'(mul_tree_10_222)), .b(16'(mul_tree_10_223)), .cin(1'b0), .value(mul_tree_10_224));
    assign mul_tree_10_225 = {mul_tree_10_224, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_226 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_227 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(16'(mul_tree_10_226)), .b(16'(mul_tree_10_227)), .cin(1'b0), .value(mul_tree_10_228));
    assign mul_tree_10_229 = {mul_tree_10_228, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_230 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_231 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_232Core rtlzz_owner_232(.a(16'(mul_tree_10_230)), .b(16'(mul_tree_10_231)), .cin(1'b0), .value(mul_tree_10_232));
    assign mul_tree_10_233 = {mul_tree_10_232, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_234 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_235 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_236Core rtlzz_owner_236(.a(16'(mul_tree_10_234)), .b(16'(mul_tree_10_235)), .cin(1'b0), .value(mul_tree_10_236));
    assign mul_tree_10_237 = {mul_tree_10_236, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_238 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_239 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(16'(mul_tree_10_238)), .b(16'(mul_tree_10_239)), .cin(1'b0), .value(mul_tree_10_240));
    assign mul_tree_10_241 = {mul_tree_10_240, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_242 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_243 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_10_242)), .b(16'(mul_tree_10_243)), .cin(1'b0), .value(mul_tree_10_244));
    assign mul_tree_10_245 = {mul_tree_10_244, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_246 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_247 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_10_246)), .b(16'(mul_tree_10_247)), .cin(1'b0), .value(mul_tree_10_248));
    assign mul_tree_10_249 = {mul_tree_10_248, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_250 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_251 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_10_250)), .b(16'(mul_tree_10_251)), .cin(1'b0), .value(mul_tree_10_252));
    assign mul_tree_10_253 = {mul_tree_10_252, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_254 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_255 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_10_254)), .b(16'(mul_tree_10_255)), .cin(1'b0), .value(mul_tree_10_256));
    assign mul_tree_10_257 = {mul_tree_10_256, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_258 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_259 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_10_258)), .b(16'(mul_tree_10_259)), .cin(1'b0), .value(mul_tree_10_260));
    assign mul_tree_10_261 = {mul_tree_10_260, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_262 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_263 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_10_262)), .b(16'(mul_tree_10_263)), .cin(1'b0), .value(mul_tree_10_264));
    assign mul_tree_10_265 = {mul_tree_10_264, 224'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_266 = ({17'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_267 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_268Core rtlzz_owner_268(.a(32'(mul_tree_10_266)), .b(48'(mul_tree_10_267)), .cin(1'h0), .value(mul_tree_10_268));
    assign mul_tree_10_269 = ({17'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_270 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_271Core rtlzz_owner_271(.a(64'(mul_tree_10_269)), .b(80'(mul_tree_10_270)), .cin(1'h0), .value(mul_tree_10_271));
    assign mul_tree_10_272 = ({17'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_273 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_274Core rtlzz_owner_274(.a(96'(mul_tree_10_272)), .b(112'(mul_tree_10_273)), .cin(1'h0), .value(mul_tree_10_274));
    assign mul_tree_10_275 = ({17'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_276 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_277Core rtlzz_owner_277(.a(128'(mul_tree_10_275)), .b(144'(mul_tree_10_276)), .cin(1'h0), .value(mul_tree_10_277));
    assign mul_tree_10_278 = ({17'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_279 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(48'(mul_tree_10_278)), .b(64'(mul_tree_10_279)), .cin(1'h0), .value(mul_tree_10_280));
    assign mul_tree_10_281 = ({17'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_282 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_283Core rtlzz_owner_283(.a(80'(mul_tree_10_281)), .b(96'(mul_tree_10_282)), .cin(1'h0), .value(mul_tree_10_283));
    assign mul_tree_10_284 = ({17'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_285 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_286Core rtlzz_owner_286(.a(112'(mul_tree_10_284)), .b(128'(mul_tree_10_285)), .cin(1'h0), .value(mul_tree_10_286));
    assign mul_tree_10_287 = ({17'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_288 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_289Core rtlzz_owner_289(.a(144'(mul_tree_10_287)), .b(160'(mul_tree_10_288)), .cin(1'h0), .value(mul_tree_10_289));
    assign mul_tree_10_290 = ({17'h0, mul_tree_10_77}); // decl: <none>; prim: <none>
    assign mul_tree_10_291 = ({1'h0, mul_tree_10_81}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_292Core rtlzz_owner_292(.a(64'(mul_tree_10_290)), .b(80'(mul_tree_10_291)), .cin(1'h0), .value(mul_tree_10_292));
    assign mul_tree_10_293 = ({17'h0, mul_tree_10_85}); // decl: <none>; prim: <none>
    assign mul_tree_10_294 = ({1'h0, mul_tree_10_89}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_295Core rtlzz_owner_295(.a(96'(mul_tree_10_293)), .b(112'(mul_tree_10_294)), .cin(1'h0), .value(mul_tree_10_295));
    assign mul_tree_10_296 = ({17'h0, mul_tree_10_93}); // decl: <none>; prim: <none>
    assign mul_tree_10_297 = ({1'h0, mul_tree_10_97}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(128'(mul_tree_10_296)), .b(144'(mul_tree_10_297)), .cin(1'h0), .value(mul_tree_10_298));
    assign mul_tree_10_299 = ({17'h0, mul_tree_10_101}); // decl: <none>; prim: <none>
    assign mul_tree_10_300 = ({1'h0, mul_tree_10_105}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(160'(mul_tree_10_299)), .b(176'(mul_tree_10_300)), .cin(1'h0), .value(mul_tree_10_301));
    assign mul_tree_10_302 = ({17'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_303 = ({1'h0, mul_tree_10_113}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_304Core rtlzz_owner_304(.a(80'(mul_tree_10_302)), .b(96'(mul_tree_10_303)), .cin(1'h0), .value(mul_tree_10_304));
    assign mul_tree_10_305 = ({17'h0, mul_tree_10_117}); // decl: <none>; prim: <none>
    assign mul_tree_10_306 = ({1'h0, mul_tree_10_121}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_307Core rtlzz_owner_307(.a(112'(mul_tree_10_305)), .b(128'(mul_tree_10_306)), .cin(1'h0), .value(mul_tree_10_307));
    assign mul_tree_10_308 = ({17'h0, mul_tree_10_125}); // decl: <none>; prim: <none>
    assign mul_tree_10_309 = ({1'h0, mul_tree_10_129}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_310Core rtlzz_owner_310(.a(144'(mul_tree_10_308)), .b(160'(mul_tree_10_309)), .cin(1'h0), .value(mul_tree_10_310));
    assign mul_tree_10_311 = ({17'h0, mul_tree_10_133}); // decl: <none>; prim: <none>
    assign mul_tree_10_312 = ({1'h0, mul_tree_10_137}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(176'(mul_tree_10_311)), .b(192'(mul_tree_10_312)), .cin(1'h0), .value(mul_tree_10_313));
    assign mul_tree_10_314 = ({17'h0, mul_tree_10_141}); // decl: <none>; prim: <none>
    assign mul_tree_10_315 = ({1'h0, mul_tree_10_145}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_10_314)), .b(112'(mul_tree_10_315)), .cin(1'h0), .value(mul_tree_10_316));
    assign mul_tree_10_317 = ({17'h0, mul_tree_10_149}); // decl: <none>; prim: <none>
    assign mul_tree_10_318 = ({1'h0, mul_tree_10_153}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(128'(mul_tree_10_317)), .b(144'(mul_tree_10_318)), .cin(1'h0), .value(mul_tree_10_319));
    assign mul_tree_10_320 = ({17'h0, mul_tree_10_157}); // decl: <none>; prim: <none>
    assign mul_tree_10_321 = ({1'h0, mul_tree_10_161}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_322Core rtlzz_owner_322(.a(160'(mul_tree_10_320)), .b(176'(mul_tree_10_321)), .cin(1'h0), .value(mul_tree_10_322));
    assign mul_tree_10_323 = ({17'h0, mul_tree_10_165}); // decl: <none>; prim: <none>
    assign mul_tree_10_324 = ({1'h0, mul_tree_10_169}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_325Core rtlzz_owner_325(.a(192'(mul_tree_10_323)), .b(208'(mul_tree_10_324)), .cin(1'h0), .value(mul_tree_10_325));
    assign mul_tree_10_326 = ({17'h0, mul_tree_10_173}); // decl: <none>; prim: <none>
    assign mul_tree_10_327 = ({1'h0, mul_tree_10_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_328Core rtlzz_owner_328(.a(112'(mul_tree_10_326)), .b(128'(mul_tree_10_327)), .cin(1'h0), .value(mul_tree_10_328));
    assign mul_tree_10_329 = ({17'h0, mul_tree_10_181}); // decl: <none>; prim: <none>
    assign mul_tree_10_330 = ({1'h0, mul_tree_10_185}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_331Core rtlzz_owner_331(.a(144'(mul_tree_10_329)), .b(160'(mul_tree_10_330)), .cin(1'h0), .value(mul_tree_10_331));
    assign mul_tree_10_332 = ({17'h0, mul_tree_10_189}); // decl: <none>; prim: <none>
    assign mul_tree_10_333 = ({1'h0, mul_tree_10_193}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(176'(mul_tree_10_332)), .b(192'(mul_tree_10_333)), .cin(1'h0), .value(mul_tree_10_334));
    assign mul_tree_10_335 = ({17'h0, mul_tree_10_197}); // decl: <none>; prim: <none>
    assign mul_tree_10_336 = ({1'h0, mul_tree_10_201}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(208'(mul_tree_10_335)), .b(224'(mul_tree_10_336)), .cin(1'h0), .value(mul_tree_10_337));
    assign mul_tree_10_338 = ({17'h0, mul_tree_10_205}); // decl: <none>; prim: <none>
    assign mul_tree_10_339 = ({1'h0, mul_tree_10_209}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_340Core rtlzz_owner_340(.a(128'(mul_tree_10_338)), .b(144'(mul_tree_10_339)), .cin(1'h0), .value(mul_tree_10_340));
    assign mul_tree_10_341 = ({17'h0, mul_tree_10_213}); // decl: <none>; prim: <none>
    assign mul_tree_10_342 = ({1'h0, mul_tree_10_217}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(160'(mul_tree_10_341)), .b(176'(mul_tree_10_342)), .cin(1'h0), .value(mul_tree_10_343));
    assign mul_tree_10_344 = ({17'h0, mul_tree_10_221}); // decl: <none>; prim: <none>
    assign mul_tree_10_345 = ({1'h0, mul_tree_10_225}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_346Core rtlzz_owner_346(.a(192'(mul_tree_10_344)), .b(208'(mul_tree_10_345)), .cin(1'h0), .value(mul_tree_10_346));
    assign mul_tree_10_347 = ({17'h0, mul_tree_10_229}); // decl: <none>; prim: <none>
    assign mul_tree_10_348 = ({1'h0, mul_tree_10_233}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_349Core rtlzz_owner_349(.a(224'(mul_tree_10_347)), .b(240'(mul_tree_10_348)), .cin(1'h0), .value(mul_tree_10_349));
    assign mul_tree_10_350 = ({17'h0, mul_tree_10_237}); // decl: <none>; prim: <none>
    assign mul_tree_10_351 = ({1'h0, mul_tree_10_241}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_352Core rtlzz_owner_352(.a(144'(mul_tree_10_350)), .b(160'(mul_tree_10_351)), .cin(1'h0), .value(mul_tree_10_352));
    assign mul_tree_10_353 = ({17'h0, mul_tree_10_245}); // decl: <none>; prim: <none>
    assign mul_tree_10_354 = ({1'h0, mul_tree_10_249}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(176'(mul_tree_10_353)), .b(192'(mul_tree_10_354)), .cin(1'h0), .value(mul_tree_10_355));
    assign mul_tree_10_356 = ({17'h0, mul_tree_10_253}); // decl: <none>; prim: <none>
    assign mul_tree_10_357 = ({1'h0, mul_tree_10_257}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(208'(mul_tree_10_356)), .b(224'(mul_tree_10_357)), .cin(1'h0), .value(mul_tree_10_358));
    assign mul_tree_10_359 = ({17'h0, mul_tree_10_261}); // decl: <none>; prim: <none>
    assign mul_tree_10_360 = ({1'h0, mul_tree_10_265}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_361Core rtlzz_owner_361(.a(240'(mul_tree_10_359)), .b(256'(mul_tree_10_360)), .cin(1'h0), .value(mul_tree_10_361[255:0]));
    assign mul_tree_10_361[256:256] = '0;
    assign mul_tree_10_362 = ({33'h0, rtlzz_pipe_268_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_363 = ({1'h0, rtlzz_pipe_271_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364Core rtlzz_owner_364(.a(49'(mul_tree_10_362)), .b(81'(mul_tree_10_363)), .cin(1'h0), .value(mul_tree_10_364));
    assign mul_tree_10_365 = ({33'h0, rtlzz_pipe_274_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_366 = ({1'h0, rtlzz_pipe_277_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_367Core rtlzz_owner_367(.a(113'(mul_tree_10_365)), .b(145'(mul_tree_10_366)), .cin(1'h0), .value(mul_tree_10_367));
    assign mul_tree_10_368 = ({33'h0, rtlzz_pipe_280_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_369 = ({1'h0, rtlzz_pipe_283_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370Core rtlzz_owner_370(.a(65'(mul_tree_10_368)), .b(97'(mul_tree_10_369)), .cin(1'h0), .value(mul_tree_10_370));
    assign mul_tree_10_371 = ({33'h0, rtlzz_pipe_286_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_372 = ({1'h0, rtlzz_pipe_289_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(129'(mul_tree_10_371)), .b(161'(mul_tree_10_372)), .cin(1'h0), .value(mul_tree_10_373));
    assign mul_tree_10_374 = ({33'h0, rtlzz_pipe_292_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_375 = ({1'h0, rtlzz_pipe_295_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(81'(mul_tree_10_374)), .b(113'(mul_tree_10_375)), .cin(1'h0), .value(mul_tree_10_376));
    assign mul_tree_10_377 = ({33'h0, rtlzz_pipe_298_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_378 = ({1'h0, rtlzz_pipe_301_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_379Core rtlzz_owner_379(.a(145'(mul_tree_10_377)), .b(177'(mul_tree_10_378)), .cin(1'h0), .value(mul_tree_10_379));
    assign mul_tree_10_380 = ({33'h0, rtlzz_pipe_304_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_381 = ({1'h0, rtlzz_pipe_307_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382Core rtlzz_owner_382(.a(97'(mul_tree_10_380)), .b(129'(mul_tree_10_381)), .cin(1'h0), .value(mul_tree_10_382));
    assign mul_tree_10_383 = ({33'h0, rtlzz_pipe_310_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_384 = ({1'h0, rtlzz_pipe_313_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385Core rtlzz_owner_385(.a(161'(mul_tree_10_383)), .b(193'(mul_tree_10_384)), .cin(1'h0), .value(mul_tree_10_385));
    assign mul_tree_10_386 = ({33'h0, rtlzz_pipe_316_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_387 = ({1'h0, rtlzz_pipe_319_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(113'(mul_tree_10_386)), .b(145'(mul_tree_10_387)), .cin(1'h0), .value(mul_tree_10_388));
    assign mul_tree_10_389 = ({33'h0, rtlzz_pipe_322_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_390 = ({1'h0, rtlzz_pipe_325_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391Core rtlzz_owner_391(.a(177'(mul_tree_10_389)), .b(209'(mul_tree_10_390)), .cin(1'h0), .value(mul_tree_10_391));
    assign mul_tree_10_392 = ({33'h0, rtlzz_pipe_328_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_393 = ({1'h0, rtlzz_pipe_331_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(129'(mul_tree_10_392)), .b(161'(mul_tree_10_393)), .cin(1'h0), .value(mul_tree_10_394));
    assign mul_tree_10_395 = ({33'h0, rtlzz_pipe_334_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_396 = ({1'h0, rtlzz_pipe_337_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397Core rtlzz_owner_397(.a(193'(mul_tree_10_395)), .b(225'(mul_tree_10_396)), .cin(1'h0), .value(mul_tree_10_397));
    assign mul_tree_10_398 = ({33'h0, rtlzz_pipe_340_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_399 = ({1'h0, rtlzz_pipe_343_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_400Core rtlzz_owner_400(.a(145'(mul_tree_10_398)), .b(177'(mul_tree_10_399)), .cin(1'h0), .value(mul_tree_10_400));
    assign mul_tree_10_401 = ({33'h0, rtlzz_pipe_346_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_402 = ({1'h0, rtlzz_pipe_349_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_403Core rtlzz_owner_403(.a(209'(mul_tree_10_401)), .b(241'(mul_tree_10_402)), .cin(1'h0), .value(mul_tree_10_403));
    assign mul_tree_10_404 = ({33'h0, rtlzz_pipe_352_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_405 = ({1'h0, rtlzz_pipe_355_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_406Core rtlzz_owner_406(.a(161'(mul_tree_10_404)), .b(193'(mul_tree_10_405)), .cin(1'h0), .value(mul_tree_10_406));
    assign mul_tree_10_407 = ({33'h0, rtlzz_pipe_358_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_408 = ({1'h0, rtlzz_pipe_361_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(225'(mul_tree_10_407)), .b(257'(mul_tree_10_408)), .cin(1'h0), .value(mul_tree_10_409[255:0]));
    assign mul_tree_10_409[257:256] = '0;
    assign mul_tree_10_410 = ({65'h0, rtlzz_pipe_364_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_411 = ({1'h0, rtlzz_pipe_367_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_413 = ({65'h0, rtlzz_pipe_370_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_414 = ({1'h0, rtlzz_pipe_373_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_416 = ({65'h0, rtlzz_pipe_376_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_417 = ({1'h0, rtlzz_pipe_379_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_419 = ({65'h0, rtlzz_pipe_382_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_420 = ({1'h0, rtlzz_pipe_385_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_422 = ({65'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_423 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_425 = ({65'h0, rtlzz_pipe_394_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_426 = ({1'h0, rtlzz_pipe_397_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_428 = ({65'h0, rtlzz_pipe_400_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_429 = ({1'h0, rtlzz_pipe_403_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_431 = ({65'h0, rtlzz_pipe_406_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_432 = ({1'h0, rtlzz_pipe_409_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_434 = ({17'h0, mul_tree_10_412}); // decl: <none>; prim: <none>
    assign mul_tree_10_435 = ({1'h0, mul_tree_10_415}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_436_reduce rtlzz_reduce_436(.i488(rtlzz_pipe_364_s2), .i489(rtlzz_pipe_367_s2), .i490(rtlzz_pipe_370_s2), .i491(rtlzz_pipe_373_s2), .y(mul_tree_10_436));
    assign mul_tree_10_437 = ({17'h0, mul_tree_10_418}); // decl: <none>; prim: <none>
    assign mul_tree_10_438 = ({1'h0, mul_tree_10_421}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_439_reduce rtlzz_reduce_439(.i492(rtlzz_pipe_376_s2), .i493(rtlzz_pipe_379_s2), .i494(rtlzz_pipe_382_s2), .i495(rtlzz_pipe_385_s2), .y(mul_tree_10_439));
    assign mul_tree_10_440 = ({17'h0, mul_tree_10_424}); // decl: <none>; prim: <none>
    assign mul_tree_10_441 = ({1'h0, mul_tree_10_427}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_442_reduce rtlzz_reduce_442(.i496(rtlzz_pipe_388_s2), .i497(rtlzz_pipe_391_s2), .i498(rtlzz_pipe_394_s2), .i499(rtlzz_pipe_397_s2), .y(mul_tree_10_442));
    assign mul_tree_10_443 = ({17'h0, mul_tree_10_430}); // decl: <none>; prim: <none>
    assign mul_tree_10_444 = ({1'h0, mul_tree_10_433}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_445_reduce rtlzz_reduce_445(.i500(rtlzz_pipe_400_s2), .i501(rtlzz_pipe_403_s2), .i502(rtlzz_pipe_406_s2), .i503(rtlzz_pipe_409_s2), .y(mul_tree_10_445));
    assign mul_tree_10_446 = ({33'h0, rtlzz_pipe_436_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_447 = ({1'h0, rtlzz_pipe_439_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_449 = ({33'h0, rtlzz_pipe_442_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_450 = ({1'h0, rtlzz_pipe_445_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_452 = ({65'h0, mul_tree_10_448}); // decl: <none>; prim: <none>
    assign mul_tree_10_453 = ({1'h0, mul_tree_10_451}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454_reduce rtlzz_reduce_454(.i504(rtlzz_pipe_436_s3), .i505(rtlzz_pipe_439_s3), .i506(rtlzz_pipe_442_s3), .i507(rtlzz_pipe_445_s3), .y(mul_tree_10_454));
    assign mul_tree_10_455 = mul_tree_10_454[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_268_s1 <= 49'h0;
            rtlzz_pipe_271_s1 <= 81'h0;
            rtlzz_pipe_274_s1 <= 113'h0;
            rtlzz_pipe_277_s1 <= 145'h0;
            rtlzz_pipe_280_s1 <= 65'h0;
            rtlzz_pipe_283_s1 <= 97'h0;
            rtlzz_pipe_286_s1 <= 129'h0;
            rtlzz_pipe_289_s1 <= 161'h0;
            rtlzz_pipe_292_s1 <= 81'h0;
            rtlzz_pipe_295_s1 <= 113'h0;
            rtlzz_pipe_298_s1 <= 145'h0;
            rtlzz_pipe_301_s1 <= 177'h0;
            rtlzz_pipe_304_s1 <= 97'h0;
            rtlzz_pipe_307_s1 <= 129'h0;
            rtlzz_pipe_310_s1 <= 161'h0;
            rtlzz_pipe_313_s1 <= 193'h0;
            rtlzz_pipe_316_s1 <= 113'h0;
            rtlzz_pipe_319_s1 <= 145'h0;
            rtlzz_pipe_322_s1 <= 177'h0;
            rtlzz_pipe_325_s1 <= 209'h0;
            rtlzz_pipe_328_s1 <= 129'h0;
            rtlzz_pipe_331_s1 <= 161'h0;
            rtlzz_pipe_334_s1 <= 193'h0;
            rtlzz_pipe_337_s1 <= 225'h0;
            rtlzz_pipe_340_s1 <= 145'h0;
            rtlzz_pipe_343_s1 <= 177'h0;
            rtlzz_pipe_346_s1 <= 209'h0;
            rtlzz_pipe_349_s1 <= 241'h0;
            rtlzz_pipe_352_s1 <= 161'h0;
            rtlzz_pipe_355_s1 <= 193'h0;
            rtlzz_pipe_358_s1 <= 225'h0;
            rtlzz_pipe_361_s1 <= 257'h0;
            rtlzz_pipe_364_s2 <= 82'h0;
            rtlzz_pipe_367_s2 <= 146'h0;
            rtlzz_pipe_370_s2 <= 98'h0;
            rtlzz_pipe_373_s2 <= 162'h0;
            rtlzz_pipe_376_s2 <= 114'h0;
            rtlzz_pipe_379_s2 <= 178'h0;
            rtlzz_pipe_382_s2 <= 130'h0;
            rtlzz_pipe_385_s2 <= 194'h0;
            rtlzz_pipe_388_s2 <= 146'h0;
            rtlzz_pipe_391_s2 <= 210'h0;
            rtlzz_pipe_394_s2 <= 162'h0;
            rtlzz_pipe_397_s2 <= 226'h0;
            rtlzz_pipe_400_s2 <= 178'h0;
            rtlzz_pipe_403_s2 <= 242'h0;
            rtlzz_pipe_406_s2 <= 194'h0;
            rtlzz_pipe_409_s2 <= 258'h0;
            rtlzz_pipe_436_s3 <= 164'h0;
            rtlzz_pipe_439_s3 <= 196'h0;
            rtlzz_pipe_442_s3 <= 228'h0;
            rtlzz_pipe_445_s3 <= 260'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_268_s1 <= mul_tree_10_268; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= mul_tree_10_271; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_274_s1 <= mul_tree_10_274; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_277_s1 <= mul_tree_10_277; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_280_s1 <= mul_tree_10_280; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_283_s1 <= mul_tree_10_283; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_286_s1 <= mul_tree_10_286; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_289_s1 <= mul_tree_10_289; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_tree_10_292; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_295_s1 <= mul_tree_10_295; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_298_s1 <= mul_tree_10_298; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_301_s1 <= mul_tree_10_301; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_304_s1 <= mul_tree_10_304; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_307_s1 <= mul_tree_10_307; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_310_s1 <= mul_tree_10_310; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_313_s1 <= mul_tree_10_313; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_316_s1 <= mul_tree_10_316; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_319_s1 <= mul_tree_10_319; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_322_s1 <= mul_tree_10_322; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_325_s1 <= mul_tree_10_325; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_328_s1 <= mul_tree_10_328; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_331_s1 <= mul_tree_10_331; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_334_s1 <= mul_tree_10_334; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_337_s1 <= mul_tree_10_337; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_340_s1 <= mul_tree_10_340; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_343_s1 <= mul_tree_10_343; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_346_s1 <= mul_tree_10_346; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_349_s1 <= mul_tree_10_349; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_352_s1 <= mul_tree_10_352; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_355_s1 <= mul_tree_10_355; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_358_s1 <= mul_tree_10_358; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_361_s1 <= mul_tree_10_361; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_364_s2 <= mul_tree_10_364; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_367_s2 <= mul_tree_10_367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_370_s2 <= mul_tree_10_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_373_s2 <= mul_tree_10_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_376_s2 <= mul_tree_10_376; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_379_s2 <= mul_tree_10_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_382_s2 <= mul_tree_10_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_385_s2 <= mul_tree_10_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_10_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_10_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_394_s2 <= mul_tree_10_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_397_s2 <= mul_tree_10_397; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_400_s2 <= mul_tree_10_400; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_403_s2 <= mul_tree_10_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_406_s2 <= mul_tree_10_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_409_s2 <= mul_tree_10_409; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_436_s3 <= mul_tree_10_436; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_439_s3 <= mul_tree_10_439; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_442_s3 <= mul_tree_10_442; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_445_s3 <= mul_tree_10_445; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_436_reduce(input wire [81:0] i488, input wire [145:0] i489, input wire [97:0] i490, input wire [161:0] i491, output wire [163:0] y);
wire [163:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i488[81], i488[80], i488[79], i488[78], i488[77], i488[76], i488[75], i488[74], i488[73], i488[72], i488[71], i488[70], i488[69], i488[68], i488[67], i488[66], i488[65], i488[64], i488[63], i488[62], i488[61], i488[60], i488[59], i488[58], i488[57], i488[56], i488[55], i488[54], i488[53], i488[52], i488[51], i488[50], i488[49], i488[48], i488[47], i488[46], i488[45], i488[44], i488[43], i488[42], i488[41], i488[40], i488[39], i488[38], i488[37], i488[36], i488[35], i488[34], i488[33], i488[32], i488[31], i488[30], i488[29], i488[28], i488[27], i488[26], i488[25], i488[24], i488[23], i488[22], i488[21], i488[20], i488[19], i488[18], i488[17], i488[16], i488[15], i488[14], i488[13], i488[12], i488[11], i488[10], i488[9], i488[8], i488[7], i488[6], i488[5], i488[4], i488[3], i488[2], i488[1], i488[0]};
wire [163:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i489[145], i489[144], i489[143], i489[142], i489[141], i489[140], i489[139], i489[138], i489[137], i489[136], i489[135], i489[134], i489[133], i489[132], i489[131], i489[130], i489[129], i489[128], i489[127], i489[126], i489[125], i489[124], i489[123], i489[122], i489[121], i489[120], i489[119], i489[118], i489[117], i489[116], i489[115], i489[114], i489[113], i489[112], i489[111], i489[110], i489[109], i489[108], i489[107], i489[106], i489[105], i489[104], i489[103], i489[102], i489[101], i489[100], i489[99], i489[98], i489[97], i489[96], i489[95], i489[94], i489[93], i489[92], i489[91], i489[90], i489[89], i489[88], i489[87], i489[86], i489[85], i489[84], i489[83], i489[82], i489[81], i489[80], i489[79], i489[78], i489[77], i489[76], i489[75], i489[74], i489[73], i489[72], i489[71], i489[70], i489[69], i489[68], i489[67], i489[66], i489[65], i489[64], i489[63], i489[62], i489[61], i489[60], i489[59], i489[58], i489[57], i489[56], i489[55], i489[54], i489[53], i489[52], i489[51], i489[50], i489[49], i489[48], i489[47], i489[46], i489[45], i489[44], i489[43], i489[42], i489[41], i489[40], i489[39], i489[38], i489[37], i489[36], i489[35], i489[34], i489[33], i489[32], i489[31], i489[30], i489[29], i489[28], i489[27], i489[26], i489[25], i489[24], i489[23], i489[22], i489[21], i489[20], i489[19], i489[18], i489[17], i489[16], i489[15], i489[14], i489[13], i489[12], i489[11], i489[10], i489[9], i489[8], i489[7], i489[6], i489[5], i489[4], i489[3], i489[2], i489[1], i489[0]};
wire [163:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[97], i490[96], i490[95], i490[94], i490[93], i490[92], i490[91], i490[90], i490[89], i490[88], i490[87], i490[86], i490[85], i490[84], i490[83], i490[82], i490[81], i490[80], i490[79], i490[78], i490[77], i490[76], i490[75], i490[74], i490[73], i490[72], i490[71], i490[70], i490[69], i490[68], i490[67], i490[66], i490[65], i490[64], i490[63], i490[62], i490[61], i490[60], i490[59], i490[58], i490[57], i490[56], i490[55], i490[54], i490[53], i490[52], i490[51], i490[50], i490[49], i490[48], i490[47], i490[46], i490[45], i490[44], i490[43], i490[42], i490[41], i490[40], i490[39], i490[38], i490[37], i490[36], i490[35], i490[34], i490[33], i490[32], i490[31], i490[30], i490[29], i490[28], i490[27], i490[26], i490[25], i490[24], i490[23], i490[22], i490[21], i490[20], i490[19], i490[18], i490[17], i490[16], i490[15], i490[14], i490[13], i490[12], i490[11], i490[10], i490[9], i490[8], i490[7], i490[6], i490[5], i490[4], i490[3], i490[2], i490[1], i490[0]};
wire [163:0] t3 = {1'b0, 1'b0, i491[161], i491[160], i491[159], i491[158], i491[157], i491[156], i491[155], i491[154], i491[153], i491[152], i491[151], i491[150], i491[149], i491[148], i491[147], i491[146], i491[145], i491[144], i491[143], i491[142], i491[141], i491[140], i491[139], i491[138], i491[137], i491[136], i491[135], i491[134], i491[133], i491[132], i491[131], i491[130], i491[129], i491[128], i491[127], i491[126], i491[125], i491[124], i491[123], i491[122], i491[121], i491[120], i491[119], i491[118], i491[117], i491[116], i491[115], i491[114], i491[113], i491[112], i491[111], i491[110], i491[109], i491[108], i491[107], i491[106], i491[105], i491[104], i491[103], i491[102], i491[101], i491[100], i491[99], i491[98], i491[97], i491[96], i491[95], i491[94], i491[93], i491[92], i491[91], i491[90], i491[89], i491[88], i491[87], i491[86], i491[85], i491[84], i491[83], i491[82], i491[81], i491[80], i491[79], i491[78], i491[77], i491[76], i491[75], i491[74], i491[73], i491[72], i491[71], i491[70], i491[69], i491[68], i491[67], i491[66], i491[65], i491[64], i491[63], i491[62], i491[61], i491[60], i491[59], i491[58], i491[57], i491[56], i491[55], i491[54], i491[53], i491[52], i491[51], i491[50], i491[49], i491[48], i491[47], i491[46], i491[45], i491[44], i491[43], i491[42], i491[41], i491[40], i491[39], i491[38], i491[37], i491[36], i491[35], i491[34], i491[33], i491[32], i491[31], i491[30], i491[29], i491[28], i491[27], i491[26], i491[25], i491[24], i491[23], i491[22], i491[21], i491[20], i491[19], i491[18], i491[17], i491[16], i491[15], i491[14], i491[13], i491[12], i491[11], i491[10], i491[9], i491[8], i491[7], i491[6], i491[5], i491[4], i491[3], i491[2], i491[1], i491[0]};
wire [163:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_439_reduce(input wire [113:0] i492, input wire [177:0] i493, input wire [129:0] i494, input wire [193:0] i495, output wire [195:0] y);
wire [195:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i492[113], i492[112], i492[111], i492[110], i492[109], i492[108], i492[107], i492[106], i492[105], i492[104], i492[103], i492[102], i492[101], i492[100], i492[99], i492[98], i492[97], i492[96], i492[95], i492[94], i492[93], i492[92], i492[91], i492[90], i492[89], i492[88], i492[87], i492[86], i492[85], i492[84], i492[83], i492[82], i492[81], i492[80], i492[79], i492[78], i492[77], i492[76], i492[75], i492[74], i492[73], i492[72], i492[71], i492[70], i492[69], i492[68], i492[67], i492[66], i492[65], i492[64], i492[63], i492[62], i492[61], i492[60], i492[59], i492[58], i492[57], i492[56], i492[55], i492[54], i492[53], i492[52], i492[51], i492[50], i492[49], i492[48], i492[47], i492[46], i492[45], i492[44], i492[43], i492[42], i492[41], i492[40], i492[39], i492[38], i492[37], i492[36], i492[35], i492[34], i492[33], i492[32], i492[31], i492[30], i492[29], i492[28], i492[27], i492[26], i492[25], i492[24], i492[23], i492[22], i492[21], i492[20], i492[19], i492[18], i492[17], i492[16], i492[15], i492[14], i492[13], i492[12], i492[11], i492[10], i492[9], i492[8], i492[7], i492[6], i492[5], i492[4], i492[3], i492[2], i492[1], i492[0]};
wire [195:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[177], i493[176], i493[175], i493[174], i493[173], i493[172], i493[171], i493[170], i493[169], i493[168], i493[167], i493[166], i493[165], i493[164], i493[163], i493[162], i493[161], i493[160], i493[159], i493[158], i493[157], i493[156], i493[155], i493[154], i493[153], i493[152], i493[151], i493[150], i493[149], i493[148], i493[147], i493[146], i493[145], i493[144], i493[143], i493[142], i493[141], i493[140], i493[139], i493[138], i493[137], i493[136], i493[135], i493[134], i493[133], i493[132], i493[131], i493[130], i493[129], i493[128], i493[127], i493[126], i493[125], i493[124], i493[123], i493[122], i493[121], i493[120], i493[119], i493[118], i493[117], i493[116], i493[115], i493[114], i493[113], i493[112], i493[111], i493[110], i493[109], i493[108], i493[107], i493[106], i493[105], i493[104], i493[103], i493[102], i493[101], i493[100], i493[99], i493[98], i493[97], i493[96], i493[95], i493[94], i493[93], i493[92], i493[91], i493[90], i493[89], i493[88], i493[87], i493[86], i493[85], i493[84], i493[83], i493[82], i493[81], i493[80], i493[79], i493[78], i493[77], i493[76], i493[75], i493[74], i493[73], i493[72], i493[71], i493[70], i493[69], i493[68], i493[67], i493[66], i493[65], i493[64], i493[63], i493[62], i493[61], i493[60], i493[59], i493[58], i493[57], i493[56], i493[55], i493[54], i493[53], i493[52], i493[51], i493[50], i493[49], i493[48], i493[47], i493[46], i493[45], i493[44], i493[43], i493[42], i493[41], i493[40], i493[39], i493[38], i493[37], i493[36], i493[35], i493[34], i493[33], i493[32], i493[31], i493[30], i493[29], i493[28], i493[27], i493[26], i493[25], i493[24], i493[23], i493[22], i493[21], i493[20], i493[19], i493[18], i493[17], i493[16], i493[15], i493[14], i493[13], i493[12], i493[11], i493[10], i493[9], i493[8], i493[7], i493[6], i493[5], i493[4], i493[3], i493[2], i493[1], i493[0]};
wire [195:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i494[129], i494[128], i494[127], i494[126], i494[125], i494[124], i494[123], i494[122], i494[121], i494[120], i494[119], i494[118], i494[117], i494[116], i494[115], i494[114], i494[113], i494[112], i494[111], i494[110], i494[109], i494[108], i494[107], i494[106], i494[105], i494[104], i494[103], i494[102], i494[101], i494[100], i494[99], i494[98], i494[97], i494[96], i494[95], i494[94], i494[93], i494[92], i494[91], i494[90], i494[89], i494[88], i494[87], i494[86], i494[85], i494[84], i494[83], i494[82], i494[81], i494[80], i494[79], i494[78], i494[77], i494[76], i494[75], i494[74], i494[73], i494[72], i494[71], i494[70], i494[69], i494[68], i494[67], i494[66], i494[65], i494[64], i494[63], i494[62], i494[61], i494[60], i494[59], i494[58], i494[57], i494[56], i494[55], i494[54], i494[53], i494[52], i494[51], i494[50], i494[49], i494[48], i494[47], i494[46], i494[45], i494[44], i494[43], i494[42], i494[41], i494[40], i494[39], i494[38], i494[37], i494[36], i494[35], i494[34], i494[33], i494[32], i494[31], i494[30], i494[29], i494[28], i494[27], i494[26], i494[25], i494[24], i494[23], i494[22], i494[21], i494[20], i494[19], i494[18], i494[17], i494[16], i494[15], i494[14], i494[13], i494[12], i494[11], i494[10], i494[9], i494[8], i494[7], i494[6], i494[5], i494[4], i494[3], i494[2], i494[1], i494[0]};
wire [195:0] t3 = {1'b0, 1'b0, i495[193], i495[192], i495[191], i495[190], i495[189], i495[188], i495[187], i495[186], i495[185], i495[184], i495[183], i495[182], i495[181], i495[180], i495[179], i495[178], i495[177], i495[176], i495[175], i495[174], i495[173], i495[172], i495[171], i495[170], i495[169], i495[168], i495[167], i495[166], i495[165], i495[164], i495[163], i495[162], i495[161], i495[160], i495[159], i495[158], i495[157], i495[156], i495[155], i495[154], i495[153], i495[152], i495[151], i495[150], i495[149], i495[148], i495[147], i495[146], i495[145], i495[144], i495[143], i495[142], i495[141], i495[140], i495[139], i495[138], i495[137], i495[136], i495[135], i495[134], i495[133], i495[132], i495[131], i495[130], i495[129], i495[128], i495[127], i495[126], i495[125], i495[124], i495[123], i495[122], i495[121], i495[120], i495[119], i495[118], i495[117], i495[116], i495[115], i495[114], i495[113], i495[112], i495[111], i495[110], i495[109], i495[108], i495[107], i495[106], i495[105], i495[104], i495[103], i495[102], i495[101], i495[100], i495[99], i495[98], i495[97], i495[96], i495[95], i495[94], i495[93], i495[92], i495[91], i495[90], i495[89], i495[88], i495[87], i495[86], i495[85], i495[84], i495[83], i495[82], i495[81], i495[80], i495[79], i495[78], i495[77], i495[76], i495[75], i495[74], i495[73], i495[72], i495[71], i495[70], i495[69], i495[68], i495[67], i495[66], i495[65], i495[64], i495[63], i495[62], i495[61], i495[60], i495[59], i495[58], i495[57], i495[56], i495[55], i495[54], i495[53], i495[52], i495[51], i495[50], i495[49], i495[48], i495[47], i495[46], i495[45], i495[44], i495[43], i495[42], i495[41], i495[40], i495[39], i495[38], i495[37], i495[36], i495[35], i495[34], i495[33], i495[32], i495[31], i495[30], i495[29], i495[28], i495[27], i495[26], i495[25], i495[24], i495[23], i495[22], i495[21], i495[20], i495[19], i495[18], i495[17], i495[16], i495[15], i495[14], i495[13], i495[12], i495[11], i495[10], i495[9], i495[8], i495[7], i495[6], i495[5], i495[4], i495[3], i495[2], i495[1], i495[0]};
wire [195:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_442_reduce(input wire [145:0] i496, input wire [209:0] i497, input wire [161:0] i498, input wire [225:0] i499, output wire [227:0] y);
wire [227:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i496[145], i496[144], i496[143], i496[142], i496[141], i496[140], i496[139], i496[138], i496[137], i496[136], i496[135], i496[134], i496[133], i496[132], i496[131], i496[130], i496[129], i496[128], i496[127], i496[126], i496[125], i496[124], i496[123], i496[122], i496[121], i496[120], i496[119], i496[118], i496[117], i496[116], i496[115], i496[114], i496[113], i496[112], i496[111], i496[110], i496[109], i496[108], i496[107], i496[106], i496[105], i496[104], i496[103], i496[102], i496[101], i496[100], i496[99], i496[98], i496[97], i496[96], i496[95], i496[94], i496[93], i496[92], i496[91], i496[90], i496[89], i496[88], i496[87], i496[86], i496[85], i496[84], i496[83], i496[82], i496[81], i496[80], i496[79], i496[78], i496[77], i496[76], i496[75], i496[74], i496[73], i496[72], i496[71], i496[70], i496[69], i496[68], i496[67], i496[66], i496[65], i496[64], i496[63], i496[62], i496[61], i496[60], i496[59], i496[58], i496[57], i496[56], i496[55], i496[54], i496[53], i496[52], i496[51], i496[50], i496[49], i496[48], i496[47], i496[46], i496[45], i496[44], i496[43], i496[42], i496[41], i496[40], i496[39], i496[38], i496[37], i496[36], i496[35], i496[34], i496[33], i496[32], i496[31], i496[30], i496[29], i496[28], i496[27], i496[26], i496[25], i496[24], i496[23], i496[22], i496[21], i496[20], i496[19], i496[18], i496[17], i496[16], i496[15], i496[14], i496[13], i496[12], i496[11], i496[10], i496[9], i496[8], i496[7], i496[6], i496[5], i496[4], i496[3], i496[2], i496[1], i496[0]};
wire [227:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[209], i497[208], i497[207], i497[206], i497[205], i497[204], i497[203], i497[202], i497[201], i497[200], i497[199], i497[198], i497[197], i497[196], i497[195], i497[194], i497[193], i497[192], i497[191], i497[190], i497[189], i497[188], i497[187], i497[186], i497[185], i497[184], i497[183], i497[182], i497[181], i497[180], i497[179], i497[178], i497[177], i497[176], i497[175], i497[174], i497[173], i497[172], i497[171], i497[170], i497[169], i497[168], i497[167], i497[166], i497[165], i497[164], i497[163], i497[162], i497[161], i497[160], i497[159], i497[158], i497[157], i497[156], i497[155], i497[154], i497[153], i497[152], i497[151], i497[150], i497[149], i497[148], i497[147], i497[146], i497[145], i497[144], i497[143], i497[142], i497[141], i497[140], i497[139], i497[138], i497[137], i497[136], i497[135], i497[134], i497[133], i497[132], i497[131], i497[130], i497[129], i497[128], i497[127], i497[126], i497[125], i497[124], i497[123], i497[122], i497[121], i497[120], i497[119], i497[118], i497[117], i497[116], i497[115], i497[114], i497[113], i497[112], i497[111], i497[110], i497[109], i497[108], i497[107], i497[106], i497[105], i497[104], i497[103], i497[102], i497[101], i497[100], i497[99], i497[98], i497[97], i497[96], i497[95], i497[94], i497[93], i497[92], i497[91], i497[90], i497[89], i497[88], i497[87], i497[86], i497[85], i497[84], i497[83], i497[82], i497[81], i497[80], i497[79], i497[78], i497[77], i497[76], i497[75], i497[74], i497[73], i497[72], i497[71], i497[70], i497[69], i497[68], i497[67], i497[66], i497[65], i497[64], i497[63], i497[62], i497[61], i497[60], i497[59], i497[58], i497[57], i497[56], i497[55], i497[54], i497[53], i497[52], i497[51], i497[50], i497[49], i497[48], i497[47], i497[46], i497[45], i497[44], i497[43], i497[42], i497[41], i497[40], i497[39], i497[38], i497[37], i497[36], i497[35], i497[34], i497[33], i497[32], i497[31], i497[30], i497[29], i497[28], i497[27], i497[26], i497[25], i497[24], i497[23], i497[22], i497[21], i497[20], i497[19], i497[18], i497[17], i497[16], i497[15], i497[14], i497[13], i497[12], i497[11], i497[10], i497[9], i497[8], i497[7], i497[6], i497[5], i497[4], i497[3], i497[2], i497[1], i497[0]};
wire [227:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i498[161], i498[160], i498[159], i498[158], i498[157], i498[156], i498[155], i498[154], i498[153], i498[152], i498[151], i498[150], i498[149], i498[148], i498[147], i498[146], i498[145], i498[144], i498[143], i498[142], i498[141], i498[140], i498[139], i498[138], i498[137], i498[136], i498[135], i498[134], i498[133], i498[132], i498[131], i498[130], i498[129], i498[128], i498[127], i498[126], i498[125], i498[124], i498[123], i498[122], i498[121], i498[120], i498[119], i498[118], i498[117], i498[116], i498[115], i498[114], i498[113], i498[112], i498[111], i498[110], i498[109], i498[108], i498[107], i498[106], i498[105], i498[104], i498[103], i498[102], i498[101], i498[100], i498[99], i498[98], i498[97], i498[96], i498[95], i498[94], i498[93], i498[92], i498[91], i498[90], i498[89], i498[88], i498[87], i498[86], i498[85], i498[84], i498[83], i498[82], i498[81], i498[80], i498[79], i498[78], i498[77], i498[76], i498[75], i498[74], i498[73], i498[72], i498[71], i498[70], i498[69], i498[68], i498[67], i498[66], i498[65], i498[64], i498[63], i498[62], i498[61], i498[60], i498[59], i498[58], i498[57], i498[56], i498[55], i498[54], i498[53], i498[52], i498[51], i498[50], i498[49], i498[48], i498[47], i498[46], i498[45], i498[44], i498[43], i498[42], i498[41], i498[40], i498[39], i498[38], i498[37], i498[36], i498[35], i498[34], i498[33], i498[32], i498[31], i498[30], i498[29], i498[28], i498[27], i498[26], i498[25], i498[24], i498[23], i498[22], i498[21], i498[20], i498[19], i498[18], i498[17], i498[16], i498[15], i498[14], i498[13], i498[12], i498[11], i498[10], i498[9], i498[8], i498[7], i498[6], i498[5], i498[4], i498[3], i498[2], i498[1], i498[0]};
wire [227:0] t3 = {1'b0, 1'b0, i499[225], i499[224], i499[223], i499[222], i499[221], i499[220], i499[219], i499[218], i499[217], i499[216], i499[215], i499[214], i499[213], i499[212], i499[211], i499[210], i499[209], i499[208], i499[207], i499[206], i499[205], i499[204], i499[203], i499[202], i499[201], i499[200], i499[199], i499[198], i499[197], i499[196], i499[195], i499[194], i499[193], i499[192], i499[191], i499[190], i499[189], i499[188], i499[187], i499[186], i499[185], i499[184], i499[183], i499[182], i499[181], i499[180], i499[179], i499[178], i499[177], i499[176], i499[175], i499[174], i499[173], i499[172], i499[171], i499[170], i499[169], i499[168], i499[167], i499[166], i499[165], i499[164], i499[163], i499[162], i499[161], i499[160], i499[159], i499[158], i499[157], i499[156], i499[155], i499[154], i499[153], i499[152], i499[151], i499[150], i499[149], i499[148], i499[147], i499[146], i499[145], i499[144], i499[143], i499[142], i499[141], i499[140], i499[139], i499[138], i499[137], i499[136], i499[135], i499[134], i499[133], i499[132], i499[131], i499[130], i499[129], i499[128], i499[127], i499[126], i499[125], i499[124], i499[123], i499[122], i499[121], i499[120], i499[119], i499[118], i499[117], i499[116], i499[115], i499[114], i499[113], i499[112], i499[111], i499[110], i499[109], i499[108], i499[107], i499[106], i499[105], i499[104], i499[103], i499[102], i499[101], i499[100], i499[99], i499[98], i499[97], i499[96], i499[95], i499[94], i499[93], i499[92], i499[91], i499[90], i499[89], i499[88], i499[87], i499[86], i499[85], i499[84], i499[83], i499[82], i499[81], i499[80], i499[79], i499[78], i499[77], i499[76], i499[75], i499[74], i499[73], i499[72], i499[71], i499[70], i499[69], i499[68], i499[67], i499[66], i499[65], i499[64], i499[63], i499[62], i499[61], i499[60], i499[59], i499[58], i499[57], i499[56], i499[55], i499[54], i499[53], i499[52], i499[51], i499[50], i499[49], i499[48], i499[47], i499[46], i499[45], i499[44], i499[43], i499[42], i499[41], i499[40], i499[39], i499[38], i499[37], i499[36], i499[35], i499[34], i499[33], i499[32], i499[31], i499[30], i499[29], i499[28], i499[27], i499[26], i499[25], i499[24], i499[23], i499[22], i499[21], i499[20], i499[19], i499[18], i499[17], i499[16], i499[15], i499[14], i499[13], i499[12], i499[11], i499[10], i499[9], i499[8], i499[7], i499[6], i499[5], i499[4], i499[3], i499[2], i499[1], i499[0]};
wire [227:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_445_reduce(input wire [177:0] i500, input wire [241:0] i501, input wire [193:0] i502, input wire [257:0] i503, output wire [259:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i500[177], i500[176], i500[175], i500[174], i500[173], i500[172], i500[171], i500[170], i500[169], i500[168], i500[167], i500[166], i500[165], i500[164], i500[163], i500[162], i500[161], i500[160], i500[159], i500[158], i500[157], i500[156], i500[155], i500[154], i500[153], i500[152], i500[151], i500[150], i500[149], i500[148], i500[147], i500[146], i500[145], i500[144], i500[143], i500[142], i500[141], i500[140], i500[139], i500[138], i500[137], i500[136], i500[135], i500[134], i500[133], i500[132], i500[131], i500[130], i500[129], i500[128], i500[127], i500[126], i500[125], i500[124], i500[123], i500[122], i500[121], i500[120], i500[119], i500[118], i500[117], i500[116], i500[115], i500[114], i500[113], i500[112], i500[111], i500[110], i500[109], i500[108], i500[107], i500[106], i500[105], i500[104], i500[103], i500[102], i500[101], i500[100], i500[99], i500[98], i500[97], i500[96], i500[95], i500[94], i500[93], i500[92], i500[91], i500[90], i500[89], i500[88], i500[87], i500[86], i500[85], i500[84], i500[83], i500[82], i500[81], i500[80], i500[79], i500[78], i500[77], i500[76], i500[75], i500[74], i500[73], i500[72], i500[71], i500[70], i500[69], i500[68], i500[67], i500[66], i500[65], i500[64], i500[63], i500[62], i500[61], i500[60], i500[59], i500[58], i500[57], i500[56], i500[55], i500[54], i500[53], i500[52], i500[51], i500[50], i500[49], i500[48], i500[47], i500[46], i500[45], i500[44], i500[43], i500[42], i500[41], i500[40], i500[39], i500[38], i500[37], i500[36], i500[35], i500[34], i500[33], i500[32], i500[31], i500[30], i500[29], i500[28], i500[27], i500[26], i500[25], i500[24], i500[23], i500[22], i500[21], i500[20], i500[19], i500[18], i500[17], i500[16], i500[15], i500[14], i500[13], i500[12], i500[11], i500[10], i500[9], i500[8], i500[7], i500[6], i500[5], i500[4], i500[3], i500[2], i500[1], i500[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i501[241], i501[240], i501[239], i501[238], i501[237], i501[236], i501[235], i501[234], i501[233], i501[232], i501[231], i501[230], i501[229], i501[228], i501[227], i501[226], i501[225], i501[224], i501[223], i501[222], i501[221], i501[220], i501[219], i501[218], i501[217], i501[216], i501[215], i501[214], i501[213], i501[212], i501[211], i501[210], i501[209], i501[208], i501[207], i501[206], i501[205], i501[204], i501[203], i501[202], i501[201], i501[200], i501[199], i501[198], i501[197], i501[196], i501[195], i501[194], i501[193], i501[192], i501[191], i501[190], i501[189], i501[188], i501[187], i501[186], i501[185], i501[184], i501[183], i501[182], i501[181], i501[180], i501[179], i501[178], i501[177], i501[176], i501[175], i501[174], i501[173], i501[172], i501[171], i501[170], i501[169], i501[168], i501[167], i501[166], i501[165], i501[164], i501[163], i501[162], i501[161], i501[160], i501[159], i501[158], i501[157], i501[156], i501[155], i501[154], i501[153], i501[152], i501[151], i501[150], i501[149], i501[148], i501[147], i501[146], i501[145], i501[144], i501[143], i501[142], i501[141], i501[140], i501[139], i501[138], i501[137], i501[136], i501[135], i501[134], i501[133], i501[132], i501[131], i501[130], i501[129], i501[128], i501[127], i501[126], i501[125], i501[124], i501[123], i501[122], i501[121], i501[120], i501[119], i501[118], i501[117], i501[116], i501[115], i501[114], i501[113], i501[112], i501[111], i501[110], i501[109], i501[108], i501[107], i501[106], i501[105], i501[104], i501[103], i501[102], i501[101], i501[100], i501[99], i501[98], i501[97], i501[96], i501[95], i501[94], i501[93], i501[92], i501[91], i501[90], i501[89], i501[88], i501[87], i501[86], i501[85], i501[84], i501[83], i501[82], i501[81], i501[80], i501[79], i501[78], i501[77], i501[76], i501[75], i501[74], i501[73], i501[72], i501[71], i501[70], i501[69], i501[68], i501[67], i501[66], i501[65], i501[64], i501[63], i501[62], i501[61], i501[60], i501[59], i501[58], i501[57], i501[56], i501[55], i501[54], i501[53], i501[52], i501[51], i501[50], i501[49], i501[48], i501[47], i501[46], i501[45], i501[44], i501[43], i501[42], i501[41], i501[40], i501[39], i501[38], i501[37], i501[36], i501[35], i501[34], i501[33], i501[32], i501[31], i501[30], i501[29], i501[28], i501[27], i501[26], i501[25], i501[24], i501[23], i501[22], i501[21], i501[20], i501[19], i501[18], i501[17], i501[16], i501[15], i501[14], i501[13], i501[12], i501[11], i501[10], i501[9], i501[8], i501[7], i501[6], i501[5], i501[4], i501[3], i501[2], i501[1], i501[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i502[193], i502[192], i502[191], i502[190], i502[189], i502[188], i502[187], i502[186], i502[185], i502[184], i502[183], i502[182], i502[181], i502[180], i502[179], i502[178], i502[177], i502[176], i502[175], i502[174], i502[173], i502[172], i502[171], i502[170], i502[169], i502[168], i502[167], i502[166], i502[165], i502[164], i502[163], i502[162], i502[161], i502[160], i502[159], i502[158], i502[157], i502[156], i502[155], i502[154], i502[153], i502[152], i502[151], i502[150], i502[149], i502[148], i502[147], i502[146], i502[145], i502[144], i502[143], i502[142], i502[141], i502[140], i502[139], i502[138], i502[137], i502[136], i502[135], i502[134], i502[133], i502[132], i502[131], i502[130], i502[129], i502[128], i502[127], i502[126], i502[125], i502[124], i502[123], i502[122], i502[121], i502[120], i502[119], i502[118], i502[117], i502[116], i502[115], i502[114], i502[113], i502[112], i502[111], i502[110], i502[109], i502[108], i502[107], i502[106], i502[105], i502[104], i502[103], i502[102], i502[101], i502[100], i502[99], i502[98], i502[97], i502[96], i502[95], i502[94], i502[93], i502[92], i502[91], i502[90], i502[89], i502[88], i502[87], i502[86], i502[85], i502[84], i502[83], i502[82], i502[81], i502[80], i502[79], i502[78], i502[77], i502[76], i502[75], i502[74], i502[73], i502[72], i502[71], i502[70], i502[69], i502[68], i502[67], i502[66], i502[65], i502[64], i502[63], i502[62], i502[61], i502[60], i502[59], i502[58], i502[57], i502[56], i502[55], i502[54], i502[53], i502[52], i502[51], i502[50], i502[49], i502[48], i502[47], i502[46], i502[45], i502[44], i502[43], i502[42], i502[41], i502[40], i502[39], i502[38], i502[37], i502[36], i502[35], i502[34], i502[33], i502[32], i502[31], i502[30], i502[29], i502[28], i502[27], i502[26], i502[25], i502[24], i502[23], i502[22], i502[21], i502[20], i502[19], i502[18], i502[17], i502[16], i502[15], i502[14], i502[13], i502[12], i502[11], i502[10], i502[9], i502[8], i502[7], i502[6], i502[5], i502[4], i502[3], i502[2], i502[1], i502[0]};
wire [255:0] t3 = {i503[255], i503[254], i503[253], i503[252], i503[251], i503[250], i503[249], i503[248], i503[247], i503[246], i503[245], i503[244], i503[243], i503[242], i503[241], i503[240], i503[239], i503[238], i503[237], i503[236], i503[235], i503[234], i503[233], i503[232], i503[231], i503[230], i503[229], i503[228], i503[227], i503[226], i503[225], i503[224], i503[223], i503[222], i503[221], i503[220], i503[219], i503[218], i503[217], i503[216], i503[215], i503[214], i503[213], i503[212], i503[211], i503[210], i503[209], i503[208], i503[207], i503[206], i503[205], i503[204], i503[203], i503[202], i503[201], i503[200], i503[199], i503[198], i503[197], i503[196], i503[195], i503[194], i503[193], i503[192], i503[191], i503[190], i503[189], i503[188], i503[187], i503[186], i503[185], i503[184], i503[183], i503[182], i503[181], i503[180], i503[179], i503[178], i503[177], i503[176], i503[175], i503[174], i503[173], i503[172], i503[171], i503[170], i503[169], i503[168], i503[167], i503[166], i503[165], i503[164], i503[163], i503[162], i503[161], i503[160], i503[159], i503[158], i503[157], i503[156], i503[155], i503[154], i503[153], i503[152], i503[151], i503[150], i503[149], i503[148], i503[147], i503[146], i503[145], i503[144], i503[143], i503[142], i503[141], i503[140], i503[139], i503[138], i503[137], i503[136], i503[135], i503[134], i503[133], i503[132], i503[131], i503[130], i503[129], i503[128], i503[127], i503[126], i503[125], i503[124], i503[123], i503[122], i503[121], i503[120], i503[119], i503[118], i503[117], i503[116], i503[115], i503[114], i503[113], i503[112], i503[111], i503[110], i503[109], i503[108], i503[107], i503[106], i503[105], i503[104], i503[103], i503[102], i503[101], i503[100], i503[99], i503[98], i503[97], i503[96], i503[95], i503[94], i503[93], i503[92], i503[91], i503[90], i503[89], i503[88], i503[87], i503[86], i503[85], i503[84], i503[83], i503[82], i503[81], i503[80], i503[79], i503[78], i503[77], i503[76], i503[75], i503[74], i503[73], i503[72], i503[71], i503[70], i503[69], i503[68], i503[67], i503[66], i503[65], i503[64], i503[63], i503[62], i503[61], i503[60], i503[59], i503[58], i503[57], i503[56], i503[55], i503[54], i503[53], i503[52], i503[51], i503[50], i503[49], i503[48], i503[47], i503[46], i503[45], i503[44], i503[43], i503[42], i503[41], i503[40], i503[39], i503[38], i503[37], i503[36], i503[35], i503[34], i503[33], i503[32], i503[31], i503[30], i503[29], i503[28], i503[27], i503[26], i503[25], i503[24], i503[23], i503[22], i503[21], i503[20], i503[19], i503[18], i503[17], i503[16], i503[15], i503[14], i503[13], i503[12], i503[11], i503[10], i503[9], i503[8], i503[7], i503[6], i503[5], i503[4], i503[3], i503[2], i503[1], i503[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454_reduce(input wire [163:0] i504, input wire [195:0] i505, input wire [227:0] i506, input wire [259:0] i507, output wire [261:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i504[163], i504[162], i504[161], i504[160], i504[159], i504[158], i504[157], i504[156], i504[155], i504[154], i504[153], i504[152], i504[151], i504[150], i504[149], i504[148], i504[147], i504[146], i504[145], i504[144], i504[143], i504[142], i504[141], i504[140], i504[139], i504[138], i504[137], i504[136], i504[135], i504[134], i504[133], i504[132], i504[131], i504[130], i504[129], i504[128], i504[127], i504[126], i504[125], i504[124], i504[123], i504[122], i504[121], i504[120], i504[119], i504[118], i504[117], i504[116], i504[115], i504[114], i504[113], i504[112], i504[111], i504[110], i504[109], i504[108], i504[107], i504[106], i504[105], i504[104], i504[103], i504[102], i504[101], i504[100], i504[99], i504[98], i504[97], i504[96], i504[95], i504[94], i504[93], i504[92], i504[91], i504[90], i504[89], i504[88], i504[87], i504[86], i504[85], i504[84], i504[83], i504[82], i504[81], i504[80], i504[79], i504[78], i504[77], i504[76], i504[75], i504[74], i504[73], i504[72], i504[71], i504[70], i504[69], i504[68], i504[67], i504[66], i504[65], i504[64], i504[63], i504[62], i504[61], i504[60], i504[59], i504[58], i504[57], i504[56], i504[55], i504[54], i504[53], i504[52], i504[51], i504[50], i504[49], i504[48], i504[47], i504[46], i504[45], i504[44], i504[43], i504[42], i504[41], i504[40], i504[39], i504[38], i504[37], i504[36], i504[35], i504[34], i504[33], i504[32], i504[31], i504[30], i504[29], i504[28], i504[27], i504[26], i504[25], i504[24], i504[23], i504[22], i504[21], i504[20], i504[19], i504[18], i504[17], i504[16], i504[15], i504[14], i504[13], i504[12], i504[11], i504[10], i504[9], i504[8], i504[7], i504[6], i504[5], i504[4], i504[3], i504[2], i504[1], i504[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i505[195], i505[194], i505[193], i505[192], i505[191], i505[190], i505[189], i505[188], i505[187], i505[186], i505[185], i505[184], i505[183], i505[182], i505[181], i505[180], i505[179], i505[178], i505[177], i505[176], i505[175], i505[174], i505[173], i505[172], i505[171], i505[170], i505[169], i505[168], i505[167], i505[166], i505[165], i505[164], i505[163], i505[162], i505[161], i505[160], i505[159], i505[158], i505[157], i505[156], i505[155], i505[154], i505[153], i505[152], i505[151], i505[150], i505[149], i505[148], i505[147], i505[146], i505[145], i505[144], i505[143], i505[142], i505[141], i505[140], i505[139], i505[138], i505[137], i505[136], i505[135], i505[134], i505[133], i505[132], i505[131], i505[130], i505[129], i505[128], i505[127], i505[126], i505[125], i505[124], i505[123], i505[122], i505[121], i505[120], i505[119], i505[118], i505[117], i505[116], i505[115], i505[114], i505[113], i505[112], i505[111], i505[110], i505[109], i505[108], i505[107], i505[106], i505[105], i505[104], i505[103], i505[102], i505[101], i505[100], i505[99], i505[98], i505[97], i505[96], i505[95], i505[94], i505[93], i505[92], i505[91], i505[90], i505[89], i505[88], i505[87], i505[86], i505[85], i505[84], i505[83], i505[82], i505[81], i505[80], i505[79], i505[78], i505[77], i505[76], i505[75], i505[74], i505[73], i505[72], i505[71], i505[70], i505[69], i505[68], i505[67], i505[66], i505[65], i505[64], i505[63], i505[62], i505[61], i505[60], i505[59], i505[58], i505[57], i505[56], i505[55], i505[54], i505[53], i505[52], i505[51], i505[50], i505[49], i505[48], i505[47], i505[46], i505[45], i505[44], i505[43], i505[42], i505[41], i505[40], i505[39], i505[38], i505[37], i505[36], i505[35], i505[34], i505[33], i505[32], i505[31], i505[30], i505[29], i505[28], i505[27], i505[26], i505[25], i505[24], i505[23], i505[22], i505[21], i505[20], i505[19], i505[18], i505[17], i505[16], i505[15], i505[14], i505[13], i505[12], i505[11], i505[10], i505[9], i505[8], i505[7], i505[6], i505[5], i505[4], i505[3], i505[2], i505[1], i505[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i506[227], i506[226], i506[225], i506[224], i506[223], i506[222], i506[221], i506[220], i506[219], i506[218], i506[217], i506[216], i506[215], i506[214], i506[213], i506[212], i506[211], i506[210], i506[209], i506[208], i506[207], i506[206], i506[205], i506[204], i506[203], i506[202], i506[201], i506[200], i506[199], i506[198], i506[197], i506[196], i506[195], i506[194], i506[193], i506[192], i506[191], i506[190], i506[189], i506[188], i506[187], i506[186], i506[185], i506[184], i506[183], i506[182], i506[181], i506[180], i506[179], i506[178], i506[177], i506[176], i506[175], i506[174], i506[173], i506[172], i506[171], i506[170], i506[169], i506[168], i506[167], i506[166], i506[165], i506[164], i506[163], i506[162], i506[161], i506[160], i506[159], i506[158], i506[157], i506[156], i506[155], i506[154], i506[153], i506[152], i506[151], i506[150], i506[149], i506[148], i506[147], i506[146], i506[145], i506[144], i506[143], i506[142], i506[141], i506[140], i506[139], i506[138], i506[137], i506[136], i506[135], i506[134], i506[133], i506[132], i506[131], i506[130], i506[129], i506[128], i506[127], i506[126], i506[125], i506[124], i506[123], i506[122], i506[121], i506[120], i506[119], i506[118], i506[117], i506[116], i506[115], i506[114], i506[113], i506[112], i506[111], i506[110], i506[109], i506[108], i506[107], i506[106], i506[105], i506[104], i506[103], i506[102], i506[101], i506[100], i506[99], i506[98], i506[97], i506[96], i506[95], i506[94], i506[93], i506[92], i506[91], i506[90], i506[89], i506[88], i506[87], i506[86], i506[85], i506[84], i506[83], i506[82], i506[81], i506[80], i506[79], i506[78], i506[77], i506[76], i506[75], i506[74], i506[73], i506[72], i506[71], i506[70], i506[69], i506[68], i506[67], i506[66], i506[65], i506[64], i506[63], i506[62], i506[61], i506[60], i506[59], i506[58], i506[57], i506[56], i506[55], i506[54], i506[53], i506[52], i506[51], i506[50], i506[49], i506[48], i506[47], i506[46], i506[45], i506[44], i506[43], i506[42], i506[41], i506[40], i506[39], i506[38], i506[37], i506[36], i506[35], i506[34], i506[33], i506[32], i506[31], i506[30], i506[29], i506[28], i506[27], i506[26], i506[25], i506[24], i506[23], i506[22], i506[21], i506[20], i506[19], i506[18], i506[17], i506[16], i506[15], i506[14], i506[13], i506[12], i506[11], i506[10], i506[9], i506[8], i506[7], i506[6], i506[5], i506[4], i506[3], i506[2], i506[1], i506[0]};
wire [255:0] t3 = {i507[255], i507[254], i507[253], i507[252], i507[251], i507[250], i507[249], i507[248], i507[247], i507[246], i507[245], i507[244], i507[243], i507[242], i507[241], i507[240], i507[239], i507[238], i507[237], i507[236], i507[235], i507[234], i507[233], i507[232], i507[231], i507[230], i507[229], i507[228], i507[227], i507[226], i507[225], i507[224], i507[223], i507[222], i507[221], i507[220], i507[219], i507[218], i507[217], i507[216], i507[215], i507[214], i507[213], i507[212], i507[211], i507[210], i507[209], i507[208], i507[207], i507[206], i507[205], i507[204], i507[203], i507[202], i507[201], i507[200], i507[199], i507[198], i507[197], i507[196], i507[195], i507[194], i507[193], i507[192], i507[191], i507[190], i507[189], i507[188], i507[187], i507[186], i507[185], i507[184], i507[183], i507[182], i507[181], i507[180], i507[179], i507[178], i507[177], i507[176], i507[175], i507[174], i507[173], i507[172], i507[171], i507[170], i507[169], i507[168], i507[167], i507[166], i507[165], i507[164], i507[163], i507[162], i507[161], i507[160], i507[159], i507[158], i507[157], i507[156], i507[155], i507[154], i507[153], i507[152], i507[151], i507[150], i507[149], i507[148], i507[147], i507[146], i507[145], i507[144], i507[143], i507[142], i507[141], i507[140], i507[139], i507[138], i507[137], i507[136], i507[135], i507[134], i507[133], i507[132], i507[131], i507[130], i507[129], i507[128], i507[127], i507[126], i507[125], i507[124], i507[123], i507[122], i507[121], i507[120], i507[119], i507[118], i507[117], i507[116], i507[115], i507[114], i507[113], i507[112], i507[111], i507[110], i507[109], i507[108], i507[107], i507[106], i507[105], i507[104], i507[103], i507[102], i507[101], i507[100], i507[99], i507[98], i507[97], i507[96], i507[95], i507[94], i507[93], i507[92], i507[91], i507[90], i507[89], i507[88], i507[87], i507[86], i507[85], i507[84], i507[83], i507[82], i507[81], i507[80], i507[79], i507[78], i507[77], i507[76], i507[75], i507[74], i507[73], i507[72], i507[71], i507[70], i507[69], i507[68], i507[67], i507[66], i507[65], i507[64], i507[63], i507[62], i507[61], i507[60], i507[59], i507[58], i507[57], i507[56], i507[55], i507[54], i507[53], i507[52], i507[51], i507[50], i507[49], i507[48], i507[47], i507[46], i507[45], i507[44], i507[43], i507[42], i507[41], i507[40], i507[39], i507[38], i507[37], i507[36], i507[35], i507[34], i507[33], i507[32], i507[31], i507[30], i507[29], i507[28], i507[27], i507[26], i507[25], i507[24], i507[23], i507[22], i507[21], i507[20], i507[19], i507[18], i507[17], i507[16], i507[15], i507[14], i507[13], i507[12], i507[11], i507[10], i507[9], i507[8], i507[7], i507[6], i507[5], i507[4], i507[3], i507[2], i507[1], i507[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349Core(input wire [223:0] a,input wire [239:0] b,input wire cin,output wire [240:0] value);
wire [223:0] masked_a=((a&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [239:0] masked_b=((b&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [240:0] aa=241'(masked_b);
wire [240:0] bb=241'(masked_a);
wire [241:0] extended={1'b0,aa}+{1'b0,bb}+242'(1'b0);
wire [240:0] native_value=extended[240:0];
assign value=native_value[0+:241];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361Core(input wire [239:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [239:0] masked_a=((a&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [255:0] masked_b=((b&256'hffffffff00000000000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364Core(input wire [48:0] a,input wire [80:0] b,input wire cin,output wire [81:0] value);
wire [48:0] masked_a=((a&49'h1ffffffffffff)|49'h0);
wire [80:0] masked_b=((b&81'h1ffffffffffffffffffff)|81'h0);
wire [81:0] aa=82'(masked_b);
wire [81:0] bb=82'(masked_a);
wire [82:0] extended={1'b0,aa}+{1'b0,bb}+83'(1'b0);
wire [81:0] native_value=extended[81:0];
assign value=native_value[0+:82];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367Core(input wire [112:0] a,input wire [144:0] b,input wire cin,output wire [145:0] value);
wire [112:0] masked_a=((a&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [144:0] masked_b=((b&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [145:0] aa=146'(masked_b);
wire [145:0] bb=146'(masked_a);
wire [146:0] extended={1'b0,aa}+{1'b0,bb}+147'(1'b0);
wire [145:0] native_value=extended[145:0];
assign value=native_value[0+:146];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370Core(input wire [64:0] a,input wire [96:0] b,input wire cin,output wire [97:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [96:0] masked_b=((b&97'h1ffffffffffffffffffffffff)|97'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:98];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [128:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [80:0] a,input wire [112:0] b,input wire cin,output wire [113:0] value);
wire [80:0] masked_a=((a&81'h1ffffffffffffffffffff)|81'h0);
wire [112:0] masked_b=((b&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [113:0] aa=114'(masked_b);
wire [113:0] bb=114'(masked_a);
wire [114:0] extended={1'b0,aa}+{1'b0,bb}+115'(1'b0);
wire [113:0] native_value=extended[113:0];
assign value=native_value[0+:114];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379Core(input wire [144:0] a,input wire [176:0] b,input wire cin,output wire [177:0] value);
wire [144:0] masked_a=((a&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [176:0] masked_b=((b&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [177:0] aa=178'(masked_b);
wire [177:0] bb=178'(masked_a);
wire [178:0] extended={1'b0,aa}+{1'b0,bb}+179'(1'b0);
wire [177:0] native_value=extended[177:0];
assign value=native_value[0+:178];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [129:0] aa=130'(masked_b);
wire [129:0] bb=130'(masked_a);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385Core(input wire [160:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [112:0] a,input wire [144:0] b,input wire cin,output wire [145:0] value);
wire [112:0] masked_a=((a&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [144:0] masked_b=((b&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [145:0] aa=146'(masked_b);
wire [145:0] bb=146'(masked_a);
wire [146:0] extended={1'b0,aa}+{1'b0,bb}+147'(1'b0);
wire [145:0] native_value=extended[145:0];
assign value=native_value[0+:146];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391Core(input wire [176:0] a,input wire [208:0] b,input wire cin,output wire [209:0] value);
wire [176:0] masked_a=((a&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [208:0] masked_b=((b&209'h1ffffffffffffffffffffffffffffffffffffffffffffffffffff)|209'h0);
wire [209:0] aa=210'(masked_b);
wire [209:0] bb=210'(masked_a);
wire [210:0] extended={1'b0,aa}+{1'b0,bb}+211'(1'b0);
wire [209:0] native_value=extended[209:0];
assign value=native_value[0+:210];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [128:0] a,input wire [160:0] b,input wire cin,output wire [161:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [160:0] masked_b=((b&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397Core(input wire [192:0] a,input wire [224:0] b,input wire cin,output wire [225:0] value);
wire [192:0] masked_a=((a&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [224:0] masked_b=((b&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [225:0] aa=226'(masked_b);
wire [225:0] bb=226'(masked_a);
wire [226:0] extended={1'b0,aa}+{1'b0,bb}+227'(1'b0);
wire [225:0] native_value=extended[225:0];
assign value=native_value[0+:226];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400Core(input wire [144:0] a,input wire [176:0] b,input wire cin,output wire [177:0] value);
wire [144:0] masked_a=((a&145'h1ffffffffffffffffffffffffffffffffffff)|145'h0);
wire [176:0] masked_b=((b&177'h1ffffffffffffffffffffffffffffffffffffffffffff)|177'h0);
wire [177:0] aa=178'(masked_b);
wire [177:0] bb=178'(masked_a);
wire [178:0] extended={1'b0,aa}+{1'b0,bb}+179'(1'b0);
wire [177:0] native_value=extended[177:0];
assign value=native_value[0+:178];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403Core(input wire [208:0] a,input wire [240:0] b,input wire cin,output wire [241:0] value);
wire [208:0] masked_a=((a&209'h1ffffffffffffffffffffffffffffffffffffffffffffffffffff)|209'h0);
wire [240:0] masked_b=((b&241'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|241'h0);
wire [241:0] aa=242'(masked_b);
wire [241:0] bb=242'(masked_a);
wire [242:0] extended={1'b0,aa}+{1'b0,bb}+243'(1'b0);
wire [241:0] native_value=extended[241:0];
assign value=native_value[0+:242];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406Core(input wire [160:0] a,input wire [192:0] b,input wire cin,output wire [193:0] value);
wire [160:0] masked_a=((a&161'h1ffffffffffffffffffffffffffffffffffffffff)|161'h0);
wire [192:0] masked_b=((b&193'h1ffffffffffffffffffffffffffffffffffffffffffffffff)|193'h0);
wire [193:0] aa=194'(masked_b);
wire [193:0] bb=194'(masked_a);
wire [194:0] extended={1'b0,aa}+{1'b0,bb}+195'(1'b0);
wire [193:0] native_value=extended[193:0];
assign value=native_value[0+:194];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [224:0] a,input wire [256:0] b,input wire cin,output wire [255:0] value);
wire [224:0] masked_a=((a&225'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|225'h0);
wire [256:0] masked_b=((b&257'h1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|257'h0);
wire [256:0] aa=257'(masked_b);
wire [256:0] bb=257'(masked_a);
wire [257:0] extended={1'b0,aa}+{1'b0,bb}+258'(1'b0);
wire [256:0] native_value=extended[256:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
