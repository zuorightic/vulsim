`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [15:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_132; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_134; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_136; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_138; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_140; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_142; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_144; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_146; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_148; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_150; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_152; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_154; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_156; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_158; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_160; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_162; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_164; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_166; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_168; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_170; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_172; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_174; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_176; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_178; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_180; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_182; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_184; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_186; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_188; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_190; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_191; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_192; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_193; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_194; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_196; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_197; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_200; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_201; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_202; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_204; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_205; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_206; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_208; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_209; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_210; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_211; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_212; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_213; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_215; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_216; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_217; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_219; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_220; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_221; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_222; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_224; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_225; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_226; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_228; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_229; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_232; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_234; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_235; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_236; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_237; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_239; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_240; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_244; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_248; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_252; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_256; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_260; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_264; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_265; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_266; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_267; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_268; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_269; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_270; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_271; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_272; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_273; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_274; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_275; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_276; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_277; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_278; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_279; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_280; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_281; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_282; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_283; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_284; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_285; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_286; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_287; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_288; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_289; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_290; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_291; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_292; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_293; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_294; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_295; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_296; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_297; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_298; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_299; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_300; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_301; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_302; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_303; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_304; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_305; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_306; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_307; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_308; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_309; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_310; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_311; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_312; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_313; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_314; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_315; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_316; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_317; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_318; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_319; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_320; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_321; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_322; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_323; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_324; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_325; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_326; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_327; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_328; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_329; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_330; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_331; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_332; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_333; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_334; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_335; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_336; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_337; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_338; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_339; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_340; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_341; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_342; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_343; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_344; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_345; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_346; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_347; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_348; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_349; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_350; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_351; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_352; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_353; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_354; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_355; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_356; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_357; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_358; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_359; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_360; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_361; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_362; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_363; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_364; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_365; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_366; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_367; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_368; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_369; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_370; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_371; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_372; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_373; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_374; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_375; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_376; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_377; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_378; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_379; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_382; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_383; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_384; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_385; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_386; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_387; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_388; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_389; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_390; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_391; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_392; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_393; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_394; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_395; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_396; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_397; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_398; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_399; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_400; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_401; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_402; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_403; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_404; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_405; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_406; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_407; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_408; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_409; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_410; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_411; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_412; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_413; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_414; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_415; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_416; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_417; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_418; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_419; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_420; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_421; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_422; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_423; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_424; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_425; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_426; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_427; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_428; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_429; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_430; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_431; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_432; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_433; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_434; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_435; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_436; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_437; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_438; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_439; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_440; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_441; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_442; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_443; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_444; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_445; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_446; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_447; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_448; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_449; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_450; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_451; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_452; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_453; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_454; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_455; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_81_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_93_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_133_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_137_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_141_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_145_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_149_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_153_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_157_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_161_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_165_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_169_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_173_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_177_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_181_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_185_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_189_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_193_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_201_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_205_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_209_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_213_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_217_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_221_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_225_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_229_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_233_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_237_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_241_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_245_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_249_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_253_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_257_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_261_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_364_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_367_s2; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_370_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_373_s2; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_376_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_382_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
    logic [145:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [209:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_394_s2; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_397_s2; // decl: <none>; prim: <none>
    logic [177:0] rtlzz_pipe_400_s2; // decl: <none>; prim: <none>
    logic [241:0] rtlzz_pipe_403_s2; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_406_s2; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_409_s2; // decl: <none>; prim: <none>
    logic [146:0] rtlzz_pipe_412_s3; // decl: <none>; prim: <none>
    logic [162:0] rtlzz_pipe_415_s3; // decl: <none>; prim: <none>
    logic [178:0] rtlzz_pipe_418_s3; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_421_s3; // decl: <none>; prim: <none>
    logic [210:0] rtlzz_pipe_424_s3; // decl: <none>; prim: <none>
    logic [226:0] rtlzz_pipe_427_s3; // decl: <none>; prim: <none>
    logic [242:0] rtlzz_pipe_430_s3; // decl: <none>; prim: <none>
    logic [258:0] rtlzz_pipe_433_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_455; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(16'(mul_tree_10_11)), .b(16'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(16'(mul_tree_10_14)), .b(16'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(16'(mul_tree_10_18)), .b(16'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(16'(mul_tree_10_22)), .b(16'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(mul_tree_10_26)), .b(16'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(16'(mul_tree_10_30)), .b(16'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(16'(mul_tree_10_34)), .b(16'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(16'(mul_tree_10_38)), .b(16'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(16'(mul_tree_10_42)), .b(16'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(mul_tree_10_46)), .b(16'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(16'(mul_tree_10_50)), .b(16'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(16'(mul_tree_10_54)), .b(16'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(16'(mul_tree_10_58)), .b(16'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(16'(mul_tree_10_62)), .b(16'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(mul_tree_10_66)), .b(16'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(16'(mul_tree_10_70)), .b(16'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(16'(mul_tree_10_74)), .b(16'(mul_tree_10_75)), .cin(1'b0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = {mul_tree_10_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(16'(mul_tree_10_78)), .b(16'(mul_tree_10_79)), .cin(1'b0), .value(mul_tree_10_80));
    assign mul_tree_10_81 = {mul_tree_10_80, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(16'(mul_tree_10_82)), .b(16'(mul_tree_10_83)), .cin(1'b0), .value(mul_tree_10_84));
    assign mul_tree_10_85 = {mul_tree_10_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(mul_tree_10_86)), .b(16'(mul_tree_10_87)), .cin(1'b0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = {mul_tree_10_88, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(16'(mul_tree_10_90)), .b(16'(mul_tree_10_91)), .cin(1'b0), .value(mul_tree_10_92));
    assign mul_tree_10_93 = {mul_tree_10_92, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_96Core rtlzz_owner_96(.a(16'(mul_tree_10_94)), .b(16'(mul_tree_10_95)), .cin(1'b0), .value(mul_tree_10_96));
    assign mul_tree_10_97 = {mul_tree_10_96, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(16'(mul_tree_10_98)), .b(16'(mul_tree_10_99)), .cin(1'b0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = {mul_tree_10_100, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(16'(mul_tree_10_102)), .b(16'(mul_tree_10_103)), .cin(1'b0), .value(mul_tree_10_104));
    assign mul_tree_10_105 = {mul_tree_10_104, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_107 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(16'(mul_tree_10_106)), .b(16'(mul_tree_10_107)), .cin(1'b0), .value(mul_tree_10_108));
    assign mul_tree_10_109 = {mul_tree_10_108, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_110 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_111 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(16'(mul_tree_10_110)), .b(16'(mul_tree_10_111)), .cin(1'b0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = {mul_tree_10_112, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_114 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_115 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(16'(mul_tree_10_114)), .b(16'(mul_tree_10_115)), .cin(1'b0), .value(mul_tree_10_116));
    assign mul_tree_10_117 = {mul_tree_10_116, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_118 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(16'(mul_tree_10_118)), .b(16'(mul_tree_10_119)), .cin(1'b0), .value(mul_tree_10_120));
    assign mul_tree_10_121 = {mul_tree_10_120, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_122 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_123 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(16'(mul_tree_10_122)), .b(16'(mul_tree_10_123)), .cin(1'b0), .value(mul_tree_10_124));
    assign mul_tree_10_125 = {mul_tree_10_124, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_126 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_127 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(mul_tree_10_126)), .b(16'(mul_tree_10_127)), .cin(1'b0), .value(mul_tree_10_128));
    assign mul_tree_10_129 = {mul_tree_10_128, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_131 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_10_130)), .b(16'(mul_tree_10_131)), .cin(1'b0), .value(mul_tree_10_132));
    assign mul_tree_10_133 = {mul_tree_10_132, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_134 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_135 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(16'(mul_tree_10_134)), .b(16'(mul_tree_10_135)), .cin(1'b0), .value(mul_tree_10_136));
    assign mul_tree_10_137 = {mul_tree_10_136, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_138 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_139 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(16'(mul_tree_10_138)), .b(16'(mul_tree_10_139)), .cin(1'b0), .value(mul_tree_10_140));
    assign mul_tree_10_141 = {mul_tree_10_140, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_142 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_143 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(16'(mul_tree_10_142)), .b(16'(mul_tree_10_143)), .cin(1'b0), .value(mul_tree_10_144));
    assign mul_tree_10_145 = {mul_tree_10_144, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_146 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_147 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(mul_tree_10_146)), .b(16'(mul_tree_10_147)), .cin(1'b0), .value(mul_tree_10_148));
    assign mul_tree_10_149 = {mul_tree_10_148, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_150 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_151 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_152Core rtlzz_owner_152(.a(16'(mul_tree_10_150)), .b(16'(mul_tree_10_151)), .cin(1'b0), .value(mul_tree_10_152));
    assign mul_tree_10_153 = {mul_tree_10_152, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_154 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_155 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(16'(mul_tree_10_154)), .b(16'(mul_tree_10_155)), .cin(1'b0), .value(mul_tree_10_156));
    assign mul_tree_10_157 = {mul_tree_10_156, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_158 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_159 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(16'(mul_tree_10_158)), .b(16'(mul_tree_10_159)), .cin(1'b0), .value(mul_tree_10_160));
    assign mul_tree_10_161 = {mul_tree_10_160, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_162 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_163 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_164Core rtlzz_owner_164(.a(16'(mul_tree_10_162)), .b(16'(mul_tree_10_163)), .cin(1'b0), .value(mul_tree_10_164));
    assign mul_tree_10_165 = {mul_tree_10_164, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_166 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_167 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(mul_tree_10_166)), .b(16'(mul_tree_10_167)), .cin(1'b0), .value(mul_tree_10_168));
    assign mul_tree_10_169 = {mul_tree_10_168, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_170 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_171 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(16'(mul_tree_10_170)), .b(16'(mul_tree_10_171)), .cin(1'b0), .value(mul_tree_10_172));
    assign mul_tree_10_173 = {mul_tree_10_172, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_174 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_175 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(16'(mul_tree_10_174)), .b(16'(mul_tree_10_175)), .cin(1'b0), .value(mul_tree_10_176));
    assign mul_tree_10_177 = {mul_tree_10_176, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_178 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_179 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(16'(mul_tree_10_178)), .b(16'(mul_tree_10_179)), .cin(1'b0), .value(mul_tree_10_180));
    assign mul_tree_10_181 = {mul_tree_10_180, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_182 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_183 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(16'(mul_tree_10_182)), .b(16'(mul_tree_10_183)), .cin(1'b0), .value(mul_tree_10_184));
    assign mul_tree_10_185 = {mul_tree_10_184, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_186 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_187 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(mul_tree_10_186)), .b(16'(mul_tree_10_187)), .cin(1'b0), .value(mul_tree_10_188));
    assign mul_tree_10_189 = {mul_tree_10_188, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_190 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_191 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_192Core rtlzz_owner_192(.a(16'(mul_tree_10_190)), .b(16'(mul_tree_10_191)), .cin(1'b0), .value(mul_tree_10_192));
    assign mul_tree_10_193 = {mul_tree_10_192, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_194 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_195 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_196Core rtlzz_owner_196(.a(16'(mul_tree_10_194)), .b(16'(mul_tree_10_195)), .cin(1'b0), .value(mul_tree_10_196));
    assign mul_tree_10_197 = {mul_tree_10_196, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_198 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_199 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(16'(mul_tree_10_198)), .b(16'(mul_tree_10_199)), .cin(1'b0), .value(mul_tree_10_200));
    assign mul_tree_10_201 = {mul_tree_10_200, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_202 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_203 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(16'(mul_tree_10_202)), .b(16'(mul_tree_10_203)), .cin(1'b0), .value(mul_tree_10_204));
    assign mul_tree_10_205 = {mul_tree_10_204, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_206 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_207 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_208Core rtlzz_owner_208(.a(16'(mul_tree_10_206)), .b(16'(mul_tree_10_207)), .cin(1'b0), .value(mul_tree_10_208));
    assign mul_tree_10_209 = {mul_tree_10_208, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_210 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_211 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(16'(mul_tree_10_210)), .b(16'(mul_tree_10_211)), .cin(1'b0), .value(mul_tree_10_212));
    assign mul_tree_10_213 = {mul_tree_10_212, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_214 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_215 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(16'(mul_tree_10_214)), .b(16'(mul_tree_10_215)), .cin(1'b0), .value(mul_tree_10_216));
    assign mul_tree_10_217 = {mul_tree_10_216, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_218 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_219 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(16'(mul_tree_10_218)), .b(16'(mul_tree_10_219)), .cin(1'b0), .value(mul_tree_10_220));
    assign mul_tree_10_221 = {mul_tree_10_220, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_222 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_223 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(16'(mul_tree_10_222)), .b(16'(mul_tree_10_223)), .cin(1'b0), .value(mul_tree_10_224));
    assign mul_tree_10_225 = {mul_tree_10_224, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_226 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_227 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(16'(mul_tree_10_226)), .b(16'(mul_tree_10_227)), .cin(1'b0), .value(mul_tree_10_228));
    assign mul_tree_10_229 = {mul_tree_10_228, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_230 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_231 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_232Core rtlzz_owner_232(.a(16'(mul_tree_10_230)), .b(16'(mul_tree_10_231)), .cin(1'b0), .value(mul_tree_10_232));
    assign mul_tree_10_233 = {mul_tree_10_232, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_234 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_235 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_236Core rtlzz_owner_236(.a(16'(mul_tree_10_234)), .b(16'(mul_tree_10_235)), .cin(1'b0), .value(mul_tree_10_236));
    assign mul_tree_10_237 = {mul_tree_10_236, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_238 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_239 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(16'(mul_tree_10_238)), .b(16'(mul_tree_10_239)), .cin(1'b0), .value(mul_tree_10_240));
    assign mul_tree_10_241 = {mul_tree_10_240, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_242 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_243 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_10_242)), .b(16'(mul_tree_10_243)), .cin(1'b0), .value(mul_tree_10_244));
    assign mul_tree_10_245 = {mul_tree_10_244, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_246 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_247 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_10_246)), .b(16'(mul_tree_10_247)), .cin(1'b0), .value(mul_tree_10_248));
    assign mul_tree_10_249 = {mul_tree_10_248, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_250 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_251 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_10_250)), .b(16'(mul_tree_10_251)), .cin(1'b0), .value(mul_tree_10_252));
    assign mul_tree_10_253 = {mul_tree_10_252, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_254 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_255 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_10_254)), .b(16'(mul_tree_10_255)), .cin(1'b0), .value(mul_tree_10_256));
    assign mul_tree_10_257 = {mul_tree_10_256, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_258 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_259 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_10_258)), .b(16'(mul_tree_10_259)), .cin(1'b0), .value(mul_tree_10_260));
    assign mul_tree_10_261 = {mul_tree_10_260, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_262 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_263 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_10_262)), .b(16'(mul_tree_10_263)), .cin(1'b0), .value(mul_tree_10_264));
    assign mul_tree_10_265 = {mul_tree_10_264, 224'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_266 = ({17'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_267 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_269 = ({17'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_270 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_272 = ({17'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_273 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_275 = ({17'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_276 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_278 = ({17'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_279 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_281 = ({17'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_282 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_284 = ({17'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_285 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_287 = ({17'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_288 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_290 = ({17'h0, rtlzz_pipe_77_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_291 = ({1'h0, rtlzz_pipe_81_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_293 = ({17'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_294 = ({1'h0, rtlzz_pipe_89_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_296 = ({17'h0, rtlzz_pipe_93_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_297 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_299 = ({17'h0, rtlzz_pipe_101_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_300 = ({1'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_302 = ({17'h0, rtlzz_pipe_109_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_303 = ({1'h0, rtlzz_pipe_113_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_305 = ({17'h0, rtlzz_pipe_117_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_306 = ({1'h0, rtlzz_pipe_121_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_308 = ({17'h0, rtlzz_pipe_125_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_309 = ({1'h0, rtlzz_pipe_129_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_311 = ({17'h0, rtlzz_pipe_133_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_312 = ({1'h0, rtlzz_pipe_137_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_314 = ({17'h0, rtlzz_pipe_141_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_315 = ({1'h0, rtlzz_pipe_145_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_317 = ({17'h0, rtlzz_pipe_149_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_318 = ({1'h0, rtlzz_pipe_153_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_320 = ({17'h0, rtlzz_pipe_157_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_321 = ({1'h0, rtlzz_pipe_161_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_323 = ({17'h0, rtlzz_pipe_165_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_324 = ({1'h0, rtlzz_pipe_169_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_326 = ({17'h0, rtlzz_pipe_173_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_327 = ({1'h0, rtlzz_pipe_177_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_329 = ({17'h0, rtlzz_pipe_181_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_330 = ({1'h0, rtlzz_pipe_185_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_332 = ({17'h0, rtlzz_pipe_189_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_333 = ({1'h0, rtlzz_pipe_193_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_335 = ({17'h0, rtlzz_pipe_197_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_336 = ({1'h0, rtlzz_pipe_201_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_338 = ({17'h0, rtlzz_pipe_205_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_339 = ({1'h0, rtlzz_pipe_209_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_341 = ({17'h0, rtlzz_pipe_213_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_342 = ({1'h0, rtlzz_pipe_217_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_344 = ({17'h0, rtlzz_pipe_221_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_345 = ({1'h0, rtlzz_pipe_225_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_347 = ({17'h0, rtlzz_pipe_229_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_348 = ({1'h0, rtlzz_pipe_233_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_350 = ({17'h0, rtlzz_pipe_237_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_351 = ({1'h0, rtlzz_pipe_241_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_353 = ({17'h0, rtlzz_pipe_245_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_354 = ({1'h0, rtlzz_pipe_249_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_356 = ({17'h0, rtlzz_pipe_253_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_357 = ({1'h0, rtlzz_pipe_257_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_359 = ({17'h0, rtlzz_pipe_261_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_360 = ({1'h0, rtlzz_pipe_265_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_362 = ({33'h0, mul_tree_10_268}); // decl: <none>; prim: <none>
    assign mul_tree_10_363 = ({1'h0, mul_tree_10_271}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364_reduce rtlzz_reduce_364(.i456(rtlzz_pipe_13_s1), .i457(rtlzz_pipe_17_s1), .i458(rtlzz_pipe_21_s1), .i459(rtlzz_pipe_25_s1), .y(mul_tree_10_364));
    assign mul_tree_10_365 = ({33'h0, mul_tree_10_274}); // decl: <none>; prim: <none>
    assign mul_tree_10_366 = ({1'h0, mul_tree_10_277}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_367_reduce rtlzz_reduce_367(.i460(rtlzz_pipe_29_s1), .i461(rtlzz_pipe_33_s1), .i462(rtlzz_pipe_37_s1), .i463(rtlzz_pipe_41_s1), .y(mul_tree_10_367));
    assign mul_tree_10_368 = ({33'h0, mul_tree_10_280}); // decl: <none>; prim: <none>
    assign mul_tree_10_369 = ({1'h0, mul_tree_10_283}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_370_reduce rtlzz_reduce_370(.i464(rtlzz_pipe_45_s1), .i465(rtlzz_pipe_49_s1), .i466(rtlzz_pipe_53_s1), .i467(rtlzz_pipe_57_s1), .y(mul_tree_10_370));
    assign mul_tree_10_371 = ({33'h0, mul_tree_10_286}); // decl: <none>; prim: <none>
    assign mul_tree_10_372 = ({1'h0, mul_tree_10_289}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373_reduce rtlzz_reduce_373(.i468(rtlzz_pipe_61_s1), .i469(rtlzz_pipe_65_s1), .i470(rtlzz_pipe_69_s1), .i471(rtlzz_pipe_73_s1), .y(mul_tree_10_373));
    assign mul_tree_10_374 = ({33'h0, mul_tree_10_292}); // decl: <none>; prim: <none>
    assign mul_tree_10_375 = ({1'h0, mul_tree_10_295}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376_reduce rtlzz_reduce_376(.i472(rtlzz_pipe_77_s1), .i473(rtlzz_pipe_81_s1), .i474(rtlzz_pipe_85_s1), .i475(rtlzz_pipe_89_s1), .y(mul_tree_10_376));
    assign mul_tree_10_377 = ({33'h0, mul_tree_10_298}); // decl: <none>; prim: <none>
    assign mul_tree_10_378 = ({1'h0, mul_tree_10_301}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_379_reduce rtlzz_reduce_379(.i476(rtlzz_pipe_93_s1), .i477(rtlzz_pipe_97_s1), .i478(rtlzz_pipe_101_s1), .i479(rtlzz_pipe_105_s1), .y(mul_tree_10_379));
    assign mul_tree_10_380 = ({33'h0, mul_tree_10_304}); // decl: <none>; prim: <none>
    assign mul_tree_10_381 = ({1'h0, mul_tree_10_307}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382_reduce rtlzz_reduce_382(.i480(rtlzz_pipe_109_s1), .i481(rtlzz_pipe_113_s1), .i482(rtlzz_pipe_117_s1), .i483(rtlzz_pipe_121_s1), .y(mul_tree_10_382));
    assign mul_tree_10_383 = ({33'h0, mul_tree_10_310}); // decl: <none>; prim: <none>
    assign mul_tree_10_384 = ({1'h0, mul_tree_10_313}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385_reduce rtlzz_reduce_385(.i484(rtlzz_pipe_125_s1), .i485(rtlzz_pipe_129_s1), .i486(rtlzz_pipe_133_s1), .i487(rtlzz_pipe_137_s1), .y(mul_tree_10_385));
    assign mul_tree_10_386 = ({33'h0, mul_tree_10_316}); // decl: <none>; prim: <none>
    assign mul_tree_10_387 = ({1'h0, mul_tree_10_319}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388_reduce rtlzz_reduce_388(.i488(rtlzz_pipe_141_s1), .i489(rtlzz_pipe_145_s1), .i490(rtlzz_pipe_149_s1), .i491(rtlzz_pipe_153_s1), .y(mul_tree_10_388));
    assign mul_tree_10_389 = ({33'h0, mul_tree_10_322}); // decl: <none>; prim: <none>
    assign mul_tree_10_390 = ({1'h0, mul_tree_10_325}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391_reduce rtlzz_reduce_391(.i492(rtlzz_pipe_157_s1), .i493(rtlzz_pipe_161_s1), .i494(rtlzz_pipe_165_s1), .i495(rtlzz_pipe_169_s1), .y(mul_tree_10_391));
    assign mul_tree_10_392 = ({33'h0, mul_tree_10_328}); // decl: <none>; prim: <none>
    assign mul_tree_10_393 = ({1'h0, mul_tree_10_331}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394_reduce rtlzz_reduce_394(.i496(rtlzz_pipe_173_s1), .i497(rtlzz_pipe_177_s1), .i498(rtlzz_pipe_181_s1), .i499(rtlzz_pipe_185_s1), .y(mul_tree_10_394));
    assign mul_tree_10_395 = ({33'h0, mul_tree_10_334}); // decl: <none>; prim: <none>
    assign mul_tree_10_396 = ({1'h0, mul_tree_10_337}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397_reduce rtlzz_reduce_397(.i500(rtlzz_pipe_189_s1), .i501(rtlzz_pipe_193_s1), .i502(rtlzz_pipe_197_s1), .i503(rtlzz_pipe_201_s1), .y(mul_tree_10_397));
    assign mul_tree_10_398 = ({33'h0, mul_tree_10_340}); // decl: <none>; prim: <none>
    assign mul_tree_10_399 = ({1'h0, mul_tree_10_343}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_400_reduce rtlzz_reduce_400(.i504(rtlzz_pipe_205_s1), .i505(rtlzz_pipe_209_s1), .i506(rtlzz_pipe_213_s1), .i507(rtlzz_pipe_217_s1), .y(mul_tree_10_400));
    assign mul_tree_10_401 = ({33'h0, mul_tree_10_346}); // decl: <none>; prim: <none>
    assign mul_tree_10_402 = ({1'h0, mul_tree_10_349}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_403_reduce rtlzz_reduce_403(.i508(rtlzz_pipe_221_s1), .i509(rtlzz_pipe_225_s1), .i510(rtlzz_pipe_229_s1), .i511(rtlzz_pipe_233_s1), .y(mul_tree_10_403));
    assign mul_tree_10_404 = ({33'h0, mul_tree_10_352}); // decl: <none>; prim: <none>
    assign mul_tree_10_405 = ({1'h0, mul_tree_10_355}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_406_reduce rtlzz_reduce_406(.i512(rtlzz_pipe_237_s1), .i513(rtlzz_pipe_241_s1), .i514(rtlzz_pipe_245_s1), .i515(rtlzz_pipe_249_s1), .y(mul_tree_10_406));
    assign mul_tree_10_407 = ({33'h0, mul_tree_10_358}); // decl: <none>; prim: <none>
    assign mul_tree_10_408 = ({1'h0, mul_tree_10_361}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409_reduce rtlzz_reduce_409(.i516(rtlzz_pipe_253_s1), .i517(rtlzz_pipe_257_s1), .i518(rtlzz_pipe_261_s1), .i519(rtlzz_pipe_265_s1), .y(mul_tree_10_409));
    assign mul_tree_10_410 = ({65'h0, rtlzz_pipe_364_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_411 = ({1'h0, rtlzz_pipe_367_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412Core rtlzz_owner_412(.a(82'(mul_tree_10_410)), .b(146'(mul_tree_10_411)), .cin(1'h0), .value(mul_tree_10_412));
    assign mul_tree_10_413 = ({65'h0, rtlzz_pipe_370_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_414 = ({1'h0, rtlzz_pipe_373_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(98'(mul_tree_10_413)), .b(162'(mul_tree_10_414)), .cin(1'h0), .value(mul_tree_10_415));
    assign mul_tree_10_416 = ({65'h0, rtlzz_pipe_376_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_417 = ({1'h0, rtlzz_pipe_379_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_418Core rtlzz_owner_418(.a(114'(mul_tree_10_416)), .b(178'(mul_tree_10_417)), .cin(1'h0), .value(mul_tree_10_418));
    assign mul_tree_10_419 = ({65'h0, rtlzz_pipe_382_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_420 = ({1'h0, rtlzz_pipe_385_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_421Core rtlzz_owner_421(.a(130'(mul_tree_10_419)), .b(194'(mul_tree_10_420)), .cin(1'h0), .value(mul_tree_10_421));
    assign mul_tree_10_422 = ({65'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_423 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_424Core rtlzz_owner_424(.a(146'(mul_tree_10_422)), .b(210'(mul_tree_10_423)), .cin(1'h0), .value(mul_tree_10_424));
    assign mul_tree_10_425 = ({65'h0, rtlzz_pipe_394_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_426 = ({1'h0, rtlzz_pipe_397_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427Core rtlzz_owner_427(.a(162'(mul_tree_10_425)), .b(226'(mul_tree_10_426)), .cin(1'h0), .value(mul_tree_10_427));
    assign mul_tree_10_428 = ({65'h0, rtlzz_pipe_400_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_429 = ({1'h0, rtlzz_pipe_403_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(178'(mul_tree_10_428)), .b(242'(mul_tree_10_429)), .cin(1'h0), .value(mul_tree_10_430));
    assign mul_tree_10_431 = ({65'h0, rtlzz_pipe_406_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_432 = ({1'h0, rtlzz_pipe_409_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433Core rtlzz_owner_433(.a(194'(mul_tree_10_431)), .b(258'(mul_tree_10_432)), .cin(1'h0), .value(mul_tree_10_433[255:0]));
    assign mul_tree_10_433[258:256] = '0;
    assign mul_tree_10_434 = ({17'h0, rtlzz_pipe_412_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_435 = ({1'h0, rtlzz_pipe_415_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_437 = ({17'h0, rtlzz_pipe_418_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_438 = ({1'h0, rtlzz_pipe_421_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_440 = ({17'h0, rtlzz_pipe_424_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_441 = ({1'h0, rtlzz_pipe_427_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_443 = ({17'h0, rtlzz_pipe_430_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_444 = ({1'h0, rtlzz_pipe_433_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_446 = ({33'h0, mul_tree_10_436}); // decl: <none>; prim: <none>
    assign mul_tree_10_447 = ({1'h0, mul_tree_10_439}); // decl: <none>; prim: <none>
    assign mul_tree_10_449 = ({33'h0, mul_tree_10_442}); // decl: <none>; prim: <none>
    assign mul_tree_10_450 = ({1'h0, mul_tree_10_445}); // decl: <none>; prim: <none>
    assign mul_tree_10_452 = ({65'h0, mul_tree_10_448}); // decl: <none>; prim: <none>
    assign mul_tree_10_453 = ({1'h0, mul_tree_10_451}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454_reduce rtlzz_reduce_454(.i536(rtlzz_pipe_412_s3), .i537(rtlzz_pipe_415_s3), .i538(rtlzz_pipe_418_s3), .i539(rtlzz_pipe_421_s3), .i540(rtlzz_pipe_424_s3), .i541(rtlzz_pipe_427_s3), .i542(rtlzz_pipe_430_s3), .i543(rtlzz_pipe_433_s3), .y(mul_tree_10_454));
    assign mul_tree_10_455 = mul_tree_10_454[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 32'h0;
            rtlzz_pipe_17_s1 <= 48'h0;
            rtlzz_pipe_21_s1 <= 64'h0;
            rtlzz_pipe_25_s1 <= 80'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 112'h0;
            rtlzz_pipe_37_s1 <= 128'h0;
            rtlzz_pipe_41_s1 <= 144'h0;
            rtlzz_pipe_45_s1 <= 48'h0;
            rtlzz_pipe_49_s1 <= 64'h0;
            rtlzz_pipe_53_s1 <= 80'h0;
            rtlzz_pipe_57_s1 <= 96'h0;
            rtlzz_pipe_61_s1 <= 112'h0;
            rtlzz_pipe_65_s1 <= 128'h0;
            rtlzz_pipe_69_s1 <= 144'h0;
            rtlzz_pipe_73_s1 <= 160'h0;
            rtlzz_pipe_77_s1 <= 64'h0;
            rtlzz_pipe_81_s1 <= 80'h0;
            rtlzz_pipe_85_s1 <= 96'h0;
            rtlzz_pipe_89_s1 <= 112'h0;
            rtlzz_pipe_93_s1 <= 128'h0;
            rtlzz_pipe_97_s1 <= 144'h0;
            rtlzz_pipe_101_s1 <= 160'h0;
            rtlzz_pipe_105_s1 <= 176'h0;
            rtlzz_pipe_109_s1 <= 80'h0;
            rtlzz_pipe_113_s1 <= 96'h0;
            rtlzz_pipe_117_s1 <= 112'h0;
            rtlzz_pipe_121_s1 <= 128'h0;
            rtlzz_pipe_125_s1 <= 144'h0;
            rtlzz_pipe_129_s1 <= 160'h0;
            rtlzz_pipe_133_s1 <= 176'h0;
            rtlzz_pipe_137_s1 <= 192'h0;
            rtlzz_pipe_141_s1 <= 96'h0;
            rtlzz_pipe_145_s1 <= 112'h0;
            rtlzz_pipe_149_s1 <= 128'h0;
            rtlzz_pipe_153_s1 <= 144'h0;
            rtlzz_pipe_157_s1 <= 160'h0;
            rtlzz_pipe_161_s1 <= 176'h0;
            rtlzz_pipe_165_s1 <= 192'h0;
            rtlzz_pipe_169_s1 <= 208'h0;
            rtlzz_pipe_173_s1 <= 112'h0;
            rtlzz_pipe_177_s1 <= 128'h0;
            rtlzz_pipe_181_s1 <= 144'h0;
            rtlzz_pipe_185_s1 <= 160'h0;
            rtlzz_pipe_189_s1 <= 176'h0;
            rtlzz_pipe_193_s1 <= 192'h0;
            rtlzz_pipe_197_s1 <= 208'h0;
            rtlzz_pipe_201_s1 <= 224'h0;
            rtlzz_pipe_205_s1 <= 128'h0;
            rtlzz_pipe_209_s1 <= 144'h0;
            rtlzz_pipe_213_s1 <= 160'h0;
            rtlzz_pipe_217_s1 <= 176'h0;
            rtlzz_pipe_221_s1 <= 192'h0;
            rtlzz_pipe_225_s1 <= 208'h0;
            rtlzz_pipe_229_s1 <= 224'h0;
            rtlzz_pipe_233_s1 <= 240'h0;
            rtlzz_pipe_237_s1 <= 144'h0;
            rtlzz_pipe_241_s1 <= 160'h0;
            rtlzz_pipe_245_s1 <= 176'h0;
            rtlzz_pipe_249_s1 <= 192'h0;
            rtlzz_pipe_253_s1 <= 208'h0;
            rtlzz_pipe_257_s1 <= 224'h0;
            rtlzz_pipe_261_s1 <= 240'h0;
            rtlzz_pipe_265_s1 <= 256'h0;
            rtlzz_pipe_364_s2 <= 82'h0;
            rtlzz_pipe_367_s2 <= 146'h0;
            rtlzz_pipe_370_s2 <= 98'h0;
            rtlzz_pipe_373_s2 <= 162'h0;
            rtlzz_pipe_376_s2 <= 114'h0;
            rtlzz_pipe_379_s2 <= 178'h0;
            rtlzz_pipe_382_s2 <= 130'h0;
            rtlzz_pipe_385_s2 <= 194'h0;
            rtlzz_pipe_388_s2 <= 146'h0;
            rtlzz_pipe_391_s2 <= 210'h0;
            rtlzz_pipe_394_s2 <= 162'h0;
            rtlzz_pipe_397_s2 <= 226'h0;
            rtlzz_pipe_400_s2 <= 178'h0;
            rtlzz_pipe_403_s2 <= 242'h0;
            rtlzz_pipe_406_s2 <= 194'h0;
            rtlzz_pipe_409_s2 <= 258'h0;
            rtlzz_pipe_412_s3 <= 147'h0;
            rtlzz_pipe_415_s3 <= 163'h0;
            rtlzz_pipe_418_s3 <= 179'h0;
            rtlzz_pipe_421_s3 <= 195'h0;
            rtlzz_pipe_424_s3 <= 211'h0;
            rtlzz_pipe_427_s3 <= 227'h0;
            rtlzz_pipe_430_s3 <= 243'h0;
            rtlzz_pipe_433_s3 <= 259'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= mul_tree_10_77; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_81_s1 <= mul_tree_10_81; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= mul_tree_10_89; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_93_s1 <= mul_tree_10_93; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_tree_10_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_10_105; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_tree_10_113; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_tree_10_117; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_tree_10_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_tree_10_125; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_tree_10_129; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_133_s1 <= mul_tree_10_133; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_137_s1 <= mul_tree_10_137; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_141_s1 <= mul_tree_10_141; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_145_s1 <= mul_tree_10_145; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_149_s1 <= mul_tree_10_149; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_153_s1 <= mul_tree_10_153; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_157_s1 <= mul_tree_10_157; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_161_s1 <= mul_tree_10_161; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_165_s1 <= mul_tree_10_165; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_169_s1 <= mul_tree_10_169; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_173_s1 <= mul_tree_10_173; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_177_s1 <= mul_tree_10_177; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_181_s1 <= mul_tree_10_181; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_185_s1 <= mul_tree_10_185; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_189_s1 <= mul_tree_10_189; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_193_s1 <= mul_tree_10_193; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_197_s1 <= mul_tree_10_197; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_201_s1 <= mul_tree_10_201; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_205_s1 <= mul_tree_10_205; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_209_s1 <= mul_tree_10_209; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_213_s1 <= mul_tree_10_213; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_217_s1 <= mul_tree_10_217; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_221_s1 <= mul_tree_10_221; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_225_s1 <= mul_tree_10_225; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_229_s1 <= mul_tree_10_229; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_233_s1 <= mul_tree_10_233; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_237_s1 <= mul_tree_10_237; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_241_s1 <= mul_tree_10_241; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_245_s1 <= mul_tree_10_245; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= mul_tree_10_249; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_253_s1 <= mul_tree_10_253; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_257_s1 <= mul_tree_10_257; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_261_s1 <= mul_tree_10_261; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= mul_tree_10_265; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_364_s2 <= mul_tree_10_364; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_367_s2 <= mul_tree_10_367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_370_s2 <= mul_tree_10_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_373_s2 <= mul_tree_10_373; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_376_s2 <= mul_tree_10_376; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_379_s2 <= mul_tree_10_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_382_s2 <= mul_tree_10_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_385_s2 <= mul_tree_10_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_10_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_10_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_394_s2 <= mul_tree_10_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_397_s2 <= mul_tree_10_397; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_400_s2 <= mul_tree_10_400; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_403_s2 <= mul_tree_10_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_406_s2 <= mul_tree_10_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_409_s2 <= mul_tree_10_409; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_412_s3 <= mul_tree_10_412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_415_s3 <= mul_tree_10_415; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_418_s3 <= mul_tree_10_418; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_421_s3 <= mul_tree_10_421; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_424_s3 <= mul_tree_10_424; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_427_s3 <= mul_tree_10_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_430_s3 <= mul_tree_10_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_433_s3 <= mul_tree_10_433; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364_reduce(input wire [31:0] i456, input wire [47:0] i457, input wire [63:0] i458, input wire [79:0] i459, output wire [81:0] y);
wire [81:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i456[31], i456[30], i456[29], i456[28], i456[27], i456[26], i456[25], i456[24], i456[23], i456[22], i456[21], i456[20], i456[19], i456[18], i456[17], i456[16], i456[15], i456[14], i456[13], i456[12], i456[11], i456[10], i456[9], i456[8], i456[7], i456[6], i456[5], i456[4], i456[3], i456[2], i456[1], i456[0]};
wire [81:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i457[47], i457[46], i457[45], i457[44], i457[43], i457[42], i457[41], i457[40], i457[39], i457[38], i457[37], i457[36], i457[35], i457[34], i457[33], i457[32], i457[31], i457[30], i457[29], i457[28], i457[27], i457[26], i457[25], i457[24], i457[23], i457[22], i457[21], i457[20], i457[19], i457[18], i457[17], i457[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i458[63], i458[62], i458[61], i458[60], i458[59], i458[58], i458[57], i458[56], i458[55], i458[54], i458[53], i458[52], i458[51], i458[50], i458[49], i458[48], i458[47], i458[46], i458[45], i458[44], i458[43], i458[42], i458[41], i458[40], i458[39], i458[38], i458[37], i458[36], i458[35], i458[34], i458[33], i458[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] t3 = {1'b0, 1'b0, i459[79], i459[78], i459[77], i459[76], i459[75], i459[74], i459[73], i459[72], i459[71], i459[70], i459[69], i459[68], i459[67], i459[66], i459[65], i459[64], i459[63], i459[62], i459[61], i459[60], i459[59], i459[58], i459[57], i459[56], i459[55], i459[54], i459[53], i459[52], i459[51], i459[50], i459[49], i459[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [81:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367_reduce(input wire [95:0] i460, input wire [111:0] i461, input wire [127:0] i462, input wire [143:0] i463, output wire [145:0] y);
wire [145:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i460[95], i460[94], i460[93], i460[92], i460[91], i460[90], i460[89], i460[88], i460[87], i460[86], i460[85], i460[84], i460[83], i460[82], i460[81], i460[80], i460[79], i460[78], i460[77], i460[76], i460[75], i460[74], i460[73], i460[72], i460[71], i460[70], i460[69], i460[68], i460[67], i460[66], i460[65], i460[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i461[111], i461[110], i461[109], i461[108], i461[107], i461[106], i461[105], i461[104], i461[103], i461[102], i461[101], i461[100], i461[99], i461[98], i461[97], i461[96], i461[95], i461[94], i461[93], i461[92], i461[91], i461[90], i461[89], i461[88], i461[87], i461[86], i461[85], i461[84], i461[83], i461[82], i461[81], i461[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i462[127], i462[126], i462[125], i462[124], i462[123], i462[122], i462[121], i462[120], i462[119], i462[118], i462[117], i462[116], i462[115], i462[114], i462[113], i462[112], i462[111], i462[110], i462[109], i462[108], i462[107], i462[106], i462[105], i462[104], i462[103], i462[102], i462[101], i462[100], i462[99], i462[98], i462[97], i462[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t3 = {1'b0, 1'b0, i463[143], i463[142], i463[141], i463[140], i463[139], i463[138], i463[137], i463[136], i463[135], i463[134], i463[133], i463[132], i463[131], i463[130], i463[129], i463[128], i463[127], i463[126], i463[125], i463[124], i463[123], i463[122], i463[121], i463[120], i463[119], i463[118], i463[117], i463[116], i463[115], i463[114], i463[113], i463[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_370_reduce(input wire [47:0] i464, input wire [63:0] i465, input wire [79:0] i466, input wire [95:0] i467, output wire [97:0] y);
wire [97:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i464[47], i464[46], i464[45], i464[44], i464[43], i464[42], i464[41], i464[40], i464[39], i464[38], i464[37], i464[36], i464[35], i464[34], i464[33], i464[32], i464[31], i464[30], i464[29], i464[28], i464[27], i464[26], i464[25], i464[24], i464[23], i464[22], i464[21], i464[20], i464[19], i464[18], i464[17], i464[16], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i465[63], i465[62], i465[61], i465[60], i465[59], i465[58], i465[57], i465[56], i465[55], i465[54], i465[53], i465[52], i465[51], i465[50], i465[49], i465[48], i465[47], i465[46], i465[45], i465[44], i465[43], i465[42], i465[41], i465[40], i465[39], i465[38], i465[37], i465[36], i465[35], i465[34], i465[33], i465[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i466[79], i466[78], i466[77], i466[76], i466[75], i466[74], i466[73], i466[72], i466[71], i466[70], i466[69], i466[68], i466[67], i466[66], i466[65], i466[64], i466[63], i466[62], i466[61], i466[60], i466[59], i466[58], i466[57], i466[56], i466[55], i466[54], i466[53], i466[52], i466[51], i466[50], i466[49], i466[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] t3 = {1'b0, 1'b0, i467[95], i467[94], i467[93], i467[92], i467[91], i467[90], i467[89], i467[88], i467[87], i467[86], i467[85], i467[84], i467[83], i467[82], i467[81], i467[80], i467[79], i467[78], i467[77], i467[76], i467[75], i467[74], i467[73], i467[72], i467[71], i467[70], i467[69], i467[68], i467[67], i467[66], i467[65], i467[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [97:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373_reduce(input wire [111:0] i468, input wire [127:0] i469, input wire [143:0] i470, input wire [159:0] i471, output wire [161:0] y);
wire [161:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i468[111], i468[110], i468[109], i468[108], i468[107], i468[106], i468[105], i468[104], i468[103], i468[102], i468[101], i468[100], i468[99], i468[98], i468[97], i468[96], i468[95], i468[94], i468[93], i468[92], i468[91], i468[90], i468[89], i468[88], i468[87], i468[86], i468[85], i468[84], i468[83], i468[82], i468[81], i468[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i469[127], i469[126], i469[125], i469[124], i469[123], i469[122], i469[121], i469[120], i469[119], i469[118], i469[117], i469[116], i469[115], i469[114], i469[113], i469[112], i469[111], i469[110], i469[109], i469[108], i469[107], i469[106], i469[105], i469[104], i469[103], i469[102], i469[101], i469[100], i469[99], i469[98], i469[97], i469[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i470[143], i470[142], i470[141], i470[140], i470[139], i470[138], i470[137], i470[136], i470[135], i470[134], i470[133], i470[132], i470[131], i470[130], i470[129], i470[128], i470[127], i470[126], i470[125], i470[124], i470[123], i470[122], i470[121], i470[120], i470[119], i470[118], i470[117], i470[116], i470[115], i470[114], i470[113], i470[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t3 = {1'b0, 1'b0, i471[159], i471[158], i471[157], i471[156], i471[155], i471[154], i471[153], i471[152], i471[151], i471[150], i471[149], i471[148], i471[147], i471[146], i471[145], i471[144], i471[143], i471[142], i471[141], i471[140], i471[139], i471[138], i471[137], i471[136], i471[135], i471[134], i471[133], i471[132], i471[131], i471[130], i471[129], i471[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376_reduce(input wire [63:0] i472, input wire [79:0] i473, input wire [95:0] i474, input wire [111:0] i475, output wire [113:0] y);
wire [113:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i472[63], i472[62], i472[61], i472[60], i472[59], i472[58], i472[57], i472[56], i472[55], i472[54], i472[53], i472[52], i472[51], i472[50], i472[49], i472[48], i472[47], i472[46], i472[45], i472[44], i472[43], i472[42], i472[41], i472[40], i472[39], i472[38], i472[37], i472[36], i472[35], i472[34], i472[33], i472[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i473[79], i473[78], i473[77], i473[76], i473[75], i473[74], i473[73], i473[72], i473[71], i473[70], i473[69], i473[68], i473[67], i473[66], i473[65], i473[64], i473[63], i473[62], i473[61], i473[60], i473[59], i473[58], i473[57], i473[56], i473[55], i473[54], i473[53], i473[52], i473[51], i473[50], i473[49], i473[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i474[95], i474[94], i474[93], i474[92], i474[91], i474[90], i474[89], i474[88], i474[87], i474[86], i474[85], i474[84], i474[83], i474[82], i474[81], i474[80], i474[79], i474[78], i474[77], i474[76], i474[75], i474[74], i474[73], i474[72], i474[71], i474[70], i474[69], i474[68], i474[67], i474[66], i474[65], i474[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] t3 = {1'b0, 1'b0, i475[111], i475[110], i475[109], i475[108], i475[107], i475[106], i475[105], i475[104], i475[103], i475[102], i475[101], i475[100], i475[99], i475[98], i475[97], i475[96], i475[95], i475[94], i475[93], i475[92], i475[91], i475[90], i475[89], i475[88], i475[87], i475[86], i475[85], i475[84], i475[83], i475[82], i475[81], i475[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [113:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_379_reduce(input wire [127:0] i476, input wire [143:0] i477, input wire [159:0] i478, input wire [175:0] i479, output wire [177:0] y);
wire [177:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i476[127], i476[126], i476[125], i476[124], i476[123], i476[122], i476[121], i476[120], i476[119], i476[118], i476[117], i476[116], i476[115], i476[114], i476[113], i476[112], i476[111], i476[110], i476[109], i476[108], i476[107], i476[106], i476[105], i476[104], i476[103], i476[102], i476[101], i476[100], i476[99], i476[98], i476[97], i476[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i477[143], i477[142], i477[141], i477[140], i477[139], i477[138], i477[137], i477[136], i477[135], i477[134], i477[133], i477[132], i477[131], i477[130], i477[129], i477[128], i477[127], i477[126], i477[125], i477[124], i477[123], i477[122], i477[121], i477[120], i477[119], i477[118], i477[117], i477[116], i477[115], i477[114], i477[113], i477[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i478[159], i478[158], i478[157], i478[156], i478[155], i478[154], i478[153], i478[152], i478[151], i478[150], i478[149], i478[148], i478[147], i478[146], i478[145], i478[144], i478[143], i478[142], i478[141], i478[140], i478[139], i478[138], i478[137], i478[136], i478[135], i478[134], i478[133], i478[132], i478[131], i478[130], i478[129], i478[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t3 = {1'b0, 1'b0, i479[175], i479[174], i479[173], i479[172], i479[171], i479[170], i479[169], i479[168], i479[167], i479[166], i479[165], i479[164], i479[163], i479[162], i479[161], i479[160], i479[159], i479[158], i479[157], i479[156], i479[155], i479[154], i479[153], i479[152], i479[151], i479[150], i479[149], i479[148], i479[147], i479[146], i479[145], i479[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382_reduce(input wire [79:0] i480, input wire [95:0] i481, input wire [111:0] i482, input wire [127:0] i483, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i480[79], i480[78], i480[77], i480[76], i480[75], i480[74], i480[73], i480[72], i480[71], i480[70], i480[69], i480[68], i480[67], i480[66], i480[65], i480[64], i480[63], i480[62], i480[61], i480[60], i480[59], i480[58], i480[57], i480[56], i480[55], i480[54], i480[53], i480[52], i480[51], i480[50], i480[49], i480[48], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i481[95], i481[94], i481[93], i481[92], i481[91], i481[90], i481[89], i481[88], i481[87], i481[86], i481[85], i481[84], i481[83], i481[82], i481[81], i481[80], i481[79], i481[78], i481[77], i481[76], i481[75], i481[74], i481[73], i481[72], i481[71], i481[70], i481[69], i481[68], i481[67], i481[66], i481[65], i481[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i482[111], i482[110], i482[109], i482[108], i482[107], i482[106], i482[105], i482[104], i482[103], i482[102], i482[101], i482[100], i482[99], i482[98], i482[97], i482[96], i482[95], i482[94], i482[93], i482[92], i482[91], i482[90], i482[89], i482[88], i482[87], i482[86], i482[85], i482[84], i482[83], i482[82], i482[81], i482[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] t3 = {1'b0, 1'b0, i483[127], i483[126], i483[125], i483[124], i483[123], i483[122], i483[121], i483[120], i483[119], i483[118], i483[117], i483[116], i483[115], i483[114], i483[113], i483[112], i483[111], i483[110], i483[109], i483[108], i483[107], i483[106], i483[105], i483[104], i483[103], i483[102], i483[101], i483[100], i483[99], i483[98], i483[97], i483[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [129:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385_reduce(input wire [143:0] i484, input wire [159:0] i485, input wire [175:0] i486, input wire [191:0] i487, output wire [193:0] y);
wire [193:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i484[143], i484[142], i484[141], i484[140], i484[139], i484[138], i484[137], i484[136], i484[135], i484[134], i484[133], i484[132], i484[131], i484[130], i484[129], i484[128], i484[127], i484[126], i484[125], i484[124], i484[123], i484[122], i484[121], i484[120], i484[119], i484[118], i484[117], i484[116], i484[115], i484[114], i484[113], i484[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i485[159], i485[158], i485[157], i485[156], i485[155], i485[154], i485[153], i485[152], i485[151], i485[150], i485[149], i485[148], i485[147], i485[146], i485[145], i485[144], i485[143], i485[142], i485[141], i485[140], i485[139], i485[138], i485[137], i485[136], i485[135], i485[134], i485[133], i485[132], i485[131], i485[130], i485[129], i485[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i486[175], i486[174], i486[173], i486[172], i486[171], i486[170], i486[169], i486[168], i486[167], i486[166], i486[165], i486[164], i486[163], i486[162], i486[161], i486[160], i486[159], i486[158], i486[157], i486[156], i486[155], i486[154], i486[153], i486[152], i486[151], i486[150], i486[149], i486[148], i486[147], i486[146], i486[145], i486[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t3 = {1'b0, 1'b0, i487[191], i487[190], i487[189], i487[188], i487[187], i487[186], i487[185], i487[184], i487[183], i487[182], i487[181], i487[180], i487[179], i487[178], i487[177], i487[176], i487[175], i487[174], i487[173], i487[172], i487[171], i487[170], i487[169], i487[168], i487[167], i487[166], i487[165], i487[164], i487[163], i487[162], i487[161], i487[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388_reduce(input wire [95:0] i488, input wire [111:0] i489, input wire [127:0] i490, input wire [143:0] i491, output wire [145:0] y);
wire [145:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i488[95], i488[94], i488[93], i488[92], i488[91], i488[90], i488[89], i488[88], i488[87], i488[86], i488[85], i488[84], i488[83], i488[82], i488[81], i488[80], i488[79], i488[78], i488[77], i488[76], i488[75], i488[74], i488[73], i488[72], i488[71], i488[70], i488[69], i488[68], i488[67], i488[66], i488[65], i488[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i489[111], i489[110], i489[109], i489[108], i489[107], i489[106], i489[105], i489[104], i489[103], i489[102], i489[101], i489[100], i489[99], i489[98], i489[97], i489[96], i489[95], i489[94], i489[93], i489[92], i489[91], i489[90], i489[89], i489[88], i489[87], i489[86], i489[85], i489[84], i489[83], i489[82], i489[81], i489[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[127], i490[126], i490[125], i490[124], i490[123], i490[122], i490[121], i490[120], i490[119], i490[118], i490[117], i490[116], i490[115], i490[114], i490[113], i490[112], i490[111], i490[110], i490[109], i490[108], i490[107], i490[106], i490[105], i490[104], i490[103], i490[102], i490[101], i490[100], i490[99], i490[98], i490[97], i490[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] t3 = {1'b0, 1'b0, i491[143], i491[142], i491[141], i491[140], i491[139], i491[138], i491[137], i491[136], i491[135], i491[134], i491[133], i491[132], i491[131], i491[130], i491[129], i491[128], i491[127], i491[126], i491[125], i491[124], i491[123], i491[122], i491[121], i491[120], i491[119], i491[118], i491[117], i491[116], i491[115], i491[114], i491[113], i491[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [145:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391_reduce(input wire [159:0] i492, input wire [175:0] i493, input wire [191:0] i494, input wire [207:0] i495, output wire [209:0] y);
wire [209:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i492[159], i492[158], i492[157], i492[156], i492[155], i492[154], i492[153], i492[152], i492[151], i492[150], i492[149], i492[148], i492[147], i492[146], i492[145], i492[144], i492[143], i492[142], i492[141], i492[140], i492[139], i492[138], i492[137], i492[136], i492[135], i492[134], i492[133], i492[132], i492[131], i492[130], i492[129], i492[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[175], i493[174], i493[173], i493[172], i493[171], i493[170], i493[169], i493[168], i493[167], i493[166], i493[165], i493[164], i493[163], i493[162], i493[161], i493[160], i493[159], i493[158], i493[157], i493[156], i493[155], i493[154], i493[153], i493[152], i493[151], i493[150], i493[149], i493[148], i493[147], i493[146], i493[145], i493[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i494[191], i494[190], i494[189], i494[188], i494[187], i494[186], i494[185], i494[184], i494[183], i494[182], i494[181], i494[180], i494[179], i494[178], i494[177], i494[176], i494[175], i494[174], i494[173], i494[172], i494[171], i494[170], i494[169], i494[168], i494[167], i494[166], i494[165], i494[164], i494[163], i494[162], i494[161], i494[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] t3 = {1'b0, 1'b0, i495[207], i495[206], i495[205], i495[204], i495[203], i495[202], i495[201], i495[200], i495[199], i495[198], i495[197], i495[196], i495[195], i495[194], i495[193], i495[192], i495[191], i495[190], i495[189], i495[188], i495[187], i495[186], i495[185], i495[184], i495[183], i495[182], i495[181], i495[180], i495[179], i495[178], i495[177], i495[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [209:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394_reduce(input wire [111:0] i496, input wire [127:0] i497, input wire [143:0] i498, input wire [159:0] i499, output wire [161:0] y);
wire [161:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i496[111], i496[110], i496[109], i496[108], i496[107], i496[106], i496[105], i496[104], i496[103], i496[102], i496[101], i496[100], i496[99], i496[98], i496[97], i496[96], i496[95], i496[94], i496[93], i496[92], i496[91], i496[90], i496[89], i496[88], i496[87], i496[86], i496[85], i496[84], i496[83], i496[82], i496[81], i496[80], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[127], i497[126], i497[125], i497[124], i497[123], i497[122], i497[121], i497[120], i497[119], i497[118], i497[117], i497[116], i497[115], i497[114], i497[113], i497[112], i497[111], i497[110], i497[109], i497[108], i497[107], i497[106], i497[105], i497[104], i497[103], i497[102], i497[101], i497[100], i497[99], i497[98], i497[97], i497[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i498[143], i498[142], i498[141], i498[140], i498[139], i498[138], i498[137], i498[136], i498[135], i498[134], i498[133], i498[132], i498[131], i498[130], i498[129], i498[128], i498[127], i498[126], i498[125], i498[124], i498[123], i498[122], i498[121], i498[120], i498[119], i498[118], i498[117], i498[116], i498[115], i498[114], i498[113], i498[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] t3 = {1'b0, 1'b0, i499[159], i499[158], i499[157], i499[156], i499[155], i499[154], i499[153], i499[152], i499[151], i499[150], i499[149], i499[148], i499[147], i499[146], i499[145], i499[144], i499[143], i499[142], i499[141], i499[140], i499[139], i499[138], i499[137], i499[136], i499[135], i499[134], i499[133], i499[132], i499[131], i499[130], i499[129], i499[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [161:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397_reduce(input wire [175:0] i500, input wire [191:0] i501, input wire [207:0] i502, input wire [223:0] i503, output wire [225:0] y);
wire [225:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i500[175], i500[174], i500[173], i500[172], i500[171], i500[170], i500[169], i500[168], i500[167], i500[166], i500[165], i500[164], i500[163], i500[162], i500[161], i500[160], i500[159], i500[158], i500[157], i500[156], i500[155], i500[154], i500[153], i500[152], i500[151], i500[150], i500[149], i500[148], i500[147], i500[146], i500[145], i500[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i501[191], i501[190], i501[189], i501[188], i501[187], i501[186], i501[185], i501[184], i501[183], i501[182], i501[181], i501[180], i501[179], i501[178], i501[177], i501[176], i501[175], i501[174], i501[173], i501[172], i501[171], i501[170], i501[169], i501[168], i501[167], i501[166], i501[165], i501[164], i501[163], i501[162], i501[161], i501[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i502[207], i502[206], i502[205], i502[204], i502[203], i502[202], i502[201], i502[200], i502[199], i502[198], i502[197], i502[196], i502[195], i502[194], i502[193], i502[192], i502[191], i502[190], i502[189], i502[188], i502[187], i502[186], i502[185], i502[184], i502[183], i502[182], i502[181], i502[180], i502[179], i502[178], i502[177], i502[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] t3 = {1'b0, 1'b0, i503[223], i503[222], i503[221], i503[220], i503[219], i503[218], i503[217], i503[216], i503[215], i503[214], i503[213], i503[212], i503[211], i503[210], i503[209], i503[208], i503[207], i503[206], i503[205], i503[204], i503[203], i503[202], i503[201], i503[200], i503[199], i503[198], i503[197], i503[196], i503[195], i503[194], i503[193], i503[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [225:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_400_reduce(input wire [127:0] i504, input wire [143:0] i505, input wire [159:0] i506, input wire [175:0] i507, output wire [177:0] y);
wire [177:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i504[127], i504[126], i504[125], i504[124], i504[123], i504[122], i504[121], i504[120], i504[119], i504[118], i504[117], i504[116], i504[115], i504[114], i504[113], i504[112], i504[111], i504[110], i504[109], i504[108], i504[107], i504[106], i504[105], i504[104], i504[103], i504[102], i504[101], i504[100], i504[99], i504[98], i504[97], i504[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i505[143], i505[142], i505[141], i505[140], i505[139], i505[138], i505[137], i505[136], i505[135], i505[134], i505[133], i505[132], i505[131], i505[130], i505[129], i505[128], i505[127], i505[126], i505[125], i505[124], i505[123], i505[122], i505[121], i505[120], i505[119], i505[118], i505[117], i505[116], i505[115], i505[114], i505[113], i505[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i506[159], i506[158], i506[157], i506[156], i506[155], i506[154], i506[153], i506[152], i506[151], i506[150], i506[149], i506[148], i506[147], i506[146], i506[145], i506[144], i506[143], i506[142], i506[141], i506[140], i506[139], i506[138], i506[137], i506[136], i506[135], i506[134], i506[133], i506[132], i506[131], i506[130], i506[129], i506[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] t3 = {1'b0, 1'b0, i507[175], i507[174], i507[173], i507[172], i507[171], i507[170], i507[169], i507[168], i507[167], i507[166], i507[165], i507[164], i507[163], i507[162], i507[161], i507[160], i507[159], i507[158], i507[157], i507[156], i507[155], i507[154], i507[153], i507[152], i507[151], i507[150], i507[149], i507[148], i507[147], i507[146], i507[145], i507[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [177:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_403_reduce(input wire [191:0] i508, input wire [207:0] i509, input wire [223:0] i510, input wire [239:0] i511, output wire [241:0] y);
wire [241:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i508[191], i508[190], i508[189], i508[188], i508[187], i508[186], i508[185], i508[184], i508[183], i508[182], i508[181], i508[180], i508[179], i508[178], i508[177], i508[176], i508[175], i508[174], i508[173], i508[172], i508[171], i508[170], i508[169], i508[168], i508[167], i508[166], i508[165], i508[164], i508[163], i508[162], i508[161], i508[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i509[207], i509[206], i509[205], i509[204], i509[203], i509[202], i509[201], i509[200], i509[199], i509[198], i509[197], i509[196], i509[195], i509[194], i509[193], i509[192], i509[191], i509[190], i509[189], i509[188], i509[187], i509[186], i509[185], i509[184], i509[183], i509[182], i509[181], i509[180], i509[179], i509[178], i509[177], i509[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i510[223], i510[222], i510[221], i510[220], i510[219], i510[218], i510[217], i510[216], i510[215], i510[214], i510[213], i510[212], i510[211], i510[210], i510[209], i510[208], i510[207], i510[206], i510[205], i510[204], i510[203], i510[202], i510[201], i510[200], i510[199], i510[198], i510[197], i510[196], i510[195], i510[194], i510[193], i510[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] t3 = {1'b0, 1'b0, i511[239], i511[238], i511[237], i511[236], i511[235], i511[234], i511[233], i511[232], i511[231], i511[230], i511[229], i511[228], i511[227], i511[226], i511[225], i511[224], i511[223], i511[222], i511[221], i511[220], i511[219], i511[218], i511[217], i511[216], i511[215], i511[214], i511[213], i511[212], i511[211], i511[210], i511[209], i511[208], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [241:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_406_reduce(input wire [143:0] i512, input wire [159:0] i513, input wire [175:0] i514, input wire [191:0] i515, output wire [193:0] y);
wire [193:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i512[143], i512[142], i512[141], i512[140], i512[139], i512[138], i512[137], i512[136], i512[135], i512[134], i512[133], i512[132], i512[131], i512[130], i512[129], i512[128], i512[127], i512[126], i512[125], i512[124], i512[123], i512[122], i512[121], i512[120], i512[119], i512[118], i512[117], i512[116], i512[115], i512[114], i512[113], i512[112], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i513[159], i513[158], i513[157], i513[156], i513[155], i513[154], i513[153], i513[152], i513[151], i513[150], i513[149], i513[148], i513[147], i513[146], i513[145], i513[144], i513[143], i513[142], i513[141], i513[140], i513[139], i513[138], i513[137], i513[136], i513[135], i513[134], i513[133], i513[132], i513[131], i513[130], i513[129], i513[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i514[175], i514[174], i514[173], i514[172], i514[171], i514[170], i514[169], i514[168], i514[167], i514[166], i514[165], i514[164], i514[163], i514[162], i514[161], i514[160], i514[159], i514[158], i514[157], i514[156], i514[155], i514[154], i514[153], i514[152], i514[151], i514[150], i514[149], i514[148], i514[147], i514[146], i514[145], i514[144], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] t3 = {1'b0, 1'b0, i515[191], i515[190], i515[189], i515[188], i515[187], i515[186], i515[185], i515[184], i515[183], i515[182], i515[181], i515[180], i515[179], i515[178], i515[177], i515[176], i515[175], i515[174], i515[173], i515[172], i515[171], i515[170], i515[169], i515[168], i515[167], i515[166], i515[165], i515[164], i515[163], i515[162], i515[161], i515[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [193:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409_reduce(input wire [207:0] i516, input wire [223:0] i517, input wire [239:0] i518, input wire [255:0] i519, output wire [257:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i516[207], i516[206], i516[205], i516[204], i516[203], i516[202], i516[201], i516[200], i516[199], i516[198], i516[197], i516[196], i516[195], i516[194], i516[193], i516[192], i516[191], i516[190], i516[189], i516[188], i516[187], i516[186], i516[185], i516[184], i516[183], i516[182], i516[181], i516[180], i516[179], i516[178], i516[177], i516[176], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i517[223], i517[222], i517[221], i517[220], i517[219], i517[218], i517[217], i517[216], i517[215], i517[214], i517[213], i517[212], i517[211], i517[210], i517[209], i517[208], i517[207], i517[206], i517[205], i517[204], i517[203], i517[202], i517[201], i517[200], i517[199], i517[198], i517[197], i517[196], i517[195], i517[194], i517[193], i517[192], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i518[239], i518[238], i518[237], i518[236], i518[235], i518[234], i518[233], i518[232], i518[231], i518[230], i518[229], i518[228], i518[227], i518[226], i518[225], i518[224], i518[223], i518[222], i518[221], i518[220], i518[219], i518[218], i518[217], i518[216], i518[215], i518[214], i518[213], i518[212], i518[211], i518[210], i518[209], i518[208], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t3 = {i519[255], i519[254], i519[253], i519[252], i519[251], i519[250], i519[249], i519[248], i519[247], i519[246], i519[245], i519[244], i519[243], i519[242], i519[241], i519[240], i519[239], i519[238], i519[237], i519[236], i519[235], i519[234], i519[233], i519[232], i519[231], i519[230], i519[229], i519[228], i519[227], i519[226], i519[225], i519[224], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454_reduce(input wire [146:0] i536, input wire [162:0] i537, input wire [178:0] i538, input wire [194:0] i539, input wire [210:0] i540, input wire [226:0] i541, input wire [242:0] i542, input wire [258:0] i543, output wire [261:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i536[146], i536[145], i536[144], i536[143], i536[142], i536[141], i536[140], i536[139], i536[138], i536[137], i536[136], i536[135], i536[134], i536[133], i536[132], i536[131], i536[130], i536[129], i536[128], i536[127], i536[126], i536[125], i536[124], i536[123], i536[122], i536[121], i536[120], i536[119], i536[118], i536[117], i536[116], i536[115], i536[114], i536[113], i536[112], i536[111], i536[110], i536[109], i536[108], i536[107], i536[106], i536[105], i536[104], i536[103], i536[102], i536[101], i536[100], i536[99], i536[98], i536[97], i536[96], i536[95], i536[94], i536[93], i536[92], i536[91], i536[90], i536[89], i536[88], i536[87], i536[86], i536[85], i536[84], i536[83], i536[82], i536[81], i536[80], i536[79], i536[78], i536[77], i536[76], i536[75], i536[74], i536[73], i536[72], i536[71], i536[70], i536[69], i536[68], i536[67], i536[66], i536[65], i536[64], i536[63], i536[62], i536[61], i536[60], i536[59], i536[58], i536[57], i536[56], i536[55], i536[54], i536[53], i536[52], i536[51], i536[50], i536[49], i536[48], i536[47], i536[46], i536[45], i536[44], i536[43], i536[42], i536[41], i536[40], i536[39], i536[38], i536[37], i536[36], i536[35], i536[34], i536[33], i536[32], i536[31], i536[30], i536[29], i536[28], i536[27], i536[26], i536[25], i536[24], i536[23], i536[22], i536[21], i536[20], i536[19], i536[18], i536[17], i536[16], i536[15], i536[14], i536[13], i536[12], i536[11], i536[10], i536[9], i536[8], i536[7], i536[6], i536[5], i536[4], i536[3], i536[2], i536[1], i536[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i537[162], i537[161], i537[160], i537[159], i537[158], i537[157], i537[156], i537[155], i537[154], i537[153], i537[152], i537[151], i537[150], i537[149], i537[148], i537[147], i537[146], i537[145], i537[144], i537[143], i537[142], i537[141], i537[140], i537[139], i537[138], i537[137], i537[136], i537[135], i537[134], i537[133], i537[132], i537[131], i537[130], i537[129], i537[128], i537[127], i537[126], i537[125], i537[124], i537[123], i537[122], i537[121], i537[120], i537[119], i537[118], i537[117], i537[116], i537[115], i537[114], i537[113], i537[112], i537[111], i537[110], i537[109], i537[108], i537[107], i537[106], i537[105], i537[104], i537[103], i537[102], i537[101], i537[100], i537[99], i537[98], i537[97], i537[96], i537[95], i537[94], i537[93], i537[92], i537[91], i537[90], i537[89], i537[88], i537[87], i537[86], i537[85], i537[84], i537[83], i537[82], i537[81], i537[80], i537[79], i537[78], i537[77], i537[76], i537[75], i537[74], i537[73], i537[72], i537[71], i537[70], i537[69], i537[68], i537[67], i537[66], i537[65], i537[64], i537[63], i537[62], i537[61], i537[60], i537[59], i537[58], i537[57], i537[56], i537[55], i537[54], i537[53], i537[52], i537[51], i537[50], i537[49], i537[48], i537[47], i537[46], i537[45], i537[44], i537[43], i537[42], i537[41], i537[40], i537[39], i537[38], i537[37], i537[36], i537[35], i537[34], i537[33], i537[32], i537[31], i537[30], i537[29], i537[28], i537[27], i537[26], i537[25], i537[24], i537[23], i537[22], i537[21], i537[20], i537[19], i537[18], i537[17], i537[16], i537[15], i537[14], i537[13], i537[12], i537[11], i537[10], i537[9], i537[8], i537[7], i537[6], i537[5], i537[4], i537[3], i537[2], i537[1], i537[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i538[178], i538[177], i538[176], i538[175], i538[174], i538[173], i538[172], i538[171], i538[170], i538[169], i538[168], i538[167], i538[166], i538[165], i538[164], i538[163], i538[162], i538[161], i538[160], i538[159], i538[158], i538[157], i538[156], i538[155], i538[154], i538[153], i538[152], i538[151], i538[150], i538[149], i538[148], i538[147], i538[146], i538[145], i538[144], i538[143], i538[142], i538[141], i538[140], i538[139], i538[138], i538[137], i538[136], i538[135], i538[134], i538[133], i538[132], i538[131], i538[130], i538[129], i538[128], i538[127], i538[126], i538[125], i538[124], i538[123], i538[122], i538[121], i538[120], i538[119], i538[118], i538[117], i538[116], i538[115], i538[114], i538[113], i538[112], i538[111], i538[110], i538[109], i538[108], i538[107], i538[106], i538[105], i538[104], i538[103], i538[102], i538[101], i538[100], i538[99], i538[98], i538[97], i538[96], i538[95], i538[94], i538[93], i538[92], i538[91], i538[90], i538[89], i538[88], i538[87], i538[86], i538[85], i538[84], i538[83], i538[82], i538[81], i538[80], i538[79], i538[78], i538[77], i538[76], i538[75], i538[74], i538[73], i538[72], i538[71], i538[70], i538[69], i538[68], i538[67], i538[66], i538[65], i538[64], i538[63], i538[62], i538[61], i538[60], i538[59], i538[58], i538[57], i538[56], i538[55], i538[54], i538[53], i538[52], i538[51], i538[50], i538[49], i538[48], i538[47], i538[46], i538[45], i538[44], i538[43], i538[42], i538[41], i538[40], i538[39], i538[38], i538[37], i538[36], i538[35], i538[34], i538[33], i538[32], i538[31], i538[30], i538[29], i538[28], i538[27], i538[26], i538[25], i538[24], i538[23], i538[22], i538[21], i538[20], i538[19], i538[18], i538[17], i538[16], i538[15], i538[14], i538[13], i538[12], i538[11], i538[10], i538[9], i538[8], i538[7], i538[6], i538[5], i538[4], i538[3], i538[2], i538[1], i538[0]};
wire [255:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i539[194], i539[193], i539[192], i539[191], i539[190], i539[189], i539[188], i539[187], i539[186], i539[185], i539[184], i539[183], i539[182], i539[181], i539[180], i539[179], i539[178], i539[177], i539[176], i539[175], i539[174], i539[173], i539[172], i539[171], i539[170], i539[169], i539[168], i539[167], i539[166], i539[165], i539[164], i539[163], i539[162], i539[161], i539[160], i539[159], i539[158], i539[157], i539[156], i539[155], i539[154], i539[153], i539[152], i539[151], i539[150], i539[149], i539[148], i539[147], i539[146], i539[145], i539[144], i539[143], i539[142], i539[141], i539[140], i539[139], i539[138], i539[137], i539[136], i539[135], i539[134], i539[133], i539[132], i539[131], i539[130], i539[129], i539[128], i539[127], i539[126], i539[125], i539[124], i539[123], i539[122], i539[121], i539[120], i539[119], i539[118], i539[117], i539[116], i539[115], i539[114], i539[113], i539[112], i539[111], i539[110], i539[109], i539[108], i539[107], i539[106], i539[105], i539[104], i539[103], i539[102], i539[101], i539[100], i539[99], i539[98], i539[97], i539[96], i539[95], i539[94], i539[93], i539[92], i539[91], i539[90], i539[89], i539[88], i539[87], i539[86], i539[85], i539[84], i539[83], i539[82], i539[81], i539[80], i539[79], i539[78], i539[77], i539[76], i539[75], i539[74], i539[73], i539[72], i539[71], i539[70], i539[69], i539[68], i539[67], i539[66], i539[65], i539[64], i539[63], i539[62], i539[61], i539[60], i539[59], i539[58], i539[57], i539[56], i539[55], i539[54], i539[53], i539[52], i539[51], i539[50], i539[49], i539[48], i539[47], i539[46], i539[45], i539[44], i539[43], i539[42], i539[41], i539[40], i539[39], i539[38], i539[37], i539[36], i539[35], i539[34], i539[33], i539[32], i539[31], i539[30], i539[29], i539[28], i539[27], i539[26], i539[25], i539[24], i539[23], i539[22], i539[21], i539[20], i539[19], i539[18], i539[17], i539[16], i539[15], i539[14], i539[13], i539[12], i539[11], i539[10], i539[9], i539[8], i539[7], i539[6], i539[5], i539[4], i539[3], i539[2], i539[1], i539[0]};
wire [255:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i540[210], i540[209], i540[208], i540[207], i540[206], i540[205], i540[204], i540[203], i540[202], i540[201], i540[200], i540[199], i540[198], i540[197], i540[196], i540[195], i540[194], i540[193], i540[192], i540[191], i540[190], i540[189], i540[188], i540[187], i540[186], i540[185], i540[184], i540[183], i540[182], i540[181], i540[180], i540[179], i540[178], i540[177], i540[176], i540[175], i540[174], i540[173], i540[172], i540[171], i540[170], i540[169], i540[168], i540[167], i540[166], i540[165], i540[164], i540[163], i540[162], i540[161], i540[160], i540[159], i540[158], i540[157], i540[156], i540[155], i540[154], i540[153], i540[152], i540[151], i540[150], i540[149], i540[148], i540[147], i540[146], i540[145], i540[144], i540[143], i540[142], i540[141], i540[140], i540[139], i540[138], i540[137], i540[136], i540[135], i540[134], i540[133], i540[132], i540[131], i540[130], i540[129], i540[128], i540[127], i540[126], i540[125], i540[124], i540[123], i540[122], i540[121], i540[120], i540[119], i540[118], i540[117], i540[116], i540[115], i540[114], i540[113], i540[112], i540[111], i540[110], i540[109], i540[108], i540[107], i540[106], i540[105], i540[104], i540[103], i540[102], i540[101], i540[100], i540[99], i540[98], i540[97], i540[96], i540[95], i540[94], i540[93], i540[92], i540[91], i540[90], i540[89], i540[88], i540[87], i540[86], i540[85], i540[84], i540[83], i540[82], i540[81], i540[80], i540[79], i540[78], i540[77], i540[76], i540[75], i540[74], i540[73], i540[72], i540[71], i540[70], i540[69], i540[68], i540[67], i540[66], i540[65], i540[64], i540[63], i540[62], i540[61], i540[60], i540[59], i540[58], i540[57], i540[56], i540[55], i540[54], i540[53], i540[52], i540[51], i540[50], i540[49], i540[48], i540[47], i540[46], i540[45], i540[44], i540[43], i540[42], i540[41], i540[40], i540[39], i540[38], i540[37], i540[36], i540[35], i540[34], i540[33], i540[32], i540[31], i540[30], i540[29], i540[28], i540[27], i540[26], i540[25], i540[24], i540[23], i540[22], i540[21], i540[20], i540[19], i540[18], i540[17], i540[16], i540[15], i540[14], i540[13], i540[12], i540[11], i540[10], i540[9], i540[8], i540[7], i540[6], i540[5], i540[4], i540[3], i540[2], i540[1], i540[0]};
wire [255:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i541[226], i541[225], i541[224], i541[223], i541[222], i541[221], i541[220], i541[219], i541[218], i541[217], i541[216], i541[215], i541[214], i541[213], i541[212], i541[211], i541[210], i541[209], i541[208], i541[207], i541[206], i541[205], i541[204], i541[203], i541[202], i541[201], i541[200], i541[199], i541[198], i541[197], i541[196], i541[195], i541[194], i541[193], i541[192], i541[191], i541[190], i541[189], i541[188], i541[187], i541[186], i541[185], i541[184], i541[183], i541[182], i541[181], i541[180], i541[179], i541[178], i541[177], i541[176], i541[175], i541[174], i541[173], i541[172], i541[171], i541[170], i541[169], i541[168], i541[167], i541[166], i541[165], i541[164], i541[163], i541[162], i541[161], i541[160], i541[159], i541[158], i541[157], i541[156], i541[155], i541[154], i541[153], i541[152], i541[151], i541[150], i541[149], i541[148], i541[147], i541[146], i541[145], i541[144], i541[143], i541[142], i541[141], i541[140], i541[139], i541[138], i541[137], i541[136], i541[135], i541[134], i541[133], i541[132], i541[131], i541[130], i541[129], i541[128], i541[127], i541[126], i541[125], i541[124], i541[123], i541[122], i541[121], i541[120], i541[119], i541[118], i541[117], i541[116], i541[115], i541[114], i541[113], i541[112], i541[111], i541[110], i541[109], i541[108], i541[107], i541[106], i541[105], i541[104], i541[103], i541[102], i541[101], i541[100], i541[99], i541[98], i541[97], i541[96], i541[95], i541[94], i541[93], i541[92], i541[91], i541[90], i541[89], i541[88], i541[87], i541[86], i541[85], i541[84], i541[83], i541[82], i541[81], i541[80], i541[79], i541[78], i541[77], i541[76], i541[75], i541[74], i541[73], i541[72], i541[71], i541[70], i541[69], i541[68], i541[67], i541[66], i541[65], i541[64], i541[63], i541[62], i541[61], i541[60], i541[59], i541[58], i541[57], i541[56], i541[55], i541[54], i541[53], i541[52], i541[51], i541[50], i541[49], i541[48], i541[47], i541[46], i541[45], i541[44], i541[43], i541[42], i541[41], i541[40], i541[39], i541[38], i541[37], i541[36], i541[35], i541[34], i541[33], i541[32], i541[31], i541[30], i541[29], i541[28], i541[27], i541[26], i541[25], i541[24], i541[23], i541[22], i541[21], i541[20], i541[19], i541[18], i541[17], i541[16], i541[15], i541[14], i541[13], i541[12], i541[11], i541[10], i541[9], i541[8], i541[7], i541[6], i541[5], i541[4], i541[3], i541[2], i541[1], i541[0]};
wire [255:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i542[242], i542[241], i542[240], i542[239], i542[238], i542[237], i542[236], i542[235], i542[234], i542[233], i542[232], i542[231], i542[230], i542[229], i542[228], i542[227], i542[226], i542[225], i542[224], i542[223], i542[222], i542[221], i542[220], i542[219], i542[218], i542[217], i542[216], i542[215], i542[214], i542[213], i542[212], i542[211], i542[210], i542[209], i542[208], i542[207], i542[206], i542[205], i542[204], i542[203], i542[202], i542[201], i542[200], i542[199], i542[198], i542[197], i542[196], i542[195], i542[194], i542[193], i542[192], i542[191], i542[190], i542[189], i542[188], i542[187], i542[186], i542[185], i542[184], i542[183], i542[182], i542[181], i542[180], i542[179], i542[178], i542[177], i542[176], i542[175], i542[174], i542[173], i542[172], i542[171], i542[170], i542[169], i542[168], i542[167], i542[166], i542[165], i542[164], i542[163], i542[162], i542[161], i542[160], i542[159], i542[158], i542[157], i542[156], i542[155], i542[154], i542[153], i542[152], i542[151], i542[150], i542[149], i542[148], i542[147], i542[146], i542[145], i542[144], i542[143], i542[142], i542[141], i542[140], i542[139], i542[138], i542[137], i542[136], i542[135], i542[134], i542[133], i542[132], i542[131], i542[130], i542[129], i542[128], i542[127], i542[126], i542[125], i542[124], i542[123], i542[122], i542[121], i542[120], i542[119], i542[118], i542[117], i542[116], i542[115], i542[114], i542[113], i542[112], i542[111], i542[110], i542[109], i542[108], i542[107], i542[106], i542[105], i542[104], i542[103], i542[102], i542[101], i542[100], i542[99], i542[98], i542[97], i542[96], i542[95], i542[94], i542[93], i542[92], i542[91], i542[90], i542[89], i542[88], i542[87], i542[86], i542[85], i542[84], i542[83], i542[82], i542[81], i542[80], i542[79], i542[78], i542[77], i542[76], i542[75], i542[74], i542[73], i542[72], i542[71], i542[70], i542[69], i542[68], i542[67], i542[66], i542[65], i542[64], i542[63], i542[62], i542[61], i542[60], i542[59], i542[58], i542[57], i542[56], i542[55], i542[54], i542[53], i542[52], i542[51], i542[50], i542[49], i542[48], i542[47], i542[46], i542[45], i542[44], i542[43], i542[42], i542[41], i542[40], i542[39], i542[38], i542[37], i542[36], i542[35], i542[34], i542[33], i542[32], i542[31], i542[30], i542[29], i542[28], i542[27], i542[26], i542[25], i542[24], i542[23], i542[22], i542[21], i542[20], i542[19], i542[18], i542[17], i542[16], i542[15], i542[14], i542[13], i542[12], i542[11], i542[10], i542[9], i542[8], i542[7], i542[6], i542[5], i542[4], i542[3], i542[2], i542[1], i542[0]};
wire [255:0] t7 = {i543[255], i543[254], i543[253], i543[252], i543[251], i543[250], i543[249], i543[248], i543[247], i543[246], i543[245], i543[244], i543[243], i543[242], i543[241], i543[240], i543[239], i543[238], i543[237], i543[236], i543[235], i543[234], i543[233], i543[232], i543[231], i543[230], i543[229], i543[228], i543[227], i543[226], i543[225], i543[224], i543[223], i543[222], i543[221], i543[220], i543[219], i543[218], i543[217], i543[216], i543[215], i543[214], i543[213], i543[212], i543[211], i543[210], i543[209], i543[208], i543[207], i543[206], i543[205], i543[204], i543[203], i543[202], i543[201], i543[200], i543[199], i543[198], i543[197], i543[196], i543[195], i543[194], i543[193], i543[192], i543[191], i543[190], i543[189], i543[188], i543[187], i543[186], i543[185], i543[184], i543[183], i543[182], i543[181], i543[180], i543[179], i543[178], i543[177], i543[176], i543[175], i543[174], i543[173], i543[172], i543[171], i543[170], i543[169], i543[168], i543[167], i543[166], i543[165], i543[164], i543[163], i543[162], i543[161], i543[160], i543[159], i543[158], i543[157], i543[156], i543[155], i543[154], i543[153], i543[152], i543[151], i543[150], i543[149], i543[148], i543[147], i543[146], i543[145], i543[144], i543[143], i543[142], i543[141], i543[140], i543[139], i543[138], i543[137], i543[136], i543[135], i543[134], i543[133], i543[132], i543[131], i543[130], i543[129], i543[128], i543[127], i543[126], i543[125], i543[124], i543[123], i543[122], i543[121], i543[120], i543[119], i543[118], i543[117], i543[116], i543[115], i543[114], i543[113], i543[112], i543[111], i543[110], i543[109], i543[108], i543[107], i543[106], i543[105], i543[104], i543[103], i543[102], i543[101], i543[100], i543[99], i543[98], i543[97], i543[96], i543[95], i543[94], i543[93], i543[92], i543[91], i543[90], i543[89], i543[88], i543[87], i543[86], i543[85], i543[84], i543[83], i543[82], i543[81], i543[80], i543[79], i543[78], i543[77], i543[76], i543[75], i543[74], i543[73], i543[72], i543[71], i543[70], i543[69], i543[68], i543[67], i543[66], i543[65], i543[64], i543[63], i543[62], i543[61], i543[60], i543[59], i543[58], i543[57], i543[56], i543[55], i543[54], i543[53], i543[52], i543[51], i543[50], i543[49], i543[48], i543[47], i543[46], i543[45], i543[44], i543[43], i543[42], i543[41], i543[40], i543[39], i543[38], i543[37], i543[36], i543[35], i543[34], i543[33], i543[32], i543[31], i543[30], i543[29], i543[28], i543[27], i543[26], i543[25], i543[24], i543[23], i543[22], i543[21], i543[20], i543[19], i543[18], i543[17], i543[16], i543[15], i543[14], i543[13], i543[12], i543[11], i543[10], i543[9], i543[8], i543[7], i543[6], i543[5], i543[4], i543[3], i543[2], i543[1], i543[0]};
wire [255:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412Core(input wire [81:0] a,input wire [145:0] b,input wire cin,output wire [146:0] value);
wire [81:0] masked_a=((a&82'h3ffffffffffffffffffff)|82'h0);
wire [145:0] masked_b=((b&146'h3ffffffffffffffffffffffffffffffffffff)|146'h0);
wire [146:0] aa=147'(masked_b);
wire [146:0] bb=147'(masked_a);
wire [147:0] extended={1'b0,aa}+{1'b0,bb}+148'(1'b0);
wire [146:0] native_value=extended[146:0];
assign value=native_value[0+:147];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [97:0] a,input wire [161:0] b,input wire cin,output wire [162:0] value);
wire [97:0] masked_a=((a&98'h3ffffffffffffffffffffffff)|98'h0);
wire [161:0] masked_b=((b&162'h3ffffffffffffffffffffffffffffffffffffffff)|162'h0);
wire [162:0] aa=163'(masked_b);
wire [162:0] bb=163'(masked_a);
wire [163:0] extended={1'b0,aa}+{1'b0,bb}+164'(1'b0);
wire [162:0] native_value=extended[162:0];
assign value=native_value[0+:163];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_418Core(input wire [113:0] a,input wire [177:0] b,input wire cin,output wire [178:0] value);
wire [113:0] masked_a=((a&114'h3ffffffffffffffffffffffffffff)|114'h0);
wire [177:0] masked_b=((b&178'h3ffffffffffffffffffffffffffffffffffffffffffff)|178'h0);
wire [178:0] aa=179'(masked_b);
wire [178:0] bb=179'(masked_a);
wire [179:0] extended={1'b0,aa}+{1'b0,bb}+180'(1'b0);
wire [178:0] native_value=extended[178:0];
assign value=native_value[0+:179];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_418();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421Core(input wire [129:0] a,input wire [193:0] b,input wire cin,output wire [194:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [193:0] masked_b=((b&194'h3ffffffffffffffffffffffffffffffffffffffffffffffff)|194'h0);
wire [194:0] aa=195'(masked_b);
wire [194:0] bb=195'(masked_a);
wire [195:0] extended={1'b0,aa}+{1'b0,bb}+196'(1'b0);
wire [194:0] native_value=extended[194:0];
assign value=native_value[0+:195];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424Core(input wire [145:0] a,input wire [209:0] b,input wire cin,output wire [210:0] value);
wire [145:0] masked_a=((a&146'h3ffffffffffffffffffffffffffffffffffff)|146'h0);
wire [209:0] masked_b=((b&210'h3ffffffffffffffffffffffffffffffffffffffffffffffffffff)|210'h0);
wire [210:0] aa=211'(masked_b);
wire [210:0] bb=211'(masked_a);
wire [211:0] extended={1'b0,aa}+{1'b0,bb}+212'(1'b0);
wire [210:0] native_value=extended[210:0];
assign value=native_value[0+:211];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427Core(input wire [161:0] a,input wire [225:0] b,input wire cin,output wire [226:0] value);
wire [161:0] masked_a=((a&162'h3ffffffffffffffffffffffffffffffffffffffff)|162'h0);
wire [225:0] masked_b=((b&226'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|226'h0);
wire [226:0] aa=227'(masked_b);
wire [226:0] bb=227'(masked_a);
wire [227:0] extended={1'b0,aa}+{1'b0,bb}+228'(1'b0);
wire [226:0] native_value=extended[226:0];
assign value=native_value[0+:227];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [177:0] a,input wire [241:0] b,input wire cin,output wire [242:0] value);
wire [177:0] masked_a=((a&178'h3ffffffffffffffffffffffffffffffffffffffffffff)|178'h0);
wire [241:0] masked_b=((b&242'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|242'h0);
wire [242:0] aa=243'(masked_b);
wire [242:0] bb=243'(masked_a);
wire [243:0] extended={1'b0,aa}+{1'b0,bb}+244'(1'b0);
wire [242:0] native_value=extended[242:0];
assign value=native_value[0+:243];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433Core(input wire [193:0] a,input wire [257:0] b,input wire cin,output wire [255:0] value);
wire [193:0] masked_a=((a&194'h3ffffffffffffffffffffffffffffffffffffffffffffffff)|194'h0);
wire [257:0] masked_b=((b&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [257:0] aa=258'(masked_b);
wire [257:0] bb=258'(masked_a);
wire [258:0] extended={1'b0,aa}+{1'b0,bb}+259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
