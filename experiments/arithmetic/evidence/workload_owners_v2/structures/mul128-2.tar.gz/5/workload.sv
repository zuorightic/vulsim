`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [15:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_132; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_134; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_136; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_138; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_140; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_142; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_144; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_146; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_148; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_150; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_152; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_154; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_156; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_158; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_160; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_162; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_164; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_166; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_168; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_170; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_172; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_10_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_174; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_176; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_178; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_180; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_182; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_184; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_186; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_188; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_190; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_191; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_192; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_193; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_194; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_196; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_197; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_200; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_201; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_202; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_204; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_205; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_206; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_208; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_209; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_210; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_211; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_212; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_213; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_215; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_216; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_217; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_219; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_220; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_221; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_222; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_224; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_225; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_226; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_228; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_229; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_232; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_234; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_235; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_236; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_237; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_239; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_240; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_244; // decl: <none>; prim: <none>
    logic [175:0] mul_tree_10_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_248; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_252; // decl: <none>; prim: <none>
    logic [207:0] mul_tree_10_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_256; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_260; // decl: <none>; prim: <none>
    logic [239:0] mul_tree_10_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_264; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_265; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_266; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_267; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_268; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_269; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_270; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_271; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_272; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_273; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_274; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_275; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_276; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_277; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_278; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_279; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_280; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_281; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_282; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_283; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_284; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_285; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_286; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_287; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_288; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_289; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_290; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_291; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_10_292; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_293; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_294; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_295; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_296; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_297; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_298; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_299; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_300; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_301; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_302; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_303; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_304; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_305; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_306; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_307; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_308; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_309; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_310; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_311; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_312; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_313; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_314; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_315; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_10_316; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_317; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_318; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_319; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_320; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_321; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_322; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_323; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_324; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_325; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_326; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_327; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_328; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_329; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_330; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_331; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_332; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_333; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_334; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_335; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_336; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_337; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_338; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_339; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_340; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_341; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_342; // decl: <none>; prim: <none>
    logic [176:0] mul_tree_10_343; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_344; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_345; // decl: <none>; prim: <none>
    logic [208:0] mul_tree_10_346; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_347; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_348; // decl: <none>; prim: <none>
    logic [240:0] mul_tree_10_349; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_350; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_351; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_352; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_353; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_354; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_355; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_356; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_357; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_358; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_359; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_360; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_361; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_362; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_363; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_10_364; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_365; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_366; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_367; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_368; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_369; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_370; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_371; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_372; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_373; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_374; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_375; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_10_376; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_377; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_378; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_379; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_382; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_383; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_384; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_385; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_386; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_387; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_388; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_389; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_390; // decl: <none>; prim: <none>
    logic [209:0] mul_tree_10_391; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_392; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_393; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_394; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_395; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_396; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_397; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_398; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_399; // decl: <none>; prim: <none>
    logic [177:0] mul_tree_10_400; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_401; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_402; // decl: <none>; prim: <none>
    logic [241:0] mul_tree_10_403; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_404; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_405; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_406; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_407; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_408; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_409; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_410; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_411; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_412; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_413; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_414; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_10_415; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_416; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_417; // decl: <none>; prim: <none>
    logic [178:0] mul_tree_10_418; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_419; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_420; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_421; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_422; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_423; // decl: <none>; prim: <none>
    logic [210:0] mul_tree_10_424; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_425; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_426; // decl: <none>; prim: <none>
    logic [226:0] mul_tree_10_427; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_428; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_429; // decl: <none>; prim: <none>
    logic [242:0] mul_tree_10_430; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_431; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_432; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_433; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_434; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_435; // decl: <none>; prim: <none>
    logic [163:0] mul_tree_10_436; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_437; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_438; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_439; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_440; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_441; // decl: <none>; prim: <none>
    logic [227:0] mul_tree_10_442; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_443; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_444; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_445; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_446; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_447; // decl: <none>; prim: <none>
    logic [196:0] mul_tree_10_448; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_449; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_450; // decl: <none>; prim: <none>
    logic [260:0] mul_tree_10_451; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_452; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_453; // decl: <none>; prim: <none>
    logic [261:0] mul_tree_10_454; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_455; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_81_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_93_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_133_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_137_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_141_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_145_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_149_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_153_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_157_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_161_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_165_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_169_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_173_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_177_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_181_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_185_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_189_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_193_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_201_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_205_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_209_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_213_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_217_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_221_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_225_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_229_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_233_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_237_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_241_s1; // decl: <none>; prim: <none>
    logic [175:0] rtlzz_pipe_245_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_249_s1; // decl: <none>; prim: <none>
    logic [207:0] rtlzz_pipe_253_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_257_s1; // decl: <none>; prim: <none>
    logic [239:0] rtlzz_pipe_261_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_268_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_274_s2; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_277_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_283_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_286_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_295_s2; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_298_s2; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_301_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_304_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_307_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_310_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_313_s2; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_316_s2; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_319_s2; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_322_s2; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_325_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_328_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_331_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_334_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_337_s2; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_340_s2; // decl: <none>; prim: <none>
    logic [176:0] rtlzz_pipe_343_s2; // decl: <none>; prim: <none>
    logic [208:0] rtlzz_pipe_346_s2; // decl: <none>; prim: <none>
    logic [240:0] rtlzz_pipe_349_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_352_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_355_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_358_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_361_s2; // decl: <none>; prim: <none>
    logic [146:0] rtlzz_pipe_412_s3; // decl: <none>; prim: <none>
    logic [162:0] rtlzz_pipe_415_s3; // decl: <none>; prim: <none>
    logic [178:0] rtlzz_pipe_418_s3; // decl: <none>; prim: <none>
    logic [194:0] rtlzz_pipe_421_s3; // decl: <none>; prim: <none>
    logic [210:0] rtlzz_pipe_424_s3; // decl: <none>; prim: <none>
    logic [226:0] rtlzz_pipe_427_s3; // decl: <none>; prim: <none>
    logic [242:0] rtlzz_pipe_430_s3; // decl: <none>; prim: <none>
    logic [258:0] rtlzz_pipe_433_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_455; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(16'(mul_tree_10_11)), .b(16'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(16'(mul_tree_10_14)), .b(16'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(16'(mul_tree_10_18)), .b(16'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(16'(mul_tree_10_22)), .b(16'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(16'(mul_tree_10_26)), .b(16'(mul_tree_10_27)), .cin(1'b0), .value(mul_tree_10_28));
    assign mul_tree_10_29 = {mul_tree_10_28, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_32Core rtlzz_owner_32(.a(16'(mul_tree_10_30)), .b(16'(mul_tree_10_31)), .cin(1'b0), .value(mul_tree_10_32));
    assign mul_tree_10_33 = {mul_tree_10_32, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(16'(mul_tree_10_34)), .b(16'(mul_tree_10_35)), .cin(1'b0), .value(mul_tree_10_36));
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(16'(mul_tree_10_38)), .b(16'(mul_tree_10_39)), .cin(1'b0), .value(mul_tree_10_40));
    assign mul_tree_10_41 = {mul_tree_10_40, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_44Core rtlzz_owner_44(.a(16'(mul_tree_10_42)), .b(16'(mul_tree_10_43)), .cin(1'b0), .value(mul_tree_10_44));
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_48Core rtlzz_owner_48(.a(16'(mul_tree_10_46)), .b(16'(mul_tree_10_47)), .cin(1'b0), .value(mul_tree_10_48));
    assign mul_tree_10_49 = {mul_tree_10_48, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(16'(mul_tree_10_50)), .b(16'(mul_tree_10_51)), .cin(1'b0), .value(mul_tree_10_52));
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(16'(mul_tree_10_54)), .b(16'(mul_tree_10_55)), .cin(1'b0), .value(mul_tree_10_56));
    assign mul_tree_10_57 = {mul_tree_10_56, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(16'(mul_tree_10_58)), .b(16'(mul_tree_10_59)), .cin(1'b0), .value(mul_tree_10_60));
    assign mul_tree_10_61 = {mul_tree_10_60, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_64Core rtlzz_owner_64(.a(16'(mul_tree_10_62)), .b(16'(mul_tree_10_63)), .cin(1'b0), .value(mul_tree_10_64));
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_68Core rtlzz_owner_68(.a(16'(mul_tree_10_66)), .b(16'(mul_tree_10_67)), .cin(1'b0), .value(mul_tree_10_68));
    assign mul_tree_10_69 = {mul_tree_10_68, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_72Core rtlzz_owner_72(.a(16'(mul_tree_10_70)), .b(16'(mul_tree_10_71)), .cin(1'b0), .value(mul_tree_10_72));
    assign mul_tree_10_73 = {mul_tree_10_72, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(16'(mul_tree_10_74)), .b(16'(mul_tree_10_75)), .cin(1'b0), .value(mul_tree_10_76));
    assign mul_tree_10_77 = {mul_tree_10_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_80Core rtlzz_owner_80(.a(16'(mul_tree_10_78)), .b(16'(mul_tree_10_79)), .cin(1'b0), .value(mul_tree_10_80));
    assign mul_tree_10_81 = {mul_tree_10_80, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(16'(mul_tree_10_82)), .b(16'(mul_tree_10_83)), .cin(1'b0), .value(mul_tree_10_84));
    assign mul_tree_10_85 = {mul_tree_10_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_88Core rtlzz_owner_88(.a(16'(mul_tree_10_86)), .b(16'(mul_tree_10_87)), .cin(1'b0), .value(mul_tree_10_88));
    assign mul_tree_10_89 = {mul_tree_10_88, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(16'(mul_tree_10_90)), .b(16'(mul_tree_10_91)), .cin(1'b0), .value(mul_tree_10_92));
    assign mul_tree_10_93 = {mul_tree_10_92, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_96Core rtlzz_owner_96(.a(16'(mul_tree_10_94)), .b(16'(mul_tree_10_95)), .cin(1'b0), .value(mul_tree_10_96));
    assign mul_tree_10_97 = {mul_tree_10_96, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_100Core rtlzz_owner_100(.a(16'(mul_tree_10_98)), .b(16'(mul_tree_10_99)), .cin(1'b0), .value(mul_tree_10_100));
    assign mul_tree_10_101 = {mul_tree_10_100, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = mul_precision_8[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(16'(mul_tree_10_102)), .b(16'(mul_tree_10_103)), .cin(1'b0), .value(mul_tree_10_104));
    assign mul_tree_10_105 = {mul_tree_10_104, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_107 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_108Core rtlzz_owner_108(.a(16'(mul_tree_10_106)), .b(16'(mul_tree_10_107)), .cin(1'b0), .value(mul_tree_10_108));
    assign mul_tree_10_109 = {mul_tree_10_108, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_110 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_111 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_112Core rtlzz_owner_112(.a(16'(mul_tree_10_110)), .b(16'(mul_tree_10_111)), .cin(1'b0), .value(mul_tree_10_112));
    assign mul_tree_10_113 = {mul_tree_10_112, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_114 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_115 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(16'(mul_tree_10_114)), .b(16'(mul_tree_10_115)), .cin(1'b0), .value(mul_tree_10_116));
    assign mul_tree_10_117 = {mul_tree_10_116, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_118 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(16'(mul_tree_10_118)), .b(16'(mul_tree_10_119)), .cin(1'b0), .value(mul_tree_10_120));
    assign mul_tree_10_121 = {mul_tree_10_120, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_122 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_123 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(16'(mul_tree_10_122)), .b(16'(mul_tree_10_123)), .cin(1'b0), .value(mul_tree_10_124));
    assign mul_tree_10_125 = {mul_tree_10_124, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_126 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_127 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(16'(mul_tree_10_126)), .b(16'(mul_tree_10_127)), .cin(1'b0), .value(mul_tree_10_128));
    assign mul_tree_10_129 = {mul_tree_10_128, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_131 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_10_130)), .b(16'(mul_tree_10_131)), .cin(1'b0), .value(mul_tree_10_132));
    assign mul_tree_10_133 = {mul_tree_10_132, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_134 = mul_precision_8[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_135 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(16'(mul_tree_10_134)), .b(16'(mul_tree_10_135)), .cin(1'b0), .value(mul_tree_10_136));
    assign mul_tree_10_137 = {mul_tree_10_136, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_138 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_139 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(16'(mul_tree_10_138)), .b(16'(mul_tree_10_139)), .cin(1'b0), .value(mul_tree_10_140));
    assign mul_tree_10_141 = {mul_tree_10_140, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_142 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_143 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(16'(mul_tree_10_142)), .b(16'(mul_tree_10_143)), .cin(1'b0), .value(mul_tree_10_144));
    assign mul_tree_10_145 = {mul_tree_10_144, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_146 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_147 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(16'(mul_tree_10_146)), .b(16'(mul_tree_10_147)), .cin(1'b0), .value(mul_tree_10_148));
    assign mul_tree_10_149 = {mul_tree_10_148, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_150 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_151 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_152Core rtlzz_owner_152(.a(16'(mul_tree_10_150)), .b(16'(mul_tree_10_151)), .cin(1'b0), .value(mul_tree_10_152));
    assign mul_tree_10_153 = {mul_tree_10_152, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_154 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_155 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(16'(mul_tree_10_154)), .b(16'(mul_tree_10_155)), .cin(1'b0), .value(mul_tree_10_156));
    assign mul_tree_10_157 = {mul_tree_10_156, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_158 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_159 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(16'(mul_tree_10_158)), .b(16'(mul_tree_10_159)), .cin(1'b0), .value(mul_tree_10_160));
    assign mul_tree_10_161 = {mul_tree_10_160, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_162 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_163 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_164Core rtlzz_owner_164(.a(16'(mul_tree_10_162)), .b(16'(mul_tree_10_163)), .cin(1'b0), .value(mul_tree_10_164));
    assign mul_tree_10_165 = {mul_tree_10_164, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_166 = mul_precision_8[79:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_167 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(16'(mul_tree_10_166)), .b(16'(mul_tree_10_167)), .cin(1'b0), .value(mul_tree_10_168));
    assign mul_tree_10_169 = {mul_tree_10_168, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_170 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_171 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(16'(mul_tree_10_170)), .b(16'(mul_tree_10_171)), .cin(1'b0), .value(mul_tree_10_172));
    assign mul_tree_10_173 = {mul_tree_10_172, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_174 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_175 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(16'(mul_tree_10_174)), .b(16'(mul_tree_10_175)), .cin(1'b0), .value(mul_tree_10_176));
    assign mul_tree_10_177 = {mul_tree_10_176, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_178 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_179 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(16'(mul_tree_10_178)), .b(16'(mul_tree_10_179)), .cin(1'b0), .value(mul_tree_10_180));
    assign mul_tree_10_181 = {mul_tree_10_180, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_182 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_183 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(16'(mul_tree_10_182)), .b(16'(mul_tree_10_183)), .cin(1'b0), .value(mul_tree_10_184));
    assign mul_tree_10_185 = {mul_tree_10_184, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_186 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_187 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(16'(mul_tree_10_186)), .b(16'(mul_tree_10_187)), .cin(1'b0), .value(mul_tree_10_188));
    assign mul_tree_10_189 = {mul_tree_10_188, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_190 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_191 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_192Core rtlzz_owner_192(.a(16'(mul_tree_10_190)), .b(16'(mul_tree_10_191)), .cin(1'b0), .value(mul_tree_10_192));
    assign mul_tree_10_193 = {mul_tree_10_192, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_194 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_195 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_196Core rtlzz_owner_196(.a(16'(mul_tree_10_194)), .b(16'(mul_tree_10_195)), .cin(1'b0), .value(mul_tree_10_196));
    assign mul_tree_10_197 = {mul_tree_10_196, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_198 = mul_precision_8[95:80]; // decl: <none>; prim: <none>
    assign mul_tree_10_199 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(16'(mul_tree_10_198)), .b(16'(mul_tree_10_199)), .cin(1'b0), .value(mul_tree_10_200));
    assign mul_tree_10_201 = {mul_tree_10_200, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_202 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_203 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(16'(mul_tree_10_202)), .b(16'(mul_tree_10_203)), .cin(1'b0), .value(mul_tree_10_204));
    assign mul_tree_10_205 = {mul_tree_10_204, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_206 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_207 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_208Core rtlzz_owner_208(.a(16'(mul_tree_10_206)), .b(16'(mul_tree_10_207)), .cin(1'b0), .value(mul_tree_10_208));
    assign mul_tree_10_209 = {mul_tree_10_208, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_210 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_211 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(16'(mul_tree_10_210)), .b(16'(mul_tree_10_211)), .cin(1'b0), .value(mul_tree_10_212));
    assign mul_tree_10_213 = {mul_tree_10_212, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_214 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_215 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(16'(mul_tree_10_214)), .b(16'(mul_tree_10_215)), .cin(1'b0), .value(mul_tree_10_216));
    assign mul_tree_10_217 = {mul_tree_10_216, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_218 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_219 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(16'(mul_tree_10_218)), .b(16'(mul_tree_10_219)), .cin(1'b0), .value(mul_tree_10_220));
    assign mul_tree_10_221 = {mul_tree_10_220, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_222 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_223 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(16'(mul_tree_10_222)), .b(16'(mul_tree_10_223)), .cin(1'b0), .value(mul_tree_10_224));
    assign mul_tree_10_225 = {mul_tree_10_224, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_226 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_227 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(16'(mul_tree_10_226)), .b(16'(mul_tree_10_227)), .cin(1'b0), .value(mul_tree_10_228));
    assign mul_tree_10_229 = {mul_tree_10_228, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_230 = mul_precision_8[111:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_231 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_232Core rtlzz_owner_232(.a(16'(mul_tree_10_230)), .b(16'(mul_tree_10_231)), .cin(1'b0), .value(mul_tree_10_232));
    assign mul_tree_10_233 = {mul_tree_10_232, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_234 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_235 = mul_precision_9[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_236Core rtlzz_owner_236(.a(16'(mul_tree_10_234)), .b(16'(mul_tree_10_235)), .cin(1'b0), .value(mul_tree_10_236));
    assign mul_tree_10_237 = {mul_tree_10_236, 112'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_238 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_239 = mul_precision_9[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(16'(mul_tree_10_238)), .b(16'(mul_tree_10_239)), .cin(1'b0), .value(mul_tree_10_240));
    assign mul_tree_10_241 = {mul_tree_10_240, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_242 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_243 = mul_precision_9[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_10_242)), .b(16'(mul_tree_10_243)), .cin(1'b0), .value(mul_tree_10_244));
    assign mul_tree_10_245 = {mul_tree_10_244, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_246 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_247 = mul_precision_9[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_10_246)), .b(16'(mul_tree_10_247)), .cin(1'b0), .value(mul_tree_10_248));
    assign mul_tree_10_249 = {mul_tree_10_248, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_250 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_251 = mul_precision_9[79:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_10_250)), .b(16'(mul_tree_10_251)), .cin(1'b0), .value(mul_tree_10_252));
    assign mul_tree_10_253 = {mul_tree_10_252, 176'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_254 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_255 = mul_precision_9[95:80]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_10_254)), .b(16'(mul_tree_10_255)), .cin(1'b0), .value(mul_tree_10_256));
    assign mul_tree_10_257 = {mul_tree_10_256, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_258 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_259 = mul_precision_9[111:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_10_258)), .b(16'(mul_tree_10_259)), .cin(1'b0), .value(mul_tree_10_260));
    assign mul_tree_10_261 = {mul_tree_10_260, 208'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_262 = mul_precision_8[127:112]; // decl: <none>; prim: <none>
    assign mul_tree_10_263 = mul_precision_9[127:112]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_10_262)), .b(16'(mul_tree_10_263)), .cin(1'b0), .value(mul_tree_10_264));
    assign mul_tree_10_265 = {mul_tree_10_264, 224'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_266 = ({17'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_267 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_268Core rtlzz_owner_268(.a(32'(mul_tree_10_266)), .b(48'(mul_tree_10_267)), .cin(1'h0), .value(mul_tree_10_268));
    assign mul_tree_10_269 = ({17'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_270 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_271Core rtlzz_owner_271(.a(64'(mul_tree_10_269)), .b(80'(mul_tree_10_270)), .cin(1'h0), .value(mul_tree_10_271));
    assign mul_tree_10_272 = ({17'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_273 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_274Core rtlzz_owner_274(.a(96'(mul_tree_10_272)), .b(112'(mul_tree_10_273)), .cin(1'h0), .value(mul_tree_10_274));
    assign mul_tree_10_275 = ({17'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_276 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_277Core rtlzz_owner_277(.a(128'(mul_tree_10_275)), .b(144'(mul_tree_10_276)), .cin(1'h0), .value(mul_tree_10_277));
    assign mul_tree_10_278 = ({17'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_279 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(48'(mul_tree_10_278)), .b(64'(mul_tree_10_279)), .cin(1'h0), .value(mul_tree_10_280));
    assign mul_tree_10_281 = ({17'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_282 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_283Core rtlzz_owner_283(.a(80'(mul_tree_10_281)), .b(96'(mul_tree_10_282)), .cin(1'h0), .value(mul_tree_10_283));
    assign mul_tree_10_284 = ({17'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_285 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_286Core rtlzz_owner_286(.a(112'(mul_tree_10_284)), .b(128'(mul_tree_10_285)), .cin(1'h0), .value(mul_tree_10_286));
    assign mul_tree_10_287 = ({17'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_288 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_289Core rtlzz_owner_289(.a(144'(mul_tree_10_287)), .b(160'(mul_tree_10_288)), .cin(1'h0), .value(mul_tree_10_289));
    assign mul_tree_10_290 = ({17'h0, rtlzz_pipe_77_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_291 = ({1'h0, rtlzz_pipe_81_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_292Core rtlzz_owner_292(.a(64'(mul_tree_10_290)), .b(80'(mul_tree_10_291)), .cin(1'h0), .value(mul_tree_10_292));
    assign mul_tree_10_293 = ({17'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_294 = ({1'h0, rtlzz_pipe_89_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_295Core rtlzz_owner_295(.a(96'(mul_tree_10_293)), .b(112'(mul_tree_10_294)), .cin(1'h0), .value(mul_tree_10_295));
    assign mul_tree_10_296 = ({17'h0, rtlzz_pipe_93_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_297 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(128'(mul_tree_10_296)), .b(144'(mul_tree_10_297)), .cin(1'h0), .value(mul_tree_10_298));
    assign mul_tree_10_299 = ({17'h0, rtlzz_pipe_101_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_300 = ({1'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(160'(mul_tree_10_299)), .b(176'(mul_tree_10_300)), .cin(1'h0), .value(mul_tree_10_301));
    assign mul_tree_10_302 = ({17'h0, rtlzz_pipe_109_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_303 = ({1'h0, rtlzz_pipe_113_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_304Core rtlzz_owner_304(.a(80'(mul_tree_10_302)), .b(96'(mul_tree_10_303)), .cin(1'h0), .value(mul_tree_10_304));
    assign mul_tree_10_305 = ({17'h0, rtlzz_pipe_117_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_306 = ({1'h0, rtlzz_pipe_121_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_307Core rtlzz_owner_307(.a(112'(mul_tree_10_305)), .b(128'(mul_tree_10_306)), .cin(1'h0), .value(mul_tree_10_307));
    assign mul_tree_10_308 = ({17'h0, rtlzz_pipe_125_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_309 = ({1'h0, rtlzz_pipe_129_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_310Core rtlzz_owner_310(.a(144'(mul_tree_10_308)), .b(160'(mul_tree_10_309)), .cin(1'h0), .value(mul_tree_10_310));
    assign mul_tree_10_311 = ({17'h0, rtlzz_pipe_133_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_312 = ({1'h0, rtlzz_pipe_137_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(176'(mul_tree_10_311)), .b(192'(mul_tree_10_312)), .cin(1'h0), .value(mul_tree_10_313));
    assign mul_tree_10_314 = ({17'h0, rtlzz_pipe_141_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_315 = ({1'h0, rtlzz_pipe_145_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_10_314)), .b(112'(mul_tree_10_315)), .cin(1'h0), .value(mul_tree_10_316));
    assign mul_tree_10_317 = ({17'h0, rtlzz_pipe_149_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_318 = ({1'h0, rtlzz_pipe_153_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(128'(mul_tree_10_317)), .b(144'(mul_tree_10_318)), .cin(1'h0), .value(mul_tree_10_319));
    assign mul_tree_10_320 = ({17'h0, rtlzz_pipe_157_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_321 = ({1'h0, rtlzz_pipe_161_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_322Core rtlzz_owner_322(.a(160'(mul_tree_10_320)), .b(176'(mul_tree_10_321)), .cin(1'h0), .value(mul_tree_10_322));
    assign mul_tree_10_323 = ({17'h0, rtlzz_pipe_165_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_324 = ({1'h0, rtlzz_pipe_169_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_325Core rtlzz_owner_325(.a(192'(mul_tree_10_323)), .b(208'(mul_tree_10_324)), .cin(1'h0), .value(mul_tree_10_325));
    assign mul_tree_10_326 = ({17'h0, rtlzz_pipe_173_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_327 = ({1'h0, rtlzz_pipe_177_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_328Core rtlzz_owner_328(.a(112'(mul_tree_10_326)), .b(128'(mul_tree_10_327)), .cin(1'h0), .value(mul_tree_10_328));
    assign mul_tree_10_329 = ({17'h0, rtlzz_pipe_181_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_330 = ({1'h0, rtlzz_pipe_185_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_331Core rtlzz_owner_331(.a(144'(mul_tree_10_329)), .b(160'(mul_tree_10_330)), .cin(1'h0), .value(mul_tree_10_331));
    assign mul_tree_10_332 = ({17'h0, rtlzz_pipe_189_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_333 = ({1'h0, rtlzz_pipe_193_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(176'(mul_tree_10_332)), .b(192'(mul_tree_10_333)), .cin(1'h0), .value(mul_tree_10_334));
    assign mul_tree_10_335 = ({17'h0, rtlzz_pipe_197_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_336 = ({1'h0, rtlzz_pipe_201_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(208'(mul_tree_10_335)), .b(224'(mul_tree_10_336)), .cin(1'h0), .value(mul_tree_10_337));
    assign mul_tree_10_338 = ({17'h0, rtlzz_pipe_205_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_339 = ({1'h0, rtlzz_pipe_209_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_340Core rtlzz_owner_340(.a(128'(mul_tree_10_338)), .b(144'(mul_tree_10_339)), .cin(1'h0), .value(mul_tree_10_340));
    assign mul_tree_10_341 = ({17'h0, rtlzz_pipe_213_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_342 = ({1'h0, rtlzz_pipe_217_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(160'(mul_tree_10_341)), .b(176'(mul_tree_10_342)), .cin(1'h0), .value(mul_tree_10_343));
    assign mul_tree_10_344 = ({17'h0, rtlzz_pipe_221_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_345 = ({1'h0, rtlzz_pipe_225_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_346Core rtlzz_owner_346(.a(192'(mul_tree_10_344)), .b(208'(mul_tree_10_345)), .cin(1'h0), .value(mul_tree_10_346));
    assign mul_tree_10_347 = ({17'h0, rtlzz_pipe_229_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_348 = ({1'h0, rtlzz_pipe_233_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_349Core rtlzz_owner_349(.a(224'(mul_tree_10_347)), .b(240'(mul_tree_10_348)), .cin(1'h0), .value(mul_tree_10_349));
    assign mul_tree_10_350 = ({17'h0, rtlzz_pipe_237_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_351 = ({1'h0, rtlzz_pipe_241_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_352Core rtlzz_owner_352(.a(144'(mul_tree_10_350)), .b(160'(mul_tree_10_351)), .cin(1'h0), .value(mul_tree_10_352));
    assign mul_tree_10_353 = ({17'h0, rtlzz_pipe_245_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_354 = ({1'h0, rtlzz_pipe_249_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(176'(mul_tree_10_353)), .b(192'(mul_tree_10_354)), .cin(1'h0), .value(mul_tree_10_355));
    assign mul_tree_10_356 = ({17'h0, rtlzz_pipe_253_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_357 = ({1'h0, rtlzz_pipe_257_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(208'(mul_tree_10_356)), .b(224'(mul_tree_10_357)), .cin(1'h0), .value(mul_tree_10_358));
    assign mul_tree_10_359 = ({17'h0, rtlzz_pipe_261_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_360 = ({1'h0, rtlzz_pipe_265_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_361Core rtlzz_owner_361(.a(240'(mul_tree_10_359)), .b(256'(mul_tree_10_360)), .cin(1'h0), .value(mul_tree_10_361[255:0]));
    assign mul_tree_10_361[256:256] = '0;
    assign mul_tree_10_362 = ({33'h0, rtlzz_pipe_268_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_363 = ({1'h0, rtlzz_pipe_271_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_365 = ({33'h0, rtlzz_pipe_274_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_366 = ({1'h0, rtlzz_pipe_277_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_368 = ({33'h0, rtlzz_pipe_280_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_369 = ({1'h0, rtlzz_pipe_283_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_371 = ({33'h0, rtlzz_pipe_286_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_372 = ({1'h0, rtlzz_pipe_289_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_374 = ({33'h0, rtlzz_pipe_292_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_375 = ({1'h0, rtlzz_pipe_295_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_377 = ({33'h0, rtlzz_pipe_298_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_378 = ({1'h0, rtlzz_pipe_301_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_380 = ({33'h0, rtlzz_pipe_304_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_381 = ({1'h0, rtlzz_pipe_307_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_383 = ({33'h0, rtlzz_pipe_310_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_384 = ({1'h0, rtlzz_pipe_313_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_386 = ({33'h0, rtlzz_pipe_316_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_387 = ({1'h0, rtlzz_pipe_319_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_389 = ({33'h0, rtlzz_pipe_322_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_390 = ({1'h0, rtlzz_pipe_325_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_392 = ({33'h0, rtlzz_pipe_328_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_393 = ({1'h0, rtlzz_pipe_331_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_395 = ({33'h0, rtlzz_pipe_334_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_396 = ({1'h0, rtlzz_pipe_337_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_398 = ({33'h0, rtlzz_pipe_340_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_399 = ({1'h0, rtlzz_pipe_343_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_401 = ({33'h0, rtlzz_pipe_346_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_402 = ({1'h0, rtlzz_pipe_349_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_404 = ({33'h0, rtlzz_pipe_352_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_405 = ({1'h0, rtlzz_pipe_355_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_407 = ({33'h0, rtlzz_pipe_358_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_408 = ({1'h0, rtlzz_pipe_361_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_410 = ({65'h0, mul_tree_10_364}); // decl: <none>; prim: <none>
    assign mul_tree_10_411 = ({1'h0, mul_tree_10_367}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412_reduce rtlzz_reduce_412(.i520(rtlzz_pipe_268_s2), .i521(rtlzz_pipe_271_s2), .i522(rtlzz_pipe_274_s2), .i523(rtlzz_pipe_277_s2), .y(mul_tree_10_412));
    assign mul_tree_10_413 = ({65'h0, mul_tree_10_370}); // decl: <none>; prim: <none>
    assign mul_tree_10_414 = ({1'h0, mul_tree_10_373}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415_reduce rtlzz_reduce_415(.i524(rtlzz_pipe_280_s2), .i525(rtlzz_pipe_283_s2), .i526(rtlzz_pipe_286_s2), .i527(rtlzz_pipe_289_s2), .y(mul_tree_10_415));
    assign mul_tree_10_416 = ({65'h0, mul_tree_10_376}); // decl: <none>; prim: <none>
    assign mul_tree_10_417 = ({1'h0, mul_tree_10_379}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_418_reduce rtlzz_reduce_418(.i528(rtlzz_pipe_292_s2), .i529(rtlzz_pipe_295_s2), .i530(rtlzz_pipe_298_s2), .i531(rtlzz_pipe_301_s2), .y(mul_tree_10_418));
    assign mul_tree_10_419 = ({65'h0, mul_tree_10_382}); // decl: <none>; prim: <none>
    assign mul_tree_10_420 = ({1'h0, mul_tree_10_385}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_421_reduce rtlzz_reduce_421(.i532(rtlzz_pipe_304_s2), .i533(rtlzz_pipe_307_s2), .i534(rtlzz_pipe_310_s2), .i535(rtlzz_pipe_313_s2), .y(mul_tree_10_421));
    assign mul_tree_10_422 = ({65'h0, mul_tree_10_388}); // decl: <none>; prim: <none>
    assign mul_tree_10_423 = ({1'h0, mul_tree_10_391}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_424_reduce rtlzz_reduce_424(.i536(rtlzz_pipe_316_s2), .i537(rtlzz_pipe_319_s2), .i538(rtlzz_pipe_322_s2), .i539(rtlzz_pipe_325_s2), .y(mul_tree_10_424));
    assign mul_tree_10_425 = ({65'h0, mul_tree_10_394}); // decl: <none>; prim: <none>
    assign mul_tree_10_426 = ({1'h0, mul_tree_10_397}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427_reduce rtlzz_reduce_427(.i540(rtlzz_pipe_328_s2), .i541(rtlzz_pipe_331_s2), .i542(rtlzz_pipe_334_s2), .i543(rtlzz_pipe_337_s2), .y(mul_tree_10_427));
    assign mul_tree_10_428 = ({65'h0, mul_tree_10_400}); // decl: <none>; prim: <none>
    assign mul_tree_10_429 = ({1'h0, mul_tree_10_403}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430_reduce rtlzz_reduce_430(.i544(rtlzz_pipe_340_s2), .i545(rtlzz_pipe_343_s2), .i546(rtlzz_pipe_346_s2), .i547(rtlzz_pipe_349_s2), .y(mul_tree_10_430));
    assign mul_tree_10_431 = ({65'h0, mul_tree_10_406}); // decl: <none>; prim: <none>
    assign mul_tree_10_432 = ({1'h0, mul_tree_10_409}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433_reduce rtlzz_reduce_433(.i548(rtlzz_pipe_352_s2), .i549(rtlzz_pipe_355_s2), .i550(rtlzz_pipe_358_s2), .i551(rtlzz_pipe_361_s2), .y(mul_tree_10_433));
    assign mul_tree_10_434 = ({17'h0, rtlzz_pipe_412_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_435 = ({1'h0, rtlzz_pipe_415_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_437 = ({17'h0, rtlzz_pipe_418_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_438 = ({1'h0, rtlzz_pipe_421_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_440 = ({17'h0, rtlzz_pipe_424_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_441 = ({1'h0, rtlzz_pipe_427_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_443 = ({17'h0, rtlzz_pipe_430_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_444 = ({1'h0, rtlzz_pipe_433_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_446 = ({33'h0, mul_tree_10_436}); // decl: <none>; prim: <none>
    assign mul_tree_10_447 = ({1'h0, mul_tree_10_439}); // decl: <none>; prim: <none>
    assign mul_tree_10_449 = ({33'h0, mul_tree_10_442}); // decl: <none>; prim: <none>
    assign mul_tree_10_450 = ({1'h0, mul_tree_10_445}); // decl: <none>; prim: <none>
    assign mul_tree_10_452 = ({65'h0, mul_tree_10_448}); // decl: <none>; prim: <none>
    assign mul_tree_10_453 = ({1'h0, mul_tree_10_451}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454_reduce rtlzz_reduce_454(.i552(rtlzz_pipe_412_s3), .i553(rtlzz_pipe_415_s3), .i554(rtlzz_pipe_418_s3), .i555(rtlzz_pipe_421_s3), .i556(rtlzz_pipe_424_s3), .i557(rtlzz_pipe_427_s3), .i558(rtlzz_pipe_430_s3), .i559(rtlzz_pipe_433_s3), .y(mul_tree_10_454));
    assign mul_tree_10_455 = mul_tree_10_454[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 32'h0;
            rtlzz_pipe_17_s1 <= 48'h0;
            rtlzz_pipe_21_s1 <= 64'h0;
            rtlzz_pipe_25_s1 <= 80'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 112'h0;
            rtlzz_pipe_37_s1 <= 128'h0;
            rtlzz_pipe_41_s1 <= 144'h0;
            rtlzz_pipe_45_s1 <= 48'h0;
            rtlzz_pipe_49_s1 <= 64'h0;
            rtlzz_pipe_53_s1 <= 80'h0;
            rtlzz_pipe_57_s1 <= 96'h0;
            rtlzz_pipe_61_s1 <= 112'h0;
            rtlzz_pipe_65_s1 <= 128'h0;
            rtlzz_pipe_69_s1 <= 144'h0;
            rtlzz_pipe_73_s1 <= 160'h0;
            rtlzz_pipe_77_s1 <= 64'h0;
            rtlzz_pipe_81_s1 <= 80'h0;
            rtlzz_pipe_85_s1 <= 96'h0;
            rtlzz_pipe_89_s1 <= 112'h0;
            rtlzz_pipe_93_s1 <= 128'h0;
            rtlzz_pipe_97_s1 <= 144'h0;
            rtlzz_pipe_101_s1 <= 160'h0;
            rtlzz_pipe_105_s1 <= 176'h0;
            rtlzz_pipe_109_s1 <= 80'h0;
            rtlzz_pipe_113_s1 <= 96'h0;
            rtlzz_pipe_117_s1 <= 112'h0;
            rtlzz_pipe_121_s1 <= 128'h0;
            rtlzz_pipe_125_s1 <= 144'h0;
            rtlzz_pipe_129_s1 <= 160'h0;
            rtlzz_pipe_133_s1 <= 176'h0;
            rtlzz_pipe_137_s1 <= 192'h0;
            rtlzz_pipe_141_s1 <= 96'h0;
            rtlzz_pipe_145_s1 <= 112'h0;
            rtlzz_pipe_149_s1 <= 128'h0;
            rtlzz_pipe_153_s1 <= 144'h0;
            rtlzz_pipe_157_s1 <= 160'h0;
            rtlzz_pipe_161_s1 <= 176'h0;
            rtlzz_pipe_165_s1 <= 192'h0;
            rtlzz_pipe_169_s1 <= 208'h0;
            rtlzz_pipe_173_s1 <= 112'h0;
            rtlzz_pipe_177_s1 <= 128'h0;
            rtlzz_pipe_181_s1 <= 144'h0;
            rtlzz_pipe_185_s1 <= 160'h0;
            rtlzz_pipe_189_s1 <= 176'h0;
            rtlzz_pipe_193_s1 <= 192'h0;
            rtlzz_pipe_197_s1 <= 208'h0;
            rtlzz_pipe_201_s1 <= 224'h0;
            rtlzz_pipe_205_s1 <= 128'h0;
            rtlzz_pipe_209_s1 <= 144'h0;
            rtlzz_pipe_213_s1 <= 160'h0;
            rtlzz_pipe_217_s1 <= 176'h0;
            rtlzz_pipe_221_s1 <= 192'h0;
            rtlzz_pipe_225_s1 <= 208'h0;
            rtlzz_pipe_229_s1 <= 224'h0;
            rtlzz_pipe_233_s1 <= 240'h0;
            rtlzz_pipe_237_s1 <= 144'h0;
            rtlzz_pipe_241_s1 <= 160'h0;
            rtlzz_pipe_245_s1 <= 176'h0;
            rtlzz_pipe_249_s1 <= 192'h0;
            rtlzz_pipe_253_s1 <= 208'h0;
            rtlzz_pipe_257_s1 <= 224'h0;
            rtlzz_pipe_261_s1 <= 240'h0;
            rtlzz_pipe_265_s1 <= 256'h0;
            rtlzz_pipe_268_s2 <= 49'h0;
            rtlzz_pipe_271_s2 <= 81'h0;
            rtlzz_pipe_274_s2 <= 113'h0;
            rtlzz_pipe_277_s2 <= 145'h0;
            rtlzz_pipe_280_s2 <= 65'h0;
            rtlzz_pipe_283_s2 <= 97'h0;
            rtlzz_pipe_286_s2 <= 129'h0;
            rtlzz_pipe_289_s2 <= 161'h0;
            rtlzz_pipe_292_s2 <= 81'h0;
            rtlzz_pipe_295_s2 <= 113'h0;
            rtlzz_pipe_298_s2 <= 145'h0;
            rtlzz_pipe_301_s2 <= 177'h0;
            rtlzz_pipe_304_s2 <= 97'h0;
            rtlzz_pipe_307_s2 <= 129'h0;
            rtlzz_pipe_310_s2 <= 161'h0;
            rtlzz_pipe_313_s2 <= 193'h0;
            rtlzz_pipe_316_s2 <= 113'h0;
            rtlzz_pipe_319_s2 <= 145'h0;
            rtlzz_pipe_322_s2 <= 177'h0;
            rtlzz_pipe_325_s2 <= 209'h0;
            rtlzz_pipe_328_s2 <= 129'h0;
            rtlzz_pipe_331_s2 <= 161'h0;
            rtlzz_pipe_334_s2 <= 193'h0;
            rtlzz_pipe_337_s2 <= 225'h0;
            rtlzz_pipe_340_s2 <= 145'h0;
            rtlzz_pipe_343_s2 <= 177'h0;
            rtlzz_pipe_346_s2 <= 209'h0;
            rtlzz_pipe_349_s2 <= 241'h0;
            rtlzz_pipe_352_s2 <= 161'h0;
            rtlzz_pipe_355_s2 <= 193'h0;
            rtlzz_pipe_358_s2 <= 225'h0;
            rtlzz_pipe_361_s2 <= 257'h0;
            rtlzz_pipe_412_s3 <= 147'h0;
            rtlzz_pipe_415_s3 <= 163'h0;
            rtlzz_pipe_418_s3 <= 179'h0;
            rtlzz_pipe_421_s3 <= 195'h0;
            rtlzz_pipe_424_s3 <= 211'h0;
            rtlzz_pipe_427_s3 <= 227'h0;
            rtlzz_pipe_430_s3 <= 243'h0;
            rtlzz_pipe_433_s3 <= 259'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= mul_tree_10_77; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_81_s1 <= mul_tree_10_81; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= mul_tree_10_89; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_93_s1 <= mul_tree_10_93; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_tree_10_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_10_105; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_tree_10_113; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_tree_10_117; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_tree_10_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_tree_10_125; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_tree_10_129; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_133_s1 <= mul_tree_10_133; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_137_s1 <= mul_tree_10_137; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_141_s1 <= mul_tree_10_141; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_145_s1 <= mul_tree_10_145; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_149_s1 <= mul_tree_10_149; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_153_s1 <= mul_tree_10_153; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_157_s1 <= mul_tree_10_157; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_161_s1 <= mul_tree_10_161; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_165_s1 <= mul_tree_10_165; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_169_s1 <= mul_tree_10_169; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_173_s1 <= mul_tree_10_173; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_177_s1 <= mul_tree_10_177; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_181_s1 <= mul_tree_10_181; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_185_s1 <= mul_tree_10_185; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_189_s1 <= mul_tree_10_189; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_193_s1 <= mul_tree_10_193; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_197_s1 <= mul_tree_10_197; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_201_s1 <= mul_tree_10_201; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_205_s1 <= mul_tree_10_205; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_209_s1 <= mul_tree_10_209; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_213_s1 <= mul_tree_10_213; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_217_s1 <= mul_tree_10_217; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_221_s1 <= mul_tree_10_221; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_225_s1 <= mul_tree_10_225; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_229_s1 <= mul_tree_10_229; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_233_s1 <= mul_tree_10_233; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_237_s1 <= mul_tree_10_237; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_241_s1 <= mul_tree_10_241; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_245_s1 <= mul_tree_10_245; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= mul_tree_10_249; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_253_s1 <= mul_tree_10_253; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_257_s1 <= mul_tree_10_257; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_261_s1 <= mul_tree_10_261; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= mul_tree_10_265; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_268_s2 <= mul_tree_10_268; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= mul_tree_10_271; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_274_s2 <= mul_tree_10_274; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_277_s2 <= mul_tree_10_277; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_280_s2 <= mul_tree_10_280; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_283_s2 <= mul_tree_10_283; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_286_s2 <= mul_tree_10_286; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_289_s2 <= mul_tree_10_289; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= mul_tree_10_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_295_s2 <= mul_tree_10_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_298_s2 <= mul_tree_10_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_301_s2 <= mul_tree_10_301; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_304_s2 <= mul_tree_10_304; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_307_s2 <= mul_tree_10_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_310_s2 <= mul_tree_10_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_313_s2 <= mul_tree_10_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_316_s2 <= mul_tree_10_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_319_s2 <= mul_tree_10_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_322_s2 <= mul_tree_10_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_325_s2 <= mul_tree_10_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_328_s2 <= mul_tree_10_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_331_s2 <= mul_tree_10_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_334_s2 <= mul_tree_10_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_337_s2 <= mul_tree_10_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_340_s2 <= mul_tree_10_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_343_s2 <= mul_tree_10_343; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_346_s2 <= mul_tree_10_346; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_349_s2 <= mul_tree_10_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_352_s2 <= mul_tree_10_352; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_355_s2 <= mul_tree_10_355; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_358_s2 <= mul_tree_10_358; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_361_s2 <= mul_tree_10_361; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_412_s3 <= mul_tree_10_412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_415_s3 <= mul_tree_10_415; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_418_s3 <= mul_tree_10_418; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_421_s3 <= mul_tree_10_421; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_424_s3 <= mul_tree_10_424; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_427_s3 <= mul_tree_10_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_430_s3 <= mul_tree_10_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_433_s3 <= mul_tree_10_433; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412_reduce(input wire [48:0] i520, input wire [80:0] i521, input wire [112:0] i522, input wire [144:0] i523, output wire [146:0] y);
wire [146:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i520[48], i520[47], i520[46], i520[45], i520[44], i520[43], i520[42], i520[41], i520[40], i520[39], i520[38], i520[37], i520[36], i520[35], i520[34], i520[33], i520[32], i520[31], i520[30], i520[29], i520[28], i520[27], i520[26], i520[25], i520[24], i520[23], i520[22], i520[21], i520[20], i520[19], i520[18], i520[17], i520[16], i520[15], i520[14], i520[13], i520[12], i520[11], i520[10], i520[9], i520[8], i520[7], i520[6], i520[5], i520[4], i520[3], i520[2], i520[1], i520[0]};
wire [146:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i521[80], i521[79], i521[78], i521[77], i521[76], i521[75], i521[74], i521[73], i521[72], i521[71], i521[70], i521[69], i521[68], i521[67], i521[66], i521[65], i521[64], i521[63], i521[62], i521[61], i521[60], i521[59], i521[58], i521[57], i521[56], i521[55], i521[54], i521[53], i521[52], i521[51], i521[50], i521[49], i521[48], i521[47], i521[46], i521[45], i521[44], i521[43], i521[42], i521[41], i521[40], i521[39], i521[38], i521[37], i521[36], i521[35], i521[34], i521[33], i521[32], i521[31], i521[30], i521[29], i521[28], i521[27], i521[26], i521[25], i521[24], i521[23], i521[22], i521[21], i521[20], i521[19], i521[18], i521[17], i521[16], i521[15], i521[14], i521[13], i521[12], i521[11], i521[10], i521[9], i521[8], i521[7], i521[6], i521[5], i521[4], i521[3], i521[2], i521[1], i521[0]};
wire [146:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i522[112], i522[111], i522[110], i522[109], i522[108], i522[107], i522[106], i522[105], i522[104], i522[103], i522[102], i522[101], i522[100], i522[99], i522[98], i522[97], i522[96], i522[95], i522[94], i522[93], i522[92], i522[91], i522[90], i522[89], i522[88], i522[87], i522[86], i522[85], i522[84], i522[83], i522[82], i522[81], i522[80], i522[79], i522[78], i522[77], i522[76], i522[75], i522[74], i522[73], i522[72], i522[71], i522[70], i522[69], i522[68], i522[67], i522[66], i522[65], i522[64], i522[63], i522[62], i522[61], i522[60], i522[59], i522[58], i522[57], i522[56], i522[55], i522[54], i522[53], i522[52], i522[51], i522[50], i522[49], i522[48], i522[47], i522[46], i522[45], i522[44], i522[43], i522[42], i522[41], i522[40], i522[39], i522[38], i522[37], i522[36], i522[35], i522[34], i522[33], i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0]};
wire [146:0] t3 = {1'b0, 1'b0, i523[144], i523[143], i523[142], i523[141], i523[140], i523[139], i523[138], i523[137], i523[136], i523[135], i523[134], i523[133], i523[132], i523[131], i523[130], i523[129], i523[128], i523[127], i523[126], i523[125], i523[124], i523[123], i523[122], i523[121], i523[120], i523[119], i523[118], i523[117], i523[116], i523[115], i523[114], i523[113], i523[112], i523[111], i523[110], i523[109], i523[108], i523[107], i523[106], i523[105], i523[104], i523[103], i523[102], i523[101], i523[100], i523[99], i523[98], i523[97], i523[96], i523[95], i523[94], i523[93], i523[92], i523[91], i523[90], i523[89], i523[88], i523[87], i523[86], i523[85], i523[84], i523[83], i523[82], i523[81], i523[80], i523[79], i523[78], i523[77], i523[76], i523[75], i523[74], i523[73], i523[72], i523[71], i523[70], i523[69], i523[68], i523[67], i523[66], i523[65], i523[64], i523[63], i523[62], i523[61], i523[60], i523[59], i523[58], i523[57], i523[56], i523[55], i523[54], i523[53], i523[52], i523[51], i523[50], i523[49], i523[48], i523[47], i523[46], i523[45], i523[44], i523[43], i523[42], i523[41], i523[40], i523[39], i523[38], i523[37], i523[36], i523[35], i523[34], i523[33], i523[32], i523[31], i523[30], i523[29], i523[28], i523[27], i523[26], i523[25], i523[24], i523[23], i523[22], i523[21], i523[20], i523[19], i523[18], i523[17], i523[16], i523[15], i523[14], i523[13], i523[12], i523[11], i523[10], i523[9], i523[8], i523[7], i523[6], i523[5], i523[4], i523[3], i523[2], i523[1], i523[0]};
wire [146:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415_reduce(input wire [64:0] i524, input wire [96:0] i525, input wire [128:0] i526, input wire [160:0] i527, output wire [162:0] y);
wire [162:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i524[64], i524[63], i524[62], i524[61], i524[60], i524[59], i524[58], i524[57], i524[56], i524[55], i524[54], i524[53], i524[52], i524[51], i524[50], i524[49], i524[48], i524[47], i524[46], i524[45], i524[44], i524[43], i524[42], i524[41], i524[40], i524[39], i524[38], i524[37], i524[36], i524[35], i524[34], i524[33], i524[32], i524[31], i524[30], i524[29], i524[28], i524[27], i524[26], i524[25], i524[24], i524[23], i524[22], i524[21], i524[20], i524[19], i524[18], i524[17], i524[16], i524[15], i524[14], i524[13], i524[12], i524[11], i524[10], i524[9], i524[8], i524[7], i524[6], i524[5], i524[4], i524[3], i524[2], i524[1], i524[0]};
wire [162:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i525[96], i525[95], i525[94], i525[93], i525[92], i525[91], i525[90], i525[89], i525[88], i525[87], i525[86], i525[85], i525[84], i525[83], i525[82], i525[81], i525[80], i525[79], i525[78], i525[77], i525[76], i525[75], i525[74], i525[73], i525[72], i525[71], i525[70], i525[69], i525[68], i525[67], i525[66], i525[65], i525[64], i525[63], i525[62], i525[61], i525[60], i525[59], i525[58], i525[57], i525[56], i525[55], i525[54], i525[53], i525[52], i525[51], i525[50], i525[49], i525[48], i525[47], i525[46], i525[45], i525[44], i525[43], i525[42], i525[41], i525[40], i525[39], i525[38], i525[37], i525[36], i525[35], i525[34], i525[33], i525[32], i525[31], i525[30], i525[29], i525[28], i525[27], i525[26], i525[25], i525[24], i525[23], i525[22], i525[21], i525[20], i525[19], i525[18], i525[17], i525[16], i525[15], i525[14], i525[13], i525[12], i525[11], i525[10], i525[9], i525[8], i525[7], i525[6], i525[5], i525[4], i525[3], i525[2], i525[1], i525[0]};
wire [162:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i526[128], i526[127], i526[126], i526[125], i526[124], i526[123], i526[122], i526[121], i526[120], i526[119], i526[118], i526[117], i526[116], i526[115], i526[114], i526[113], i526[112], i526[111], i526[110], i526[109], i526[108], i526[107], i526[106], i526[105], i526[104], i526[103], i526[102], i526[101], i526[100], i526[99], i526[98], i526[97], i526[96], i526[95], i526[94], i526[93], i526[92], i526[91], i526[90], i526[89], i526[88], i526[87], i526[86], i526[85], i526[84], i526[83], i526[82], i526[81], i526[80], i526[79], i526[78], i526[77], i526[76], i526[75], i526[74], i526[73], i526[72], i526[71], i526[70], i526[69], i526[68], i526[67], i526[66], i526[65], i526[64], i526[63], i526[62], i526[61], i526[60], i526[59], i526[58], i526[57], i526[56], i526[55], i526[54], i526[53], i526[52], i526[51], i526[50], i526[49], i526[48], i526[47], i526[46], i526[45], i526[44], i526[43], i526[42], i526[41], i526[40], i526[39], i526[38], i526[37], i526[36], i526[35], i526[34], i526[33], i526[32], i526[31], i526[30], i526[29], i526[28], i526[27], i526[26], i526[25], i526[24], i526[23], i526[22], i526[21], i526[20], i526[19], i526[18], i526[17], i526[16], i526[15], i526[14], i526[13], i526[12], i526[11], i526[10], i526[9], i526[8], i526[7], i526[6], i526[5], i526[4], i526[3], i526[2], i526[1], i526[0]};
wire [162:0] t3 = {1'b0, 1'b0, i527[160], i527[159], i527[158], i527[157], i527[156], i527[155], i527[154], i527[153], i527[152], i527[151], i527[150], i527[149], i527[148], i527[147], i527[146], i527[145], i527[144], i527[143], i527[142], i527[141], i527[140], i527[139], i527[138], i527[137], i527[136], i527[135], i527[134], i527[133], i527[132], i527[131], i527[130], i527[129], i527[128], i527[127], i527[126], i527[125], i527[124], i527[123], i527[122], i527[121], i527[120], i527[119], i527[118], i527[117], i527[116], i527[115], i527[114], i527[113], i527[112], i527[111], i527[110], i527[109], i527[108], i527[107], i527[106], i527[105], i527[104], i527[103], i527[102], i527[101], i527[100], i527[99], i527[98], i527[97], i527[96], i527[95], i527[94], i527[93], i527[92], i527[91], i527[90], i527[89], i527[88], i527[87], i527[86], i527[85], i527[84], i527[83], i527[82], i527[81], i527[80], i527[79], i527[78], i527[77], i527[76], i527[75], i527[74], i527[73], i527[72], i527[71], i527[70], i527[69], i527[68], i527[67], i527[66], i527[65], i527[64], i527[63], i527[62], i527[61], i527[60], i527[59], i527[58], i527[57], i527[56], i527[55], i527[54], i527[53], i527[52], i527[51], i527[50], i527[49], i527[48], i527[47], i527[46], i527[45], i527[44], i527[43], i527[42], i527[41], i527[40], i527[39], i527[38], i527[37], i527[36], i527[35], i527[34], i527[33], i527[32], i527[31], i527[30], i527[29], i527[28], i527[27], i527[26], i527[25], i527[24], i527[23], i527[22], i527[21], i527[20], i527[19], i527[18], i527[17], i527[16], i527[15], i527[14], i527[13], i527[12], i527[11], i527[10], i527[9], i527[8], i527[7], i527[6], i527[5], i527[4], i527[3], i527[2], i527[1], i527[0]};
wire [162:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_418_reduce(input wire [80:0] i528, input wire [112:0] i529, input wire [144:0] i530, input wire [176:0] i531, output wire [178:0] y);
wire [178:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i528[80], i528[79], i528[78], i528[77], i528[76], i528[75], i528[74], i528[73], i528[72], i528[71], i528[70], i528[69], i528[68], i528[67], i528[66], i528[65], i528[64], i528[63], i528[62], i528[61], i528[60], i528[59], i528[58], i528[57], i528[56], i528[55], i528[54], i528[53], i528[52], i528[51], i528[50], i528[49], i528[48], i528[47], i528[46], i528[45], i528[44], i528[43], i528[42], i528[41], i528[40], i528[39], i528[38], i528[37], i528[36], i528[35], i528[34], i528[33], i528[32], i528[31], i528[30], i528[29], i528[28], i528[27], i528[26], i528[25], i528[24], i528[23], i528[22], i528[21], i528[20], i528[19], i528[18], i528[17], i528[16], i528[15], i528[14], i528[13], i528[12], i528[11], i528[10], i528[9], i528[8], i528[7], i528[6], i528[5], i528[4], i528[3], i528[2], i528[1], i528[0]};
wire [178:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i529[112], i529[111], i529[110], i529[109], i529[108], i529[107], i529[106], i529[105], i529[104], i529[103], i529[102], i529[101], i529[100], i529[99], i529[98], i529[97], i529[96], i529[95], i529[94], i529[93], i529[92], i529[91], i529[90], i529[89], i529[88], i529[87], i529[86], i529[85], i529[84], i529[83], i529[82], i529[81], i529[80], i529[79], i529[78], i529[77], i529[76], i529[75], i529[74], i529[73], i529[72], i529[71], i529[70], i529[69], i529[68], i529[67], i529[66], i529[65], i529[64], i529[63], i529[62], i529[61], i529[60], i529[59], i529[58], i529[57], i529[56], i529[55], i529[54], i529[53], i529[52], i529[51], i529[50], i529[49], i529[48], i529[47], i529[46], i529[45], i529[44], i529[43], i529[42], i529[41], i529[40], i529[39], i529[38], i529[37], i529[36], i529[35], i529[34], i529[33], i529[32], i529[31], i529[30], i529[29], i529[28], i529[27], i529[26], i529[25], i529[24], i529[23], i529[22], i529[21], i529[20], i529[19], i529[18], i529[17], i529[16], i529[15], i529[14], i529[13], i529[12], i529[11], i529[10], i529[9], i529[8], i529[7], i529[6], i529[5], i529[4], i529[3], i529[2], i529[1], i529[0]};
wire [178:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i530[144], i530[143], i530[142], i530[141], i530[140], i530[139], i530[138], i530[137], i530[136], i530[135], i530[134], i530[133], i530[132], i530[131], i530[130], i530[129], i530[128], i530[127], i530[126], i530[125], i530[124], i530[123], i530[122], i530[121], i530[120], i530[119], i530[118], i530[117], i530[116], i530[115], i530[114], i530[113], i530[112], i530[111], i530[110], i530[109], i530[108], i530[107], i530[106], i530[105], i530[104], i530[103], i530[102], i530[101], i530[100], i530[99], i530[98], i530[97], i530[96], i530[95], i530[94], i530[93], i530[92], i530[91], i530[90], i530[89], i530[88], i530[87], i530[86], i530[85], i530[84], i530[83], i530[82], i530[81], i530[80], i530[79], i530[78], i530[77], i530[76], i530[75], i530[74], i530[73], i530[72], i530[71], i530[70], i530[69], i530[68], i530[67], i530[66], i530[65], i530[64], i530[63], i530[62], i530[61], i530[60], i530[59], i530[58], i530[57], i530[56], i530[55], i530[54], i530[53], i530[52], i530[51], i530[50], i530[49], i530[48], i530[47], i530[46], i530[45], i530[44], i530[43], i530[42], i530[41], i530[40], i530[39], i530[38], i530[37], i530[36], i530[35], i530[34], i530[33], i530[32], i530[31], i530[30], i530[29], i530[28], i530[27], i530[26], i530[25], i530[24], i530[23], i530[22], i530[21], i530[20], i530[19], i530[18], i530[17], i530[16], i530[15], i530[14], i530[13], i530[12], i530[11], i530[10], i530[9], i530[8], i530[7], i530[6], i530[5], i530[4], i530[3], i530[2], i530[1], i530[0]};
wire [178:0] t3 = {1'b0, 1'b0, i531[176], i531[175], i531[174], i531[173], i531[172], i531[171], i531[170], i531[169], i531[168], i531[167], i531[166], i531[165], i531[164], i531[163], i531[162], i531[161], i531[160], i531[159], i531[158], i531[157], i531[156], i531[155], i531[154], i531[153], i531[152], i531[151], i531[150], i531[149], i531[148], i531[147], i531[146], i531[145], i531[144], i531[143], i531[142], i531[141], i531[140], i531[139], i531[138], i531[137], i531[136], i531[135], i531[134], i531[133], i531[132], i531[131], i531[130], i531[129], i531[128], i531[127], i531[126], i531[125], i531[124], i531[123], i531[122], i531[121], i531[120], i531[119], i531[118], i531[117], i531[116], i531[115], i531[114], i531[113], i531[112], i531[111], i531[110], i531[109], i531[108], i531[107], i531[106], i531[105], i531[104], i531[103], i531[102], i531[101], i531[100], i531[99], i531[98], i531[97], i531[96], i531[95], i531[94], i531[93], i531[92], i531[91], i531[90], i531[89], i531[88], i531[87], i531[86], i531[85], i531[84], i531[83], i531[82], i531[81], i531[80], i531[79], i531[78], i531[77], i531[76], i531[75], i531[74], i531[73], i531[72], i531[71], i531[70], i531[69], i531[68], i531[67], i531[66], i531[65], i531[64], i531[63], i531[62], i531[61], i531[60], i531[59], i531[58], i531[57], i531[56], i531[55], i531[54], i531[53], i531[52], i531[51], i531[50], i531[49], i531[48], i531[47], i531[46], i531[45], i531[44], i531[43], i531[42], i531[41], i531[40], i531[39], i531[38], i531[37], i531[36], i531[35], i531[34], i531[33], i531[32], i531[31], i531[30], i531[29], i531[28], i531[27], i531[26], i531[25], i531[24], i531[23], i531[22], i531[21], i531[20], i531[19], i531[18], i531[17], i531[16], i531[15], i531[14], i531[13], i531[12], i531[11], i531[10], i531[9], i531[8], i531[7], i531[6], i531[5], i531[4], i531[3], i531[2], i531[1], i531[0]};
wire [178:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_421_reduce(input wire [96:0] i532, input wire [128:0] i533, input wire [160:0] i534, input wire [192:0] i535, output wire [194:0] y);
wire [194:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i532[96], i532[95], i532[94], i532[93], i532[92], i532[91], i532[90], i532[89], i532[88], i532[87], i532[86], i532[85], i532[84], i532[83], i532[82], i532[81], i532[80], i532[79], i532[78], i532[77], i532[76], i532[75], i532[74], i532[73], i532[72], i532[71], i532[70], i532[69], i532[68], i532[67], i532[66], i532[65], i532[64], i532[63], i532[62], i532[61], i532[60], i532[59], i532[58], i532[57], i532[56], i532[55], i532[54], i532[53], i532[52], i532[51], i532[50], i532[49], i532[48], i532[47], i532[46], i532[45], i532[44], i532[43], i532[42], i532[41], i532[40], i532[39], i532[38], i532[37], i532[36], i532[35], i532[34], i532[33], i532[32], i532[31], i532[30], i532[29], i532[28], i532[27], i532[26], i532[25], i532[24], i532[23], i532[22], i532[21], i532[20], i532[19], i532[18], i532[17], i532[16], i532[15], i532[14], i532[13], i532[12], i532[11], i532[10], i532[9], i532[8], i532[7], i532[6], i532[5], i532[4], i532[3], i532[2], i532[1], i532[0]};
wire [194:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i533[128], i533[127], i533[126], i533[125], i533[124], i533[123], i533[122], i533[121], i533[120], i533[119], i533[118], i533[117], i533[116], i533[115], i533[114], i533[113], i533[112], i533[111], i533[110], i533[109], i533[108], i533[107], i533[106], i533[105], i533[104], i533[103], i533[102], i533[101], i533[100], i533[99], i533[98], i533[97], i533[96], i533[95], i533[94], i533[93], i533[92], i533[91], i533[90], i533[89], i533[88], i533[87], i533[86], i533[85], i533[84], i533[83], i533[82], i533[81], i533[80], i533[79], i533[78], i533[77], i533[76], i533[75], i533[74], i533[73], i533[72], i533[71], i533[70], i533[69], i533[68], i533[67], i533[66], i533[65], i533[64], i533[63], i533[62], i533[61], i533[60], i533[59], i533[58], i533[57], i533[56], i533[55], i533[54], i533[53], i533[52], i533[51], i533[50], i533[49], i533[48], i533[47], i533[46], i533[45], i533[44], i533[43], i533[42], i533[41], i533[40], i533[39], i533[38], i533[37], i533[36], i533[35], i533[34], i533[33], i533[32], i533[31], i533[30], i533[29], i533[28], i533[27], i533[26], i533[25], i533[24], i533[23], i533[22], i533[21], i533[20], i533[19], i533[18], i533[17], i533[16], i533[15], i533[14], i533[13], i533[12], i533[11], i533[10], i533[9], i533[8], i533[7], i533[6], i533[5], i533[4], i533[3], i533[2], i533[1], i533[0]};
wire [194:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i534[160], i534[159], i534[158], i534[157], i534[156], i534[155], i534[154], i534[153], i534[152], i534[151], i534[150], i534[149], i534[148], i534[147], i534[146], i534[145], i534[144], i534[143], i534[142], i534[141], i534[140], i534[139], i534[138], i534[137], i534[136], i534[135], i534[134], i534[133], i534[132], i534[131], i534[130], i534[129], i534[128], i534[127], i534[126], i534[125], i534[124], i534[123], i534[122], i534[121], i534[120], i534[119], i534[118], i534[117], i534[116], i534[115], i534[114], i534[113], i534[112], i534[111], i534[110], i534[109], i534[108], i534[107], i534[106], i534[105], i534[104], i534[103], i534[102], i534[101], i534[100], i534[99], i534[98], i534[97], i534[96], i534[95], i534[94], i534[93], i534[92], i534[91], i534[90], i534[89], i534[88], i534[87], i534[86], i534[85], i534[84], i534[83], i534[82], i534[81], i534[80], i534[79], i534[78], i534[77], i534[76], i534[75], i534[74], i534[73], i534[72], i534[71], i534[70], i534[69], i534[68], i534[67], i534[66], i534[65], i534[64], i534[63], i534[62], i534[61], i534[60], i534[59], i534[58], i534[57], i534[56], i534[55], i534[54], i534[53], i534[52], i534[51], i534[50], i534[49], i534[48], i534[47], i534[46], i534[45], i534[44], i534[43], i534[42], i534[41], i534[40], i534[39], i534[38], i534[37], i534[36], i534[35], i534[34], i534[33], i534[32], i534[31], i534[30], i534[29], i534[28], i534[27], i534[26], i534[25], i534[24], i534[23], i534[22], i534[21], i534[20], i534[19], i534[18], i534[17], i534[16], i534[15], i534[14], i534[13], i534[12], i534[11], i534[10], i534[9], i534[8], i534[7], i534[6], i534[5], i534[4], i534[3], i534[2], i534[1], i534[0]};
wire [194:0] t3 = {1'b0, 1'b0, i535[192], i535[191], i535[190], i535[189], i535[188], i535[187], i535[186], i535[185], i535[184], i535[183], i535[182], i535[181], i535[180], i535[179], i535[178], i535[177], i535[176], i535[175], i535[174], i535[173], i535[172], i535[171], i535[170], i535[169], i535[168], i535[167], i535[166], i535[165], i535[164], i535[163], i535[162], i535[161], i535[160], i535[159], i535[158], i535[157], i535[156], i535[155], i535[154], i535[153], i535[152], i535[151], i535[150], i535[149], i535[148], i535[147], i535[146], i535[145], i535[144], i535[143], i535[142], i535[141], i535[140], i535[139], i535[138], i535[137], i535[136], i535[135], i535[134], i535[133], i535[132], i535[131], i535[130], i535[129], i535[128], i535[127], i535[126], i535[125], i535[124], i535[123], i535[122], i535[121], i535[120], i535[119], i535[118], i535[117], i535[116], i535[115], i535[114], i535[113], i535[112], i535[111], i535[110], i535[109], i535[108], i535[107], i535[106], i535[105], i535[104], i535[103], i535[102], i535[101], i535[100], i535[99], i535[98], i535[97], i535[96], i535[95], i535[94], i535[93], i535[92], i535[91], i535[90], i535[89], i535[88], i535[87], i535[86], i535[85], i535[84], i535[83], i535[82], i535[81], i535[80], i535[79], i535[78], i535[77], i535[76], i535[75], i535[74], i535[73], i535[72], i535[71], i535[70], i535[69], i535[68], i535[67], i535[66], i535[65], i535[64], i535[63], i535[62], i535[61], i535[60], i535[59], i535[58], i535[57], i535[56], i535[55], i535[54], i535[53], i535[52], i535[51], i535[50], i535[49], i535[48], i535[47], i535[46], i535[45], i535[44], i535[43], i535[42], i535[41], i535[40], i535[39], i535[38], i535[37], i535[36], i535[35], i535[34], i535[33], i535[32], i535[31], i535[30], i535[29], i535[28], i535[27], i535[26], i535[25], i535[24], i535[23], i535[22], i535[21], i535[20], i535[19], i535[18], i535[17], i535[16], i535[15], i535[14], i535[13], i535[12], i535[11], i535[10], i535[9], i535[8], i535[7], i535[6], i535[5], i535[4], i535[3], i535[2], i535[1], i535[0]};
wire [194:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_424_reduce(input wire [112:0] i536, input wire [144:0] i537, input wire [176:0] i538, input wire [208:0] i539, output wire [210:0] y);
wire [210:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i536[112], i536[111], i536[110], i536[109], i536[108], i536[107], i536[106], i536[105], i536[104], i536[103], i536[102], i536[101], i536[100], i536[99], i536[98], i536[97], i536[96], i536[95], i536[94], i536[93], i536[92], i536[91], i536[90], i536[89], i536[88], i536[87], i536[86], i536[85], i536[84], i536[83], i536[82], i536[81], i536[80], i536[79], i536[78], i536[77], i536[76], i536[75], i536[74], i536[73], i536[72], i536[71], i536[70], i536[69], i536[68], i536[67], i536[66], i536[65], i536[64], i536[63], i536[62], i536[61], i536[60], i536[59], i536[58], i536[57], i536[56], i536[55], i536[54], i536[53], i536[52], i536[51], i536[50], i536[49], i536[48], i536[47], i536[46], i536[45], i536[44], i536[43], i536[42], i536[41], i536[40], i536[39], i536[38], i536[37], i536[36], i536[35], i536[34], i536[33], i536[32], i536[31], i536[30], i536[29], i536[28], i536[27], i536[26], i536[25], i536[24], i536[23], i536[22], i536[21], i536[20], i536[19], i536[18], i536[17], i536[16], i536[15], i536[14], i536[13], i536[12], i536[11], i536[10], i536[9], i536[8], i536[7], i536[6], i536[5], i536[4], i536[3], i536[2], i536[1], i536[0]};
wire [210:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i537[144], i537[143], i537[142], i537[141], i537[140], i537[139], i537[138], i537[137], i537[136], i537[135], i537[134], i537[133], i537[132], i537[131], i537[130], i537[129], i537[128], i537[127], i537[126], i537[125], i537[124], i537[123], i537[122], i537[121], i537[120], i537[119], i537[118], i537[117], i537[116], i537[115], i537[114], i537[113], i537[112], i537[111], i537[110], i537[109], i537[108], i537[107], i537[106], i537[105], i537[104], i537[103], i537[102], i537[101], i537[100], i537[99], i537[98], i537[97], i537[96], i537[95], i537[94], i537[93], i537[92], i537[91], i537[90], i537[89], i537[88], i537[87], i537[86], i537[85], i537[84], i537[83], i537[82], i537[81], i537[80], i537[79], i537[78], i537[77], i537[76], i537[75], i537[74], i537[73], i537[72], i537[71], i537[70], i537[69], i537[68], i537[67], i537[66], i537[65], i537[64], i537[63], i537[62], i537[61], i537[60], i537[59], i537[58], i537[57], i537[56], i537[55], i537[54], i537[53], i537[52], i537[51], i537[50], i537[49], i537[48], i537[47], i537[46], i537[45], i537[44], i537[43], i537[42], i537[41], i537[40], i537[39], i537[38], i537[37], i537[36], i537[35], i537[34], i537[33], i537[32], i537[31], i537[30], i537[29], i537[28], i537[27], i537[26], i537[25], i537[24], i537[23], i537[22], i537[21], i537[20], i537[19], i537[18], i537[17], i537[16], i537[15], i537[14], i537[13], i537[12], i537[11], i537[10], i537[9], i537[8], i537[7], i537[6], i537[5], i537[4], i537[3], i537[2], i537[1], i537[0]};
wire [210:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i538[176], i538[175], i538[174], i538[173], i538[172], i538[171], i538[170], i538[169], i538[168], i538[167], i538[166], i538[165], i538[164], i538[163], i538[162], i538[161], i538[160], i538[159], i538[158], i538[157], i538[156], i538[155], i538[154], i538[153], i538[152], i538[151], i538[150], i538[149], i538[148], i538[147], i538[146], i538[145], i538[144], i538[143], i538[142], i538[141], i538[140], i538[139], i538[138], i538[137], i538[136], i538[135], i538[134], i538[133], i538[132], i538[131], i538[130], i538[129], i538[128], i538[127], i538[126], i538[125], i538[124], i538[123], i538[122], i538[121], i538[120], i538[119], i538[118], i538[117], i538[116], i538[115], i538[114], i538[113], i538[112], i538[111], i538[110], i538[109], i538[108], i538[107], i538[106], i538[105], i538[104], i538[103], i538[102], i538[101], i538[100], i538[99], i538[98], i538[97], i538[96], i538[95], i538[94], i538[93], i538[92], i538[91], i538[90], i538[89], i538[88], i538[87], i538[86], i538[85], i538[84], i538[83], i538[82], i538[81], i538[80], i538[79], i538[78], i538[77], i538[76], i538[75], i538[74], i538[73], i538[72], i538[71], i538[70], i538[69], i538[68], i538[67], i538[66], i538[65], i538[64], i538[63], i538[62], i538[61], i538[60], i538[59], i538[58], i538[57], i538[56], i538[55], i538[54], i538[53], i538[52], i538[51], i538[50], i538[49], i538[48], i538[47], i538[46], i538[45], i538[44], i538[43], i538[42], i538[41], i538[40], i538[39], i538[38], i538[37], i538[36], i538[35], i538[34], i538[33], i538[32], i538[31], i538[30], i538[29], i538[28], i538[27], i538[26], i538[25], i538[24], i538[23], i538[22], i538[21], i538[20], i538[19], i538[18], i538[17], i538[16], i538[15], i538[14], i538[13], i538[12], i538[11], i538[10], i538[9], i538[8], i538[7], i538[6], i538[5], i538[4], i538[3], i538[2], i538[1], i538[0]};
wire [210:0] t3 = {1'b0, 1'b0, i539[208], i539[207], i539[206], i539[205], i539[204], i539[203], i539[202], i539[201], i539[200], i539[199], i539[198], i539[197], i539[196], i539[195], i539[194], i539[193], i539[192], i539[191], i539[190], i539[189], i539[188], i539[187], i539[186], i539[185], i539[184], i539[183], i539[182], i539[181], i539[180], i539[179], i539[178], i539[177], i539[176], i539[175], i539[174], i539[173], i539[172], i539[171], i539[170], i539[169], i539[168], i539[167], i539[166], i539[165], i539[164], i539[163], i539[162], i539[161], i539[160], i539[159], i539[158], i539[157], i539[156], i539[155], i539[154], i539[153], i539[152], i539[151], i539[150], i539[149], i539[148], i539[147], i539[146], i539[145], i539[144], i539[143], i539[142], i539[141], i539[140], i539[139], i539[138], i539[137], i539[136], i539[135], i539[134], i539[133], i539[132], i539[131], i539[130], i539[129], i539[128], i539[127], i539[126], i539[125], i539[124], i539[123], i539[122], i539[121], i539[120], i539[119], i539[118], i539[117], i539[116], i539[115], i539[114], i539[113], i539[112], i539[111], i539[110], i539[109], i539[108], i539[107], i539[106], i539[105], i539[104], i539[103], i539[102], i539[101], i539[100], i539[99], i539[98], i539[97], i539[96], i539[95], i539[94], i539[93], i539[92], i539[91], i539[90], i539[89], i539[88], i539[87], i539[86], i539[85], i539[84], i539[83], i539[82], i539[81], i539[80], i539[79], i539[78], i539[77], i539[76], i539[75], i539[74], i539[73], i539[72], i539[71], i539[70], i539[69], i539[68], i539[67], i539[66], i539[65], i539[64], i539[63], i539[62], i539[61], i539[60], i539[59], i539[58], i539[57], i539[56], i539[55], i539[54], i539[53], i539[52], i539[51], i539[50], i539[49], i539[48], i539[47], i539[46], i539[45], i539[44], i539[43], i539[42], i539[41], i539[40], i539[39], i539[38], i539[37], i539[36], i539[35], i539[34], i539[33], i539[32], i539[31], i539[30], i539[29], i539[28], i539[27], i539[26], i539[25], i539[24], i539[23], i539[22], i539[21], i539[20], i539[19], i539[18], i539[17], i539[16], i539[15], i539[14], i539[13], i539[12], i539[11], i539[10], i539[9], i539[8], i539[7], i539[6], i539[5], i539[4], i539[3], i539[2], i539[1], i539[0]};
wire [210:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427_reduce(input wire [128:0] i540, input wire [160:0] i541, input wire [192:0] i542, input wire [224:0] i543, output wire [226:0] y);
wire [226:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i540[128], i540[127], i540[126], i540[125], i540[124], i540[123], i540[122], i540[121], i540[120], i540[119], i540[118], i540[117], i540[116], i540[115], i540[114], i540[113], i540[112], i540[111], i540[110], i540[109], i540[108], i540[107], i540[106], i540[105], i540[104], i540[103], i540[102], i540[101], i540[100], i540[99], i540[98], i540[97], i540[96], i540[95], i540[94], i540[93], i540[92], i540[91], i540[90], i540[89], i540[88], i540[87], i540[86], i540[85], i540[84], i540[83], i540[82], i540[81], i540[80], i540[79], i540[78], i540[77], i540[76], i540[75], i540[74], i540[73], i540[72], i540[71], i540[70], i540[69], i540[68], i540[67], i540[66], i540[65], i540[64], i540[63], i540[62], i540[61], i540[60], i540[59], i540[58], i540[57], i540[56], i540[55], i540[54], i540[53], i540[52], i540[51], i540[50], i540[49], i540[48], i540[47], i540[46], i540[45], i540[44], i540[43], i540[42], i540[41], i540[40], i540[39], i540[38], i540[37], i540[36], i540[35], i540[34], i540[33], i540[32], i540[31], i540[30], i540[29], i540[28], i540[27], i540[26], i540[25], i540[24], i540[23], i540[22], i540[21], i540[20], i540[19], i540[18], i540[17], i540[16], i540[15], i540[14], i540[13], i540[12], i540[11], i540[10], i540[9], i540[8], i540[7], i540[6], i540[5], i540[4], i540[3], i540[2], i540[1], i540[0]};
wire [226:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i541[160], i541[159], i541[158], i541[157], i541[156], i541[155], i541[154], i541[153], i541[152], i541[151], i541[150], i541[149], i541[148], i541[147], i541[146], i541[145], i541[144], i541[143], i541[142], i541[141], i541[140], i541[139], i541[138], i541[137], i541[136], i541[135], i541[134], i541[133], i541[132], i541[131], i541[130], i541[129], i541[128], i541[127], i541[126], i541[125], i541[124], i541[123], i541[122], i541[121], i541[120], i541[119], i541[118], i541[117], i541[116], i541[115], i541[114], i541[113], i541[112], i541[111], i541[110], i541[109], i541[108], i541[107], i541[106], i541[105], i541[104], i541[103], i541[102], i541[101], i541[100], i541[99], i541[98], i541[97], i541[96], i541[95], i541[94], i541[93], i541[92], i541[91], i541[90], i541[89], i541[88], i541[87], i541[86], i541[85], i541[84], i541[83], i541[82], i541[81], i541[80], i541[79], i541[78], i541[77], i541[76], i541[75], i541[74], i541[73], i541[72], i541[71], i541[70], i541[69], i541[68], i541[67], i541[66], i541[65], i541[64], i541[63], i541[62], i541[61], i541[60], i541[59], i541[58], i541[57], i541[56], i541[55], i541[54], i541[53], i541[52], i541[51], i541[50], i541[49], i541[48], i541[47], i541[46], i541[45], i541[44], i541[43], i541[42], i541[41], i541[40], i541[39], i541[38], i541[37], i541[36], i541[35], i541[34], i541[33], i541[32], i541[31], i541[30], i541[29], i541[28], i541[27], i541[26], i541[25], i541[24], i541[23], i541[22], i541[21], i541[20], i541[19], i541[18], i541[17], i541[16], i541[15], i541[14], i541[13], i541[12], i541[11], i541[10], i541[9], i541[8], i541[7], i541[6], i541[5], i541[4], i541[3], i541[2], i541[1], i541[0]};
wire [226:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i542[192], i542[191], i542[190], i542[189], i542[188], i542[187], i542[186], i542[185], i542[184], i542[183], i542[182], i542[181], i542[180], i542[179], i542[178], i542[177], i542[176], i542[175], i542[174], i542[173], i542[172], i542[171], i542[170], i542[169], i542[168], i542[167], i542[166], i542[165], i542[164], i542[163], i542[162], i542[161], i542[160], i542[159], i542[158], i542[157], i542[156], i542[155], i542[154], i542[153], i542[152], i542[151], i542[150], i542[149], i542[148], i542[147], i542[146], i542[145], i542[144], i542[143], i542[142], i542[141], i542[140], i542[139], i542[138], i542[137], i542[136], i542[135], i542[134], i542[133], i542[132], i542[131], i542[130], i542[129], i542[128], i542[127], i542[126], i542[125], i542[124], i542[123], i542[122], i542[121], i542[120], i542[119], i542[118], i542[117], i542[116], i542[115], i542[114], i542[113], i542[112], i542[111], i542[110], i542[109], i542[108], i542[107], i542[106], i542[105], i542[104], i542[103], i542[102], i542[101], i542[100], i542[99], i542[98], i542[97], i542[96], i542[95], i542[94], i542[93], i542[92], i542[91], i542[90], i542[89], i542[88], i542[87], i542[86], i542[85], i542[84], i542[83], i542[82], i542[81], i542[80], i542[79], i542[78], i542[77], i542[76], i542[75], i542[74], i542[73], i542[72], i542[71], i542[70], i542[69], i542[68], i542[67], i542[66], i542[65], i542[64], i542[63], i542[62], i542[61], i542[60], i542[59], i542[58], i542[57], i542[56], i542[55], i542[54], i542[53], i542[52], i542[51], i542[50], i542[49], i542[48], i542[47], i542[46], i542[45], i542[44], i542[43], i542[42], i542[41], i542[40], i542[39], i542[38], i542[37], i542[36], i542[35], i542[34], i542[33], i542[32], i542[31], i542[30], i542[29], i542[28], i542[27], i542[26], i542[25], i542[24], i542[23], i542[22], i542[21], i542[20], i542[19], i542[18], i542[17], i542[16], i542[15], i542[14], i542[13], i542[12], i542[11], i542[10], i542[9], i542[8], i542[7], i542[6], i542[5], i542[4], i542[3], i542[2], i542[1], i542[0]};
wire [226:0] t3 = {1'b0, 1'b0, i543[224], i543[223], i543[222], i543[221], i543[220], i543[219], i543[218], i543[217], i543[216], i543[215], i543[214], i543[213], i543[212], i543[211], i543[210], i543[209], i543[208], i543[207], i543[206], i543[205], i543[204], i543[203], i543[202], i543[201], i543[200], i543[199], i543[198], i543[197], i543[196], i543[195], i543[194], i543[193], i543[192], i543[191], i543[190], i543[189], i543[188], i543[187], i543[186], i543[185], i543[184], i543[183], i543[182], i543[181], i543[180], i543[179], i543[178], i543[177], i543[176], i543[175], i543[174], i543[173], i543[172], i543[171], i543[170], i543[169], i543[168], i543[167], i543[166], i543[165], i543[164], i543[163], i543[162], i543[161], i543[160], i543[159], i543[158], i543[157], i543[156], i543[155], i543[154], i543[153], i543[152], i543[151], i543[150], i543[149], i543[148], i543[147], i543[146], i543[145], i543[144], i543[143], i543[142], i543[141], i543[140], i543[139], i543[138], i543[137], i543[136], i543[135], i543[134], i543[133], i543[132], i543[131], i543[130], i543[129], i543[128], i543[127], i543[126], i543[125], i543[124], i543[123], i543[122], i543[121], i543[120], i543[119], i543[118], i543[117], i543[116], i543[115], i543[114], i543[113], i543[112], i543[111], i543[110], i543[109], i543[108], i543[107], i543[106], i543[105], i543[104], i543[103], i543[102], i543[101], i543[100], i543[99], i543[98], i543[97], i543[96], i543[95], i543[94], i543[93], i543[92], i543[91], i543[90], i543[89], i543[88], i543[87], i543[86], i543[85], i543[84], i543[83], i543[82], i543[81], i543[80], i543[79], i543[78], i543[77], i543[76], i543[75], i543[74], i543[73], i543[72], i543[71], i543[70], i543[69], i543[68], i543[67], i543[66], i543[65], i543[64], i543[63], i543[62], i543[61], i543[60], i543[59], i543[58], i543[57], i543[56], i543[55], i543[54], i543[53], i543[52], i543[51], i543[50], i543[49], i543[48], i543[47], i543[46], i543[45], i543[44], i543[43], i543[42], i543[41], i543[40], i543[39], i543[38], i543[37], i543[36], i543[35], i543[34], i543[33], i543[32], i543[31], i543[30], i543[29], i543[28], i543[27], i543[26], i543[25], i543[24], i543[23], i543[22], i543[21], i543[20], i543[19], i543[18], i543[17], i543[16], i543[15], i543[14], i543[13], i543[12], i543[11], i543[10], i543[9], i543[8], i543[7], i543[6], i543[5], i543[4], i543[3], i543[2], i543[1], i543[0]};
wire [226:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430_reduce(input wire [144:0] i544, input wire [176:0] i545, input wire [208:0] i546, input wire [240:0] i547, output wire [242:0] y);
wire [242:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i544[144], i544[143], i544[142], i544[141], i544[140], i544[139], i544[138], i544[137], i544[136], i544[135], i544[134], i544[133], i544[132], i544[131], i544[130], i544[129], i544[128], i544[127], i544[126], i544[125], i544[124], i544[123], i544[122], i544[121], i544[120], i544[119], i544[118], i544[117], i544[116], i544[115], i544[114], i544[113], i544[112], i544[111], i544[110], i544[109], i544[108], i544[107], i544[106], i544[105], i544[104], i544[103], i544[102], i544[101], i544[100], i544[99], i544[98], i544[97], i544[96], i544[95], i544[94], i544[93], i544[92], i544[91], i544[90], i544[89], i544[88], i544[87], i544[86], i544[85], i544[84], i544[83], i544[82], i544[81], i544[80], i544[79], i544[78], i544[77], i544[76], i544[75], i544[74], i544[73], i544[72], i544[71], i544[70], i544[69], i544[68], i544[67], i544[66], i544[65], i544[64], i544[63], i544[62], i544[61], i544[60], i544[59], i544[58], i544[57], i544[56], i544[55], i544[54], i544[53], i544[52], i544[51], i544[50], i544[49], i544[48], i544[47], i544[46], i544[45], i544[44], i544[43], i544[42], i544[41], i544[40], i544[39], i544[38], i544[37], i544[36], i544[35], i544[34], i544[33], i544[32], i544[31], i544[30], i544[29], i544[28], i544[27], i544[26], i544[25], i544[24], i544[23], i544[22], i544[21], i544[20], i544[19], i544[18], i544[17], i544[16], i544[15], i544[14], i544[13], i544[12], i544[11], i544[10], i544[9], i544[8], i544[7], i544[6], i544[5], i544[4], i544[3], i544[2], i544[1], i544[0]};
wire [242:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i545[176], i545[175], i545[174], i545[173], i545[172], i545[171], i545[170], i545[169], i545[168], i545[167], i545[166], i545[165], i545[164], i545[163], i545[162], i545[161], i545[160], i545[159], i545[158], i545[157], i545[156], i545[155], i545[154], i545[153], i545[152], i545[151], i545[150], i545[149], i545[148], i545[147], i545[146], i545[145], i545[144], i545[143], i545[142], i545[141], i545[140], i545[139], i545[138], i545[137], i545[136], i545[135], i545[134], i545[133], i545[132], i545[131], i545[130], i545[129], i545[128], i545[127], i545[126], i545[125], i545[124], i545[123], i545[122], i545[121], i545[120], i545[119], i545[118], i545[117], i545[116], i545[115], i545[114], i545[113], i545[112], i545[111], i545[110], i545[109], i545[108], i545[107], i545[106], i545[105], i545[104], i545[103], i545[102], i545[101], i545[100], i545[99], i545[98], i545[97], i545[96], i545[95], i545[94], i545[93], i545[92], i545[91], i545[90], i545[89], i545[88], i545[87], i545[86], i545[85], i545[84], i545[83], i545[82], i545[81], i545[80], i545[79], i545[78], i545[77], i545[76], i545[75], i545[74], i545[73], i545[72], i545[71], i545[70], i545[69], i545[68], i545[67], i545[66], i545[65], i545[64], i545[63], i545[62], i545[61], i545[60], i545[59], i545[58], i545[57], i545[56], i545[55], i545[54], i545[53], i545[52], i545[51], i545[50], i545[49], i545[48], i545[47], i545[46], i545[45], i545[44], i545[43], i545[42], i545[41], i545[40], i545[39], i545[38], i545[37], i545[36], i545[35], i545[34], i545[33], i545[32], i545[31], i545[30], i545[29], i545[28], i545[27], i545[26], i545[25], i545[24], i545[23], i545[22], i545[21], i545[20], i545[19], i545[18], i545[17], i545[16], i545[15], i545[14], i545[13], i545[12], i545[11], i545[10], i545[9], i545[8], i545[7], i545[6], i545[5], i545[4], i545[3], i545[2], i545[1], i545[0]};
wire [242:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i546[208], i546[207], i546[206], i546[205], i546[204], i546[203], i546[202], i546[201], i546[200], i546[199], i546[198], i546[197], i546[196], i546[195], i546[194], i546[193], i546[192], i546[191], i546[190], i546[189], i546[188], i546[187], i546[186], i546[185], i546[184], i546[183], i546[182], i546[181], i546[180], i546[179], i546[178], i546[177], i546[176], i546[175], i546[174], i546[173], i546[172], i546[171], i546[170], i546[169], i546[168], i546[167], i546[166], i546[165], i546[164], i546[163], i546[162], i546[161], i546[160], i546[159], i546[158], i546[157], i546[156], i546[155], i546[154], i546[153], i546[152], i546[151], i546[150], i546[149], i546[148], i546[147], i546[146], i546[145], i546[144], i546[143], i546[142], i546[141], i546[140], i546[139], i546[138], i546[137], i546[136], i546[135], i546[134], i546[133], i546[132], i546[131], i546[130], i546[129], i546[128], i546[127], i546[126], i546[125], i546[124], i546[123], i546[122], i546[121], i546[120], i546[119], i546[118], i546[117], i546[116], i546[115], i546[114], i546[113], i546[112], i546[111], i546[110], i546[109], i546[108], i546[107], i546[106], i546[105], i546[104], i546[103], i546[102], i546[101], i546[100], i546[99], i546[98], i546[97], i546[96], i546[95], i546[94], i546[93], i546[92], i546[91], i546[90], i546[89], i546[88], i546[87], i546[86], i546[85], i546[84], i546[83], i546[82], i546[81], i546[80], i546[79], i546[78], i546[77], i546[76], i546[75], i546[74], i546[73], i546[72], i546[71], i546[70], i546[69], i546[68], i546[67], i546[66], i546[65], i546[64], i546[63], i546[62], i546[61], i546[60], i546[59], i546[58], i546[57], i546[56], i546[55], i546[54], i546[53], i546[52], i546[51], i546[50], i546[49], i546[48], i546[47], i546[46], i546[45], i546[44], i546[43], i546[42], i546[41], i546[40], i546[39], i546[38], i546[37], i546[36], i546[35], i546[34], i546[33], i546[32], i546[31], i546[30], i546[29], i546[28], i546[27], i546[26], i546[25], i546[24], i546[23], i546[22], i546[21], i546[20], i546[19], i546[18], i546[17], i546[16], i546[15], i546[14], i546[13], i546[12], i546[11], i546[10], i546[9], i546[8], i546[7], i546[6], i546[5], i546[4], i546[3], i546[2], i546[1], i546[0]};
wire [242:0] t3 = {1'b0, 1'b0, i547[240], i547[239], i547[238], i547[237], i547[236], i547[235], i547[234], i547[233], i547[232], i547[231], i547[230], i547[229], i547[228], i547[227], i547[226], i547[225], i547[224], i547[223], i547[222], i547[221], i547[220], i547[219], i547[218], i547[217], i547[216], i547[215], i547[214], i547[213], i547[212], i547[211], i547[210], i547[209], i547[208], i547[207], i547[206], i547[205], i547[204], i547[203], i547[202], i547[201], i547[200], i547[199], i547[198], i547[197], i547[196], i547[195], i547[194], i547[193], i547[192], i547[191], i547[190], i547[189], i547[188], i547[187], i547[186], i547[185], i547[184], i547[183], i547[182], i547[181], i547[180], i547[179], i547[178], i547[177], i547[176], i547[175], i547[174], i547[173], i547[172], i547[171], i547[170], i547[169], i547[168], i547[167], i547[166], i547[165], i547[164], i547[163], i547[162], i547[161], i547[160], i547[159], i547[158], i547[157], i547[156], i547[155], i547[154], i547[153], i547[152], i547[151], i547[150], i547[149], i547[148], i547[147], i547[146], i547[145], i547[144], i547[143], i547[142], i547[141], i547[140], i547[139], i547[138], i547[137], i547[136], i547[135], i547[134], i547[133], i547[132], i547[131], i547[130], i547[129], i547[128], i547[127], i547[126], i547[125], i547[124], i547[123], i547[122], i547[121], i547[120], i547[119], i547[118], i547[117], i547[116], i547[115], i547[114], i547[113], i547[112], i547[111], i547[110], i547[109], i547[108], i547[107], i547[106], i547[105], i547[104], i547[103], i547[102], i547[101], i547[100], i547[99], i547[98], i547[97], i547[96], i547[95], i547[94], i547[93], i547[92], i547[91], i547[90], i547[89], i547[88], i547[87], i547[86], i547[85], i547[84], i547[83], i547[82], i547[81], i547[80], i547[79], i547[78], i547[77], i547[76], i547[75], i547[74], i547[73], i547[72], i547[71], i547[70], i547[69], i547[68], i547[67], i547[66], i547[65], i547[64], i547[63], i547[62], i547[61], i547[60], i547[59], i547[58], i547[57], i547[56], i547[55], i547[54], i547[53], i547[52], i547[51], i547[50], i547[49], i547[48], i547[47], i547[46], i547[45], i547[44], i547[43], i547[42], i547[41], i547[40], i547[39], i547[38], i547[37], i547[36], i547[35], i547[34], i547[33], i547[32], i547[31], i547[30], i547[29], i547[28], i547[27], i547[26], i547[25], i547[24], i547[23], i547[22], i547[21], i547[20], i547[19], i547[18], i547[17], i547[16], i547[15], i547[14], i547[13], i547[12], i547[11], i547[10], i547[9], i547[8], i547[7], i547[6], i547[5], i547[4], i547[3], i547[2], i547[1], i547[0]};
wire [242:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433_reduce(input wire [160:0] i548, input wire [192:0] i549, input wire [224:0] i550, input wire [256:0] i551, output wire [258:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i548[160], i548[159], i548[158], i548[157], i548[156], i548[155], i548[154], i548[153], i548[152], i548[151], i548[150], i548[149], i548[148], i548[147], i548[146], i548[145], i548[144], i548[143], i548[142], i548[141], i548[140], i548[139], i548[138], i548[137], i548[136], i548[135], i548[134], i548[133], i548[132], i548[131], i548[130], i548[129], i548[128], i548[127], i548[126], i548[125], i548[124], i548[123], i548[122], i548[121], i548[120], i548[119], i548[118], i548[117], i548[116], i548[115], i548[114], i548[113], i548[112], i548[111], i548[110], i548[109], i548[108], i548[107], i548[106], i548[105], i548[104], i548[103], i548[102], i548[101], i548[100], i548[99], i548[98], i548[97], i548[96], i548[95], i548[94], i548[93], i548[92], i548[91], i548[90], i548[89], i548[88], i548[87], i548[86], i548[85], i548[84], i548[83], i548[82], i548[81], i548[80], i548[79], i548[78], i548[77], i548[76], i548[75], i548[74], i548[73], i548[72], i548[71], i548[70], i548[69], i548[68], i548[67], i548[66], i548[65], i548[64], i548[63], i548[62], i548[61], i548[60], i548[59], i548[58], i548[57], i548[56], i548[55], i548[54], i548[53], i548[52], i548[51], i548[50], i548[49], i548[48], i548[47], i548[46], i548[45], i548[44], i548[43], i548[42], i548[41], i548[40], i548[39], i548[38], i548[37], i548[36], i548[35], i548[34], i548[33], i548[32], i548[31], i548[30], i548[29], i548[28], i548[27], i548[26], i548[25], i548[24], i548[23], i548[22], i548[21], i548[20], i548[19], i548[18], i548[17], i548[16], i548[15], i548[14], i548[13], i548[12], i548[11], i548[10], i548[9], i548[8], i548[7], i548[6], i548[5], i548[4], i548[3], i548[2], i548[1], i548[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i549[192], i549[191], i549[190], i549[189], i549[188], i549[187], i549[186], i549[185], i549[184], i549[183], i549[182], i549[181], i549[180], i549[179], i549[178], i549[177], i549[176], i549[175], i549[174], i549[173], i549[172], i549[171], i549[170], i549[169], i549[168], i549[167], i549[166], i549[165], i549[164], i549[163], i549[162], i549[161], i549[160], i549[159], i549[158], i549[157], i549[156], i549[155], i549[154], i549[153], i549[152], i549[151], i549[150], i549[149], i549[148], i549[147], i549[146], i549[145], i549[144], i549[143], i549[142], i549[141], i549[140], i549[139], i549[138], i549[137], i549[136], i549[135], i549[134], i549[133], i549[132], i549[131], i549[130], i549[129], i549[128], i549[127], i549[126], i549[125], i549[124], i549[123], i549[122], i549[121], i549[120], i549[119], i549[118], i549[117], i549[116], i549[115], i549[114], i549[113], i549[112], i549[111], i549[110], i549[109], i549[108], i549[107], i549[106], i549[105], i549[104], i549[103], i549[102], i549[101], i549[100], i549[99], i549[98], i549[97], i549[96], i549[95], i549[94], i549[93], i549[92], i549[91], i549[90], i549[89], i549[88], i549[87], i549[86], i549[85], i549[84], i549[83], i549[82], i549[81], i549[80], i549[79], i549[78], i549[77], i549[76], i549[75], i549[74], i549[73], i549[72], i549[71], i549[70], i549[69], i549[68], i549[67], i549[66], i549[65], i549[64], i549[63], i549[62], i549[61], i549[60], i549[59], i549[58], i549[57], i549[56], i549[55], i549[54], i549[53], i549[52], i549[51], i549[50], i549[49], i549[48], i549[47], i549[46], i549[45], i549[44], i549[43], i549[42], i549[41], i549[40], i549[39], i549[38], i549[37], i549[36], i549[35], i549[34], i549[33], i549[32], i549[31], i549[30], i549[29], i549[28], i549[27], i549[26], i549[25], i549[24], i549[23], i549[22], i549[21], i549[20], i549[19], i549[18], i549[17], i549[16], i549[15], i549[14], i549[13], i549[12], i549[11], i549[10], i549[9], i549[8], i549[7], i549[6], i549[5], i549[4], i549[3], i549[2], i549[1], i549[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i550[224], i550[223], i550[222], i550[221], i550[220], i550[219], i550[218], i550[217], i550[216], i550[215], i550[214], i550[213], i550[212], i550[211], i550[210], i550[209], i550[208], i550[207], i550[206], i550[205], i550[204], i550[203], i550[202], i550[201], i550[200], i550[199], i550[198], i550[197], i550[196], i550[195], i550[194], i550[193], i550[192], i550[191], i550[190], i550[189], i550[188], i550[187], i550[186], i550[185], i550[184], i550[183], i550[182], i550[181], i550[180], i550[179], i550[178], i550[177], i550[176], i550[175], i550[174], i550[173], i550[172], i550[171], i550[170], i550[169], i550[168], i550[167], i550[166], i550[165], i550[164], i550[163], i550[162], i550[161], i550[160], i550[159], i550[158], i550[157], i550[156], i550[155], i550[154], i550[153], i550[152], i550[151], i550[150], i550[149], i550[148], i550[147], i550[146], i550[145], i550[144], i550[143], i550[142], i550[141], i550[140], i550[139], i550[138], i550[137], i550[136], i550[135], i550[134], i550[133], i550[132], i550[131], i550[130], i550[129], i550[128], i550[127], i550[126], i550[125], i550[124], i550[123], i550[122], i550[121], i550[120], i550[119], i550[118], i550[117], i550[116], i550[115], i550[114], i550[113], i550[112], i550[111], i550[110], i550[109], i550[108], i550[107], i550[106], i550[105], i550[104], i550[103], i550[102], i550[101], i550[100], i550[99], i550[98], i550[97], i550[96], i550[95], i550[94], i550[93], i550[92], i550[91], i550[90], i550[89], i550[88], i550[87], i550[86], i550[85], i550[84], i550[83], i550[82], i550[81], i550[80], i550[79], i550[78], i550[77], i550[76], i550[75], i550[74], i550[73], i550[72], i550[71], i550[70], i550[69], i550[68], i550[67], i550[66], i550[65], i550[64], i550[63], i550[62], i550[61], i550[60], i550[59], i550[58], i550[57], i550[56], i550[55], i550[54], i550[53], i550[52], i550[51], i550[50], i550[49], i550[48], i550[47], i550[46], i550[45], i550[44], i550[43], i550[42], i550[41], i550[40], i550[39], i550[38], i550[37], i550[36], i550[35], i550[34], i550[33], i550[32], i550[31], i550[30], i550[29], i550[28], i550[27], i550[26], i550[25], i550[24], i550[23], i550[22], i550[21], i550[20], i550[19], i550[18], i550[17], i550[16], i550[15], i550[14], i550[13], i550[12], i550[11], i550[10], i550[9], i550[8], i550[7], i550[6], i550[5], i550[4], i550[3], i550[2], i550[1], i550[0]};
wire [255:0] t3 = {i551[255], i551[254], i551[253], i551[252], i551[251], i551[250], i551[249], i551[248], i551[247], i551[246], i551[245], i551[244], i551[243], i551[242], i551[241], i551[240], i551[239], i551[238], i551[237], i551[236], i551[235], i551[234], i551[233], i551[232], i551[231], i551[230], i551[229], i551[228], i551[227], i551[226], i551[225], i551[224], i551[223], i551[222], i551[221], i551[220], i551[219], i551[218], i551[217], i551[216], i551[215], i551[214], i551[213], i551[212], i551[211], i551[210], i551[209], i551[208], i551[207], i551[206], i551[205], i551[204], i551[203], i551[202], i551[201], i551[200], i551[199], i551[198], i551[197], i551[196], i551[195], i551[194], i551[193], i551[192], i551[191], i551[190], i551[189], i551[188], i551[187], i551[186], i551[185], i551[184], i551[183], i551[182], i551[181], i551[180], i551[179], i551[178], i551[177], i551[176], i551[175], i551[174], i551[173], i551[172], i551[171], i551[170], i551[169], i551[168], i551[167], i551[166], i551[165], i551[164], i551[163], i551[162], i551[161], i551[160], i551[159], i551[158], i551[157], i551[156], i551[155], i551[154], i551[153], i551[152], i551[151], i551[150], i551[149], i551[148], i551[147], i551[146], i551[145], i551[144], i551[143], i551[142], i551[141], i551[140], i551[139], i551[138], i551[137], i551[136], i551[135], i551[134], i551[133], i551[132], i551[131], i551[130], i551[129], i551[128], i551[127], i551[126], i551[125], i551[124], i551[123], i551[122], i551[121], i551[120], i551[119], i551[118], i551[117], i551[116], i551[115], i551[114], i551[113], i551[112], i551[111], i551[110], i551[109], i551[108], i551[107], i551[106], i551[105], i551[104], i551[103], i551[102], i551[101], i551[100], i551[99], i551[98], i551[97], i551[96], i551[95], i551[94], i551[93], i551[92], i551[91], i551[90], i551[89], i551[88], i551[87], i551[86], i551[85], i551[84], i551[83], i551[82], i551[81], i551[80], i551[79], i551[78], i551[77], i551[76], i551[75], i551[74], i551[73], i551[72], i551[71], i551[70], i551[69], i551[68], i551[67], i551[66], i551[65], i551[64], i551[63], i551[62], i551[61], i551[60], i551[59], i551[58], i551[57], i551[56], i551[55], i551[54], i551[53], i551[52], i551[51], i551[50], i551[49], i551[48], i551[47], i551[46], i551[45], i551[44], i551[43], i551[42], i551[41], i551[40], i551[39], i551[38], i551[37], i551[36], i551[35], i551[34], i551[33], i551[32], i551[31], i551[30], i551[29], i551[28], i551[27], i551[26], i551[25], i551[24], i551[23], i551[22], i551[21], i551[20], i551[19], i551[18], i551[17], i551[16], i551[15], i551[14], i551[13], i551[12], i551[11], i551[10], i551[9], i551[8], i551[7], i551[6], i551[5], i551[4], i551[3], i551[2], i551[1], i551[0]};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454_reduce(input wire [146:0] i552, input wire [162:0] i553, input wire [178:0] i554, input wire [194:0] i555, input wire [210:0] i556, input wire [226:0] i557, input wire [242:0] i558, input wire [258:0] i559, output wire [261:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i552[146], i552[145], i552[144], i552[143], i552[142], i552[141], i552[140], i552[139], i552[138], i552[137], i552[136], i552[135], i552[134], i552[133], i552[132], i552[131], i552[130], i552[129], i552[128], i552[127], i552[126], i552[125], i552[124], i552[123], i552[122], i552[121], i552[120], i552[119], i552[118], i552[117], i552[116], i552[115], i552[114], i552[113], i552[112], i552[111], i552[110], i552[109], i552[108], i552[107], i552[106], i552[105], i552[104], i552[103], i552[102], i552[101], i552[100], i552[99], i552[98], i552[97], i552[96], i552[95], i552[94], i552[93], i552[92], i552[91], i552[90], i552[89], i552[88], i552[87], i552[86], i552[85], i552[84], i552[83], i552[82], i552[81], i552[80], i552[79], i552[78], i552[77], i552[76], i552[75], i552[74], i552[73], i552[72], i552[71], i552[70], i552[69], i552[68], i552[67], i552[66], i552[65], i552[64], i552[63], i552[62], i552[61], i552[60], i552[59], i552[58], i552[57], i552[56], i552[55], i552[54], i552[53], i552[52], i552[51], i552[50], i552[49], i552[48], i552[47], i552[46], i552[45], i552[44], i552[43], i552[42], i552[41], i552[40], i552[39], i552[38], i552[37], i552[36], i552[35], i552[34], i552[33], i552[32], i552[31], i552[30], i552[29], i552[28], i552[27], i552[26], i552[25], i552[24], i552[23], i552[22], i552[21], i552[20], i552[19], i552[18], i552[17], i552[16], i552[15], i552[14], i552[13], i552[12], i552[11], i552[10], i552[9], i552[8], i552[7], i552[6], i552[5], i552[4], i552[3], i552[2], i552[1], i552[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i553[162], i553[161], i553[160], i553[159], i553[158], i553[157], i553[156], i553[155], i553[154], i553[153], i553[152], i553[151], i553[150], i553[149], i553[148], i553[147], i553[146], i553[145], i553[144], i553[143], i553[142], i553[141], i553[140], i553[139], i553[138], i553[137], i553[136], i553[135], i553[134], i553[133], i553[132], i553[131], i553[130], i553[129], i553[128], i553[127], i553[126], i553[125], i553[124], i553[123], i553[122], i553[121], i553[120], i553[119], i553[118], i553[117], i553[116], i553[115], i553[114], i553[113], i553[112], i553[111], i553[110], i553[109], i553[108], i553[107], i553[106], i553[105], i553[104], i553[103], i553[102], i553[101], i553[100], i553[99], i553[98], i553[97], i553[96], i553[95], i553[94], i553[93], i553[92], i553[91], i553[90], i553[89], i553[88], i553[87], i553[86], i553[85], i553[84], i553[83], i553[82], i553[81], i553[80], i553[79], i553[78], i553[77], i553[76], i553[75], i553[74], i553[73], i553[72], i553[71], i553[70], i553[69], i553[68], i553[67], i553[66], i553[65], i553[64], i553[63], i553[62], i553[61], i553[60], i553[59], i553[58], i553[57], i553[56], i553[55], i553[54], i553[53], i553[52], i553[51], i553[50], i553[49], i553[48], i553[47], i553[46], i553[45], i553[44], i553[43], i553[42], i553[41], i553[40], i553[39], i553[38], i553[37], i553[36], i553[35], i553[34], i553[33], i553[32], i553[31], i553[30], i553[29], i553[28], i553[27], i553[26], i553[25], i553[24], i553[23], i553[22], i553[21], i553[20], i553[19], i553[18], i553[17], i553[16], i553[15], i553[14], i553[13], i553[12], i553[11], i553[10], i553[9], i553[8], i553[7], i553[6], i553[5], i553[4], i553[3], i553[2], i553[1], i553[0]};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i554[178], i554[177], i554[176], i554[175], i554[174], i554[173], i554[172], i554[171], i554[170], i554[169], i554[168], i554[167], i554[166], i554[165], i554[164], i554[163], i554[162], i554[161], i554[160], i554[159], i554[158], i554[157], i554[156], i554[155], i554[154], i554[153], i554[152], i554[151], i554[150], i554[149], i554[148], i554[147], i554[146], i554[145], i554[144], i554[143], i554[142], i554[141], i554[140], i554[139], i554[138], i554[137], i554[136], i554[135], i554[134], i554[133], i554[132], i554[131], i554[130], i554[129], i554[128], i554[127], i554[126], i554[125], i554[124], i554[123], i554[122], i554[121], i554[120], i554[119], i554[118], i554[117], i554[116], i554[115], i554[114], i554[113], i554[112], i554[111], i554[110], i554[109], i554[108], i554[107], i554[106], i554[105], i554[104], i554[103], i554[102], i554[101], i554[100], i554[99], i554[98], i554[97], i554[96], i554[95], i554[94], i554[93], i554[92], i554[91], i554[90], i554[89], i554[88], i554[87], i554[86], i554[85], i554[84], i554[83], i554[82], i554[81], i554[80], i554[79], i554[78], i554[77], i554[76], i554[75], i554[74], i554[73], i554[72], i554[71], i554[70], i554[69], i554[68], i554[67], i554[66], i554[65], i554[64], i554[63], i554[62], i554[61], i554[60], i554[59], i554[58], i554[57], i554[56], i554[55], i554[54], i554[53], i554[52], i554[51], i554[50], i554[49], i554[48], i554[47], i554[46], i554[45], i554[44], i554[43], i554[42], i554[41], i554[40], i554[39], i554[38], i554[37], i554[36], i554[35], i554[34], i554[33], i554[32], i554[31], i554[30], i554[29], i554[28], i554[27], i554[26], i554[25], i554[24], i554[23], i554[22], i554[21], i554[20], i554[19], i554[18], i554[17], i554[16], i554[15], i554[14], i554[13], i554[12], i554[11], i554[10], i554[9], i554[8], i554[7], i554[6], i554[5], i554[4], i554[3], i554[2], i554[1], i554[0]};
wire [255:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i555[194], i555[193], i555[192], i555[191], i555[190], i555[189], i555[188], i555[187], i555[186], i555[185], i555[184], i555[183], i555[182], i555[181], i555[180], i555[179], i555[178], i555[177], i555[176], i555[175], i555[174], i555[173], i555[172], i555[171], i555[170], i555[169], i555[168], i555[167], i555[166], i555[165], i555[164], i555[163], i555[162], i555[161], i555[160], i555[159], i555[158], i555[157], i555[156], i555[155], i555[154], i555[153], i555[152], i555[151], i555[150], i555[149], i555[148], i555[147], i555[146], i555[145], i555[144], i555[143], i555[142], i555[141], i555[140], i555[139], i555[138], i555[137], i555[136], i555[135], i555[134], i555[133], i555[132], i555[131], i555[130], i555[129], i555[128], i555[127], i555[126], i555[125], i555[124], i555[123], i555[122], i555[121], i555[120], i555[119], i555[118], i555[117], i555[116], i555[115], i555[114], i555[113], i555[112], i555[111], i555[110], i555[109], i555[108], i555[107], i555[106], i555[105], i555[104], i555[103], i555[102], i555[101], i555[100], i555[99], i555[98], i555[97], i555[96], i555[95], i555[94], i555[93], i555[92], i555[91], i555[90], i555[89], i555[88], i555[87], i555[86], i555[85], i555[84], i555[83], i555[82], i555[81], i555[80], i555[79], i555[78], i555[77], i555[76], i555[75], i555[74], i555[73], i555[72], i555[71], i555[70], i555[69], i555[68], i555[67], i555[66], i555[65], i555[64], i555[63], i555[62], i555[61], i555[60], i555[59], i555[58], i555[57], i555[56], i555[55], i555[54], i555[53], i555[52], i555[51], i555[50], i555[49], i555[48], i555[47], i555[46], i555[45], i555[44], i555[43], i555[42], i555[41], i555[40], i555[39], i555[38], i555[37], i555[36], i555[35], i555[34], i555[33], i555[32], i555[31], i555[30], i555[29], i555[28], i555[27], i555[26], i555[25], i555[24], i555[23], i555[22], i555[21], i555[20], i555[19], i555[18], i555[17], i555[16], i555[15], i555[14], i555[13], i555[12], i555[11], i555[10], i555[9], i555[8], i555[7], i555[6], i555[5], i555[4], i555[3], i555[2], i555[1], i555[0]};
wire [255:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i556[210], i556[209], i556[208], i556[207], i556[206], i556[205], i556[204], i556[203], i556[202], i556[201], i556[200], i556[199], i556[198], i556[197], i556[196], i556[195], i556[194], i556[193], i556[192], i556[191], i556[190], i556[189], i556[188], i556[187], i556[186], i556[185], i556[184], i556[183], i556[182], i556[181], i556[180], i556[179], i556[178], i556[177], i556[176], i556[175], i556[174], i556[173], i556[172], i556[171], i556[170], i556[169], i556[168], i556[167], i556[166], i556[165], i556[164], i556[163], i556[162], i556[161], i556[160], i556[159], i556[158], i556[157], i556[156], i556[155], i556[154], i556[153], i556[152], i556[151], i556[150], i556[149], i556[148], i556[147], i556[146], i556[145], i556[144], i556[143], i556[142], i556[141], i556[140], i556[139], i556[138], i556[137], i556[136], i556[135], i556[134], i556[133], i556[132], i556[131], i556[130], i556[129], i556[128], i556[127], i556[126], i556[125], i556[124], i556[123], i556[122], i556[121], i556[120], i556[119], i556[118], i556[117], i556[116], i556[115], i556[114], i556[113], i556[112], i556[111], i556[110], i556[109], i556[108], i556[107], i556[106], i556[105], i556[104], i556[103], i556[102], i556[101], i556[100], i556[99], i556[98], i556[97], i556[96], i556[95], i556[94], i556[93], i556[92], i556[91], i556[90], i556[89], i556[88], i556[87], i556[86], i556[85], i556[84], i556[83], i556[82], i556[81], i556[80], i556[79], i556[78], i556[77], i556[76], i556[75], i556[74], i556[73], i556[72], i556[71], i556[70], i556[69], i556[68], i556[67], i556[66], i556[65], i556[64], i556[63], i556[62], i556[61], i556[60], i556[59], i556[58], i556[57], i556[56], i556[55], i556[54], i556[53], i556[52], i556[51], i556[50], i556[49], i556[48], i556[47], i556[46], i556[45], i556[44], i556[43], i556[42], i556[41], i556[40], i556[39], i556[38], i556[37], i556[36], i556[35], i556[34], i556[33], i556[32], i556[31], i556[30], i556[29], i556[28], i556[27], i556[26], i556[25], i556[24], i556[23], i556[22], i556[21], i556[20], i556[19], i556[18], i556[17], i556[16], i556[15], i556[14], i556[13], i556[12], i556[11], i556[10], i556[9], i556[8], i556[7], i556[6], i556[5], i556[4], i556[3], i556[2], i556[1], i556[0]};
wire [255:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i557[226], i557[225], i557[224], i557[223], i557[222], i557[221], i557[220], i557[219], i557[218], i557[217], i557[216], i557[215], i557[214], i557[213], i557[212], i557[211], i557[210], i557[209], i557[208], i557[207], i557[206], i557[205], i557[204], i557[203], i557[202], i557[201], i557[200], i557[199], i557[198], i557[197], i557[196], i557[195], i557[194], i557[193], i557[192], i557[191], i557[190], i557[189], i557[188], i557[187], i557[186], i557[185], i557[184], i557[183], i557[182], i557[181], i557[180], i557[179], i557[178], i557[177], i557[176], i557[175], i557[174], i557[173], i557[172], i557[171], i557[170], i557[169], i557[168], i557[167], i557[166], i557[165], i557[164], i557[163], i557[162], i557[161], i557[160], i557[159], i557[158], i557[157], i557[156], i557[155], i557[154], i557[153], i557[152], i557[151], i557[150], i557[149], i557[148], i557[147], i557[146], i557[145], i557[144], i557[143], i557[142], i557[141], i557[140], i557[139], i557[138], i557[137], i557[136], i557[135], i557[134], i557[133], i557[132], i557[131], i557[130], i557[129], i557[128], i557[127], i557[126], i557[125], i557[124], i557[123], i557[122], i557[121], i557[120], i557[119], i557[118], i557[117], i557[116], i557[115], i557[114], i557[113], i557[112], i557[111], i557[110], i557[109], i557[108], i557[107], i557[106], i557[105], i557[104], i557[103], i557[102], i557[101], i557[100], i557[99], i557[98], i557[97], i557[96], i557[95], i557[94], i557[93], i557[92], i557[91], i557[90], i557[89], i557[88], i557[87], i557[86], i557[85], i557[84], i557[83], i557[82], i557[81], i557[80], i557[79], i557[78], i557[77], i557[76], i557[75], i557[74], i557[73], i557[72], i557[71], i557[70], i557[69], i557[68], i557[67], i557[66], i557[65], i557[64], i557[63], i557[62], i557[61], i557[60], i557[59], i557[58], i557[57], i557[56], i557[55], i557[54], i557[53], i557[52], i557[51], i557[50], i557[49], i557[48], i557[47], i557[46], i557[45], i557[44], i557[43], i557[42], i557[41], i557[40], i557[39], i557[38], i557[37], i557[36], i557[35], i557[34], i557[33], i557[32], i557[31], i557[30], i557[29], i557[28], i557[27], i557[26], i557[25], i557[24], i557[23], i557[22], i557[21], i557[20], i557[19], i557[18], i557[17], i557[16], i557[15], i557[14], i557[13], i557[12], i557[11], i557[10], i557[9], i557[8], i557[7], i557[6], i557[5], i557[4], i557[3], i557[2], i557[1], i557[0]};
wire [255:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i558[242], i558[241], i558[240], i558[239], i558[238], i558[237], i558[236], i558[235], i558[234], i558[233], i558[232], i558[231], i558[230], i558[229], i558[228], i558[227], i558[226], i558[225], i558[224], i558[223], i558[222], i558[221], i558[220], i558[219], i558[218], i558[217], i558[216], i558[215], i558[214], i558[213], i558[212], i558[211], i558[210], i558[209], i558[208], i558[207], i558[206], i558[205], i558[204], i558[203], i558[202], i558[201], i558[200], i558[199], i558[198], i558[197], i558[196], i558[195], i558[194], i558[193], i558[192], i558[191], i558[190], i558[189], i558[188], i558[187], i558[186], i558[185], i558[184], i558[183], i558[182], i558[181], i558[180], i558[179], i558[178], i558[177], i558[176], i558[175], i558[174], i558[173], i558[172], i558[171], i558[170], i558[169], i558[168], i558[167], i558[166], i558[165], i558[164], i558[163], i558[162], i558[161], i558[160], i558[159], i558[158], i558[157], i558[156], i558[155], i558[154], i558[153], i558[152], i558[151], i558[150], i558[149], i558[148], i558[147], i558[146], i558[145], i558[144], i558[143], i558[142], i558[141], i558[140], i558[139], i558[138], i558[137], i558[136], i558[135], i558[134], i558[133], i558[132], i558[131], i558[130], i558[129], i558[128], i558[127], i558[126], i558[125], i558[124], i558[123], i558[122], i558[121], i558[120], i558[119], i558[118], i558[117], i558[116], i558[115], i558[114], i558[113], i558[112], i558[111], i558[110], i558[109], i558[108], i558[107], i558[106], i558[105], i558[104], i558[103], i558[102], i558[101], i558[100], i558[99], i558[98], i558[97], i558[96], i558[95], i558[94], i558[93], i558[92], i558[91], i558[90], i558[89], i558[88], i558[87], i558[86], i558[85], i558[84], i558[83], i558[82], i558[81], i558[80], i558[79], i558[78], i558[77], i558[76], i558[75], i558[74], i558[73], i558[72], i558[71], i558[70], i558[69], i558[68], i558[67], i558[66], i558[65], i558[64], i558[63], i558[62], i558[61], i558[60], i558[59], i558[58], i558[57], i558[56], i558[55], i558[54], i558[53], i558[52], i558[51], i558[50], i558[49], i558[48], i558[47], i558[46], i558[45], i558[44], i558[43], i558[42], i558[41], i558[40], i558[39], i558[38], i558[37], i558[36], i558[35], i558[34], i558[33], i558[32], i558[31], i558[30], i558[29], i558[28], i558[27], i558[26], i558[25], i558[24], i558[23], i558[22], i558[21], i558[20], i558[19], i558[18], i558[17], i558[16], i558[15], i558[14], i558[13], i558[12], i558[11], i558[10], i558[9], i558[8], i558[7], i558[6], i558[5], i558[4], i558[3], i558[2], i558[1], i558[0]};
wire [255:0] t7 = {i559[255], i559[254], i559[253], i559[252], i559[251], i559[250], i559[249], i559[248], i559[247], i559[246], i559[245], i559[244], i559[243], i559[242], i559[241], i559[240], i559[239], i559[238], i559[237], i559[236], i559[235], i559[234], i559[233], i559[232], i559[231], i559[230], i559[229], i559[228], i559[227], i559[226], i559[225], i559[224], i559[223], i559[222], i559[221], i559[220], i559[219], i559[218], i559[217], i559[216], i559[215], i559[214], i559[213], i559[212], i559[211], i559[210], i559[209], i559[208], i559[207], i559[206], i559[205], i559[204], i559[203], i559[202], i559[201], i559[200], i559[199], i559[198], i559[197], i559[196], i559[195], i559[194], i559[193], i559[192], i559[191], i559[190], i559[189], i559[188], i559[187], i559[186], i559[185], i559[184], i559[183], i559[182], i559[181], i559[180], i559[179], i559[178], i559[177], i559[176], i559[175], i559[174], i559[173], i559[172], i559[171], i559[170], i559[169], i559[168], i559[167], i559[166], i559[165], i559[164], i559[163], i559[162], i559[161], i559[160], i559[159], i559[158], i559[157], i559[156], i559[155], i559[154], i559[153], i559[152], i559[151], i559[150], i559[149], i559[148], i559[147], i559[146], i559[145], i559[144], i559[143], i559[142], i559[141], i559[140], i559[139], i559[138], i559[137], i559[136], i559[135], i559[134], i559[133], i559[132], i559[131], i559[130], i559[129], i559[128], i559[127], i559[126], i559[125], i559[124], i559[123], i559[122], i559[121], i559[120], i559[119], i559[118], i559[117], i559[116], i559[115], i559[114], i559[113], i559[112], i559[111], i559[110], i559[109], i559[108], i559[107], i559[106], i559[105], i559[104], i559[103], i559[102], i559[101], i559[100], i559[99], i559[98], i559[97], i559[96], i559[95], i559[94], i559[93], i559[92], i559[91], i559[90], i559[89], i559[88], i559[87], i559[86], i559[85], i559[84], i559[83], i559[82], i559[81], i559[80], i559[79], i559[78], i559[77], i559[76], i559[75], i559[74], i559[73], i559[72], i559[71], i559[70], i559[69], i559[68], i559[67], i559[66], i559[65], i559[64], i559[63], i559[62], i559[61], i559[60], i559[59], i559[58], i559[57], i559[56], i559[55], i559[54], i559[53], i559[52], i559[51], i559[50], i559[49], i559[48], i559[47], i559[46], i559[45], i559[44], i559[43], i559[42], i559[41], i559[40], i559[39], i559[38], i559[37], i559[36], i559[35], i559[34], i559[33], i559[32], i559[31], i559[30], i559[29], i559[28], i559[27], i559[26], i559[25], i559[24], i559[23], i559[22], i559[21], i559[20], i559[19], i559[18], i559[17], i559[16], i559[15], i559[14], i559[13], i559[12], i559[11], i559[10], i559[9], i559[8], i559[7], i559[6], i559[5], i559[4], i559[3], i559[2], i559[1], i559[0]};
wire [255:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_32();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_44();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_48();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_64();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_68();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_72();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_80();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_88();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_96();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_108();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_112();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_152();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_192();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_196();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_208();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_232();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_236();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_268();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_271();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_277();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_283();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_289();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [80:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:81];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_292();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_295();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [112:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_322();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_328();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_331();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340Core(input wire [127:0] a,input wire [143:0] b,input wire cin,output wire [144:0] value);
wire [127:0] masked_a=((a&128'hffffffff000000000000000000000000)|128'h0);
wire [143:0] masked_b=((b&144'hffffffff0000000000000000000000000000)|144'h0);
wire [144:0] aa=145'(masked_b);
wire [144:0] bb=145'(masked_a);
wire [145:0] extended={1'b0,aa}+{1'b0,bb}+146'(1'b0);
wire [144:0] native_value=extended[144:0];
assign value=native_value[0+:145];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_340();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [159:0] a,input wire [175:0] b,input wire cin,output wire [176:0] value);
wire [159:0] masked_a=((a&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [175:0] masked_b=((b&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [176:0] aa=177'(masked_b);
wire [176:0] bb=177'(masked_a);
wire [177:0] extended={1'b0,aa}+{1'b0,bb}+178'(1'b0);
wire [176:0] native_value=extended[176:0];
assign value=native_value[0+:177];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346Core(input wire [191:0] a,input wire [207:0] b,input wire cin,output wire [208:0] value);
wire [191:0] masked_a=((a&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [207:0] masked_b=((b&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [208:0] aa=209'(masked_b);
wire [208:0] bb=209'(masked_a);
wire [209:0] extended={1'b0,aa}+{1'b0,bb}+210'(1'b0);
wire [208:0] native_value=extended[208:0];
assign value=native_value[0+:209];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349Core(input wire [223:0] a,input wire [239:0] b,input wire cin,output wire [240:0] value);
wire [223:0] masked_a=((a&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [239:0] masked_b=((b&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [240:0] aa=241'(masked_b);
wire [240:0] bb=241'(masked_a);
wire [241:0] extended={1'b0,aa}+{1'b0,bb}+242'(1'b0);
wire [240:0] native_value=extended[240:0];
assign value=native_value[0+:241];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352Core(input wire [143:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [143:0] masked_a=((a&144'hffffffff0000000000000000000000000000)|144'h0);
wire [159:0] masked_b=((b&160'hffffffff00000000000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [175:0] a,input wire [191:0] b,input wire cin,output wire [192:0] value);
wire [175:0] masked_a=((a&176'hffffffff000000000000000000000000000000000000)|176'h0);
wire [191:0] masked_b=((b&192'hffffffff0000000000000000000000000000000000000000)|192'h0);
wire [192:0] aa=193'(masked_b);
wire [192:0] bb=193'(masked_a);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [207:0] a,input wire [223:0] b,input wire cin,output wire [224:0] value);
wire [207:0] masked_a=((a&208'hffffffff00000000000000000000000000000000000000000000)|208'h0);
wire [223:0] masked_b=((b&224'hffffffff000000000000000000000000000000000000000000000000)|224'h0);
wire [224:0] aa=225'(masked_b);
wire [224:0] bb=225'(masked_a);
wire [225:0] extended={1'b0,aa}+{1'b0,bb}+226'(1'b0);
wire [224:0] native_value=extended[224:0];
assign value=native_value[0+:225];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361Core(input wire [239:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [239:0] masked_a=((a&240'hffffffff0000000000000000000000000000000000000000000000000000)|240'h0);
wire [255:0] masked_b=((b&256'hffffffff00000000000000000000000000000000000000000000000000000000)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
