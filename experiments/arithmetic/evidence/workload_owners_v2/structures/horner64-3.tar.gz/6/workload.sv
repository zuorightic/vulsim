`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [15:0] mul_tree_17_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_26; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_17_27; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_28; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_30; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_31; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_32; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_34; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_17_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_36; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_38; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_17_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_40; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_42; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_44; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_46; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_17_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_48; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_50; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_52; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_54; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_56; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_58; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_17_59; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_60; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_62; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_63; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_64; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_66; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_17_67; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_68; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_70; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_17_71; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_72; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_74; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_75; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_76; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_77; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_78; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_17_79; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_80; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_81; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_17_83; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_17_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_17_85; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_17_86; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_87; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_88; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_89; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_17_90; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_17_91; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_17_92; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_93; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_94; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_95; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_96; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_97; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_17_98; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_17_99; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_17_100; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_17_101; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_102; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_103; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_104; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_105; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_106; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_107; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_17_108; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_17_109; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_17_110; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_17_111; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_17_112; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_17_113; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_17_114; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_17_115; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_17_116; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_119; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_17_120; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_17_121; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_17_122; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_17_123; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_17_124; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_17_125; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_17_126; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_17_127; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_17_128; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_129; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_130; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_132; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_133; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_134; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_135; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_18_136; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_137; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_138; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_139; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_140; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_141; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_142; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_143; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_18_144; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_145; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_147; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_18_148; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_149; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_150; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_151; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_152; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_153; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_154; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_155; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_18_156; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_157; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_158; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_159; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_160; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_161; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_162; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_163; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_164; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_165; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_166; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_167; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_18_168; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_169; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_170; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_171; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_172; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_173; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_174; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_175; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_18_176; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_177; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_179; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_18_180; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_181; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_182; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_183; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_184; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_185; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_186; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_187; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_18_188; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_189; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_18_190; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_191; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_18_192; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_18_193; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_18_194; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_18_195; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_196; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_197; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_198; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_18_199; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_18_200; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_18_201; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_202; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_203; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_204; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_205; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_206; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_18_207; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_18_208; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_18_209; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_18_210; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_211; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_212; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_213; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_214; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_215; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_216; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_18_217; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_18_218; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_18_219; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_18_220; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_18_221; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_18_222; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_18_223; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_18_224; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_18_225; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_226; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_227; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_228; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_18_229; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_18_230; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_18_231; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_18_232; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_18_233; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_18_234; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_18_235; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_18_236; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_18_237; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_238; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_239; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_240; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_241; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_242; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_243; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_244; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_19_245; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_246; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_247; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_248; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_249; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_250; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_251; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_252; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_19_253; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_254; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_255; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_256; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_19_257; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_258; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_259; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_260; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_261; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_262; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_263; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_264; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_19_265; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_266; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_267; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_268; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_269; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_270; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_271; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_272; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_273; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_274; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_275; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_276; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_19_277; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_278; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_279; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_280; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_281; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_282; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_283; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_284; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_19_285; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_286; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_287; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_288; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_19_289; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_290; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_291; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_292; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_293; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_294; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_295; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_296; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_19_297; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_298; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_19_299; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_300; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_19_301; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_19_302; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_19_303; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_19_304; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_305; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_306; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_307; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_19_308; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_19_309; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_19_310; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_311; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_312; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_313; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_314; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_315; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_19_316; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_19_317; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_19_318; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_19_319; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_320; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_321; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_322; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_323; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_324; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_325; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_19_326; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_19_327; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_19_328; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_19_329; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_19_330; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_19_331; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_19_332; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_19_333; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_19_334; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_335; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_336; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_337; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_19_338; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_19_339; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_19_340; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_19_341; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_19_342; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_19_343; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_19_344; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_19_345; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_19_346; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_347; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_348; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_349; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_350; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_351; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_352; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_353; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_20_354; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_355; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_356; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_357; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_358; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_359; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_360; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_361; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_20_362; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_363; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_364; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_365; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_20_366; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_367; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_368; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_369; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_370; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_371; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_372; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_373; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_20_374; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_375; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_376; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_377; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_378; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_379; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_380; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_381; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_382; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_383; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_384; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_385; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_20_386; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_387; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_388; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_389; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_390; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_391; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_392; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_393; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_20_394; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_395; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_397; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_20_398; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_399; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_400; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_401; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_402; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_403; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_404; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_405; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_20_406; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_407; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_20_408; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_409; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_20_410; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_20_411; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_20_412; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_20_413; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_414; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_415; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_416; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_20_417; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_20_418; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_20_419; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_420; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_421; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_422; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_423; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_424; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_20_425; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_20_426; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_20_427; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_20_428; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_429; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_430; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_431; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_432; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_433; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_434; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_20_435; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_20_436; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_20_437; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_20_438; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_20_439; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_20_440; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_20_441; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_20_442; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_20_443; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_444; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_445; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_446; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_20_447; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_20_448; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_20_449; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_20_450; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_20_451; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_20_452; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_20_453; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_20_454; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_20_455; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_456; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s7; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s7; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [31:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_86_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_89_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_92_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_95_s2; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_98_s2; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [81:0] rtlzz_pipe_110_s3; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_113_s3; // decl: <none>; prim: <none>
    logic [113:0] rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_119_s3; // decl: <none>; prim: <none>
    logic [98:0] rtlzz_pipe_122_s4; // decl: <none>; prim: <none>
    logic [130:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_7_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] rtlzz_pipe_8_s6; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [48:0] rtlzz_pipe_195_s7; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_198_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_201_s7; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_204_s7; // decl: <none>; prim: <none>
    logic [80:0] rtlzz_pipe_207_s7; // decl: <none>; prim: <none>
    logic [112:0] rtlzz_pipe_210_s7; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_213_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_216_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_8Core rtlzz_owner_8(.a(64'(rtlzz_pipe_7_s5)), .b(64'(rtlzz_pipe_4_s5)), .cin(1'b0), .value(s8_norm_add_2_v0));
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_10_reduce rtlzz_reduce_10(.i484(rtlzz_pipe_3_s7), .i522(rtlzz_pipe_195_s7), .i523(rtlzz_pipe_198_s7), .i524(rtlzz_pipe_201_s7), .i525(rtlzz_pipe_204_s7), .i526(rtlzz_pipe_207_s7), .i527(rtlzz_pipe_210_s7), .i528(rtlzz_pipe_213_s7), .i529(rtlzz_pipe_216_s7), .y(s8_norm_add_5_v0));
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_12_reduce rtlzz_reduce_12(.i241(mul_tree_19_241), .i244(mul_tree_19_244), .i248(mul_tree_19_248), .i252(mul_tree_19_252), .i256(mul_tree_19_256), .i260(mul_tree_19_260), .i264(mul_tree_19_264), .i272(mul_tree_19_272), .i276(mul_tree_19_276), .i288(mul_tree_19_288), .i477(rtlzz_pipe_2_s7), .y(s8_norm_add_8_v0));
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_14_reduce rtlzz_reduce_14(.i350(mul_tree_20_350), .i353(mul_tree_20_353), .i357(mul_tree_20_357), .i361(mul_tree_20_361), .i365(mul_tree_20_365), .i369(mul_tree_20_369), .i373(mul_tree_20_373), .i381(mul_tree_20_381), .i385(mul_tree_20_385), .i397(mul_tree_20_397), .i470(rtlzz_pipe_1_s7), .y(s8_norm_add_11_v0));
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign arith_original_17 = mul_tree_17_129; // decl: <none>; prim: <none>
    assign arith_original_18 = mul_tree_18_238; // decl: <none>; prim: <none>
    assign arith_original_19 = mul_tree_19_347; // decl: <none>; prim: <none>
    assign arith_original_20 = mul_tree_20_456; // decl: <none>; prim: <none>
    assign mul_tree_17_21 = c4[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_22 = x[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(16'(mul_tree_17_21)), .b(16'(mul_tree_17_22)), .cin(1'b0), .value(mul_tree_17_23));
    assign mul_tree_17_24 = c4[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_25 = x[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(16'(mul_tree_17_24)), .b(16'(mul_tree_17_25)), .cin(1'b0), .value(mul_tree_17_26));
    assign mul_tree_17_27 = {mul_tree_17_26, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_28 = c4[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_29 = x[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(16'(mul_tree_17_28)), .b(16'(mul_tree_17_29)), .cin(1'b0), .value(mul_tree_17_30));
    assign mul_tree_17_31 = {mul_tree_17_30, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_32 = c4[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_33 = x[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(16'(mul_tree_17_32)), .b(16'(mul_tree_17_33)), .cin(1'b0), .value(mul_tree_17_34[15:0]));
    assign mul_tree_17_34[31:16] = '0;
    assign mul_tree_17_35 = {mul_tree_17_34, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_36 = c4[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_17_37 = x[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(16'(mul_tree_17_36)), .b(16'(mul_tree_17_37)), .cin(1'b0), .value(mul_tree_17_38));
    assign mul_tree_17_39 = {mul_tree_17_38, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_40 = c4[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_17_41 = x[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(16'(mul_tree_17_40)), .b(16'(mul_tree_17_41)), .cin(1'b0), .value(mul_tree_17_42));
    assign mul_tree_17_43 = {mul_tree_17_42, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_44 = c4[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_17_45 = x[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_46Core rtlzz_owner_46(.a(16'(mul_tree_17_44)), .b(16'(mul_tree_17_45)), .cin(1'b0), .value(mul_tree_17_46[15:0]));
    assign mul_tree_17_46[31:16] = '0;
    assign mul_tree_17_47 = {mul_tree_17_46, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_48 = c4[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_17_49 = x[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_50 = 32'(($unsigned(32'($unsigned(mul_tree_17_48))) * $unsigned(32'($unsigned(mul_tree_17_49))))); // decl: <none>; prim: <none>
    assign mul_tree_17_51 = {mul_tree_17_50, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_52 = c4[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_53 = x[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(16'(mul_tree_17_52)), .b(16'(mul_tree_17_53)), .cin(1'b0), .value(mul_tree_17_54));
    assign mul_tree_17_55 = {mul_tree_17_54, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_56 = c4[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_57 = x[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(16'(mul_tree_17_56)), .b(16'(mul_tree_17_57)), .cin(1'b0), .value(mul_tree_17_58[15:0]));
    assign mul_tree_17_58[31:16] = '0;
    assign mul_tree_17_59 = {mul_tree_17_58, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_60 = c4[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_61 = x[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_62 = 32'(($unsigned(32'($unsigned(mul_tree_17_60))) * $unsigned(32'($unsigned(mul_tree_17_61))))); // decl: <none>; prim: <none>
    assign mul_tree_17_63 = {mul_tree_17_62, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_64 = c4[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_65 = x[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_66 = 32'(($unsigned(32'($unsigned(mul_tree_17_64))) * $unsigned(32'($unsigned(mul_tree_17_65))))); // decl: <none>; prim: <none>
    assign mul_tree_17_67 = {mul_tree_17_66, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_68 = c4[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_69 = x[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(16'(mul_tree_17_68)), .b(16'(mul_tree_17_69)), .cin(1'b0), .value(mul_tree_17_70[15:0]));
    assign mul_tree_17_70[31:16] = '0;
    assign mul_tree_17_71 = {mul_tree_17_70, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_72 = c4[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_73 = x[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_17_74 = 32'(($unsigned(32'($unsigned(mul_tree_17_72))) * $unsigned(32'($unsigned(mul_tree_17_73))))); // decl: <none>; prim: <none>
    assign mul_tree_17_75 = {mul_tree_17_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_76 = c4[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_77 = x[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_78 = 32'(($unsigned(32'($unsigned(mul_tree_17_76))) * $unsigned(32'($unsigned(mul_tree_17_77))))); // decl: <none>; prim: <none>
    assign mul_tree_17_79 = {mul_tree_17_78, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_80 = c4[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_81 = x[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_17_82 = 32'(($unsigned(32'($unsigned(mul_tree_17_80))) * $unsigned(32'($unsigned(mul_tree_17_81))))); // decl: <none>; prim: <none>
    assign mul_tree_17_83 = {mul_tree_17_82, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_84 = ({17'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_85 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(32'(mul_tree_17_84)), .b(48'(mul_tree_17_85)), .cin(1'h0), .value(mul_tree_17_86));
    assign mul_tree_17_87 = ({17'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_88 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_89Core rtlzz_owner_89(.a(64'(mul_tree_17_87)), .b(80'(mul_tree_17_88)), .cin(1'h0), .value(mul_tree_17_89[63:0]));
    assign mul_tree_17_89[80:64] = '0;
    assign mul_tree_17_90 = ({17'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_91 = ({1'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(48'(mul_tree_17_90)), .b(64'(mul_tree_17_91)), .cin(1'h0), .value(mul_tree_17_92[63:0]));
    assign mul_tree_17_92[64:64] = '0;
    assign mul_tree_17_93 = ({17'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_94 = ({1'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(80'(mul_tree_17_93)), .b(96'(mul_tree_17_94)), .cin(1'h0), .value(mul_tree_17_95[63:0]));
    assign mul_tree_17_95[96:64] = '0;
    assign mul_tree_17_96 = ({17'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_97 = ({1'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(64'(mul_tree_17_96)), .b(80'(mul_tree_17_97)), .cin(1'h0), .value(mul_tree_17_98[63:0]));
    assign mul_tree_17_98[80:64] = '0;
    assign mul_tree_17_99 = ({17'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_100 = ({1'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_101Core rtlzz_owner_101(.a(96'(mul_tree_17_99)), .b(112'(mul_tree_17_100)), .cin(1'h0), .value(mul_tree_17_101[63:0]));
    assign mul_tree_17_101[112:64] = '0;
    assign mul_tree_17_102 = ({17'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_103 = ({1'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_104Core rtlzz_owner_104(.a(80'(mul_tree_17_102)), .b(96'(mul_tree_17_103)), .cin(1'h0), .value(mul_tree_17_104[63:0]));
    assign mul_tree_17_104[96:64] = '0;
    assign mul_tree_17_105 = ({17'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_106 = ({1'h0, rtlzz_pipe_83_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_107Core rtlzz_owner_107(.a(112'(mul_tree_17_105)), .b(128'(mul_tree_17_106)), .cin(1'h0), .value(mul_tree_17_107[63:0]));
    assign mul_tree_17_107[128:64] = '0;
    assign mul_tree_17_108 = ({33'h0, rtlzz_pipe_86_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_109 = ({1'h0, rtlzz_pipe_89_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(49'(mul_tree_17_108)), .b(81'(mul_tree_17_109)), .cin(1'h0), .value(mul_tree_17_110[63:0]));
    assign mul_tree_17_110[81:64] = '0;
    assign mul_tree_17_111 = ({33'h0, rtlzz_pipe_92_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_112 = ({1'h0, rtlzz_pipe_95_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_113Core rtlzz_owner_113(.a(65'(mul_tree_17_111)), .b(97'(mul_tree_17_112)), .cin(1'h0), .value(mul_tree_17_113[63:0]));
    assign mul_tree_17_113[97:64] = '0;
    assign mul_tree_17_114 = ({33'h0, rtlzz_pipe_98_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_115 = ({1'h0, rtlzz_pipe_101_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_116Core rtlzz_owner_116(.a(81'(mul_tree_17_114)), .b(113'(mul_tree_17_115)), .cin(1'h0), .value(mul_tree_17_116[63:0]));
    assign mul_tree_17_116[113:64] = '0;
    assign mul_tree_17_117 = ({33'h0, rtlzz_pipe_104_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_118 = ({1'h0, rtlzz_pipe_107_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_119Core rtlzz_owner_119(.a(97'(mul_tree_17_117)), .b(129'(mul_tree_17_118)), .cin(1'h0), .value(mul_tree_17_119[63:0]));
    assign mul_tree_17_119[129:64] = '0;
    assign mul_tree_17_120 = ({17'h0, rtlzz_pipe_110_s3}); // decl: <none>; prim: <none>
    assign mul_tree_17_121 = ({1'h0, rtlzz_pipe_113_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_122Core rtlzz_owner_122(.a(82'(mul_tree_17_120)), .b(98'(mul_tree_17_121)), .cin(1'h0), .value(mul_tree_17_122[63:0]));
    assign mul_tree_17_122[98:64] = '0;
    assign mul_tree_17_123 = ({17'h0, rtlzz_pipe_116_s3}); // decl: <none>; prim: <none>
    assign mul_tree_17_124 = ({1'h0, rtlzz_pipe_119_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_125Core rtlzz_owner_125(.a(114'(mul_tree_17_123)), .b(130'(mul_tree_17_124)), .cin(1'h0), .value(mul_tree_17_125[63:0]));
    assign mul_tree_17_125[130:64] = '0;
    assign mul_tree_17_126 = ({33'h0, rtlzz_pipe_122_s4}); // decl: <none>; prim: <none>
    assign mul_tree_17_127 = ({1'h0, rtlzz_pipe_125_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_128Core rtlzz_owner_128(.a(99'(mul_tree_17_126)), .b(131'(mul_tree_17_127)), .cin(1'h0), .value(mul_tree_17_128[63:0]));
    assign mul_tree_17_128[131:64] = '0;
    assign mul_tree_17_129 = mul_tree_17_128[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_130 = rtlzz_pipe_8_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_131 = rtlzz_pipe_0_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(16'(mul_tree_18_130)), .b(16'(mul_tree_18_131)), .cin(1'b0), .value(mul_tree_18_132));
    assign mul_tree_18_133 = rtlzz_pipe_8_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_134 = rtlzz_pipe_0_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_135Core rtlzz_owner_135(.a(16'(mul_tree_18_133)), .b(16'(mul_tree_18_134)), .cin(1'b0), .value(mul_tree_18_135));
    assign mul_tree_18_136 = {mul_tree_18_135, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_137 = rtlzz_pipe_8_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_138 = rtlzz_pipe_0_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_139Core rtlzz_owner_139(.a(16'(mul_tree_18_137)), .b(16'(mul_tree_18_138)), .cin(1'b0), .value(mul_tree_18_139));
    assign mul_tree_18_140 = {mul_tree_18_139, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_141 = rtlzz_pipe_8_s6[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_142 = rtlzz_pipe_0_s6[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(16'(mul_tree_18_141)), .b(16'(mul_tree_18_142)), .cin(1'b0), .value(mul_tree_18_143[15:0]));
    assign mul_tree_18_143[31:16] = '0;
    assign mul_tree_18_144 = {mul_tree_18_143, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_145 = rtlzz_pipe_8_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_18_146 = rtlzz_pipe_0_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_147Core rtlzz_owner_147(.a(16'(mul_tree_18_145)), .b(16'(mul_tree_18_146)), .cin(1'b0), .value(mul_tree_18_147));
    assign mul_tree_18_148 = {mul_tree_18_147, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_149 = rtlzz_pipe_8_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_18_150 = rtlzz_pipe_0_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(16'(mul_tree_18_149)), .b(16'(mul_tree_18_150)), .cin(1'b0), .value(mul_tree_18_151));
    assign mul_tree_18_152 = {mul_tree_18_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_153 = rtlzz_pipe_8_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_18_154 = rtlzz_pipe_0_s6[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(16'(mul_tree_18_153)), .b(16'(mul_tree_18_154)), .cin(1'b0), .value(mul_tree_18_155[15:0]));
    assign mul_tree_18_155[31:16] = '0;
    assign mul_tree_18_156 = {mul_tree_18_155, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_157 = rtlzz_pipe_8_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_18_158 = rtlzz_pipe_0_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_159 = 32'(($unsigned(32'($unsigned(mul_tree_18_157))) * $unsigned(32'($unsigned(mul_tree_18_158))))); // decl: <none>; prim: <none>
    assign mul_tree_18_160 = {mul_tree_18_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_161 = rtlzz_pipe_8_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_162 = rtlzz_pipe_0_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(16'(mul_tree_18_161)), .b(16'(mul_tree_18_162)), .cin(1'b0), .value(mul_tree_18_163));
    assign mul_tree_18_164 = {mul_tree_18_163, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_165 = rtlzz_pipe_8_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_166 = rtlzz_pipe_0_s6[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(16'(mul_tree_18_165)), .b(16'(mul_tree_18_166)), .cin(1'b0), .value(mul_tree_18_167[15:0]));
    assign mul_tree_18_167[31:16] = '0;
    assign mul_tree_18_168 = {mul_tree_18_167, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_169 = rtlzz_pipe_8_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_170 = rtlzz_pipe_0_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_171 = 32'(($unsigned(32'($unsigned(mul_tree_18_169))) * $unsigned(32'($unsigned(mul_tree_18_170))))); // decl: <none>; prim: <none>
    assign mul_tree_18_172 = {mul_tree_18_171, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_173 = rtlzz_pipe_8_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_174 = rtlzz_pipe_0_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_175 = 32'(($unsigned(32'($unsigned(mul_tree_18_173))) * $unsigned(32'($unsigned(mul_tree_18_174))))); // decl: <none>; prim: <none>
    assign mul_tree_18_176 = {mul_tree_18_175, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_177 = rtlzz_pipe_8_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_178 = rtlzz_pipe_0_s6[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_179Core rtlzz_owner_179(.a(16'(mul_tree_18_177)), .b(16'(mul_tree_18_178)), .cin(1'b0), .value(mul_tree_18_179[15:0]));
    assign mul_tree_18_179[31:16] = '0;
    assign mul_tree_18_180 = {mul_tree_18_179, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_181 = rtlzz_pipe_8_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_182 = rtlzz_pipe_0_s6[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_18_183 = 32'(($unsigned(32'($unsigned(mul_tree_18_181))) * $unsigned(32'($unsigned(mul_tree_18_182))))); // decl: <none>; prim: <none>
    assign mul_tree_18_184 = {mul_tree_18_183, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_185 = rtlzz_pipe_8_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_186 = rtlzz_pipe_0_s6[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_187 = 32'(($unsigned(32'($unsigned(mul_tree_18_185))) * $unsigned(32'($unsigned(mul_tree_18_186))))); // decl: <none>; prim: <none>
    assign mul_tree_18_188 = {mul_tree_18_187, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_189 = rtlzz_pipe_8_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_190 = rtlzz_pipe_0_s6[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_18_191 = 32'(($unsigned(32'($unsigned(mul_tree_18_189))) * $unsigned(32'($unsigned(mul_tree_18_190))))); // decl: <none>; prim: <none>
    assign mul_tree_18_192 = {mul_tree_18_191, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_193 = ({17'h0, mul_tree_18_132}); // decl: <none>; prim: <none>
    assign mul_tree_18_194 = ({1'h0, mul_tree_18_136}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_195Core rtlzz_owner_195(.a(32'(mul_tree_18_193)), .b(48'(mul_tree_18_194)), .cin(1'h0), .value(mul_tree_18_195));
    assign mul_tree_18_196 = ({17'h0, mul_tree_18_140}); // decl: <none>; prim: <none>
    assign mul_tree_18_197 = ({1'h0, mul_tree_18_144}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(64'(mul_tree_18_196)), .b(80'(mul_tree_18_197)), .cin(1'h0), .value(mul_tree_18_198[63:0]));
    assign mul_tree_18_198[80:64] = '0;
    assign mul_tree_18_199 = ({17'h0, mul_tree_18_148}); // decl: <none>; prim: <none>
    assign mul_tree_18_200 = ({1'h0, mul_tree_18_152}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(48'(mul_tree_18_199)), .b(64'(mul_tree_18_200)), .cin(1'h0), .value(mul_tree_18_201[63:0]));
    assign mul_tree_18_201[64:64] = '0;
    assign mul_tree_18_202 = ({17'h0, mul_tree_18_156}); // decl: <none>; prim: <none>
    assign mul_tree_18_203 = ({1'h0, mul_tree_18_160}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(80'(mul_tree_18_202)), .b(96'(mul_tree_18_203)), .cin(1'h0), .value(mul_tree_18_204[63:0]));
    assign mul_tree_18_204[96:64] = '0;
    assign mul_tree_18_205 = ({17'h0, mul_tree_18_164}); // decl: <none>; prim: <none>
    assign mul_tree_18_206 = ({1'h0, mul_tree_18_168}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_207Core rtlzz_owner_207(.a(64'(mul_tree_18_205)), .b(80'(mul_tree_18_206)), .cin(1'h0), .value(mul_tree_18_207[63:0]));
    assign mul_tree_18_207[80:64] = '0;
    assign mul_tree_18_208 = ({17'h0, mul_tree_18_172}); // decl: <none>; prim: <none>
    assign mul_tree_18_209 = ({1'h0, mul_tree_18_176}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_210Core rtlzz_owner_210(.a(96'(mul_tree_18_208)), .b(112'(mul_tree_18_209)), .cin(1'h0), .value(mul_tree_18_210[63:0]));
    assign mul_tree_18_210[112:64] = '0;
    assign mul_tree_18_211 = ({17'h0, mul_tree_18_180}); // decl: <none>; prim: <none>
    assign mul_tree_18_212 = ({1'h0, mul_tree_18_184}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_213Core rtlzz_owner_213(.a(80'(mul_tree_18_211)), .b(96'(mul_tree_18_212)), .cin(1'h0), .value(mul_tree_18_213[63:0]));
    assign mul_tree_18_213[96:64] = '0;
    assign mul_tree_18_214 = ({17'h0, mul_tree_18_188}); // decl: <none>; prim: <none>
    assign mul_tree_18_215 = ({1'h0, mul_tree_18_192}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(112'(mul_tree_18_214)), .b(128'(mul_tree_18_215)), .cin(1'h0), .value(mul_tree_18_216[63:0]));
    assign mul_tree_18_216[128:64] = '0;
    assign mul_tree_18_217 = ({33'h0, rtlzz_pipe_195_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_218 = ({1'h0, rtlzz_pipe_198_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_220 = ({33'h0, rtlzz_pipe_201_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_221 = ({1'h0, rtlzz_pipe_204_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_223 = ({33'h0, rtlzz_pipe_207_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_224 = ({1'h0, rtlzz_pipe_210_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_226 = ({33'h0, rtlzz_pipe_213_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_227 = ({1'h0, rtlzz_pipe_216_s7}); // decl: <none>; prim: <none>
    assign mul_tree_18_229 = ({17'h0, mul_tree_18_219}); // decl: <none>; prim: <none>
    assign mul_tree_18_230 = ({1'h0, mul_tree_18_222}); // decl: <none>; prim: <none>
    assign mul_tree_18_232 = ({17'h0, mul_tree_18_225}); // decl: <none>; prim: <none>
    assign mul_tree_18_233 = ({1'h0, mul_tree_18_228}); // decl: <none>; prim: <none>
    assign mul_tree_18_235 = ({33'h0, mul_tree_18_231}); // decl: <none>; prim: <none>
    assign mul_tree_18_236 = ({1'h0, mul_tree_18_234}); // decl: <none>; prim: <none>
    assign mul_tree_18_238 = mul_tree_18_237[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_239 = s8_norm_add_5_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_240 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_241Core rtlzz_owner_241(.a(16'(mul_tree_19_239)), .b(16'(mul_tree_19_240)), .cin(1'b0), .value(mul_tree_19_241));
    assign mul_tree_19_242 = s8_norm_add_5_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_243 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(16'(mul_tree_19_242)), .b(16'(mul_tree_19_243)), .cin(1'b0), .value(mul_tree_19_244));
    assign mul_tree_19_245 = {mul_tree_19_244, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_246 = s8_norm_add_5_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_247 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(16'(mul_tree_19_246)), .b(16'(mul_tree_19_247)), .cin(1'b0), .value(mul_tree_19_248));
    assign mul_tree_19_249 = {mul_tree_19_248, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_250 = s8_norm_add_5_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_251 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(16'(mul_tree_19_250)), .b(16'(mul_tree_19_251)), .cin(1'b0), .value(mul_tree_19_252[15:0]));
    assign mul_tree_19_252[31:16] = '0;
    assign mul_tree_19_253 = {mul_tree_19_252, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_254 = s8_norm_add_5_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_19_255 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_256Core rtlzz_owner_256(.a(16'(mul_tree_19_254)), .b(16'(mul_tree_19_255)), .cin(1'b0), .value(mul_tree_19_256));
    assign mul_tree_19_257 = {mul_tree_19_256, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_258 = s8_norm_add_5_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_19_259 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_260Core rtlzz_owner_260(.a(16'(mul_tree_19_258)), .b(16'(mul_tree_19_259)), .cin(1'b0), .value(mul_tree_19_260));
    assign mul_tree_19_261 = {mul_tree_19_260, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_262 = s8_norm_add_5_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_19_263 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_264Core rtlzz_owner_264(.a(16'(mul_tree_19_262)), .b(16'(mul_tree_19_263)), .cin(1'b0), .value(mul_tree_19_264[15:0]));
    assign mul_tree_19_264[31:16] = '0;
    assign mul_tree_19_265 = {mul_tree_19_264, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_266 = s8_norm_add_5_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_19_267 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_268 = 32'(($unsigned(32'($unsigned(mul_tree_19_266))) * $unsigned(32'($unsigned(mul_tree_19_267))))); // decl: <none>; prim: <none>
    assign mul_tree_19_269 = {mul_tree_19_268, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_270 = s8_norm_add_5_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_271 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_272Core rtlzz_owner_272(.a(16'(mul_tree_19_270)), .b(16'(mul_tree_19_271)), .cin(1'b0), .value(mul_tree_19_272));
    assign mul_tree_19_273 = {mul_tree_19_272, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_274 = s8_norm_add_5_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_275 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(16'(mul_tree_19_274)), .b(16'(mul_tree_19_275)), .cin(1'b0), .value(mul_tree_19_276[15:0]));
    assign mul_tree_19_276[31:16] = '0;
    assign mul_tree_19_277 = {mul_tree_19_276, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_278 = s8_norm_add_5_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_279 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_280 = 32'(($unsigned(32'($unsigned(mul_tree_19_278))) * $unsigned(32'($unsigned(mul_tree_19_279))))); // decl: <none>; prim: <none>
    assign mul_tree_19_281 = {mul_tree_19_280, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_282 = s8_norm_add_5_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_283 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_284 = 32'(($unsigned(32'($unsigned(mul_tree_19_282))) * $unsigned(32'($unsigned(mul_tree_19_283))))); // decl: <none>; prim: <none>
    assign mul_tree_19_285 = {mul_tree_19_284, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_286 = s8_norm_add_5_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_287 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_288Core rtlzz_owner_288(.a(16'(mul_tree_19_286)), .b(16'(mul_tree_19_287)), .cin(1'b0), .value(mul_tree_19_288[15:0]));
    assign mul_tree_19_288[31:16] = '0;
    assign mul_tree_19_289 = {mul_tree_19_288, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_290 = s8_norm_add_5_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_291 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_19_292 = 32'(($unsigned(32'($unsigned(mul_tree_19_290))) * $unsigned(32'($unsigned(mul_tree_19_291))))); // decl: <none>; prim: <none>
    assign mul_tree_19_293 = {mul_tree_19_292, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_294 = s8_norm_add_5_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_295 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_296 = 32'(($unsigned(32'($unsigned(mul_tree_19_294))) * $unsigned(32'($unsigned(mul_tree_19_295))))); // decl: <none>; prim: <none>
    assign mul_tree_19_297 = {mul_tree_19_296, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_298 = s8_norm_add_5_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_299 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_19_300 = 32'(($unsigned(32'($unsigned(mul_tree_19_298))) * $unsigned(32'($unsigned(mul_tree_19_299))))); // decl: <none>; prim: <none>
    assign mul_tree_19_301 = {mul_tree_19_300, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_302 = ({17'h0, mul_tree_19_241}); // decl: <none>; prim: <none>
    assign mul_tree_19_303 = ({1'h0, mul_tree_19_245}); // decl: <none>; prim: <none>
    assign mul_tree_19_305 = ({17'h0, mul_tree_19_249}); // decl: <none>; prim: <none>
    assign mul_tree_19_306 = ({1'h0, mul_tree_19_253}); // decl: <none>; prim: <none>
    assign mul_tree_19_308 = ({17'h0, mul_tree_19_257}); // decl: <none>; prim: <none>
    assign mul_tree_19_309 = ({1'h0, mul_tree_19_261}); // decl: <none>; prim: <none>
    assign mul_tree_19_311 = ({17'h0, mul_tree_19_265}); // decl: <none>; prim: <none>
    assign mul_tree_19_312 = ({1'h0, mul_tree_19_269}); // decl: <none>; prim: <none>
    assign mul_tree_19_314 = ({17'h0, mul_tree_19_273}); // decl: <none>; prim: <none>
    assign mul_tree_19_315 = ({1'h0, mul_tree_19_277}); // decl: <none>; prim: <none>
    assign mul_tree_19_317 = ({17'h0, mul_tree_19_281}); // decl: <none>; prim: <none>
    assign mul_tree_19_318 = ({1'h0, mul_tree_19_285}); // decl: <none>; prim: <none>
    assign mul_tree_19_320 = ({17'h0, mul_tree_19_289}); // decl: <none>; prim: <none>
    assign mul_tree_19_321 = ({1'h0, mul_tree_19_293}); // decl: <none>; prim: <none>
    assign mul_tree_19_323 = ({17'h0, mul_tree_19_297}); // decl: <none>; prim: <none>
    assign mul_tree_19_324 = ({1'h0, mul_tree_19_301}); // decl: <none>; prim: <none>
    assign mul_tree_19_326 = ({33'h0, mul_tree_19_304}); // decl: <none>; prim: <none>
    assign mul_tree_19_327 = ({1'h0, mul_tree_19_307}); // decl: <none>; prim: <none>
    assign mul_tree_19_329 = ({33'h0, mul_tree_19_310}); // decl: <none>; prim: <none>
    assign mul_tree_19_330 = ({1'h0, mul_tree_19_313}); // decl: <none>; prim: <none>
    assign mul_tree_19_332 = ({33'h0, mul_tree_19_316}); // decl: <none>; prim: <none>
    assign mul_tree_19_333 = ({1'h0, mul_tree_19_319}); // decl: <none>; prim: <none>
    assign mul_tree_19_335 = ({33'h0, mul_tree_19_322}); // decl: <none>; prim: <none>
    assign mul_tree_19_336 = ({1'h0, mul_tree_19_325}); // decl: <none>; prim: <none>
    assign mul_tree_19_338 = ({17'h0, mul_tree_19_328}); // decl: <none>; prim: <none>
    assign mul_tree_19_339 = ({1'h0, mul_tree_19_331}); // decl: <none>; prim: <none>
    assign mul_tree_19_341 = ({17'h0, mul_tree_19_334}); // decl: <none>; prim: <none>
    assign mul_tree_19_342 = ({1'h0, mul_tree_19_337}); // decl: <none>; prim: <none>
    assign mul_tree_19_344 = ({33'h0, mul_tree_19_340}); // decl: <none>; prim: <none>
    assign mul_tree_19_345 = ({1'h0, mul_tree_19_343}); // decl: <none>; prim: <none>
    assign mul_tree_19_347 = mul_tree_19_346[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_348 = s8_norm_add_8_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_349 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_350Core rtlzz_owner_350(.a(16'(mul_tree_20_348)), .b(16'(mul_tree_20_349)), .cin(1'b0), .value(mul_tree_20_350));
    assign mul_tree_20_351 = s8_norm_add_8_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_352 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_353Core rtlzz_owner_353(.a(16'(mul_tree_20_351)), .b(16'(mul_tree_20_352)), .cin(1'b0), .value(mul_tree_20_353));
    assign mul_tree_20_354 = {mul_tree_20_353, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_355 = s8_norm_add_8_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_356 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_357Core rtlzz_owner_357(.a(16'(mul_tree_20_355)), .b(16'(mul_tree_20_356)), .cin(1'b0), .value(mul_tree_20_357));
    assign mul_tree_20_358 = {mul_tree_20_357, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_359 = s8_norm_add_8_v0[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_360 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_361Core rtlzz_owner_361(.a(16'(mul_tree_20_359)), .b(16'(mul_tree_20_360)), .cin(1'b0), .value(mul_tree_20_361[15:0]));
    assign mul_tree_20_361[31:16] = '0;
    assign mul_tree_20_362 = {mul_tree_20_361, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_363 = s8_norm_add_8_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_20_364 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_365Core rtlzz_owner_365(.a(16'(mul_tree_20_363)), .b(16'(mul_tree_20_364)), .cin(1'b0), .value(mul_tree_20_365));
    assign mul_tree_20_366 = {mul_tree_20_365, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_367 = s8_norm_add_8_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_20_368 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(16'(mul_tree_20_367)), .b(16'(mul_tree_20_368)), .cin(1'b0), .value(mul_tree_20_369));
    assign mul_tree_20_370 = {mul_tree_20_369, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_371 = s8_norm_add_8_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_20_372 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(16'(mul_tree_20_371)), .b(16'(mul_tree_20_372)), .cin(1'b0), .value(mul_tree_20_373[15:0]));
    assign mul_tree_20_373[31:16] = '0;
    assign mul_tree_20_374 = {mul_tree_20_373, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_375 = s8_norm_add_8_v0[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_20_376 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_377 = 32'(($unsigned(32'($unsigned(mul_tree_20_375))) * $unsigned(32'($unsigned(mul_tree_20_376))))); // decl: <none>; prim: <none>
    assign mul_tree_20_378 = {mul_tree_20_377, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_379 = s8_norm_add_8_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_380 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_381Core rtlzz_owner_381(.a(16'(mul_tree_20_379)), .b(16'(mul_tree_20_380)), .cin(1'b0), .value(mul_tree_20_381));
    assign mul_tree_20_382 = {mul_tree_20_381, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_383 = s8_norm_add_8_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_384 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_385Core rtlzz_owner_385(.a(16'(mul_tree_20_383)), .b(16'(mul_tree_20_384)), .cin(1'b0), .value(mul_tree_20_385[15:0]));
    assign mul_tree_20_385[31:16] = '0;
    assign mul_tree_20_386 = {mul_tree_20_385, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_387 = s8_norm_add_8_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_388 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_389 = 32'(($unsigned(32'($unsigned(mul_tree_20_387))) * $unsigned(32'($unsigned(mul_tree_20_388))))); // decl: <none>; prim: <none>
    assign mul_tree_20_390 = {mul_tree_20_389, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_391 = s8_norm_add_8_v0[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_392 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_393 = 32'(($unsigned(32'($unsigned(mul_tree_20_391))) * $unsigned(32'($unsigned(mul_tree_20_392))))); // decl: <none>; prim: <none>
    assign mul_tree_20_394 = {mul_tree_20_393, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_395 = s8_norm_add_8_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_396 = rtlzz_pipe_0_s7[15:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397Core rtlzz_owner_397(.a(16'(mul_tree_20_395)), .b(16'(mul_tree_20_396)), .cin(1'b0), .value(mul_tree_20_397[15:0]));
    assign mul_tree_20_397[31:16] = '0;
    assign mul_tree_20_398 = {mul_tree_20_397, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_399 = s8_norm_add_8_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_400 = rtlzz_pipe_0_s7[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_20_401 = 32'(($unsigned(32'($unsigned(mul_tree_20_399))) * $unsigned(32'($unsigned(mul_tree_20_400))))); // decl: <none>; prim: <none>
    assign mul_tree_20_402 = {mul_tree_20_401, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_403 = s8_norm_add_8_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_404 = rtlzz_pipe_0_s7[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_405 = 32'(($unsigned(32'($unsigned(mul_tree_20_403))) * $unsigned(32'($unsigned(mul_tree_20_404))))); // decl: <none>; prim: <none>
    assign mul_tree_20_406 = {mul_tree_20_405, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_407 = s8_norm_add_8_v0[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_408 = rtlzz_pipe_0_s7[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_20_409 = 32'(($unsigned(32'($unsigned(mul_tree_20_407))) * $unsigned(32'($unsigned(mul_tree_20_408))))); // decl: <none>; prim: <none>
    assign mul_tree_20_410 = {mul_tree_20_409, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_411 = ({17'h0, mul_tree_20_350}); // decl: <none>; prim: <none>
    assign mul_tree_20_412 = ({1'h0, mul_tree_20_354}); // decl: <none>; prim: <none>
    assign mul_tree_20_414 = ({17'h0, mul_tree_20_358}); // decl: <none>; prim: <none>
    assign mul_tree_20_415 = ({1'h0, mul_tree_20_362}); // decl: <none>; prim: <none>
    assign mul_tree_20_417 = ({17'h0, mul_tree_20_366}); // decl: <none>; prim: <none>
    assign mul_tree_20_418 = ({1'h0, mul_tree_20_370}); // decl: <none>; prim: <none>
    assign mul_tree_20_420 = ({17'h0, mul_tree_20_374}); // decl: <none>; prim: <none>
    assign mul_tree_20_421 = ({1'h0, mul_tree_20_378}); // decl: <none>; prim: <none>
    assign mul_tree_20_423 = ({17'h0, mul_tree_20_382}); // decl: <none>; prim: <none>
    assign mul_tree_20_424 = ({1'h0, mul_tree_20_386}); // decl: <none>; prim: <none>
    assign mul_tree_20_426 = ({17'h0, mul_tree_20_390}); // decl: <none>; prim: <none>
    assign mul_tree_20_427 = ({1'h0, mul_tree_20_394}); // decl: <none>; prim: <none>
    assign mul_tree_20_429 = ({17'h0, mul_tree_20_398}); // decl: <none>; prim: <none>
    assign mul_tree_20_430 = ({1'h0, mul_tree_20_402}); // decl: <none>; prim: <none>
    assign mul_tree_20_432 = ({17'h0, mul_tree_20_406}); // decl: <none>; prim: <none>
    assign mul_tree_20_433 = ({1'h0, mul_tree_20_410}); // decl: <none>; prim: <none>
    assign mul_tree_20_435 = ({33'h0, mul_tree_20_413}); // decl: <none>; prim: <none>
    assign mul_tree_20_436 = ({1'h0, mul_tree_20_416}); // decl: <none>; prim: <none>
    assign mul_tree_20_438 = ({33'h0, mul_tree_20_419}); // decl: <none>; prim: <none>
    assign mul_tree_20_439 = ({1'h0, mul_tree_20_422}); // decl: <none>; prim: <none>
    assign mul_tree_20_441 = ({33'h0, mul_tree_20_425}); // decl: <none>; prim: <none>
    assign mul_tree_20_442 = ({1'h0, mul_tree_20_428}); // decl: <none>; prim: <none>
    assign mul_tree_20_444 = ({33'h0, mul_tree_20_431}); // decl: <none>; prim: <none>
    assign mul_tree_20_445 = ({1'h0, mul_tree_20_434}); // decl: <none>; prim: <none>
    assign mul_tree_20_447 = ({17'h0, mul_tree_20_437}); // decl: <none>; prim: <none>
    assign mul_tree_20_448 = ({1'h0, mul_tree_20_440}); // decl: <none>; prim: <none>
    assign mul_tree_20_450 = ({17'h0, mul_tree_20_443}); // decl: <none>; prim: <none>
    assign mul_tree_20_451 = ({1'h0, mul_tree_20_446}); // decl: <none>; prim: <none>
    assign mul_tree_20_453 = ({33'h0, mul_tree_20_449}); // decl: <none>; prim: <none>
    assign mul_tree_20_454 = ({1'h0, mul_tree_20_452}); // decl: <none>; prim: <none>
    assign mul_tree_20_456 = mul_tree_20_455[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_1_s1 <= 64'h0;
            rtlzz_pipe_1_s2 <= 64'h0;
            rtlzz_pipe_1_s3 <= 64'h0;
            rtlzz_pipe_1_s4 <= 64'h0;
            rtlzz_pipe_1_s5 <= 64'h0;
            rtlzz_pipe_1_s6 <= 64'h0;
            rtlzz_pipe_1_s7 <= 64'h0;
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_2_s3 <= 64'h0;
            rtlzz_pipe_2_s4 <= 64'h0;
            rtlzz_pipe_2_s5 <= 64'h0;
            rtlzz_pipe_2_s6 <= 64'h0;
            rtlzz_pipe_2_s7 <= 64'h0;
            rtlzz_pipe_3_s1 <= 64'h0;
            rtlzz_pipe_3_s2 <= 64'h0;
            rtlzz_pipe_3_s3 <= 64'h0;
            rtlzz_pipe_3_s4 <= 64'h0;
            rtlzz_pipe_3_s5 <= 64'h0;
            rtlzz_pipe_3_s6 <= 64'h0;
            rtlzz_pipe_3_s7 <= 64'h0;
            rtlzz_pipe_4_s1 <= 64'h0;
            rtlzz_pipe_4_s2 <= 64'h0;
            rtlzz_pipe_4_s3 <= 64'h0;
            rtlzz_pipe_4_s4 <= 64'h0;
            rtlzz_pipe_4_s5 <= 64'h0;
            rtlzz_pipe_23_s1 <= 32'h0;
            rtlzz_pipe_27_s1 <= 48'h0;
            rtlzz_pipe_31_s1 <= 64'h0;
            rtlzz_pipe_35_s1 <= 80'h0;
            rtlzz_pipe_39_s1 <= 48'h0;
            rtlzz_pipe_43_s1 <= 64'h0;
            rtlzz_pipe_47_s1 <= 80'h0;
            rtlzz_pipe_51_s1 <= 96'h0;
            rtlzz_pipe_55_s1 <= 64'h0;
            rtlzz_pipe_59_s1 <= 80'h0;
            rtlzz_pipe_63_s1 <= 96'h0;
            rtlzz_pipe_67_s1 <= 112'h0;
            rtlzz_pipe_71_s1 <= 80'h0;
            rtlzz_pipe_75_s1 <= 96'h0;
            rtlzz_pipe_79_s1 <= 112'h0;
            rtlzz_pipe_83_s1 <= 128'h0;
            rtlzz_pipe_86_s2 <= 49'h0;
            rtlzz_pipe_89_s2 <= 81'h0;
            rtlzz_pipe_92_s2 <= 65'h0;
            rtlzz_pipe_95_s2 <= 97'h0;
            rtlzz_pipe_98_s2 <= 81'h0;
            rtlzz_pipe_101_s2 <= 113'h0;
            rtlzz_pipe_104_s2 <= 97'h0;
            rtlzz_pipe_107_s2 <= 129'h0;
            rtlzz_pipe_110_s3 <= 82'h0;
            rtlzz_pipe_113_s3 <= 98'h0;
            rtlzz_pipe_116_s3 <= 114'h0;
            rtlzz_pipe_119_s3 <= 130'h0;
            rtlzz_pipe_122_s4 <= 99'h0;
            rtlzz_pipe_125_s4 <= 131'h0;
            rtlzz_pipe_7_s5 <= 64'h0;
            rtlzz_pipe_8_s6 <= 64'h0;
            rtlzz_pipe_195_s7 <= 49'h0;
            rtlzz_pipe_198_s7 <= 81'h0;
            rtlzz_pipe_201_s7 <= 65'h0;
            rtlzz_pipe_204_s7 <= 97'h0;
            rtlzz_pipe_207_s7 <= 81'h0;
            rtlzz_pipe_210_s7 <= 113'h0;
            rtlzz_pipe_213_s7 <= 97'h0;
            rtlzz_pipe_216_s7 <= 129'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_1_s1 <= c0; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1_s2 <= rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1_s3 <= rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1_s4 <= rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1_s5 <= rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1_s6 <= rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1_s7 <= rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (iv) begin
        rtlzz_pipe_2_s1 <= c1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_2_s3 <= rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_2_s4 <= rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_2_s5 <= rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_2_s6 <= rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_2_s7 <= rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= c2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_3_s2 <= rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_3_s4 <= rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_3_s5 <= rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_3_s6 <= rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_3_s7 <= rtlzz_pipe_3_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= c3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_4_s3 <= rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_4_s4 <= rtlzz_pipe_4_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_4_s5 <= rtlzz_pipe_4_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_17_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_17_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_17_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_17_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_17_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_17_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_17_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_17_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_17_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_17_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_17_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_17_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_17_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_17_75; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_17_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_83_s1 <= mul_tree_17_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_86_s2 <= mul_tree_17_86; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_89_s2 <= mul_tree_17_89; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_92_s2 <= mul_tree_17_92; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_95_s2 <= mul_tree_17_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_98_s2 <= mul_tree_17_98; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_101_s2 <= mul_tree_17_101; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= mul_tree_17_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= mul_tree_17_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_110_s3 <= mul_tree_17_110; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_113_s3 <= mul_tree_17_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_116_s3 <= mul_tree_17_116; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_119_s3 <= mul_tree_17_119; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_122_s4 <= mul_tree_17_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= mul_tree_17_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_8_s6 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_195_s7 <= mul_tree_18_195; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_198_s7 <= mul_tree_18_198; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_201_s7 <= mul_tree_18_201; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_204_s7 <= mul_tree_18_204; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_207_s7 <= mul_tree_18_207; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_210_s7 <= mul_tree_18_210; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_213_s7 <= mul_tree_18_213; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_216_s7 <= mul_tree_18_216; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10_reduce(input wire [63:0] i484, input wire [48:0] i522, input wire [80:0] i523, input wire [64:0] i524, input wire [96:0] i525, input wire [80:0] i526, input wire [112:0] i527, input wire [96:0] i528, input wire [128:0] i529, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i522[48], i522[47], i522[46], i522[45], i522[44], i522[43], i522[42], i522[41], i522[40], i522[39], i522[38], i522[37], i522[36], i522[35], i522[34], i522[33], i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0]};
wire [63:0] t1 = {i523[63], i523[62], i523[61], i523[60], i523[59], i523[58], i523[57], i523[56], i523[55], i523[54], i523[53], i523[52], i523[51], i523[50], i523[49], i523[48], i523[47], i523[46], i523[45], i523[44], i523[43], i523[42], i523[41], i523[40], i523[39], i523[38], i523[37], i523[36], i523[35], i523[34], i523[33], i523[32], i523[31], i523[30], i523[29], i523[28], i523[27], i523[26], i523[25], i523[24], i523[23], i523[22], i523[21], i523[20], i523[19], i523[18], i523[17], i523[16], i523[15], i523[14], i523[13], i523[12], i523[11], i523[10], i523[9], i523[8], i523[7], i523[6], i523[5], i523[4], i523[3], i523[2], i523[1], i523[0]};
wire [63:0] t2 = {i524[63], i524[62], i524[61], i524[60], i524[59], i524[58], i524[57], i524[56], i524[55], i524[54], i524[53], i524[52], i524[51], i524[50], i524[49], i524[48], i524[47], i524[46], i524[45], i524[44], i524[43], i524[42], i524[41], i524[40], i524[39], i524[38], i524[37], i524[36], i524[35], i524[34], i524[33], i524[32], i524[31], i524[30], i524[29], i524[28], i524[27], i524[26], i524[25], i524[24], i524[23], i524[22], i524[21], i524[20], i524[19], i524[18], i524[17], i524[16], i524[15], i524[14], i524[13], i524[12], i524[11], i524[10], i524[9], i524[8], i524[7], i524[6], i524[5], i524[4], i524[3], i524[2], i524[1], i524[0]};
wire [63:0] t3 = {i525[63], i525[62], i525[61], i525[60], i525[59], i525[58], i525[57], i525[56], i525[55], i525[54], i525[53], i525[52], i525[51], i525[50], i525[49], i525[48], i525[47], i525[46], i525[45], i525[44], i525[43], i525[42], i525[41], i525[40], i525[39], i525[38], i525[37], i525[36], i525[35], i525[34], i525[33], i525[32], i525[31], i525[30], i525[29], i525[28], i525[27], i525[26], i525[25], i525[24], i525[23], i525[22], i525[21], i525[20], i525[19], i525[18], i525[17], i525[16], i525[15], i525[14], i525[13], i525[12], i525[11], i525[10], i525[9], i525[8], i525[7], i525[6], i525[5], i525[4], i525[3], i525[2], i525[1], i525[0]};
wire [63:0] t4 = {i526[63], i526[62], i526[61], i526[60], i526[59], i526[58], i526[57], i526[56], i526[55], i526[54], i526[53], i526[52], i526[51], i526[50], i526[49], i526[48], i526[47], i526[46], i526[45], i526[44], i526[43], i526[42], i526[41], i526[40], i526[39], i526[38], i526[37], i526[36], i526[35], i526[34], i526[33], i526[32], i526[31], i526[30], i526[29], i526[28], i526[27], i526[26], i526[25], i526[24], i526[23], i526[22], i526[21], i526[20], i526[19], i526[18], i526[17], i526[16], i526[15], i526[14], i526[13], i526[12], i526[11], i526[10], i526[9], i526[8], i526[7], i526[6], i526[5], i526[4], i526[3], i526[2], i526[1], i526[0]};
wire [63:0] t5 = {i527[63], i527[62], i527[61], i527[60], i527[59], i527[58], i527[57], i527[56], i527[55], i527[54], i527[53], i527[52], i527[51], i527[50], i527[49], i527[48], i527[47], i527[46], i527[45], i527[44], i527[43], i527[42], i527[41], i527[40], i527[39], i527[38], i527[37], i527[36], i527[35], i527[34], i527[33], i527[32], i527[31], i527[30], i527[29], i527[28], i527[27], i527[26], i527[25], i527[24], i527[23], i527[22], i527[21], i527[20], i527[19], i527[18], i527[17], i527[16], i527[15], i527[14], i527[13], i527[12], i527[11], i527[10], i527[9], i527[8], i527[7], i527[6], i527[5], i527[4], i527[3], i527[2], i527[1], i527[0]};
wire [63:0] t6 = {i528[63], i528[62], i528[61], i528[60], i528[59], i528[58], i528[57], i528[56], i528[55], i528[54], i528[53], i528[52], i528[51], i528[50], i528[49], i528[48], i528[47], i528[46], i528[45], i528[44], i528[43], i528[42], i528[41], i528[40], i528[39], i528[38], i528[37], i528[36], i528[35], i528[34], i528[33], i528[32], i528[31], i528[30], i528[29], i528[28], i528[27], i528[26], i528[25], i528[24], i528[23], i528[22], i528[21], i528[20], i528[19], i528[18], i528[17], i528[16], i528[15], i528[14], i528[13], i528[12], i528[11], i528[10], i528[9], i528[8], i528[7], i528[6], i528[5], i528[4], i528[3], i528[2], i528[1], i528[0]};
wire [63:0] t7 = {i529[63], i529[62], i529[61], i529[60], i529[59], i529[58], i529[57], i529[56], i529[55], i529[54], i529[53], i529[52], i529[51], i529[50], i529[49], i529[48], i529[47], i529[46], i529[45], i529[44], i529[43], i529[42], i529[41], i529[40], i529[39], i529[38], i529[37], i529[36], i529[35], i529[34], i529[33], i529[32], i529[31], i529[30], i529[29], i529[28], i529[27], i529[26], i529[25], i529[24], i529[23], i529[22], i529[21], i529[20], i529[19], i529[18], i529[17], i529[16], i529[15], i529[14], i529[13], i529[12], i529[11], i529[10], i529[9], i529[8], i529[7], i529[6], i529[5], i529[4], i529[3], i529[2], i529[1], i529[0]};
wire [63:0] t8 = {i484[63], i484[62], i484[61], i484[60], i484[59], i484[58], i484[57], i484[56], i484[55], i484[54], i484[53], i484[52], i484[51], i484[50], i484[49], i484[48], i484[47], i484[46], i484[45], i484[44], i484[43], i484[42], i484[41], i484[40], i484[39], i484[38], i484[37], i484[36], i484[35], i484[34], i484[33], i484[32], i484[31], i484[30], i484[29], i484[28], i484[27], i484[26], i484[25], i484[24], i484[23], i484[22], i484[21], i484[20], i484[19], i484[18], i484[17], i484[16], i484[15], i484[14], i484[13], i484[12], i484[11], i484[10], i484[9], i484[8], i484[7], i484[6], i484[5], i484[4], i484[3], i484[2], i484[1], i484[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12_reduce(input wire [31:0] i241, input wire [31:0] i244, input wire [31:0] i248, input wire [31:0] i252, input wire [31:0] i256, input wire [31:0] i260, input wire [31:0] i264, input wire [31:0] i272, input wire [31:0] i276, input wire [31:0] i288, input wire [63:0] i477, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i241[31], i241[30], i241[29], i241[28], i241[27], i241[26], i241[25], i241[24], i241[23], i241[22], i241[21], i241[20], i241[19], i241[18], i241[17], i241[16], i241[15], i241[14], i241[13], i241[12], i241[11], i241[10], i241[9], i241[8], i241[7], i241[6], i241[5], i241[4], i241[3], i241[2], i241[1], i241[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i244[31], i244[30], i244[29], i244[28], i244[27], i244[26], i244[25], i244[24], i244[23], i244[22], i244[21], i244[20], i244[19], i244[18], i244[17], i244[16], i244[15], i244[14], i244[13], i244[12], i244[11], i244[10], i244[9], i244[8], i244[7], i244[6], i244[5], i244[4], i244[3], i244[2], i244[1], i244[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i248[31], i248[30], i248[29], i248[28], i248[27], i248[26], i248[25], i248[24], i248[23], i248[22], i248[21], i248[20], i248[19], i248[18], i248[17], i248[16], i248[15], i248[14], i248[13], i248[12], i248[11], i248[10], i248[9], i248[8], i248[7], i248[6], i248[5], i248[4], i248[3], i248[2], i248[1], i248[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i252[15], i252[14], i252[13], i252[12], i252[11], i252[10], i252[9], i252[8], i252[7], i252[6], i252[5], i252[4], i252[3], i252[2], i252[1], i252[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i256[31], i256[30], i256[29], i256[28], i256[27], i256[26], i256[25], i256[24], i256[23], i256[22], i256[21], i256[20], i256[19], i256[18], i256[17], i256[16], i256[15], i256[14], i256[13], i256[12], i256[11], i256[10], i256[9], i256[8], i256[7], i256[6], i256[5], i256[4], i256[3], i256[2], i256[1], i256[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t5 = {i260[31], i260[30], i260[29], i260[28], i260[27], i260[26], i260[25], i260[24], i260[23], i260[22], i260[21], i260[20], i260[19], i260[18], i260[17], i260[16], i260[15], i260[14], i260[13], i260[12], i260[11], i260[10], i260[9], i260[8], i260[7], i260[6], i260[5], i260[4], i260[3], i260[2], i260[1], i260[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t6 = {i264[15], i264[14], i264[13], i264[12], i264[11], i264[10], i264[9], i264[8], i264[7], i264[6], i264[5], i264[4], i264[3], i264[2], i264[1], i264[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t7 = {i272[31], i272[30], i272[29], i272[28], i272[27], i272[26], i272[25], i272[24], i272[23], i272[22], i272[21], i272[20], i272[19], i272[18], i272[17], i272[16], i272[15], i272[14], i272[13], i272[12], i272[11], i272[10], i272[9], i272[8], i272[7], i272[6], i272[5], i272[4], i272[3], i272[2], i272[1], i272[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t8 = {i276[15], i276[14], i276[13], i276[12], i276[11], i276[10], i276[9], i276[8], i276[7], i276[6], i276[5], i276[4], i276[3], i276[2], i276[1], i276[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t9 = {i288[15], i288[14], i288[13], i288[12], i288[11], i288[10], i288[9], i288[8], i288[7], i288[6], i288[5], i288[4], i288[3], i288[2], i288[1], i288[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t10 = {i477[63], i477[62], i477[61], i477[60], i477[59], i477[58], i477[57], i477[56], i477[55], i477[54], i477[53], i477[52], i477[51], i477[50], i477[49], i477[48], i477[47], i477[46], i477[45], i477[44], i477[43], i477[42], i477[41], i477[40], i477[39], i477[38], i477[37], i477[36], i477[35], i477[34], i477[33], i477[32], i477[31], i477[30], i477[29], i477[28], i477[27], i477[26], i477[25], i477[24], i477[23], i477[22], i477[21], i477[20], i477[19], i477[18], i477[17], i477[16], i477[15], i477[14], i477[13], i477[12], i477[11], i477[10], i477[9], i477[8], i477[7], i477[6], i477[5], i477[4], i477[3], i477[2], i477[1], i477[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14_reduce(input wire [31:0] i350, input wire [31:0] i353, input wire [31:0] i357, input wire [31:0] i361, input wire [31:0] i365, input wire [31:0] i369, input wire [31:0] i373, input wire [31:0] i381, input wire [31:0] i385, input wire [31:0] i397, input wire [63:0] i470, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i350[31], i350[30], i350[29], i350[28], i350[27], i350[26], i350[25], i350[24], i350[23], i350[22], i350[21], i350[20], i350[19], i350[18], i350[17], i350[16], i350[15], i350[14], i350[13], i350[12], i350[11], i350[10], i350[9], i350[8], i350[7], i350[6], i350[5], i350[4], i350[3], i350[2], i350[1], i350[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i353[31], i353[30], i353[29], i353[28], i353[27], i353[26], i353[25], i353[24], i353[23], i353[22], i353[21], i353[20], i353[19], i353[18], i353[17], i353[16], i353[15], i353[14], i353[13], i353[12], i353[11], i353[10], i353[9], i353[8], i353[7], i353[6], i353[5], i353[4], i353[3], i353[2], i353[1], i353[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {i357[31], i357[30], i357[29], i357[28], i357[27], i357[26], i357[25], i357[24], i357[23], i357[22], i357[21], i357[20], i357[19], i357[18], i357[17], i357[16], i357[15], i357[14], i357[13], i357[12], i357[11], i357[10], i357[9], i357[8], i357[7], i357[6], i357[5], i357[4], i357[3], i357[2], i357[1], i357[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i361[15], i361[14], i361[13], i361[12], i361[11], i361[10], i361[9], i361[8], i361[7], i361[6], i361[5], i361[4], i361[3], i361[2], i361[1], i361[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i365[31], i365[30], i365[29], i365[28], i365[27], i365[26], i365[25], i365[24], i365[23], i365[22], i365[21], i365[20], i365[19], i365[18], i365[17], i365[16], i365[15], i365[14], i365[13], i365[12], i365[11], i365[10], i365[9], i365[8], i365[7], i365[6], i365[5], i365[4], i365[3], i365[2], i365[1], i365[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t5 = {i369[31], i369[30], i369[29], i369[28], i369[27], i369[26], i369[25], i369[24], i369[23], i369[22], i369[21], i369[20], i369[19], i369[18], i369[17], i369[16], i369[15], i369[14], i369[13], i369[12], i369[11], i369[10], i369[9], i369[8], i369[7], i369[6], i369[5], i369[4], i369[3], i369[2], i369[1], i369[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t6 = {i373[15], i373[14], i373[13], i373[12], i373[11], i373[10], i373[9], i373[8], i373[7], i373[6], i373[5], i373[4], i373[3], i373[2], i373[1], i373[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t7 = {i381[31], i381[30], i381[29], i381[28], i381[27], i381[26], i381[25], i381[24], i381[23], i381[22], i381[21], i381[20], i381[19], i381[18], i381[17], i381[16], i381[15], i381[14], i381[13], i381[12], i381[11], i381[10], i381[9], i381[8], i381[7], i381[6], i381[5], i381[4], i381[3], i381[2], i381[1], i381[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t8 = {i385[15], i385[14], i385[13], i385[12], i385[11], i385[10], i385[9], i385[8], i385[7], i385[6], i385[5], i385[4], i385[3], i385[2], i385[1], i385[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t9 = {i397[15], i397[14], i397[13], i397[12], i397[11], i397[10], i397[9], i397[8], i397[7], i397[6], i397[5], i397[4], i397[3], i397[2], i397[1], i397[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t10 = {i470[63], i470[62], i470[61], i470[60], i470[59], i470[58], i470[57], i470[56], i470[55], i470[54], i470[53], i470[52], i470[51], i470[50], i470[49], i470[48], i470[47], i470[46], i470[45], i470[44], i470[43], i470[42], i470[41], i470[40], i470[39], i470[38], i470[37], i470[36], i470[35], i470[34], i470[33], i470[32], i470[31], i470[30], i470[29], i470[28], i470[27], i470[26], i470[25], i470[24], i470[23], i470[22], i470[21], i470[20], i470[19], i470[18], i470[17], i470[16], i470[15], i470[14], i470[13], i470[12], i470[11], i470[10], i470[9], i470[8], i470[7], i470[6], i470[5], i470[4], i470[3], i470[2], i470[1], i470[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_8Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_8();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_89Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [79:0] aa=80'(masked_b);
wire [79:0] bb=80'(masked_a);
wire [80:0] extended={1'b0,aa}+{1'b0,bb}+81'(1'b0);
wire [79:0] native_value=extended[79:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_89();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [79:0] aa=80'(masked_b);
wire [79:0] bb=80'(masked_a);
wire [80:0] extended={1'b0,aa}+{1'b0,bb}+81'(1'b0);
wire [79:0] native_value=extended[79:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [63:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [111:0] aa=112'(masked_b);
wire [111:0] bb=112'(masked_a);
wire [112:0] extended={1'b0,aa}+{1'b0,bb}+113'(1'b0);
wire [111:0] native_value=extended[111:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_101();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [63:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [48:0] a,input wire [80:0] b,input wire cin,output wire [63:0] value);
wire [48:0] masked_a=((a&49'h1ffffffffffff)|49'h0);
wire [80:0] masked_b=((b&81'h1ffffffffffffffffffff)|81'h0);
wire [80:0] aa=81'(masked_b);
wire [80:0] bb=81'(masked_a);
wire [81:0] extended={1'b0,aa}+{1'b0,bb}+82'(1'b0);
wire [80:0] native_value=extended[80:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113Core(input wire [64:0] a,input wire [96:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [96:0] masked_b=((b&97'h1ffffffffffffffffffffffff)|97'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116Core(input wire [80:0] a,input wire [112:0] b,input wire cin,output wire [63:0] value);
wire [80:0] masked_a=((a&81'h1ffffffffffffffffffff)|81'h0);
wire [112:0] masked_b=((b&113'h1ffffffffffffffffffffffffffff)|113'h0);
wire [112:0] aa=113'(masked_b);
wire [112:0] bb=113'(masked_a);
wire [113:0] extended={1'b0,aa}+{1'b0,bb}+114'(1'b0);
wire [112:0] native_value=extended[112:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_119Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_119();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122Core(input wire [81:0] a,input wire [97:0] b,input wire cin,output wire [63:0] value);
wire [81:0] masked_a=((a&82'h3ffffffffffffffffffff)|82'h0);
wire [97:0] masked_b=((b&98'h3ffffffffffffffffffffffff)|98'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_125Core(input wire [113:0] a,input wire [129:0] b,input wire cin,output wire [63:0] value);
wire [113:0] masked_a=((a&114'h3ffffffffffffffffffffffffffff)|114'h0);
wire [129:0] masked_b=((b&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_b);
wire [129:0] bb=130'(masked_a);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_125();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128Core(input wire [98:0] a,input wire [130:0] b,input wire cin,output wire [63:0] value);
wire [98:0] masked_a=((a&99'h7ffffffffffffffffffffffff)|99'h0);
wire [130:0] masked_b=((b&131'h7ffffffffffffffffffffffffffffffff)|131'h0);
wire [130:0] aa=131'(masked_b);
wire [130:0] bb=131'(masked_a);
wire [131:0] extended={1'b0,aa}+{1'b0,bb}+132'(1'b0);
wire [130:0] native_value=extended[130:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_128();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195Core(input wire [31:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [47:0] masked_b=((b&48'hffffffff0000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [79:0] aa=80'(masked_b);
wire [79:0] bb=80'(masked_a);
wire [80:0] extended={1'b0,aa}+{1'b0,bb}+81'(1'b0);
wire [79:0] native_value=extended[79:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [47:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [47:0] masked_a=((a&48'hffffffff0000)|48'h0);
wire [63:0] masked_b=((b&64'hffffffff00000000)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_207Core(input wire [63:0] a,input wire [79:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffff00000000)|64'h0);
wire [79:0] masked_b=((b&80'hffffffff000000000000)|80'h0);
wire [79:0] aa=80'(masked_b);
wire [79:0] bb=80'(masked_a);
wire [80:0] extended={1'b0,aa}+{1'b0,bb}+81'(1'b0);
wire [79:0] native_value=extended[79:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_207();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210Core(input wire [95:0] a,input wire [111:0] b,input wire cin,output wire [63:0] value);
wire [95:0] masked_a=((a&96'hffffffff0000000000000000)|96'h0);
wire [111:0] masked_b=((b&112'hffffffff00000000000000000000)|112'h0);
wire [111:0] aa=112'(masked_b);
wire [111:0] bb=112'(masked_a);
wire [112:0] extended={1'b0,aa}+{1'b0,bb}+113'(1'b0);
wire [111:0] native_value=extended[111:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213Core(input wire [79:0] a,input wire [95:0] b,input wire cin,output wire [63:0] value);
wire [79:0] masked_a=((a&80'hffffffff000000000000)|80'h0);
wire [95:0] masked_b=((b&96'hffffffff0000000000000000)|96'h0);
wire [95:0] aa=96'(masked_b);
wire [95:0] bb=96'(masked_a);
wire [96:0] extended={1'b0,aa}+{1'b0,bb}+97'(1'b0);
wire [95:0] native_value=extended[95:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [111:0] a,input wire [127:0] b,input wire cin,output wire [63:0] value);
wire [111:0] masked_a=((a&112'hffffffff00000000000000000000)|112'h0);
wire [127:0] masked_b=((b&128'hffffffff000000000000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_256();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_272Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_272();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_361();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [31:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_385();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397Core(input wire [15:0] a,input wire [15:0] b,input wire cin,output wire [15:0] value);
wire [15:0] masked_a=((a&16'hffff)|16'h0);
wire [15:0] masked_b=((b&16'hffff)|16'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [31:0] native_value=aa*bb;
assign value=native_value[0+:16];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
