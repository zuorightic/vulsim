`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_66; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_70; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_72; // decl: <none>; prim: <none>
    logic mul_tree_38_73; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_77; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_78; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_81; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_84; // decl: <none>; prim: <none>
    logic mul_tree_38_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_89; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_90; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_93; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_94; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_96; // decl: <none>; prim: <none>
    logic mul_tree_38_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_98; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_101; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_102; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_104; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_105; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_106; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_108; // decl: <none>; prim: <none>
    logic mul_tree_38_109; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_110; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_114; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_115; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_116; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_119; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_120; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_121; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_122; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_123; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_124; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_125; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_126; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_127; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_128; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_129; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_130; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_131; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_132; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_133; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_134; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_135; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_136; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_137; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_138; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_139; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_140; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_141; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_142; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_143; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_144; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_160; // decl: <none>; prim: <none>
    logic mul_tree_39_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_162; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_163; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_164; // decl: <none>; prim: <none>
    logic mul_tree_39_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_166; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_167; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_168; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_169; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_170; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_171; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_172; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_173; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_174; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_175; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_176; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_177; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_178; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_179; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_180; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_181; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_182; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_183; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_184; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_15_s5; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] rtlzz_pipe_15_s7; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [127:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s6; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s6; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_114_s7; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_117_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_120_s7; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_123_s7; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_126_s7; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_129_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s3 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(129'(rtlzz_pipe_15_s7)), .b(129'(n3_v0)), .cin(1'b0), .value(s8_norm_sub_14_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_sub_18_v0[63:0]));
    assign s8_norm_sub_18_v0[128:64] = '0;
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_64; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_145; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_184; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(32'(mul_tree_37_40)), .b(32'(mul_tree_37_41)), .cin(1'b0), .value(mul_tree_37_42));
    assign mul_tree_37_43 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(32'(mul_tree_37_43)), .b(32'(mul_tree_37_44)), .cin(1'b0), .value(mul_tree_37_45));
    assign mul_tree_37_46 = {mul_tree_37_45, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(32'(mul_tree_37_47)), .b(32'(mul_tree_37_48)), .cin(1'b0), .value(mul_tree_37_49));
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(32'(mul_tree_37_51)), .b(32'(mul_tree_37_52)), .cin(1'b0), .value(mul_tree_37_53));
    assign mul_tree_37_54 = {mul_tree_37_53, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_56 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_57Core rtlzz_owner_57(.a(64'(mul_tree_37_55)), .b(96'(mul_tree_37_56)), .cin(1'h0), .value(mul_tree_37_57));
    assign mul_tree_37_58 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_59 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(96'(mul_tree_37_58)), .b(128'(mul_tree_37_59)), .cin(1'h0), .value(mul_tree_37_60[127:0]));
    assign mul_tree_37_60[128:128] = '0;
    assign mul_tree_37_61 = ({33'h0, rtlzz_pipe_57_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_62 = ({1'h0, rtlzz_pipe_60_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(97'(mul_tree_37_61)), .b(129'(mul_tree_37_62)), .cin(1'h0), .value(mul_tree_37_63[127:0]));
    assign mul_tree_37_63[129:128] = '0;
    assign mul_tree_37_64 = mul_tree_37_63[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_65 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_66 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(32'(mul_tree_38_65)), .b(32'(mul_tree_38_66)), .cin(1'b0), .value(mul_tree_38_67));
    assign mul_tree_38_68 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_69 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(32'(mul_tree_38_68)), .b(32'(mul_tree_38_69)), .cin(1'b0), .value(mul_tree_38_70));
    assign mul_tree_38_71 = {mul_tree_38_70, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_72 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_73 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(32'(mul_tree_38_72)), .b(1'(mul_tree_38_73)), .cin(1'b0), .value(mul_tree_38_74));
    assign mul_tree_38_75 = {mul_tree_38_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_76 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_77 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(32'(mul_tree_38_76)), .b(32'(mul_tree_38_77)), .cin(1'b0), .value(mul_tree_38_78));
    assign mul_tree_38_79 = {mul_tree_38_78, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_80 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_81 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(32'(mul_tree_38_80)), .b(32'(mul_tree_38_81)), .cin(1'b0), .value(mul_tree_38_82));
    assign mul_tree_38_83 = {mul_tree_38_82, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_84 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_85 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(32'(mul_tree_38_84)), .b(1'(mul_tree_38_85)), .cin(1'b0), .value(mul_tree_38_86));
    assign mul_tree_38_87 = {mul_tree_38_86, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_88 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_89 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(32'(mul_tree_38_88)), .b(32'(mul_tree_38_89)), .cin(1'b0), .value(mul_tree_38_90));
    assign mul_tree_38_91 = {mul_tree_38_90, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_92 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_93 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(32'(mul_tree_38_92)), .b(32'(mul_tree_38_93)), .cin(1'b0), .value(mul_tree_38_94));
    assign mul_tree_38_95 = {mul_tree_38_94, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_96 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_97 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_38_96)), .b(1'(mul_tree_38_97)), .cin(1'b0), .value(mul_tree_38_98));
    assign mul_tree_38_99 = {mul_tree_38_98, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_100 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_101 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(32'(mul_tree_38_100)), .b(32'(mul_tree_38_101)), .cin(1'b0), .value(mul_tree_38_102));
    assign mul_tree_38_103 = {mul_tree_38_102, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_104 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_105 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(32'(mul_tree_38_104)), .b(32'(mul_tree_38_105)), .cin(1'b0), .value(mul_tree_38_106));
    assign mul_tree_38_107 = {mul_tree_38_106, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_108 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_109 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(32'(mul_tree_38_108)), .b(1'(mul_tree_38_109)), .cin(1'b0), .value(mul_tree_38_110));
    assign mul_tree_38_111 = {mul_tree_38_110, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_112 = ({33'h0, rtlzz_pipe_67_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_113 = ({1'h0, rtlzz_pipe_71_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(64'(mul_tree_38_112)), .b(96'(mul_tree_38_113)), .cin(1'h0), .value(mul_tree_38_114));
    assign mul_tree_38_115 = ({1'h0, rtlzz_pipe_75_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_116 = ({2'h0, rtlzz_pipe_79_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_117Core rtlzz_owner_117(.a(97'(mul_tree_38_115)), .b(96'(mul_tree_38_116)), .cin(1'h0), .value(mul_tree_38_117));
    assign mul_tree_38_118 = ({2'h0, rtlzz_pipe_83_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_119 = ({1'h0, rtlzz_pipe_87_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(128'(mul_tree_38_118)), .b(129'(mul_tree_38_119)), .cin(1'h0), .value(mul_tree_38_120));
    assign mul_tree_38_121 = ({33'h0, rtlzz_pipe_91_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_122 = ({1'h0, rtlzz_pipe_95_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(128'(mul_tree_38_121)), .b(160'(mul_tree_38_122)), .cin(1'h0), .value(mul_tree_38_123));
    assign mul_tree_38_124 = ({1'h0, rtlzz_pipe_99_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_125 = ({2'h0, rtlzz_pipe_103_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(161'(mul_tree_38_124)), .b(160'(mul_tree_38_125)), .cin(1'h0), .value(mul_tree_38_126));
    assign mul_tree_38_127 = ({2'h0, rtlzz_pipe_107_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_128 = ({1'h0, rtlzz_pipe_111_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(192'(mul_tree_38_127)), .b(193'(mul_tree_38_128)), .cin(1'h0), .value(mul_tree_38_129[192:0]));
    assign mul_tree_38_129[193:193] = '0;
    assign mul_tree_38_130 = ({2'h0, rtlzz_pipe_114_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_131 = ({1'h0, rtlzz_pipe_117_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_133 = ({32'h0, rtlzz_pipe_120_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_134 = ({1'h0, rtlzz_pipe_123_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_136 = ({33'h0, rtlzz_pipe_126_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_137 = ({1'h0, rtlzz_pipe_129_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_139 = ({64'h0, mul_tree_38_132}); // decl: <none>; prim: <none>
    assign mul_tree_38_140 = ({1'h0, mul_tree_38_135}); // decl: <none>; prim: <none>
    assign mul_tree_38_142 = ({33'h0, mul_tree_38_141}); // decl: <none>; prim: <none>
    assign mul_tree_38_143 = ({1'h0, mul_tree_38_138}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144_reduce rtlzz_reduce_144(.i230(rtlzz_pipe_114_s7), .i231(rtlzz_pipe_117_s7), .i232(rtlzz_pipe_120_s7), .i233(rtlzz_pipe_123_s7), .i234(rtlzz_pipe_126_s7), .i235(rtlzz_pipe_129_s7), .y(mul_tree_38_144));
    assign mul_tree_38_145 = mul_tree_38_144[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_146 = mul_precision_34[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_147 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_39_146)), .b(32'(mul_tree_39_147)), .cin(1'b0), .value(mul_tree_39_148));
    assign mul_tree_39_149 = mul_precision_34[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_150 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_39_149)), .b(32'(mul_tree_39_150)), .cin(1'b0), .value(mul_tree_39_151));
    assign mul_tree_39_152 = {mul_tree_39_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_153 = mul_precision_34[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_154 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_39_153)), .b(32'(mul_tree_39_154)), .cin(1'b0), .value(mul_tree_39_155));
    assign mul_tree_39_156 = {mul_tree_39_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_157 = mul_precision_34[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_158 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_39_157)), .b(32'(mul_tree_39_158)), .cin(1'b0), .value(mul_tree_39_159));
    assign mul_tree_39_160 = {mul_tree_39_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_161 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_162 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(1'(mul_tree_39_161)), .b(32'(mul_tree_39_162)), .cin(1'b0), .value(mul_tree_39_163));
    assign mul_tree_39_164 = {mul_tree_39_163, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_165 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_166 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(1'(mul_tree_39_165)), .b(32'(mul_tree_39_166)), .cin(1'b0), .value(mul_tree_39_167));
    assign mul_tree_39_168 = {mul_tree_39_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_169 = ({33'h0, mul_tree_39_148}); // decl: <none>; prim: <none>
    assign mul_tree_39_170 = ({1'h0, mul_tree_39_152}); // decl: <none>; prim: <none>
    assign mul_tree_39_172 = ({33'h0, mul_tree_39_156}); // decl: <none>; prim: <none>
    assign mul_tree_39_173 = ({1'h0, mul_tree_39_160}); // decl: <none>; prim: <none>
    assign mul_tree_39_175 = ({33'h0, mul_tree_39_164}); // decl: <none>; prim: <none>
    assign mul_tree_39_176 = ({1'h0, mul_tree_39_168}); // decl: <none>; prim: <none>
    assign mul_tree_39_178 = ({33'h0, mul_tree_39_171}); // decl: <none>; prim: <none>
    assign mul_tree_39_179 = ({1'h0, mul_tree_39_174}); // decl: <none>; prim: <none>
    assign mul_tree_39_181 = ({1'h0, mul_tree_39_180}); // decl: <none>; prim: <none>
    assign mul_tree_39_182 = ({1'h0, mul_tree_39_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_183_reduce rtlzz_reduce_183(.i148(mul_tree_39_148), .i151(mul_tree_39_151), .i155(mul_tree_39_155), .i159(mul_tree_39_159), .i163(mul_tree_39_163), .i167(mul_tree_39_167), .y(mul_tree_39_183));
    assign mul_tree_39_184 = mul_tree_39_183[128:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 96'h0;
            rtlzz_pipe_54_s1 <= 128'h0;
            rtlzz_pipe_57_s2 <= 97'h0;
            rtlzz_pipe_60_s2 <= 129'h0;
            rtlzz_pipe_23_s3 <= 193'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_25_s4 <= 129'h0;
            rtlzz_pipe_15_s5 <= 129'h0;
            rtlzz_pipe_15_s6 <= 129'h0;
            rtlzz_pipe_15_s7 <= 129'h0;
            rtlzz_pipe_31_s4 <= 128'h0;
            rtlzz_pipe_31_s5 <= 128'h0;
            rtlzz_pipe_67_s6 <= 64'h0;
            rtlzz_pipe_71_s6 <= 96'h0;
            rtlzz_pipe_75_s6 <= 97'h0;
            rtlzz_pipe_79_s6 <= 96'h0;
            rtlzz_pipe_83_s6 <= 128'h0;
            rtlzz_pipe_87_s6 <= 129'h0;
            rtlzz_pipe_91_s6 <= 128'h0;
            rtlzz_pipe_95_s6 <= 160'h0;
            rtlzz_pipe_99_s6 <= 161'h0;
            rtlzz_pipe_103_s6 <= 160'h0;
            rtlzz_pipe_107_s6 <= 192'h0;
            rtlzz_pipe_111_s6 <= 193'h0;
            rtlzz_pipe_114_s7 <= 97'h0;
            rtlzz_pipe_117_s7 <= 98'h0;
            rtlzz_pipe_120_s7 <= 130'h0;
            rtlzz_pipe_123_s7 <= 161'h0;
            rtlzz_pipe_126_s7 <= 162'h0;
            rtlzz_pipe_129_s7 <= 194'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= mul_tree_37_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= mul_tree_37_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_25_s4 <= rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_15_s5 <= tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_15_s6 <= rtlzz_pipe_15_s5; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_15_s7 <= rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_31_s5 <= rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= mul_tree_38_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_71_s6 <= mul_tree_38_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= mul_tree_38_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= mul_tree_38_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= mul_tree_38_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= mul_tree_38_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_91_s6 <= mul_tree_38_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_95_s6 <= mul_tree_38_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_99_s6 <= mul_tree_38_99; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= mul_tree_38_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= mul_tree_38_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= mul_tree_38_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_114_s7 <= mul_tree_38_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_117_s7 <= mul_tree_38_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_120_s7 <= mul_tree_38_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_123_s7 <= mul_tree_38_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_126_s7 <= mul_tree_38_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_129_s7 <= mul_tree_38_129; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144_reduce(input wire [96:0] i230, input wire [97:0] i231, input wire [129:0] i232, input wire [160:0] i233, input wire [161:0] i234, input wire [193:0] i235, output wire [195:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i230[96], i230[95], i230[94], i230[93], i230[92], i230[91], i230[90], i230[89], i230[88], i230[87], i230[86], i230[85], i230[84], i230[83], i230[82], i230[81], i230[80], i230[79], i230[78], i230[77], i230[76], i230[75], i230[74], i230[73], i230[72], i230[71], i230[70], i230[69], i230[68], i230[67], i230[66], i230[65], i230[64], i230[63], i230[62], i230[61], i230[60], i230[59], i230[58], i230[57], i230[56], i230[55], i230[54], i230[53], i230[52], i230[51], i230[50], i230[49], i230[48], i230[47], i230[46], i230[45], i230[44], i230[43], i230[42], i230[41], i230[40], i230[39], i230[38], i230[37], i230[36], i230[35], i230[34], i230[33], i230[32], i230[31], i230[30], i230[29], i230[28], i230[27], i230[26], i230[25], i230[24], i230[23], i230[22], i230[21], i230[20], i230[19], i230[18], i230[17], i230[16], i230[15], i230[14], i230[13], i230[12], i230[11], i230[10], i230[9], i230[8], i230[7], i230[6], i230[5], i230[4], i230[3], i230[2], i230[1], i230[0]};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i231[97], i231[96], i231[95], i231[94], i231[93], i231[92], i231[91], i231[90], i231[89], i231[88], i231[87], i231[86], i231[85], i231[84], i231[83], i231[82], i231[81], i231[80], i231[79], i231[78], i231[77], i231[76], i231[75], i231[74], i231[73], i231[72], i231[71], i231[70], i231[69], i231[68], i231[67], i231[66], i231[65], i231[64], i231[63], i231[62], i231[61], i231[60], i231[59], i231[58], i231[57], i231[56], i231[55], i231[54], i231[53], i231[52], i231[51], i231[50], i231[49], i231[48], i231[47], i231[46], i231[45], i231[44], i231[43], i231[42], i231[41], i231[40], i231[39], i231[38], i231[37], i231[36], i231[35], i231[34], i231[33], i231[32], i231[31], i231[30], i231[29], i231[28], i231[27], i231[26], i231[25], i231[24], i231[23], i231[22], i231[21], i231[20], i231[19], i231[18], i231[17], i231[16], i231[15], i231[14], i231[13], i231[12], i231[11], i231[10], i231[9], i231[8], i231[7], i231[6], i231[5], i231[4], i231[3], i231[2], i231[1], i231[0]};
wire [192:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i232[129], i232[128], i232[127], i232[126], i232[125], i232[124], i232[123], i232[122], i232[121], i232[120], i232[119], i232[118], i232[117], i232[116], i232[115], i232[114], i232[113], i232[112], i232[111], i232[110], i232[109], i232[108], i232[107], i232[106], i232[105], i232[104], i232[103], i232[102], i232[101], i232[100], i232[99], i232[98], i232[97], i232[96], i232[95], i232[94], i232[93], i232[92], i232[91], i232[90], i232[89], i232[88], i232[87], i232[86], i232[85], i232[84], i232[83], i232[82], i232[81], i232[80], i232[79], i232[78], i232[77], i232[76], i232[75], i232[74], i232[73], i232[72], i232[71], i232[70], i232[69], i232[68], i232[67], i232[66], i232[65], i232[64], i232[63], i232[62], i232[61], i232[60], i232[59], i232[58], i232[57], i232[56], i232[55], i232[54], i232[53], i232[52], i232[51], i232[50], i232[49], i232[48], i232[47], i232[46], i232[45], i232[44], i232[43], i232[42], i232[41], i232[40], i232[39], i232[38], i232[37], i232[36], i232[35], i232[34], i232[33], i232[32], i232[31], i232[30], i232[29], i232[28], i232[27], i232[26], i232[25], i232[24], i232[23], i232[22], i232[21], i232[20], i232[19], i232[18], i232[17], i232[16], i232[15], i232[14], i232[13], i232[12], i232[11], i232[10], i232[9], i232[8], i232[7], i232[6], i232[5], i232[4], i232[3], i232[2], i232[1], i232[0]};
wire [192:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i233[160], i233[159], i233[158], i233[157], i233[156], i233[155], i233[154], i233[153], i233[152], i233[151], i233[150], i233[149], i233[148], i233[147], i233[146], i233[145], i233[144], i233[143], i233[142], i233[141], i233[140], i233[139], i233[138], i233[137], i233[136], i233[135], i233[134], i233[133], i233[132], i233[131], i233[130], i233[129], i233[128], i233[127], i233[126], i233[125], i233[124], i233[123], i233[122], i233[121], i233[120], i233[119], i233[118], i233[117], i233[116], i233[115], i233[114], i233[113], i233[112], i233[111], i233[110], i233[109], i233[108], i233[107], i233[106], i233[105], i233[104], i233[103], i233[102], i233[101], i233[100], i233[99], i233[98], i233[97], i233[96], i233[95], i233[94], i233[93], i233[92], i233[91], i233[90], i233[89], i233[88], i233[87], i233[86], i233[85], i233[84], i233[83], i233[82], i233[81], i233[80], i233[79], i233[78], i233[77], i233[76], i233[75], i233[74], i233[73], i233[72], i233[71], i233[70], i233[69], i233[68], i233[67], i233[66], i233[65], i233[64], i233[63], i233[62], i233[61], i233[60], i233[59], i233[58], i233[57], i233[56], i233[55], i233[54], i233[53], i233[52], i233[51], i233[50], i233[49], i233[48], i233[47], i233[46], i233[45], i233[44], i233[43], i233[42], i233[41], i233[40], i233[39], i233[38], i233[37], i233[36], i233[35], i233[34], i233[33], i233[32], i233[31], i233[30], i233[29], i233[28], i233[27], i233[26], i233[25], i233[24], i233[23], i233[22], i233[21], i233[20], i233[19], i233[18], i233[17], i233[16], i233[15], i233[14], i233[13], i233[12], i233[11], i233[10], i233[9], i233[8], i233[7], i233[6], i233[5], i233[4], i233[3], i233[2], i233[1], i233[0]};
wire [192:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i234[161], i234[160], i234[159], i234[158], i234[157], i234[156], i234[155], i234[154], i234[153], i234[152], i234[151], i234[150], i234[149], i234[148], i234[147], i234[146], i234[145], i234[144], i234[143], i234[142], i234[141], i234[140], i234[139], i234[138], i234[137], i234[136], i234[135], i234[134], i234[133], i234[132], i234[131], i234[130], i234[129], i234[128], i234[127], i234[126], i234[125], i234[124], i234[123], i234[122], i234[121], i234[120], i234[119], i234[118], i234[117], i234[116], i234[115], i234[114], i234[113], i234[112], i234[111], i234[110], i234[109], i234[108], i234[107], i234[106], i234[105], i234[104], i234[103], i234[102], i234[101], i234[100], i234[99], i234[98], i234[97], i234[96], i234[95], i234[94], i234[93], i234[92], i234[91], i234[90], i234[89], i234[88], i234[87], i234[86], i234[85], i234[84], i234[83], i234[82], i234[81], i234[80], i234[79], i234[78], i234[77], i234[76], i234[75], i234[74], i234[73], i234[72], i234[71], i234[70], i234[69], i234[68], i234[67], i234[66], i234[65], i234[64], i234[63], i234[62], i234[61], i234[60], i234[59], i234[58], i234[57], i234[56], i234[55], i234[54], i234[53], i234[52], i234[51], i234[50], i234[49], i234[48], i234[47], i234[46], i234[45], i234[44], i234[43], i234[42], i234[41], i234[40], i234[39], i234[38], i234[37], i234[36], i234[35], i234[34], i234[33], i234[32], i234[31], i234[30], i234[29], i234[28], i234[27], i234[26], i234[25], i234[24], i234[23], i234[22], i234[21], i234[20], i234[19], i234[18], i234[17], i234[16], i234[15], i234[14], i234[13], i234[12], i234[11], i234[10], i234[9], i234[8], i234[7], i234[6], i234[5], i234[4], i234[3], i234[2], i234[1], i234[0]};
wire [192:0] t5 = {i235[192], i235[191], i235[190], i235[189], i235[188], i235[187], i235[186], i235[185], i235[184], i235[183], i235[182], i235[181], i235[180], i235[179], i235[178], i235[177], i235[176], i235[175], i235[174], i235[173], i235[172], i235[171], i235[170], i235[169], i235[168], i235[167], i235[166], i235[165], i235[164], i235[163], i235[162], i235[161], i235[160], i235[159], i235[158], i235[157], i235[156], i235[155], i235[154], i235[153], i235[152], i235[151], i235[150], i235[149], i235[148], i235[147], i235[146], i235[145], i235[144], i235[143], i235[142], i235[141], i235[140], i235[139], i235[138], i235[137], i235[136], i235[135], i235[134], i235[133], i235[132], i235[131], i235[130], i235[129], i235[128], i235[127], i235[126], i235[125], i235[124], i235[123], i235[122], i235[121], i235[120], i235[119], i235[118], i235[117], i235[116], i235[115], i235[114], i235[113], i235[112], i235[111], i235[110], i235[109], i235[108], i235[107], i235[106], i235[105], i235[104], i235[103], i235[102], i235[101], i235[100], i235[99], i235[98], i235[97], i235[96], i235[95], i235[94], i235[93], i235[92], i235[91], i235[90], i235[89], i235[88], i235[87], i235[86], i235[85], i235[84], i235[83], i235[82], i235[81], i235[80], i235[79], i235[78], i235[77], i235[76], i235[75], i235[74], i235[73], i235[72], i235[71], i235[70], i235[69], i235[68], i235[67], i235[66], i235[65], i235[64], i235[63], i235[62], i235[61], i235[60], i235[59], i235[58], i235[57], i235[56], i235[55], i235[54], i235[53], i235[52], i235[51], i235[50], i235[49], i235[48], i235[47], i235[46], i235[45], i235[44], i235[43], i235[42], i235[41], i235[40], i235[39], i235[38], i235[37], i235[36], i235[35], i235[34], i235[33], i235[32], i235[31], i235[30], i235[29], i235[28], i235[27], i235[26], i235[25], i235[24], i235[23], i235[22], i235[21], i235[20], i235[19], i235[18], i235[17], i235[16], i235[15], i235[14], i235[13], i235[12], i235[11], i235[10], i235[9], i235[8], i235[7], i235[6], i235[5], i235[4], i235[3], i235[2], i235[1], i235[0]};
wire [192:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183_reduce(input wire [63:0] i148, input wire [63:0] i151, input wire [63:0] i155, input wire [63:0] i159, input wire [32:0] i163, input wire [32:0] i167, output wire [130:0] y);
wire [128:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i148[63], i148[62], i148[61], i148[60], i148[59], i148[58], i148[57], i148[56], i148[55], i148[54], i148[53], i148[52], i148[51], i148[50], i148[49], i148[48], i148[47], i148[46], i148[45], i148[44], i148[43], i148[42], i148[41], i148[40], i148[39], i148[38], i148[37], i148[36], i148[35], i148[34], i148[33], i148[32], i148[31], i148[30], i148[29], i148[28], i148[27], i148[26], i148[25], i148[24], i148[23], i148[22], i148[21], i148[20], i148[19], i148[18], i148[17], i148[16], i148[15], i148[14], i148[13], i148[12], i148[11], i148[10], i148[9], i148[8], i148[7], i148[6], i148[5], i148[4], i148[3], i148[2], i148[1], i148[0]};
wire [128:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i151[63], i151[62], i151[61], i151[60], i151[59], i151[58], i151[57], i151[56], i151[55], i151[54], i151[53], i151[52], i151[51], i151[50], i151[49], i151[48], i151[47], i151[46], i151[45], i151[44], i151[43], i151[42], i151[41], i151[40], i151[39], i151[38], i151[37], i151[36], i151[35], i151[34], i151[33], i151[32], i151[31], i151[30], i151[29], i151[28], i151[27], i151[26], i151[25], i151[24], i151[23], i151[22], i151[21], i151[20], i151[19], i151[18], i151[17], i151[16], i151[15], i151[14], i151[13], i151[12], i151[11], i151[10], i151[9], i151[8], i151[7], i151[6], i151[5], i151[4], i151[3], i151[2], i151[1], i151[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i155[63], i155[62], i155[61], i155[60], i155[59], i155[58], i155[57], i155[56], i155[55], i155[54], i155[53], i155[52], i155[51], i155[50], i155[49], i155[48], i155[47], i155[46], i155[45], i155[44], i155[43], i155[42], i155[41], i155[40], i155[39], i155[38], i155[37], i155[36], i155[35], i155[34], i155[33], i155[32], i155[31], i155[30], i155[29], i155[28], i155[27], i155[26], i155[25], i155[24], i155[23], i155[22], i155[21], i155[20], i155[19], i155[18], i155[17], i155[16], i155[15], i155[14], i155[13], i155[12], i155[11], i155[10], i155[9], i155[8], i155[7], i155[6], i155[5], i155[4], i155[3], i155[2], i155[1], i155[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t3 = {1'b0, i159[63], i159[62], i159[61], i159[60], i159[59], i159[58], i159[57], i159[56], i159[55], i159[54], i159[53], i159[52], i159[51], i159[50], i159[49], i159[48], i159[47], i159[46], i159[45], i159[44], i159[43], i159[42], i159[41], i159[40], i159[39], i159[38], i159[37], i159[36], i159[35], i159[34], i159[33], i159[32], i159[31], i159[30], i159[29], i159[28], i159[27], i159[26], i159[25], i159[24], i159[23], i159[22], i159[21], i159[20], i159[19], i159[18], i159[17], i159[16], i159[15], i159[14], i159[13], i159[12], i159[11], i159[10], i159[9], i159[8], i159[7], i159[6], i159[5], i159[4], i159[3], i159[2], i159[1], i159[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i163[32], i163[31], i163[30], i163[29], i163[28], i163[27], i163[26], i163[25], i163[24], i163[23], i163[22], i163[21], i163[20], i163[19], i163[18], i163[17], i163[16], i163[15], i163[14], i163[13], i163[12], i163[11], i163[10], i163[9], i163[8], i163[7], i163[6], i163[5], i163[4], i163[3], i163[2], i163[1], i163[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t5 = {i167[32], i167[31], i167[30], i167[29], i167[28], i167[27], i167[26], i167[25], i167[24], i167[23], i167[22], i167[21], i167[20], i167[19], i167[18], i167[17], i167[16], i167[15], i167[14], i167[13], i167[12], i167[11], i167[10], i167[9], i167[8], i167[7], i167[6], i167[5], i167[4], i167[3], i167[2], i167[1], i167[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117Core(input wire [96:0] a,input wire [95:0] b,input wire cin,output wire [97:0] value);
wire [96:0] masked_a=((a&97'h1ffffffff0000000000000000)|97'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:98];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [127:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] masked_b=((b&129'h1ffffffff000000000000000000000000)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [160:0] a,input wire [159:0] b,input wire cin,output wire [161:0] value);
wire [160:0] masked_a=((a&161'h1ffffffff00000000000000000000000000000000)|161'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [191:0] a,input wire [192:0] b,input wire cin,output wire [192:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] masked_b=((b&193'h1ffffffff0000000000000000000000000000000000000000)|193'h0);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
