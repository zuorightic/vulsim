`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_66; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_70; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_72; // decl: <none>; prim: <none>
    logic mul_tree_38_73; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_77; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_78; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_81; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_84; // decl: <none>; prim: <none>
    logic mul_tree_38_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_89; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_90; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_93; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_94; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_96; // decl: <none>; prim: <none>
    logic mul_tree_38_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_98; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_101; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_102; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_104; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_105; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_106; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_108; // decl: <none>; prim: <none>
    logic mul_tree_38_109; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_110; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_114; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_115; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_116; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_119; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_120; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_121; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_122; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_123; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_124; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_125; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_126; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_127; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_128; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_129; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_130; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_131; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_132; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_133; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_134; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_135; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_136; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_137; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_138; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_139; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_140; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_141; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_142; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_143; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_144; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_160; // decl: <none>; prim: <none>
    logic mul_tree_39_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_162; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_163; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_164; // decl: <none>; prim: <none>
    logic mul_tree_39_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_166; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_167; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_168; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_169; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_170; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_171; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_172; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_173; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_174; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_175; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_176; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_177; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_178; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_179; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_180; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_181; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_182; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_183; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_184; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] rtlzz_pipe_15_s7; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [127:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s5; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s6; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s5; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s5; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s6; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s5; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_114_s7; // decl: <none>; prim: <none>
    logic [97:0] rtlzz_pipe_117_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_120_s7; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_123_s7; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_126_s7; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_129_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s3 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s5 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(129'(rtlzz_pipe_15_s7)), .b(129'(n3_v0)), .cin(1'b0), .value(s8_norm_sub_14_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_sub_18_v0[63:0]));
    assign s8_norm_sub_18_v0[128:64] = '0;
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_64; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_145; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_184; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(32'(mul_tree_37_40)), .b(32'(mul_tree_37_41)), .cin(1'b0), .value(mul_tree_37_42));
    assign mul_tree_37_43 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(32'(mul_tree_37_43)), .b(32'(mul_tree_37_44)), .cin(1'b0), .value(mul_tree_37_45));
    assign mul_tree_37_46 = {mul_tree_37_45, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(32'(mul_tree_37_47)), .b(32'(mul_tree_37_48)), .cin(1'b0), .value(mul_tree_37_49));
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(32'(mul_tree_37_51)), .b(32'(mul_tree_37_52)), .cin(1'b0), .value(mul_tree_37_53));
    assign mul_tree_37_54 = {mul_tree_37_53, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_56 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_57Core rtlzz_owner_57(.a(64'(mul_tree_37_55)), .b(96'(mul_tree_37_56)), .cin(1'h0), .value(mul_tree_37_57));
    assign mul_tree_37_58 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_59 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(96'(mul_tree_37_58)), .b(128'(mul_tree_37_59)), .cin(1'h0), .value(mul_tree_37_60[127:0]));
    assign mul_tree_37_60[128:128] = '0;
    assign mul_tree_37_61 = ({33'h0, rtlzz_pipe_57_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_62 = ({1'h0, rtlzz_pipe_60_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(97'(mul_tree_37_61)), .b(129'(mul_tree_37_62)), .cin(1'h0), .value(mul_tree_37_63[127:0]));
    assign mul_tree_37_63[129:128] = '0;
    assign mul_tree_37_64 = mul_tree_37_63[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_65 = rtlzz_pipe_31_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_66 = rtlzz_pipe_32_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(32'(mul_tree_38_65)), .b(32'(mul_tree_38_66)), .cin(1'b0), .value(mul_tree_38_67));
    assign mul_tree_38_68 = rtlzz_pipe_31_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_69 = rtlzz_pipe_32_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(32'(mul_tree_38_68)), .b(32'(mul_tree_38_69)), .cin(1'b0), .value(mul_tree_38_70));
    assign mul_tree_38_71 = {mul_tree_38_70, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_72 = rtlzz_pipe_31_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_73 = rtlzz_pipe_32_s4[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(32'(mul_tree_38_72)), .b(1'(mul_tree_38_73)), .cin(1'b0), .value(mul_tree_38_74));
    assign mul_tree_38_75 = {mul_tree_38_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_76 = rtlzz_pipe_31_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_77 = rtlzz_pipe_32_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(32'(mul_tree_38_76)), .b(32'(mul_tree_38_77)), .cin(1'b0), .value(mul_tree_38_78));
    assign mul_tree_38_79 = {mul_tree_38_78, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_80 = rtlzz_pipe_31_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_81 = rtlzz_pipe_32_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(32'(mul_tree_38_80)), .b(32'(mul_tree_38_81)), .cin(1'b0), .value(mul_tree_38_82));
    assign mul_tree_38_83 = {mul_tree_38_82, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_84 = rtlzz_pipe_31_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_85 = rtlzz_pipe_32_s4[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(32'(mul_tree_38_84)), .b(1'(mul_tree_38_85)), .cin(1'b0), .value(mul_tree_38_86));
    assign mul_tree_38_87 = {mul_tree_38_86, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_88 = rtlzz_pipe_31_s4[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_89 = rtlzz_pipe_32_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(32'(mul_tree_38_88)), .b(32'(mul_tree_38_89)), .cin(1'b0), .value(mul_tree_38_90));
    assign mul_tree_38_91 = {mul_tree_38_90, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_92 = rtlzz_pipe_31_s4[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_93 = rtlzz_pipe_32_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(32'(mul_tree_38_92)), .b(32'(mul_tree_38_93)), .cin(1'b0), .value(mul_tree_38_94));
    assign mul_tree_38_95 = {mul_tree_38_94, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_96 = rtlzz_pipe_31_s4[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_97 = rtlzz_pipe_32_s4[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_38_96)), .b(1'(mul_tree_38_97)), .cin(1'b0), .value(mul_tree_38_98));
    assign mul_tree_38_99 = {mul_tree_38_98, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_100 = rtlzz_pipe_31_s4[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_101 = rtlzz_pipe_32_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(32'(mul_tree_38_100)), .b(32'(mul_tree_38_101)), .cin(1'b0), .value(mul_tree_38_102));
    assign mul_tree_38_103 = {mul_tree_38_102, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_104 = rtlzz_pipe_31_s4[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_105 = rtlzz_pipe_32_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(32'(mul_tree_38_104)), .b(32'(mul_tree_38_105)), .cin(1'b0), .value(mul_tree_38_106));
    assign mul_tree_38_107 = {mul_tree_38_106, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_108 = rtlzz_pipe_31_s4[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_109 = rtlzz_pipe_32_s4[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(32'(mul_tree_38_108)), .b(1'(mul_tree_38_109)), .cin(1'b0), .value(mul_tree_38_110));
    assign mul_tree_38_111 = {mul_tree_38_110, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_112 = ({33'h0, rtlzz_pipe_67_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_113 = ({1'h0, rtlzz_pipe_71_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(64'(mul_tree_38_112)), .b(96'(mul_tree_38_113)), .cin(1'h0), .value(mul_tree_38_114));
    assign mul_tree_38_115 = ({1'h0, rtlzz_pipe_75_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_116 = ({2'h0, rtlzz_pipe_79_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_117Core rtlzz_owner_117(.a(97'(mul_tree_38_115)), .b(96'(mul_tree_38_116)), .cin(1'h0), .value(mul_tree_38_117));
    assign mul_tree_38_118 = ({2'h0, rtlzz_pipe_83_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_119 = ({1'h0, rtlzz_pipe_87_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(128'(mul_tree_38_118)), .b(129'(mul_tree_38_119)), .cin(1'h0), .value(mul_tree_38_120));
    assign mul_tree_38_121 = ({33'h0, rtlzz_pipe_91_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_122 = ({1'h0, rtlzz_pipe_95_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(128'(mul_tree_38_121)), .b(160'(mul_tree_38_122)), .cin(1'h0), .value(mul_tree_38_123));
    assign mul_tree_38_124 = ({1'h0, rtlzz_pipe_99_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_125 = ({2'h0, rtlzz_pipe_103_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(161'(mul_tree_38_124)), .b(160'(mul_tree_38_125)), .cin(1'h0), .value(mul_tree_38_126));
    assign mul_tree_38_127 = ({2'h0, rtlzz_pipe_107_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_128 = ({1'h0, rtlzz_pipe_111_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(192'(mul_tree_38_127)), .b(193'(mul_tree_38_128)), .cin(1'h0), .value(mul_tree_38_129[192:0]));
    assign mul_tree_38_129[193:193] = '0;
    assign mul_tree_38_130 = ({2'h0, rtlzz_pipe_114_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_131 = ({1'h0, rtlzz_pipe_117_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_133 = ({32'h0, rtlzz_pipe_120_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_134 = ({1'h0, rtlzz_pipe_123_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_136 = ({33'h0, rtlzz_pipe_126_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_137 = ({1'h0, rtlzz_pipe_129_s7}); // decl: <none>; prim: <none>
    assign mul_tree_38_139 = ({64'h0, mul_tree_38_132}); // decl: <none>; prim: <none>
    assign mul_tree_38_140 = ({1'h0, mul_tree_38_135}); // decl: <none>; prim: <none>
    assign mul_tree_38_142 = ({33'h0, mul_tree_38_141}); // decl: <none>; prim: <none>
    assign mul_tree_38_143 = ({1'h0, mul_tree_38_138}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144_reduce rtlzz_reduce_144(.i240(rtlzz_pipe_114_s7), .i241(rtlzz_pipe_117_s7), .i242(rtlzz_pipe_120_s7), .i243(rtlzz_pipe_123_s7), .i244(rtlzz_pipe_126_s7), .i245(rtlzz_pipe_129_s7), .y(mul_tree_38_144));
    assign mul_tree_38_145 = mul_tree_38_144[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_146 = mul_precision_34[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_147 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_39_146)), .b(32'(mul_tree_39_147)), .cin(1'b0), .value(mul_tree_39_148));
    assign mul_tree_39_149 = mul_precision_34[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_150 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_39_149)), .b(32'(mul_tree_39_150)), .cin(1'b0), .value(mul_tree_39_151));
    assign mul_tree_39_152 = {mul_tree_39_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_153 = mul_precision_34[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_154 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_39_153)), .b(32'(mul_tree_39_154)), .cin(1'b0), .value(mul_tree_39_155));
    assign mul_tree_39_156 = {mul_tree_39_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_157 = mul_precision_34[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_158 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_39_157)), .b(32'(mul_tree_39_158)), .cin(1'b0), .value(mul_tree_39_159));
    assign mul_tree_39_160 = {mul_tree_39_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_161 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_162 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(1'(mul_tree_39_161)), .b(32'(mul_tree_39_162)), .cin(1'b0), .value(mul_tree_39_163));
    assign mul_tree_39_164 = {mul_tree_39_163, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_165 = mul_precision_34[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_166 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(1'(mul_tree_39_165)), .b(32'(mul_tree_39_166)), .cin(1'b0), .value(mul_tree_39_167));
    assign mul_tree_39_168 = {mul_tree_39_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_169 = ({33'h0, mul_tree_39_148}); // decl: <none>; prim: <none>
    assign mul_tree_39_170 = ({1'h0, mul_tree_39_152}); // decl: <none>; prim: <none>
    assign mul_tree_39_172 = ({33'h0, mul_tree_39_156}); // decl: <none>; prim: <none>
    assign mul_tree_39_173 = ({1'h0, mul_tree_39_160}); // decl: <none>; prim: <none>
    assign mul_tree_39_175 = ({33'h0, mul_tree_39_164}); // decl: <none>; prim: <none>
    assign mul_tree_39_176 = ({1'h0, mul_tree_39_168}); // decl: <none>; prim: <none>
    assign mul_tree_39_178 = ({33'h0, mul_tree_39_171}); // decl: <none>; prim: <none>
    assign mul_tree_39_179 = ({1'h0, mul_tree_39_174}); // decl: <none>; prim: <none>
    assign mul_tree_39_181 = ({1'h0, mul_tree_39_180}); // decl: <none>; prim: <none>
    assign mul_tree_39_182 = ({1'h0, mul_tree_39_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_183_reduce rtlzz_reduce_183(.i148(mul_tree_39_148), .i151(mul_tree_39_151), .i155(mul_tree_39_155), .i159(mul_tree_39_159), .i163(mul_tree_39_163), .i167(mul_tree_39_167), .y(mul_tree_39_183));
    assign mul_tree_39_184 = mul_tree_39_183[128:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 96'h0;
            rtlzz_pipe_54_s1 <= 128'h0;
            rtlzz_pipe_57_s2 <= 97'h0;
            rtlzz_pipe_60_s2 <= 129'h0;
            rtlzz_pipe_23_s3 <= 193'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_25_s4 <= 129'h0;
            rtlzz_pipe_25_s5 <= 129'h0;
            rtlzz_pipe_15_s6 <= 129'h0;
            rtlzz_pipe_15_s7 <= 129'h0;
            rtlzz_pipe_31_s4 <= 128'h0;
            rtlzz_pipe_67_s5 <= 64'h0;
            rtlzz_pipe_67_s6 <= 64'h0;
            rtlzz_pipe_71_s5 <= 96'h0;
            rtlzz_pipe_71_s6 <= 96'h0;
            rtlzz_pipe_75_s5 <= 97'h0;
            rtlzz_pipe_75_s6 <= 97'h0;
            rtlzz_pipe_79_s5 <= 96'h0;
            rtlzz_pipe_79_s6 <= 96'h0;
            rtlzz_pipe_83_s5 <= 128'h0;
            rtlzz_pipe_83_s6 <= 128'h0;
            rtlzz_pipe_87_s5 <= 129'h0;
            rtlzz_pipe_87_s6 <= 129'h0;
            rtlzz_pipe_91_s5 <= 128'h0;
            rtlzz_pipe_91_s6 <= 128'h0;
            rtlzz_pipe_95_s5 <= 160'h0;
            rtlzz_pipe_95_s6 <= 160'h0;
            rtlzz_pipe_99_s5 <= 161'h0;
            rtlzz_pipe_99_s6 <= 161'h0;
            rtlzz_pipe_103_s5 <= 160'h0;
            rtlzz_pipe_103_s6 <= 160'h0;
            rtlzz_pipe_107_s5 <= 192'h0;
            rtlzz_pipe_107_s6 <= 192'h0;
            rtlzz_pipe_111_s5 <= 193'h0;
            rtlzz_pipe_111_s6 <= 193'h0;
            rtlzz_pipe_114_s7 <= 97'h0;
            rtlzz_pipe_117_s7 <= 98'h0;
            rtlzz_pipe_120_s7 <= 130'h0;
            rtlzz_pipe_123_s7 <= 161'h0;
            rtlzz_pipe_126_s7 <= 162'h0;
            rtlzz_pipe_129_s7 <= 194'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= mul_tree_37_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= mul_tree_37_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_25_s4 <= rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_25_s5 <= rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_15_s6 <= tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_15_s7 <= rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_67_s5 <= mul_tree_38_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= rtlzz_pipe_67_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_71_s5 <= mul_tree_38_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_71_s6 <= rtlzz_pipe_71_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_75_s5 <= mul_tree_38_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= rtlzz_pipe_75_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_79_s5 <= mul_tree_38_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= rtlzz_pipe_79_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_83_s5 <= mul_tree_38_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= rtlzz_pipe_83_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_87_s5 <= mul_tree_38_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= rtlzz_pipe_87_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_91_s5 <= mul_tree_38_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_91_s6 <= rtlzz_pipe_91_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_95_s5 <= mul_tree_38_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_95_s6 <= rtlzz_pipe_95_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_99_s5 <= mul_tree_38_99; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_99_s6 <= rtlzz_pipe_99_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_103_s5 <= mul_tree_38_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_107_s5 <= mul_tree_38_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= rtlzz_pipe_107_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_111_s5 <= mul_tree_38_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= rtlzz_pipe_111_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_114_s7 <= mul_tree_38_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_117_s7 <= mul_tree_38_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_120_s7 <= mul_tree_38_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_123_s7 <= mul_tree_38_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_126_s7 <= mul_tree_38_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_129_s7 <= mul_tree_38_129; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144_reduce(input wire [96:0] i240, input wire [97:0] i241, input wire [129:0] i242, input wire [160:0] i243, input wire [161:0] i244, input wire [193:0] i245, output wire [195:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i240[96], i240[95], i240[94], i240[93], i240[92], i240[91], i240[90], i240[89], i240[88], i240[87], i240[86], i240[85], i240[84], i240[83], i240[82], i240[81], i240[80], i240[79], i240[78], i240[77], i240[76], i240[75], i240[74], i240[73], i240[72], i240[71], i240[70], i240[69], i240[68], i240[67], i240[66], i240[65], i240[64], i240[63], i240[62], i240[61], i240[60], i240[59], i240[58], i240[57], i240[56], i240[55], i240[54], i240[53], i240[52], i240[51], i240[50], i240[49], i240[48], i240[47], i240[46], i240[45], i240[44], i240[43], i240[42], i240[41], i240[40], i240[39], i240[38], i240[37], i240[36], i240[35], i240[34], i240[33], i240[32], i240[31], i240[30], i240[29], i240[28], i240[27], i240[26], i240[25], i240[24], i240[23], i240[22], i240[21], i240[20], i240[19], i240[18], i240[17], i240[16], i240[15], i240[14], i240[13], i240[12], i240[11], i240[10], i240[9], i240[8], i240[7], i240[6], i240[5], i240[4], i240[3], i240[2], i240[1], i240[0]};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i241[97], i241[96], i241[95], i241[94], i241[93], i241[92], i241[91], i241[90], i241[89], i241[88], i241[87], i241[86], i241[85], i241[84], i241[83], i241[82], i241[81], i241[80], i241[79], i241[78], i241[77], i241[76], i241[75], i241[74], i241[73], i241[72], i241[71], i241[70], i241[69], i241[68], i241[67], i241[66], i241[65], i241[64], i241[63], i241[62], i241[61], i241[60], i241[59], i241[58], i241[57], i241[56], i241[55], i241[54], i241[53], i241[52], i241[51], i241[50], i241[49], i241[48], i241[47], i241[46], i241[45], i241[44], i241[43], i241[42], i241[41], i241[40], i241[39], i241[38], i241[37], i241[36], i241[35], i241[34], i241[33], i241[32], i241[31], i241[30], i241[29], i241[28], i241[27], i241[26], i241[25], i241[24], i241[23], i241[22], i241[21], i241[20], i241[19], i241[18], i241[17], i241[16], i241[15], i241[14], i241[13], i241[12], i241[11], i241[10], i241[9], i241[8], i241[7], i241[6], i241[5], i241[4], i241[3], i241[2], i241[1], i241[0]};
wire [192:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i242[129], i242[128], i242[127], i242[126], i242[125], i242[124], i242[123], i242[122], i242[121], i242[120], i242[119], i242[118], i242[117], i242[116], i242[115], i242[114], i242[113], i242[112], i242[111], i242[110], i242[109], i242[108], i242[107], i242[106], i242[105], i242[104], i242[103], i242[102], i242[101], i242[100], i242[99], i242[98], i242[97], i242[96], i242[95], i242[94], i242[93], i242[92], i242[91], i242[90], i242[89], i242[88], i242[87], i242[86], i242[85], i242[84], i242[83], i242[82], i242[81], i242[80], i242[79], i242[78], i242[77], i242[76], i242[75], i242[74], i242[73], i242[72], i242[71], i242[70], i242[69], i242[68], i242[67], i242[66], i242[65], i242[64], i242[63], i242[62], i242[61], i242[60], i242[59], i242[58], i242[57], i242[56], i242[55], i242[54], i242[53], i242[52], i242[51], i242[50], i242[49], i242[48], i242[47], i242[46], i242[45], i242[44], i242[43], i242[42], i242[41], i242[40], i242[39], i242[38], i242[37], i242[36], i242[35], i242[34], i242[33], i242[32], i242[31], i242[30], i242[29], i242[28], i242[27], i242[26], i242[25], i242[24], i242[23], i242[22], i242[21], i242[20], i242[19], i242[18], i242[17], i242[16], i242[15], i242[14], i242[13], i242[12], i242[11], i242[10], i242[9], i242[8], i242[7], i242[6], i242[5], i242[4], i242[3], i242[2], i242[1], i242[0]};
wire [192:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i243[160], i243[159], i243[158], i243[157], i243[156], i243[155], i243[154], i243[153], i243[152], i243[151], i243[150], i243[149], i243[148], i243[147], i243[146], i243[145], i243[144], i243[143], i243[142], i243[141], i243[140], i243[139], i243[138], i243[137], i243[136], i243[135], i243[134], i243[133], i243[132], i243[131], i243[130], i243[129], i243[128], i243[127], i243[126], i243[125], i243[124], i243[123], i243[122], i243[121], i243[120], i243[119], i243[118], i243[117], i243[116], i243[115], i243[114], i243[113], i243[112], i243[111], i243[110], i243[109], i243[108], i243[107], i243[106], i243[105], i243[104], i243[103], i243[102], i243[101], i243[100], i243[99], i243[98], i243[97], i243[96], i243[95], i243[94], i243[93], i243[92], i243[91], i243[90], i243[89], i243[88], i243[87], i243[86], i243[85], i243[84], i243[83], i243[82], i243[81], i243[80], i243[79], i243[78], i243[77], i243[76], i243[75], i243[74], i243[73], i243[72], i243[71], i243[70], i243[69], i243[68], i243[67], i243[66], i243[65], i243[64], i243[63], i243[62], i243[61], i243[60], i243[59], i243[58], i243[57], i243[56], i243[55], i243[54], i243[53], i243[52], i243[51], i243[50], i243[49], i243[48], i243[47], i243[46], i243[45], i243[44], i243[43], i243[42], i243[41], i243[40], i243[39], i243[38], i243[37], i243[36], i243[35], i243[34], i243[33], i243[32], i243[31], i243[30], i243[29], i243[28], i243[27], i243[26], i243[25], i243[24], i243[23], i243[22], i243[21], i243[20], i243[19], i243[18], i243[17], i243[16], i243[15], i243[14], i243[13], i243[12], i243[11], i243[10], i243[9], i243[8], i243[7], i243[6], i243[5], i243[4], i243[3], i243[2], i243[1], i243[0]};
wire [192:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i244[161], i244[160], i244[159], i244[158], i244[157], i244[156], i244[155], i244[154], i244[153], i244[152], i244[151], i244[150], i244[149], i244[148], i244[147], i244[146], i244[145], i244[144], i244[143], i244[142], i244[141], i244[140], i244[139], i244[138], i244[137], i244[136], i244[135], i244[134], i244[133], i244[132], i244[131], i244[130], i244[129], i244[128], i244[127], i244[126], i244[125], i244[124], i244[123], i244[122], i244[121], i244[120], i244[119], i244[118], i244[117], i244[116], i244[115], i244[114], i244[113], i244[112], i244[111], i244[110], i244[109], i244[108], i244[107], i244[106], i244[105], i244[104], i244[103], i244[102], i244[101], i244[100], i244[99], i244[98], i244[97], i244[96], i244[95], i244[94], i244[93], i244[92], i244[91], i244[90], i244[89], i244[88], i244[87], i244[86], i244[85], i244[84], i244[83], i244[82], i244[81], i244[80], i244[79], i244[78], i244[77], i244[76], i244[75], i244[74], i244[73], i244[72], i244[71], i244[70], i244[69], i244[68], i244[67], i244[66], i244[65], i244[64], i244[63], i244[62], i244[61], i244[60], i244[59], i244[58], i244[57], i244[56], i244[55], i244[54], i244[53], i244[52], i244[51], i244[50], i244[49], i244[48], i244[47], i244[46], i244[45], i244[44], i244[43], i244[42], i244[41], i244[40], i244[39], i244[38], i244[37], i244[36], i244[35], i244[34], i244[33], i244[32], i244[31], i244[30], i244[29], i244[28], i244[27], i244[26], i244[25], i244[24], i244[23], i244[22], i244[21], i244[20], i244[19], i244[18], i244[17], i244[16], i244[15], i244[14], i244[13], i244[12], i244[11], i244[10], i244[9], i244[8], i244[7], i244[6], i244[5], i244[4], i244[3], i244[2], i244[1], i244[0]};
wire [192:0] t5 = {i245[192], i245[191], i245[190], i245[189], i245[188], i245[187], i245[186], i245[185], i245[184], i245[183], i245[182], i245[181], i245[180], i245[179], i245[178], i245[177], i245[176], i245[175], i245[174], i245[173], i245[172], i245[171], i245[170], i245[169], i245[168], i245[167], i245[166], i245[165], i245[164], i245[163], i245[162], i245[161], i245[160], i245[159], i245[158], i245[157], i245[156], i245[155], i245[154], i245[153], i245[152], i245[151], i245[150], i245[149], i245[148], i245[147], i245[146], i245[145], i245[144], i245[143], i245[142], i245[141], i245[140], i245[139], i245[138], i245[137], i245[136], i245[135], i245[134], i245[133], i245[132], i245[131], i245[130], i245[129], i245[128], i245[127], i245[126], i245[125], i245[124], i245[123], i245[122], i245[121], i245[120], i245[119], i245[118], i245[117], i245[116], i245[115], i245[114], i245[113], i245[112], i245[111], i245[110], i245[109], i245[108], i245[107], i245[106], i245[105], i245[104], i245[103], i245[102], i245[101], i245[100], i245[99], i245[98], i245[97], i245[96], i245[95], i245[94], i245[93], i245[92], i245[91], i245[90], i245[89], i245[88], i245[87], i245[86], i245[85], i245[84], i245[83], i245[82], i245[81], i245[80], i245[79], i245[78], i245[77], i245[76], i245[75], i245[74], i245[73], i245[72], i245[71], i245[70], i245[69], i245[68], i245[67], i245[66], i245[65], i245[64], i245[63], i245[62], i245[61], i245[60], i245[59], i245[58], i245[57], i245[56], i245[55], i245[54], i245[53], i245[52], i245[51], i245[50], i245[49], i245[48], i245[47], i245[46], i245[45], i245[44], i245[43], i245[42], i245[41], i245[40], i245[39], i245[38], i245[37], i245[36], i245[35], i245[34], i245[33], i245[32], i245[31], i245[30], i245[29], i245[28], i245[27], i245[26], i245[25], i245[24], i245[23], i245[22], i245[21], i245[20], i245[19], i245[18], i245[17], i245[16], i245[15], i245[14], i245[13], i245[12], i245[11], i245[10], i245[9], i245[8], i245[7], i245[6], i245[5], i245[4], i245[3], i245[2], i245[1], i245[0]};
wire [192:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183_reduce(input wire [63:0] i148, input wire [63:0] i151, input wire [63:0] i155, input wire [63:0] i159, input wire [32:0] i163, input wire [32:0] i167, output wire [130:0] y);
wire [128:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i148[63], i148[62], i148[61], i148[60], i148[59], i148[58], i148[57], i148[56], i148[55], i148[54], i148[53], i148[52], i148[51], i148[50], i148[49], i148[48], i148[47], i148[46], i148[45], i148[44], i148[43], i148[42], i148[41], i148[40], i148[39], i148[38], i148[37], i148[36], i148[35], i148[34], i148[33], i148[32], i148[31], i148[30], i148[29], i148[28], i148[27], i148[26], i148[25], i148[24], i148[23], i148[22], i148[21], i148[20], i148[19], i148[18], i148[17], i148[16], i148[15], i148[14], i148[13], i148[12], i148[11], i148[10], i148[9], i148[8], i148[7], i148[6], i148[5], i148[4], i148[3], i148[2], i148[1], i148[0]};
wire [128:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i151[63], i151[62], i151[61], i151[60], i151[59], i151[58], i151[57], i151[56], i151[55], i151[54], i151[53], i151[52], i151[51], i151[50], i151[49], i151[48], i151[47], i151[46], i151[45], i151[44], i151[43], i151[42], i151[41], i151[40], i151[39], i151[38], i151[37], i151[36], i151[35], i151[34], i151[33], i151[32], i151[31], i151[30], i151[29], i151[28], i151[27], i151[26], i151[25], i151[24], i151[23], i151[22], i151[21], i151[20], i151[19], i151[18], i151[17], i151[16], i151[15], i151[14], i151[13], i151[12], i151[11], i151[10], i151[9], i151[8], i151[7], i151[6], i151[5], i151[4], i151[3], i151[2], i151[1], i151[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i155[63], i155[62], i155[61], i155[60], i155[59], i155[58], i155[57], i155[56], i155[55], i155[54], i155[53], i155[52], i155[51], i155[50], i155[49], i155[48], i155[47], i155[46], i155[45], i155[44], i155[43], i155[42], i155[41], i155[40], i155[39], i155[38], i155[37], i155[36], i155[35], i155[34], i155[33], i155[32], i155[31], i155[30], i155[29], i155[28], i155[27], i155[26], i155[25], i155[24], i155[23], i155[22], i155[21], i155[20], i155[19], i155[18], i155[17], i155[16], i155[15], i155[14], i155[13], i155[12], i155[11], i155[10], i155[9], i155[8], i155[7], i155[6], i155[5], i155[4], i155[3], i155[2], i155[1], i155[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t3 = {1'b0, i159[63], i159[62], i159[61], i159[60], i159[59], i159[58], i159[57], i159[56], i159[55], i159[54], i159[53], i159[52], i159[51], i159[50], i159[49], i159[48], i159[47], i159[46], i159[45], i159[44], i159[43], i159[42], i159[41], i159[40], i159[39], i159[38], i159[37], i159[36], i159[35], i159[34], i159[33], i159[32], i159[31], i159[30], i159[29], i159[28], i159[27], i159[26], i159[25], i159[24], i159[23], i159[22], i159[21], i159[20], i159[19], i159[18], i159[17], i159[16], i159[15], i159[14], i159[13], i159[12], i159[11], i159[10], i159[9], i159[8], i159[7], i159[6], i159[5], i159[4], i159[3], i159[2], i159[1], i159[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i163[32], i163[31], i163[30], i163[29], i163[28], i163[27], i163[26], i163[25], i163[24], i163[23], i163[22], i163[21], i163[20], i163[19], i163[18], i163[17], i163[16], i163[15], i163[14], i163[13], i163[12], i163[11], i163[10], i163[9], i163[8], i163[7], i163[6], i163[5], i163[4], i163[3], i163[2], i163[1], i163[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t5 = {i167[32], i167[31], i167[30], i167[29], i167[28], i167[27], i167[26], i167[25], i167[24], i167[23], i167[22], i167[21], i167[20], i167[19], i167[18], i167[17], i167[16], i167[15], i167[14], i167[13], i167[12], i167[11], i167[10], i167[9], i167[8], i167[7], i167[6], i167[5], i167[4], i167[3], i167[2], i167[1], i167[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117Core(input wire [96:0] a,input wire [95:0] b,input wire cin,output wire [97:0] value);
wire [96:0] masked_a=((a&97'h1ffffffff0000000000000000)|97'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [97:0] aa=98'(masked_b);
wire [97:0] bb=98'(masked_a);
wire [98:0] extended={1'b0,aa}+{1'b0,bb}+99'(1'b0);
wire [97:0] native_value=extended[97:0];
assign value=native_value[0+:98];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_117();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [127:0] a,input wire [128:0] b,input wire cin,output wire [129:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [128:0] masked_b=((b&129'h1ffffffff000000000000000000000000)|129'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}+{1'b0,bb}+131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [127:0] a,input wire [159:0] b,input wire cin,output wire [160:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffff0000000000000000)|128'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [160:0] aa=161'(masked_b);
wire [160:0] bb=161'(masked_a);
wire [161:0] extended={1'b0,aa}+{1'b0,bb}+162'(1'b0);
wire [160:0] native_value=extended[160:0];
assign value=native_value[0+:161];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [160:0] a,input wire [159:0] b,input wire cin,output wire [161:0] value);
wire [160:0] masked_a=((a&161'h1ffffffff00000000000000000000000000000000)|161'h0);
wire [159:0] masked_b=((b&160'hffffffffffffffff000000000000000000000000)|160'h0);
wire [161:0] aa=162'(masked_b);
wire [161:0] bb=162'(masked_a);
wire [162:0] extended={1'b0,aa}+{1'b0,bb}+163'(1'b0);
wire [161:0] native_value=extended[161:0];
assign value=native_value[0+:162];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [191:0] a,input wire [192:0] b,input wire cin,output wire [192:0] value);
wire [191:0] masked_a=((a&192'hffffffffffffffff00000000000000000000000000000000)|192'h0);
wire [192:0] masked_b=((b&193'h1ffffffff0000000000000000000000000000000000000000)|193'h0);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [193:0] extended={1'b0,aa}+{1'b0,bb}+194'(1'b0);
wire [192:0] native_value=extended[192:0];
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
