`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_66; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_70; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_72; // decl: <none>; prim: <none>
    logic mul_tree_38_73; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_77; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_78; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_81; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_84; // decl: <none>; prim: <none>
    logic mul_tree_38_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_89; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_90; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_93; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_94; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_96; // decl: <none>; prim: <none>
    logic mul_tree_38_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_98; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_101; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_102; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_104; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_105; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_106; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_108; // decl: <none>; prim: <none>
    logic mul_tree_38_109; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_110; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_114; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_115; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_116; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_119; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_120; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_121; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_122; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_123; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_124; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_125; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_126; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_127; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_128; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_129; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_130; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_131; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_132; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_133; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_134; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_135; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_136; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_137; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_138; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_139; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_140; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_141; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_142; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_143; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_144; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_160; // decl: <none>; prim: <none>
    logic mul_tree_39_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_162; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_163; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_164; // decl: <none>; prim: <none>
    logic mul_tree_39_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_166; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_167; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_168; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_169; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_170; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_171; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_172; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_173; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_174; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_175; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_176; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_177; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_178; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_179; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_180; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_181; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_182; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_183; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_184; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_15_s5; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] rtlzz_pipe_15_s7; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [127:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s6; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s6; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_34_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s3 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(129'(rtlzz_pipe_15_s7)), .b(129'(n3_v0)), .cin(1'b0), .value(s8_norm_sub_14_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_sub_18_v0[63:0]));
    assign s8_norm_sub_18_v0[128:64] = '0;
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_64; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_145; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_184; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(32'(mul_tree_37_40)), .b(32'(mul_tree_37_41)), .cin(1'b0), .value(mul_tree_37_42));
    assign mul_tree_37_43 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(32'(mul_tree_37_43)), .b(32'(mul_tree_37_44)), .cin(1'b0), .value(mul_tree_37_45));
    assign mul_tree_37_46 = {mul_tree_37_45, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(32'(mul_tree_37_47)), .b(32'(mul_tree_37_48)), .cin(1'b0), .value(mul_tree_37_49));
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(32'(mul_tree_37_51)), .b(32'(mul_tree_37_52)), .cin(1'b0), .value(mul_tree_37_53));
    assign mul_tree_37_54 = {mul_tree_37_53, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_56 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_57Core rtlzz_owner_57(.a(64'(mul_tree_37_55)), .b(96'(mul_tree_37_56)), .cin(1'h0), .value(mul_tree_37_57));
    assign mul_tree_37_58 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_59 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(96'(mul_tree_37_58)), .b(128'(mul_tree_37_59)), .cin(1'h0), .value(mul_tree_37_60[127:0]));
    assign mul_tree_37_60[128:128] = '0;
    assign mul_tree_37_61 = ({33'h0, rtlzz_pipe_57_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_62 = ({1'h0, rtlzz_pipe_60_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(97'(mul_tree_37_61)), .b(129'(mul_tree_37_62)), .cin(1'h0), .value(mul_tree_37_63[127:0]));
    assign mul_tree_37_63[129:128] = '0;
    assign mul_tree_37_64 = mul_tree_37_63[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_65 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_66 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(32'(mul_tree_38_65)), .b(32'(mul_tree_38_66)), .cin(1'b0), .value(mul_tree_38_67));
    assign mul_tree_38_68 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_69 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(32'(mul_tree_38_68)), .b(32'(mul_tree_38_69)), .cin(1'b0), .value(mul_tree_38_70));
    assign mul_tree_38_71 = {mul_tree_38_70, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_72 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_73 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(32'(mul_tree_38_72)), .b(1'(mul_tree_38_73)), .cin(1'b0), .value(mul_tree_38_74));
    assign mul_tree_38_75 = {mul_tree_38_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_76 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_77 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(32'(mul_tree_38_76)), .b(32'(mul_tree_38_77)), .cin(1'b0), .value(mul_tree_38_78));
    assign mul_tree_38_79 = {mul_tree_38_78, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_80 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_81 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(32'(mul_tree_38_80)), .b(32'(mul_tree_38_81)), .cin(1'b0), .value(mul_tree_38_82));
    assign mul_tree_38_83 = {mul_tree_38_82, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_84 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_85 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(32'(mul_tree_38_84)), .b(1'(mul_tree_38_85)), .cin(1'b0), .value(mul_tree_38_86));
    assign mul_tree_38_87 = {mul_tree_38_86, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_88 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_89 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(32'(mul_tree_38_88)), .b(32'(mul_tree_38_89)), .cin(1'b0), .value(mul_tree_38_90));
    assign mul_tree_38_91 = {mul_tree_38_90, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_92 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_93 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(32'(mul_tree_38_92)), .b(32'(mul_tree_38_93)), .cin(1'b0), .value(mul_tree_38_94));
    assign mul_tree_38_95 = {mul_tree_38_94, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_96 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_97 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_38_96)), .b(1'(mul_tree_38_97)), .cin(1'b0), .value(mul_tree_38_98));
    assign mul_tree_38_99 = {mul_tree_38_98, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_100 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_101 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(32'(mul_tree_38_100)), .b(32'(mul_tree_38_101)), .cin(1'b0), .value(mul_tree_38_102));
    assign mul_tree_38_103 = {mul_tree_38_102, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_104 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_105 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(32'(mul_tree_38_104)), .b(32'(mul_tree_38_105)), .cin(1'b0), .value(mul_tree_38_106));
    assign mul_tree_38_107 = {mul_tree_38_106, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_108 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_109 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(32'(mul_tree_38_108)), .b(1'(mul_tree_38_109)), .cin(1'b0), .value(mul_tree_38_110));
    assign mul_tree_38_111 = {mul_tree_38_110, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_112 = ({33'h0, rtlzz_pipe_67_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_113 = ({1'h0, rtlzz_pipe_71_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_115 = ({1'h0, rtlzz_pipe_75_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_116 = ({2'h0, rtlzz_pipe_79_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_118 = ({2'h0, rtlzz_pipe_83_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_119 = ({1'h0, rtlzz_pipe_87_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_121 = ({33'h0, rtlzz_pipe_91_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_122 = ({1'h0, rtlzz_pipe_95_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_124 = ({1'h0, rtlzz_pipe_99_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_125 = ({2'h0, rtlzz_pipe_103_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_127 = ({2'h0, rtlzz_pipe_107_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_128 = ({1'h0, rtlzz_pipe_111_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_130 = ({2'h0, mul_tree_38_114}); // decl: <none>; prim: <none>
    assign mul_tree_38_131 = ({1'h0, mul_tree_38_117}); // decl: <none>; prim: <none>
    assign mul_tree_38_133 = ({32'h0, mul_tree_38_120}); // decl: <none>; prim: <none>
    assign mul_tree_38_134 = ({1'h0, mul_tree_38_123}); // decl: <none>; prim: <none>
    assign mul_tree_38_136 = ({33'h0, mul_tree_38_126}); // decl: <none>; prim: <none>
    assign mul_tree_38_137 = ({1'h0, mul_tree_38_129}); // decl: <none>; prim: <none>
    assign mul_tree_38_139 = ({64'h0, mul_tree_38_132}); // decl: <none>; prim: <none>
    assign mul_tree_38_140 = ({1'h0, mul_tree_38_135}); // decl: <none>; prim: <none>
    assign mul_tree_38_142 = ({33'h0, mul_tree_38_141}); // decl: <none>; prim: <none>
    assign mul_tree_38_143 = ({1'h0, mul_tree_38_138}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144_reduce rtlzz_reduce_144(.i218(rtlzz_pipe_67_s6), .i219(rtlzz_pipe_71_s6), .i220(rtlzz_pipe_75_s6), .i221(rtlzz_pipe_79_s6), .i222(rtlzz_pipe_83_s6), .i223(rtlzz_pipe_87_s6), .i224(rtlzz_pipe_91_s6), .i225(rtlzz_pipe_95_s6), .i226(rtlzz_pipe_99_s6), .i227(rtlzz_pipe_103_s6), .i228(rtlzz_pipe_107_s6), .i229(rtlzz_pipe_111_s6), .y(mul_tree_38_144));
    assign mul_tree_38_145 = mul_tree_38_144[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_146 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_147 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_39_146)), .b(32'(mul_tree_39_147)), .cin(1'b0), .value(mul_tree_39_148));
    assign mul_tree_39_149 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_150 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_39_149)), .b(32'(mul_tree_39_150)), .cin(1'b0), .value(mul_tree_39_151));
    assign mul_tree_39_152 = {mul_tree_39_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_153 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_154 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_39_153)), .b(32'(mul_tree_39_154)), .cin(1'b0), .value(mul_tree_39_155));
    assign mul_tree_39_156 = {mul_tree_39_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_157 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_158 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_39_157)), .b(32'(mul_tree_39_158)), .cin(1'b0), .value(mul_tree_39_159));
    assign mul_tree_39_160 = {mul_tree_39_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_161 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_162 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(1'(mul_tree_39_161)), .b(32'(mul_tree_39_162)), .cin(1'b0), .value(mul_tree_39_163));
    assign mul_tree_39_164 = {mul_tree_39_163, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_165 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_166 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(1'(mul_tree_39_165)), .b(32'(mul_tree_39_166)), .cin(1'b0), .value(mul_tree_39_167));
    assign mul_tree_39_168 = {mul_tree_39_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_169 = ({33'h0, mul_tree_39_148}); // decl: <none>; prim: <none>
    assign mul_tree_39_170 = ({1'h0, mul_tree_39_152}); // decl: <none>; prim: <none>
    assign mul_tree_39_172 = ({33'h0, mul_tree_39_156}); // decl: <none>; prim: <none>
    assign mul_tree_39_173 = ({1'h0, mul_tree_39_160}); // decl: <none>; prim: <none>
    assign mul_tree_39_175 = ({33'h0, mul_tree_39_164}); // decl: <none>; prim: <none>
    assign mul_tree_39_176 = ({1'h0, mul_tree_39_168}); // decl: <none>; prim: <none>
    assign mul_tree_39_178 = ({33'h0, mul_tree_39_171}); // decl: <none>; prim: <none>
    assign mul_tree_39_179 = ({1'h0, mul_tree_39_174}); // decl: <none>; prim: <none>
    assign mul_tree_39_181 = ({1'h0, mul_tree_39_180}); // decl: <none>; prim: <none>
    assign mul_tree_39_182 = ({1'h0, mul_tree_39_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_183_reduce rtlzz_reduce_183(.i148(mul_tree_39_148), .i151(mul_tree_39_151), .i155(mul_tree_39_155), .i159(mul_tree_39_159), .i163(mul_tree_39_163), .i167(mul_tree_39_167), .y(mul_tree_39_183));
    assign mul_tree_39_184 = mul_tree_39_183[128:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 96'h0;
            rtlzz_pipe_54_s1 <= 128'h0;
            rtlzz_pipe_57_s2 <= 97'h0;
            rtlzz_pipe_60_s2 <= 129'h0;
            rtlzz_pipe_23_s3 <= 193'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_25_s4 <= 129'h0;
            rtlzz_pipe_15_s5 <= 129'h0;
            rtlzz_pipe_15_s6 <= 129'h0;
            rtlzz_pipe_15_s7 <= 129'h0;
            rtlzz_pipe_31_s4 <= 128'h0;
            rtlzz_pipe_31_s5 <= 128'h0;
            rtlzz_pipe_67_s6 <= 64'h0;
            rtlzz_pipe_71_s6 <= 96'h0;
            rtlzz_pipe_75_s6 <= 97'h0;
            rtlzz_pipe_79_s6 <= 96'h0;
            rtlzz_pipe_83_s6 <= 128'h0;
            rtlzz_pipe_87_s6 <= 129'h0;
            rtlzz_pipe_91_s6 <= 128'h0;
            rtlzz_pipe_95_s6 <= 160'h0;
            rtlzz_pipe_99_s6 <= 161'h0;
            rtlzz_pipe_103_s6 <= 160'h0;
            rtlzz_pipe_107_s6 <= 192'h0;
            rtlzz_pipe_111_s6 <= 193'h0;
            rtlzz_pipe_34_s7 <= 65'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= mul_tree_37_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= mul_tree_37_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_25_s4 <= rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_15_s5 <= tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_15_s6 <= rtlzz_pipe_15_s5; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_15_s7 <= rtlzz_pipe_15_s6; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_31_s5 <= rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= mul_tree_38_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_71_s6 <= mul_tree_38_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= mul_tree_38_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= mul_tree_38_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= mul_tree_38_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= mul_tree_38_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_91_s6 <= mul_tree_38_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_95_s6 <= mul_tree_38_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_99_s6 <= mul_tree_38_99; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= mul_tree_38_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= mul_tree_38_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= mul_tree_38_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_34_s7 <= mul_precision_34; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144_reduce(input wire [63:0] i218, input wire [95:0] i219, input wire [96:0] i220, input wire [95:0] i221, input wire [127:0] i222, input wire [128:0] i223, input wire [127:0] i224, input wire [159:0] i225, input wire [160:0] i226, input wire [159:0] i227, input wire [191:0] i228, input wire [192:0] i229, output wire [195:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i218[63], i218[62], i218[61], i218[60], i218[59], i218[58], i218[57], i218[56], i218[55], i218[54], i218[53], i218[52], i218[51], i218[50], i218[49], i218[48], i218[47], i218[46], i218[45], i218[44], i218[43], i218[42], i218[41], i218[40], i218[39], i218[38], i218[37], i218[36], i218[35], i218[34], i218[33], i218[32], i218[31], i218[30], i218[29], i218[28], i218[27], i218[26], i218[25], i218[24], i218[23], i218[22], i218[21], i218[20], i218[19], i218[18], i218[17], i218[16], i218[15], i218[14], i218[13], i218[12], i218[11], i218[10], i218[9], i218[8], i218[7], i218[6], i218[5], i218[4], i218[3], i218[2], i218[1], i218[0]};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i219[95], i219[94], i219[93], i219[92], i219[91], i219[90], i219[89], i219[88], i219[87], i219[86], i219[85], i219[84], i219[83], i219[82], i219[81], i219[80], i219[79], i219[78], i219[77], i219[76], i219[75], i219[74], i219[73], i219[72], i219[71], i219[70], i219[69], i219[68], i219[67], i219[66], i219[65], i219[64], i219[63], i219[62], i219[61], i219[60], i219[59], i219[58], i219[57], i219[56], i219[55], i219[54], i219[53], i219[52], i219[51], i219[50], i219[49], i219[48], i219[47], i219[46], i219[45], i219[44], i219[43], i219[42], i219[41], i219[40], i219[39], i219[38], i219[37], i219[36], i219[35], i219[34], i219[33], i219[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i220[96], i220[95], i220[94], i220[93], i220[92], i220[91], i220[90], i220[89], i220[88], i220[87], i220[86], i220[85], i220[84], i220[83], i220[82], i220[81], i220[80], i220[79], i220[78], i220[77], i220[76], i220[75], i220[74], i220[73], i220[72], i220[71], i220[70], i220[69], i220[68], i220[67], i220[66], i220[65], i220[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i221[95], i221[94], i221[93], i221[92], i221[91], i221[90], i221[89], i221[88], i221[87], i221[86], i221[85], i221[84], i221[83], i221[82], i221[81], i221[80], i221[79], i221[78], i221[77], i221[76], i221[75], i221[74], i221[73], i221[72], i221[71], i221[70], i221[69], i221[68], i221[67], i221[66], i221[65], i221[64], i221[63], i221[62], i221[61], i221[60], i221[59], i221[58], i221[57], i221[56], i221[55], i221[54], i221[53], i221[52], i221[51], i221[50], i221[49], i221[48], i221[47], i221[46], i221[45], i221[44], i221[43], i221[42], i221[41], i221[40], i221[39], i221[38], i221[37], i221[36], i221[35], i221[34], i221[33], i221[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i222[127], i222[126], i222[125], i222[124], i222[123], i222[122], i222[121], i222[120], i222[119], i222[118], i222[117], i222[116], i222[115], i222[114], i222[113], i222[112], i222[111], i222[110], i222[109], i222[108], i222[107], i222[106], i222[105], i222[104], i222[103], i222[102], i222[101], i222[100], i222[99], i222[98], i222[97], i222[96], i222[95], i222[94], i222[93], i222[92], i222[91], i222[90], i222[89], i222[88], i222[87], i222[86], i222[85], i222[84], i222[83], i222[82], i222[81], i222[80], i222[79], i222[78], i222[77], i222[76], i222[75], i222[74], i222[73], i222[72], i222[71], i222[70], i222[69], i222[68], i222[67], i222[66], i222[65], i222[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i223[128], i223[127], i223[126], i223[125], i223[124], i223[123], i223[122], i223[121], i223[120], i223[119], i223[118], i223[117], i223[116], i223[115], i223[114], i223[113], i223[112], i223[111], i223[110], i223[109], i223[108], i223[107], i223[106], i223[105], i223[104], i223[103], i223[102], i223[101], i223[100], i223[99], i223[98], i223[97], i223[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i224[127], i224[126], i224[125], i224[124], i224[123], i224[122], i224[121], i224[120], i224[119], i224[118], i224[117], i224[116], i224[115], i224[114], i224[113], i224[112], i224[111], i224[110], i224[109], i224[108], i224[107], i224[106], i224[105], i224[104], i224[103], i224[102], i224[101], i224[100], i224[99], i224[98], i224[97], i224[96], i224[95], i224[94], i224[93], i224[92], i224[91], i224[90], i224[89], i224[88], i224[87], i224[86], i224[85], i224[84], i224[83], i224[82], i224[81], i224[80], i224[79], i224[78], i224[77], i224[76], i224[75], i224[74], i224[73], i224[72], i224[71], i224[70], i224[69], i224[68], i224[67], i224[66], i224[65], i224[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i225[159], i225[158], i225[157], i225[156], i225[155], i225[154], i225[153], i225[152], i225[151], i225[150], i225[149], i225[148], i225[147], i225[146], i225[145], i225[144], i225[143], i225[142], i225[141], i225[140], i225[139], i225[138], i225[137], i225[136], i225[135], i225[134], i225[133], i225[132], i225[131], i225[130], i225[129], i225[128], i225[127], i225[126], i225[125], i225[124], i225[123], i225[122], i225[121], i225[120], i225[119], i225[118], i225[117], i225[116], i225[115], i225[114], i225[113], i225[112], i225[111], i225[110], i225[109], i225[108], i225[107], i225[106], i225[105], i225[104], i225[103], i225[102], i225[101], i225[100], i225[99], i225[98], i225[97], i225[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i226[160], i226[159], i226[158], i226[157], i226[156], i226[155], i226[154], i226[153], i226[152], i226[151], i226[150], i226[149], i226[148], i226[147], i226[146], i226[145], i226[144], i226[143], i226[142], i226[141], i226[140], i226[139], i226[138], i226[137], i226[136], i226[135], i226[134], i226[133], i226[132], i226[131], i226[130], i226[129], i226[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t9 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i227[159], i227[158], i227[157], i227[156], i227[155], i227[154], i227[153], i227[152], i227[151], i227[150], i227[149], i227[148], i227[147], i227[146], i227[145], i227[144], i227[143], i227[142], i227[141], i227[140], i227[139], i227[138], i227[137], i227[136], i227[135], i227[134], i227[133], i227[132], i227[131], i227[130], i227[129], i227[128], i227[127], i227[126], i227[125], i227[124], i227[123], i227[122], i227[121], i227[120], i227[119], i227[118], i227[117], i227[116], i227[115], i227[114], i227[113], i227[112], i227[111], i227[110], i227[109], i227[108], i227[107], i227[106], i227[105], i227[104], i227[103], i227[102], i227[101], i227[100], i227[99], i227[98], i227[97], i227[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t10 = {1'b0, i228[191], i228[190], i228[189], i228[188], i228[187], i228[186], i228[185], i228[184], i228[183], i228[182], i228[181], i228[180], i228[179], i228[178], i228[177], i228[176], i228[175], i228[174], i228[173], i228[172], i228[171], i228[170], i228[169], i228[168], i228[167], i228[166], i228[165], i228[164], i228[163], i228[162], i228[161], i228[160], i228[159], i228[158], i228[157], i228[156], i228[155], i228[154], i228[153], i228[152], i228[151], i228[150], i228[149], i228[148], i228[147], i228[146], i228[145], i228[144], i228[143], i228[142], i228[141], i228[140], i228[139], i228[138], i228[137], i228[136], i228[135], i228[134], i228[133], i228[132], i228[131], i228[130], i228[129], i228[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t11 = {i229[192], i229[191], i229[190], i229[189], i229[188], i229[187], i229[186], i229[185], i229[184], i229[183], i229[182], i229[181], i229[180], i229[179], i229[178], i229[177], i229[176], i229[175], i229[174], i229[173], i229[172], i229[171], i229[170], i229[169], i229[168], i229[167], i229[166], i229[165], i229[164], i229[163], i229[162], i229[161], i229[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183_reduce(input wire [63:0] i148, input wire [63:0] i151, input wire [63:0] i155, input wire [63:0] i159, input wire [32:0] i163, input wire [32:0] i167, output wire [130:0] y);
wire [128:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i148[63], i148[62], i148[61], i148[60], i148[59], i148[58], i148[57], i148[56], i148[55], i148[54], i148[53], i148[52], i148[51], i148[50], i148[49], i148[48], i148[47], i148[46], i148[45], i148[44], i148[43], i148[42], i148[41], i148[40], i148[39], i148[38], i148[37], i148[36], i148[35], i148[34], i148[33], i148[32], i148[31], i148[30], i148[29], i148[28], i148[27], i148[26], i148[25], i148[24], i148[23], i148[22], i148[21], i148[20], i148[19], i148[18], i148[17], i148[16], i148[15], i148[14], i148[13], i148[12], i148[11], i148[10], i148[9], i148[8], i148[7], i148[6], i148[5], i148[4], i148[3], i148[2], i148[1], i148[0]};
wire [128:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i151[63], i151[62], i151[61], i151[60], i151[59], i151[58], i151[57], i151[56], i151[55], i151[54], i151[53], i151[52], i151[51], i151[50], i151[49], i151[48], i151[47], i151[46], i151[45], i151[44], i151[43], i151[42], i151[41], i151[40], i151[39], i151[38], i151[37], i151[36], i151[35], i151[34], i151[33], i151[32], i151[31], i151[30], i151[29], i151[28], i151[27], i151[26], i151[25], i151[24], i151[23], i151[22], i151[21], i151[20], i151[19], i151[18], i151[17], i151[16], i151[15], i151[14], i151[13], i151[12], i151[11], i151[10], i151[9], i151[8], i151[7], i151[6], i151[5], i151[4], i151[3], i151[2], i151[1], i151[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i155[63], i155[62], i155[61], i155[60], i155[59], i155[58], i155[57], i155[56], i155[55], i155[54], i155[53], i155[52], i155[51], i155[50], i155[49], i155[48], i155[47], i155[46], i155[45], i155[44], i155[43], i155[42], i155[41], i155[40], i155[39], i155[38], i155[37], i155[36], i155[35], i155[34], i155[33], i155[32], i155[31], i155[30], i155[29], i155[28], i155[27], i155[26], i155[25], i155[24], i155[23], i155[22], i155[21], i155[20], i155[19], i155[18], i155[17], i155[16], i155[15], i155[14], i155[13], i155[12], i155[11], i155[10], i155[9], i155[8], i155[7], i155[6], i155[5], i155[4], i155[3], i155[2], i155[1], i155[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t3 = {1'b0, i159[63], i159[62], i159[61], i159[60], i159[59], i159[58], i159[57], i159[56], i159[55], i159[54], i159[53], i159[52], i159[51], i159[50], i159[49], i159[48], i159[47], i159[46], i159[45], i159[44], i159[43], i159[42], i159[41], i159[40], i159[39], i159[38], i159[37], i159[36], i159[35], i159[34], i159[33], i159[32], i159[31], i159[30], i159[29], i159[28], i159[27], i159[26], i159[25], i159[24], i159[23], i159[22], i159[21], i159[20], i159[19], i159[18], i159[17], i159[16], i159[15], i159[14], i159[13], i159[12], i159[11], i159[10], i159[9], i159[8], i159[7], i159[6], i159[5], i159[4], i159[3], i159[2], i159[1], i159[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i163[32], i163[31], i163[30], i163[29], i163[28], i163[27], i163[26], i163[25], i163[24], i163[23], i163[22], i163[21], i163[20], i163[19], i163[18], i163[17], i163[16], i163[15], i163[14], i163[13], i163[12], i163[11], i163[10], i163[9], i163[8], i163[7], i163[6], i163[5], i163[4], i163[3], i163[2], i163[1], i163[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t5 = {i167[32], i167[31], i167[30], i167[29], i167[28], i167[27], i167[26], i167[25], i167[24], i167[23], i167[22], i167[21], i167[20], i167[19], i167[18], i167[17], i167[16], i167[15], i167[14], i167[13], i167[12], i167[11], i167[10], i167[9], i167[8], i167[7], i167[6], i167[5], i167[4], i167[3], i167[2], i167[1], i167[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}-{1'b0,bb}-130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
