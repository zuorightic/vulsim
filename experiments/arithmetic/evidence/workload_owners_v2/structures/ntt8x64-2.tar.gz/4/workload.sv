`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] x1, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] x2, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] x3, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] x4, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] x5, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] x6, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] x7, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    output logic [63:0] y0, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    output logic [63:0] y1, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    output logic [63:0] y2, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    output logic [63:0] y3, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    output logic [63:0] y4, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    output logic [63:0] y5, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    output logic [63:0] y6, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    output logic [63:0] y7, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:8; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [64:0] tmp_workload_top_int_65__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] tmp_workload_top_int_65__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    logic [64:0] s8_norm_add_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_sub_20_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:18-44:62; prim: /home/zyrv/vulsim/workload.cpp:44:18-44:62
    logic [64:0] tmp_workload_top_int_65__41_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] tmp_workload_top_int_65__43_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    logic [64:0] s8_norm_add_34_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic s8_norm_cmp_38_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_sub_40_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_mux_41_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:19-50:66; prim: /home/zyrv/vulsim/workload.cpp:50:19-50:66
    logic [64:0] tmp_workload_top_int_65__74_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] tmp_workload_top_int_65__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] s8_norm_add_54_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic s8_norm_cmp_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_sub_60_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_mux_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    logic [64:0] tmp_workload_top_int_65__107_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] tmp_workload_top_int_65__109_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_mux_71_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
    logic [64:0] s8_norm_add_74_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic s8_norm_cmp_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_mux_81_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:19-62:66; prim: /home/zyrv/vulsim/workload.cpp:62:19-62:66
    logic [64:0] tmp_workload_top_int_65__140_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] tmp_workload_top_int_65__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    logic [64:0] s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic s8_norm_cmp_88_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_sub_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_mux_91_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
    logic [64:0] s8_norm_add_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic s8_norm_cmp_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_mux_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
    logic [127:0] tmp_workload_top_int_128__175_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    logic [255:0] s8_norm_mul_106_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:49; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:31
    logic [192:0] tmp_workload_top_int_193__180_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    logic [385:0] s8_norm_mul_110_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n34_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    logic [257:0] s8_norm_mul_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:20-75:48; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:22
    logic [128:0] n36_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    logic [128:0] tmp_workload_top_int_129__191_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:39
    logic s8_norm_cmp_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:21-77:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_122_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:50-77:68; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_mux_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:69; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:69
    logic [64:0] tmp_workload_top_int_65__204_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] tmp_workload_top_int_65__206_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    logic [64:0] s8_norm_add_127_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:45; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:45
    logic s8_norm_cmp_129_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:20-80:37; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_sub_131_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:48-80:65; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_mux_132_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:66; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:66
    logic [64:0] s8_norm_add_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] s8_norm_sub_137_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:59; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:59
    logic s8_norm_cmp_139_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:20-82:37; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_sub_141_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:48-82:65; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_mux_142_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:19-82:66; prim: /home/zyrv/vulsim/workload.cpp:82:19-82:66
    logic [64:0] tmp_workload_top_int_65__237_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] tmp_workload_top_int_65__239_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    logic [64:0] s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_sub_151_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_mux_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
    logic [64:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic s8_norm_cmp_159_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_mux_162_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:66; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:66
    logic [127:0] tmp_workload_top_int_128__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    logic [255:0] s8_norm_mul_167_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:49; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:31
    logic [192:0] tmp_workload_top_int_193__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [385:0] s8_norm_mul_171_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n54_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    logic [257:0] s8_norm_mul_176_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:48; prim: /home/zyrv/vulsim/workload.cpp:94:19-94:22
    logic [128:0] n56_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    logic [128:0] tmp_workload_top_int_129__288_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_179_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:39
    logic s8_norm_cmp_181_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:21-97:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_183_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:50-97:68; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_mux_184_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:20-97:69; prim: /home/zyrv/vulsim/workload.cpp:97:20-97:69
    logic [64:0] tmp_workload_top_int_65__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] tmp_workload_top_int_65__303_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    logic [64:0] s8_norm_add_188_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:46; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:46
    logic s8_norm_cmp_190_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:20-100:37; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_sub_192_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:48-100:65; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_mux_193_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:19-100:66; prim: /home/zyrv/vulsim/workload.cpp:100:19-100:66
    logic [64:0] s8_norm_add_196_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] s8_norm_sub_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
    logic s8_norm_cmp_200_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_sub_202_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:48-102:65; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_mux_203_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:19-102:66; prim: /home/zyrv/vulsim/workload.cpp:102:19-102:66
    logic [64:0] tmp_workload_top_int_65__334_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    logic [64:0] tmp_workload_top_int_65__336_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    logic [64:0] s8_norm_add_208_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    logic s8_norm_cmp_210_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_sub_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:48-106:65; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_mux_213_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:19-106:66; prim: /home/zyrv/vulsim/workload.cpp:106:19-106:66
    logic [64:0] s8_norm_add_216_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:45; prim: /home/zyrv/vulsim/workload.cpp:69:19-69:31
    logic [64:0] s8_norm_sub_218_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
    logic s8_norm_cmp_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:20-108:37; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_sub_222_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:48-108:65; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_mux_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:19-108:66; prim: /home/zyrv/vulsim/workload.cpp:108:19-108:66
    logic [63:0] tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [127:0] tmp_workload_top_int_128__369_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    logic [255:0] s8_norm_mul_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:49; prim: /home/zyrv/vulsim/workload.cpp:103:19-103:31
    logic [192:0] tmp_workload_top_int_193__374_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    logic [385:0] s8_norm_mul_232_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    logic [257:0] s8_norm_mul_237_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:20-115:48; prim: /home/zyrv/vulsim/workload.cpp:114:19-114:22
    logic [128:0] n76_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    logic [128:0] tmp_workload_top_int_129__385_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_240_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:39
    logic s8_norm_cmp_242_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:21-117:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_244_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:50-117:68; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_mux_245_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:20-117:69; prim: /home/zyrv/vulsim/workload.cpp:117:20-117:69
    logic [64:0] tmp_workload_top_int_65__398_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    logic [64:0] tmp_workload_top_int_65__400_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    logic [64:0] s8_norm_add_249_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:46; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:46
    logic s8_norm_cmp_251_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:20-120:37; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_sub_253_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:48-120:65; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_mux_254_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:19-120:66; prim: /home/zyrv/vulsim/workload.cpp:120:19-120:66
    logic [64:0] s8_norm_add_257_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:45; prim: /home/zyrv/vulsim/workload.cpp:83:19-83:31
    logic [64:0] s8_norm_sub_259_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:60; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:60
    logic s8_norm_cmp_261_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:20-122:37; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_sub_263_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:48-122:65; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_mux_264_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:19-122:66; prim: /home/zyrv/vulsim/workload.cpp:122:19-122:66
    logic [63:0] tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    logic [63:0] tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    logic [127:0] tmp_workload_top_int_128__433_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    logic [255:0] s8_norm_mul_269_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:49; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:31
    logic [192:0] tmp_workload_top_int_193__438_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    logic [385:0] s8_norm_mul_273_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n88_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    logic [257:0] s8_norm_mul_278_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:20-129:48; prim: /home/zyrv/vulsim/workload.cpp:128:19-128:22
    logic [128:0] n90_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    logic [128:0] tmp_workload_top_int_129__449_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_281_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
    logic s8_norm_cmp_283_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:21-131:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_285_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:50-131:68; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_mux_286_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:20-131:69; prim: /home/zyrv/vulsim/workload.cpp:131:20-131:69
    logic [64:0] tmp_workload_top_int_65__462_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    logic [64:0] tmp_workload_top_int_65__464_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    logic [64:0] s8_norm_add_290_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:46; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:46
    logic s8_norm_cmp_292_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:20-134:37; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_sub_294_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:48-134:65; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_mux_295_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:19-134:66; prim: /home/zyrv/vulsim/workload.cpp:134:19-134:66
    logic [64:0] s8_norm_add_298_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:45; prim: /home/zyrv/vulsim/workload.cpp:70:19-70:31
    logic [64:0] s8_norm_sub_300_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
    logic s8_norm_cmp_302_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_sub_304_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:48-136:65; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_mux_305_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:19-136:66; prim: /home/zyrv/vulsim/workload.cpp:136:19-136:66
    logic [63:0] tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    logic [63:0] tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    logic [127:0] tmp_workload_top_int_128__497_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    logic [255:0] s8_norm_mul_310_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:51; prim: /home/zyrv/vulsim/workload.cpp:104:19-104:31
    logic [192:0] tmp_workload_top_int_193__502_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    logic [385:0] s8_norm_mul_314_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:50; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n102_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    logic [257:0] s8_norm_mul_319_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:21-143:50; prim: /home/zyrv/vulsim/workload.cpp:142:20-142:24
    logic [128:0] n104_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    logic [128:0] tmp_workload_top_int_129__513_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_322_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:42; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:42
    logic s8_norm_cmp_324_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:22-145:41; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_326_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:53-145:72; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_mux_327_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:21-145:73; prim: /home/zyrv/vulsim/workload.cpp:145:21-145:73
    logic [64:0] tmp_workload_top_int_65__526_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    logic [64:0] tmp_workload_top_int_65__528_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    logic [64:0] s8_norm_add_331_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:48; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:48
    logic s8_norm_cmp_333_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:21-148:39; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_sub_335_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:51-148:69; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_mux_336_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:20-148:70; prim: /home/zyrv/vulsim/workload.cpp:148:20-148:70
    logic [64:0] s8_norm_add_339_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:46; prim: /home/zyrv/vulsim/workload.cpp:84:19-84:31
    logic [64:0] s8_norm_sub_341_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:62; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:62
    logic s8_norm_cmp_343_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:21-150:39; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_sub_345_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:51-150:69; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_mux_346_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:20-150:70; prim: /home/zyrv/vulsim/workload.cpp:150:20-150:70
    logic [63:0] tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    logic [63:0] tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    logic [127:0] __beopt_width_858; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_859; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_860; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_862; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_863; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_865; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_866; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_867; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_869; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_870; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_872; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_873; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_874; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_876; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_877; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_879; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_880; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_881; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_883; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_884; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_886; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_887; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_888; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_890; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_891; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_255; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    logic [128:0] __beopt_width_259; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    logic [128:0] __beopt_width_263; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    logic [128:0] __beopt_width_268; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    logic [128:0] __beopt_width_272; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    logic [128:0] __beopt_width_256; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_260; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_264; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_267; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_253; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_254; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_255; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_256; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_257; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_258; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_259; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_260; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_261; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_262; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_263; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_264; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_265; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_266; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_267; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_268; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_269; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_270; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_272; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_273; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_274; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_275; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_276; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_277; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_278; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_279; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_280; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_281; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_282; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_283; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_284; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_285; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_286; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_287; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_288; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_289; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_290; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_291; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [112:0] arith_original_298; // decl: <none>; prim: <none>
    logic [192:0] arith_original_299; // decl: <none>; prim: <none>
    logic [128:0] arith_original_300; // decl: <none>; prim: <none>
    logic [112:0] arith_original_301; // decl: <none>; prim: <none>
    logic [192:0] arith_original_302; // decl: <none>; prim: <none>
    logic [128:0] arith_original_303; // decl: <none>; prim: <none>
    logic [127:0] arith_original_304; // decl: <none>; prim: <none>
    logic [192:0] arith_original_305; // decl: <none>; prim: <none>
    logic [128:0] arith_original_306; // decl: <none>; prim: <none>
    logic [112:0] arith_original_307; // decl: <none>; prim: <none>
    logic [192:0] arith_original_308; // decl: <none>; prim: <none>
    logic [128:0] arith_original_309; // decl: <none>; prim: <none>
    logic [127:0] arith_original_310; // decl: <none>; prim: <none>
    logic [192:0] arith_original_311; // decl: <none>; prim: <none>
    logic [128:0] arith_original_312; // decl: <none>; prim: <none>
    logic [63:0] limb_11_313; // decl: <none>; prim: <none>
    logic [63:0] limb_11_314; // decl: <none>; prim: <none>
    logic [64:0] limb_11_315; // decl: <none>; prim: <none>
    logic [63:0] limb_11_316; // decl: <none>; prim: <none>
    logic limb_11_317; // decl: <none>; prim: <none>
    logic limb_11_318; // decl: <none>; prim: <none>
    logic limb_11_319; // decl: <none>; prim: <none>
    logic [1:0] limb_11_320; // decl: <none>; prim: <none>
    logic limb_11_321; // decl: <none>; prim: <none>
    logic [64:0] limb_11_322; // decl: <none>; prim: <none>
    logic [63:0] limb_13_323; // decl: <none>; prim: <none>
    logic [63:0] limb_13_324; // decl: <none>; prim: <none>
    logic [63:0] limb_13_325; // decl: <none>; prim: <none>
    logic [64:0] limb_13_326; // decl: <none>; prim: <none>
    logic [63:0] limb_13_327; // decl: <none>; prim: <none>
    logic limb_13_328; // decl: <none>; prim: <none>
    logic limb_13_329; // decl: <none>; prim: <none>
    logic limb_13_330; // decl: <none>; prim: <none>
    logic limb_13_331; // decl: <none>; prim: <none>
    logic [1:0] limb_13_332; // decl: <none>; prim: <none>
    logic limb_13_333; // decl: <none>; prim: <none>
    logic [64:0] limb_13_334; // decl: <none>; prim: <none>
    logic [63:0] limb_15_335; // decl: <none>; prim: <none>
    logic [63:0] limb_15_336; // decl: <none>; prim: <none>
    logic [64:0] limb_15_337; // decl: <none>; prim: <none>
    logic [63:0] limb_15_338; // decl: <none>; prim: <none>
    logic limb_15_339; // decl: <none>; prim: <none>
    logic limb_15_340; // decl: <none>; prim: <none>
    logic limb_15_341; // decl: <none>; prim: <none>
    logic [1:0] limb_15_342; // decl: <none>; prim: <none>
    logic limb_15_343; // decl: <none>; prim: <none>
    logic [64:0] limb_15_344; // decl: <none>; prim: <none>
    logic [63:0] limb_16_345; // decl: <none>; prim: <none>
    logic [63:0] limb_16_346; // decl: <none>; prim: <none>
    logic [63:0] limb_16_347; // decl: <none>; prim: <none>
    logic [64:0] limb_16_348; // decl: <none>; prim: <none>
    logic [63:0] limb_16_349; // decl: <none>; prim: <none>
    logic limb_16_350; // decl: <none>; prim: <none>
    logic limb_16_351; // decl: <none>; prim: <none>
    logic limb_16_352; // decl: <none>; prim: <none>
    logic limb_16_353; // decl: <none>; prim: <none>
    logic [1:0] limb_16_354; // decl: <none>; prim: <none>
    logic limb_16_355; // decl: <none>; prim: <none>
    logic [64:0] limb_16_356; // decl: <none>; prim: <none>
    logic [63:0] limb_18_357; // decl: <none>; prim: <none>
    logic [63:0] limb_18_358; // decl: <none>; prim: <none>
    logic [63:0] limb_18_359; // decl: <none>; prim: <none>
    logic [64:0] limb_18_360; // decl: <none>; prim: <none>
    logic [63:0] limb_18_361; // decl: <none>; prim: <none>
    logic limb_18_362; // decl: <none>; prim: <none>
    logic limb_18_363; // decl: <none>; prim: <none>
    logic limb_18_364; // decl: <none>; prim: <none>
    logic limb_18_365; // decl: <none>; prim: <none>
    logic [1:0] limb_18_366; // decl: <none>; prim: <none>
    logic limb_18_367; // decl: <none>; prim: <none>
    logic [64:0] limb_18_368; // decl: <none>; prim: <none>
    logic [63:0] limb_22_369; // decl: <none>; prim: <none>
    logic [63:0] limb_22_370; // decl: <none>; prim: <none>
    logic [64:0] limb_22_371; // decl: <none>; prim: <none>
    logic [63:0] limb_22_372; // decl: <none>; prim: <none>
    logic limb_22_373; // decl: <none>; prim: <none>
    logic limb_22_374; // decl: <none>; prim: <none>
    logic limb_22_375; // decl: <none>; prim: <none>
    logic [1:0] limb_22_376; // decl: <none>; prim: <none>
    logic limb_22_377; // decl: <none>; prim: <none>
    logic [64:0] limb_22_378; // decl: <none>; prim: <none>
    logic [63:0] limb_24_379; // decl: <none>; prim: <none>
    logic [63:0] limb_24_380; // decl: <none>; prim: <none>
    logic [63:0] limb_24_381; // decl: <none>; prim: <none>
    logic [64:0] limb_24_382; // decl: <none>; prim: <none>
    logic [63:0] limb_24_383; // decl: <none>; prim: <none>
    logic limb_24_384; // decl: <none>; prim: <none>
    logic limb_24_385; // decl: <none>; prim: <none>
    logic limb_24_386; // decl: <none>; prim: <none>
    logic limb_24_387; // decl: <none>; prim: <none>
    logic [1:0] limb_24_388; // decl: <none>; prim: <none>
    logic limb_24_389; // decl: <none>; prim: <none>
    logic [64:0] limb_24_390; // decl: <none>; prim: <none>
    logic [63:0] limb_26_391; // decl: <none>; prim: <none>
    logic [63:0] limb_26_392; // decl: <none>; prim: <none>
    logic [64:0] limb_26_393; // decl: <none>; prim: <none>
    logic [63:0] limb_26_394; // decl: <none>; prim: <none>
    logic limb_26_395; // decl: <none>; prim: <none>
    logic limb_26_396; // decl: <none>; prim: <none>
    logic limb_26_397; // decl: <none>; prim: <none>
    logic [1:0] limb_26_398; // decl: <none>; prim: <none>
    logic limb_26_399; // decl: <none>; prim: <none>
    logic [64:0] limb_26_400; // decl: <none>; prim: <none>
    logic [63:0] limb_27_401; // decl: <none>; prim: <none>
    logic [63:0] limb_27_402; // decl: <none>; prim: <none>
    logic [63:0] limb_27_403; // decl: <none>; prim: <none>
    logic [64:0] limb_27_404; // decl: <none>; prim: <none>
    logic [63:0] limb_27_405; // decl: <none>; prim: <none>
    logic limb_27_406; // decl: <none>; prim: <none>
    logic limb_27_407; // decl: <none>; prim: <none>
    logic limb_27_408; // decl: <none>; prim: <none>
    logic limb_27_409; // decl: <none>; prim: <none>
    logic [1:0] limb_27_410; // decl: <none>; prim: <none>
    logic limb_27_411; // decl: <none>; prim: <none>
    logic [64:0] limb_27_412; // decl: <none>; prim: <none>
    logic [63:0] limb_29_413; // decl: <none>; prim: <none>
    logic [63:0] limb_29_414; // decl: <none>; prim: <none>
    logic [63:0] limb_29_415; // decl: <none>; prim: <none>
    logic [64:0] limb_29_416; // decl: <none>; prim: <none>
    logic [63:0] limb_29_417; // decl: <none>; prim: <none>
    logic limb_29_418; // decl: <none>; prim: <none>
    logic limb_29_419; // decl: <none>; prim: <none>
    logic limb_29_420; // decl: <none>; prim: <none>
    logic limb_29_421; // decl: <none>; prim: <none>
    logic [1:0] limb_29_422; // decl: <none>; prim: <none>
    logic limb_29_423; // decl: <none>; prim: <none>
    logic [64:0] limb_29_424; // decl: <none>; prim: <none>
    logic [63:0] limb_33_425; // decl: <none>; prim: <none>
    logic [63:0] limb_33_426; // decl: <none>; prim: <none>
    logic [64:0] limb_33_427; // decl: <none>; prim: <none>
    logic [63:0] limb_33_428; // decl: <none>; prim: <none>
    logic limb_33_429; // decl: <none>; prim: <none>
    logic limb_33_430; // decl: <none>; prim: <none>
    logic limb_33_431; // decl: <none>; prim: <none>
    logic [1:0] limb_33_432; // decl: <none>; prim: <none>
    logic limb_33_433; // decl: <none>; prim: <none>
    logic [64:0] limb_33_434; // decl: <none>; prim: <none>
    logic [63:0] limb_35_435; // decl: <none>; prim: <none>
    logic [63:0] limb_35_436; // decl: <none>; prim: <none>
    logic [63:0] limb_35_437; // decl: <none>; prim: <none>
    logic [64:0] limb_35_438; // decl: <none>; prim: <none>
    logic [63:0] limb_35_439; // decl: <none>; prim: <none>
    logic limb_35_440; // decl: <none>; prim: <none>
    logic limb_35_441; // decl: <none>; prim: <none>
    logic limb_35_442; // decl: <none>; prim: <none>
    logic limb_35_443; // decl: <none>; prim: <none>
    logic [1:0] limb_35_444; // decl: <none>; prim: <none>
    logic limb_35_445; // decl: <none>; prim: <none>
    logic [64:0] limb_35_446; // decl: <none>; prim: <none>
    logic [63:0] limb_37_447; // decl: <none>; prim: <none>
    logic [63:0] limb_37_448; // decl: <none>; prim: <none>
    logic [64:0] limb_37_449; // decl: <none>; prim: <none>
    logic [63:0] limb_37_450; // decl: <none>; prim: <none>
    logic limb_37_451; // decl: <none>; prim: <none>
    logic limb_37_452; // decl: <none>; prim: <none>
    logic limb_37_453; // decl: <none>; prim: <none>
    logic [1:0] limb_37_454; // decl: <none>; prim: <none>
    logic limb_37_455; // decl: <none>; prim: <none>
    logic [64:0] limb_37_456; // decl: <none>; prim: <none>
    logic [63:0] limb_38_457; // decl: <none>; prim: <none>
    logic [63:0] limb_38_458; // decl: <none>; prim: <none>
    logic [63:0] limb_38_459; // decl: <none>; prim: <none>
    logic [64:0] limb_38_460; // decl: <none>; prim: <none>
    logic [63:0] limb_38_461; // decl: <none>; prim: <none>
    logic limb_38_462; // decl: <none>; prim: <none>
    logic limb_38_463; // decl: <none>; prim: <none>
    logic limb_38_464; // decl: <none>; prim: <none>
    logic limb_38_465; // decl: <none>; prim: <none>
    logic [1:0] limb_38_466; // decl: <none>; prim: <none>
    logic limb_38_467; // decl: <none>; prim: <none>
    logic [64:0] limb_38_468; // decl: <none>; prim: <none>
    logic [63:0] limb_40_469; // decl: <none>; prim: <none>
    logic [63:0] limb_40_470; // decl: <none>; prim: <none>
    logic [63:0] limb_40_471; // decl: <none>; prim: <none>
    logic [64:0] limb_40_472; // decl: <none>; prim: <none>
    logic [63:0] limb_40_473; // decl: <none>; prim: <none>
    logic limb_40_474; // decl: <none>; prim: <none>
    logic limb_40_475; // decl: <none>; prim: <none>
    logic limb_40_476; // decl: <none>; prim: <none>
    logic limb_40_477; // decl: <none>; prim: <none>
    logic [1:0] limb_40_478; // decl: <none>; prim: <none>
    logic limb_40_479; // decl: <none>; prim: <none>
    logic [64:0] limb_40_480; // decl: <none>; prim: <none>
    logic [63:0] limb_44_481; // decl: <none>; prim: <none>
    logic [63:0] limb_44_482; // decl: <none>; prim: <none>
    logic [64:0] limb_44_483; // decl: <none>; prim: <none>
    logic [63:0] limb_44_484; // decl: <none>; prim: <none>
    logic limb_44_485; // decl: <none>; prim: <none>
    logic limb_44_486; // decl: <none>; prim: <none>
    logic limb_44_487; // decl: <none>; prim: <none>
    logic [1:0] limb_44_488; // decl: <none>; prim: <none>
    logic limb_44_489; // decl: <none>; prim: <none>
    logic [64:0] limb_44_490; // decl: <none>; prim: <none>
    logic [63:0] limb_46_491; // decl: <none>; prim: <none>
    logic [63:0] limb_46_492; // decl: <none>; prim: <none>
    logic [63:0] limb_46_493; // decl: <none>; prim: <none>
    logic [64:0] limb_46_494; // decl: <none>; prim: <none>
    logic [63:0] limb_46_495; // decl: <none>; prim: <none>
    logic limb_46_496; // decl: <none>; prim: <none>
    logic limb_46_497; // decl: <none>; prim: <none>
    logic limb_46_498; // decl: <none>; prim: <none>
    logic limb_46_499; // decl: <none>; prim: <none>
    logic [1:0] limb_46_500; // decl: <none>; prim: <none>
    logic limb_46_501; // decl: <none>; prim: <none>
    logic [64:0] limb_46_502; // decl: <none>; prim: <none>
    logic [63:0] limb_48_503; // decl: <none>; prim: <none>
    logic [63:0] limb_48_504; // decl: <none>; prim: <none>
    logic [64:0] limb_48_505; // decl: <none>; prim: <none>
    logic [63:0] limb_48_506; // decl: <none>; prim: <none>
    logic limb_48_507; // decl: <none>; prim: <none>
    logic limb_48_508; // decl: <none>; prim: <none>
    logic limb_48_509; // decl: <none>; prim: <none>
    logic [1:0] limb_48_510; // decl: <none>; prim: <none>
    logic limb_48_511; // decl: <none>; prim: <none>
    logic [64:0] limb_48_512; // decl: <none>; prim: <none>
    logic [63:0] limb_49_513; // decl: <none>; prim: <none>
    logic [63:0] limb_49_514; // decl: <none>; prim: <none>
    logic [63:0] limb_49_515; // decl: <none>; prim: <none>
    logic [64:0] limb_49_516; // decl: <none>; prim: <none>
    logic [63:0] limb_49_517; // decl: <none>; prim: <none>
    logic limb_49_518; // decl: <none>; prim: <none>
    logic limb_49_519; // decl: <none>; prim: <none>
    logic limb_49_520; // decl: <none>; prim: <none>
    logic limb_49_521; // decl: <none>; prim: <none>
    logic [1:0] limb_49_522; // decl: <none>; prim: <none>
    logic limb_49_523; // decl: <none>; prim: <none>
    logic [64:0] limb_49_524; // decl: <none>; prim: <none>
    logic [63:0] limb_51_525; // decl: <none>; prim: <none>
    logic [63:0] limb_51_526; // decl: <none>; prim: <none>
    logic [63:0] limb_51_527; // decl: <none>; prim: <none>
    logic [64:0] limb_51_528; // decl: <none>; prim: <none>
    logic [63:0] limb_51_529; // decl: <none>; prim: <none>
    logic limb_51_530; // decl: <none>; prim: <none>
    logic limb_51_531; // decl: <none>; prim: <none>
    logic limb_51_532; // decl: <none>; prim: <none>
    logic limb_51_533; // decl: <none>; prim: <none>
    logic [1:0] limb_51_534; // decl: <none>; prim: <none>
    logic limb_51_535; // decl: <none>; prim: <none>
    logic [64:0] limb_51_536; // decl: <none>; prim: <none>
    logic [63:0] limb_55_537; // decl: <none>; prim: <none>
    logic [63:0] limb_55_538; // decl: <none>; prim: <none>
    logic [64:0] limb_55_539; // decl: <none>; prim: <none>
    logic [63:0] limb_55_540; // decl: <none>; prim: <none>
    logic limb_55_541; // decl: <none>; prim: <none>
    logic limb_55_542; // decl: <none>; prim: <none>
    logic limb_55_543; // decl: <none>; prim: <none>
    logic [1:0] limb_55_544; // decl: <none>; prim: <none>
    logic limb_55_545; // decl: <none>; prim: <none>
    logic [64:0] limb_55_546; // decl: <none>; prim: <none>
    logic [63:0] limb_57_547; // decl: <none>; prim: <none>
    logic [63:0] limb_57_548; // decl: <none>; prim: <none>
    logic [63:0] limb_57_549; // decl: <none>; prim: <none>
    logic [64:0] limb_57_550; // decl: <none>; prim: <none>
    logic [63:0] limb_57_551; // decl: <none>; prim: <none>
    logic limb_57_552; // decl: <none>; prim: <none>
    logic limb_57_553; // decl: <none>; prim: <none>
    logic limb_57_554; // decl: <none>; prim: <none>
    logic limb_57_555; // decl: <none>; prim: <none>
    logic [1:0] limb_57_556; // decl: <none>; prim: <none>
    logic limb_57_557; // decl: <none>; prim: <none>
    logic [64:0] limb_57_558; // decl: <none>; prim: <none>
    logic [63:0] limb_59_559; // decl: <none>; prim: <none>
    logic [63:0] limb_59_560; // decl: <none>; prim: <none>
    logic [64:0] limb_59_561; // decl: <none>; prim: <none>
    logic [63:0] limb_59_562; // decl: <none>; prim: <none>
    logic limb_59_563; // decl: <none>; prim: <none>
    logic limb_59_564; // decl: <none>; prim: <none>
    logic limb_59_565; // decl: <none>; prim: <none>
    logic [1:0] limb_59_566; // decl: <none>; prim: <none>
    logic limb_59_567; // decl: <none>; prim: <none>
    logic [64:0] limb_59_568; // decl: <none>; prim: <none>
    logic [63:0] limb_60_569; // decl: <none>; prim: <none>
    logic [63:0] limb_60_570; // decl: <none>; prim: <none>
    logic [63:0] limb_60_571; // decl: <none>; prim: <none>
    logic [64:0] limb_60_572; // decl: <none>; prim: <none>
    logic [63:0] limb_60_573; // decl: <none>; prim: <none>
    logic limb_60_574; // decl: <none>; prim: <none>
    logic limb_60_575; // decl: <none>; prim: <none>
    logic limb_60_576; // decl: <none>; prim: <none>
    logic limb_60_577; // decl: <none>; prim: <none>
    logic [1:0] limb_60_578; // decl: <none>; prim: <none>
    logic limb_60_579; // decl: <none>; prim: <none>
    logic [64:0] limb_60_580; // decl: <none>; prim: <none>
    logic [63:0] limb_62_581; // decl: <none>; prim: <none>
    logic [63:0] limb_62_582; // decl: <none>; prim: <none>
    logic [63:0] limb_62_583; // decl: <none>; prim: <none>
    logic [64:0] limb_62_584; // decl: <none>; prim: <none>
    logic [63:0] limb_62_585; // decl: <none>; prim: <none>
    logic limb_62_586; // decl: <none>; prim: <none>
    logic limb_62_587; // decl: <none>; prim: <none>
    logic limb_62_588; // decl: <none>; prim: <none>
    logic limb_62_589; // decl: <none>; prim: <none>
    logic [1:0] limb_62_590; // decl: <none>; prim: <none>
    logic limb_62_591; // decl: <none>; prim: <none>
    logic [64:0] limb_62_592; // decl: <none>; prim: <none>
    logic [63:0] limb_72_593; // decl: <none>; prim: <none>
    logic [63:0] limb_72_594; // decl: <none>; prim: <none>
    logic [63:0] limb_72_595; // decl: <none>; prim: <none>
    logic [64:0] limb_72_596; // decl: <none>; prim: <none>
    logic [63:0] limb_72_597; // decl: <none>; prim: <none>
    logic limb_72_598; // decl: <none>; prim: <none>
    logic [63:0] limb_72_599; // decl: <none>; prim: <none>
    logic [63:0] limb_72_600; // decl: <none>; prim: <none>
    logic [63:0] limb_72_601; // decl: <none>; prim: <none>
    logic [64:0] limb_72_602; // decl: <none>; prim: <none>
    logic [63:0] limb_72_603; // decl: <none>; prim: <none>
    logic limb_72_604; // decl: <none>; prim: <none>
    logic limb_72_605; // decl: <none>; prim: <none>
    logic limb_72_606; // decl: <none>; prim: <none>
    logic limb_72_607; // decl: <none>; prim: <none>
    logic [1:0] limb_72_608; // decl: <none>; prim: <none>
    logic limb_72_609; // decl: <none>; prim: <none>
    logic [128:0] limb_72_610; // decl: <none>; prim: <none>
    logic [63:0] limb_74_611; // decl: <none>; prim: <none>
    logic [63:0] limb_74_612; // decl: <none>; prim: <none>
    logic [63:0] limb_74_613; // decl: <none>; prim: <none>
    logic [64:0] limb_74_614; // decl: <none>; prim: <none>
    logic [63:0] limb_74_615; // decl: <none>; prim: <none>
    logic limb_74_616; // decl: <none>; prim: <none>
    logic [63:0] limb_74_617; // decl: <none>; prim: <none>
    logic [63:0] limb_74_618; // decl: <none>; prim: <none>
    logic [63:0] limb_74_619; // decl: <none>; prim: <none>
    logic [64:0] limb_74_620; // decl: <none>; prim: <none>
    logic [63:0] limb_74_621; // decl: <none>; prim: <none>
    logic limb_74_622; // decl: <none>; prim: <none>
    logic limb_74_623; // decl: <none>; prim: <none>
    logic limb_74_624; // decl: <none>; prim: <none>
    logic limb_74_625; // decl: <none>; prim: <none>
    logic [1:0] limb_74_626; // decl: <none>; prim: <none>
    logic limb_74_627; // decl: <none>; prim: <none>
    logic [128:0] limb_74_628; // decl: <none>; prim: <none>
    logic [63:0] limb_78_629; // decl: <none>; prim: <none>
    logic [63:0] limb_78_630; // decl: <none>; prim: <none>
    logic [64:0] limb_78_631; // decl: <none>; prim: <none>
    logic [63:0] limb_78_632; // decl: <none>; prim: <none>
    logic limb_78_633; // decl: <none>; prim: <none>
    logic limb_78_634; // decl: <none>; prim: <none>
    logic limb_78_635; // decl: <none>; prim: <none>
    logic [1:0] limb_78_636; // decl: <none>; prim: <none>
    logic limb_78_637; // decl: <none>; prim: <none>
    logic [64:0] limb_78_638; // decl: <none>; prim: <none>
    logic [63:0] limb_80_639; // decl: <none>; prim: <none>
    logic [63:0] limb_80_640; // decl: <none>; prim: <none>
    logic [63:0] limb_80_641; // decl: <none>; prim: <none>
    logic [64:0] limb_80_642; // decl: <none>; prim: <none>
    logic [63:0] limb_80_643; // decl: <none>; prim: <none>
    logic limb_80_644; // decl: <none>; prim: <none>
    logic limb_80_645; // decl: <none>; prim: <none>
    logic limb_80_646; // decl: <none>; prim: <none>
    logic limb_80_647; // decl: <none>; prim: <none>
    logic [1:0] limb_80_648; // decl: <none>; prim: <none>
    logic limb_80_649; // decl: <none>; prim: <none>
    logic [64:0] limb_80_650; // decl: <none>; prim: <none>
    logic [63:0] limb_82_651; // decl: <none>; prim: <none>
    logic [63:0] limb_82_652; // decl: <none>; prim: <none>
    logic [64:0] limb_82_653; // decl: <none>; prim: <none>
    logic [63:0] limb_82_654; // decl: <none>; prim: <none>
    logic limb_82_655; // decl: <none>; prim: <none>
    logic limb_82_656; // decl: <none>; prim: <none>
    logic limb_82_657; // decl: <none>; prim: <none>
    logic [1:0] limb_82_658; // decl: <none>; prim: <none>
    logic limb_82_659; // decl: <none>; prim: <none>
    logic [64:0] limb_82_660; // decl: <none>; prim: <none>
    logic [63:0] limb_83_661; // decl: <none>; prim: <none>
    logic [63:0] limb_83_662; // decl: <none>; prim: <none>
    logic [63:0] limb_83_663; // decl: <none>; prim: <none>
    logic [64:0] limb_83_664; // decl: <none>; prim: <none>
    logic [63:0] limb_83_665; // decl: <none>; prim: <none>
    logic limb_83_666; // decl: <none>; prim: <none>
    logic limb_83_667; // decl: <none>; prim: <none>
    logic limb_83_668; // decl: <none>; prim: <none>
    logic limb_83_669; // decl: <none>; prim: <none>
    logic [1:0] limb_83_670; // decl: <none>; prim: <none>
    logic limb_83_671; // decl: <none>; prim: <none>
    logic [64:0] limb_83_672; // decl: <none>; prim: <none>
    logic [63:0] limb_85_673; // decl: <none>; prim: <none>
    logic [63:0] limb_85_674; // decl: <none>; prim: <none>
    logic [63:0] limb_85_675; // decl: <none>; prim: <none>
    logic [64:0] limb_85_676; // decl: <none>; prim: <none>
    logic [63:0] limb_85_677; // decl: <none>; prim: <none>
    logic limb_85_678; // decl: <none>; prim: <none>
    logic limb_85_679; // decl: <none>; prim: <none>
    logic limb_85_680; // decl: <none>; prim: <none>
    logic limb_85_681; // decl: <none>; prim: <none>
    logic [1:0] limb_85_682; // decl: <none>; prim: <none>
    logic limb_85_683; // decl: <none>; prim: <none>
    logic [64:0] limb_85_684; // decl: <none>; prim: <none>
    logic [63:0] limb_89_685; // decl: <none>; prim: <none>
    logic [63:0] limb_89_686; // decl: <none>; prim: <none>
    logic [64:0] limb_89_687; // decl: <none>; prim: <none>
    logic [63:0] limb_89_688; // decl: <none>; prim: <none>
    logic limb_89_689; // decl: <none>; prim: <none>
    logic limb_89_690; // decl: <none>; prim: <none>
    logic limb_89_691; // decl: <none>; prim: <none>
    logic [1:0] limb_89_692; // decl: <none>; prim: <none>
    logic limb_89_693; // decl: <none>; prim: <none>
    logic [64:0] limb_89_694; // decl: <none>; prim: <none>
    logic [63:0] limb_91_695; // decl: <none>; prim: <none>
    logic [63:0] limb_91_696; // decl: <none>; prim: <none>
    logic [63:0] limb_91_697; // decl: <none>; prim: <none>
    logic [64:0] limb_91_698; // decl: <none>; prim: <none>
    logic [63:0] limb_91_699; // decl: <none>; prim: <none>
    logic limb_91_700; // decl: <none>; prim: <none>
    logic limb_91_701; // decl: <none>; prim: <none>
    logic limb_91_702; // decl: <none>; prim: <none>
    logic limb_91_703; // decl: <none>; prim: <none>
    logic [1:0] limb_91_704; // decl: <none>; prim: <none>
    logic limb_91_705; // decl: <none>; prim: <none>
    logic [64:0] limb_91_706; // decl: <none>; prim: <none>
    logic [63:0] limb_93_707; // decl: <none>; prim: <none>
    logic [63:0] limb_93_708; // decl: <none>; prim: <none>
    logic [64:0] limb_93_709; // decl: <none>; prim: <none>
    logic [63:0] limb_93_710; // decl: <none>; prim: <none>
    logic limb_93_711; // decl: <none>; prim: <none>
    logic limb_93_712; // decl: <none>; prim: <none>
    logic limb_93_713; // decl: <none>; prim: <none>
    logic [1:0] limb_93_714; // decl: <none>; prim: <none>
    logic limb_93_715; // decl: <none>; prim: <none>
    logic [64:0] limb_93_716; // decl: <none>; prim: <none>
    logic [63:0] limb_94_717; // decl: <none>; prim: <none>
    logic [63:0] limb_94_718; // decl: <none>; prim: <none>
    logic [63:0] limb_94_719; // decl: <none>; prim: <none>
    logic [64:0] limb_94_720; // decl: <none>; prim: <none>
    logic [63:0] limb_94_721; // decl: <none>; prim: <none>
    logic limb_94_722; // decl: <none>; prim: <none>
    logic limb_94_723; // decl: <none>; prim: <none>
    logic limb_94_724; // decl: <none>; prim: <none>
    logic limb_94_725; // decl: <none>; prim: <none>
    logic [1:0] limb_94_726; // decl: <none>; prim: <none>
    logic limb_94_727; // decl: <none>; prim: <none>
    logic [64:0] limb_94_728; // decl: <none>; prim: <none>
    logic [63:0] limb_96_729; // decl: <none>; prim: <none>
    logic [63:0] limb_96_730; // decl: <none>; prim: <none>
    logic [63:0] limb_96_731; // decl: <none>; prim: <none>
    logic [64:0] limb_96_732; // decl: <none>; prim: <none>
    logic [63:0] limb_96_733; // decl: <none>; prim: <none>
    logic limb_96_734; // decl: <none>; prim: <none>
    logic limb_96_735; // decl: <none>; prim: <none>
    logic limb_96_736; // decl: <none>; prim: <none>
    logic limb_96_737; // decl: <none>; prim: <none>
    logic [1:0] limb_96_738; // decl: <none>; prim: <none>
    logic limb_96_739; // decl: <none>; prim: <none>
    logic [64:0] limb_96_740; // decl: <none>; prim: <none>
    logic [63:0] limb_106_741; // decl: <none>; prim: <none>
    logic [63:0] limb_106_742; // decl: <none>; prim: <none>
    logic [63:0] limb_106_743; // decl: <none>; prim: <none>
    logic [64:0] limb_106_744; // decl: <none>; prim: <none>
    logic [63:0] limb_106_745; // decl: <none>; prim: <none>
    logic limb_106_746; // decl: <none>; prim: <none>
    logic [63:0] limb_106_747; // decl: <none>; prim: <none>
    logic [63:0] limb_106_748; // decl: <none>; prim: <none>
    logic [63:0] limb_106_749; // decl: <none>; prim: <none>
    logic [64:0] limb_106_750; // decl: <none>; prim: <none>
    logic [63:0] limb_106_751; // decl: <none>; prim: <none>
    logic limb_106_752; // decl: <none>; prim: <none>
    logic limb_106_753; // decl: <none>; prim: <none>
    logic limb_106_754; // decl: <none>; prim: <none>
    logic limb_106_755; // decl: <none>; prim: <none>
    logic [1:0] limb_106_756; // decl: <none>; prim: <none>
    logic limb_106_757; // decl: <none>; prim: <none>
    logic [128:0] limb_106_758; // decl: <none>; prim: <none>
    logic [63:0] limb_108_759; // decl: <none>; prim: <none>
    logic [63:0] limb_108_760; // decl: <none>; prim: <none>
    logic [63:0] limb_108_761; // decl: <none>; prim: <none>
    logic [64:0] limb_108_762; // decl: <none>; prim: <none>
    logic [63:0] limb_108_763; // decl: <none>; prim: <none>
    logic limb_108_764; // decl: <none>; prim: <none>
    logic [63:0] limb_108_765; // decl: <none>; prim: <none>
    logic [63:0] limb_108_766; // decl: <none>; prim: <none>
    logic [63:0] limb_108_767; // decl: <none>; prim: <none>
    logic [64:0] limb_108_768; // decl: <none>; prim: <none>
    logic [63:0] limb_108_769; // decl: <none>; prim: <none>
    logic limb_108_770; // decl: <none>; prim: <none>
    logic limb_108_771; // decl: <none>; prim: <none>
    logic limb_108_772; // decl: <none>; prim: <none>
    logic limb_108_773; // decl: <none>; prim: <none>
    logic [1:0] limb_108_774; // decl: <none>; prim: <none>
    logic limb_108_775; // decl: <none>; prim: <none>
    logic [128:0] limb_108_776; // decl: <none>; prim: <none>
    logic [63:0] limb_112_777; // decl: <none>; prim: <none>
    logic [63:0] limb_112_778; // decl: <none>; prim: <none>
    logic [64:0] limb_112_779; // decl: <none>; prim: <none>
    logic [63:0] limb_112_780; // decl: <none>; prim: <none>
    logic limb_112_781; // decl: <none>; prim: <none>
    logic limb_112_782; // decl: <none>; prim: <none>
    logic limb_112_783; // decl: <none>; prim: <none>
    logic [1:0] limb_112_784; // decl: <none>; prim: <none>
    logic limb_112_785; // decl: <none>; prim: <none>
    logic [64:0] limb_112_786; // decl: <none>; prim: <none>
    logic [63:0] limb_114_787; // decl: <none>; prim: <none>
    logic [63:0] limb_114_788; // decl: <none>; prim: <none>
    logic [63:0] limb_114_789; // decl: <none>; prim: <none>
    logic [64:0] limb_114_790; // decl: <none>; prim: <none>
    logic [63:0] limb_114_791; // decl: <none>; prim: <none>
    logic limb_114_792; // decl: <none>; prim: <none>
    logic limb_114_793; // decl: <none>; prim: <none>
    logic limb_114_794; // decl: <none>; prim: <none>
    logic limb_114_795; // decl: <none>; prim: <none>
    logic [1:0] limb_114_796; // decl: <none>; prim: <none>
    logic limb_114_797; // decl: <none>; prim: <none>
    logic [64:0] limb_114_798; // decl: <none>; prim: <none>
    logic [63:0] limb_116_799; // decl: <none>; prim: <none>
    logic [63:0] limb_116_800; // decl: <none>; prim: <none>
    logic [64:0] limb_116_801; // decl: <none>; prim: <none>
    logic [63:0] limb_116_802; // decl: <none>; prim: <none>
    logic limb_116_803; // decl: <none>; prim: <none>
    logic limb_116_804; // decl: <none>; prim: <none>
    logic limb_116_805; // decl: <none>; prim: <none>
    logic [1:0] limb_116_806; // decl: <none>; prim: <none>
    logic limb_116_807; // decl: <none>; prim: <none>
    logic [64:0] limb_116_808; // decl: <none>; prim: <none>
    logic [63:0] limb_117_809; // decl: <none>; prim: <none>
    logic [63:0] limb_117_810; // decl: <none>; prim: <none>
    logic [63:0] limb_117_811; // decl: <none>; prim: <none>
    logic [64:0] limb_117_812; // decl: <none>; prim: <none>
    logic [63:0] limb_117_813; // decl: <none>; prim: <none>
    logic limb_117_814; // decl: <none>; prim: <none>
    logic limb_117_815; // decl: <none>; prim: <none>
    logic limb_117_816; // decl: <none>; prim: <none>
    logic limb_117_817; // decl: <none>; prim: <none>
    logic [1:0] limb_117_818; // decl: <none>; prim: <none>
    logic limb_117_819; // decl: <none>; prim: <none>
    logic [64:0] limb_117_820; // decl: <none>; prim: <none>
    logic [63:0] limb_119_821; // decl: <none>; prim: <none>
    logic [63:0] limb_119_822; // decl: <none>; prim: <none>
    logic [63:0] limb_119_823; // decl: <none>; prim: <none>
    logic [64:0] limb_119_824; // decl: <none>; prim: <none>
    logic [63:0] limb_119_825; // decl: <none>; prim: <none>
    logic limb_119_826; // decl: <none>; prim: <none>
    logic limb_119_827; // decl: <none>; prim: <none>
    logic limb_119_828; // decl: <none>; prim: <none>
    logic limb_119_829; // decl: <none>; prim: <none>
    logic [1:0] limb_119_830; // decl: <none>; prim: <none>
    logic limb_119_831; // decl: <none>; prim: <none>
    logic [64:0] limb_119_832; // decl: <none>; prim: <none>
    logic [63:0] limb_123_833; // decl: <none>; prim: <none>
    logic [63:0] limb_123_834; // decl: <none>; prim: <none>
    logic [64:0] limb_123_835; // decl: <none>; prim: <none>
    logic [63:0] limb_123_836; // decl: <none>; prim: <none>
    logic limb_123_837; // decl: <none>; prim: <none>
    logic limb_123_838; // decl: <none>; prim: <none>
    logic limb_123_839; // decl: <none>; prim: <none>
    logic [1:0] limb_123_840; // decl: <none>; prim: <none>
    logic limb_123_841; // decl: <none>; prim: <none>
    logic [64:0] limb_123_842; // decl: <none>; prim: <none>
    logic [63:0] limb_125_843; // decl: <none>; prim: <none>
    logic [63:0] limb_125_844; // decl: <none>; prim: <none>
    logic [63:0] limb_125_845; // decl: <none>; prim: <none>
    logic [64:0] limb_125_846; // decl: <none>; prim: <none>
    logic [63:0] limb_125_847; // decl: <none>; prim: <none>
    logic limb_125_848; // decl: <none>; prim: <none>
    logic limb_125_849; // decl: <none>; prim: <none>
    logic limb_125_850; // decl: <none>; prim: <none>
    logic limb_125_851; // decl: <none>; prim: <none>
    logic [1:0] limb_125_852; // decl: <none>; prim: <none>
    logic limb_125_853; // decl: <none>; prim: <none>
    logic [64:0] limb_125_854; // decl: <none>; prim: <none>
    logic [63:0] limb_127_855; // decl: <none>; prim: <none>
    logic [63:0] limb_127_856; // decl: <none>; prim: <none>
    logic [64:0] limb_127_857; // decl: <none>; prim: <none>
    logic [63:0] limb_127_858; // decl: <none>; prim: <none>
    logic limb_127_859; // decl: <none>; prim: <none>
    logic limb_127_860; // decl: <none>; prim: <none>
    logic limb_127_861; // decl: <none>; prim: <none>
    logic [1:0] limb_127_862; // decl: <none>; prim: <none>
    logic limb_127_863; // decl: <none>; prim: <none>
    logic [64:0] limb_127_864; // decl: <none>; prim: <none>
    logic [63:0] limb_128_865; // decl: <none>; prim: <none>
    logic [63:0] limb_128_866; // decl: <none>; prim: <none>
    logic [63:0] limb_128_867; // decl: <none>; prim: <none>
    logic [64:0] limb_128_868; // decl: <none>; prim: <none>
    logic [63:0] limb_128_869; // decl: <none>; prim: <none>
    logic limb_128_870; // decl: <none>; prim: <none>
    logic limb_128_871; // decl: <none>; prim: <none>
    logic limb_128_872; // decl: <none>; prim: <none>
    logic limb_128_873; // decl: <none>; prim: <none>
    logic [1:0] limb_128_874; // decl: <none>; prim: <none>
    logic limb_128_875; // decl: <none>; prim: <none>
    logic [64:0] limb_128_876; // decl: <none>; prim: <none>
    logic [63:0] limb_130_877; // decl: <none>; prim: <none>
    logic [63:0] limb_130_878; // decl: <none>; prim: <none>
    logic [63:0] limb_130_879; // decl: <none>; prim: <none>
    logic [64:0] limb_130_880; // decl: <none>; prim: <none>
    logic [63:0] limb_130_881; // decl: <none>; prim: <none>
    logic limb_130_882; // decl: <none>; prim: <none>
    logic limb_130_883; // decl: <none>; prim: <none>
    logic limb_130_884; // decl: <none>; prim: <none>
    logic limb_130_885; // decl: <none>; prim: <none>
    logic [1:0] limb_130_886; // decl: <none>; prim: <none>
    logic limb_130_887; // decl: <none>; prim: <none>
    logic [64:0] limb_130_888; // decl: <none>; prim: <none>
    logic [63:0] limb_142_889; // decl: <none>; prim: <none>
    logic [63:0] limb_142_890; // decl: <none>; prim: <none>
    logic [63:0] limb_142_891; // decl: <none>; prim: <none>
    logic [64:0] limb_142_892; // decl: <none>; prim: <none>
    logic [63:0] limb_142_893; // decl: <none>; prim: <none>
    logic limb_142_894; // decl: <none>; prim: <none>
    logic [63:0] limb_142_895; // decl: <none>; prim: <none>
    logic [63:0] limb_142_896; // decl: <none>; prim: <none>
    logic [63:0] limb_142_897; // decl: <none>; prim: <none>
    logic [64:0] limb_142_898; // decl: <none>; prim: <none>
    logic [63:0] limb_142_899; // decl: <none>; prim: <none>
    logic limb_142_900; // decl: <none>; prim: <none>
    logic limb_142_901; // decl: <none>; prim: <none>
    logic limb_142_902; // decl: <none>; prim: <none>
    logic limb_142_903; // decl: <none>; prim: <none>
    logic [1:0] limb_142_904; // decl: <none>; prim: <none>
    logic limb_142_905; // decl: <none>; prim: <none>
    logic [128:0] limb_142_906; // decl: <none>; prim: <none>
    logic [63:0] limb_144_907; // decl: <none>; prim: <none>
    logic [63:0] limb_144_908; // decl: <none>; prim: <none>
    logic [63:0] limb_144_909; // decl: <none>; prim: <none>
    logic [64:0] limb_144_910; // decl: <none>; prim: <none>
    logic [63:0] limb_144_911; // decl: <none>; prim: <none>
    logic limb_144_912; // decl: <none>; prim: <none>
    logic [63:0] limb_144_913; // decl: <none>; prim: <none>
    logic [63:0] limb_144_914; // decl: <none>; prim: <none>
    logic [63:0] limb_144_915; // decl: <none>; prim: <none>
    logic [64:0] limb_144_916; // decl: <none>; prim: <none>
    logic [63:0] limb_144_917; // decl: <none>; prim: <none>
    logic limb_144_918; // decl: <none>; prim: <none>
    logic limb_144_919; // decl: <none>; prim: <none>
    logic limb_144_920; // decl: <none>; prim: <none>
    logic limb_144_921; // decl: <none>; prim: <none>
    logic [1:0] limb_144_922; // decl: <none>; prim: <none>
    logic limb_144_923; // decl: <none>; prim: <none>
    logic [128:0] limb_144_924; // decl: <none>; prim: <none>
    logic [63:0] limb_148_925; // decl: <none>; prim: <none>
    logic [63:0] limb_148_926; // decl: <none>; prim: <none>
    logic [64:0] limb_148_927; // decl: <none>; prim: <none>
    logic [63:0] limb_148_928; // decl: <none>; prim: <none>
    logic limb_148_929; // decl: <none>; prim: <none>
    logic limb_148_930; // decl: <none>; prim: <none>
    logic limb_148_931; // decl: <none>; prim: <none>
    logic [1:0] limb_148_932; // decl: <none>; prim: <none>
    logic limb_148_933; // decl: <none>; prim: <none>
    logic [64:0] limb_148_934; // decl: <none>; prim: <none>
    logic [63:0] limb_150_935; // decl: <none>; prim: <none>
    logic [63:0] limb_150_936; // decl: <none>; prim: <none>
    logic [63:0] limb_150_937; // decl: <none>; prim: <none>
    logic [64:0] limb_150_938; // decl: <none>; prim: <none>
    logic [63:0] limb_150_939; // decl: <none>; prim: <none>
    logic limb_150_940; // decl: <none>; prim: <none>
    logic limb_150_941; // decl: <none>; prim: <none>
    logic limb_150_942; // decl: <none>; prim: <none>
    logic limb_150_943; // decl: <none>; prim: <none>
    logic [1:0] limb_150_944; // decl: <none>; prim: <none>
    logic limb_150_945; // decl: <none>; prim: <none>
    logic [64:0] limb_150_946; // decl: <none>; prim: <none>
    logic [63:0] limb_152_947; // decl: <none>; prim: <none>
    logic [63:0] limb_152_948; // decl: <none>; prim: <none>
    logic [64:0] limb_152_949; // decl: <none>; prim: <none>
    logic [63:0] limb_152_950; // decl: <none>; prim: <none>
    logic limb_152_951; // decl: <none>; prim: <none>
    logic limb_152_952; // decl: <none>; prim: <none>
    logic limb_152_953; // decl: <none>; prim: <none>
    logic [1:0] limb_152_954; // decl: <none>; prim: <none>
    logic limb_152_955; // decl: <none>; prim: <none>
    logic [64:0] limb_152_956; // decl: <none>; prim: <none>
    logic [63:0] limb_153_957; // decl: <none>; prim: <none>
    logic [63:0] limb_153_958; // decl: <none>; prim: <none>
    logic [63:0] limb_153_959; // decl: <none>; prim: <none>
    logic [64:0] limb_153_960; // decl: <none>; prim: <none>
    logic [63:0] limb_153_961; // decl: <none>; prim: <none>
    logic limb_153_962; // decl: <none>; prim: <none>
    logic limb_153_963; // decl: <none>; prim: <none>
    logic limb_153_964; // decl: <none>; prim: <none>
    logic limb_153_965; // decl: <none>; prim: <none>
    logic [1:0] limb_153_966; // decl: <none>; prim: <none>
    logic limb_153_967; // decl: <none>; prim: <none>
    logic [64:0] limb_153_968; // decl: <none>; prim: <none>
    logic [63:0] limb_155_969; // decl: <none>; prim: <none>
    logic [63:0] limb_155_970; // decl: <none>; prim: <none>
    logic [63:0] limb_155_971; // decl: <none>; prim: <none>
    logic [64:0] limb_155_972; // decl: <none>; prim: <none>
    logic [63:0] limb_155_973; // decl: <none>; prim: <none>
    logic limb_155_974; // decl: <none>; prim: <none>
    logic limb_155_975; // decl: <none>; prim: <none>
    logic limb_155_976; // decl: <none>; prim: <none>
    logic limb_155_977; // decl: <none>; prim: <none>
    logic [1:0] limb_155_978; // decl: <none>; prim: <none>
    logic limb_155_979; // decl: <none>; prim: <none>
    logic [64:0] limb_155_980; // decl: <none>; prim: <none>
    logic [63:0] limb_167_981; // decl: <none>; prim: <none>
    logic [63:0] limb_167_982; // decl: <none>; prim: <none>
    logic [63:0] limb_167_983; // decl: <none>; prim: <none>
    logic [64:0] limb_167_984; // decl: <none>; prim: <none>
    logic [63:0] limb_167_985; // decl: <none>; prim: <none>
    logic limb_167_986; // decl: <none>; prim: <none>
    logic [63:0] limb_167_987; // decl: <none>; prim: <none>
    logic [63:0] limb_167_988; // decl: <none>; prim: <none>
    logic [63:0] limb_167_989; // decl: <none>; prim: <none>
    logic [64:0] limb_167_990; // decl: <none>; prim: <none>
    logic [63:0] limb_167_991; // decl: <none>; prim: <none>
    logic limb_167_992; // decl: <none>; prim: <none>
    logic limb_167_993; // decl: <none>; prim: <none>
    logic limb_167_994; // decl: <none>; prim: <none>
    logic limb_167_995; // decl: <none>; prim: <none>
    logic [1:0] limb_167_996; // decl: <none>; prim: <none>
    logic limb_167_997; // decl: <none>; prim: <none>
    logic [128:0] limb_167_998; // decl: <none>; prim: <none>
    logic [63:0] limb_169_999; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1000; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1001; // decl: <none>; prim: <none>
    logic [64:0] limb_169_1002; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1003; // decl: <none>; prim: <none>
    logic limb_169_1004; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1005; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1006; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1007; // decl: <none>; prim: <none>
    logic [64:0] limb_169_1008; // decl: <none>; prim: <none>
    logic [63:0] limb_169_1009; // decl: <none>; prim: <none>
    logic limb_169_1010; // decl: <none>; prim: <none>
    logic limb_169_1011; // decl: <none>; prim: <none>
    logic limb_169_1012; // decl: <none>; prim: <none>
    logic limb_169_1013; // decl: <none>; prim: <none>
    logic [1:0] limb_169_1014; // decl: <none>; prim: <none>
    logic limb_169_1015; // decl: <none>; prim: <none>
    logic [128:0] limb_169_1016; // decl: <none>; prim: <none>
    logic [63:0] limb_173_1017; // decl: <none>; prim: <none>
    logic [63:0] limb_173_1018; // decl: <none>; prim: <none>
    logic [64:0] limb_173_1019; // decl: <none>; prim: <none>
    logic [63:0] limb_173_1020; // decl: <none>; prim: <none>
    logic limb_173_1021; // decl: <none>; prim: <none>
    logic limb_173_1022; // decl: <none>; prim: <none>
    logic limb_173_1023; // decl: <none>; prim: <none>
    logic [1:0] limb_173_1024; // decl: <none>; prim: <none>
    logic limb_173_1025; // decl: <none>; prim: <none>
    logic [64:0] limb_173_1026; // decl: <none>; prim: <none>
    logic [63:0] limb_175_1027; // decl: <none>; prim: <none>
    logic [63:0] limb_175_1028; // decl: <none>; prim: <none>
    logic [63:0] limb_175_1029; // decl: <none>; prim: <none>
    logic [64:0] limb_175_1030; // decl: <none>; prim: <none>
    logic [63:0] limb_175_1031; // decl: <none>; prim: <none>
    logic limb_175_1032; // decl: <none>; prim: <none>
    logic limb_175_1033; // decl: <none>; prim: <none>
    logic limb_175_1034; // decl: <none>; prim: <none>
    logic limb_175_1035; // decl: <none>; prim: <none>
    logic [1:0] limb_175_1036; // decl: <none>; prim: <none>
    logic limb_175_1037; // decl: <none>; prim: <none>
    logic [64:0] limb_175_1038; // decl: <none>; prim: <none>
    logic [63:0] limb_177_1039; // decl: <none>; prim: <none>
    logic [63:0] limb_177_1040; // decl: <none>; prim: <none>
    logic [64:0] limb_177_1041; // decl: <none>; prim: <none>
    logic [63:0] limb_177_1042; // decl: <none>; prim: <none>
    logic limb_177_1043; // decl: <none>; prim: <none>
    logic limb_177_1044; // decl: <none>; prim: <none>
    logic limb_177_1045; // decl: <none>; prim: <none>
    logic [1:0] limb_177_1046; // decl: <none>; prim: <none>
    logic limb_177_1047; // decl: <none>; prim: <none>
    logic [64:0] limb_177_1048; // decl: <none>; prim: <none>
    logic [63:0] limb_178_1049; // decl: <none>; prim: <none>
    logic [63:0] limb_178_1050; // decl: <none>; prim: <none>
    logic [63:0] limb_178_1051; // decl: <none>; prim: <none>
    logic [64:0] limb_178_1052; // decl: <none>; prim: <none>
    logic [63:0] limb_178_1053; // decl: <none>; prim: <none>
    logic limb_178_1054; // decl: <none>; prim: <none>
    logic limb_178_1055; // decl: <none>; prim: <none>
    logic limb_178_1056; // decl: <none>; prim: <none>
    logic limb_178_1057; // decl: <none>; prim: <none>
    logic [1:0] limb_178_1058; // decl: <none>; prim: <none>
    logic limb_178_1059; // decl: <none>; prim: <none>
    logic [64:0] limb_178_1060; // decl: <none>; prim: <none>
    logic [63:0] limb_180_1061; // decl: <none>; prim: <none>
    logic [63:0] limb_180_1062; // decl: <none>; prim: <none>
    logic [63:0] limb_180_1063; // decl: <none>; prim: <none>
    logic [64:0] limb_180_1064; // decl: <none>; prim: <none>
    logic [63:0] limb_180_1065; // decl: <none>; prim: <none>
    logic limb_180_1066; // decl: <none>; prim: <none>
    logic limb_180_1067; // decl: <none>; prim: <none>
    logic limb_180_1068; // decl: <none>; prim: <none>
    logic limb_180_1069; // decl: <none>; prim: <none>
    logic [1:0] limb_180_1070; // decl: <none>; prim: <none>
    logic limb_180_1071; // decl: <none>; prim: <none>
    logic [64:0] limb_180_1072; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1073; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1074; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1075; // decl: <none>; prim: <none>
    logic [64:0] limb_192_1076; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1077; // decl: <none>; prim: <none>
    logic limb_192_1078; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1079; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1080; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1081; // decl: <none>; prim: <none>
    logic [64:0] limb_192_1082; // decl: <none>; prim: <none>
    logic [63:0] limb_192_1083; // decl: <none>; prim: <none>
    logic limb_192_1084; // decl: <none>; prim: <none>
    logic limb_192_1085; // decl: <none>; prim: <none>
    logic limb_192_1086; // decl: <none>; prim: <none>
    logic limb_192_1087; // decl: <none>; prim: <none>
    logic [1:0] limb_192_1088; // decl: <none>; prim: <none>
    logic limb_192_1089; // decl: <none>; prim: <none>
    logic [128:0] limb_192_1090; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1091; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1092; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1093; // decl: <none>; prim: <none>
    logic [64:0] limb_194_1094; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1095; // decl: <none>; prim: <none>
    logic limb_194_1096; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1097; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1098; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1099; // decl: <none>; prim: <none>
    logic [64:0] limb_194_1100; // decl: <none>; prim: <none>
    logic [63:0] limb_194_1101; // decl: <none>; prim: <none>
    logic limb_194_1102; // decl: <none>; prim: <none>
    logic limb_194_1103; // decl: <none>; prim: <none>
    logic limb_194_1104; // decl: <none>; prim: <none>
    logic limb_194_1105; // decl: <none>; prim: <none>
    logic [1:0] limb_194_1106; // decl: <none>; prim: <none>
    logic limb_194_1107; // decl: <none>; prim: <none>
    logic [128:0] limb_194_1108; // decl: <none>; prim: <none>
    logic [63:0] limb_198_1109; // decl: <none>; prim: <none>
    logic [63:0] limb_198_1110; // decl: <none>; prim: <none>
    logic [64:0] limb_198_1111; // decl: <none>; prim: <none>
    logic [63:0] limb_198_1112; // decl: <none>; prim: <none>
    logic limb_198_1113; // decl: <none>; prim: <none>
    logic limb_198_1114; // decl: <none>; prim: <none>
    logic limb_198_1115; // decl: <none>; prim: <none>
    logic [1:0] limb_198_1116; // decl: <none>; prim: <none>
    logic limb_198_1117; // decl: <none>; prim: <none>
    logic [64:0] limb_198_1118; // decl: <none>; prim: <none>
    logic [63:0] limb_200_1119; // decl: <none>; prim: <none>
    logic [63:0] limb_200_1120; // decl: <none>; prim: <none>
    logic [63:0] limb_200_1121; // decl: <none>; prim: <none>
    logic [64:0] limb_200_1122; // decl: <none>; prim: <none>
    logic [63:0] limb_200_1123; // decl: <none>; prim: <none>
    logic limb_200_1124; // decl: <none>; prim: <none>
    logic limb_200_1125; // decl: <none>; prim: <none>
    logic limb_200_1126; // decl: <none>; prim: <none>
    logic limb_200_1127; // decl: <none>; prim: <none>
    logic [1:0] limb_200_1128; // decl: <none>; prim: <none>
    logic limb_200_1129; // decl: <none>; prim: <none>
    logic [64:0] limb_200_1130; // decl: <none>; prim: <none>
    logic [63:0] limb_202_1131; // decl: <none>; prim: <none>
    logic [63:0] limb_202_1132; // decl: <none>; prim: <none>
    logic [64:0] limb_202_1133; // decl: <none>; prim: <none>
    logic [63:0] limb_202_1134; // decl: <none>; prim: <none>
    logic limb_202_1135; // decl: <none>; prim: <none>
    logic limb_202_1136; // decl: <none>; prim: <none>
    logic limb_202_1137; // decl: <none>; prim: <none>
    logic [1:0] limb_202_1138; // decl: <none>; prim: <none>
    logic limb_202_1139; // decl: <none>; prim: <none>
    logic [64:0] limb_202_1140; // decl: <none>; prim: <none>
    logic [63:0] limb_203_1141; // decl: <none>; prim: <none>
    logic [63:0] limb_203_1142; // decl: <none>; prim: <none>
    logic [63:0] limb_203_1143; // decl: <none>; prim: <none>
    logic [64:0] limb_203_1144; // decl: <none>; prim: <none>
    logic [63:0] limb_203_1145; // decl: <none>; prim: <none>
    logic limb_203_1146; // decl: <none>; prim: <none>
    logic limb_203_1147; // decl: <none>; prim: <none>
    logic limb_203_1148; // decl: <none>; prim: <none>
    logic limb_203_1149; // decl: <none>; prim: <none>
    logic [1:0] limb_203_1150; // decl: <none>; prim: <none>
    logic limb_203_1151; // decl: <none>; prim: <none>
    logic [64:0] limb_203_1152; // decl: <none>; prim: <none>
    logic [63:0] limb_205_1153; // decl: <none>; prim: <none>
    logic [63:0] limb_205_1154; // decl: <none>; prim: <none>
    logic [63:0] limb_205_1155; // decl: <none>; prim: <none>
    logic [64:0] limb_205_1156; // decl: <none>; prim: <none>
    logic [63:0] limb_205_1157; // decl: <none>; prim: <none>
    logic limb_205_1158; // decl: <none>; prim: <none>
    logic limb_205_1159; // decl: <none>; prim: <none>
    logic limb_205_1160; // decl: <none>; prim: <none>
    logic limb_205_1161; // decl: <none>; prim: <none>
    logic [1:0] limb_205_1162; // decl: <none>; prim: <none>
    logic limb_205_1163; // decl: <none>; prim: <none>
    logic [64:0] limb_205_1164; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_316_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_317_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_318_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_319_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [63:0] rtlzz_pipe_323_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_327_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_329_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_329_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_329_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_13_s5; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_14_s6; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    logic [63:0] rtlzz_pipe_335_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_338_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_339_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_340_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_345_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_345_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_346_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_347_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_349_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_349_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_350_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_350_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_351_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_351_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_351_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_351_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_352_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_353_s12; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_16_s13; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic [64:0] rtlzz_pipe_16_s14; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic [64:0] rtlzz_pipe_16_s15; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic rtlzz_pipe_17_s14; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic rtlzz_pipe_17_s15; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [63:0] rtlzz_pipe_357_s13; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_357_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_363_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_363_s14; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_18_s15; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [63:0] rtlzz_pipe_372_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_373_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_374_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_375_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_22_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic rtlzz_pipe_23_s3; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s4; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s5; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [63:0] rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_379_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_383_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_384_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_385_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_385_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_24_s5; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_25_s6; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    logic [63:0] rtlzz_pipe_391_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_391_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_394_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_395_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_396_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_401_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_401_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_402_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_403_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_405_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_405_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_406_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_406_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_407_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_408_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_409_s12; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_27_s13; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic [64:0] rtlzz_pipe_27_s14; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic rtlzz_pipe_28_s13; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic rtlzz_pipe_28_s14; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [63:0] rtlzz_pipe_413_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_419_s13; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_29_s14; // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [128:0] rtlzz_pipe_221_s15; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_256_s15; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_428_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_429_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_430_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_431_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_33_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s5; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic rtlzz_pipe_34_s3; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s4; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s5; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [63:0] rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_435_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_439_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_440_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_441_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_441_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_35_s5; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_36_s6; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [63:0] rtlzz_pipe_447_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_447_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_450_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_451_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_452_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_457_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_457_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_458_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_459_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_461_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_462_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_463_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_463_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_463_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_464_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_38_s12; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic [64:0] rtlzz_pipe_38_s13; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic rtlzz_pipe_39_s13; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [63:0] rtlzz_pipe_473_s12; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_473_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_474_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_474_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_475_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_475_s13; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_484_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_485_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_486_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_487_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_44_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic rtlzz_pipe_45_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s4; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [63:0] rtlzz_pipe_491_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_491_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_495_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_496_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_497_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_497_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_497_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_46_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_47_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
    logic [63:0] rtlzz_pipe_503_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_503_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_506_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_507_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_508_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_513_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_513_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_514_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_515_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_519_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_519_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_521_s10; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_49_s11; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [64:0] rtlzz_pipe_49_s12; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [63:0] rtlzz_pipe_529_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_530_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_531_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_51_s12; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [63:0] rtlzz_pipe_262_s13; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_224_s14; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_226_s14; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_226_s15; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_268_s15; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_540_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_541_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_542_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_543_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_55_s8; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic [64:0] rtlzz_pipe_55_s9; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic rtlzz_pipe_56_s8; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic rtlzz_pipe_56_s9; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [63:0] rtlzz_pipe_547_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_553_s8; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_57_s9; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [63:0] rtlzz_pipe_569_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_569_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_570_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_573_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_573_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_574_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_574_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_575_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_577_s10; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_60_s11; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [64:0] rtlzz_pipe_60_s12; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic rtlzz_pipe_61_s11; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic rtlzz_pipe_61_s12; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [63:0] rtlzz_pipe_581_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_587_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_62_s12; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] rtlzz_pipe_63_s13; // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
    logic [63:0] rtlzz_pipe_688_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_689_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_690_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_691_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_89_s8; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [64:0] rtlzz_pipe_89_s9; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic rtlzz_pipe_90_s8; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic rtlzz_pipe_90_s9; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [63:0] rtlzz_pipe_695_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_699_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_700_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_701_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_701_s9; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_92_s10; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
    logic [63:0] rtlzz_pipe_710_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_710_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_711_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_711_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_712_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_712_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_717_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_717_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_717_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_717_s12; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_718_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_718_s8; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_718_s9; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_718_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_718_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_719_s12; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_721_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_722_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_723_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_723_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_723_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_723_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_723_s13; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s8; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s9; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s13; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_94_s14; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic [64:0] rtlzz_pipe_96_s14; // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [63:0] rtlzz_pipe_777_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_777_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_782_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_782_s15; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_809_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_809_s15; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s15; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_833_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_838_s10; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_123_s11; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    logic [64:0] rtlzz_pipe_123_s12; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    logic rtlzz_pipe_124_s12; // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [63:0] rtlzz_pipe_843_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_843_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_849_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_849_s12; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_132_s13; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] rtlzz_pipe_132_s14; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] rtlzz_pipe_132_s15; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] rtlzz_pipe_865_s10; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_865_s11; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_866_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_871_s10; // decl: <none>; prim: <none>
    logic rtlzz_pipe_871_s11; // decl: <none>; prim: <none>
    logic rtlzz_pipe_873_s11; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_128_s12; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
    logic [63:0] rtlzz_pipe_881_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_882_s12; // decl: <none>; prim: <none>
    logic rtlzz_pipe_883_s12; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_133_s13; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [63:0] rtlzz_pipe_133_s14; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [63:0] rtlzz_pipe_133_s15; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [63:0] rtlzz_pipe_1017_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1022_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_182_s15; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    logic [63:0] rtlzz_pipe_1049_s14; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1055_s14; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_183_s15; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s15; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8


    assign tmp_workload_top_int_65__8_v0 = ({1'h0, x0}); // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    assign tmp_workload_top_int_65__10_v0 = ({1'h0, x4}); // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    assign s8_norm_add_6_v0 = limb_11_322; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_12Core rtlzz_owner_12(.a(65'(rtlzz_pipe_11_s2)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_8_v0));
    assign s8_norm_sub_10_v0 = limb_13_334; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_14Core rtlzz_owner_14(.a(65'(rtlzz_pipe_13_s5)), .b(65'(rtlzz_pipe_11_s5)), .cin(rtlzz_pipe_12_s5), .value(s8_norm_mux_11_v0));
    assign s8_norm_add_14_v0 = limb_15_344; // decl: <none>; prim: <none>
    assign s8_norm_sub_16_v0 = limb_16_356; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(65'(rtlzz_pipe_16_s13)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_18_v0));
    assign s8_norm_sub_20_v0 = limb_18_368; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(65'(rtlzz_pipe_18_s15)), .b(65'(rtlzz_pipe_16_s15)), .cin(rtlzz_pipe_17_s15), .value(s8_norm_mux_21_v0));
    assign tmp_workload_top_int_65__41_v0 = ({1'h0, x2}); // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    assign tmp_workload_top_int_65__43_v0 = ({1'h0, x6}); // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    assign s8_norm_add_26_v0 = limb_22_378; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(65'(rtlzz_pipe_22_s2)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_28_v0));
    assign s8_norm_sub_30_v0 = limb_24_390; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_25Core rtlzz_owner_25(.a(65'(rtlzz_pipe_24_s5)), .b(65'(rtlzz_pipe_22_s5)), .cin(rtlzz_pipe_23_s5), .value(s8_norm_mux_31_v0));
    assign s8_norm_add_34_v0 = limb_26_400; // decl: <none>; prim: <none>
    assign s8_norm_sub_36_v0 = limb_27_412; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_28Core rtlzz_owner_28(.a(65'(s8_norm_sub_36_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_38_v0));
    assign s8_norm_sub_40_v0 = limb_29_424; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(65'(rtlzz_pipe_29_s14)), .b(65'(rtlzz_pipe_27_s14)), .cin(rtlzz_pipe_28_s14), .value(s8_norm_mux_41_v0));
    assign tmp_workload_top_int_65__74_v0 = ({1'h0, x1}); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    assign tmp_workload_top_int_65__76_v0 = ({1'h0, x5}); // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    assign s8_norm_add_46_v0 = limb_33_434; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(65'(rtlzz_pipe_33_s2)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_48_v0));
    assign s8_norm_sub_50_v0 = limb_35_446; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_36Core rtlzz_owner_36(.a(65'(rtlzz_pipe_35_s5)), .b(65'(rtlzz_pipe_33_s5)), .cin(rtlzz_pipe_34_s5), .value(s8_norm_mux_51_v0));
    assign s8_norm_add_54_v0 = limb_37_456; // decl: <none>; prim: <none>
    assign s8_norm_sub_56_v0 = limb_38_468; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_39Core rtlzz_owner_39(.a(65'(rtlzz_pipe_38_s12)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_58_v0));
    assign s8_norm_sub_60_v0 = limb_40_480; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_41Core rtlzz_owner_41(.a(65'(s8_norm_sub_60_v0)), .b(65'(rtlzz_pipe_38_s13)), .cin(rtlzz_pipe_39_s13), .value(s8_norm_mux_61_v0));
    assign tmp_workload_top_int_65__107_v0 = ({1'h0, x3}); // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    assign tmp_workload_top_int_65__109_v0 = ({1'h0, x7}); // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    assign s8_norm_add_66_v0 = limb_44_490; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(65'(rtlzz_pipe_44_s2)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_68_v0));
    assign s8_norm_sub_70_v0 = limb_46_502; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_47Core rtlzz_owner_47(.a(65'(rtlzz_pipe_46_s5)), .b(65'(rtlzz_pipe_44_s5)), .cin(rtlzz_pipe_45_s5), .value(s8_norm_mux_71_v0));
    assign s8_norm_add_74_v0 = limb_48_512; // decl: <none>; prim: <none>
    assign s8_norm_sub_76_v0 = limb_49_524; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(65'(rtlzz_pipe_49_s12)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_78_v0));
    assign s8_norm_sub_80_v0 = limb_51_536; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_52Core rtlzz_owner_52(.a(65'(rtlzz_pipe_51_s12)), .b(65'(rtlzz_pipe_49_s12)), .cin(s8_norm_cmp_78_v0), .value(s8_norm_mux_81_v0));
    assign tmp_workload_top_int_65__140_v0 = (rtlzz_pipe_14_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    assign tmp_workload_top_int_65__142_v0 = (rtlzz_pipe_25_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    assign s8_norm_add_86_v0 = limb_55_546; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_56Core rtlzz_owner_56(.a(65'(s8_norm_add_86_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_88_v0));
    assign s8_norm_sub_90_v0 = limb_57_558; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(65'(rtlzz_pipe_57_s9)), .b(65'(rtlzz_pipe_55_s9)), .cin(rtlzz_pipe_56_s9), .value(s8_norm_mux_91_v0));
    assign s8_norm_add_94_v0 = limb_59_568; // decl: <none>; prim: <none>
    assign s8_norm_sub_96_v0 = limb_60_580; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(65'(s8_norm_sub_96_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_98_v0));
    assign s8_norm_sub_100_v0 = limb_62_592; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(65'(rtlzz_pipe_62_s12)), .b(65'(rtlzz_pipe_60_s12)), .cin(rtlzz_pipe_61_s12), .value(s8_norm_mux_101_v0));
    assign tmp_workload_top_int_128__175_v0 = (__beopt_width_858 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    assign s8_norm_mul_106_v0 = ({143'h0, mul_precision_255}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__180_v0 = (__beopt_width_859 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    assign s8_norm_mul_110_v0 = ({193'h0, mul_precision_258}); // decl: <none>; prim: <none>
    assign n34_v0 = s8_norm_mul_110_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    assign s8_norm_mul_115_v0 = ({129'h0, mul_precision_261}); // decl: <none>; prim: <none>
    assign n36_v0 = s8_norm_mul_115_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    assign tmp_workload_top_int_129__191_v0 = (rtlzz_pipe_221_s15 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    assign s8_norm_sub_118_v0 = limb_72_610; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_73Core rtlzz_owner_73(.a(129'(s8_norm_sub_118_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_120_v0));
    assign s8_norm_sub_122_v0 = limb_74_628; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_75Core rtlzz_owner_75(.a(129'(s8_norm_sub_122_v0)), .b(129'(s8_norm_sub_118_v0)), .cin(s8_norm_cmp_120_v0), .value(s8_norm_mux_123_v0[64:0]));
    assign s8_norm_mux_123_v0[128:65] = '0;
    assign tmp_workload_top_int_65__204_v0 = (s8_norm_mux_21_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    assign tmp_workload_top_int_65__206_v0 = (__beopt_width_863 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    assign s8_norm_add_127_v0 = limb_78_638; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_79Core rtlzz_owner_79(.a(65'(s8_norm_add_127_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_129_v0));
    assign s8_norm_sub_131_v0 = limb_80_650; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_81Core rtlzz_owner_81(.a(65'(s8_norm_sub_131_v0)), .b(65'(s8_norm_add_127_v0)), .cin(s8_norm_cmp_129_v0), .value(s8_norm_mux_132_v0));
    assign s8_norm_add_135_v0 = limb_82_660; // decl: <none>; prim: <none>
    assign s8_norm_sub_137_v0 = limb_83_672; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_84Core rtlzz_owner_84(.a(65'(s8_norm_sub_137_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_139_v0));
    assign s8_norm_sub_141_v0 = limb_85_684; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(65'(s8_norm_sub_141_v0)), .b(65'(s8_norm_sub_137_v0)), .cin(s8_norm_cmp_139_v0), .value(s8_norm_mux_142_v0));
    assign tmp_workload_top_int_65__237_v0 = (rtlzz_pipe_36_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    assign tmp_workload_top_int_65__239_v0 = (rtlzz_pipe_47_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    assign s8_norm_add_147_v0 = limb_89_694; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(65'(s8_norm_add_147_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_149_v0));
    assign s8_norm_sub_151_v0 = limb_91_706; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_92Core rtlzz_owner_92(.a(65'(s8_norm_sub_151_v0)), .b(65'(rtlzz_pipe_89_s9)), .cin(rtlzz_pipe_90_s9), .value(s8_norm_mux_152_v0));
    assign s8_norm_add_155_v0 = limb_93_716; // decl: <none>; prim: <none>
    assign s8_norm_sub_157_v0 = limb_94_728; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(65'(rtlzz_pipe_94_s14)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_159_v0));
    assign s8_norm_sub_161_v0 = limb_96_740; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(65'(rtlzz_pipe_96_s14)), .b(65'(rtlzz_pipe_94_s14)), .cin(s8_norm_cmp_159_v0), .value(s8_norm_mux_162_v0));
    assign tmp_workload_top_int_128__272_v0 = (__beopt_width_865 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    assign s8_norm_mul_167_v0 = ({143'h0, mul_precision_264}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__277_v0 = (rtlzz_pipe_224_s14 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign s8_norm_mul_171_v0 = ({193'h0, mul_precision_267}); // decl: <none>; prim: <none>
    assign n54_v0 = s8_norm_mul_171_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    assign s8_norm_mul_176_v0 = ({129'h0, mul_precision_270}); // decl: <none>; prim: <none>
    assign n56_v0 = s8_norm_mul_176_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    assign tmp_workload_top_int_129__288_v0 = (rtlzz_pipe_226_s15 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign s8_norm_sub_179_v0 = limb_106_758; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_107Core rtlzz_owner_107(.a(129'(s8_norm_sub_179_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_181_v0));
    assign s8_norm_sub_183_v0 = limb_108_776; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_109Core rtlzz_owner_109(.a(129'(s8_norm_sub_183_v0)), .b(129'(s8_norm_sub_179_v0)), .cin(s8_norm_cmp_181_v0), .value(s8_norm_mux_184_v0[64:0]));
    assign s8_norm_mux_184_v0[128:65] = '0;
    assign tmp_workload_top_int_65__301_v0 = (s8_norm_mux_61_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    assign tmp_workload_top_int_65__303_v0 = (__beopt_width_870 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    assign s8_norm_add_188_v0 = limb_112_786; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_113Core rtlzz_owner_113(.a(65'(s8_norm_add_188_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_190_v0));
    assign s8_norm_sub_192_v0 = limb_114_798; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115Core rtlzz_owner_115(.a(65'(s8_norm_sub_192_v0)), .b(65'(s8_norm_add_188_v0)), .cin(s8_norm_cmp_190_v0), .value(s8_norm_mux_193_v0));
    assign s8_norm_add_196_v0 = limb_116_808; // decl: <none>; prim: <none>
    assign s8_norm_sub_198_v0 = limb_117_820; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(65'(s8_norm_sub_198_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_200_v0));
    assign s8_norm_sub_202_v0 = limb_119_832; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_120Core rtlzz_owner_120(.a(65'(s8_norm_sub_202_v0)), .b(65'(s8_norm_sub_198_v0)), .cin(s8_norm_cmp_200_v0), .value(s8_norm_mux_203_v0));
    assign tmp_workload_top_int_65__334_v0 = (s8_norm_mux_91_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    assign tmp_workload_top_int_65__336_v0 = (rtlzz_pipe_92_s10 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    assign s8_norm_add_208_v0 = limb_123_842; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_124Core rtlzz_owner_124(.a(65'(rtlzz_pipe_123_s11)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_210_v0));
    assign s8_norm_sub_212_v0 = limb_125_854; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(65'(s8_norm_sub_212_v0)), .b(65'(rtlzz_pipe_123_s12)), .cin(rtlzz_pipe_124_s12), .value(s8_norm_mux_213_v0[63:0]));
    assign s8_norm_mux_213_v0[64:64] = '0;
    assign s8_norm_add_216_v0 = limb_127_864; // decl: <none>; prim: <none>
    assign s8_norm_sub_218_v0 = limb_128_876; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(65'(rtlzz_pipe_128_s12)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_220_v0));
    assign s8_norm_sub_222_v0 = limb_130_888; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(65'(s8_norm_sub_222_v0)), .b(65'(rtlzz_pipe_128_s12)), .cin(s8_norm_cmp_220_v0), .value(s8_norm_mux_223_v0[63:0]));
    assign s8_norm_mux_223_v0[64:64] = '0;
    assign tmp_workload_top_int_64__363_v0 = s8_norm_mux_213_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    assign tmp_workload_top_int_64__365_v0 = s8_norm_mux_223_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    assign tmp_workload_top_int_128__369_v0 = (__beopt_width_872 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    assign s8_norm_mul_228_v0 = ({128'h0, mul_precision_273}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__374_v0 = (__beopt_width_873 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    assign s8_norm_mul_232_v0 = ({193'h0, mul_precision_276}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_232_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    assign s8_norm_mul_237_v0 = ({129'h0, mul_precision_279}); // decl: <none>; prim: <none>
    assign n76_v0 = s8_norm_mul_237_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    assign tmp_workload_top_int_129__385_v0 = (__beopt_width_876 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    assign s8_norm_sub_240_v0 = limb_142_906; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(129'(s8_norm_sub_240_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_242_v0));
    assign s8_norm_sub_244_v0 = limb_144_924; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_145Core rtlzz_owner_145(.a(129'(s8_norm_sub_244_v0)), .b(129'(s8_norm_sub_240_v0)), .cin(s8_norm_cmp_242_v0), .value(s8_norm_mux_245_v0[64:0]));
    assign s8_norm_mux_245_v0[128:65] = '0;
    assign tmp_workload_top_int_65__398_v0 = (s8_norm_mux_132_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    assign tmp_workload_top_int_65__400_v0 = (__beopt_width_877 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    assign s8_norm_add_249_v0 = limb_148_934; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_149Core rtlzz_owner_149(.a(65'(s8_norm_add_249_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_251_v0));
    assign s8_norm_sub_253_v0 = limb_150_946; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(65'(s8_norm_sub_253_v0)), .b(65'(s8_norm_add_249_v0)), .cin(s8_norm_cmp_251_v0), .value(s8_norm_mux_254_v0[63:0]));
    assign s8_norm_mux_254_v0[64:64] = '0;
    assign s8_norm_add_257_v0 = limb_152_956; // decl: <none>; prim: <none>
    assign s8_norm_sub_259_v0 = limb_153_968; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(65'(s8_norm_sub_259_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_261_v0));
    assign s8_norm_sub_263_v0 = limb_155_980; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_156Core rtlzz_owner_156(.a(65'(s8_norm_sub_263_v0)), .b(65'(s8_norm_sub_259_v0)), .cin(s8_norm_cmp_261_v0), .value(s8_norm_mux_264_v0[63:0]));
    assign s8_norm_mux_264_v0[64:64] = '0;
    assign tmp_workload_top_int_64__427_v0 = s8_norm_mux_254_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    assign tmp_workload_top_int_64__429_v0 = s8_norm_mux_264_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    assign tmp_workload_top_int_128__433_v0 = (__beopt_width_879 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    assign s8_norm_mul_269_v0 = ({143'h0, mul_precision_282}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__438_v0 = (__beopt_width_880 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    assign s8_norm_mul_273_v0 = ({193'h0, mul_precision_285}); // decl: <none>; prim: <none>
    assign n88_v0 = s8_norm_mul_273_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    assign s8_norm_mul_278_v0 = ({129'h0, mul_precision_288}); // decl: <none>; prim: <none>
    assign n90_v0 = s8_norm_mul_278_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    assign tmp_workload_top_int_129__449_v0 = (__beopt_width_883 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    assign s8_norm_sub_281_v0 = limb_167_998; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_168Core rtlzz_owner_168(.a(129'(s8_norm_sub_281_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_283_v0));
    assign s8_norm_sub_285_v0 = limb_169_1016; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(129'(s8_norm_sub_285_v0)), .b(129'(s8_norm_sub_281_v0)), .cin(s8_norm_cmp_283_v0), .value(s8_norm_mux_286_v0[64:0]));
    assign s8_norm_mux_286_v0[128:65] = '0;
    assign tmp_workload_top_int_65__462_v0 = (rtlzz_pipe_63_s13 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    assign tmp_workload_top_int_65__464_v0 = (__beopt_width_884 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    assign s8_norm_add_290_v0 = limb_173_1026; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(65'(s8_norm_add_290_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_292_v0));
    assign s8_norm_sub_294_v0 = limb_175_1038; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(65'(s8_norm_sub_294_v0)), .b(65'(s8_norm_add_290_v0)), .cin(s8_norm_cmp_292_v0), .value(s8_norm_mux_295_v0[63:0]));
    assign s8_norm_mux_295_v0[64:64] = '0;
    assign s8_norm_add_298_v0 = limb_177_1048; // decl: <none>; prim: <none>
    assign s8_norm_sub_300_v0 = limb_178_1060; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_179Core rtlzz_owner_179(.a(65'(s8_norm_sub_300_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_302_v0));
    assign s8_norm_sub_304_v0 = limb_180_1072; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_181Core rtlzz_owner_181(.a(65'(s8_norm_sub_304_v0)), .b(65'(s8_norm_sub_300_v0)), .cin(s8_norm_cmp_302_v0), .value(s8_norm_mux_305_v0[63:0]));
    assign s8_norm_mux_305_v0[64:64] = '0;
    assign tmp_workload_top_int_64__491_v0 = s8_norm_mux_295_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    assign tmp_workload_top_int_64__493_v0 = s8_norm_mux_305_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    assign tmp_workload_top_int_128__497_v0 = (__beopt_width_886 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    assign s8_norm_mul_310_v0 = ({128'h0, mul_precision_291}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__502_v0 = (__beopt_width_887 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    assign s8_norm_mul_314_v0 = ({193'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign n102_v0 = s8_norm_mul_314_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    assign s8_norm_mul_319_v0 = ({129'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign n104_v0 = s8_norm_mul_319_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    assign tmp_workload_top_int_129__513_v0 = (__beopt_width_890 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    assign s8_norm_sub_322_v0 = limb_192_1090; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_193Core rtlzz_owner_193(.a(129'(s8_norm_sub_322_v0)), .b(129'(129'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_324_v0));
    assign s8_norm_sub_326_v0 = limb_194_1108; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_195Core rtlzz_owner_195(.a(129'(s8_norm_sub_326_v0)), .b(129'(s8_norm_sub_322_v0)), .cin(s8_norm_cmp_324_v0), .value(s8_norm_mux_327_v0[64:0]));
    assign s8_norm_mux_327_v0[128:65] = '0;
    assign tmp_workload_top_int_65__526_v0 = (s8_norm_mux_142_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    assign tmp_workload_top_int_65__528_v0 = (__beopt_width_891 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    assign s8_norm_add_331_v0 = limb_198_1118; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_199Core rtlzz_owner_199(.a(65'(s8_norm_add_331_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_333_v0));
    assign s8_norm_sub_335_v0 = limb_200_1130; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(65'(s8_norm_sub_335_v0)), .b(65'(s8_norm_add_331_v0)), .cin(s8_norm_cmp_333_v0), .value(s8_norm_mux_336_v0[63:0]));
    assign s8_norm_mux_336_v0[64:64] = '0;
    assign s8_norm_add_339_v0 = limb_202_1140; // decl: <none>; prim: <none>
    assign s8_norm_sub_341_v0 = limb_203_1152; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_204Core rtlzz_owner_204(.a(65'(s8_norm_sub_341_v0)), .b(65'(65'hffffffff00000001)), .cin(1'b0), .value(s8_norm_cmp_343_v0));
    assign s8_norm_sub_345_v0 = limb_205_1164; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(65'(s8_norm_sub_345_v0)), .b(65'(s8_norm_sub_341_v0)), .cin(s8_norm_cmp_343_v0), .value(s8_norm_mux_346_v0[63:0]));
    assign s8_norm_mux_346_v0[64:64] = '0;
    assign tmp_workload_top_int_64__555_v0 = s8_norm_mux_336_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    assign tmp_workload_top_int_64__557_v0 = s8_norm_mux_346_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    assign y0 = rtlzz_pipe_132_s15; // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    assign y1 = tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    assign y2 = rtlzz_pipe_182_s15; // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    assign y3 = tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    assign y4 = rtlzz_pipe_133_s15; // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    assign y5 = tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    assign y6 = rtlzz_pipe_183_s15; // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    assign y7 = tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    assign ov = rtlzz_valid_s15; // decl: <none>; prim: <none>
    assign __beopt_width_858 = ({63'h0, s8_norm_mux_41_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_859 = s8_norm_mul_106_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_860 = n34_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_862 = s8_norm_mul_106_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_863 = s8_norm_mux_123_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_865 = ({63'h0, s8_norm_mux_81_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_866 = s8_norm_mul_167_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_867 = n54_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_869 = s8_norm_mul_167_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_870 = s8_norm_mux_184_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_872 = ({63'h0, s8_norm_mux_193_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_873 = s8_norm_mul_228_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_874 = n74_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_876 = s8_norm_mul_228_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_877 = s8_norm_mux_245_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_879 = ({63'h0, s8_norm_mux_162_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_880 = s8_norm_mul_269_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_881 = n88_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_883 = s8_norm_mul_269_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_884 = s8_norm_mux_286_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_886 = ({63'h0, s8_norm_mux_203_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_887 = s8_norm_mul_310_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_888 = n102_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_890 = s8_norm_mul_310_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_891 = s8_norm_mux_327_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_255 = (__beopt_width_256 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    assign __beopt_width_259 = (__beopt_width_260 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    assign __beopt_width_263 = (__beopt_width_264 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    assign __beopt_width_268 = (__beopt_width_267 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    assign __beopt_width_272 = (__beopt_width_271 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    assign __beopt_width_256 = ({64'h0, __beopt_width_860}); // decl: <none>; prim: <none>
    assign __beopt_width_260 = ({64'h0, __beopt_width_867}); // decl: <none>; prim: <none>
    assign __beopt_width_264 = ({64'h0, __beopt_width_874}); // decl: <none>; prim: <none>
    assign __beopt_width_267 = ({64'h0, __beopt_width_881}); // decl: <none>; prim: <none>
    assign __beopt_width_271 = ({64'h0, __beopt_width_888}); // decl: <none>; prim: <none>
    assign mul_precision_253 = tmp_workload_top_int_128__175_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_254 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_255 = arith_original_298; // decl: <none>; prim: <none>
    assign mul_precision_256 = tmp_workload_top_int_193__180_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_257 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_258 = arith_original_299; // decl: <none>; prim: <none>
    assign mul_precision_259 = __beopt_width_255[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_260 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_261 = arith_original_300; // decl: <none>; prim: <none>
    assign mul_precision_262 = tmp_workload_top_int_128__272_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_263 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_264 = arith_original_301; // decl: <none>; prim: <none>
    assign mul_precision_265 = tmp_workload_top_int_193__277_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_266 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_267 = arith_original_302; // decl: <none>; prim: <none>
    assign mul_precision_268 = __beopt_width_259[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_269 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_270 = arith_original_303; // decl: <none>; prim: <none>
    assign mul_precision_271 = tmp_workload_top_int_128__369_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_272 = 64'((128'hfffffffeff000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_273 = arith_original_304; // decl: <none>; prim: <none>
    assign mul_precision_274 = tmp_workload_top_int_193__374_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_275 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_276 = arith_original_305; // decl: <none>; prim: <none>
    assign mul_precision_277 = __beopt_width_263[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_278 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_279 = arith_original_306; // decl: <none>; prim: <none>
    assign mul_precision_280 = tmp_workload_top_int_128__433_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_281 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_282 = arith_original_307; // decl: <none>; prim: <none>
    assign mul_precision_283 = tmp_workload_top_int_193__438_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_284 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_285 = arith_original_308; // decl: <none>; prim: <none>
    assign mul_precision_286 = __beopt_width_268[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_287 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_288 = arith_original_309; // decl: <none>; prim: <none>
    assign mul_precision_289 = tmp_workload_top_int_128__497_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_290 = 64'((128'hfffffeff00000101) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_291 = arith_original_310; // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_193__502_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_311; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_272[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_312; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(64'(mul_precision_253)), .b(49'(mul_precision_254)), .cin(1'b0), .value(arith_original_298));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_299Core rtlzz_owner_299(.a(128'(rtlzz_pipe_256_s15)), .b(65'(mul_precision_257)), .cin(1'b0), .value(arith_original_299));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_300Core rtlzz_owner_300(.a(65'(mul_precision_259)), .b(64'(mul_precision_260)), .cin(1'b0), .value(arith_original_300));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(64'(rtlzz_pipe_262_s13)), .b(49'(mul_precision_263)), .cin(1'b0), .value(arith_original_301));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_302Core rtlzz_owner_302(.a(128'(mul_precision_265)), .b(65'(mul_precision_266)), .cin(1'b0), .value(arith_original_302));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_303Core rtlzz_owner_303(.a(65'(rtlzz_pipe_268_s15)), .b(64'(mul_precision_269)), .cin(1'b0), .value(arith_original_303));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_304Core rtlzz_owner_304(.a(64'(mul_precision_271)), .b(64'(mul_precision_272)), .cin(1'b0), .value(arith_original_304));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_305Core rtlzz_owner_305(.a(128'(mul_precision_274)), .b(65'(mul_precision_275)), .cin(1'b0), .value(arith_original_305));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_306Core rtlzz_owner_306(.a(65'(mul_precision_277)), .b(64'(mul_precision_278)), .cin(1'b0), .value(arith_original_306));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_307Core rtlzz_owner_307(.a(64'(mul_precision_280)), .b(49'(mul_precision_281)), .cin(1'b0), .value(arith_original_307));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_308Core rtlzz_owner_308(.a(128'(mul_precision_283)), .b(65'(mul_precision_284)), .cin(1'b0), .value(arith_original_308));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(65'(mul_precision_286)), .b(64'(mul_precision_287)), .cin(1'b0), .value(arith_original_309));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_310Core rtlzz_owner_310(.a(64'(mul_precision_289)), .b(64'(mul_precision_290)), .cin(1'b0), .value(arith_original_310));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_311Core rtlzz_owner_311(.a(128'(mul_precision_292)), .b(65'(mul_precision_293)), .cin(1'b0), .value(arith_original_311));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_312Core rtlzz_owner_312(.a(65'(mul_precision_295)), .b(64'(mul_precision_296)), .cin(1'b0), .value(arith_original_312));
    assign limb_11_313 = tmp_workload_top_int_65__8_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_11_314 = tmp_workload_top_int_65__10_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_315Core rtlzz_owner_315(.a(64'(limb_11_313)), .b(64'(limb_11_314)), .cin(1'h0), .value(limb_11_315));
    assign limb_11_316 = limb_11_315[63:0]; // decl: <none>; prim: <none>
    assign limb_11_317 = limb_11_315[64]; // decl: <none>; prim: <none>
    assign limb_11_318 = tmp_workload_top_int_65__8_v0[64]; // decl: <none>; prim: <none>
    assign limb_11_319 = tmp_workload_top_int_65__10_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_320Core rtlzz_owner_320(.a(1'(rtlzz_pipe_318_s1)), .b(1'(rtlzz_pipe_319_s1)), .cin(rtlzz_pipe_317_s1), .value(limb_11_320[0:0]));
    assign limb_11_320[1:1] = '0;
    assign limb_11_321 = limb_11_320[0]; // decl: <none>; prim: <none>
    assign limb_11_322 = {limb_11_321, rtlzz_pipe_316_s1}; // decl: <none>; prim: <none>
    assign limb_13_323 = s8_norm_add_6_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_13_324 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_13_325 = (~limb_13_324); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_326Core rtlzz_owner_326(.a(64'(rtlzz_pipe_323_s3)), .b(64'(limb_13_325)), .cin(1'h1), .value(limb_13_326));
    assign limb_13_327 = limb_13_326[63:0]; // decl: <none>; prim: <none>
    assign limb_13_328 = limb_13_326[64]; // decl: <none>; prim: <none>
    assign limb_13_329 = s8_norm_add_6_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_330 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_13_331 = (~limb_13_330); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_332Core rtlzz_owner_332(.a(1'(rtlzz_pipe_329_s4)), .b(1'(limb_13_331)), .cin(rtlzz_pipe_328_s4), .value(limb_13_332[0:0]));
    assign limb_13_332[1:1] = '0;
    assign limb_13_333 = limb_13_332[0]; // decl: <none>; prim: <none>
    assign limb_13_334 = {limb_13_333, rtlzz_pipe_327_s4}; // decl: <none>; prim: <none>
    assign limb_15_335 = tmp_workload_top_int_65__8_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_15_336 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(64'(rtlzz_pipe_335_s7)), .b(64'(limb_15_336)), .cin(1'h0), .value(limb_15_337));
    assign limb_15_338 = limb_15_337[63:0]; // decl: <none>; prim: <none>
    assign limb_15_339 = limb_15_337[64]; // decl: <none>; prim: <none>
    assign limb_15_340 = tmp_workload_top_int_65__8_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_341 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_342Core rtlzz_owner_342(.a(1'(rtlzz_pipe_340_s8)), .b(1'(limb_15_341)), .cin(rtlzz_pipe_339_s8), .value(limb_15_342[0:0]));
    assign limb_15_342[1:1] = '0;
    assign limb_15_343 = limb_15_342[0]; // decl: <none>; prim: <none>
    assign limb_15_344 = {limb_15_343, rtlzz_pipe_338_s8}; // decl: <none>; prim: <none>
    assign limb_16_345 = s8_norm_add_14_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_346 = tmp_workload_top_int_65__10_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_347 = (~rtlzz_pipe_346_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(64'(rtlzz_pipe_345_s10)), .b(64'(rtlzz_pipe_347_s10)), .cin(1'h1), .value(limb_16_348));
    assign limb_16_349 = limb_16_348[63:0]; // decl: <none>; prim: <none>
    assign limb_16_350 = limb_16_348[64]; // decl: <none>; prim: <none>
    assign limb_16_351 = s8_norm_add_14_v0[64]; // decl: <none>; prim: <none>
    assign limb_16_352 = tmp_workload_top_int_65__10_v0[64]; // decl: <none>; prim: <none>
    assign limb_16_353 = (~rtlzz_pipe_352_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(1'(rtlzz_pipe_351_s12)), .b(1'(rtlzz_pipe_353_s12)), .cin(rtlzz_pipe_350_s12), .value(limb_16_354[0:0]));
    assign limb_16_354[1:1] = '0;
    assign limb_16_355 = limb_16_354[0]; // decl: <none>; prim: <none>
    assign limb_16_356 = {limb_16_355, rtlzz_pipe_349_s12}; // decl: <none>; prim: <none>
    assign limb_18_357 = s8_norm_sub_16_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_18_358 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_18_359 = (~limb_18_358); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_360Core rtlzz_owner_360(.a(64'(rtlzz_pipe_357_s14)), .b(64'(limb_18_359)), .cin(1'h1), .value(limb_18_360));
    assign limb_18_361 = limb_18_360[63:0]; // decl: <none>; prim: <none>
    assign limb_18_362 = limb_18_360[64]; // decl: <none>; prim: <none>
    assign limb_18_363 = s8_norm_sub_16_v0[64]; // decl: <none>; prim: <none>
    assign limb_18_364 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_18_365 = (~limb_18_364); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366Core rtlzz_owner_366(.a(1'(rtlzz_pipe_363_s14)), .b(1'(limb_18_365)), .cin(limb_18_362), .value(limb_18_366[0:0]));
    assign limb_18_366[1:1] = '0;
    assign limb_18_367 = limb_18_366[0]; // decl: <none>; prim: <none>
    assign limb_18_368 = {limb_18_367, limb_18_361}; // decl: <none>; prim: <none>
    assign limb_22_369 = tmp_workload_top_int_65__41_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_22_370 = tmp_workload_top_int_65__43_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_371Core rtlzz_owner_371(.a(64'(limb_22_369)), .b(64'(limb_22_370)), .cin(1'h0), .value(limb_22_371));
    assign limb_22_372 = limb_22_371[63:0]; // decl: <none>; prim: <none>
    assign limb_22_373 = limb_22_371[64]; // decl: <none>; prim: <none>
    assign limb_22_374 = tmp_workload_top_int_65__41_v0[64]; // decl: <none>; prim: <none>
    assign limb_22_375 = tmp_workload_top_int_65__43_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(1'(rtlzz_pipe_374_s1)), .b(1'(rtlzz_pipe_375_s1)), .cin(rtlzz_pipe_373_s1), .value(limb_22_376[0:0]));
    assign limb_22_376[1:1] = '0;
    assign limb_22_377 = limb_22_376[0]; // decl: <none>; prim: <none>
    assign limb_22_378 = {limb_22_377, rtlzz_pipe_372_s1}; // decl: <none>; prim: <none>
    assign limb_24_379 = s8_norm_add_26_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_24_380 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_24_381 = (~limb_24_380); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382Core rtlzz_owner_382(.a(64'(rtlzz_pipe_379_s3)), .b(64'(limb_24_381)), .cin(1'h1), .value(limb_24_382));
    assign limb_24_383 = limb_24_382[63:0]; // decl: <none>; prim: <none>
    assign limb_24_384 = limb_24_382[64]; // decl: <none>; prim: <none>
    assign limb_24_385 = s8_norm_add_26_v0[64]; // decl: <none>; prim: <none>
    assign limb_24_386 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_24_387 = (~limb_24_386); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(1'(rtlzz_pipe_385_s4)), .b(1'(limb_24_387)), .cin(rtlzz_pipe_384_s4), .value(limb_24_388[0:0]));
    assign limb_24_388[1:1] = '0;
    assign limb_24_389 = limb_24_388[0]; // decl: <none>; prim: <none>
    assign limb_24_390 = {limb_24_389, rtlzz_pipe_383_s4}; // decl: <none>; prim: <none>
    assign limb_26_391 = tmp_workload_top_int_65__41_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_26_392 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_393Core rtlzz_owner_393(.a(64'(rtlzz_pipe_391_s7)), .b(64'(limb_26_392)), .cin(1'h0), .value(limb_26_393));
    assign limb_26_394 = limb_26_393[63:0]; // decl: <none>; prim: <none>
    assign limb_26_395 = limb_26_393[64]; // decl: <none>; prim: <none>
    assign limb_26_396 = tmp_workload_top_int_65__41_v0[64]; // decl: <none>; prim: <none>
    assign limb_26_397 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(1'(rtlzz_pipe_396_s8)), .b(1'(limb_26_397)), .cin(rtlzz_pipe_395_s8), .value(limb_26_398[0:0]));
    assign limb_26_398[1:1] = '0;
    assign limb_26_399 = limb_26_398[0]; // decl: <none>; prim: <none>
    assign limb_26_400 = {limb_26_399, rtlzz_pipe_394_s8}; // decl: <none>; prim: <none>
    assign limb_27_401 = s8_norm_add_34_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_27_402 = tmp_workload_top_int_65__43_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_27_403 = (~rtlzz_pipe_402_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_404Core rtlzz_owner_404(.a(64'(rtlzz_pipe_401_s10)), .b(64'(rtlzz_pipe_403_s10)), .cin(1'h1), .value(limb_27_404));
    assign limb_27_405 = limb_27_404[63:0]; // decl: <none>; prim: <none>
    assign limb_27_406 = limb_27_404[64]; // decl: <none>; prim: <none>
    assign limb_27_407 = s8_norm_add_34_v0[64]; // decl: <none>; prim: <none>
    assign limb_27_408 = tmp_workload_top_int_65__43_v0[64]; // decl: <none>; prim: <none>
    assign limb_27_409 = (~rtlzz_pipe_408_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_410Core rtlzz_owner_410(.a(1'(rtlzz_pipe_407_s12)), .b(1'(rtlzz_pipe_409_s12)), .cin(rtlzz_pipe_406_s12), .value(limb_27_410[0:0]));
    assign limb_27_410[1:1] = '0;
    assign limb_27_411 = limb_27_410[0]; // decl: <none>; prim: <none>
    assign limb_27_412 = {limb_27_411, rtlzz_pipe_405_s12}; // decl: <none>; prim: <none>
    assign limb_29_413 = s8_norm_sub_36_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_414 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_29_415 = (~limb_29_414); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_416Core rtlzz_owner_416(.a(64'(rtlzz_pipe_413_s13)), .b(64'(limb_29_415)), .cin(1'h1), .value(limb_29_416));
    assign limb_29_417 = limb_29_416[63:0]; // decl: <none>; prim: <none>
    assign limb_29_418 = limb_29_416[64]; // decl: <none>; prim: <none>
    assign limb_29_419 = s8_norm_sub_36_v0[64]; // decl: <none>; prim: <none>
    assign limb_29_420 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_29_421 = (~limb_29_420); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_422Core rtlzz_owner_422(.a(1'(rtlzz_pipe_419_s13)), .b(1'(limb_29_421)), .cin(limb_29_418), .value(limb_29_422[0:0]));
    assign limb_29_422[1:1] = '0;
    assign limb_29_423 = limb_29_422[0]; // decl: <none>; prim: <none>
    assign limb_29_424 = {limb_29_423, limb_29_417}; // decl: <none>; prim: <none>
    assign limb_33_425 = tmp_workload_top_int_65__74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_33_426 = tmp_workload_top_int_65__76_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427Core rtlzz_owner_427(.a(64'(limb_33_425)), .b(64'(limb_33_426)), .cin(1'h0), .value(limb_33_427));
    assign limb_33_428 = limb_33_427[63:0]; // decl: <none>; prim: <none>
    assign limb_33_429 = limb_33_427[64]; // decl: <none>; prim: <none>
    assign limb_33_430 = tmp_workload_top_int_65__74_v0[64]; // decl: <none>; prim: <none>
    assign limb_33_431 = tmp_workload_top_int_65__76_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_432Core rtlzz_owner_432(.a(1'(rtlzz_pipe_430_s1)), .b(1'(rtlzz_pipe_431_s1)), .cin(rtlzz_pipe_429_s1), .value(limb_33_432[0:0]));
    assign limb_33_432[1:1] = '0;
    assign limb_33_433 = limb_33_432[0]; // decl: <none>; prim: <none>
    assign limb_33_434 = {limb_33_433, rtlzz_pipe_428_s1}; // decl: <none>; prim: <none>
    assign limb_35_435 = s8_norm_add_46_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_35_436 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_35_437 = (~limb_35_436); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_438Core rtlzz_owner_438(.a(64'(rtlzz_pipe_435_s3)), .b(64'(limb_35_437)), .cin(1'h1), .value(limb_35_438));
    assign limb_35_439 = limb_35_438[63:0]; // decl: <none>; prim: <none>
    assign limb_35_440 = limb_35_438[64]; // decl: <none>; prim: <none>
    assign limb_35_441 = s8_norm_add_46_v0[64]; // decl: <none>; prim: <none>
    assign limb_35_442 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_35_443 = (~limb_35_442); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_444Core rtlzz_owner_444(.a(1'(rtlzz_pipe_441_s4)), .b(1'(limb_35_443)), .cin(rtlzz_pipe_440_s4), .value(limb_35_444[0:0]));
    assign limb_35_444[1:1] = '0;
    assign limb_35_445 = limb_35_444[0]; // decl: <none>; prim: <none>
    assign limb_35_446 = {limb_35_445, rtlzz_pipe_439_s4}; // decl: <none>; prim: <none>
    assign limb_37_447 = tmp_workload_top_int_65__74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_37_448 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_449Core rtlzz_owner_449(.a(64'(rtlzz_pipe_447_s7)), .b(64'(limb_37_448)), .cin(1'h0), .value(limb_37_449));
    assign limb_37_450 = limb_37_449[63:0]; // decl: <none>; prim: <none>
    assign limb_37_451 = limb_37_449[64]; // decl: <none>; prim: <none>
    assign limb_37_452 = tmp_workload_top_int_65__74_v0[64]; // decl: <none>; prim: <none>
    assign limb_37_453 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_454Core rtlzz_owner_454(.a(1'(rtlzz_pipe_452_s8)), .b(1'(limb_37_453)), .cin(rtlzz_pipe_451_s8), .value(limb_37_454[0:0]));
    assign limb_37_454[1:1] = '0;
    assign limb_37_455 = limb_37_454[0]; // decl: <none>; prim: <none>
    assign limb_37_456 = {limb_37_455, rtlzz_pipe_450_s8}; // decl: <none>; prim: <none>
    assign limb_38_457 = s8_norm_add_54_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_38_458 = tmp_workload_top_int_65__76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_38_459 = (~rtlzz_pipe_458_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_460Core rtlzz_owner_460(.a(64'(rtlzz_pipe_457_s10)), .b(64'(rtlzz_pipe_459_s10)), .cin(1'h1), .value(limb_38_460));
    assign limb_38_461 = limb_38_460[63:0]; // decl: <none>; prim: <none>
    assign limb_38_462 = limb_38_460[64]; // decl: <none>; prim: <none>
    assign limb_38_463 = s8_norm_add_54_v0[64]; // decl: <none>; prim: <none>
    assign limb_38_464 = tmp_workload_top_int_65__76_v0[64]; // decl: <none>; prim: <none>
    assign limb_38_465 = (~rtlzz_pipe_464_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_466Core rtlzz_owner_466(.a(1'(rtlzz_pipe_463_s11)), .b(1'(limb_38_465)), .cin(rtlzz_pipe_462_s11), .value(limb_38_466[0:0]));
    assign limb_38_466[1:1] = '0;
    assign limb_38_467 = limb_38_466[0]; // decl: <none>; prim: <none>
    assign limb_38_468 = {limb_38_467, rtlzz_pipe_461_s11}; // decl: <none>; prim: <none>
    assign limb_40_469 = s8_norm_sub_56_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_470 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_40_471 = (~limb_40_470); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_472Core rtlzz_owner_472(.a(64'(limb_40_469)), .b(64'(limb_40_471)), .cin(1'h1), .value(limb_40_472));
    assign limb_40_473 = limb_40_472[63:0]; // decl: <none>; prim: <none>
    assign limb_40_474 = limb_40_472[64]; // decl: <none>; prim: <none>
    assign limb_40_475 = s8_norm_sub_56_v0[64]; // decl: <none>; prim: <none>
    assign limb_40_476 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_40_477 = (~limb_40_476); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_478Core rtlzz_owner_478(.a(1'(rtlzz_pipe_475_s13)), .b(1'(limb_40_477)), .cin(rtlzz_pipe_474_s13), .value(limb_40_478[0:0]));
    assign limb_40_478[1:1] = '0;
    assign limb_40_479 = limb_40_478[0]; // decl: <none>; prim: <none>
    assign limb_40_480 = {limb_40_479, rtlzz_pipe_473_s13}; // decl: <none>; prim: <none>
    assign limb_44_481 = tmp_workload_top_int_65__107_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_44_482 = tmp_workload_top_int_65__109_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_483Core rtlzz_owner_483(.a(64'(limb_44_481)), .b(64'(limb_44_482)), .cin(1'h0), .value(limb_44_483));
    assign limb_44_484 = limb_44_483[63:0]; // decl: <none>; prim: <none>
    assign limb_44_485 = limb_44_483[64]; // decl: <none>; prim: <none>
    assign limb_44_486 = tmp_workload_top_int_65__107_v0[64]; // decl: <none>; prim: <none>
    assign limb_44_487 = tmp_workload_top_int_65__109_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_488Core rtlzz_owner_488(.a(1'(rtlzz_pipe_486_s1)), .b(1'(rtlzz_pipe_487_s1)), .cin(rtlzz_pipe_485_s1), .value(limb_44_488[0:0]));
    assign limb_44_488[1:1] = '0;
    assign limb_44_489 = limb_44_488[0]; // decl: <none>; prim: <none>
    assign limb_44_490 = {limb_44_489, rtlzz_pipe_484_s1}; // decl: <none>; prim: <none>
    assign limb_46_491 = s8_norm_add_66_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_46_492 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_46_493 = (~limb_46_492); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_494Core rtlzz_owner_494(.a(64'(rtlzz_pipe_491_s3)), .b(64'(limb_46_493)), .cin(1'h1), .value(limb_46_494));
    assign limb_46_495 = limb_46_494[63:0]; // decl: <none>; prim: <none>
    assign limb_46_496 = limb_46_494[64]; // decl: <none>; prim: <none>
    assign limb_46_497 = s8_norm_add_66_v0[64]; // decl: <none>; prim: <none>
    assign limb_46_498 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_46_499 = (~limb_46_498); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_500Core rtlzz_owner_500(.a(1'(rtlzz_pipe_497_s4)), .b(1'(limb_46_499)), .cin(rtlzz_pipe_496_s4), .value(limb_46_500[0:0]));
    assign limb_46_500[1:1] = '0;
    assign limb_46_501 = limb_46_500[0]; // decl: <none>; prim: <none>
    assign limb_46_502 = {limb_46_501, rtlzz_pipe_495_s4}; // decl: <none>; prim: <none>
    assign limb_48_503 = tmp_workload_top_int_65__107_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_48_504 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(64'(rtlzz_pipe_503_s7)), .b(64'(limb_48_504)), .cin(1'h0), .value(limb_48_505));
    assign limb_48_506 = limb_48_505[63:0]; // decl: <none>; prim: <none>
    assign limb_48_507 = limb_48_505[64]; // decl: <none>; prim: <none>
    assign limb_48_508 = tmp_workload_top_int_65__107_v0[64]; // decl: <none>; prim: <none>
    assign limb_48_509 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_510Core rtlzz_owner_510(.a(1'(rtlzz_pipe_508_s8)), .b(1'(limb_48_509)), .cin(rtlzz_pipe_507_s8), .value(limb_48_510[0:0]));
    assign limb_48_510[1:1] = '0;
    assign limb_48_511 = limb_48_510[0]; // decl: <none>; prim: <none>
    assign limb_48_512 = {limb_48_511, rtlzz_pipe_506_s8}; // decl: <none>; prim: <none>
    assign limb_49_513 = s8_norm_add_74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_49_514 = tmp_workload_top_int_65__109_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_49_515 = (~rtlzz_pipe_514_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_516Core rtlzz_owner_516(.a(64'(rtlzz_pipe_513_s10)), .b(64'(rtlzz_pipe_515_s10)), .cin(1'h1), .value(limb_49_516));
    assign limb_49_517 = limb_49_516[63:0]; // decl: <none>; prim: <none>
    assign limb_49_518 = limb_49_516[64]; // decl: <none>; prim: <none>
    assign limb_49_519 = s8_norm_add_74_v0[64]; // decl: <none>; prim: <none>
    assign limb_49_520 = tmp_workload_top_int_65__109_v0[64]; // decl: <none>; prim: <none>
    assign limb_49_521 = (~limb_49_520); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_522Core rtlzz_owner_522(.a(1'(rtlzz_pipe_519_s10)), .b(1'(rtlzz_pipe_521_s10)), .cin(limb_49_518), .value(limb_49_522[0:0]));
    assign limb_49_522[1:1] = '0;
    assign limb_49_523 = limb_49_522[0]; // decl: <none>; prim: <none>
    assign limb_49_524 = {limb_49_523, limb_49_517}; // decl: <none>; prim: <none>
    assign limb_51_525 = s8_norm_sub_76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_51_526 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_51_527 = (~limb_51_526); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_528Core rtlzz_owner_528(.a(64'(limb_51_525)), .b(64'(limb_51_527)), .cin(1'h1), .value(limb_51_528));
    assign limb_51_529 = limb_51_528[63:0]; // decl: <none>; prim: <none>
    assign limb_51_530 = limb_51_528[64]; // decl: <none>; prim: <none>
    assign limb_51_531 = s8_norm_sub_76_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_532 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_51_533 = (~limb_51_532); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_534Core rtlzz_owner_534(.a(1'(rtlzz_pipe_531_s11)), .b(1'(limb_51_533)), .cin(rtlzz_pipe_530_s11), .value(limb_51_534[0:0]));
    assign limb_51_534[1:1] = '0;
    assign limb_51_535 = limb_51_534[0]; // decl: <none>; prim: <none>
    assign limb_51_536 = {limb_51_535, rtlzz_pipe_529_s11}; // decl: <none>; prim: <none>
    assign limb_55_537 = tmp_workload_top_int_65__140_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_55_538 = tmp_workload_top_int_65__142_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_539Core rtlzz_owner_539(.a(64'(limb_55_537)), .b(64'(limb_55_538)), .cin(1'h0), .value(limb_55_539));
    assign limb_55_540 = limb_55_539[63:0]; // decl: <none>; prim: <none>
    assign limb_55_541 = limb_55_539[64]; // decl: <none>; prim: <none>
    assign limb_55_542 = tmp_workload_top_int_65__140_v0[64]; // decl: <none>; prim: <none>
    assign limb_55_543 = tmp_workload_top_int_65__142_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_544Core rtlzz_owner_544(.a(1'(rtlzz_pipe_542_s7)), .b(1'(rtlzz_pipe_543_s7)), .cin(rtlzz_pipe_541_s7), .value(limb_55_544[0:0]));
    assign limb_55_544[1:1] = '0;
    assign limb_55_545 = limb_55_544[0]; // decl: <none>; prim: <none>
    assign limb_55_546 = {limb_55_545, rtlzz_pipe_540_s7}; // decl: <none>; prim: <none>
    assign limb_57_547 = s8_norm_add_86_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_57_548 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_57_549 = (~limb_57_548); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(64'(rtlzz_pipe_547_s8)), .b(64'(limb_57_549)), .cin(1'h1), .value(limb_57_550));
    assign limb_57_551 = limb_57_550[63:0]; // decl: <none>; prim: <none>
    assign limb_57_552 = limb_57_550[64]; // decl: <none>; prim: <none>
    assign limb_57_553 = s8_norm_add_86_v0[64]; // decl: <none>; prim: <none>
    assign limb_57_554 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_57_555 = (~limb_57_554); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_556Core rtlzz_owner_556(.a(1'(rtlzz_pipe_553_s8)), .b(1'(limb_57_555)), .cin(limb_57_552), .value(limb_57_556[0:0]));
    assign limb_57_556[1:1] = '0;
    assign limb_57_557 = limb_57_556[0]; // decl: <none>; prim: <none>
    assign limb_57_558 = {limb_57_557, limb_57_551}; // decl: <none>; prim: <none>
    assign limb_59_559 = tmp_workload_top_int_65__140_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_59_560 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_561Core rtlzz_owner_561(.a(64'(limb_59_559)), .b(64'(limb_59_560)), .cin(1'h0), .value(limb_59_561));
    assign limb_59_562 = limb_59_561[63:0]; // decl: <none>; prim: <none>
    assign limb_59_563 = limb_59_561[64]; // decl: <none>; prim: <none>
    assign limb_59_564 = tmp_workload_top_int_65__140_v0[64]; // decl: <none>; prim: <none>
    assign limb_59_565 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_566Core rtlzz_owner_566(.a(1'(limb_59_564)), .b(1'(limb_59_565)), .cin(limb_59_563), .value(limb_59_566[0:0]));
    assign limb_59_566[1:1] = '0;
    assign limb_59_567 = limb_59_566[0]; // decl: <none>; prim: <none>
    assign limb_59_568 = {limb_59_567, limb_59_562}; // decl: <none>; prim: <none>
    assign limb_60_569 = s8_norm_add_94_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_60_570 = tmp_workload_top_int_65__142_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_60_571 = (~rtlzz_pipe_570_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_572Core rtlzz_owner_572(.a(64'(rtlzz_pipe_569_s8)), .b(64'(rtlzz_pipe_571_s8)), .cin(1'h1), .value(limb_60_572));
    assign limb_60_573 = limb_60_572[63:0]; // decl: <none>; prim: <none>
    assign limb_60_574 = limb_60_572[64]; // decl: <none>; prim: <none>
    assign limb_60_575 = s8_norm_add_94_v0[64]; // decl: <none>; prim: <none>
    assign limb_60_576 = tmp_workload_top_int_65__142_v0[64]; // decl: <none>; prim: <none>
    assign limb_60_577 = (~rtlzz_pipe_576_s9); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_578Core rtlzz_owner_578(.a(1'(rtlzz_pipe_575_s10)), .b(1'(rtlzz_pipe_577_s10)), .cin(rtlzz_pipe_574_s10), .value(limb_60_578[0:0]));
    assign limb_60_578[1:1] = '0;
    assign limb_60_579 = limb_60_578[0]; // decl: <none>; prim: <none>
    assign limb_60_580 = {limb_60_579, rtlzz_pipe_573_s10}; // decl: <none>; prim: <none>
    assign limb_62_581 = s8_norm_sub_96_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_62_582 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_62_583 = (~limb_62_582); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_584Core rtlzz_owner_584(.a(64'(rtlzz_pipe_581_s11)), .b(64'(limb_62_583)), .cin(1'h1), .value(limb_62_584));
    assign limb_62_585 = limb_62_584[63:0]; // decl: <none>; prim: <none>
    assign limb_62_586 = limb_62_584[64]; // decl: <none>; prim: <none>
    assign limb_62_587 = s8_norm_sub_96_v0[64]; // decl: <none>; prim: <none>
    assign limb_62_588 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_62_589 = (~limb_62_588); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_590Core rtlzz_owner_590(.a(1'(rtlzz_pipe_587_s11)), .b(1'(limb_62_589)), .cin(limb_62_586), .value(limb_62_590[0:0]));
    assign limb_62_590[1:1] = '0;
    assign limb_62_591 = limb_62_590[0]; // decl: <none>; prim: <none>
    assign limb_62_592 = {limb_62_591, limb_62_585}; // decl: <none>; prim: <none>
    assign limb_72_593 = tmp_workload_top_int_129__191_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_72_594 = n36_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_72_595 = (~limb_72_594); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_596Core rtlzz_owner_596(.a(64'(limb_72_593)), .b(64'(limb_72_595)), .cin(1'h1), .value(limb_72_596));
    assign limb_72_597 = limb_72_596[63:0]; // decl: <none>; prim: <none>
    assign limb_72_598 = limb_72_596[64]; // decl: <none>; prim: <none>
    assign limb_72_599 = tmp_workload_top_int_129__191_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_72_600 = n36_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_72_601 = (~limb_72_600); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_602Core rtlzz_owner_602(.a(64'(limb_72_599)), .b(64'(limb_72_601)), .cin(limb_72_598), .value(limb_72_602));
    assign limb_72_603 = limb_72_602[63:0]; // decl: <none>; prim: <none>
    assign limb_72_604 = limb_72_602[64]; // decl: <none>; prim: <none>
    assign limb_72_605 = tmp_workload_top_int_129__191_v0[128]; // decl: <none>; prim: <none>
    assign limb_72_606 = n36_v0[128]; // decl: <none>; prim: <none>
    assign limb_72_607 = (~limb_72_606); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_608Core rtlzz_owner_608(.a(1'(limb_72_605)), .b(1'(limb_72_607)), .cin(limb_72_604), .value(limb_72_608[0:0]));
    assign limb_72_608[1:1] = '0;
    assign limb_72_609 = limb_72_608[0]; // decl: <none>; prim: <none>
    assign limb_72_610 = {limb_72_609, limb_72_603, limb_72_597}; // decl: <none>; prim: <none>
    assign limb_74_611 = s8_norm_sub_118_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_74_612 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_74_613 = (~limb_74_612); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_614Core rtlzz_owner_614(.a(64'(limb_74_611)), .b(64'(limb_74_613)), .cin(1'h1), .value(limb_74_614));
    assign limb_74_615 = limb_74_614[63:0]; // decl: <none>; prim: <none>
    assign limb_74_616 = limb_74_614[64]; // decl: <none>; prim: <none>
    assign limb_74_617 = s8_norm_sub_118_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_74_618 = 64'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_74_619 = (~limb_74_618); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_620Core rtlzz_owner_620(.a(64'(limb_74_617)), .b(64'(limb_74_619)), .cin(limb_74_616), .value(limb_74_620[0:0]));
    assign limb_74_620[64:1] = '0;
    assign limb_74_621 = limb_74_620[63:0]; // decl: <none>; prim: <none>
    assign limb_74_622 = limb_74_620[64]; // decl: <none>; prim: <none>
    assign limb_74_623 = s8_norm_sub_118_v0[128]; // decl: <none>; prim: <none>
    assign limb_74_624 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_74_625 = (~limb_74_624); // decl: <none>; prim: <none>
    assign limb_74_626 = 2'((({1'h0, limb_74_623}) + ({1'h0, limb_74_625}) + ({1'h0, limb_74_622}))); // decl: <none>; prim: <none>
    assign limb_74_627 = limb_74_626[0]; // decl: <none>; prim: <none>
    assign limb_74_628 = {limb_74_627, limb_74_621, limb_74_615}; // decl: <none>; prim: <none>
    assign limb_78_629 = tmp_workload_top_int_65__204_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_630 = tmp_workload_top_int_65__206_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_631Core rtlzz_owner_631(.a(64'(limb_78_629)), .b(64'(limb_78_630)), .cin(1'h0), .value(limb_78_631));
    assign limb_78_632 = limb_78_631[63:0]; // decl: <none>; prim: <none>
    assign limb_78_633 = limb_78_631[64]; // decl: <none>; prim: <none>
    assign limb_78_634 = tmp_workload_top_int_65__204_v0[64]; // decl: <none>; prim: <none>
    assign limb_78_635 = tmp_workload_top_int_65__206_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_636Core rtlzz_owner_636(.a(1'(limb_78_634)), .b(1'(limb_78_635)), .cin(limb_78_633), .value(limb_78_636[0:0]));
    assign limb_78_636[1:1] = '0;
    assign limb_78_637 = limb_78_636[0]; // decl: <none>; prim: <none>
    assign limb_78_638 = {limb_78_637, limb_78_632}; // decl: <none>; prim: <none>
    assign limb_80_639 = s8_norm_add_127_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_80_640 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_80_641 = (~limb_80_640); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_642Core rtlzz_owner_642(.a(64'(limb_80_639)), .b(64'(limb_80_641)), .cin(1'h1), .value(limb_80_642));
    assign limb_80_643 = limb_80_642[63:0]; // decl: <none>; prim: <none>
    assign limb_80_644 = limb_80_642[64]; // decl: <none>; prim: <none>
    assign limb_80_645 = s8_norm_add_127_v0[64]; // decl: <none>; prim: <none>
    assign limb_80_646 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_80_647 = (~limb_80_646); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_648Core rtlzz_owner_648(.a(1'(limb_80_645)), .b(1'(limb_80_647)), .cin(limb_80_644), .value(limb_80_648[0:0]));
    assign limb_80_648[1:1] = '0;
    assign limb_80_649 = limb_80_648[0]; // decl: <none>; prim: <none>
    assign limb_80_650 = {limb_80_649, limb_80_643}; // decl: <none>; prim: <none>
    assign limb_82_651 = tmp_workload_top_int_65__204_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_82_652 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_653Core rtlzz_owner_653(.a(64'(limb_82_651)), .b(64'(limb_82_652)), .cin(1'h0), .value(limb_82_653));
    assign limb_82_654 = limb_82_653[63:0]; // decl: <none>; prim: <none>
    assign limb_82_655 = limb_82_653[64]; // decl: <none>; prim: <none>
    assign limb_82_656 = tmp_workload_top_int_65__204_v0[64]; // decl: <none>; prim: <none>
    assign limb_82_657 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_658Core rtlzz_owner_658(.a(1'(limb_82_656)), .b(1'(limb_82_657)), .cin(limb_82_655), .value(limb_82_658[0:0]));
    assign limb_82_658[1:1] = '0;
    assign limb_82_659 = limb_82_658[0]; // decl: <none>; prim: <none>
    assign limb_82_660 = {limb_82_659, limb_82_654}; // decl: <none>; prim: <none>
    assign limb_83_661 = s8_norm_add_135_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_83_662 = tmp_workload_top_int_65__206_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_83_663 = (~limb_83_662); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_664Core rtlzz_owner_664(.a(64'(limb_83_661)), .b(64'(limb_83_663)), .cin(1'h1), .value(limb_83_664));
    assign limb_83_665 = limb_83_664[63:0]; // decl: <none>; prim: <none>
    assign limb_83_666 = limb_83_664[64]; // decl: <none>; prim: <none>
    assign limb_83_667 = s8_norm_add_135_v0[64]; // decl: <none>; prim: <none>
    assign limb_83_668 = tmp_workload_top_int_65__206_v0[64]; // decl: <none>; prim: <none>
    assign limb_83_669 = (~limb_83_668); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_670Core rtlzz_owner_670(.a(1'(limb_83_667)), .b(1'(limb_83_669)), .cin(limb_83_666), .value(limb_83_670[0:0]));
    assign limb_83_670[1:1] = '0;
    assign limb_83_671 = limb_83_670[0]; // decl: <none>; prim: <none>
    assign limb_83_672 = {limb_83_671, limb_83_665}; // decl: <none>; prim: <none>
    assign limb_85_673 = s8_norm_sub_137_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_85_674 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_85_675 = (~limb_85_674); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_676Core rtlzz_owner_676(.a(64'(limb_85_673)), .b(64'(limb_85_675)), .cin(1'h1), .value(limb_85_676));
    assign limb_85_677 = limb_85_676[63:0]; // decl: <none>; prim: <none>
    assign limb_85_678 = limb_85_676[64]; // decl: <none>; prim: <none>
    assign limb_85_679 = s8_norm_sub_137_v0[64]; // decl: <none>; prim: <none>
    assign limb_85_680 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_85_681 = (~limb_85_680); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_682Core rtlzz_owner_682(.a(1'(limb_85_679)), .b(1'(limb_85_681)), .cin(limb_85_678), .value(limb_85_682[0:0]));
    assign limb_85_682[1:1] = '0;
    assign limb_85_683 = limb_85_682[0]; // decl: <none>; prim: <none>
    assign limb_85_684 = {limb_85_683, limb_85_677}; // decl: <none>; prim: <none>
    assign limb_89_685 = tmp_workload_top_int_65__237_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_89_686 = tmp_workload_top_int_65__239_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_687Core rtlzz_owner_687(.a(64'(limb_89_685)), .b(64'(limb_89_686)), .cin(1'h0), .value(limb_89_687));
    assign limb_89_688 = limb_89_687[63:0]; // decl: <none>; prim: <none>
    assign limb_89_689 = limb_89_687[64]; // decl: <none>; prim: <none>
    assign limb_89_690 = tmp_workload_top_int_65__237_v0[64]; // decl: <none>; prim: <none>
    assign limb_89_691 = tmp_workload_top_int_65__239_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_692Core rtlzz_owner_692(.a(1'(rtlzz_pipe_690_s7)), .b(1'(rtlzz_pipe_691_s7)), .cin(rtlzz_pipe_689_s7), .value(limb_89_692[0:0]));
    assign limb_89_692[1:1] = '0;
    assign limb_89_693 = limb_89_692[0]; // decl: <none>; prim: <none>
    assign limb_89_694 = {limb_89_693, rtlzz_pipe_688_s7}; // decl: <none>; prim: <none>
    assign limb_91_695 = s8_norm_add_147_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_91_696 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_91_697 = (~limb_91_696); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_698Core rtlzz_owner_698(.a(64'(rtlzz_pipe_695_s8)), .b(64'(limb_91_697)), .cin(1'h1), .value(limb_91_698));
    assign limb_91_699 = limb_91_698[63:0]; // decl: <none>; prim: <none>
    assign limb_91_700 = limb_91_698[64]; // decl: <none>; prim: <none>
    assign limb_91_701 = s8_norm_add_147_v0[64]; // decl: <none>; prim: <none>
    assign limb_91_702 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_91_703 = (~limb_91_702); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_704Core rtlzz_owner_704(.a(1'(rtlzz_pipe_701_s9)), .b(1'(limb_91_703)), .cin(rtlzz_pipe_700_s9), .value(limb_91_704[0:0]));
    assign limb_91_704[1:1] = '0;
    assign limb_91_705 = limb_91_704[0]; // decl: <none>; prim: <none>
    assign limb_91_706 = {limb_91_705, rtlzz_pipe_699_s9}; // decl: <none>; prim: <none>
    assign limb_93_707 = tmp_workload_top_int_65__237_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_93_708 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_709Core rtlzz_owner_709(.a(64'(limb_93_707)), .b(64'(limb_93_708)), .cin(1'h0), .value(limb_93_709));
    assign limb_93_710 = limb_93_709[63:0]; // decl: <none>; prim: <none>
    assign limb_93_711 = limb_93_709[64]; // decl: <none>; prim: <none>
    assign limb_93_712 = tmp_workload_top_int_65__237_v0[64]; // decl: <none>; prim: <none>
    assign limb_93_713 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_714Core rtlzz_owner_714(.a(1'(rtlzz_pipe_712_s8)), .b(1'(limb_93_713)), .cin(rtlzz_pipe_711_s8), .value(limb_93_714[0:0]));
    assign limb_93_714[1:1] = '0;
    assign limb_93_715 = limb_93_714[0]; // decl: <none>; prim: <none>
    assign limb_93_716 = {limb_93_715, rtlzz_pipe_710_s8}; // decl: <none>; prim: <none>
    assign limb_94_717 = s8_norm_add_155_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_94_718 = tmp_workload_top_int_65__239_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_94_719 = (~rtlzz_pipe_718_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_720Core rtlzz_owner_720(.a(64'(rtlzz_pipe_717_s12)), .b(64'(rtlzz_pipe_719_s12)), .cin(1'h1), .value(limb_94_720));
    assign limb_94_721 = limb_94_720[63:0]; // decl: <none>; prim: <none>
    assign limb_94_722 = limb_94_720[64]; // decl: <none>; prim: <none>
    assign limb_94_723 = s8_norm_add_155_v0[64]; // decl: <none>; prim: <none>
    assign limb_94_724 = tmp_workload_top_int_65__239_v0[64]; // decl: <none>; prim: <none>
    assign limb_94_725 = (~rtlzz_pipe_724_s13); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_726Core rtlzz_owner_726(.a(1'(rtlzz_pipe_723_s13)), .b(1'(limb_94_725)), .cin(rtlzz_pipe_722_s13), .value(limb_94_726[0:0]));
    assign limb_94_726[1:1] = '0;
    assign limb_94_727 = limb_94_726[0]; // decl: <none>; prim: <none>
    assign limb_94_728 = {limb_94_727, rtlzz_pipe_721_s13}; // decl: <none>; prim: <none>
    assign limb_96_729 = s8_norm_sub_157_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_96_730 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_96_731 = (~limb_96_730); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_732Core rtlzz_owner_732(.a(64'(limb_96_729)), .b(64'(limb_96_731)), .cin(1'h1), .value(limb_96_732));
    assign limb_96_733 = limb_96_732[63:0]; // decl: <none>; prim: <none>
    assign limb_96_734 = limb_96_732[64]; // decl: <none>; prim: <none>
    assign limb_96_735 = s8_norm_sub_157_v0[64]; // decl: <none>; prim: <none>
    assign limb_96_736 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_96_737 = (~limb_96_736); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_738Core rtlzz_owner_738(.a(1'(limb_96_735)), .b(1'(limb_96_737)), .cin(limb_96_734), .value(limb_96_738[0:0]));
    assign limb_96_738[1:1] = '0;
    assign limb_96_739 = limb_96_738[0]; // decl: <none>; prim: <none>
    assign limb_96_740 = {limb_96_739, limb_96_733}; // decl: <none>; prim: <none>
    assign limb_106_741 = tmp_workload_top_int_129__288_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_106_742 = n56_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_106_743 = (~limb_106_742); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_744Core rtlzz_owner_744(.a(64'(limb_106_741)), .b(64'(limb_106_743)), .cin(1'h1), .value(limb_106_744));
    assign limb_106_745 = limb_106_744[63:0]; // decl: <none>; prim: <none>
    assign limb_106_746 = limb_106_744[64]; // decl: <none>; prim: <none>
    assign limb_106_747 = tmp_workload_top_int_129__288_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_106_748 = n56_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_106_749 = (~limb_106_748); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_750Core rtlzz_owner_750(.a(64'(limb_106_747)), .b(64'(limb_106_749)), .cin(limb_106_746), .value(limb_106_750));
    assign limb_106_751 = limb_106_750[63:0]; // decl: <none>; prim: <none>
    assign limb_106_752 = limb_106_750[64]; // decl: <none>; prim: <none>
    assign limb_106_753 = tmp_workload_top_int_129__288_v0[128]; // decl: <none>; prim: <none>
    assign limb_106_754 = n56_v0[128]; // decl: <none>; prim: <none>
    assign limb_106_755 = (~limb_106_754); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_756Core rtlzz_owner_756(.a(1'(limb_106_753)), .b(1'(limb_106_755)), .cin(limb_106_752), .value(limb_106_756[0:0]));
    assign limb_106_756[1:1] = '0;
    assign limb_106_757 = limb_106_756[0]; // decl: <none>; prim: <none>
    assign limb_106_758 = {limb_106_757, limb_106_751, limb_106_745}; // decl: <none>; prim: <none>
    assign limb_108_759 = s8_norm_sub_179_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_108_760 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_108_761 = (~limb_108_760); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_762Core rtlzz_owner_762(.a(64'(limb_108_759)), .b(64'(limb_108_761)), .cin(1'h1), .value(limb_108_762));
    assign limb_108_763 = limb_108_762[63:0]; // decl: <none>; prim: <none>
    assign limb_108_764 = limb_108_762[64]; // decl: <none>; prim: <none>
    assign limb_108_765 = s8_norm_sub_179_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_108_766 = 64'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_108_767 = (~limb_108_766); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_768Core rtlzz_owner_768(.a(64'(limb_108_765)), .b(64'(limb_108_767)), .cin(limb_108_764), .value(limb_108_768[0:0]));
    assign limb_108_768[64:1] = '0;
    assign limb_108_769 = limb_108_768[63:0]; // decl: <none>; prim: <none>
    assign limb_108_770 = limb_108_768[64]; // decl: <none>; prim: <none>
    assign limb_108_771 = s8_norm_sub_179_v0[128]; // decl: <none>; prim: <none>
    assign limb_108_772 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_108_773 = (~limb_108_772); // decl: <none>; prim: <none>
    assign limb_108_774 = 2'((({1'h0, limb_108_771}) + ({1'h0, limb_108_773}) + ({1'h0, limb_108_770}))); // decl: <none>; prim: <none>
    assign limb_108_775 = limb_108_774[0]; // decl: <none>; prim: <none>
    assign limb_108_776 = {limb_108_775, limb_108_769, limb_108_763}; // decl: <none>; prim: <none>
    assign limb_112_777 = tmp_workload_top_int_65__301_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_112_778 = tmp_workload_top_int_65__303_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_779Core rtlzz_owner_779(.a(64'(rtlzz_pipe_777_s15)), .b(64'(limb_112_778)), .cin(1'h0), .value(limb_112_779));
    assign limb_112_780 = limb_112_779[63:0]; // decl: <none>; prim: <none>
    assign limb_112_781 = limb_112_779[64]; // decl: <none>; prim: <none>
    assign limb_112_782 = tmp_workload_top_int_65__301_v0[64]; // decl: <none>; prim: <none>
    assign limb_112_783 = tmp_workload_top_int_65__303_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_784Core rtlzz_owner_784(.a(1'(rtlzz_pipe_782_s15)), .b(1'(limb_112_783)), .cin(limb_112_781), .value(limb_112_784[0:0]));
    assign limb_112_784[1:1] = '0;
    assign limb_112_785 = limb_112_784[0]; // decl: <none>; prim: <none>
    assign limb_112_786 = {limb_112_785, limb_112_780}; // decl: <none>; prim: <none>
    assign limb_114_787 = s8_norm_add_188_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_114_788 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_114_789 = (~limb_114_788); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_790Core rtlzz_owner_790(.a(64'(limb_114_787)), .b(64'(limb_114_789)), .cin(1'h1), .value(limb_114_790));
    assign limb_114_791 = limb_114_790[63:0]; // decl: <none>; prim: <none>
    assign limb_114_792 = limb_114_790[64]; // decl: <none>; prim: <none>
    assign limb_114_793 = s8_norm_add_188_v0[64]; // decl: <none>; prim: <none>
    assign limb_114_794 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_114_795 = (~limb_114_794); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_796Core rtlzz_owner_796(.a(1'(limb_114_793)), .b(1'(limb_114_795)), .cin(limb_114_792), .value(limb_114_796[0:0]));
    assign limb_114_796[1:1] = '0;
    assign limb_114_797 = limb_114_796[0]; // decl: <none>; prim: <none>
    assign limb_114_798 = {limb_114_797, limb_114_791}; // decl: <none>; prim: <none>
    assign limb_116_799 = tmp_workload_top_int_65__301_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_116_800 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_801Core rtlzz_owner_801(.a(64'(limb_116_799)), .b(64'(limb_116_800)), .cin(1'h0), .value(limb_116_801));
    assign limb_116_802 = limb_116_801[63:0]; // decl: <none>; prim: <none>
    assign limb_116_803 = limb_116_801[64]; // decl: <none>; prim: <none>
    assign limb_116_804 = tmp_workload_top_int_65__301_v0[64]; // decl: <none>; prim: <none>
    assign limb_116_805 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_806Core rtlzz_owner_806(.a(1'(limb_116_804)), .b(1'(limb_116_805)), .cin(limb_116_803), .value(limb_116_806[0:0]));
    assign limb_116_806[1:1] = '0;
    assign limb_116_807 = limb_116_806[0]; // decl: <none>; prim: <none>
    assign limb_116_808 = {limb_116_807, limb_116_802}; // decl: <none>; prim: <none>
    assign limb_117_809 = s8_norm_add_196_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_117_810 = tmp_workload_top_int_65__303_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_117_811 = (~limb_117_810); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_812Core rtlzz_owner_812(.a(64'(rtlzz_pipe_809_s15)), .b(64'(limb_117_811)), .cin(1'h1), .value(limb_117_812));
    assign limb_117_813 = limb_117_812[63:0]; // decl: <none>; prim: <none>
    assign limb_117_814 = limb_117_812[64]; // decl: <none>; prim: <none>
    assign limb_117_815 = s8_norm_add_196_v0[64]; // decl: <none>; prim: <none>
    assign limb_117_816 = tmp_workload_top_int_65__303_v0[64]; // decl: <none>; prim: <none>
    assign limb_117_817 = (~limb_117_816); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_818Core rtlzz_owner_818(.a(1'(rtlzz_pipe_815_s15)), .b(1'(limb_117_817)), .cin(limb_117_814), .value(limb_117_818[0:0]));
    assign limb_117_818[1:1] = '0;
    assign limb_117_819 = limb_117_818[0]; // decl: <none>; prim: <none>
    assign limb_117_820 = {limb_117_819, limb_117_813}; // decl: <none>; prim: <none>
    assign limb_119_821 = s8_norm_sub_198_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_119_822 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_119_823 = (~limb_119_822); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_824Core rtlzz_owner_824(.a(64'(limb_119_821)), .b(64'(limb_119_823)), .cin(1'h1), .value(limb_119_824));
    assign limb_119_825 = limb_119_824[63:0]; // decl: <none>; prim: <none>
    assign limb_119_826 = limb_119_824[64]; // decl: <none>; prim: <none>
    assign limb_119_827 = s8_norm_sub_198_v0[64]; // decl: <none>; prim: <none>
    assign limb_119_828 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_119_829 = (~limb_119_828); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_830Core rtlzz_owner_830(.a(1'(limb_119_827)), .b(1'(limb_119_829)), .cin(limb_119_826), .value(limb_119_830[0:0]));
    assign limb_119_830[1:1] = '0;
    assign limb_119_831 = limb_119_830[0]; // decl: <none>; prim: <none>
    assign limb_119_832 = {limb_119_831, limb_119_825}; // decl: <none>; prim: <none>
    assign limb_123_833 = tmp_workload_top_int_65__334_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_123_834 = tmp_workload_top_int_65__336_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_835Core rtlzz_owner_835(.a(64'(rtlzz_pipe_833_s10)), .b(64'(limb_123_834)), .cin(1'h0), .value(limb_123_835));
    assign limb_123_836 = limb_123_835[63:0]; // decl: <none>; prim: <none>
    assign limb_123_837 = limb_123_835[64]; // decl: <none>; prim: <none>
    assign limb_123_838 = tmp_workload_top_int_65__334_v0[64]; // decl: <none>; prim: <none>
    assign limb_123_839 = tmp_workload_top_int_65__336_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_840Core rtlzz_owner_840(.a(1'(rtlzz_pipe_838_s10)), .b(1'(limb_123_839)), .cin(limb_123_837), .value(limb_123_840[0:0]));
    assign limb_123_840[1:1] = '0;
    assign limb_123_841 = limb_123_840[0]; // decl: <none>; prim: <none>
    assign limb_123_842 = {limb_123_841, limb_123_836}; // decl: <none>; prim: <none>
    assign limb_125_843 = s8_norm_add_208_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_125_844 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_125_845 = (~limb_125_844); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_846Core rtlzz_owner_846(.a(64'(rtlzz_pipe_843_s12)), .b(64'(limb_125_845)), .cin(1'h1), .value(limb_125_846[63:0]));
    assign limb_125_846[64:64] = '0;
    assign limb_125_847 = limb_125_846[63:0]; // decl: <none>; prim: <none>
    assign limb_125_848 = limb_125_846[64]; // decl: <none>; prim: <none>
    assign limb_125_849 = s8_norm_add_208_v0[64]; // decl: <none>; prim: <none>
    assign limb_125_850 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_125_851 = (~limb_125_850); // decl: <none>; prim: <none>
    assign limb_125_852 = 2'((({1'h0, rtlzz_pipe_849_s12}) + ({1'h0, limb_125_851}) + ({1'h0, limb_125_848}))); // decl: <none>; prim: <none>
    assign limb_125_853 = limb_125_852[0]; // decl: <none>; prim: <none>
    assign limb_125_854 = {limb_125_853, limb_125_847}; // decl: <none>; prim: <none>
    assign limb_127_855 = tmp_workload_top_int_65__334_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_127_856 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_857Core rtlzz_owner_857(.a(64'(limb_127_855)), .b(64'(limb_127_856)), .cin(1'h0), .value(limb_127_857));
    assign limb_127_858 = limb_127_857[63:0]; // decl: <none>; prim: <none>
    assign limb_127_859 = limb_127_857[64]; // decl: <none>; prim: <none>
    assign limb_127_860 = tmp_workload_top_int_65__334_v0[64]; // decl: <none>; prim: <none>
    assign limb_127_861 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_862Core rtlzz_owner_862(.a(1'(limb_127_860)), .b(1'(limb_127_861)), .cin(limb_127_859), .value(limb_127_862[0:0]));
    assign limb_127_862[1:1] = '0;
    assign limb_127_863 = limb_127_862[0]; // decl: <none>; prim: <none>
    assign limb_127_864 = {limb_127_863, limb_127_858}; // decl: <none>; prim: <none>
    assign limb_128_865 = s8_norm_add_216_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_128_866 = tmp_workload_top_int_65__336_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_128_867 = (~rtlzz_pipe_866_s11); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_868Core rtlzz_owner_868(.a(64'(rtlzz_pipe_865_s11)), .b(64'(limb_128_867)), .cin(1'h1), .value(limb_128_868));
    assign limb_128_869 = limb_128_868[63:0]; // decl: <none>; prim: <none>
    assign limb_128_870 = limb_128_868[64]; // decl: <none>; prim: <none>
    assign limb_128_871 = s8_norm_add_216_v0[64]; // decl: <none>; prim: <none>
    assign limb_128_872 = tmp_workload_top_int_65__336_v0[64]; // decl: <none>; prim: <none>
    assign limb_128_873 = (~limb_128_872); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_874Core rtlzz_owner_874(.a(1'(rtlzz_pipe_871_s11)), .b(1'(rtlzz_pipe_873_s11)), .cin(limb_128_870), .value(limb_128_874[0:0]));
    assign limb_128_874[1:1] = '0;
    assign limb_128_875 = limb_128_874[0]; // decl: <none>; prim: <none>
    assign limb_128_876 = {limb_128_875, limb_128_869}; // decl: <none>; prim: <none>
    assign limb_130_877 = s8_norm_sub_218_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_130_878 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_130_879 = (~limb_130_878); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_880Core rtlzz_owner_880(.a(64'(limb_130_877)), .b(64'(limb_130_879)), .cin(1'h1), .value(limb_130_880[63:0]));
    assign limb_130_880[64:64] = '0;
    assign limb_130_881 = limb_130_880[63:0]; // decl: <none>; prim: <none>
    assign limb_130_882 = limb_130_880[64]; // decl: <none>; prim: <none>
    assign limb_130_883 = s8_norm_sub_218_v0[64]; // decl: <none>; prim: <none>
    assign limb_130_884 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_130_885 = (~limb_130_884); // decl: <none>; prim: <none>
    assign limb_130_886 = 2'((({1'h0, rtlzz_pipe_883_s12}) + ({1'h0, limb_130_885}) + ({1'h0, rtlzz_pipe_882_s12}))); // decl: <none>; prim: <none>
    assign limb_130_887 = limb_130_886[0]; // decl: <none>; prim: <none>
    assign limb_130_888 = {limb_130_887, rtlzz_pipe_881_s12}; // decl: <none>; prim: <none>
    assign limb_142_889 = tmp_workload_top_int_129__385_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_142_890 = n76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_142_891 = (~limb_142_890); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_892Core rtlzz_owner_892(.a(64'(limb_142_889)), .b(64'(limb_142_891)), .cin(1'h1), .value(limb_142_892));
    assign limb_142_893 = limb_142_892[63:0]; // decl: <none>; prim: <none>
    assign limb_142_894 = limb_142_892[64]; // decl: <none>; prim: <none>
    assign limb_142_895 = tmp_workload_top_int_129__385_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_142_896 = n76_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_142_897 = (~limb_142_896); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_898Core rtlzz_owner_898(.a(64'(limb_142_895)), .b(64'(limb_142_897)), .cin(limb_142_894), .value(limb_142_898));
    assign limb_142_899 = limb_142_898[63:0]; // decl: <none>; prim: <none>
    assign limb_142_900 = limb_142_898[64]; // decl: <none>; prim: <none>
    assign limb_142_901 = tmp_workload_top_int_129__385_v0[128]; // decl: <none>; prim: <none>
    assign limb_142_902 = n76_v0[128]; // decl: <none>; prim: <none>
    assign limb_142_903 = (~limb_142_902); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_904Core rtlzz_owner_904(.a(1'(limb_142_901)), .b(1'(limb_142_903)), .cin(limb_142_900), .value(limb_142_904[0:0]));
    assign limb_142_904[1:1] = '0;
    assign limb_142_905 = limb_142_904[0]; // decl: <none>; prim: <none>
    assign limb_142_906 = {limb_142_905, limb_142_899, limb_142_893}; // decl: <none>; prim: <none>
    assign limb_144_907 = s8_norm_sub_240_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_144_908 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_144_909 = (~limb_144_908); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_910Core rtlzz_owner_910(.a(64'(limb_144_907)), .b(64'(limb_144_909)), .cin(1'h1), .value(limb_144_910));
    assign limb_144_911 = limb_144_910[63:0]; // decl: <none>; prim: <none>
    assign limb_144_912 = limb_144_910[64]; // decl: <none>; prim: <none>
    assign limb_144_913 = s8_norm_sub_240_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_144_914 = 64'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_144_915 = (~limb_144_914); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_916Core rtlzz_owner_916(.a(64'(limb_144_913)), .b(64'(limb_144_915)), .cin(limb_144_912), .value(limb_144_916[0:0]));
    assign limb_144_916[64:1] = '0;
    assign limb_144_917 = limb_144_916[63:0]; // decl: <none>; prim: <none>
    assign limb_144_918 = limb_144_916[64]; // decl: <none>; prim: <none>
    assign limb_144_919 = s8_norm_sub_240_v0[128]; // decl: <none>; prim: <none>
    assign limb_144_920 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_144_921 = (~limb_144_920); // decl: <none>; prim: <none>
    assign limb_144_922 = 2'((({1'h0, limb_144_919}) + ({1'h0, limb_144_921}) + ({1'h0, limb_144_918}))); // decl: <none>; prim: <none>
    assign limb_144_923 = limb_144_922[0]; // decl: <none>; prim: <none>
    assign limb_144_924 = {limb_144_923, limb_144_917, limb_144_911}; // decl: <none>; prim: <none>
    assign limb_148_925 = tmp_workload_top_int_65__398_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_148_926 = tmp_workload_top_int_65__400_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_927Core rtlzz_owner_927(.a(64'(limb_148_925)), .b(64'(limb_148_926)), .cin(1'h0), .value(limb_148_927));
    assign limb_148_928 = limb_148_927[63:0]; // decl: <none>; prim: <none>
    assign limb_148_929 = limb_148_927[64]; // decl: <none>; prim: <none>
    assign limb_148_930 = tmp_workload_top_int_65__398_v0[64]; // decl: <none>; prim: <none>
    assign limb_148_931 = tmp_workload_top_int_65__400_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_932Core rtlzz_owner_932(.a(1'(limb_148_930)), .b(1'(limb_148_931)), .cin(limb_148_929), .value(limb_148_932[0:0]));
    assign limb_148_932[1:1] = '0;
    assign limb_148_933 = limb_148_932[0]; // decl: <none>; prim: <none>
    assign limb_148_934 = {limb_148_933, limb_148_928}; // decl: <none>; prim: <none>
    assign limb_150_935 = s8_norm_add_249_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_150_936 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_150_937 = (~limb_150_936); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_938Core rtlzz_owner_938(.a(64'(limb_150_935)), .b(64'(limb_150_937)), .cin(1'h1), .value(limb_150_938[63:0]));
    assign limb_150_938[64:64] = '0;
    assign limb_150_939 = limb_150_938[63:0]; // decl: <none>; prim: <none>
    assign limb_150_940 = limb_150_938[64]; // decl: <none>; prim: <none>
    assign limb_150_941 = s8_norm_add_249_v0[64]; // decl: <none>; prim: <none>
    assign limb_150_942 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_150_943 = (~limb_150_942); // decl: <none>; prim: <none>
    assign limb_150_944 = 2'((({1'h0, limb_150_941}) + ({1'h0, limb_150_943}) + ({1'h0, limb_150_940}))); // decl: <none>; prim: <none>
    assign limb_150_945 = limb_150_944[0]; // decl: <none>; prim: <none>
    assign limb_150_946 = {limb_150_945, limb_150_939}; // decl: <none>; prim: <none>
    assign limb_152_947 = tmp_workload_top_int_65__398_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_152_948 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_949Core rtlzz_owner_949(.a(64'(limb_152_947)), .b(64'(limb_152_948)), .cin(1'h0), .value(limb_152_949));
    assign limb_152_950 = limb_152_949[63:0]; // decl: <none>; prim: <none>
    assign limb_152_951 = limb_152_949[64]; // decl: <none>; prim: <none>
    assign limb_152_952 = tmp_workload_top_int_65__398_v0[64]; // decl: <none>; prim: <none>
    assign limb_152_953 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_954Core rtlzz_owner_954(.a(1'(limb_152_952)), .b(1'(limb_152_953)), .cin(limb_152_951), .value(limb_152_954[0:0]));
    assign limb_152_954[1:1] = '0;
    assign limb_152_955 = limb_152_954[0]; // decl: <none>; prim: <none>
    assign limb_152_956 = {limb_152_955, limb_152_950}; // decl: <none>; prim: <none>
    assign limb_153_957 = s8_norm_add_257_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_153_958 = tmp_workload_top_int_65__400_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_153_959 = (~limb_153_958); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_960Core rtlzz_owner_960(.a(64'(limb_153_957)), .b(64'(limb_153_959)), .cin(1'h1), .value(limb_153_960));
    assign limb_153_961 = limb_153_960[63:0]; // decl: <none>; prim: <none>
    assign limb_153_962 = limb_153_960[64]; // decl: <none>; prim: <none>
    assign limb_153_963 = s8_norm_add_257_v0[64]; // decl: <none>; prim: <none>
    assign limb_153_964 = tmp_workload_top_int_65__400_v0[64]; // decl: <none>; prim: <none>
    assign limb_153_965 = (~limb_153_964); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_966Core rtlzz_owner_966(.a(1'(limb_153_963)), .b(1'(limb_153_965)), .cin(limb_153_962), .value(limb_153_966[0:0]));
    assign limb_153_966[1:1] = '0;
    assign limb_153_967 = limb_153_966[0]; // decl: <none>; prim: <none>
    assign limb_153_968 = {limb_153_967, limb_153_961}; // decl: <none>; prim: <none>
    assign limb_155_969 = s8_norm_sub_259_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_155_970 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_155_971 = (~limb_155_970); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_972Core rtlzz_owner_972(.a(64'(limb_155_969)), .b(64'(limb_155_971)), .cin(1'h1), .value(limb_155_972[63:0]));
    assign limb_155_972[64:64] = '0;
    assign limb_155_973 = limb_155_972[63:0]; // decl: <none>; prim: <none>
    assign limb_155_974 = limb_155_972[64]; // decl: <none>; prim: <none>
    assign limb_155_975 = s8_norm_sub_259_v0[64]; // decl: <none>; prim: <none>
    assign limb_155_976 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_155_977 = (~limb_155_976); // decl: <none>; prim: <none>
    assign limb_155_978 = 2'((({1'h0, limb_155_975}) + ({1'h0, limb_155_977}) + ({1'h0, limb_155_974}))); // decl: <none>; prim: <none>
    assign limb_155_979 = limb_155_978[0]; // decl: <none>; prim: <none>
    assign limb_155_980 = {limb_155_979, limb_155_973}; // decl: <none>; prim: <none>
    assign limb_167_981 = tmp_workload_top_int_129__449_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_167_982 = n90_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_167_983 = (~limb_167_982); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_984Core rtlzz_owner_984(.a(64'(limb_167_981)), .b(64'(limb_167_983)), .cin(1'h1), .value(limb_167_984));
    assign limb_167_985 = limb_167_984[63:0]; // decl: <none>; prim: <none>
    assign limb_167_986 = limb_167_984[64]; // decl: <none>; prim: <none>
    assign limb_167_987 = tmp_workload_top_int_129__449_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_167_988 = n90_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_167_989 = (~limb_167_988); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_990Core rtlzz_owner_990(.a(64'(limb_167_987)), .b(64'(limb_167_989)), .cin(limb_167_986), .value(limb_167_990));
    assign limb_167_991 = limb_167_990[63:0]; // decl: <none>; prim: <none>
    assign limb_167_992 = limb_167_990[64]; // decl: <none>; prim: <none>
    assign limb_167_993 = tmp_workload_top_int_129__449_v0[128]; // decl: <none>; prim: <none>
    assign limb_167_994 = n90_v0[128]; // decl: <none>; prim: <none>
    assign limb_167_995 = (~limb_167_994); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_996Core rtlzz_owner_996(.a(1'(limb_167_993)), .b(1'(limb_167_995)), .cin(limb_167_992), .value(limb_167_996[0:0]));
    assign limb_167_996[1:1] = '0;
    assign limb_167_997 = limb_167_996[0]; // decl: <none>; prim: <none>
    assign limb_167_998 = {limb_167_997, limb_167_991, limb_167_985}; // decl: <none>; prim: <none>
    assign limb_169_999 = s8_norm_sub_281_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_169_1000 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_169_1001 = (~limb_169_1000); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1002Core rtlzz_owner_1002(.a(64'(limb_169_999)), .b(64'(limb_169_1001)), .cin(1'h1), .value(limb_169_1002));
    assign limb_169_1003 = limb_169_1002[63:0]; // decl: <none>; prim: <none>
    assign limb_169_1004 = limb_169_1002[64]; // decl: <none>; prim: <none>
    assign limb_169_1005 = s8_norm_sub_281_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_169_1006 = 64'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_169_1007 = (~limb_169_1006); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1008Core rtlzz_owner_1008(.a(64'(limb_169_1005)), .b(64'(limb_169_1007)), .cin(limb_169_1004), .value(limb_169_1008[0:0]));
    assign limb_169_1008[64:1] = '0;
    assign limb_169_1009 = limb_169_1008[63:0]; // decl: <none>; prim: <none>
    assign limb_169_1010 = limb_169_1008[64]; // decl: <none>; prim: <none>
    assign limb_169_1011 = s8_norm_sub_281_v0[128]; // decl: <none>; prim: <none>
    assign limb_169_1012 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_169_1013 = (~limb_169_1012); // decl: <none>; prim: <none>
    assign limb_169_1014 = 2'((({1'h0, limb_169_1011}) + ({1'h0, limb_169_1013}) + ({1'h0, limb_169_1010}))); // decl: <none>; prim: <none>
    assign limb_169_1015 = limb_169_1014[0]; // decl: <none>; prim: <none>
    assign limb_169_1016 = {limb_169_1015, limb_169_1009, limb_169_1003}; // decl: <none>; prim: <none>
    assign limb_173_1017 = tmp_workload_top_int_65__462_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_173_1018 = tmp_workload_top_int_65__464_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1019Core rtlzz_owner_1019(.a(64'(rtlzz_pipe_1017_s14)), .b(64'(limb_173_1018)), .cin(1'h0), .value(limb_173_1019));
    assign limb_173_1020 = limb_173_1019[63:0]; // decl: <none>; prim: <none>
    assign limb_173_1021 = limb_173_1019[64]; // decl: <none>; prim: <none>
    assign limb_173_1022 = tmp_workload_top_int_65__462_v0[64]; // decl: <none>; prim: <none>
    assign limb_173_1023 = tmp_workload_top_int_65__464_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1024Core rtlzz_owner_1024(.a(1'(rtlzz_pipe_1022_s14)), .b(1'(limb_173_1023)), .cin(limb_173_1021), .value(limb_173_1024[0:0]));
    assign limb_173_1024[1:1] = '0;
    assign limb_173_1025 = limb_173_1024[0]; // decl: <none>; prim: <none>
    assign limb_173_1026 = {limb_173_1025, limb_173_1020}; // decl: <none>; prim: <none>
    assign limb_175_1027 = s8_norm_add_290_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_175_1028 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_175_1029 = (~limb_175_1028); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1030Core rtlzz_owner_1030(.a(64'(limb_175_1027)), .b(64'(limb_175_1029)), .cin(1'h1), .value(limb_175_1030[63:0]));
    assign limb_175_1030[64:64] = '0;
    assign limb_175_1031 = limb_175_1030[63:0]; // decl: <none>; prim: <none>
    assign limb_175_1032 = limb_175_1030[64]; // decl: <none>; prim: <none>
    assign limb_175_1033 = s8_norm_add_290_v0[64]; // decl: <none>; prim: <none>
    assign limb_175_1034 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_175_1035 = (~limb_175_1034); // decl: <none>; prim: <none>
    assign limb_175_1036 = 2'((({1'h0, limb_175_1033}) + ({1'h0, limb_175_1035}) + ({1'h0, limb_175_1032}))); // decl: <none>; prim: <none>
    assign limb_175_1037 = limb_175_1036[0]; // decl: <none>; prim: <none>
    assign limb_175_1038 = {limb_175_1037, limb_175_1031}; // decl: <none>; prim: <none>
    assign limb_177_1039 = tmp_workload_top_int_65__462_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_177_1040 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1041Core rtlzz_owner_1041(.a(64'(limb_177_1039)), .b(64'(limb_177_1040)), .cin(1'h0), .value(limb_177_1041));
    assign limb_177_1042 = limb_177_1041[63:0]; // decl: <none>; prim: <none>
    assign limb_177_1043 = limb_177_1041[64]; // decl: <none>; prim: <none>
    assign limb_177_1044 = tmp_workload_top_int_65__462_v0[64]; // decl: <none>; prim: <none>
    assign limb_177_1045 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1046Core rtlzz_owner_1046(.a(1'(limb_177_1044)), .b(1'(limb_177_1045)), .cin(limb_177_1043), .value(limb_177_1046[0:0]));
    assign limb_177_1046[1:1] = '0;
    assign limb_177_1047 = limb_177_1046[0]; // decl: <none>; prim: <none>
    assign limb_177_1048 = {limb_177_1047, limb_177_1042}; // decl: <none>; prim: <none>
    assign limb_178_1049 = s8_norm_add_298_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_178_1050 = tmp_workload_top_int_65__464_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_178_1051 = (~limb_178_1050); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1052Core rtlzz_owner_1052(.a(64'(rtlzz_pipe_1049_s14)), .b(64'(limb_178_1051)), .cin(1'h1), .value(limb_178_1052));
    assign limb_178_1053 = limb_178_1052[63:0]; // decl: <none>; prim: <none>
    assign limb_178_1054 = limb_178_1052[64]; // decl: <none>; prim: <none>
    assign limb_178_1055 = s8_norm_add_298_v0[64]; // decl: <none>; prim: <none>
    assign limb_178_1056 = tmp_workload_top_int_65__464_v0[64]; // decl: <none>; prim: <none>
    assign limb_178_1057 = (~limb_178_1056); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1058Core rtlzz_owner_1058(.a(1'(rtlzz_pipe_1055_s14)), .b(1'(limb_178_1057)), .cin(limb_178_1054), .value(limb_178_1058[0:0]));
    assign limb_178_1058[1:1] = '0;
    assign limb_178_1059 = limb_178_1058[0]; // decl: <none>; prim: <none>
    assign limb_178_1060 = {limb_178_1059, limb_178_1053}; // decl: <none>; prim: <none>
    assign limb_180_1061 = s8_norm_sub_300_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_180_1062 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_180_1063 = (~limb_180_1062); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1064Core rtlzz_owner_1064(.a(64'(limb_180_1061)), .b(64'(limb_180_1063)), .cin(1'h1), .value(limb_180_1064[63:0]));
    assign limb_180_1064[64:64] = '0;
    assign limb_180_1065 = limb_180_1064[63:0]; // decl: <none>; prim: <none>
    assign limb_180_1066 = limb_180_1064[64]; // decl: <none>; prim: <none>
    assign limb_180_1067 = s8_norm_sub_300_v0[64]; // decl: <none>; prim: <none>
    assign limb_180_1068 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_180_1069 = (~limb_180_1068); // decl: <none>; prim: <none>
    assign limb_180_1070 = 2'((({1'h0, limb_180_1067}) + ({1'h0, limb_180_1069}) + ({1'h0, limb_180_1066}))); // decl: <none>; prim: <none>
    assign limb_180_1071 = limb_180_1070[0]; // decl: <none>; prim: <none>
    assign limb_180_1072 = {limb_180_1071, limb_180_1065}; // decl: <none>; prim: <none>
    assign limb_192_1073 = tmp_workload_top_int_129__513_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_192_1074 = n104_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_192_1075 = (~limb_192_1074); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1076Core rtlzz_owner_1076(.a(64'(limb_192_1073)), .b(64'(limb_192_1075)), .cin(1'h1), .value(limb_192_1076));
    assign limb_192_1077 = limb_192_1076[63:0]; // decl: <none>; prim: <none>
    assign limb_192_1078 = limb_192_1076[64]; // decl: <none>; prim: <none>
    assign limb_192_1079 = tmp_workload_top_int_129__513_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_192_1080 = n104_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_192_1081 = (~limb_192_1080); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1082Core rtlzz_owner_1082(.a(64'(limb_192_1079)), .b(64'(limb_192_1081)), .cin(limb_192_1078), .value(limb_192_1082));
    assign limb_192_1083 = limb_192_1082[63:0]; // decl: <none>; prim: <none>
    assign limb_192_1084 = limb_192_1082[64]; // decl: <none>; prim: <none>
    assign limb_192_1085 = tmp_workload_top_int_129__513_v0[128]; // decl: <none>; prim: <none>
    assign limb_192_1086 = n104_v0[128]; // decl: <none>; prim: <none>
    assign limb_192_1087 = (~limb_192_1086); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1088Core rtlzz_owner_1088(.a(1'(limb_192_1085)), .b(1'(limb_192_1087)), .cin(limb_192_1084), .value(limb_192_1088[0:0]));
    assign limb_192_1088[1:1] = '0;
    assign limb_192_1089 = limb_192_1088[0]; // decl: <none>; prim: <none>
    assign limb_192_1090 = {limb_192_1089, limb_192_1083, limb_192_1077}; // decl: <none>; prim: <none>
    assign limb_194_1091 = s8_norm_sub_322_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_194_1092 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_194_1093 = (~limb_194_1092); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1094Core rtlzz_owner_1094(.a(64'(limb_194_1091)), .b(64'(limb_194_1093)), .cin(1'h1), .value(limb_194_1094));
    assign limb_194_1095 = limb_194_1094[63:0]; // decl: <none>; prim: <none>
    assign limb_194_1096 = limb_194_1094[64]; // decl: <none>; prim: <none>
    assign limb_194_1097 = s8_norm_sub_322_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_194_1098 = 64'((129'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_194_1099 = (~limb_194_1098); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1100Core rtlzz_owner_1100(.a(64'(limb_194_1097)), .b(64'(limb_194_1099)), .cin(limb_194_1096), .value(limb_194_1100[0:0]));
    assign limb_194_1100[64:1] = '0;
    assign limb_194_1101 = limb_194_1100[63:0]; // decl: <none>; prim: <none>
    assign limb_194_1102 = limb_194_1100[64]; // decl: <none>; prim: <none>
    assign limb_194_1103 = s8_norm_sub_322_v0[128]; // decl: <none>; prim: <none>
    assign limb_194_1104 = 1'((129'hffffffff00000001) >> 128); // decl: <none>; prim: <none>
    assign limb_194_1105 = (~limb_194_1104); // decl: <none>; prim: <none>
    assign limb_194_1106 = 2'((({1'h0, limb_194_1103}) + ({1'h0, limb_194_1105}) + ({1'h0, limb_194_1102}))); // decl: <none>; prim: <none>
    assign limb_194_1107 = limb_194_1106[0]; // decl: <none>; prim: <none>
    assign limb_194_1108 = {limb_194_1107, limb_194_1101, limb_194_1095}; // decl: <none>; prim: <none>
    assign limb_198_1109 = tmp_workload_top_int_65__526_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_198_1110 = tmp_workload_top_int_65__528_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1111Core rtlzz_owner_1111(.a(64'(limb_198_1109)), .b(64'(limb_198_1110)), .cin(1'h0), .value(limb_198_1111));
    assign limb_198_1112 = limb_198_1111[63:0]; // decl: <none>; prim: <none>
    assign limb_198_1113 = limb_198_1111[64]; // decl: <none>; prim: <none>
    assign limb_198_1114 = tmp_workload_top_int_65__526_v0[64]; // decl: <none>; prim: <none>
    assign limb_198_1115 = tmp_workload_top_int_65__528_v0[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1116Core rtlzz_owner_1116(.a(1'(limb_198_1114)), .b(1'(limb_198_1115)), .cin(limb_198_1113), .value(limb_198_1116[0:0]));
    assign limb_198_1116[1:1] = '0;
    assign limb_198_1117 = limb_198_1116[0]; // decl: <none>; prim: <none>
    assign limb_198_1118 = {limb_198_1117, limb_198_1112}; // decl: <none>; prim: <none>
    assign limb_200_1119 = s8_norm_add_331_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_200_1120 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_200_1121 = (~limb_200_1120); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1122Core rtlzz_owner_1122(.a(64'(limb_200_1119)), .b(64'(limb_200_1121)), .cin(1'h1), .value(limb_200_1122[63:0]));
    assign limb_200_1122[64:64] = '0;
    assign limb_200_1123 = limb_200_1122[63:0]; // decl: <none>; prim: <none>
    assign limb_200_1124 = limb_200_1122[64]; // decl: <none>; prim: <none>
    assign limb_200_1125 = s8_norm_add_331_v0[64]; // decl: <none>; prim: <none>
    assign limb_200_1126 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_200_1127 = (~limb_200_1126); // decl: <none>; prim: <none>
    assign limb_200_1128 = 2'((({1'h0, limb_200_1125}) + ({1'h0, limb_200_1127}) + ({1'h0, limb_200_1124}))); // decl: <none>; prim: <none>
    assign limb_200_1129 = limb_200_1128[0]; // decl: <none>; prim: <none>
    assign limb_200_1130 = {limb_200_1129, limb_200_1123}; // decl: <none>; prim: <none>
    assign limb_202_1131 = tmp_workload_top_int_65__526_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_202_1132 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1133Core rtlzz_owner_1133(.a(64'(limb_202_1131)), .b(64'(limb_202_1132)), .cin(1'h0), .value(limb_202_1133));
    assign limb_202_1134 = limb_202_1133[63:0]; // decl: <none>; prim: <none>
    assign limb_202_1135 = limb_202_1133[64]; // decl: <none>; prim: <none>
    assign limb_202_1136 = tmp_workload_top_int_65__526_v0[64]; // decl: <none>; prim: <none>
    assign limb_202_1137 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1138Core rtlzz_owner_1138(.a(1'(limb_202_1136)), .b(1'(limb_202_1137)), .cin(limb_202_1135), .value(limb_202_1138[0:0]));
    assign limb_202_1138[1:1] = '0;
    assign limb_202_1139 = limb_202_1138[0]; // decl: <none>; prim: <none>
    assign limb_202_1140 = {limb_202_1139, limb_202_1134}; // decl: <none>; prim: <none>
    assign limb_203_1141 = s8_norm_add_339_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_203_1142 = tmp_workload_top_int_65__528_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_203_1143 = (~limb_203_1142); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1144Core rtlzz_owner_1144(.a(64'(limb_203_1141)), .b(64'(limb_203_1143)), .cin(1'h1), .value(limb_203_1144));
    assign limb_203_1145 = limb_203_1144[63:0]; // decl: <none>; prim: <none>
    assign limb_203_1146 = limb_203_1144[64]; // decl: <none>; prim: <none>
    assign limb_203_1147 = s8_norm_add_339_v0[64]; // decl: <none>; prim: <none>
    assign limb_203_1148 = tmp_workload_top_int_65__528_v0[64]; // decl: <none>; prim: <none>
    assign limb_203_1149 = (~limb_203_1148); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1150Core rtlzz_owner_1150(.a(1'(limb_203_1147)), .b(1'(limb_203_1149)), .cin(limb_203_1146), .value(limb_203_1150[0:0]));
    assign limb_203_1150[1:1] = '0;
    assign limb_203_1151 = limb_203_1150[0]; // decl: <none>; prim: <none>
    assign limb_203_1152 = {limb_203_1151, limb_203_1145}; // decl: <none>; prim: <none>
    assign limb_205_1153 = s8_norm_sub_341_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_205_1154 = 64'((65'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign limb_205_1155 = (~limb_205_1154); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1156Core rtlzz_owner_1156(.a(64'(limb_205_1153)), .b(64'(limb_205_1155)), .cin(1'h1), .value(limb_205_1156[63:0]));
    assign limb_205_1156[64:64] = '0;
    assign limb_205_1157 = limb_205_1156[63:0]; // decl: <none>; prim: <none>
    assign limb_205_1158 = limb_205_1156[64]; // decl: <none>; prim: <none>
    assign limb_205_1159 = s8_norm_sub_341_v0[64]; // decl: <none>; prim: <none>
    assign limb_205_1160 = 1'((65'hffffffff00000001) >> 64); // decl: <none>; prim: <none>
    assign limb_205_1161 = (~limb_205_1160); // decl: <none>; prim: <none>
    assign limb_205_1162 = 2'((({1'h0, limb_205_1159}) + ({1'h0, limb_205_1161}) + ({1'h0, limb_205_1158}))); // decl: <none>; prim: <none>
    assign limb_205_1163 = limb_205_1162[0]; // decl: <none>; prim: <none>
    assign limb_205_1164 = {limb_205_1163, limb_205_1157}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_316_s1 <= 64'h0;
            rtlzz_pipe_317_s1 <= 1'h0;
            rtlzz_pipe_318_s1 <= 1'h0;
            rtlzz_pipe_319_s1 <= 1'h0;
            rtlzz_pipe_11_s2 <= 65'h0;
            rtlzz_pipe_11_s3 <= 65'h0;
            rtlzz_pipe_11_s4 <= 65'h0;
            rtlzz_pipe_11_s5 <= 65'h0;
            rtlzz_pipe_12_s3 <= 1'h1;
            rtlzz_pipe_12_s4 <= 1'h1;
            rtlzz_pipe_12_s5 <= 1'h1;
            rtlzz_pipe_323_s2 <= 64'h0;
            rtlzz_pipe_323_s3 <= 64'h0;
            rtlzz_pipe_327_s4 <= 64'hffffffff;
            rtlzz_pipe_328_s4 <= 1'h0;
            rtlzz_pipe_329_s2 <= 1'h0;
            rtlzz_pipe_329_s3 <= 1'h0;
            rtlzz_pipe_329_s4 <= 1'h0;
            rtlzz_pipe_13_s5 <= 65'h100000000ffffffff;
            rtlzz_pipe_14_s6 <= 65'h0;
            rtlzz_pipe_335_s1 <= 64'h0;
            rtlzz_pipe_335_s2 <= 64'h0;
            rtlzz_pipe_335_s3 <= 64'h0;
            rtlzz_pipe_335_s4 <= 64'h0;
            rtlzz_pipe_335_s5 <= 64'h0;
            rtlzz_pipe_335_s6 <= 64'h0;
            rtlzz_pipe_335_s7 <= 64'h0;
            rtlzz_pipe_338_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_339_s8 <= 1'h0;
            rtlzz_pipe_340_s1 <= 1'h0;
            rtlzz_pipe_340_s2 <= 1'h0;
            rtlzz_pipe_340_s3 <= 1'h0;
            rtlzz_pipe_340_s4 <= 1'h0;
            rtlzz_pipe_340_s5 <= 1'h0;
            rtlzz_pipe_340_s6 <= 1'h0;
            rtlzz_pipe_340_s7 <= 1'h0;
            rtlzz_pipe_340_s8 <= 1'h0;
            rtlzz_pipe_345_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_345_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_346_s1 <= 64'h0;
            rtlzz_pipe_346_s2 <= 64'h0;
            rtlzz_pipe_346_s3 <= 64'h0;
            rtlzz_pipe_346_s4 <= 64'h0;
            rtlzz_pipe_346_s5 <= 64'h0;
            rtlzz_pipe_346_s6 <= 64'h0;
            rtlzz_pipe_346_s7 <= 64'h0;
            rtlzz_pipe_346_s8 <= 64'h0;
            rtlzz_pipe_346_s9 <= 64'h0;
            rtlzz_pipe_347_s10 <= 64'hffffffffffffffff;
            rtlzz_pipe_349_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_349_s12 <= 64'hffffffff00000001;
            rtlzz_pipe_350_s11 <= 1'h1;
            rtlzz_pipe_350_s12 <= 1'h1;
            rtlzz_pipe_351_s9 <= 1'h0;
            rtlzz_pipe_351_s10 <= 1'h0;
            rtlzz_pipe_351_s11 <= 1'h0;
            rtlzz_pipe_351_s12 <= 1'h0;
            rtlzz_pipe_352_s1 <= 1'h0;
            rtlzz_pipe_352_s2 <= 1'h0;
            rtlzz_pipe_352_s3 <= 1'h0;
            rtlzz_pipe_352_s4 <= 1'h0;
            rtlzz_pipe_352_s5 <= 1'h0;
            rtlzz_pipe_352_s6 <= 1'h0;
            rtlzz_pipe_352_s7 <= 1'h0;
            rtlzz_pipe_352_s8 <= 1'h0;
            rtlzz_pipe_352_s9 <= 1'h0;
            rtlzz_pipe_352_s10 <= 1'h0;
            rtlzz_pipe_352_s11 <= 1'h0;
            rtlzz_pipe_353_s12 <= 1'h1;
            rtlzz_pipe_16_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_16_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_16_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_17_s14 <= 1'h0;
            rtlzz_pipe_17_s15 <= 1'h0;
            rtlzz_pipe_357_s13 <= 64'hffffffff00000001;
            rtlzz_pipe_357_s14 <= 64'hffffffff00000001;
            rtlzz_pipe_363_s13 <= 1'h0;
            rtlzz_pipe_363_s14 <= 1'h0;
            rtlzz_pipe_18_s15 <= 65'h0;
            rtlzz_pipe_372_s1 <= 64'h0;
            rtlzz_pipe_373_s1 <= 1'h0;
            rtlzz_pipe_374_s1 <= 1'h0;
            rtlzz_pipe_375_s1 <= 1'h0;
            rtlzz_pipe_22_s2 <= 65'h0;
            rtlzz_pipe_22_s3 <= 65'h0;
            rtlzz_pipe_22_s4 <= 65'h0;
            rtlzz_pipe_22_s5 <= 65'h0;
            rtlzz_pipe_23_s3 <= 1'h1;
            rtlzz_pipe_23_s4 <= 1'h1;
            rtlzz_pipe_23_s5 <= 1'h1;
            rtlzz_pipe_379_s2 <= 64'h0;
            rtlzz_pipe_379_s3 <= 64'h0;
            rtlzz_pipe_383_s4 <= 64'hffffffff;
            rtlzz_pipe_384_s4 <= 1'h0;
            rtlzz_pipe_385_s2 <= 1'h0;
            rtlzz_pipe_385_s3 <= 1'h0;
            rtlzz_pipe_385_s4 <= 1'h0;
            rtlzz_pipe_24_s5 <= 65'h100000000ffffffff;
            rtlzz_pipe_25_s6 <= 65'h0;
            rtlzz_pipe_391_s1 <= 64'h0;
            rtlzz_pipe_391_s2 <= 64'h0;
            rtlzz_pipe_391_s3 <= 64'h0;
            rtlzz_pipe_391_s4 <= 64'h0;
            rtlzz_pipe_391_s5 <= 64'h0;
            rtlzz_pipe_391_s6 <= 64'h0;
            rtlzz_pipe_391_s7 <= 64'h0;
            rtlzz_pipe_394_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_395_s8 <= 1'h0;
            rtlzz_pipe_396_s1 <= 1'h0;
            rtlzz_pipe_396_s2 <= 1'h0;
            rtlzz_pipe_396_s3 <= 1'h0;
            rtlzz_pipe_396_s4 <= 1'h0;
            rtlzz_pipe_396_s5 <= 1'h0;
            rtlzz_pipe_396_s6 <= 1'h0;
            rtlzz_pipe_396_s7 <= 1'h0;
            rtlzz_pipe_396_s8 <= 1'h0;
            rtlzz_pipe_401_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_401_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_402_s1 <= 64'h0;
            rtlzz_pipe_402_s2 <= 64'h0;
            rtlzz_pipe_402_s3 <= 64'h0;
            rtlzz_pipe_402_s4 <= 64'h0;
            rtlzz_pipe_402_s5 <= 64'h0;
            rtlzz_pipe_402_s6 <= 64'h0;
            rtlzz_pipe_402_s7 <= 64'h0;
            rtlzz_pipe_402_s8 <= 64'h0;
            rtlzz_pipe_402_s9 <= 64'h0;
            rtlzz_pipe_403_s10 <= 64'hffffffffffffffff;
            rtlzz_pipe_405_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_405_s12 <= 64'hffffffff00000001;
            rtlzz_pipe_406_s11 <= 1'h1;
            rtlzz_pipe_406_s12 <= 1'h1;
            rtlzz_pipe_407_s9 <= 1'h0;
            rtlzz_pipe_407_s10 <= 1'h0;
            rtlzz_pipe_407_s11 <= 1'h0;
            rtlzz_pipe_407_s12 <= 1'h0;
            rtlzz_pipe_408_s1 <= 1'h0;
            rtlzz_pipe_408_s2 <= 1'h0;
            rtlzz_pipe_408_s3 <= 1'h0;
            rtlzz_pipe_408_s4 <= 1'h0;
            rtlzz_pipe_408_s5 <= 1'h0;
            rtlzz_pipe_408_s6 <= 1'h0;
            rtlzz_pipe_408_s7 <= 1'h0;
            rtlzz_pipe_408_s8 <= 1'h0;
            rtlzz_pipe_408_s9 <= 1'h0;
            rtlzz_pipe_408_s10 <= 1'h0;
            rtlzz_pipe_408_s11 <= 1'h0;
            rtlzz_pipe_409_s12 <= 1'h1;
            rtlzz_pipe_27_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_27_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_28_s13 <= 1'h0;
            rtlzz_pipe_28_s14 <= 1'h0;
            rtlzz_pipe_413_s13 <= 64'hffffffff00000001;
            rtlzz_pipe_419_s13 <= 1'h0;
            rtlzz_pipe_29_s14 <= 65'h0;
            rtlzz_pipe_221_s15 <= 129'h0;
            rtlzz_pipe_256_s15 <= 128'h0;
            rtlzz_pipe_428_s1 <= 64'h0;
            rtlzz_pipe_429_s1 <= 1'h0;
            rtlzz_pipe_430_s1 <= 1'h0;
            rtlzz_pipe_431_s1 <= 1'h0;
            rtlzz_pipe_33_s2 <= 65'h0;
            rtlzz_pipe_33_s3 <= 65'h0;
            rtlzz_pipe_33_s4 <= 65'h0;
            rtlzz_pipe_33_s5 <= 65'h0;
            rtlzz_pipe_34_s3 <= 1'h1;
            rtlzz_pipe_34_s4 <= 1'h1;
            rtlzz_pipe_34_s5 <= 1'h1;
            rtlzz_pipe_435_s2 <= 64'h0;
            rtlzz_pipe_435_s3 <= 64'h0;
            rtlzz_pipe_439_s4 <= 64'hffffffff;
            rtlzz_pipe_440_s4 <= 1'h0;
            rtlzz_pipe_441_s2 <= 1'h0;
            rtlzz_pipe_441_s3 <= 1'h0;
            rtlzz_pipe_441_s4 <= 1'h0;
            rtlzz_pipe_35_s5 <= 65'h100000000ffffffff;
            rtlzz_pipe_36_s6 <= 65'h0;
            rtlzz_pipe_447_s1 <= 64'h0;
            rtlzz_pipe_447_s2 <= 64'h0;
            rtlzz_pipe_447_s3 <= 64'h0;
            rtlzz_pipe_447_s4 <= 64'h0;
            rtlzz_pipe_447_s5 <= 64'h0;
            rtlzz_pipe_447_s6 <= 64'h0;
            rtlzz_pipe_447_s7 <= 64'h0;
            rtlzz_pipe_450_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_451_s8 <= 1'h0;
            rtlzz_pipe_452_s1 <= 1'h0;
            rtlzz_pipe_452_s2 <= 1'h0;
            rtlzz_pipe_452_s3 <= 1'h0;
            rtlzz_pipe_452_s4 <= 1'h0;
            rtlzz_pipe_452_s5 <= 1'h0;
            rtlzz_pipe_452_s6 <= 1'h0;
            rtlzz_pipe_452_s7 <= 1'h0;
            rtlzz_pipe_452_s8 <= 1'h0;
            rtlzz_pipe_457_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_457_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_458_s1 <= 64'h0;
            rtlzz_pipe_458_s2 <= 64'h0;
            rtlzz_pipe_458_s3 <= 64'h0;
            rtlzz_pipe_458_s4 <= 64'h0;
            rtlzz_pipe_458_s5 <= 64'h0;
            rtlzz_pipe_458_s6 <= 64'h0;
            rtlzz_pipe_458_s7 <= 64'h0;
            rtlzz_pipe_458_s8 <= 64'h0;
            rtlzz_pipe_458_s9 <= 64'h0;
            rtlzz_pipe_459_s10 <= 64'hffffffffffffffff;
            rtlzz_pipe_461_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_462_s11 <= 1'h1;
            rtlzz_pipe_463_s9 <= 1'h0;
            rtlzz_pipe_463_s10 <= 1'h0;
            rtlzz_pipe_463_s11 <= 1'h0;
            rtlzz_pipe_464_s1 <= 1'h0;
            rtlzz_pipe_464_s2 <= 1'h0;
            rtlzz_pipe_464_s3 <= 1'h0;
            rtlzz_pipe_464_s4 <= 1'h0;
            rtlzz_pipe_464_s5 <= 1'h0;
            rtlzz_pipe_464_s6 <= 1'h0;
            rtlzz_pipe_464_s7 <= 1'h0;
            rtlzz_pipe_464_s8 <= 1'h0;
            rtlzz_pipe_464_s9 <= 1'h0;
            rtlzz_pipe_464_s10 <= 1'h0;
            rtlzz_pipe_464_s11 <= 1'h0;
            rtlzz_pipe_38_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_38_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_39_s13 <= 1'h0;
            rtlzz_pipe_473_s12 <= 64'h0;
            rtlzz_pipe_473_s13 <= 64'h0;
            rtlzz_pipe_474_s12 <= 1'h1;
            rtlzz_pipe_474_s13 <= 1'h1;
            rtlzz_pipe_475_s12 <= 1'h0;
            rtlzz_pipe_475_s13 <= 1'h0;
            rtlzz_pipe_484_s1 <= 64'h0;
            rtlzz_pipe_485_s1 <= 1'h0;
            rtlzz_pipe_486_s1 <= 1'h0;
            rtlzz_pipe_487_s1 <= 1'h0;
            rtlzz_pipe_44_s2 <= 65'h0;
            rtlzz_pipe_44_s3 <= 65'h0;
            rtlzz_pipe_44_s4 <= 65'h0;
            rtlzz_pipe_44_s5 <= 65'h0;
            rtlzz_pipe_45_s3 <= 1'h1;
            rtlzz_pipe_45_s4 <= 1'h1;
            rtlzz_pipe_45_s5 <= 1'h1;
            rtlzz_pipe_491_s2 <= 64'h0;
            rtlzz_pipe_491_s3 <= 64'h0;
            rtlzz_pipe_495_s4 <= 64'hffffffff;
            rtlzz_pipe_496_s4 <= 1'h0;
            rtlzz_pipe_497_s2 <= 1'h0;
            rtlzz_pipe_497_s3 <= 1'h0;
            rtlzz_pipe_497_s4 <= 1'h0;
            rtlzz_pipe_46_s5 <= 65'h100000000ffffffff;
            rtlzz_pipe_47_s6 <= 65'h0;
            rtlzz_pipe_503_s1 <= 64'h0;
            rtlzz_pipe_503_s2 <= 64'h0;
            rtlzz_pipe_503_s3 <= 64'h0;
            rtlzz_pipe_503_s4 <= 64'h0;
            rtlzz_pipe_503_s5 <= 64'h0;
            rtlzz_pipe_503_s6 <= 64'h0;
            rtlzz_pipe_503_s7 <= 64'h0;
            rtlzz_pipe_506_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_507_s8 <= 1'h0;
            rtlzz_pipe_508_s1 <= 1'h0;
            rtlzz_pipe_508_s2 <= 1'h0;
            rtlzz_pipe_508_s3 <= 1'h0;
            rtlzz_pipe_508_s4 <= 1'h0;
            rtlzz_pipe_508_s5 <= 1'h0;
            rtlzz_pipe_508_s6 <= 1'h0;
            rtlzz_pipe_508_s7 <= 1'h0;
            rtlzz_pipe_508_s8 <= 1'h0;
            rtlzz_pipe_513_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_513_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_514_s1 <= 64'h0;
            rtlzz_pipe_514_s2 <= 64'h0;
            rtlzz_pipe_514_s3 <= 64'h0;
            rtlzz_pipe_514_s4 <= 64'h0;
            rtlzz_pipe_514_s5 <= 64'h0;
            rtlzz_pipe_514_s6 <= 64'h0;
            rtlzz_pipe_514_s7 <= 64'h0;
            rtlzz_pipe_514_s8 <= 64'h0;
            rtlzz_pipe_514_s9 <= 64'h0;
            rtlzz_pipe_515_s10 <= 64'hffffffffffffffff;
            rtlzz_pipe_519_s9 <= 1'h0;
            rtlzz_pipe_519_s10 <= 1'h0;
            rtlzz_pipe_521_s1 <= 1'h1;
            rtlzz_pipe_521_s2 <= 1'h1;
            rtlzz_pipe_521_s3 <= 1'h1;
            rtlzz_pipe_521_s4 <= 1'h1;
            rtlzz_pipe_521_s5 <= 1'h1;
            rtlzz_pipe_521_s6 <= 1'h1;
            rtlzz_pipe_521_s7 <= 1'h1;
            rtlzz_pipe_521_s8 <= 1'h1;
            rtlzz_pipe_521_s9 <= 1'h1;
            rtlzz_pipe_521_s10 <= 1'h1;
            rtlzz_pipe_49_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_49_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_529_s11 <= 64'h0;
            rtlzz_pipe_530_s11 <= 1'h1;
            rtlzz_pipe_531_s11 <= 1'h0;
            rtlzz_pipe_51_s12 <= 65'h0;
            rtlzz_pipe_262_s13 <= 64'h0;
            rtlzz_pipe_224_s14 <= 193'h0;
            rtlzz_pipe_226_s14 <= 129'h0;
            rtlzz_pipe_226_s15 <= 129'h0;
            rtlzz_pipe_268_s15 <= 65'h0;
            rtlzz_pipe_540_s7 <= 64'h0;
            rtlzz_pipe_541_s7 <= 1'h0;
            rtlzz_pipe_542_s7 <= 1'h0;
            rtlzz_pipe_543_s7 <= 1'h0;
            rtlzz_pipe_55_s8 <= 65'h0;
            rtlzz_pipe_55_s9 <= 65'h0;
            rtlzz_pipe_56_s8 <= 1'h1;
            rtlzz_pipe_56_s9 <= 1'h1;
            rtlzz_pipe_547_s8 <= 64'h0;
            rtlzz_pipe_553_s8 <= 1'h0;
            rtlzz_pipe_57_s9 <= 65'h100000000ffffffff;
            rtlzz_pipe_569_s7 <= 64'hffffffff00000001;
            rtlzz_pipe_569_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_570_s7 <= 64'h0;
            rtlzz_pipe_571_s8 <= 64'hffffffffffffffff;
            rtlzz_pipe_573_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_573_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_574_s9 <= 1'h1;
            rtlzz_pipe_574_s10 <= 1'h1;
            rtlzz_pipe_575_s7 <= 1'h0;
            rtlzz_pipe_575_s8 <= 1'h0;
            rtlzz_pipe_575_s9 <= 1'h0;
            rtlzz_pipe_575_s10 <= 1'h0;
            rtlzz_pipe_576_s7 <= 1'h0;
            rtlzz_pipe_576_s8 <= 1'h0;
            rtlzz_pipe_576_s9 <= 1'h0;
            rtlzz_pipe_577_s10 <= 1'h1;
            rtlzz_pipe_60_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_61_s11 <= 1'h0;
            rtlzz_pipe_61_s12 <= 1'h0;
            rtlzz_pipe_581_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_587_s11 <= 1'h0;
            rtlzz_pipe_62_s12 <= 65'h0;
            rtlzz_pipe_63_s13 <= 65'h0;
            rtlzz_pipe_688_s7 <= 64'h0;
            rtlzz_pipe_689_s7 <= 1'h0;
            rtlzz_pipe_690_s7 <= 1'h0;
            rtlzz_pipe_691_s7 <= 1'h0;
            rtlzz_pipe_89_s8 <= 65'h0;
            rtlzz_pipe_89_s9 <= 65'h0;
            rtlzz_pipe_90_s8 <= 1'h1;
            rtlzz_pipe_90_s9 <= 1'h1;
            rtlzz_pipe_695_s8 <= 64'h0;
            rtlzz_pipe_699_s9 <= 64'hffffffff;
            rtlzz_pipe_700_s9 <= 1'h0;
            rtlzz_pipe_701_s8 <= 1'h0;
            rtlzz_pipe_701_s9 <= 1'h0;
            rtlzz_pipe_92_s10 <= 65'h0;
            rtlzz_pipe_710_s7 <= 64'hffffffff00000001;
            rtlzz_pipe_710_s8 <= 64'hffffffff00000001;
            rtlzz_pipe_711_s7 <= 1'h0;
            rtlzz_pipe_711_s8 <= 1'h0;
            rtlzz_pipe_712_s7 <= 1'h0;
            rtlzz_pipe_712_s8 <= 1'h0;
            rtlzz_pipe_717_s9 <= 64'hffffffff00000001;
            rtlzz_pipe_717_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_717_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_717_s12 <= 64'hffffffff00000001;
            rtlzz_pipe_718_s7 <= 64'h0;
            rtlzz_pipe_718_s8 <= 64'h0;
            rtlzz_pipe_718_s9 <= 64'h0;
            rtlzz_pipe_718_s10 <= 64'h0;
            rtlzz_pipe_718_s11 <= 64'h0;
            rtlzz_pipe_719_s12 <= 64'hffffffffffffffff;
            rtlzz_pipe_721_s13 <= 64'hffffffff00000001;
            rtlzz_pipe_722_s13 <= 1'h1;
            rtlzz_pipe_723_s9 <= 1'h0;
            rtlzz_pipe_723_s10 <= 1'h0;
            rtlzz_pipe_723_s11 <= 1'h0;
            rtlzz_pipe_723_s12 <= 1'h0;
            rtlzz_pipe_723_s13 <= 1'h0;
            rtlzz_pipe_724_s7 <= 1'h0;
            rtlzz_pipe_724_s8 <= 1'h0;
            rtlzz_pipe_724_s9 <= 1'h0;
            rtlzz_pipe_724_s10 <= 1'h0;
            rtlzz_pipe_724_s11 <= 1'h0;
            rtlzz_pipe_724_s12 <= 1'h0;
            rtlzz_pipe_724_s13 <= 1'h0;
            rtlzz_pipe_94_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_96_s14 <= 65'h0;
            rtlzz_pipe_777_s14 <= 64'h0;
            rtlzz_pipe_777_s15 <= 64'h0;
            rtlzz_pipe_782_s14 <= 1'h0;
            rtlzz_pipe_782_s15 <= 1'h0;
            rtlzz_pipe_809_s14 <= 64'hffffffff00000001;
            rtlzz_pipe_809_s15 <= 64'hffffffff00000001;
            rtlzz_pipe_815_s14 <= 1'h0;
            rtlzz_pipe_815_s15 <= 1'h0;
            rtlzz_pipe_833_s10 <= 64'h0;
            rtlzz_pipe_838_s10 <= 1'h0;
            rtlzz_pipe_123_s11 <= 65'h0;
            rtlzz_pipe_123_s12 <= 65'h0;
            rtlzz_pipe_124_s12 <= 1'h1;
            rtlzz_pipe_843_s11 <= 64'h0;
            rtlzz_pipe_843_s12 <= 64'h0;
            rtlzz_pipe_849_s11 <= 1'h0;
            rtlzz_pipe_849_s12 <= 1'h0;
            rtlzz_pipe_132_s13 <= 64'h0;
            rtlzz_pipe_132_s14 <= 64'h0;
            rtlzz_pipe_132_s15 <= 64'h0;
            rtlzz_pipe_865_s10 <= 64'hffffffff00000001;
            rtlzz_pipe_865_s11 <= 64'hffffffff00000001;
            rtlzz_pipe_866_s11 <= 64'h0;
            rtlzz_pipe_871_s10 <= 1'h0;
            rtlzz_pipe_871_s11 <= 1'h0;
            rtlzz_pipe_873_s11 <= 1'h1;
            rtlzz_pipe_128_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_881_s12 <= 64'h0;
            rtlzz_pipe_882_s12 <= 1'h1;
            rtlzz_pipe_883_s12 <= 1'h0;
            rtlzz_pipe_133_s13 <= 64'h0;
            rtlzz_pipe_133_s14 <= 64'h0;
            rtlzz_pipe_133_s15 <= 64'h0;
            rtlzz_pipe_1017_s14 <= 64'h0;
            rtlzz_pipe_1022_s14 <= 1'h0;
            rtlzz_pipe_182_s15 <= 64'h0;
            rtlzz_pipe_1049_s14 <= 64'hffffffff00000001;
            rtlzz_pipe_1055_s14 <= 1'h0;
            rtlzz_pipe_183_s15 <= 64'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
            rtlzz_valid_s8 <= 1'h0;
            rtlzz_valid_s9 <= 1'h0;
            rtlzz_valid_s10 <= 1'h0;
            rtlzz_valid_s11 <= 1'h0;
            rtlzz_valid_s12 <= 1'h0;
            rtlzz_valid_s13 <= 1'h0;
            rtlzz_valid_s14 <= 1'h0;
            rtlzz_valid_s15 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_316_s1 <= limb_11_316; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_317_s1 <= limb_11_317; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_318_s1 <= limb_11_318; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_319_s1 <= limb_11_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_11_s3 <= rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_11_s4 <= rtlzz_pipe_11_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_323_s2 <= limb_13_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_323_s3 <= rtlzz_pipe_323_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_327_s4 <= limb_13_327; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= limb_13_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_329_s2 <= limb_13_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_329_s3 <= rtlzz_pipe_329_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_329_s4 <= rtlzz_pipe_329_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_13_s5 <= s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_14_s6 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
        end
        if (iv) begin
        rtlzz_pipe_335_s1 <= limb_15_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_335_s2 <= rtlzz_pipe_335_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_335_s3 <= rtlzz_pipe_335_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_335_s5 <= rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_335_s6 <= rtlzz_pipe_335_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_335_s7 <= rtlzz_pipe_335_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_338_s8 <= limb_15_338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_339_s8 <= limb_15_339; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_340_s1 <= limb_15_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_340_s2 <= rtlzz_pipe_340_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_340_s3 <= rtlzz_pipe_340_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_340_s4 <= rtlzz_pipe_340_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_340_s5 <= rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_340_s7 <= rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_340_s8 <= rtlzz_pipe_340_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_345_s9 <= limb_16_345; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_345_s10 <= rtlzz_pipe_345_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_346_s1 <= limb_16_346; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_346_s2 <= rtlzz_pipe_346_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_346_s3 <= rtlzz_pipe_346_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_346_s4 <= rtlzz_pipe_346_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_346_s5 <= rtlzz_pipe_346_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_346_s6 <= rtlzz_pipe_346_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_346_s7 <= rtlzz_pipe_346_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_346_s8 <= rtlzz_pipe_346_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_346_s9 <= rtlzz_pipe_346_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_347_s10 <= limb_16_347; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_349_s11 <= limb_16_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_349_s12 <= rtlzz_pipe_349_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_350_s11 <= limb_16_350; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_350_s12 <= rtlzz_pipe_350_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_351_s9 <= limb_16_351; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_351_s10 <= rtlzz_pipe_351_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_351_s11 <= rtlzz_pipe_351_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_351_s12 <= rtlzz_pipe_351_s11; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_352_s1 <= limb_16_352; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_352_s2 <= rtlzz_pipe_352_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_352_s3 <= rtlzz_pipe_352_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_352_s4 <= rtlzz_pipe_352_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_352_s5 <= rtlzz_pipe_352_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_352_s6 <= rtlzz_pipe_352_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_352_s7 <= rtlzz_pipe_352_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_352_s8 <= rtlzz_pipe_352_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_352_s9 <= rtlzz_pipe_352_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_352_s10 <= rtlzz_pipe_352_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_352_s11 <= rtlzz_pipe_352_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_353_s12 <= limb_16_353; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_16_s13 <= s8_norm_sub_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_16_s14 <= rtlzz_pipe_16_s13; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_16_s15 <= rtlzz_pipe_16_s14; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_17_s14 <= s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_17_s15 <= rtlzz_pipe_17_s14; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_357_s13 <= limb_18_357; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_357_s14 <= rtlzz_pipe_357_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_363_s13 <= limb_18_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_363_s14 <= rtlzz_pipe_363_s13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_18_s15 <= s8_norm_sub_20_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (iv) begin
        rtlzz_pipe_372_s1 <= limb_22_372; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_373_s1 <= limb_22_373; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_374_s1 <= limb_22_374; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_375_s1 <= limb_22_375; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_22_s2 <= s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_22_s3 <= rtlzz_pipe_22_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_22_s4 <= rtlzz_pipe_22_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_22_s5 <= rtlzz_pipe_22_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_23_s4 <= rtlzz_pipe_23_s3; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_23_s5 <= rtlzz_pipe_23_s4; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_379_s2 <= limb_24_379; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_379_s3 <= rtlzz_pipe_379_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_383_s4 <= limb_24_383; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_384_s4 <= limb_24_384; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_385_s2 <= limb_24_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_385_s3 <= rtlzz_pipe_385_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_385_s4 <= rtlzz_pipe_385_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_24_s5 <= s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_25_s6 <= s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
        end
        if (iv) begin
        rtlzz_pipe_391_s1 <= limb_26_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= rtlzz_pipe_391_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_391_s3 <= rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_391_s4 <= rtlzz_pipe_391_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_391_s5 <= rtlzz_pipe_391_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_391_s6 <= rtlzz_pipe_391_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_391_s7 <= rtlzz_pipe_391_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_394_s8 <= limb_26_394; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_395_s8 <= limb_26_395; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_396_s1 <= limb_26_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_396_s2 <= rtlzz_pipe_396_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_396_s3 <= rtlzz_pipe_396_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_396_s4 <= rtlzz_pipe_396_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_396_s5 <= rtlzz_pipe_396_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_396_s6 <= rtlzz_pipe_396_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_396_s7 <= rtlzz_pipe_396_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_396_s8 <= rtlzz_pipe_396_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_401_s9 <= limb_27_401; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_401_s10 <= rtlzz_pipe_401_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_402_s1 <= limb_27_402; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_402_s2 <= rtlzz_pipe_402_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_402_s3 <= rtlzz_pipe_402_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_402_s4 <= rtlzz_pipe_402_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_402_s5 <= rtlzz_pipe_402_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_402_s6 <= rtlzz_pipe_402_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_402_s7 <= rtlzz_pipe_402_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_402_s8 <= rtlzz_pipe_402_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_402_s9 <= rtlzz_pipe_402_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_403_s10 <= limb_27_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_405_s11 <= limb_27_405; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_405_s12 <= rtlzz_pipe_405_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_406_s11 <= limb_27_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_406_s12 <= rtlzz_pipe_406_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_407_s9 <= limb_27_407; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_407_s10 <= rtlzz_pipe_407_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_407_s11 <= rtlzz_pipe_407_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_407_s12 <= rtlzz_pipe_407_s11; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_408_s1 <= limb_27_408; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_408_s2 <= rtlzz_pipe_408_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_408_s3 <= rtlzz_pipe_408_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_408_s4 <= rtlzz_pipe_408_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_408_s5 <= rtlzz_pipe_408_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_408_s6 <= rtlzz_pipe_408_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_408_s7 <= rtlzz_pipe_408_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_408_s8 <= rtlzz_pipe_408_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_408_s9 <= rtlzz_pipe_408_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_408_s10 <= rtlzz_pipe_408_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_408_s11 <= rtlzz_pipe_408_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_409_s12 <= limb_27_409; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_27_s13 <= s8_norm_sub_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_27_s14 <= rtlzz_pipe_27_s13; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_28_s13 <= s8_norm_cmp_38_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_28_s14 <= rtlzz_pipe_28_s13; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_413_s13 <= limb_29_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_419_s13 <= limb_29_419; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_29_s14 <= s8_norm_sub_40_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_221_s15 <= __beopt_width_862; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_256_s15 <= mul_precision_256; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_428_s1 <= limb_33_428; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_429_s1 <= limb_33_429; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_430_s1 <= limb_33_430; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_431_s1 <= limb_33_431; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_33_s4 <= rtlzz_pipe_33_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_33_s5 <= rtlzz_pipe_33_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_34_s4 <= rtlzz_pipe_34_s3; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_34_s5 <= rtlzz_pipe_34_s4; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_435_s2 <= limb_35_435; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_435_s3 <= rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_439_s4 <= limb_35_439; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_440_s4 <= limb_35_440; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_441_s2 <= limb_35_441; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_441_s3 <= rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_441_s4 <= rtlzz_pipe_441_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_36_s6 <= s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (iv) begin
        rtlzz_pipe_447_s1 <= limb_37_447; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_447_s2 <= rtlzz_pipe_447_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_447_s3 <= rtlzz_pipe_447_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_447_s4 <= rtlzz_pipe_447_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_447_s5 <= rtlzz_pipe_447_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_447_s6 <= rtlzz_pipe_447_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_447_s7 <= rtlzz_pipe_447_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_450_s8 <= limb_37_450; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_451_s8 <= limb_37_451; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_452_s1 <= limb_37_452; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_452_s2 <= rtlzz_pipe_452_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_452_s3 <= rtlzz_pipe_452_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_452_s4 <= rtlzz_pipe_452_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_452_s5 <= rtlzz_pipe_452_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_452_s6 <= rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_452_s7 <= rtlzz_pipe_452_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_452_s8 <= rtlzz_pipe_452_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_457_s9 <= limb_38_457; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_457_s10 <= rtlzz_pipe_457_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_458_s1 <= limb_38_458; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_458_s2 <= rtlzz_pipe_458_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_458_s3 <= rtlzz_pipe_458_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_458_s4 <= rtlzz_pipe_458_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_458_s5 <= rtlzz_pipe_458_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_458_s6 <= rtlzz_pipe_458_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_458_s7 <= rtlzz_pipe_458_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_458_s8 <= rtlzz_pipe_458_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_458_s9 <= rtlzz_pipe_458_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_459_s10 <= limb_38_459; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_461_s11 <= limb_38_461; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_462_s11 <= limb_38_462; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_463_s9 <= limb_38_463; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_463_s10 <= rtlzz_pipe_463_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_463_s11 <= rtlzz_pipe_463_s10; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_464_s1 <= limb_38_464; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_464_s2 <= rtlzz_pipe_464_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_464_s3 <= rtlzz_pipe_464_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_464_s4 <= rtlzz_pipe_464_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_464_s5 <= rtlzz_pipe_464_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_464_s6 <= rtlzz_pipe_464_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_464_s7 <= rtlzz_pipe_464_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_464_s8 <= rtlzz_pipe_464_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_464_s9 <= rtlzz_pipe_464_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_464_s10 <= rtlzz_pipe_464_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_464_s11 <= rtlzz_pipe_464_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_38_s12 <= s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_38_s13 <= rtlzz_pipe_38_s12; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_39_s13 <= s8_norm_cmp_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_473_s12 <= limb_40_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_473_s13 <= rtlzz_pipe_473_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_474_s12 <= limb_40_474; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_474_s13 <= rtlzz_pipe_474_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_475_s12 <= limb_40_475; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_475_s13 <= rtlzz_pipe_475_s12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_484_s1 <= limb_44_484; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_485_s1 <= limb_44_485; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_486_s1 <= limb_44_486; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_487_s1 <= limb_44_487; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_44_s2 <= s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= rtlzz_pipe_44_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_44_s4 <= rtlzz_pipe_44_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= rtlzz_pipe_44_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_45_s3 <= s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_45_s4 <= rtlzz_pipe_45_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_45_s5 <= rtlzz_pipe_45_s4; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_491_s2 <= limb_46_491; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_491_s3 <= rtlzz_pipe_491_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_495_s4 <= limb_46_495; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_496_s4 <= limb_46_496; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_497_s2 <= limb_46_497; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_497_s3 <= rtlzz_pipe_497_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_497_s4 <= rtlzz_pipe_497_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_46_s5 <= s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_47_s6 <= s8_norm_mux_71_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
        end
        if (iv) begin
        rtlzz_pipe_503_s1 <= limb_48_503; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_503_s2 <= rtlzz_pipe_503_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_503_s3 <= rtlzz_pipe_503_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_503_s4 <= rtlzz_pipe_503_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_503_s5 <= rtlzz_pipe_503_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_503_s6 <= rtlzz_pipe_503_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_503_s7 <= rtlzz_pipe_503_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_506_s8 <= limb_48_506; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_507_s8 <= limb_48_507; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_508_s1 <= limb_48_508; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_508_s2 <= rtlzz_pipe_508_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_508_s3 <= rtlzz_pipe_508_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_508_s4 <= rtlzz_pipe_508_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_508_s5 <= rtlzz_pipe_508_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_508_s6 <= rtlzz_pipe_508_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_508_s7 <= rtlzz_pipe_508_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_508_s8 <= rtlzz_pipe_508_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_513_s9 <= limb_49_513; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_513_s10 <= rtlzz_pipe_513_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_514_s1 <= limb_49_514; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_514_s2 <= rtlzz_pipe_514_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_514_s3 <= rtlzz_pipe_514_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_514_s4 <= rtlzz_pipe_514_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_514_s5 <= rtlzz_pipe_514_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_514_s6 <= rtlzz_pipe_514_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_514_s7 <= rtlzz_pipe_514_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_514_s8 <= rtlzz_pipe_514_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_514_s9 <= rtlzz_pipe_514_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_515_s10 <= limb_49_515; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_519_s9 <= limb_49_519; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_519_s10 <= rtlzz_pipe_519_s9; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_521_s1 <= limb_49_521; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_521_s2 <= rtlzz_pipe_521_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_521_s3 <= rtlzz_pipe_521_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_521_s4 <= rtlzz_pipe_521_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_521_s5 <= rtlzz_pipe_521_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_521_s6 <= rtlzz_pipe_521_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_521_s7 <= rtlzz_pipe_521_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_521_s8 <= rtlzz_pipe_521_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_521_s9 <= rtlzz_pipe_521_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_521_s10 <= rtlzz_pipe_521_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_49_s11 <= s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_49_s12 <= rtlzz_pipe_49_s11; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_529_s11 <= limb_51_529; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_530_s11 <= limb_51_530; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_531_s11 <= limb_51_531; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_51_s12 <= s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_262_s13 <= mul_precision_262; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_224_s14 <= __beopt_width_866; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_226_s14 <= __beopt_width_869; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_226_s15 <= rtlzz_pipe_226_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_268_s15 <= mul_precision_268; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_540_s7 <= limb_55_540; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_541_s7 <= limb_55_541; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_542_s7 <= limb_55_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_543_s7 <= limb_55_543; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_55_s8 <= s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_55_s9 <= rtlzz_pipe_55_s8; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_56_s8 <= s8_norm_cmp_88_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_56_s9 <= rtlzz_pipe_56_s8; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_547_s8 <= limb_57_547; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_553_s8 <= limb_57_553; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_57_s9 <= s8_norm_sub_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_569_s7 <= limb_60_569; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_569_s8 <= rtlzz_pipe_569_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_570_s7 <= limb_60_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_571_s8 <= limb_60_571; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_573_s9 <= limb_60_573; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_573_s10 <= rtlzz_pipe_573_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_574_s9 <= limb_60_574; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_574_s10 <= rtlzz_pipe_574_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_575_s7 <= limb_60_575; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_575_s8 <= rtlzz_pipe_575_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_575_s9 <= rtlzz_pipe_575_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_575_s10 <= rtlzz_pipe_575_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_576_s7 <= limb_60_576; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_576_s8 <= rtlzz_pipe_576_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_576_s9 <= rtlzz_pipe_576_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_577_s10 <= limb_60_577; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_60_s11 <= s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_60_s12 <= rtlzz_pipe_60_s11; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_61_s11 <= s8_norm_cmp_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_61_s12 <= rtlzz_pipe_61_s11; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_581_s11 <= limb_62_581; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_587_s11 <= limb_62_587; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_62_s12 <= s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_63_s13 <= s8_norm_mux_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_688_s7 <= limb_89_688; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_689_s7 <= limb_89_689; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_690_s7 <= limb_89_690; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_691_s7 <= limb_89_691; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_89_s8 <= s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_89_s9 <= rtlzz_pipe_89_s8; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_90_s8 <= s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_90_s9 <= rtlzz_pipe_90_s8; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_695_s8 <= limb_91_695; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_699_s9 <= limb_91_699; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_700_s9 <= limb_91_700; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_701_s8 <= limb_91_701; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_701_s9 <= rtlzz_pipe_701_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_92_s10 <= s8_norm_mux_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_710_s7 <= limb_93_710; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_710_s8 <= rtlzz_pipe_710_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_711_s7 <= limb_93_711; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_711_s8 <= rtlzz_pipe_711_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_712_s7 <= limb_93_712; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_712_s8 <= rtlzz_pipe_712_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_717_s9 <= limb_94_717; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_717_s10 <= rtlzz_pipe_717_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_717_s11 <= rtlzz_pipe_717_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_717_s12 <= rtlzz_pipe_717_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_718_s7 <= limb_94_718; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_718_s8 <= rtlzz_pipe_718_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_718_s9 <= rtlzz_pipe_718_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_718_s10 <= rtlzz_pipe_718_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_718_s11 <= rtlzz_pipe_718_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_719_s12 <= limb_94_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_721_s13 <= limb_94_721; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_722_s13 <= limb_94_722; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_723_s9 <= limb_94_723; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_723_s10 <= rtlzz_pipe_723_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_723_s11 <= rtlzz_pipe_723_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_723_s12 <= rtlzz_pipe_723_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_723_s13 <= rtlzz_pipe_723_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_724_s7 <= limb_94_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_724_s8 <= rtlzz_pipe_724_s7; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_724_s9 <= rtlzz_pipe_724_s8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_724_s10 <= rtlzz_pipe_724_s9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_724_s11 <= rtlzz_pipe_724_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_724_s12 <= rtlzz_pipe_724_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_724_s13 <= rtlzz_pipe_724_s12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_94_s14 <= s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_96_s14 <= s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_777_s14 <= limb_112_777; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_777_s15 <= rtlzz_pipe_777_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_782_s14 <= limb_112_782; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_782_s15 <= rtlzz_pipe_782_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_809_s14 <= limb_117_809; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_809_s15 <= rtlzz_pipe_809_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_815_s14 <= limb_117_815; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_815_s15 <= rtlzz_pipe_815_s14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_833_s10 <= limb_123_833; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_838_s10 <= limb_123_838; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_123_s11 <= s8_norm_add_208_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_123_s12 <= rtlzz_pipe_123_s11; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_124_s12 <= s8_norm_cmp_210_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_843_s11 <= limb_125_843; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_843_s12 <= rtlzz_pipe_843_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_849_s11 <= limb_125_849; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_849_s12 <= rtlzz_pipe_849_s11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_132_s13 <= tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_132_s14 <= rtlzz_pipe_132_s13; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_132_s15 <= rtlzz_pipe_132_s14; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_865_s10 <= limb_128_865; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_865_s11 <= rtlzz_pipe_865_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_866_s11 <= limb_128_866; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_871_s10 <= limb_128_871; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_871_s11 <= rtlzz_pipe_871_s10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_873_s11 <= limb_128_873; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_128_s12 <= s8_norm_sub_218_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_881_s12 <= limb_130_881; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_882_s12 <= limb_130_882; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_883_s12 <= limb_130_883; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_133_s13 <= tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_133_s14 <= rtlzz_pipe_133_s13; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_133_s15 <= rtlzz_pipe_133_s14; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1017_s14 <= limb_173_1017; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1022_s14 <= limb_173_1022; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_182_s15 <= tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1049_s14 <= limb_178_1049; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_1055_s14 <= limb_178_1055; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_183_s15 <= tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s8 <= rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s9 <= rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s10 <= rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s11 <= rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s12 <= rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s13 <= rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s14 <= rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s15 <= rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_12();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_14();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_28();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_36();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_41();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_47Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_47();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_52();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_56();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_73();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_75Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_75();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_79();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_81();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_84();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_92();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_107();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_109();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_156();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_168();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_179();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_181Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_181();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h0)|129'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_193();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [64:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_195();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_199Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_199();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [0:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h0)|65'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=65'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [64:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_299Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_299();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_302();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffeff000001);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307Core(input wire [63:0] a,input wire [48:0] b,input wire cin,output wire [112:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [48:0] masked_b=((b&49'h0)|49'h1000000000000);
wire [112:0] aa=113'(masked_a);
wire [112:0] bb=113'(masked_b);
wire [112:0] native_value=aa*bb;
assign value=native_value[0+:113];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_307();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'h1ffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffeff00000101);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_311Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h0)|65'h100000000ffffffff);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_311();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_332Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_332();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_371Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_371();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_404Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_404();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_410Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_410();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_422Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_422();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_449Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_449();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_454();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_460Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_460();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_466();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_478Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_478();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_483();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_488();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_500Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_500();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_510Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_510();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_528Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_528();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_539Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_539();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_556Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_556();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_561Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_561();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_566Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_566();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_578Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_578();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_584Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_584();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_590Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_590();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_602Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h1ffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_602();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_608Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_608();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_614Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_614();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_620Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffffffffffff);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_620();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_636Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_636();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_642Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_642();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_648Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_648();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_658Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_658();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_664Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_664();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_670Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_670();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_676Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_676();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_687Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_687();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_692Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_692();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_698Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_698();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_704Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_704();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_709Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_709();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_714Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_714();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_720Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_720();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_732Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_732();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_738Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_738();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_744Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_744();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_750Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h1ffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_750();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_756Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_756();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_762Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_762();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_768Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffffffffffff);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_768();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_779Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_779();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_801Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_801();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_806Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_806();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_812Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_812();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_818Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_818();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_824Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_824();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_830Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_830();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_846Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_846();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_857Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_857();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_862();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_868Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_868();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_874();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_880Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_880();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_892Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_892();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_898Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_898();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_904Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_904();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_910Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_910();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_916Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffffffffffff);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_916();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_927Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_927();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_932Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_932();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_938Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_938();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_949Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_949();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_954Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_954();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_960Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_960();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_966Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_966();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_972Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_972();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_984Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_984();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_990Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h1ffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_990();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_996Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_996();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1002Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1002();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1008Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffffffffffff);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1008();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1019Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1019();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1024Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1024();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1030Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1030();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1041Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1041();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1046Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1046();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1052Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1052();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1076Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1076();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1082Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1082();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1088Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1088();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1094Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1094();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1100Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffffffffffff);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1111Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1111();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1116Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1116();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1122Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1122();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1133Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hffffffff00000001);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1133();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1138Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h1);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1156Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'hfffffffe);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1156();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x0_data,input wire x0_wen,input wire [63:0] x1_data,input wire x1_wen,input wire [63:0] x2_data,input wire x2_wen,input wire [63:0] x3_data,input wire x3_wen,input wire [63:0] x4_data,input wire x4_wen,input wire [63:0] x5_data,input wire x5_wen,input wire [63:0] x6_data,input wire x6_wen,input wire [63:0] x7_data,input wire x7_wen,output reg [63:0] y0,output reg [63:0] y1,output reg [63:0] y2,output reg [63:0] y3,output reg [63:0] y4,output reg [63:0] y5,output reg [63:0] y6,output reg [63:0] y7);
reg liv;wire cov;
reg [63:0] l_x0;
reg [63:0] l_x1;
reg [63:0] l_x2;
reg [63:0] l_x3;
reg [63:0] l_x4;
reg [63:0] l_x5;
reg [63:0] l_x6;
reg [63:0] l_x7;
wire [63:0] c_y0;
wire [63:0] c_y1;
wire [63:0] c_y2;
wire [63:0] c_y3;
wire [63:0] c_y4;
wire [63:0] c_y5;
wire [63:0] c_y6;
wire [63:0] c_y7;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x0(l_x0),.x1(l_x1),.x2(l_x2),.x3(l_x3),.x4(l_x4),.x5(l_x5),.x6(l_x6),.x7(l_x7),.y0(c_y0),.y1(c_y1),.y2(c_y2),.y3(c_y3),.y4(c_y4),.y5(c_y5),.y6(c_y6),.y7(c_y7));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x0<=64'h0;l_x1<=64'h0;l_x2<=64'h0;l_x3<=64'h0;l_x4<=64'h0;l_x5<=64'h0;l_x6<=64'h0;l_x7<=64'h0;y0<=64'h0;y1<=64'h0;y2<=64'h0;y3<=64'h0;y4<=64'h0;y5<=64'h0;y6<=64'h0;y7<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x0_wen)l_x0<=x0_data;if(x1_wen)l_x1<=x1_data;if(x2_wen)l_x2<=x2_data;if(x3_wen)l_x3<=x3_data;if(x4_wen)l_x4<=x4_data;if(x5_wen)l_x5<=x5_data;if(x6_wen)l_x6<=x6_data;if(x7_wen)l_x7<=x7_data;y0<=c_y0;y1<=c_y1;y2<=c_y2;y3<=c_y3;y4<=c_y4;y5<=c_y5;y6<=c_y6;y7<=c_y7;end
endmodule
