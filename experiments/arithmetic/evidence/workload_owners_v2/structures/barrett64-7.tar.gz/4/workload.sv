`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_66; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_70; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_72; // decl: <none>; prim: <none>
    logic mul_tree_38_73; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_77; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_78; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_81; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_84; // decl: <none>; prim: <none>
    logic mul_tree_38_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_89; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_90; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_93; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_94; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_96; // decl: <none>; prim: <none>
    logic mul_tree_38_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_98; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_101; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_102; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_104; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_105; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_106; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_108; // decl: <none>; prim: <none>
    logic mul_tree_38_109; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_110; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_114; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_115; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_116; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_119; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_120; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_121; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_122; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_123; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_124; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_125; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_126; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_127; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_128; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_129; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_130; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_131; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_132; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_133; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_134; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_135; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_136; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_137; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_138; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_139; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_140; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_141; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_142; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_143; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_144; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_160; // decl: <none>; prim: <none>
    logic mul_tree_39_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_162; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_163; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_164; // decl: <none>; prim: <none>
    logic mul_tree_39_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_166; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_167; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_168; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_169; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_170; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_171; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_172; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_173; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_174; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_175; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_176; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_177; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_178; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_179; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_180; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_181; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_182; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_183; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_184; // decl: <none>; prim: <none>
    logic [31:0] limb_16_185; // decl: <none>; prim: <none>
    logic [31:0] limb_16_186; // decl: <none>; prim: <none>
    logic [31:0] limb_16_187; // decl: <none>; prim: <none>
    logic [32:0] limb_16_188; // decl: <none>; prim: <none>
    logic [31:0] limb_16_189; // decl: <none>; prim: <none>
    logic limb_16_190; // decl: <none>; prim: <none>
    logic [31:0] limb_16_191; // decl: <none>; prim: <none>
    logic [31:0] limb_16_192; // decl: <none>; prim: <none>
    logic [31:0] limb_16_193; // decl: <none>; prim: <none>
    logic [32:0] limb_16_194; // decl: <none>; prim: <none>
    logic [31:0] limb_16_195; // decl: <none>; prim: <none>
    logic limb_16_196; // decl: <none>; prim: <none>
    logic [31:0] limb_16_197; // decl: <none>; prim: <none>
    logic [31:0] limb_16_198; // decl: <none>; prim: <none>
    logic [31:0] limb_16_199; // decl: <none>; prim: <none>
    logic [32:0] limb_16_200; // decl: <none>; prim: <none>
    logic [31:0] limb_16_201; // decl: <none>; prim: <none>
    logic limb_16_202; // decl: <none>; prim: <none>
    logic [31:0] limb_16_203; // decl: <none>; prim: <none>
    logic [31:0] limb_16_204; // decl: <none>; prim: <none>
    logic [31:0] limb_16_205; // decl: <none>; prim: <none>
    logic [32:0] limb_16_206; // decl: <none>; prim: <none>
    logic [31:0] limb_16_207; // decl: <none>; prim: <none>
    logic limb_16_208; // decl: <none>; prim: <none>
    logic limb_16_209; // decl: <none>; prim: <none>
    logic limb_16_210; // decl: <none>; prim: <none>
    logic limb_16_211; // decl: <none>; prim: <none>
    logic [1:0] limb_16_212; // decl: <none>; prim: <none>
    logic limb_16_213; // decl: <none>; prim: <none>
    logic [128:0] limb_16_214; // decl: <none>; prim: <none>
    logic [31:0] limb_18_215; // decl: <none>; prim: <none>
    logic [31:0] limb_18_216; // decl: <none>; prim: <none>
    logic [31:0] limb_18_217; // decl: <none>; prim: <none>
    logic [32:0] limb_18_218; // decl: <none>; prim: <none>
    logic [31:0] limb_18_219; // decl: <none>; prim: <none>
    logic limb_18_220; // decl: <none>; prim: <none>
    logic [31:0] limb_18_221; // decl: <none>; prim: <none>
    logic [31:0] limb_18_222; // decl: <none>; prim: <none>
    logic [31:0] limb_18_223; // decl: <none>; prim: <none>
    logic [32:0] limb_18_224; // decl: <none>; prim: <none>
    logic [31:0] limb_18_225; // decl: <none>; prim: <none>
    logic limb_18_226; // decl: <none>; prim: <none>
    logic [31:0] limb_18_227; // decl: <none>; prim: <none>
    logic [31:0] limb_18_228; // decl: <none>; prim: <none>
    logic [31:0] limb_18_229; // decl: <none>; prim: <none>
    logic [32:0] limb_18_230; // decl: <none>; prim: <none>
    logic [31:0] limb_18_231; // decl: <none>; prim: <none>
    logic limb_18_232; // decl: <none>; prim: <none>
    logic [31:0] limb_18_233; // decl: <none>; prim: <none>
    logic [31:0] limb_18_234; // decl: <none>; prim: <none>
    logic [31:0] limb_18_235; // decl: <none>; prim: <none>
    logic [32:0] limb_18_236; // decl: <none>; prim: <none>
    logic [31:0] limb_18_237; // decl: <none>; prim: <none>
    logic limb_18_238; // decl: <none>; prim: <none>
    logic limb_18_239; // decl: <none>; prim: <none>
    logic limb_18_240; // decl: <none>; prim: <none>
    logic limb_18_241; // decl: <none>; prim: <none>
    logic [1:0] limb_18_242; // decl: <none>; prim: <none>
    logic limb_18_243; // decl: <none>; prim: <none>
    logic [128:0] limb_18_244; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s6; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s6; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_34_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_185_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_185_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_185_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_191_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_191_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_197_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_203_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_203_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_209_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_209_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_209_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_217_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_222_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_223_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_228_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_228_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_229_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_229_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_229_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_229_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_229_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_234_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_234_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_234_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_234_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_234_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_235_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_235_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_240_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_240_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_240_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_241_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_241_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_241_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_241_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s3 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    assign s8_norm_sub_14_v0 = limb_16_214; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    assign s8_norm_sub_18_v0 = limb_18_244; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_64; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_145; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_184; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(32'(mul_tree_37_40)), .b(32'(mul_tree_37_41)), .cin(1'b0), .value(mul_tree_37_42));
    assign mul_tree_37_43 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_45Core rtlzz_owner_45(.a(32'(mul_tree_37_43)), .b(32'(mul_tree_37_44)), .cin(1'b0), .value(mul_tree_37_45));
    assign mul_tree_37_46 = {mul_tree_37_45, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(32'(mul_tree_37_47)), .b(32'(mul_tree_37_48)), .cin(1'b0), .value(mul_tree_37_49));
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(32'(mul_tree_37_51)), .b(32'(mul_tree_37_52)), .cin(1'b0), .value(mul_tree_37_53));
    assign mul_tree_37_54 = {mul_tree_37_53, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_56 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_57Core rtlzz_owner_57(.a(64'(mul_tree_37_55)), .b(96'(mul_tree_37_56)), .cin(1'h0), .value(mul_tree_37_57));
    assign mul_tree_37_58 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_59 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_60Core rtlzz_owner_60(.a(96'(mul_tree_37_58)), .b(128'(mul_tree_37_59)), .cin(1'h0), .value(mul_tree_37_60[127:0]));
    assign mul_tree_37_60[128:128] = '0;
    assign mul_tree_37_61 = ({33'h0, rtlzz_pipe_57_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_62 = ({1'h0, rtlzz_pipe_60_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_63Core rtlzz_owner_63(.a(97'(mul_tree_37_61)), .b(129'(mul_tree_37_62)), .cin(1'h0), .value(mul_tree_37_63[127:0]));
    assign mul_tree_37_63[129:128] = '0;
    assign mul_tree_37_64 = mul_tree_37_63[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_65 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_66 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(32'(mul_tree_38_65)), .b(32'(mul_tree_38_66)), .cin(1'b0), .value(mul_tree_38_67));
    assign mul_tree_38_68 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_69 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(32'(mul_tree_38_68)), .b(32'(mul_tree_38_69)), .cin(1'b0), .value(mul_tree_38_70));
    assign mul_tree_38_71 = {mul_tree_38_70, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_72 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_73 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(32'(mul_tree_38_72)), .b(1'(mul_tree_38_73)), .cin(1'b0), .value(mul_tree_38_74));
    assign mul_tree_38_75 = {mul_tree_38_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_76 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_77 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(32'(mul_tree_38_76)), .b(32'(mul_tree_38_77)), .cin(1'b0), .value(mul_tree_38_78));
    assign mul_tree_38_79 = {mul_tree_38_78, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_80 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_81 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(32'(mul_tree_38_80)), .b(32'(mul_tree_38_81)), .cin(1'b0), .value(mul_tree_38_82));
    assign mul_tree_38_83 = {mul_tree_38_82, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_84 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_85 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(32'(mul_tree_38_84)), .b(1'(mul_tree_38_85)), .cin(1'b0), .value(mul_tree_38_86));
    assign mul_tree_38_87 = {mul_tree_38_86, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_88 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_89 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(32'(mul_tree_38_88)), .b(32'(mul_tree_38_89)), .cin(1'b0), .value(mul_tree_38_90));
    assign mul_tree_38_91 = {mul_tree_38_90, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_92 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_93 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(32'(mul_tree_38_92)), .b(32'(mul_tree_38_93)), .cin(1'b0), .value(mul_tree_38_94));
    assign mul_tree_38_95 = {mul_tree_38_94, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_96 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_97 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(32'(mul_tree_38_96)), .b(1'(mul_tree_38_97)), .cin(1'b0), .value(mul_tree_38_98));
    assign mul_tree_38_99 = {mul_tree_38_98, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_100 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_101 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(32'(mul_tree_38_100)), .b(32'(mul_tree_38_101)), .cin(1'b0), .value(mul_tree_38_102));
    assign mul_tree_38_103 = {mul_tree_38_102, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_104 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_105 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(32'(mul_tree_38_104)), .b(32'(mul_tree_38_105)), .cin(1'b0), .value(mul_tree_38_106));
    assign mul_tree_38_107 = {mul_tree_38_106, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_108 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_109 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(32'(mul_tree_38_108)), .b(1'(mul_tree_38_109)), .cin(1'b0), .value(mul_tree_38_110));
    assign mul_tree_38_111 = {mul_tree_38_110, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_112 = ({33'h0, rtlzz_pipe_67_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_113 = ({1'h0, rtlzz_pipe_71_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_115 = ({1'h0, rtlzz_pipe_75_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_116 = ({2'h0, rtlzz_pipe_79_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_118 = ({2'h0, rtlzz_pipe_83_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_119 = ({1'h0, rtlzz_pipe_87_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_121 = ({33'h0, rtlzz_pipe_91_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_122 = ({1'h0, rtlzz_pipe_95_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_124 = ({1'h0, rtlzz_pipe_99_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_125 = ({2'h0, rtlzz_pipe_103_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_127 = ({2'h0, rtlzz_pipe_107_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_128 = ({1'h0, rtlzz_pipe_111_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_130 = ({2'h0, mul_tree_38_114}); // decl: <none>; prim: <none>
    assign mul_tree_38_131 = ({1'h0, mul_tree_38_117}); // decl: <none>; prim: <none>
    assign mul_tree_38_133 = ({32'h0, mul_tree_38_120}); // decl: <none>; prim: <none>
    assign mul_tree_38_134 = ({1'h0, mul_tree_38_123}); // decl: <none>; prim: <none>
    assign mul_tree_38_136 = ({33'h0, mul_tree_38_126}); // decl: <none>; prim: <none>
    assign mul_tree_38_137 = ({1'h0, mul_tree_38_129}); // decl: <none>; prim: <none>
    assign mul_tree_38_139 = ({64'h0, mul_tree_38_132}); // decl: <none>; prim: <none>
    assign mul_tree_38_140 = ({1'h0, mul_tree_38_135}); // decl: <none>; prim: <none>
    assign mul_tree_38_142 = ({33'h0, mul_tree_38_141}); // decl: <none>; prim: <none>
    assign mul_tree_38_143 = ({1'h0, mul_tree_38_138}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144_reduce rtlzz_reduce_144(.i275(rtlzz_pipe_67_s6), .i276(rtlzz_pipe_71_s6), .i277(rtlzz_pipe_75_s6), .i278(rtlzz_pipe_79_s6), .i279(rtlzz_pipe_83_s6), .i280(rtlzz_pipe_87_s6), .i281(rtlzz_pipe_91_s6), .i282(rtlzz_pipe_95_s6), .i283(rtlzz_pipe_99_s6), .i284(rtlzz_pipe_103_s6), .i285(rtlzz_pipe_107_s6), .i286(rtlzz_pipe_111_s6), .y(mul_tree_38_144));
    assign mul_tree_38_145 = mul_tree_38_144[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_146 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_147 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_39_146)), .b(32'(mul_tree_39_147)), .cin(1'b0), .value(mul_tree_39_148));
    assign mul_tree_39_149 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_150 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_39_149)), .b(32'(mul_tree_39_150)), .cin(1'b0), .value(mul_tree_39_151));
    assign mul_tree_39_152 = {mul_tree_39_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_153 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_154 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_39_153)), .b(32'(mul_tree_39_154)), .cin(1'b0), .value(mul_tree_39_155));
    assign mul_tree_39_156 = {mul_tree_39_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_157 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_158 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_39_157)), .b(32'(mul_tree_39_158)), .cin(1'b0), .value(mul_tree_39_159));
    assign mul_tree_39_160 = {mul_tree_39_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_161 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_162 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(1'(mul_tree_39_161)), .b(32'(mul_tree_39_162)), .cin(1'b0), .value(mul_tree_39_163));
    assign mul_tree_39_164 = {mul_tree_39_163, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_165 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_166 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(1'(mul_tree_39_165)), .b(32'(mul_tree_39_166)), .cin(1'b0), .value(mul_tree_39_167));
    assign mul_tree_39_168 = {mul_tree_39_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_169 = ({33'h0, mul_tree_39_148}); // decl: <none>; prim: <none>
    assign mul_tree_39_170 = ({1'h0, mul_tree_39_152}); // decl: <none>; prim: <none>
    assign mul_tree_39_172 = ({33'h0, mul_tree_39_156}); // decl: <none>; prim: <none>
    assign mul_tree_39_173 = ({1'h0, mul_tree_39_160}); // decl: <none>; prim: <none>
    assign mul_tree_39_175 = ({33'h0, mul_tree_39_164}); // decl: <none>; prim: <none>
    assign mul_tree_39_176 = ({1'h0, mul_tree_39_168}); // decl: <none>; prim: <none>
    assign mul_tree_39_178 = ({33'h0, mul_tree_39_171}); // decl: <none>; prim: <none>
    assign mul_tree_39_179 = ({1'h0, mul_tree_39_174}); // decl: <none>; prim: <none>
    assign mul_tree_39_181 = ({1'h0, mul_tree_39_180}); // decl: <none>; prim: <none>
    assign mul_tree_39_182 = ({1'h0, mul_tree_39_177}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_183_reduce rtlzz_reduce_183(.i148(mul_tree_39_148), .i151(mul_tree_39_151), .i155(mul_tree_39_155), .i159(mul_tree_39_159), .i163(mul_tree_39_163), .i167(mul_tree_39_167), .y(mul_tree_39_183));
    assign mul_tree_39_184 = mul_tree_39_183[128:0]; // decl: <none>; prim: <none>
    assign limb_16_185 = tmp_workload_top_int_129__16_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_16_186 = n3_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_16_187 = (~limb_16_186); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(32'(rtlzz_pipe_185_s7)), .b(32'(limb_16_187)), .cin(1'h1), .value(limb_16_188));
    assign limb_16_189 = limb_16_188[31:0]; // decl: <none>; prim: <none>
    assign limb_16_190 = limb_16_188[32]; // decl: <none>; prim: <none>
    assign limb_16_191 = tmp_workload_top_int_129__16_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_16_192 = n3_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_16_193 = (~limb_16_192); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(32'(rtlzz_pipe_191_s7)), .b(32'(limb_16_193)), .cin(limb_16_190), .value(limb_16_194));
    assign limb_16_195 = limb_16_194[31:0]; // decl: <none>; prim: <none>
    assign limb_16_196 = limb_16_194[32]; // decl: <none>; prim: <none>
    assign limb_16_197 = tmp_workload_top_int_129__16_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_16_198 = n3_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_16_199 = (~limb_16_198); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_200Core rtlzz_owner_200(.a(32'(rtlzz_pipe_197_s7)), .b(32'(limb_16_199)), .cin(limb_16_196), .value(limb_16_200));
    assign limb_16_201 = limb_16_200[31:0]; // decl: <none>; prim: <none>
    assign limb_16_202 = limb_16_200[32]; // decl: <none>; prim: <none>
    assign limb_16_203 = tmp_workload_top_int_129__16_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_16_204 = n3_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_16_205 = (~limb_16_204); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(32'(rtlzz_pipe_203_s7)), .b(32'(limb_16_205)), .cin(limb_16_202), .value(limb_16_206));
    assign limb_16_207 = limb_16_206[31:0]; // decl: <none>; prim: <none>
    assign limb_16_208 = limb_16_206[32]; // decl: <none>; prim: <none>
    assign limb_16_209 = tmp_workload_top_int_129__16_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_210 = n3_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_211 = (~limb_16_210); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_212Core rtlzz_owner_212(.a(1'(rtlzz_pipe_209_s7)), .b(1'(limb_16_211)), .cin(limb_16_208), .value(limb_16_212[0:0]));
    assign limb_16_212[1:1] = '0;
    assign limb_16_213 = limb_16_212[0]; // decl: <none>; prim: <none>
    assign limb_16_214 = {limb_16_213, limb_16_207, limb_16_201, limb_16_195, limb_16_189}; // decl: <none>; prim: <none>
    assign limb_18_215 = s8_norm_sub_14_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_18_216 = tmp_workload_top_int_129__13_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_18_217 = (~limb_18_216); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(32'(limb_18_215)), .b(32'(rtlzz_pipe_217_s7)), .cin(1'h1), .value(limb_18_218));
    assign limb_18_219 = limb_18_218[31:0]; // decl: <none>; prim: <none>
    assign limb_18_220 = limb_18_218[32]; // decl: <none>; prim: <none>
    assign limb_18_221 = s8_norm_sub_14_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_18_222 = tmp_workload_top_int_129__13_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_18_223 = (~rtlzz_pipe_222_s1); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_224Core rtlzz_owner_224(.a(32'(limb_18_221)), .b(32'(rtlzz_pipe_223_s7)), .cin(limb_18_220), .value(limb_18_224[31:0]));
    assign limb_18_224[32:32] = '0;
    assign limb_18_225 = limb_18_224[31:0]; // decl: <none>; prim: <none>
    assign limb_18_226 = limb_18_224[32]; // decl: <none>; prim: <none>
    assign limb_18_227 = s8_norm_sub_14_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_18_228 = tmp_workload_top_int_129__13_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_18_229 = (~rtlzz_pipe_228_s2); // decl: <none>; prim: <none>
    assign limb_18_230 = 33'((({1'h0, limb_18_227}) + ({1'h0, rtlzz_pipe_229_s7}) + ({32'h0, limb_18_226}))); // decl: <none>; prim: <none>
    assign limb_18_231 = limb_18_230[31:0]; // decl: <none>; prim: <none>
    assign limb_18_232 = limb_18_230[32]; // decl: <none>; prim: <none>
    assign limb_18_233 = s8_norm_sub_14_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_18_234 = tmp_workload_top_int_129__13_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_18_235 = (~rtlzz_pipe_234_s5); // decl: <none>; prim: <none>
    assign limb_18_236 = 33'((({1'h0, limb_18_233}) + ({1'h0, rtlzz_pipe_235_s7}) + ({32'h0, limb_18_232}))); // decl: <none>; prim: <none>
    assign limb_18_237 = limb_18_236[31:0]; // decl: <none>; prim: <none>
    assign limb_18_238 = limb_18_236[32]; // decl: <none>; prim: <none>
    assign limb_18_239 = s8_norm_sub_14_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_240 = tmp_workload_top_int_129__13_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_241 = (~rtlzz_pipe_240_s3); // decl: <none>; prim: <none>
    assign limb_18_242 = 2'((({1'h0, limb_18_239}) + ({1'h0, rtlzz_pipe_241_s7}) + ({1'h0, limb_18_238}))); // decl: <none>; prim: <none>
    assign limb_18_243 = limb_18_242[0]; // decl: <none>; prim: <none>
    assign limb_18_244 = {limb_18_243, limb_18_237, limb_18_231, limb_18_225, limb_18_219}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 96'h0;
            rtlzz_pipe_54_s1 <= 128'h0;
            rtlzz_pipe_57_s2 <= 97'h0;
            rtlzz_pipe_60_s2 <= 129'h0;
            rtlzz_pipe_23_s3 <= 193'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_25_s4 <= 129'h0;
            rtlzz_pipe_31_s4 <= 128'h0;
            rtlzz_pipe_31_s5 <= 128'h0;
            rtlzz_pipe_67_s6 <= 64'h0;
            rtlzz_pipe_71_s6 <= 96'h0;
            rtlzz_pipe_75_s6 <= 97'h0;
            rtlzz_pipe_79_s6 <= 96'h0;
            rtlzz_pipe_83_s6 <= 128'h0;
            rtlzz_pipe_87_s6 <= 129'h0;
            rtlzz_pipe_91_s6 <= 128'h0;
            rtlzz_pipe_95_s6 <= 160'h0;
            rtlzz_pipe_99_s6 <= 161'h0;
            rtlzz_pipe_103_s6 <= 160'h0;
            rtlzz_pipe_107_s6 <= 192'h0;
            rtlzz_pipe_111_s6 <= 193'h0;
            rtlzz_pipe_34_s7 <= 65'h0;
            rtlzz_pipe_185_s5 <= 32'h0;
            rtlzz_pipe_185_s6 <= 32'h0;
            rtlzz_pipe_185_s7 <= 32'h0;
            rtlzz_pipe_191_s5 <= 32'h0;
            rtlzz_pipe_191_s6 <= 32'h0;
            rtlzz_pipe_191_s7 <= 32'h0;
            rtlzz_pipe_197_s5 <= 32'h0;
            rtlzz_pipe_197_s6 <= 32'h0;
            rtlzz_pipe_197_s7 <= 32'h0;
            rtlzz_pipe_203_s5 <= 32'h0;
            rtlzz_pipe_203_s6 <= 32'h0;
            rtlzz_pipe_203_s7 <= 32'h0;
            rtlzz_pipe_209_s5 <= 1'h0;
            rtlzz_pipe_209_s6 <= 1'h0;
            rtlzz_pipe_209_s7 <= 1'h0;
            rtlzz_pipe_217_s1 <= 32'hffffffff;
            rtlzz_pipe_217_s2 <= 32'hffffffff;
            rtlzz_pipe_217_s3 <= 32'hffffffff;
            rtlzz_pipe_217_s4 <= 32'hffffffff;
            rtlzz_pipe_217_s5 <= 32'hffffffff;
            rtlzz_pipe_217_s6 <= 32'hffffffff;
            rtlzz_pipe_217_s7 <= 32'hffffffff;
            rtlzz_pipe_222_s1 <= 32'h0;
            rtlzz_pipe_223_s2 <= 32'hffffffff;
            rtlzz_pipe_223_s3 <= 32'hffffffff;
            rtlzz_pipe_223_s4 <= 32'hffffffff;
            rtlzz_pipe_223_s5 <= 32'hffffffff;
            rtlzz_pipe_223_s6 <= 32'hffffffff;
            rtlzz_pipe_223_s7 <= 32'hffffffff;
            rtlzz_pipe_228_s1 <= 32'h0;
            rtlzz_pipe_228_s2 <= 32'h0;
            rtlzz_pipe_229_s3 <= 32'hffffffff;
            rtlzz_pipe_229_s4 <= 32'hffffffff;
            rtlzz_pipe_229_s5 <= 32'hffffffff;
            rtlzz_pipe_229_s6 <= 32'hffffffff;
            rtlzz_pipe_229_s7 <= 32'hffffffff;
            rtlzz_pipe_234_s1 <= 32'h0;
            rtlzz_pipe_234_s2 <= 32'h0;
            rtlzz_pipe_234_s3 <= 32'h0;
            rtlzz_pipe_234_s4 <= 32'h0;
            rtlzz_pipe_234_s5 <= 32'h0;
            rtlzz_pipe_235_s6 <= 32'hffffffff;
            rtlzz_pipe_235_s7 <= 32'hffffffff;
            rtlzz_pipe_240_s1 <= 1'h0;
            rtlzz_pipe_240_s2 <= 1'h0;
            rtlzz_pipe_240_s3 <= 1'h0;
            rtlzz_pipe_241_s4 <= 1'h1;
            rtlzz_pipe_241_s5 <= 1'h1;
            rtlzz_pipe_241_s6 <= 1'h1;
            rtlzz_pipe_241_s7 <= 1'h1;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= mul_tree_37_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= mul_tree_37_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_25_s4 <= rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_31_s5 <= rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= mul_tree_38_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_71_s6 <= mul_tree_38_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= mul_tree_38_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= mul_tree_38_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= mul_tree_38_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= mul_tree_38_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_91_s6 <= mul_tree_38_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_95_s6 <= mul_tree_38_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_99_s6 <= mul_tree_38_99; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= mul_tree_38_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= mul_tree_38_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= mul_tree_38_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_34_s7 <= mul_precision_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_185_s5 <= limb_16_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_185_s6 <= rtlzz_pipe_185_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_185_s7 <= rtlzz_pipe_185_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_191_s5 <= limb_16_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_191_s6 <= rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_191_s7 <= rtlzz_pipe_191_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_197_s5 <= limb_16_197; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_197_s6 <= rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_197_s7 <= rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_203_s5 <= limb_16_203; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_203_s6 <= rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_203_s7 <= rtlzz_pipe_203_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_209_s5 <= limb_16_209; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_209_s6 <= rtlzz_pipe_209_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_209_s7 <= rtlzz_pipe_209_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_217_s1 <= limb_18_217; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_217_s2 <= rtlzz_pipe_217_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_217_s3 <= rtlzz_pipe_217_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_217_s4 <= rtlzz_pipe_217_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_217_s5 <= rtlzz_pipe_217_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_217_s6 <= rtlzz_pipe_217_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_217_s7 <= rtlzz_pipe_217_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_222_s1 <= limb_18_222; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_223_s2 <= limb_18_223; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_223_s3 <= rtlzz_pipe_223_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_223_s4 <= rtlzz_pipe_223_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_223_s5 <= rtlzz_pipe_223_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_223_s6 <= rtlzz_pipe_223_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_223_s7 <= rtlzz_pipe_223_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_228_s1 <= limb_18_228; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_228_s2 <= rtlzz_pipe_228_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_229_s3 <= limb_18_229; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_229_s4 <= rtlzz_pipe_229_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_229_s5 <= rtlzz_pipe_229_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_229_s6 <= rtlzz_pipe_229_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_229_s7 <= rtlzz_pipe_229_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_234_s1 <= limb_18_234; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_234_s2 <= rtlzz_pipe_234_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_234_s3 <= rtlzz_pipe_234_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_234_s4 <= rtlzz_pipe_234_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_234_s5 <= rtlzz_pipe_234_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_235_s6 <= limb_18_235; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_235_s7 <= rtlzz_pipe_235_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_240_s1 <= limb_18_240; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_240_s2 <= rtlzz_pipe_240_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_240_s3 <= rtlzz_pipe_240_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_241_s4 <= limb_18_241; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_241_s5 <= rtlzz_pipe_241_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_241_s6 <= rtlzz_pipe_241_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_241_s7 <= rtlzz_pipe_241_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144_reduce(input wire [63:0] i275, input wire [95:0] i276, input wire [96:0] i277, input wire [95:0] i278, input wire [127:0] i279, input wire [128:0] i280, input wire [127:0] i281, input wire [159:0] i282, input wire [160:0] i283, input wire [159:0] i284, input wire [191:0] i285, input wire [192:0] i286, output wire [195:0] y);
wire [192:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i275[63], i275[62], i275[61], i275[60], i275[59], i275[58], i275[57], i275[56], i275[55], i275[54], i275[53], i275[52], i275[51], i275[50], i275[49], i275[48], i275[47], i275[46], i275[45], i275[44], i275[43], i275[42], i275[41], i275[40], i275[39], i275[38], i275[37], i275[36], i275[35], i275[34], i275[33], i275[32], i275[31], i275[30], i275[29], i275[28], i275[27], i275[26], i275[25], i275[24], i275[23], i275[22], i275[21], i275[20], i275[19], i275[18], i275[17], i275[16], i275[15], i275[14], i275[13], i275[12], i275[11], i275[10], i275[9], i275[8], i275[7], i275[6], i275[5], i275[4], i275[3], i275[2], i275[1], i275[0]};
wire [192:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i276[95], i276[94], i276[93], i276[92], i276[91], i276[90], i276[89], i276[88], i276[87], i276[86], i276[85], i276[84], i276[83], i276[82], i276[81], i276[80], i276[79], i276[78], i276[77], i276[76], i276[75], i276[74], i276[73], i276[72], i276[71], i276[70], i276[69], i276[68], i276[67], i276[66], i276[65], i276[64], i276[63], i276[62], i276[61], i276[60], i276[59], i276[58], i276[57], i276[56], i276[55], i276[54], i276[53], i276[52], i276[51], i276[50], i276[49], i276[48], i276[47], i276[46], i276[45], i276[44], i276[43], i276[42], i276[41], i276[40], i276[39], i276[38], i276[37], i276[36], i276[35], i276[34], i276[33], i276[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i277[96], i277[95], i277[94], i277[93], i277[92], i277[91], i277[90], i277[89], i277[88], i277[87], i277[86], i277[85], i277[84], i277[83], i277[82], i277[81], i277[80], i277[79], i277[78], i277[77], i277[76], i277[75], i277[74], i277[73], i277[72], i277[71], i277[70], i277[69], i277[68], i277[67], i277[66], i277[65], i277[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i278[95], i278[94], i278[93], i278[92], i278[91], i278[90], i278[89], i278[88], i278[87], i278[86], i278[85], i278[84], i278[83], i278[82], i278[81], i278[80], i278[79], i278[78], i278[77], i278[76], i278[75], i278[74], i278[73], i278[72], i278[71], i278[70], i278[69], i278[68], i278[67], i278[66], i278[65], i278[64], i278[63], i278[62], i278[61], i278[60], i278[59], i278[58], i278[57], i278[56], i278[55], i278[54], i278[53], i278[52], i278[51], i278[50], i278[49], i278[48], i278[47], i278[46], i278[45], i278[44], i278[43], i278[42], i278[41], i278[40], i278[39], i278[38], i278[37], i278[36], i278[35], i278[34], i278[33], i278[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i279[127], i279[126], i279[125], i279[124], i279[123], i279[122], i279[121], i279[120], i279[119], i279[118], i279[117], i279[116], i279[115], i279[114], i279[113], i279[112], i279[111], i279[110], i279[109], i279[108], i279[107], i279[106], i279[105], i279[104], i279[103], i279[102], i279[101], i279[100], i279[99], i279[98], i279[97], i279[96], i279[95], i279[94], i279[93], i279[92], i279[91], i279[90], i279[89], i279[88], i279[87], i279[86], i279[85], i279[84], i279[83], i279[82], i279[81], i279[80], i279[79], i279[78], i279[77], i279[76], i279[75], i279[74], i279[73], i279[72], i279[71], i279[70], i279[69], i279[68], i279[67], i279[66], i279[65], i279[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i280[128], i280[127], i280[126], i280[125], i280[124], i280[123], i280[122], i280[121], i280[120], i280[119], i280[118], i280[117], i280[116], i280[115], i280[114], i280[113], i280[112], i280[111], i280[110], i280[109], i280[108], i280[107], i280[106], i280[105], i280[104], i280[103], i280[102], i280[101], i280[100], i280[99], i280[98], i280[97], i280[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i281[127], i281[126], i281[125], i281[124], i281[123], i281[122], i281[121], i281[120], i281[119], i281[118], i281[117], i281[116], i281[115], i281[114], i281[113], i281[112], i281[111], i281[110], i281[109], i281[108], i281[107], i281[106], i281[105], i281[104], i281[103], i281[102], i281[101], i281[100], i281[99], i281[98], i281[97], i281[96], i281[95], i281[94], i281[93], i281[92], i281[91], i281[90], i281[89], i281[88], i281[87], i281[86], i281[85], i281[84], i281[83], i281[82], i281[81], i281[80], i281[79], i281[78], i281[77], i281[76], i281[75], i281[74], i281[73], i281[72], i281[71], i281[70], i281[69], i281[68], i281[67], i281[66], i281[65], i281[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i282[159], i282[158], i282[157], i282[156], i282[155], i282[154], i282[153], i282[152], i282[151], i282[150], i282[149], i282[148], i282[147], i282[146], i282[145], i282[144], i282[143], i282[142], i282[141], i282[140], i282[139], i282[138], i282[137], i282[136], i282[135], i282[134], i282[133], i282[132], i282[131], i282[130], i282[129], i282[128], i282[127], i282[126], i282[125], i282[124], i282[123], i282[122], i282[121], i282[120], i282[119], i282[118], i282[117], i282[116], i282[115], i282[114], i282[113], i282[112], i282[111], i282[110], i282[109], i282[108], i282[107], i282[106], i282[105], i282[104], i282[103], i282[102], i282[101], i282[100], i282[99], i282[98], i282[97], i282[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i283[160], i283[159], i283[158], i283[157], i283[156], i283[155], i283[154], i283[153], i283[152], i283[151], i283[150], i283[149], i283[148], i283[147], i283[146], i283[145], i283[144], i283[143], i283[142], i283[141], i283[140], i283[139], i283[138], i283[137], i283[136], i283[135], i283[134], i283[133], i283[132], i283[131], i283[130], i283[129], i283[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t9 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i284[159], i284[158], i284[157], i284[156], i284[155], i284[154], i284[153], i284[152], i284[151], i284[150], i284[149], i284[148], i284[147], i284[146], i284[145], i284[144], i284[143], i284[142], i284[141], i284[140], i284[139], i284[138], i284[137], i284[136], i284[135], i284[134], i284[133], i284[132], i284[131], i284[130], i284[129], i284[128], i284[127], i284[126], i284[125], i284[124], i284[123], i284[122], i284[121], i284[120], i284[119], i284[118], i284[117], i284[116], i284[115], i284[114], i284[113], i284[112], i284[111], i284[110], i284[109], i284[108], i284[107], i284[106], i284[105], i284[104], i284[103], i284[102], i284[101], i284[100], i284[99], i284[98], i284[97], i284[96], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t10 = {1'b0, i285[191], i285[190], i285[189], i285[188], i285[187], i285[186], i285[185], i285[184], i285[183], i285[182], i285[181], i285[180], i285[179], i285[178], i285[177], i285[176], i285[175], i285[174], i285[173], i285[172], i285[171], i285[170], i285[169], i285[168], i285[167], i285[166], i285[165], i285[164], i285[163], i285[162], i285[161], i285[160], i285[159], i285[158], i285[157], i285[156], i285[155], i285[154], i285[153], i285[152], i285[151], i285[150], i285[149], i285[148], i285[147], i285[146], i285[145], i285[144], i285[143], i285[142], i285[141], i285[140], i285[139], i285[138], i285[137], i285[136], i285[135], i285[134], i285[133], i285[132], i285[131], i285[130], i285[129], i285[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] t11 = {i286[192], i286[191], i286[190], i286[189], i286[188], i286[187], i286[186], i286[185], i286[184], i286[183], i286[182], i286[181], i286[180], i286[179], i286[178], i286[177], i286[176], i286[175], i286[174], i286[173], i286[172], i286[171], i286[170], i286[169], i286[168], i286[167], i286[166], i286[165], i286[164], i286[163], i286[162], i286[161], i286[160], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [192:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_183_reduce(input wire [63:0] i148, input wire [63:0] i151, input wire [63:0] i155, input wire [63:0] i159, input wire [32:0] i163, input wire [32:0] i167, output wire [130:0] y);
wire [128:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i148[63], i148[62], i148[61], i148[60], i148[59], i148[58], i148[57], i148[56], i148[55], i148[54], i148[53], i148[52], i148[51], i148[50], i148[49], i148[48], i148[47], i148[46], i148[45], i148[44], i148[43], i148[42], i148[41], i148[40], i148[39], i148[38], i148[37], i148[36], i148[35], i148[34], i148[33], i148[32], i148[31], i148[30], i148[29], i148[28], i148[27], i148[26], i148[25], i148[24], i148[23], i148[22], i148[21], i148[20], i148[19], i148[18], i148[17], i148[16], i148[15], i148[14], i148[13], i148[12], i148[11], i148[10], i148[9], i148[8], i148[7], i148[6], i148[5], i148[4], i148[3], i148[2], i148[1], i148[0]};
wire [128:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i151[63], i151[62], i151[61], i151[60], i151[59], i151[58], i151[57], i151[56], i151[55], i151[54], i151[53], i151[52], i151[51], i151[50], i151[49], i151[48], i151[47], i151[46], i151[45], i151[44], i151[43], i151[42], i151[41], i151[40], i151[39], i151[38], i151[37], i151[36], i151[35], i151[34], i151[33], i151[32], i151[31], i151[30], i151[29], i151[28], i151[27], i151[26], i151[25], i151[24], i151[23], i151[22], i151[21], i151[20], i151[19], i151[18], i151[17], i151[16], i151[15], i151[14], i151[13], i151[12], i151[11], i151[10], i151[9], i151[8], i151[7], i151[6], i151[5], i151[4], i151[3], i151[2], i151[1], i151[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i155[63], i155[62], i155[61], i155[60], i155[59], i155[58], i155[57], i155[56], i155[55], i155[54], i155[53], i155[52], i155[51], i155[50], i155[49], i155[48], i155[47], i155[46], i155[45], i155[44], i155[43], i155[42], i155[41], i155[40], i155[39], i155[38], i155[37], i155[36], i155[35], i155[34], i155[33], i155[32], i155[31], i155[30], i155[29], i155[28], i155[27], i155[26], i155[25], i155[24], i155[23], i155[22], i155[21], i155[20], i155[19], i155[18], i155[17], i155[16], i155[15], i155[14], i155[13], i155[12], i155[11], i155[10], i155[9], i155[8], i155[7], i155[6], i155[5], i155[4], i155[3], i155[2], i155[1], i155[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t3 = {1'b0, i159[63], i159[62], i159[61], i159[60], i159[59], i159[58], i159[57], i159[56], i159[55], i159[54], i159[53], i159[52], i159[51], i159[50], i159[49], i159[48], i159[47], i159[46], i159[45], i159[44], i159[43], i159[42], i159[41], i159[40], i159[39], i159[38], i159[37], i159[36], i159[35], i159[34], i159[33], i159[32], i159[31], i159[30], i159[29], i159[28], i159[27], i159[26], i159[25], i159[24], i159[23], i159[22], i159[21], i159[20], i159[19], i159[18], i159[17], i159[16], i159[15], i159[14], i159[13], i159[12], i159[11], i159[10], i159[9], i159[8], i159[7], i159[6], i159[5], i159[4], i159[3], i159[2], i159[1], i159[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i163[32], i163[31], i163[30], i163[29], i163[28], i163[27], i163[26], i163[25], i163[24], i163[23], i163[22], i163[21], i163[20], i163[19], i163[18], i163[17], i163[16], i163[15], i163[14], i163[13], i163[12], i163[11], i163[10], i163[9], i163[8], i163[7], i163[6], i163[5], i163[4], i163[3], i163[2], i163[1], i163[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] t5 = {i167[32], i167[31], i167[30], i167[29], i167[28], i167[27], i167[26], i167[25], i167[24], i167[23], i167[22], i167[21], i167[20], i167[19], i167[18], i167[17], i167[16], i167[15], i167[14], i167[13], i167[12], i167[11], i167[10], i167[9], i167[8], i167[7], i167[6], i167[5], i167[4], i167[3], i167[2], i167[1], i167[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [128:0] sum = t0 + t1 + t2 + t3 + t4 + t5;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_45();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_57();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_60();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_63();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_212();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_224();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
