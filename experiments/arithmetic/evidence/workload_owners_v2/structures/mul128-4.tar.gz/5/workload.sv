`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [63:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_3_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] rtlzz_pipe_3_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(64'(mul_tree_10_11)), .b(64'(mul_tree_10_12)), .cin(1'b0), .value(mul_tree_10_13));
    assign mul_tree_10_14 = mul_precision_8[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_16Core rtlzz_owner_16(.a(64'(mul_tree_10_14)), .b(64'(mul_tree_10_15)), .cin(1'b0), .value(mul_tree_10_16));
    assign mul_tree_10_17 = {mul_tree_10_16, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(64'(mul_tree_10_18)), .b(64'(mul_tree_10_19)), .cin(1'b0), .value(mul_tree_10_20));
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_24Core rtlzz_owner_24(.a(64'(mul_tree_10_22)), .b(64'(mul_tree_10_23)), .cin(1'b0), .value(mul_tree_10_24));
    assign mul_tree_10_25 = {mul_tree_10_24, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({65'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({65'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({65'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34_reduce rtlzz_reduce_34(.i36(rtlzz_pipe_13_s1), .i37(rtlzz_pipe_17_s1), .i38(rtlzz_pipe_21_s1), .i39(rtlzz_pipe_25_s1), .y(mul_tree_10_34));
    assign mul_tree_10_35 = mul_tree_10_34[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 128'h0;
            rtlzz_pipe_17_s1 <= 192'h0;
            rtlzz_pipe_21_s1 <= 192'h0;
            rtlzz_pipe_25_s1 <= 256'h0;
            rtlzz_pipe_3_s2 <= 256'h0;
            rtlzz_pipe_3_s3 <= 256'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_3_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= rtlzz_pipe_3_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34_reduce(input wire [127:0] i36, input wire [191:0] i37, input wire [191:0] i38, input wire [255:0] i39, output wire [257:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i36[127], i36[126], i36[125], i36[124], i36[123], i36[122], i36[121], i36[120], i36[119], i36[118], i36[117], i36[116], i36[115], i36[114], i36[113], i36[112], i36[111], i36[110], i36[109], i36[108], i36[107], i36[106], i36[105], i36[104], i36[103], i36[102], i36[101], i36[100], i36[99], i36[98], i36[97], i36[96], i36[95], i36[94], i36[93], i36[92], i36[91], i36[90], i36[89], i36[88], i36[87], i36[86], i36[85], i36[84], i36[83], i36[82], i36[81], i36[80], i36[79], i36[78], i36[77], i36[76], i36[75], i36[74], i36[73], i36[72], i36[71], i36[70], i36[69], i36[68], i36[67], i36[66], i36[65], i36[64], i36[63], i36[62], i36[61], i36[60], i36[59], i36[58], i36[57], i36[56], i36[55], i36[54], i36[53], i36[52], i36[51], i36[50], i36[49], i36[48], i36[47], i36[46], i36[45], i36[44], i36[43], i36[42], i36[41], i36[40], i36[39], i36[38], i36[37], i36[36], i36[35], i36[34], i36[33], i36[32], i36[31], i36[30], i36[29], i36[28], i36[27], i36[26], i36[25], i36[24], i36[23], i36[22], i36[21], i36[20], i36[19], i36[18], i36[17], i36[16], i36[15], i36[14], i36[13], i36[12], i36[11], i36[10], i36[9], i36[8], i36[7], i36[6], i36[5], i36[4], i36[3], i36[2], i36[1], i36[0]};
wire [255:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i37[191], i37[190], i37[189], i37[188], i37[187], i37[186], i37[185], i37[184], i37[183], i37[182], i37[181], i37[180], i37[179], i37[178], i37[177], i37[176], i37[175], i37[174], i37[173], i37[172], i37[171], i37[170], i37[169], i37[168], i37[167], i37[166], i37[165], i37[164], i37[163], i37[162], i37[161], i37[160], i37[159], i37[158], i37[157], i37[156], i37[155], i37[154], i37[153], i37[152], i37[151], i37[150], i37[149], i37[148], i37[147], i37[146], i37[145], i37[144], i37[143], i37[142], i37[141], i37[140], i37[139], i37[138], i37[137], i37[136], i37[135], i37[134], i37[133], i37[132], i37[131], i37[130], i37[129], i37[128], i37[127], i37[126], i37[125], i37[124], i37[123], i37[122], i37[121], i37[120], i37[119], i37[118], i37[117], i37[116], i37[115], i37[114], i37[113], i37[112], i37[111], i37[110], i37[109], i37[108], i37[107], i37[106], i37[105], i37[104], i37[103], i37[102], i37[101], i37[100], i37[99], i37[98], i37[97], i37[96], i37[95], i37[94], i37[93], i37[92], i37[91], i37[90], i37[89], i37[88], i37[87], i37[86], i37[85], i37[84], i37[83], i37[82], i37[81], i37[80], i37[79], i37[78], i37[77], i37[76], i37[75], i37[74], i37[73], i37[72], i37[71], i37[70], i37[69], i37[68], i37[67], i37[66], i37[65], i37[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i38[191], i38[190], i38[189], i38[188], i38[187], i38[186], i38[185], i38[184], i38[183], i38[182], i38[181], i38[180], i38[179], i38[178], i38[177], i38[176], i38[175], i38[174], i38[173], i38[172], i38[171], i38[170], i38[169], i38[168], i38[167], i38[166], i38[165], i38[164], i38[163], i38[162], i38[161], i38[160], i38[159], i38[158], i38[157], i38[156], i38[155], i38[154], i38[153], i38[152], i38[151], i38[150], i38[149], i38[148], i38[147], i38[146], i38[145], i38[144], i38[143], i38[142], i38[141], i38[140], i38[139], i38[138], i38[137], i38[136], i38[135], i38[134], i38[133], i38[132], i38[131], i38[130], i38[129], i38[128], i38[127], i38[126], i38[125], i38[124], i38[123], i38[122], i38[121], i38[120], i38[119], i38[118], i38[117], i38[116], i38[115], i38[114], i38[113], i38[112], i38[111], i38[110], i38[109], i38[108], i38[107], i38[106], i38[105], i38[104], i38[103], i38[102], i38[101], i38[100], i38[99], i38[98], i38[97], i38[96], i38[95], i38[94], i38[93], i38[92], i38[91], i38[90], i38[89], i38[88], i38[87], i38[86], i38[85], i38[84], i38[83], i38[82], i38[81], i38[80], i38[79], i38[78], i38[77], i38[76], i38[75], i38[74], i38[73], i38[72], i38[71], i38[70], i38[69], i38[68], i38[67], i38[66], i38[65], i38[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] t3 = {i39[255], i39[254], i39[253], i39[252], i39[251], i39[250], i39[249], i39[248], i39[247], i39[246], i39[245], i39[244], i39[243], i39[242], i39[241], i39[240], i39[239], i39[238], i39[237], i39[236], i39[235], i39[234], i39[233], i39[232], i39[231], i39[230], i39[229], i39[228], i39[227], i39[226], i39[225], i39[224], i39[223], i39[222], i39[221], i39[220], i39[219], i39[218], i39[217], i39[216], i39[215], i39[214], i39[213], i39[212], i39[211], i39[210], i39[209], i39[208], i39[207], i39[206], i39[205], i39[204], i39[203], i39[202], i39[201], i39[200], i39[199], i39[198], i39[197], i39[196], i39[195], i39[194], i39[193], i39[192], i39[191], i39[190], i39[189], i39[188], i39[187], i39[186], i39[185], i39[184], i39[183], i39[182], i39[181], i39[180], i39[179], i39[178], i39[177], i39[176], i39[175], i39[174], i39[173], i39[172], i39[171], i39[170], i39[169], i39[168], i39[167], i39[166], i39[165], i39[164], i39[163], i39[162], i39[161], i39[160], i39[159], i39[158], i39[157], i39[156], i39[155], i39[154], i39[153], i39[152], i39[151], i39[150], i39[149], i39[148], i39[147], i39[146], i39[145], i39[144], i39[143], i39[142], i39[141], i39[140], i39[139], i39[138], i39[137], i39[136], i39[135], i39[134], i39[133], i39[132], i39[131], i39[130], i39[129], i39[128], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [255:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_16();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_24();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
