`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [31:0] mul_tree_130_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_130_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_130_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_130_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_160; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_161; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_162; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_130_163; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_164; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_165; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_130_166; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_167; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_168; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_130_169; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_130_170; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_172; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_174; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_175; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_176; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_177; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_179; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_180; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_131_181; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_182; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_131_183; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_131_184; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_185; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_186; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_187; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_131_188; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_189; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_190; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_131_191; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_192; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_193; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_131_194; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_131_195; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_196; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_197; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_198; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_199; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_200; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_201; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_202; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_203; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_204; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_205; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_132_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_207; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_132_208; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_132_209; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_210; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_211; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_212; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_132_213; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_214; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_215; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_132_216; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_217; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_218; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_132_219; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_132_220; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_221; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_222; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_223; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_224; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_225; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_226; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_227; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_228; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_229; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_230; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_133_231; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_232; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_133_233; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_133_234; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_235; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_236; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_237; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_133_238; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_239; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_240; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_133_241; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_242; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_243; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_133_244; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_133_245; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_246; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_247; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_248; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_249; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_250; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_251; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_252; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_253; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_254; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_255; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_134_256; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_257; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_134_258; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_134_259; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_260; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_261; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_262; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_134_263; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_264; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_265; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_134_266; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_267; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_268; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_134_269; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_134_270; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_271; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_272; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_273; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_274; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_275; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_276; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_277; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_278; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_279; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_280; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_135_281; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_282; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_135_283; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_135_284; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_285; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_286; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_287; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_135_288; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_289; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_290; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_135_291; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_292; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_293; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_135_294; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_135_295; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_296; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_297; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_298; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_299; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_300; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_301; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_302; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_303; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_304; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_305; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_136_306; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_307; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_136_308; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_136_309; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_310; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_311; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_312; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_136_313; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_314; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_315; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_136_316; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_317; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_318; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_136_319; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_136_320; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_321; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_322; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_323; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_324; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_325; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_326; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_327; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_328; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_329; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_330; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_137_331; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_332; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_137_333; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_137_334; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_335; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_336; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_337; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_137_338; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_339; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_340; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_137_341; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_342; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_343; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_137_344; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_137_345; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_346; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_347; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_348; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_349; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_350; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_351; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_352; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_353; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_354; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_355; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_138_356; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_357; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_138_358; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_138_359; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_360; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_361; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_362; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_138_363; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_364; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_365; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_138_366; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_367; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_368; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_138_369; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_138_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_373; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_374; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_375; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_376; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_377; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_378; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_379; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_380; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_139_381; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_382; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_139_383; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_139_384; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_385; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_386; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_387; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_139_388; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_389; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_390; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_139_391; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_392; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_393; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_139_394; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_139_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_398; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_399; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_400; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_401; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_402; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_403; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_404; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_405; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_140_406; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_407; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_140_408; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_140_409; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_410; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_411; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_412; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_140_413; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_414; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_415; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_140_416; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_417; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_418; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_140_419; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_140_420; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_421; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_422; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_423; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_424; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_425; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_426; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_427; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_428; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_429; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_430; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_141_431; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_432; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_141_433; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_141_434; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_435; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_436; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_437; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_141_438; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_439; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_440; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_141_441; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_442; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_443; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_141_444; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_141_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_446; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_447; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_448; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_449; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_450; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_451; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_452; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_453; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_454; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_455; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_142_456; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_457; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_142_458; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_142_459; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_460; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_461; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_462; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_142_463; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_464; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_465; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_142_466; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_467; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_468; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_142_469; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_142_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_471; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_472; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_476; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_477; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_478; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_479; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_480; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_143_481; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_482; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_143_483; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_143_484; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_485; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_486; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_487; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_143_488; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_489; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_490; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_143_491; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_492; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_493; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_143_494; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_143_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_496; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_497; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_501; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_502; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_503; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_504; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_505; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_144_506; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_507; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_144_508; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_144_509; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_510; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_511; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_512; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_144_513; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_514; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_515; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_144_516; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_517; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_518; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_144_519; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_144_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_521; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_522; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_523; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_524; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_525; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_526; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_527; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_528; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_529; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_530; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_145_531; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_532; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_145_533; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_145_534; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_535; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_536; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_537; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_145_538; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_539; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_540; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_145_541; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_542; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_543; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_145_544; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_145_545; // decl: <none>; prim: <none>
    logic [128:0] limb_49_546; // decl: <none>; prim: <none>
    logic [128:0] limb_49_547; // decl: <none>; prim: <none>
    logic [63:0] limb_49_548; // decl: <none>; prim: <none>
    logic [63:0] limb_49_549; // decl: <none>; prim: <none>
    logic [64:0] limb_49_550; // decl: <none>; prim: <none>
    logic [63:0] limb_49_551; // decl: <none>; prim: <none>
    logic limb_49_552; // decl: <none>; prim: <none>
    logic [63:0] limb_49_553; // decl: <none>; prim: <none>
    logic [63:0] limb_49_554; // decl: <none>; prim: <none>
    logic [64:0] limb_49_555; // decl: <none>; prim: <none>
    logic [63:0] limb_49_556; // decl: <none>; prim: <none>
    logic limb_49_557; // decl: <none>; prim: <none>
    logic limb_49_558; // decl: <none>; prim: <none>
    logic limb_49_559; // decl: <none>; prim: <none>
    logic [1:0] limb_49_560; // decl: <none>; prim: <none>
    logic limb_49_561; // decl: <none>; prim: <none>
    logic [128:0] limb_49_562; // decl: <none>; prim: <none>
    logic [128:0] limb_50_563; // decl: <none>; prim: <none>
    logic [128:0] limb_50_564; // decl: <none>; prim: <none>
    logic [63:0] limb_50_565; // decl: <none>; prim: <none>
    logic [63:0] limb_50_566; // decl: <none>; prim: <none>
    logic [64:0] limb_50_567; // decl: <none>; prim: <none>
    logic [63:0] limb_50_568; // decl: <none>; prim: <none>
    logic limb_50_569; // decl: <none>; prim: <none>
    logic [63:0] limb_50_570; // decl: <none>; prim: <none>
    logic [63:0] limb_50_571; // decl: <none>; prim: <none>
    logic [64:0] limb_50_572; // decl: <none>; prim: <none>
    logic [63:0] limb_50_573; // decl: <none>; prim: <none>
    logic limb_50_574; // decl: <none>; prim: <none>
    logic limb_50_575; // decl: <none>; prim: <none>
    logic limb_50_576; // decl: <none>; prim: <none>
    logic [1:0] limb_50_577; // decl: <none>; prim: <none>
    logic limb_50_578; // decl: <none>; prim: <none>
    logic [128:0] limb_50_579; // decl: <none>; prim: <none>
    logic [128:0] limb_51_580; // decl: <none>; prim: <none>
    logic [128:0] limb_51_581; // decl: <none>; prim: <none>
    logic [63:0] limb_51_582; // decl: <none>; prim: <none>
    logic [63:0] limb_51_583; // decl: <none>; prim: <none>
    logic [64:0] limb_51_584; // decl: <none>; prim: <none>
    logic [63:0] limb_51_585; // decl: <none>; prim: <none>
    logic limb_51_586; // decl: <none>; prim: <none>
    logic [63:0] limb_51_587; // decl: <none>; prim: <none>
    logic [63:0] limb_51_588; // decl: <none>; prim: <none>
    logic [64:0] limb_51_589; // decl: <none>; prim: <none>
    logic [63:0] limb_51_590; // decl: <none>; prim: <none>
    logic limb_51_591; // decl: <none>; prim: <none>
    logic limb_51_592; // decl: <none>; prim: <none>
    logic limb_51_593; // decl: <none>; prim: <none>
    logic [1:0] limb_51_594; // decl: <none>; prim: <none>
    logic limb_51_595; // decl: <none>; prim: <none>
    logic [128:0] limb_51_596; // decl: <none>; prim: <none>
    logic [128:0] limb_52_597; // decl: <none>; prim: <none>
    logic [128:0] limb_52_598; // decl: <none>; prim: <none>
    logic [63:0] limb_52_599; // decl: <none>; prim: <none>
    logic [63:0] limb_52_600; // decl: <none>; prim: <none>
    logic [64:0] limb_52_601; // decl: <none>; prim: <none>
    logic [63:0] limb_52_602; // decl: <none>; prim: <none>
    logic limb_52_603; // decl: <none>; prim: <none>
    logic [63:0] limb_52_604; // decl: <none>; prim: <none>
    logic [63:0] limb_52_605; // decl: <none>; prim: <none>
    logic [64:0] limb_52_606; // decl: <none>; prim: <none>
    logic [63:0] limb_52_607; // decl: <none>; prim: <none>
    logic limb_52_608; // decl: <none>; prim: <none>
    logic limb_52_609; // decl: <none>; prim: <none>
    logic limb_52_610; // decl: <none>; prim: <none>
    logic [1:0] limb_52_611; // decl: <none>; prim: <none>
    logic limb_52_612; // decl: <none>; prim: <none>
    logic [128:0] limb_52_613; // decl: <none>; prim: <none>
    logic [128:0] limb_53_614; // decl: <none>; prim: <none>
    logic [128:0] limb_53_615; // decl: <none>; prim: <none>
    logic [63:0] limb_53_616; // decl: <none>; prim: <none>
    logic [63:0] limb_53_617; // decl: <none>; prim: <none>
    logic [64:0] limb_53_618; // decl: <none>; prim: <none>
    logic [63:0] limb_53_619; // decl: <none>; prim: <none>
    logic limb_53_620; // decl: <none>; prim: <none>
    logic [63:0] limb_53_621; // decl: <none>; prim: <none>
    logic [63:0] limb_53_622; // decl: <none>; prim: <none>
    logic [64:0] limb_53_623; // decl: <none>; prim: <none>
    logic [63:0] limb_53_624; // decl: <none>; prim: <none>
    logic limb_53_625; // decl: <none>; prim: <none>
    logic limb_53_626; // decl: <none>; prim: <none>
    logic limb_53_627; // decl: <none>; prim: <none>
    logic [1:0] limb_53_628; // decl: <none>; prim: <none>
    logic limb_53_629; // decl: <none>; prim: <none>
    logic [128:0] limb_53_630; // decl: <none>; prim: <none>
    logic [128:0] limb_54_631; // decl: <none>; prim: <none>
    logic [128:0] limb_54_632; // decl: <none>; prim: <none>
    logic [63:0] limb_54_633; // decl: <none>; prim: <none>
    logic [63:0] limb_54_634; // decl: <none>; prim: <none>
    logic [64:0] limb_54_635; // decl: <none>; prim: <none>
    logic [63:0] limb_54_636; // decl: <none>; prim: <none>
    logic limb_54_637; // decl: <none>; prim: <none>
    logic [63:0] limb_54_638; // decl: <none>; prim: <none>
    logic [63:0] limb_54_639; // decl: <none>; prim: <none>
    logic [64:0] limb_54_640; // decl: <none>; prim: <none>
    logic [63:0] limb_54_641; // decl: <none>; prim: <none>
    logic limb_54_642; // decl: <none>; prim: <none>
    logic limb_54_643; // decl: <none>; prim: <none>
    logic limb_54_644; // decl: <none>; prim: <none>
    logic [1:0] limb_54_645; // decl: <none>; prim: <none>
    logic limb_54_646; // decl: <none>; prim: <none>
    logic [128:0] limb_54_647; // decl: <none>; prim: <none>
    logic [128:0] limb_55_648; // decl: <none>; prim: <none>
    logic [128:0] limb_55_649; // decl: <none>; prim: <none>
    logic [63:0] limb_55_650; // decl: <none>; prim: <none>
    logic [63:0] limb_55_651; // decl: <none>; prim: <none>
    logic [64:0] limb_55_652; // decl: <none>; prim: <none>
    logic [63:0] limb_55_653; // decl: <none>; prim: <none>
    logic limb_55_654; // decl: <none>; prim: <none>
    logic [63:0] limb_55_655; // decl: <none>; prim: <none>
    logic [63:0] limb_55_656; // decl: <none>; prim: <none>
    logic [64:0] limb_55_657; // decl: <none>; prim: <none>
    logic [63:0] limb_55_658; // decl: <none>; prim: <none>
    logic limb_55_659; // decl: <none>; prim: <none>
    logic limb_55_660; // decl: <none>; prim: <none>
    logic limb_55_661; // decl: <none>; prim: <none>
    logic [1:0] limb_55_662; // decl: <none>; prim: <none>
    logic limb_55_663; // decl: <none>; prim: <none>
    logic [128:0] limb_55_664; // decl: <none>; prim: <none>
    logic [128:0] limb_56_665; // decl: <none>; prim: <none>
    logic [128:0] limb_56_666; // decl: <none>; prim: <none>
    logic [63:0] limb_56_667; // decl: <none>; prim: <none>
    logic [63:0] limb_56_668; // decl: <none>; prim: <none>
    logic [64:0] limb_56_669; // decl: <none>; prim: <none>
    logic [63:0] limb_56_670; // decl: <none>; prim: <none>
    logic limb_56_671; // decl: <none>; prim: <none>
    logic [63:0] limb_56_672; // decl: <none>; prim: <none>
    logic [63:0] limb_56_673; // decl: <none>; prim: <none>
    logic [64:0] limb_56_674; // decl: <none>; prim: <none>
    logic [63:0] limb_56_675; // decl: <none>; prim: <none>
    logic limb_56_676; // decl: <none>; prim: <none>
    logic limb_56_677; // decl: <none>; prim: <none>
    logic limb_56_678; // decl: <none>; prim: <none>
    logic [1:0] limb_56_679; // decl: <none>; prim: <none>
    logic limb_56_680; // decl: <none>; prim: <none>
    logic [128:0] limb_56_681; // decl: <none>; prim: <none>
    logic [129:0] limb_57_682; // decl: <none>; prim: <none>
    logic [129:0] limb_57_683; // decl: <none>; prim: <none>
    logic [63:0] limb_57_684; // decl: <none>; prim: <none>
    logic [63:0] limb_57_685; // decl: <none>; prim: <none>
    logic [64:0] limb_57_686; // decl: <none>; prim: <none>
    logic [63:0] limb_57_687; // decl: <none>; prim: <none>
    logic limb_57_688; // decl: <none>; prim: <none>
    logic [63:0] limb_57_689; // decl: <none>; prim: <none>
    logic [63:0] limb_57_690; // decl: <none>; prim: <none>
    logic [64:0] limb_57_691; // decl: <none>; prim: <none>
    logic [63:0] limb_57_692; // decl: <none>; prim: <none>
    logic limb_57_693; // decl: <none>; prim: <none>
    logic [1:0] limb_57_694; // decl: <none>; prim: <none>
    logic [1:0] limb_57_695; // decl: <none>; prim: <none>
    logic [2:0] limb_57_696; // decl: <none>; prim: <none>
    logic [1:0] limb_57_697; // decl: <none>; prim: <none>
    logic [129:0] limb_57_698; // decl: <none>; prim: <none>
    logic [129:0] limb_58_699; // decl: <none>; prim: <none>
    logic [129:0] limb_58_700; // decl: <none>; prim: <none>
    logic [63:0] limb_58_701; // decl: <none>; prim: <none>
    logic [63:0] limb_58_702; // decl: <none>; prim: <none>
    logic [64:0] limb_58_703; // decl: <none>; prim: <none>
    logic [63:0] limb_58_704; // decl: <none>; prim: <none>
    logic limb_58_705; // decl: <none>; prim: <none>
    logic [63:0] limb_58_706; // decl: <none>; prim: <none>
    logic [63:0] limb_58_707; // decl: <none>; prim: <none>
    logic [64:0] limb_58_708; // decl: <none>; prim: <none>
    logic [63:0] limb_58_709; // decl: <none>; prim: <none>
    logic limb_58_710; // decl: <none>; prim: <none>
    logic [1:0] limb_58_711; // decl: <none>; prim: <none>
    logic [1:0] limb_58_712; // decl: <none>; prim: <none>
    logic [2:0] limb_58_713; // decl: <none>; prim: <none>
    logic [1:0] limb_58_714; // decl: <none>; prim: <none>
    logic [129:0] limb_58_715; // decl: <none>; prim: <none>
    logic [129:0] limb_59_716; // decl: <none>; prim: <none>
    logic [129:0] limb_59_717; // decl: <none>; prim: <none>
    logic [63:0] limb_59_718; // decl: <none>; prim: <none>
    logic [63:0] limb_59_719; // decl: <none>; prim: <none>
    logic [64:0] limb_59_720; // decl: <none>; prim: <none>
    logic [63:0] limb_59_721; // decl: <none>; prim: <none>
    logic limb_59_722; // decl: <none>; prim: <none>
    logic [63:0] limb_59_723; // decl: <none>; prim: <none>
    logic [63:0] limb_59_724; // decl: <none>; prim: <none>
    logic [64:0] limb_59_725; // decl: <none>; prim: <none>
    logic [63:0] limb_59_726; // decl: <none>; prim: <none>
    logic limb_59_727; // decl: <none>; prim: <none>
    logic [1:0] limb_59_728; // decl: <none>; prim: <none>
    logic [1:0] limb_59_729; // decl: <none>; prim: <none>
    logic [2:0] limb_59_730; // decl: <none>; prim: <none>
    logic [1:0] limb_59_731; // decl: <none>; prim: <none>
    logic [129:0] limb_59_732; // decl: <none>; prim: <none>
    logic [129:0] limb_60_733; // decl: <none>; prim: <none>
    logic [129:0] limb_60_734; // decl: <none>; prim: <none>
    logic [63:0] limb_60_735; // decl: <none>; prim: <none>
    logic [63:0] limb_60_736; // decl: <none>; prim: <none>
    logic [64:0] limb_60_737; // decl: <none>; prim: <none>
    logic [63:0] limb_60_738; // decl: <none>; prim: <none>
    logic limb_60_739; // decl: <none>; prim: <none>
    logic [63:0] limb_60_740; // decl: <none>; prim: <none>
    logic [63:0] limb_60_741; // decl: <none>; prim: <none>
    logic [64:0] limb_60_742; // decl: <none>; prim: <none>
    logic [63:0] limb_60_743; // decl: <none>; prim: <none>
    logic limb_60_744; // decl: <none>; prim: <none>
    logic [1:0] limb_60_745; // decl: <none>; prim: <none>
    logic [1:0] limb_60_746; // decl: <none>; prim: <none>
    logic [2:0] limb_60_747; // decl: <none>; prim: <none>
    logic [1:0] limb_60_748; // decl: <none>; prim: <none>
    logic [129:0] limb_60_749; // decl: <none>; prim: <none>
    logic [130:0] limb_61_750; // decl: <none>; prim: <none>
    logic [130:0] limb_61_751; // decl: <none>; prim: <none>
    logic [63:0] limb_61_752; // decl: <none>; prim: <none>
    logic [63:0] limb_61_753; // decl: <none>; prim: <none>
    logic [64:0] limb_61_754; // decl: <none>; prim: <none>
    logic [63:0] limb_61_755; // decl: <none>; prim: <none>
    logic limb_61_756; // decl: <none>; prim: <none>
    logic [63:0] limb_61_757; // decl: <none>; prim: <none>
    logic [63:0] limb_61_758; // decl: <none>; prim: <none>
    logic [64:0] limb_61_759; // decl: <none>; prim: <none>
    logic [63:0] limb_61_760; // decl: <none>; prim: <none>
    logic limb_61_761; // decl: <none>; prim: <none>
    logic [2:0] limb_61_762; // decl: <none>; prim: <none>
    logic [2:0] limb_61_763; // decl: <none>; prim: <none>
    logic [3:0] limb_61_764; // decl: <none>; prim: <none>
    logic [2:0] limb_61_765; // decl: <none>; prim: <none>
    logic [130:0] limb_61_766; // decl: <none>; prim: <none>
    logic [130:0] limb_62_767; // decl: <none>; prim: <none>
    logic [130:0] limb_62_768; // decl: <none>; prim: <none>
    logic [63:0] limb_62_769; // decl: <none>; prim: <none>
    logic [63:0] limb_62_770; // decl: <none>; prim: <none>
    logic [64:0] limb_62_771; // decl: <none>; prim: <none>
    logic [63:0] limb_62_772; // decl: <none>; prim: <none>
    logic limb_62_773; // decl: <none>; prim: <none>
    logic [63:0] limb_62_774; // decl: <none>; prim: <none>
    logic [63:0] limb_62_775; // decl: <none>; prim: <none>
    logic [64:0] limb_62_776; // decl: <none>; prim: <none>
    logic [63:0] limb_62_777; // decl: <none>; prim: <none>
    logic limb_62_778; // decl: <none>; prim: <none>
    logic [2:0] limb_62_779; // decl: <none>; prim: <none>
    logic [2:0] limb_62_780; // decl: <none>; prim: <none>
    logic [3:0] limb_62_781; // decl: <none>; prim: <none>
    logic [2:0] limb_62_782; // decl: <none>; prim: <none>
    logic [130:0] limb_62_783; // decl: <none>; prim: <none>
    logic [131:0] limb_63_784; // decl: <none>; prim: <none>
    logic [131:0] limb_63_785; // decl: <none>; prim: <none>
    logic [63:0] limb_63_786; // decl: <none>; prim: <none>
    logic [63:0] limb_63_787; // decl: <none>; prim: <none>
    logic [64:0] limb_63_788; // decl: <none>; prim: <none>
    logic [63:0] limb_63_789; // decl: <none>; prim: <none>
    logic limb_63_790; // decl: <none>; prim: <none>
    logic [63:0] limb_63_791; // decl: <none>; prim: <none>
    logic [63:0] limb_63_792; // decl: <none>; prim: <none>
    logic [64:0] limb_63_793; // decl: <none>; prim: <none>
    logic [63:0] limb_63_794; // decl: <none>; prim: <none>
    logic limb_63_795; // decl: <none>; prim: <none>
    logic [3:0] limb_63_796; // decl: <none>; prim: <none>
    logic [3:0] limb_63_797; // decl: <none>; prim: <none>
    logic [4:0] limb_63_798; // decl: <none>; prim: <none>
    logic [3:0] limb_63_799; // decl: <none>; prim: <none>
    logic [131:0] limb_63_800; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_114_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_115_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_156_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_160_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_166_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_173_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_177_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_181_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_185_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_188_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_213_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_216_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_223_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_227_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_231_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_235_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_238_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_241_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_248_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_252_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_256_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_260_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_273_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_273_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_277_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_277_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_281_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_281_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_298_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_302_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_306_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_310_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_313_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_316_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_327_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_327_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_331_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_335_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_363_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_366_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_373_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_377_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_381_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_385_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_388_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_391_s2; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_413_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_416_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_423_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_427_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_431_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_435_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_438_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_448_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_452_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_456_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_460_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_473_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_477_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_481_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_485_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_498_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_502_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_506_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_510_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_513_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_516_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_523_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_527_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_531_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_535_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_548_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_548_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_548_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_548_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_549_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_553_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_553_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_553_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_553_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_554_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_558_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_558_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_558_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_558_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_559_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_566_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_566_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_566_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_566_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_566_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_571_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_576_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_582_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_582_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_582_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_587_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_587_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_587_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_592_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_599_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_599_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_599_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_604_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_604_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_604_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_609_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_609_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_609_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_617_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_617_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_617_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_622_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_622_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_622_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_622_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_622_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_627_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_634_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_634_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_636_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_639_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_639_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_641_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_642_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_643_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_644_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_644_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_644_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_650_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_650_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_655_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_655_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_660_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_660_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_667_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_667_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_667_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_667_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_668_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_668_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_672_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_672_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_672_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_672_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_673_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_673_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_677_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_678_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_678_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_684_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_689_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_694_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_702_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_702_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_707_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_707_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_712_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_712_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_719_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_719_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_724_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_724_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_729_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_729_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_736_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_741_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_746_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    assign s8_norm_add_64_v0 = limb_49_562; // decl: <none>; prim: <none>
    assign s8_norm_add_65_v0 = limb_50_579; // decl: <none>; prim: <none>
    assign s8_norm_add_66_v0 = limb_51_596; // decl: <none>; prim: <none>
    assign s8_norm_add_67_v0 = limb_52_613; // decl: <none>; prim: <none>
    assign s8_norm_add_68_v0 = limb_53_630; // decl: <none>; prim: <none>
    assign s8_norm_add_69_v0 = limb_54_647; // decl: <none>; prim: <none>
    assign s8_norm_add_70_v0 = limb_55_664; // decl: <none>; prim: <none>
    assign s8_norm_add_71_v0 = limb_56_681; // decl: <none>; prim: <none>
    assign s8_norm_add_72_v0 = limb_57_698; // decl: <none>; prim: <none>
    assign s8_norm_add_73_v0 = limb_58_715; // decl: <none>; prim: <none>
    assign s8_norm_add_74_v0 = limb_59_732; // decl: <none>; prim: <none>
    assign s8_norm_add_75_v0 = limb_60_749; // decl: <none>; prim: <none>
    assign s8_norm_add_76_v0 = limb_61_766; // decl: <none>; prim: <none>
    assign s8_norm_add_77_v0 = limb_62_783; // decl: <none>; prim: <none>
    assign s8_norm_add_78_v0 = limb_63_800; // decl: <none>; prim: <none>
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    assign arith_original_130 = mul_tree_130_170; // decl: <none>; prim: <none>
    assign arith_original_131 = mul_tree_131_195; // decl: <none>; prim: <none>
    assign arith_original_132 = mul_tree_132_220; // decl: <none>; prim: <none>
    assign arith_original_133 = mul_tree_133_245; // decl: <none>; prim: <none>
    assign arith_original_134 = mul_tree_134_270; // decl: <none>; prim: <none>
    assign arith_original_135 = mul_tree_135_295; // decl: <none>; prim: <none>
    assign arith_original_136 = mul_tree_136_320; // decl: <none>; prim: <none>
    assign arith_original_137 = mul_tree_137_345; // decl: <none>; prim: <none>
    assign arith_original_138 = mul_tree_138_370; // decl: <none>; prim: <none>
    assign arith_original_139 = mul_tree_139_395; // decl: <none>; prim: <none>
    assign arith_original_140 = mul_tree_140_420; // decl: <none>; prim: <none>
    assign arith_original_141 = mul_tree_141_445; // decl: <none>; prim: <none>
    assign arith_original_142 = mul_tree_142_470; // decl: <none>; prim: <none>
    assign arith_original_143 = mul_tree_143_495; // decl: <none>; prim: <none>
    assign arith_original_144 = mul_tree_144_520; // decl: <none>; prim: <none>
    assign arith_original_145 = mul_tree_145_545; // decl: <none>; prim: <none>
    assign mul_tree_130_146 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_147 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_148Core rtlzz_owner_148(.a(32'(mul_tree_130_146)), .b(32'(mul_tree_130_147)), .cin(1'b0), .value(mul_tree_130_148));
    assign mul_tree_130_149 = mul_precision_98[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_130_150 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_151Core rtlzz_owner_151(.a(32'(mul_tree_130_149)), .b(32'(mul_tree_130_150)), .cin(1'b0), .value(mul_tree_130_151));
    assign mul_tree_130_152 = {mul_tree_130_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_153 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_154 = mul_precision_99[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(32'(mul_tree_130_153)), .b(32'(mul_tree_130_154)), .cin(1'b0), .value(mul_tree_130_155));
    assign mul_tree_130_156 = {mul_tree_130_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_157 = mul_precision_98[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_130_158 = mul_precision_99[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_159Core rtlzz_owner_159(.a(32'(mul_tree_130_157)), .b(32'(mul_tree_130_158)), .cin(1'b0), .value(mul_tree_130_159));
    assign mul_tree_130_160 = {mul_tree_130_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_130_161 = ({33'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_162 = ({1'h0, rtlzz_pipe_152_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_163Core rtlzz_owner_163(.a(64'(mul_tree_130_161)), .b(96'(mul_tree_130_162)), .cin(1'h0), .value(mul_tree_130_163));
    assign mul_tree_130_164 = ({33'h0, rtlzz_pipe_156_s1}); // decl: <none>; prim: <none>
    assign mul_tree_130_165 = ({1'h0, rtlzz_pipe_160_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(96'(mul_tree_130_164)), .b(128'(mul_tree_130_165)), .cin(1'h0), .value(mul_tree_130_166[127:0]));
    assign mul_tree_130_166[128:128] = '0;
    assign mul_tree_130_167 = ({33'h0, rtlzz_pipe_163_s2}); // decl: <none>; prim: <none>
    assign mul_tree_130_168 = ({1'h0, rtlzz_pipe_166_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_169Core rtlzz_owner_169(.a(97'(mul_tree_130_167)), .b(129'(mul_tree_130_168)), .cin(1'h0), .value(mul_tree_130_169[127:0]));
    assign mul_tree_130_169[129:128] = '0;
    assign mul_tree_130_170 = mul_tree_130_169[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_171 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_172 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_173Core rtlzz_owner_173(.a(32'(mul_tree_131_171)), .b(32'(mul_tree_131_172)), .cin(1'b0), .value(mul_tree_131_173));
    assign mul_tree_131_174 = rtlzz_pipe_100_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_131_175 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_176Core rtlzz_owner_176(.a(32'(mul_tree_131_174)), .b(32'(mul_tree_131_175)), .cin(1'b0), .value(mul_tree_131_176));
    assign mul_tree_131_177 = {mul_tree_131_176, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_178 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_179 = rtlzz_pipe_101_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_180Core rtlzz_owner_180(.a(32'(mul_tree_131_178)), .b(32'(mul_tree_131_179)), .cin(1'b0), .value(mul_tree_131_180));
    assign mul_tree_131_181 = {mul_tree_131_180, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_182 = rtlzz_pipe_100_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_131_183 = rtlzz_pipe_101_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(32'(mul_tree_131_182)), .b(32'(mul_tree_131_183)), .cin(1'b0), .value(mul_tree_131_184));
    assign mul_tree_131_185 = {mul_tree_131_184, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_131_186 = ({33'h0, rtlzz_pipe_173_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_187 = ({1'h0, rtlzz_pipe_177_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_188Core rtlzz_owner_188(.a(64'(mul_tree_131_186)), .b(96'(mul_tree_131_187)), .cin(1'h0), .value(mul_tree_131_188));
    assign mul_tree_131_189 = ({33'h0, rtlzz_pipe_181_s4}); // decl: <none>; prim: <none>
    assign mul_tree_131_190 = ({1'h0, rtlzz_pipe_185_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_191Core rtlzz_owner_191(.a(96'(mul_tree_131_189)), .b(128'(mul_tree_131_190)), .cin(1'h0), .value(mul_tree_131_191[127:0]));
    assign mul_tree_131_191[128:128] = '0;
    assign mul_tree_131_192 = ({33'h0, rtlzz_pipe_188_s5}); // decl: <none>; prim: <none>
    assign mul_tree_131_193 = ({1'h0, rtlzz_pipe_191_s5}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(97'(mul_tree_131_192)), .b(129'(mul_tree_131_193)), .cin(1'h0), .value(mul_tree_131_194[127:0]));
    assign mul_tree_131_194[129:128] = '0;
    assign mul_tree_131_195 = mul_tree_131_194[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_196 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_197 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(32'(mul_tree_132_196)), .b(32'(mul_tree_132_197)), .cin(1'b0), .value(mul_tree_132_198));
    assign mul_tree_132_199 = rtlzz_pipe_102_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_132_200 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(32'(mul_tree_132_199)), .b(32'(mul_tree_132_200)), .cin(1'b0), .value(mul_tree_132_201));
    assign mul_tree_132_202 = {mul_tree_132_201, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_203 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_204 = rtlzz_pipe_103_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_205Core rtlzz_owner_205(.a(32'(mul_tree_132_203)), .b(32'(mul_tree_132_204)), .cin(1'b0), .value(mul_tree_132_205));
    assign mul_tree_132_206 = {mul_tree_132_205, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_207 = rtlzz_pipe_102_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_132_208 = rtlzz_pipe_103_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_209Core rtlzz_owner_209(.a(32'(mul_tree_132_207)), .b(32'(mul_tree_132_208)), .cin(1'b0), .value(mul_tree_132_209));
    assign mul_tree_132_210 = {mul_tree_132_209, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_132_211 = ({33'h0, mul_tree_132_198}); // decl: <none>; prim: <none>
    assign mul_tree_132_212 = ({1'h0, mul_tree_132_202}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_213Core rtlzz_owner_213(.a(64'(mul_tree_132_211)), .b(96'(mul_tree_132_212)), .cin(1'h0), .value(mul_tree_132_213));
    assign mul_tree_132_214 = ({33'h0, mul_tree_132_206}); // decl: <none>; prim: <none>
    assign mul_tree_132_215 = ({1'h0, mul_tree_132_210}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_216Core rtlzz_owner_216(.a(96'(mul_tree_132_214)), .b(128'(mul_tree_132_215)), .cin(1'h0), .value(mul_tree_132_216[127:0]));
    assign mul_tree_132_216[128:128] = '0;
    assign mul_tree_132_217 = ({33'h0, rtlzz_pipe_213_s7}); // decl: <none>; prim: <none>
    assign mul_tree_132_218 = ({1'h0, rtlzz_pipe_216_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_219Core rtlzz_owner_219(.a(97'(mul_tree_132_217)), .b(129'(mul_tree_132_218)), .cin(1'h0), .value(mul_tree_132_219[127:0]));
    assign mul_tree_132_219[129:128] = '0;
    assign mul_tree_132_220 = mul_tree_132_219[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_221 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_222 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223Core rtlzz_owner_223(.a(32'(mul_tree_133_221)), .b(32'(mul_tree_133_222)), .cin(1'b0), .value(mul_tree_133_223));
    assign mul_tree_133_224 = mul_precision_104[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_133_225 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(32'(mul_tree_133_224)), .b(32'(mul_tree_133_225)), .cin(1'b0), .value(mul_tree_133_226));
    assign mul_tree_133_227 = {mul_tree_133_226, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_228 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_229 = mul_precision_105[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(32'(mul_tree_133_228)), .b(32'(mul_tree_133_229)), .cin(1'b0), .value(mul_tree_133_230));
    assign mul_tree_133_231 = {mul_tree_133_230, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_232 = mul_precision_104[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_133_233 = mul_precision_105[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(32'(mul_tree_133_232)), .b(32'(mul_tree_133_233)), .cin(1'b0), .value(mul_tree_133_234));
    assign mul_tree_133_235 = {mul_tree_133_234, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_133_236 = ({33'h0, rtlzz_pipe_223_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_237 = ({1'h0, rtlzz_pipe_227_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(64'(mul_tree_133_236)), .b(96'(mul_tree_133_237)), .cin(1'h0), .value(mul_tree_133_238));
    assign mul_tree_133_239 = ({33'h0, rtlzz_pipe_231_s1}); // decl: <none>; prim: <none>
    assign mul_tree_133_240 = ({1'h0, rtlzz_pipe_235_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_241Core rtlzz_owner_241(.a(96'(mul_tree_133_239)), .b(128'(mul_tree_133_240)), .cin(1'h0), .value(mul_tree_133_241[127:0]));
    assign mul_tree_133_241[128:128] = '0;
    assign mul_tree_133_242 = ({33'h0, rtlzz_pipe_238_s2}); // decl: <none>; prim: <none>
    assign mul_tree_133_243 = ({1'h0, rtlzz_pipe_241_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_244Core rtlzz_owner_244(.a(97'(mul_tree_133_242)), .b(129'(mul_tree_133_243)), .cin(1'h0), .value(mul_tree_133_244[127:0]));
    assign mul_tree_133_244[129:128] = '0;
    assign mul_tree_133_245 = mul_tree_133_244[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_246 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_247 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_248Core rtlzz_owner_248(.a(32'(mul_tree_134_246)), .b(32'(mul_tree_134_247)), .cin(1'b0), .value(mul_tree_134_248));
    assign mul_tree_134_249 = rtlzz_pipe_106_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_134_250 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_251Core rtlzz_owner_251(.a(32'(mul_tree_134_249)), .b(32'(mul_tree_134_250)), .cin(1'b0), .value(mul_tree_134_251));
    assign mul_tree_134_252 = {mul_tree_134_251, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_253 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_254 = rtlzz_pipe_107_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_255Core rtlzz_owner_255(.a(32'(mul_tree_134_253)), .b(32'(mul_tree_134_254)), .cin(1'b0), .value(mul_tree_134_255));
    assign mul_tree_134_256 = {mul_tree_134_255, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_257 = rtlzz_pipe_106_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_134_258 = rtlzz_pipe_107_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_259Core rtlzz_owner_259(.a(32'(mul_tree_134_257)), .b(32'(mul_tree_134_258)), .cin(1'b0), .value(mul_tree_134_259));
    assign mul_tree_134_260 = {mul_tree_134_259, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_134_261 = ({33'h0, rtlzz_pipe_248_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_262 = ({1'h0, rtlzz_pipe_252_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_264 = ({33'h0, rtlzz_pipe_256_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_265 = ({1'h0, rtlzz_pipe_260_s4}); // decl: <none>; prim: <none>
    assign mul_tree_134_267 = ({33'h0, mul_tree_134_263}); // decl: <none>; prim: <none>
    assign mul_tree_134_268 = ({1'h0, mul_tree_134_266}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_269_reduce rtlzz_reduce_269(.i905(rtlzz_pipe_248_s4), .i906(rtlzz_pipe_252_s4), .i907(rtlzz_pipe_256_s4), .i908(rtlzz_pipe_260_s4), .y(mul_tree_134_269));
    assign mul_tree_134_270 = mul_tree_134_269[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_271 = rtlzz_pipe_108_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_272 = rtlzz_pipe_109_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_273Core rtlzz_owner_273(.a(32'(mul_tree_135_271)), .b(32'(mul_tree_135_272)), .cin(1'b0), .value(mul_tree_135_273));
    assign mul_tree_135_274 = rtlzz_pipe_108_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_135_275 = rtlzz_pipe_109_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(32'(mul_tree_135_274)), .b(32'(mul_tree_135_275)), .cin(1'b0), .value(mul_tree_135_276));
    assign mul_tree_135_277 = {mul_tree_135_276, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_278 = rtlzz_pipe_108_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_279 = rtlzz_pipe_109_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_280Core rtlzz_owner_280(.a(32'(mul_tree_135_278)), .b(32'(mul_tree_135_279)), .cin(1'b0), .value(mul_tree_135_280));
    assign mul_tree_135_281 = {mul_tree_135_280, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_282 = rtlzz_pipe_108_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_135_283 = rtlzz_pipe_109_s5[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_284Core rtlzz_owner_284(.a(32'(mul_tree_135_282)), .b(32'(mul_tree_135_283)), .cin(1'b0), .value(mul_tree_135_284));
    assign mul_tree_135_285 = {mul_tree_135_284, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_135_286 = ({33'h0, rtlzz_pipe_273_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_287 = ({1'h0, rtlzz_pipe_277_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_289 = ({33'h0, rtlzz_pipe_281_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_290 = ({1'h0, rtlzz_pipe_285_s7}); // decl: <none>; prim: <none>
    assign mul_tree_135_292 = ({33'h0, mul_tree_135_288}); // decl: <none>; prim: <none>
    assign mul_tree_135_293 = ({1'h0, mul_tree_135_291}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294_reduce rtlzz_reduce_294(.i910(rtlzz_pipe_273_s7), .i912(rtlzz_pipe_277_s7), .i914(rtlzz_pipe_281_s7), .i916(rtlzz_pipe_285_s7), .y(mul_tree_135_294));
    assign mul_tree_135_295 = mul_tree_135_294[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_296 = mul_precision_110[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_297 = mul_precision_111[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_298Core rtlzz_owner_298(.a(32'(mul_tree_136_296)), .b(32'(mul_tree_136_297)), .cin(1'b0), .value(mul_tree_136_298));
    assign mul_tree_136_299 = mul_precision_110[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_136_300 = mul_precision_111[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_301Core rtlzz_owner_301(.a(32'(mul_tree_136_299)), .b(32'(mul_tree_136_300)), .cin(1'b0), .value(mul_tree_136_301));
    assign mul_tree_136_302 = {mul_tree_136_301, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_303 = mul_precision_110[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_304 = mul_precision_111[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_305Core rtlzz_owner_305(.a(32'(mul_tree_136_303)), .b(32'(mul_tree_136_304)), .cin(1'b0), .value(mul_tree_136_305));
    assign mul_tree_136_306 = {mul_tree_136_305, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_307 = mul_precision_110[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_136_308 = mul_precision_111[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(32'(mul_tree_136_307)), .b(32'(mul_tree_136_308)), .cin(1'b0), .value(mul_tree_136_309));
    assign mul_tree_136_310 = {mul_tree_136_309, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_136_311 = ({33'h0, rtlzz_pipe_298_s1}); // decl: <none>; prim: <none>
    assign mul_tree_136_312 = ({1'h0, rtlzz_pipe_302_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(64'(mul_tree_136_311)), .b(96'(mul_tree_136_312)), .cin(1'h0), .value(mul_tree_136_313));
    assign mul_tree_136_314 = ({33'h0, rtlzz_pipe_306_s1}); // decl: <none>; prim: <none>
    assign mul_tree_136_315 = ({1'h0, rtlzz_pipe_310_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_316Core rtlzz_owner_316(.a(96'(mul_tree_136_314)), .b(128'(mul_tree_136_315)), .cin(1'h0), .value(mul_tree_136_316[127:0]));
    assign mul_tree_136_316[128:128] = '0;
    assign mul_tree_136_317 = ({33'h0, rtlzz_pipe_313_s2}); // decl: <none>; prim: <none>
    assign mul_tree_136_318 = ({1'h0, rtlzz_pipe_316_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_319Core rtlzz_owner_319(.a(97'(mul_tree_136_317)), .b(129'(mul_tree_136_318)), .cin(1'h0), .value(mul_tree_136_319[127:0]));
    assign mul_tree_136_319[129:128] = '0;
    assign mul_tree_136_320 = mul_tree_136_319[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_321 = rtlzz_pipe_112_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_322 = rtlzz_pipe_113_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_323Core rtlzz_owner_323(.a(32'(mul_tree_137_321)), .b(32'(mul_tree_137_322)), .cin(1'b0), .value(mul_tree_137_323));
    assign mul_tree_137_324 = rtlzz_pipe_112_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_137_325 = rtlzz_pipe_113_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_326Core rtlzz_owner_326(.a(32'(mul_tree_137_324)), .b(32'(mul_tree_137_325)), .cin(1'b0), .value(mul_tree_137_326));
    assign mul_tree_137_327 = {mul_tree_137_326, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_328 = rtlzz_pipe_112_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_329 = rtlzz_pipe_113_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(32'(mul_tree_137_328)), .b(32'(mul_tree_137_329)), .cin(1'b0), .value(mul_tree_137_330));
    assign mul_tree_137_331 = {mul_tree_137_330, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_332 = rtlzz_pipe_112_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_137_333 = rtlzz_pipe_113_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_334Core rtlzz_owner_334(.a(32'(mul_tree_137_332)), .b(32'(mul_tree_137_333)), .cin(1'b0), .value(mul_tree_137_334));
    assign mul_tree_137_335 = {mul_tree_137_334, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_137_336 = ({33'h0, rtlzz_pipe_323_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_337 = ({1'h0, rtlzz_pipe_327_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_339 = ({33'h0, rtlzz_pipe_331_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_340 = ({1'h0, rtlzz_pipe_335_s5}); // decl: <none>; prim: <none>
    assign mul_tree_137_342 = ({33'h0, mul_tree_137_338}); // decl: <none>; prim: <none>
    assign mul_tree_137_343 = ({1'h0, mul_tree_137_341}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_344_reduce rtlzz_reduce_344(.i924(rtlzz_pipe_323_s5), .i926(rtlzz_pipe_327_s5), .i928(rtlzz_pipe_331_s5), .i930(rtlzz_pipe_335_s5), .y(mul_tree_137_344));
    assign mul_tree_137_345 = mul_tree_137_344[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_346 = rtlzz_pipe_114_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_347 = rtlzz_pipe_115_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(32'(mul_tree_138_346)), .b(32'(mul_tree_138_347)), .cin(1'b0), .value(mul_tree_138_348));
    assign mul_tree_138_349 = rtlzz_pipe_114_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_138_350 = rtlzz_pipe_115_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(32'(mul_tree_138_349)), .b(32'(mul_tree_138_350)), .cin(1'b0), .value(mul_tree_138_351));
    assign mul_tree_138_352 = {mul_tree_138_351, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_353 = rtlzz_pipe_114_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_354 = rtlzz_pipe_115_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(32'(mul_tree_138_353)), .b(32'(mul_tree_138_354)), .cin(1'b0), .value(mul_tree_138_355));
    assign mul_tree_138_356 = {mul_tree_138_355, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_357 = rtlzz_pipe_114_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_138_358 = rtlzz_pipe_115_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(32'(mul_tree_138_357)), .b(32'(mul_tree_138_358)), .cin(1'b0), .value(mul_tree_138_359));
    assign mul_tree_138_360 = {mul_tree_138_359, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_138_361 = ({33'h0, mul_tree_138_348}); // decl: <none>; prim: <none>
    assign mul_tree_138_362 = ({1'h0, mul_tree_138_352}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_363Core rtlzz_owner_363(.a(64'(mul_tree_138_361)), .b(96'(mul_tree_138_362)), .cin(1'h0), .value(mul_tree_138_363));
    assign mul_tree_138_364 = ({33'h0, mul_tree_138_356}); // decl: <none>; prim: <none>
    assign mul_tree_138_365 = ({1'h0, mul_tree_138_360}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366Core rtlzz_owner_366(.a(96'(mul_tree_138_364)), .b(128'(mul_tree_138_365)), .cin(1'h0), .value(mul_tree_138_366[127:0]));
    assign mul_tree_138_366[128:128] = '0;
    assign mul_tree_138_367 = ({33'h0, rtlzz_pipe_363_s7}); // decl: <none>; prim: <none>
    assign mul_tree_138_368 = ({1'h0, rtlzz_pipe_366_s7}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(97'(mul_tree_138_367)), .b(129'(mul_tree_138_368)), .cin(1'h0), .value(mul_tree_138_369[127:0]));
    assign mul_tree_138_369[129:128] = '0;
    assign mul_tree_138_370 = mul_tree_138_369[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_371 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_372 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_139_371)), .b(32'(mul_tree_139_372)), .cin(1'b0), .value(mul_tree_139_373));
    assign mul_tree_139_374 = mul_precision_116[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_139_375 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(32'(mul_tree_139_374)), .b(32'(mul_tree_139_375)), .cin(1'b0), .value(mul_tree_139_376));
    assign mul_tree_139_377 = {mul_tree_139_376, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_378 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_379 = mul_precision_117[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_380Core rtlzz_owner_380(.a(32'(mul_tree_139_378)), .b(32'(mul_tree_139_379)), .cin(1'b0), .value(mul_tree_139_380));
    assign mul_tree_139_381 = {mul_tree_139_380, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_382 = mul_precision_116[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_139_383 = mul_precision_117[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_384Core rtlzz_owner_384(.a(32'(mul_tree_139_382)), .b(32'(mul_tree_139_383)), .cin(1'b0), .value(mul_tree_139_384));
    assign mul_tree_139_385 = {mul_tree_139_384, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_139_386 = ({33'h0, rtlzz_pipe_373_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_387 = ({1'h0, rtlzz_pipe_377_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(64'(mul_tree_139_386)), .b(96'(mul_tree_139_387)), .cin(1'h0), .value(mul_tree_139_388));
    assign mul_tree_139_389 = ({33'h0, rtlzz_pipe_381_s1}); // decl: <none>; prim: <none>
    assign mul_tree_139_390 = ({1'h0, rtlzz_pipe_385_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_391Core rtlzz_owner_391(.a(96'(mul_tree_139_389)), .b(128'(mul_tree_139_390)), .cin(1'h0), .value(mul_tree_139_391[127:0]));
    assign mul_tree_139_391[128:128] = '0;
    assign mul_tree_139_392 = ({33'h0, rtlzz_pipe_388_s2}); // decl: <none>; prim: <none>
    assign mul_tree_139_393 = ({1'h0, rtlzz_pipe_391_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(97'(mul_tree_139_392)), .b(129'(mul_tree_139_393)), .cin(1'h0), .value(mul_tree_139_394[127:0]));
    assign mul_tree_139_394[129:128] = '0;
    assign mul_tree_139_395 = mul_tree_139_394[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_396 = rtlzz_pipe_118_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_397 = rtlzz_pipe_119_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_140_396)), .b(32'(mul_tree_140_397)), .cin(1'b0), .value(mul_tree_140_398));
    assign mul_tree_140_399 = rtlzz_pipe_118_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_140_400 = rtlzz_pipe_119_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_401Core rtlzz_owner_401(.a(32'(mul_tree_140_399)), .b(32'(mul_tree_140_400)), .cin(1'b0), .value(mul_tree_140_401));
    assign mul_tree_140_402 = {mul_tree_140_401, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_403 = rtlzz_pipe_118_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_404 = rtlzz_pipe_119_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405Core rtlzz_owner_405(.a(32'(mul_tree_140_403)), .b(32'(mul_tree_140_404)), .cin(1'b0), .value(mul_tree_140_405));
    assign mul_tree_140_406 = {mul_tree_140_405, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_407 = rtlzz_pipe_118_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_140_408 = rtlzz_pipe_119_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_409Core rtlzz_owner_409(.a(32'(mul_tree_140_407)), .b(32'(mul_tree_140_408)), .cin(1'b0), .value(mul_tree_140_409));
    assign mul_tree_140_410 = {mul_tree_140_409, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_140_411 = ({33'h0, mul_tree_140_398}); // decl: <none>; prim: <none>
    assign mul_tree_140_412 = ({1'h0, mul_tree_140_402}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_413Core rtlzz_owner_413(.a(64'(mul_tree_140_411)), .b(96'(mul_tree_140_412)), .cin(1'h0), .value(mul_tree_140_413));
    assign mul_tree_140_414 = ({33'h0, mul_tree_140_406}); // decl: <none>; prim: <none>
    assign mul_tree_140_415 = ({1'h0, mul_tree_140_410}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_416Core rtlzz_owner_416(.a(96'(mul_tree_140_414)), .b(128'(mul_tree_140_415)), .cin(1'h0), .value(mul_tree_140_416[127:0]));
    assign mul_tree_140_416[128:128] = '0;
    assign mul_tree_140_417 = ({33'h0, rtlzz_pipe_413_s4}); // decl: <none>; prim: <none>
    assign mul_tree_140_418 = ({1'h0, rtlzz_pipe_416_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(97'(mul_tree_140_417)), .b(129'(mul_tree_140_418)), .cin(1'h0), .value(mul_tree_140_419[127:0]));
    assign mul_tree_140_419[129:128] = '0;
    assign mul_tree_140_420 = mul_tree_140_419[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_421 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_422 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(32'(mul_tree_141_421)), .b(32'(mul_tree_141_422)), .cin(1'b0), .value(mul_tree_141_423));
    assign mul_tree_141_424 = mul_precision_120[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_141_425 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_426Core rtlzz_owner_426(.a(32'(mul_tree_141_424)), .b(32'(mul_tree_141_425)), .cin(1'b0), .value(mul_tree_141_426));
    assign mul_tree_141_427 = {mul_tree_141_426, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_428 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_429 = mul_precision_121[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(32'(mul_tree_141_428)), .b(32'(mul_tree_141_429)), .cin(1'b0), .value(mul_tree_141_430));
    assign mul_tree_141_431 = {mul_tree_141_430, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_432 = mul_precision_120[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_141_433 = mul_precision_121[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_434Core rtlzz_owner_434(.a(32'(mul_tree_141_432)), .b(32'(mul_tree_141_433)), .cin(1'b0), .value(mul_tree_141_434));
    assign mul_tree_141_435 = {mul_tree_141_434, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_141_436 = ({33'h0, rtlzz_pipe_423_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_437 = ({1'h0, rtlzz_pipe_427_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_438Core rtlzz_owner_438(.a(64'(mul_tree_141_436)), .b(96'(mul_tree_141_437)), .cin(1'h0), .value(mul_tree_141_438));
    assign mul_tree_141_439 = ({33'h0, rtlzz_pipe_431_s1}); // decl: <none>; prim: <none>
    assign mul_tree_141_440 = ({1'h0, rtlzz_pipe_435_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_441Core rtlzz_owner_441(.a(96'(mul_tree_141_439)), .b(128'(mul_tree_141_440)), .cin(1'h0), .value(mul_tree_141_441[127:0]));
    assign mul_tree_141_441[128:128] = '0;
    assign mul_tree_141_442 = ({33'h0, rtlzz_pipe_438_s2}); // decl: <none>; prim: <none>
    assign mul_tree_141_443 = ({1'h0, rtlzz_pipe_441_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_444Core rtlzz_owner_444(.a(97'(mul_tree_141_442)), .b(129'(mul_tree_141_443)), .cin(1'h0), .value(mul_tree_141_444[127:0]));
    assign mul_tree_141_444[129:128] = '0;
    assign mul_tree_141_445 = mul_tree_141_444[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_446 = rtlzz_pipe_122_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_447 = rtlzz_pipe_123_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_448Core rtlzz_owner_448(.a(32'(mul_tree_142_446)), .b(32'(mul_tree_142_447)), .cin(1'b0), .value(mul_tree_142_448));
    assign mul_tree_142_449 = rtlzz_pipe_122_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_142_450 = rtlzz_pipe_123_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(32'(mul_tree_142_449)), .b(32'(mul_tree_142_450)), .cin(1'b0), .value(mul_tree_142_451));
    assign mul_tree_142_452 = {mul_tree_142_451, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_453 = rtlzz_pipe_122_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_454 = rtlzz_pipe_123_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(32'(mul_tree_142_453)), .b(32'(mul_tree_142_454)), .cin(1'b0), .value(mul_tree_142_455));
    assign mul_tree_142_456 = {mul_tree_142_455, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_457 = rtlzz_pipe_122_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_142_458 = rtlzz_pipe_123_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_459Core rtlzz_owner_459(.a(32'(mul_tree_142_457)), .b(32'(mul_tree_142_458)), .cin(1'b0), .value(mul_tree_142_459));
    assign mul_tree_142_460 = {mul_tree_142_459, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_142_461 = ({33'h0, rtlzz_pipe_448_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_462 = ({1'h0, rtlzz_pipe_452_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_464 = ({33'h0, rtlzz_pipe_456_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_465 = ({1'h0, rtlzz_pipe_460_s5}); // decl: <none>; prim: <none>
    assign mul_tree_142_467 = ({33'h0, mul_tree_142_463}); // decl: <none>; prim: <none>
    assign mul_tree_142_468 = ({1'h0, mul_tree_142_466}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_469_reduce rtlzz_reduce_469(.i947(rtlzz_pipe_448_s5), .i948(rtlzz_pipe_452_s5), .i949(rtlzz_pipe_456_s5), .i950(rtlzz_pipe_460_s5), .y(mul_tree_142_469));
    assign mul_tree_142_470 = mul_tree_142_469[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_471 = rtlzz_pipe_124_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_472 = rtlzz_pipe_125_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_473Core rtlzz_owner_473(.a(32'(mul_tree_143_471)), .b(32'(mul_tree_143_472)), .cin(1'b0), .value(mul_tree_143_473));
    assign mul_tree_143_474 = rtlzz_pipe_124_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_143_475 = rtlzz_pipe_125_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_143_474)), .b(32'(mul_tree_143_475)), .cin(1'b0), .value(mul_tree_143_476));
    assign mul_tree_143_477 = {mul_tree_143_476, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_478 = rtlzz_pipe_124_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_479 = rtlzz_pipe_125_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_480Core rtlzz_owner_480(.a(32'(mul_tree_143_478)), .b(32'(mul_tree_143_479)), .cin(1'b0), .value(mul_tree_143_480));
    assign mul_tree_143_481 = {mul_tree_143_480, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_482 = rtlzz_pipe_124_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_143_483 = rtlzz_pipe_125_s6[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_484Core rtlzz_owner_484(.a(32'(mul_tree_143_482)), .b(32'(mul_tree_143_483)), .cin(1'b0), .value(mul_tree_143_484));
    assign mul_tree_143_485 = {mul_tree_143_484, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_143_486 = ({33'h0, rtlzz_pipe_473_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_487 = ({1'h0, rtlzz_pipe_477_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_489 = ({33'h0, rtlzz_pipe_481_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_490 = ({1'h0, rtlzz_pipe_485_s7}); // decl: <none>; prim: <none>
    assign mul_tree_143_492 = ({33'h0, mul_tree_143_488}); // decl: <none>; prim: <none>
    assign mul_tree_143_493 = ({1'h0, mul_tree_143_491}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_494_reduce rtlzz_reduce_494(.i951(rtlzz_pipe_473_s7), .i952(rtlzz_pipe_477_s7), .i953(rtlzz_pipe_481_s7), .i954(rtlzz_pipe_485_s7), .y(mul_tree_143_494));
    assign mul_tree_143_495 = mul_tree_143_494[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_496 = mul_precision_126[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_497 = mul_precision_127[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_498Core rtlzz_owner_498(.a(32'(mul_tree_144_496)), .b(32'(mul_tree_144_497)), .cin(1'b0), .value(mul_tree_144_498));
    assign mul_tree_144_499 = mul_precision_126[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_144_500 = mul_precision_127[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_144_499)), .b(32'(mul_tree_144_500)), .cin(1'b0), .value(mul_tree_144_501));
    assign mul_tree_144_502 = {mul_tree_144_501, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_503 = mul_precision_126[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_504 = mul_precision_127[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(32'(mul_tree_144_503)), .b(32'(mul_tree_144_504)), .cin(1'b0), .value(mul_tree_144_505));
    assign mul_tree_144_506 = {mul_tree_144_505, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_507 = mul_precision_126[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_144_508 = mul_precision_127[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_509Core rtlzz_owner_509(.a(32'(mul_tree_144_507)), .b(32'(mul_tree_144_508)), .cin(1'b0), .value(mul_tree_144_509));
    assign mul_tree_144_510 = {mul_tree_144_509, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_144_511 = ({33'h0, rtlzz_pipe_498_s1}); // decl: <none>; prim: <none>
    assign mul_tree_144_512 = ({1'h0, rtlzz_pipe_502_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_513Core rtlzz_owner_513(.a(64'(mul_tree_144_511)), .b(96'(mul_tree_144_512)), .cin(1'h0), .value(mul_tree_144_513));
    assign mul_tree_144_514 = ({33'h0, rtlzz_pipe_506_s1}); // decl: <none>; prim: <none>
    assign mul_tree_144_515 = ({1'h0, rtlzz_pipe_510_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_516Core rtlzz_owner_516(.a(96'(mul_tree_144_514)), .b(128'(mul_tree_144_515)), .cin(1'h0), .value(mul_tree_144_516[127:0]));
    assign mul_tree_144_516[128:128] = '0;
    assign mul_tree_144_517 = ({33'h0, rtlzz_pipe_513_s2}); // decl: <none>; prim: <none>
    assign mul_tree_144_518 = ({1'h0, rtlzz_pipe_516_s2}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_519Core rtlzz_owner_519(.a(97'(mul_tree_144_517)), .b(129'(mul_tree_144_518)), .cin(1'h0), .value(mul_tree_144_519[127:0]));
    assign mul_tree_144_519[129:128] = '0;
    assign mul_tree_144_520 = mul_tree_144_519[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_521 = rtlzz_pipe_128_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_522 = rtlzz_pipe_129_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_523Core rtlzz_owner_523(.a(32'(mul_tree_145_521)), .b(32'(mul_tree_145_522)), .cin(1'b0), .value(mul_tree_145_523));
    assign mul_tree_145_524 = rtlzz_pipe_128_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_145_525 = rtlzz_pipe_129_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(32'(mul_tree_145_524)), .b(32'(mul_tree_145_525)), .cin(1'b0), .value(mul_tree_145_526));
    assign mul_tree_145_527 = {mul_tree_145_526, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_528 = rtlzz_pipe_128_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_529 = rtlzz_pipe_129_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_530Core rtlzz_owner_530(.a(32'(mul_tree_145_528)), .b(32'(mul_tree_145_529)), .cin(1'b0), .value(mul_tree_145_530));
    assign mul_tree_145_531 = {mul_tree_145_530, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_532 = rtlzz_pipe_128_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_145_533 = rtlzz_pipe_129_s3[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_534Core rtlzz_owner_534(.a(32'(mul_tree_145_532)), .b(32'(mul_tree_145_533)), .cin(1'b0), .value(mul_tree_145_534));
    assign mul_tree_145_535 = {mul_tree_145_534, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_145_536 = ({33'h0, rtlzz_pipe_523_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_537 = ({1'h0, rtlzz_pipe_527_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_539 = ({33'h0, rtlzz_pipe_531_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_540 = ({1'h0, rtlzz_pipe_535_s4}); // decl: <none>; prim: <none>
    assign mul_tree_145_542 = ({33'h0, mul_tree_145_538}); // decl: <none>; prim: <none>
    assign mul_tree_145_543 = ({1'h0, mul_tree_145_541}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_544_reduce rtlzz_reduce_544(.i961(rtlzz_pipe_523_s4), .i962(rtlzz_pipe_527_s4), .i963(rtlzz_pipe_531_s4), .i964(rtlzz_pipe_535_s4), .y(mul_tree_145_544));
    assign mul_tree_145_545 = mul_tree_145_544[127:0]; // decl: <none>; prim: <none>
    assign limb_49_546 = ({1'h0, s8_norm_mul_2_v0}); // decl: <none>; prim: <none>
    assign limb_49_547 = ({1'h0, s8_norm_mul_6_v0}); // decl: <none>; prim: <none>
    assign limb_49_548 = limb_49_546[63:0]; // decl: <none>; prim: <none>
    assign limb_49_549 = limb_49_547[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(64'(rtlzz_pipe_548_s6)), .b(64'(rtlzz_pipe_549_s6)), .cin(1'h0), .value(limb_49_550));
    assign limb_49_551 = limb_49_550[63:0]; // decl: <none>; prim: <none>
    assign limb_49_552 = limb_49_550[64]; // decl: <none>; prim: <none>
    assign limb_49_553 = limb_49_546[127:64]; // decl: <none>; prim: <none>
    assign limb_49_554 = limb_49_547[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_555Core rtlzz_owner_555(.a(64'(rtlzz_pipe_553_s6)), .b(64'(rtlzz_pipe_554_s6)), .cin(limb_49_552), .value(limb_49_555));
    assign limb_49_556 = limb_49_555[63:0]; // decl: <none>; prim: <none>
    assign limb_49_557 = limb_49_555[64]; // decl: <none>; prim: <none>
    assign limb_49_558 = limb_49_546[128]; // decl: <none>; prim: <none>
    assign limb_49_559 = limb_49_547[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_560Core rtlzz_owner_560(.a(1'(rtlzz_pipe_558_s6)), .b(1'(rtlzz_pipe_559_s6)), .cin(limb_49_557), .value(limb_49_560[0:0]));
    assign limb_49_560[1:1] = '0;
    assign limb_49_561 = limb_49_560[0]; // decl: <none>; prim: <none>
    assign limb_49_562 = {limb_49_561, limb_49_556, limb_49_551}; // decl: <none>; prim: <none>
    assign limb_50_563 = ({1'h0, s8_norm_mul_10_v0}); // decl: <none>; prim: <none>
    assign limb_50_564 = ({1'h0, s8_norm_mul_14_v0}); // decl: <none>; prim: <none>
    assign limb_50_565 = limb_50_563[63:0]; // decl: <none>; prim: <none>
    assign limb_50_566 = limb_50_564[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_567Core rtlzz_owner_567(.a(64'(limb_50_565)), .b(64'(rtlzz_pipe_566_s7)), .cin(1'h0), .value(limb_50_567));
    assign limb_50_568 = limb_50_567[63:0]; // decl: <none>; prim: <none>
    assign limb_50_569 = limb_50_567[64]; // decl: <none>; prim: <none>
    assign limb_50_570 = limb_50_563[127:64]; // decl: <none>; prim: <none>
    assign limb_50_571 = limb_50_564[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_572Core rtlzz_owner_572(.a(64'(limb_50_570)), .b(64'(rtlzz_pipe_571_s7)), .cin(limb_50_569), .value(limb_50_572));
    assign limb_50_573 = limb_50_572[63:0]; // decl: <none>; prim: <none>
    assign limb_50_574 = limb_50_572[64]; // decl: <none>; prim: <none>
    assign limb_50_575 = limb_50_563[128]; // decl: <none>; prim: <none>
    assign limb_50_576 = limb_50_564[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_577Core rtlzz_owner_577(.a(1'(limb_50_575)), .b(1'(rtlzz_pipe_576_s7)), .cin(limb_50_574), .value(limb_50_577[0:0]));
    assign limb_50_577[1:1] = '0;
    assign limb_50_578 = limb_50_577[0]; // decl: <none>; prim: <none>
    assign limb_50_579 = {limb_50_578, limb_50_573, limb_50_568}; // decl: <none>; prim: <none>
    assign limb_51_580 = ({1'h0, s8_norm_mul_18_v0}); // decl: <none>; prim: <none>
    assign limb_51_581 = ({1'h0, s8_norm_mul_22_v0}); // decl: <none>; prim: <none>
    assign limb_51_582 = limb_51_580[63:0]; // decl: <none>; prim: <none>
    assign limb_51_583 = limb_51_581[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_584Core rtlzz_owner_584(.a(64'(rtlzz_pipe_582_s7)), .b(64'(limb_51_583)), .cin(1'h0), .value(limb_51_584));
    assign limb_51_585 = limb_51_584[63:0]; // decl: <none>; prim: <none>
    assign limb_51_586 = limb_51_584[64]; // decl: <none>; prim: <none>
    assign limb_51_587 = limb_51_580[127:64]; // decl: <none>; prim: <none>
    assign limb_51_588 = limb_51_581[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589Core rtlzz_owner_589(.a(64'(rtlzz_pipe_587_s7)), .b(64'(limb_51_588)), .cin(limb_51_586), .value(limb_51_589));
    assign limb_51_590 = limb_51_589[63:0]; // decl: <none>; prim: <none>
    assign limb_51_591 = limb_51_589[64]; // decl: <none>; prim: <none>
    assign limb_51_592 = limb_51_580[128]; // decl: <none>; prim: <none>
    assign limb_51_593 = limb_51_581[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_594Core rtlzz_owner_594(.a(1'(rtlzz_pipe_592_s7)), .b(1'(limb_51_593)), .cin(limb_51_591), .value(limb_51_594[0:0]));
    assign limb_51_594[1:1] = '0;
    assign limb_51_595 = limb_51_594[0]; // decl: <none>; prim: <none>
    assign limb_51_596 = {limb_51_595, limb_51_590, limb_51_585}; // decl: <none>; prim: <none>
    assign limb_52_597 = ({1'h0, s8_norm_mul_26_v0}); // decl: <none>; prim: <none>
    assign limb_52_598 = ({1'h0, s8_norm_mul_30_v0}); // decl: <none>; prim: <none>
    assign limb_52_599 = limb_52_597[63:0]; // decl: <none>; prim: <none>
    assign limb_52_600 = limb_52_598[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_601Core rtlzz_owner_601(.a(64'(rtlzz_pipe_599_s5)), .b(64'(limb_52_600)), .cin(1'h0), .value(limb_52_601));
    assign limb_52_602 = limb_52_601[63:0]; // decl: <none>; prim: <none>
    assign limb_52_603 = limb_52_601[64]; // decl: <none>; prim: <none>
    assign limb_52_604 = limb_52_597[127:64]; // decl: <none>; prim: <none>
    assign limb_52_605 = limb_52_598[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_606Core rtlzz_owner_606(.a(64'(rtlzz_pipe_604_s5)), .b(64'(limb_52_605)), .cin(limb_52_603), .value(limb_52_606));
    assign limb_52_607 = limb_52_606[63:0]; // decl: <none>; prim: <none>
    assign limb_52_608 = limb_52_606[64]; // decl: <none>; prim: <none>
    assign limb_52_609 = limb_52_597[128]; // decl: <none>; prim: <none>
    assign limb_52_610 = limb_52_598[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_611Core rtlzz_owner_611(.a(1'(rtlzz_pipe_609_s5)), .b(1'(limb_52_610)), .cin(limb_52_608), .value(limb_52_611[0:0]));
    assign limb_52_611[1:1] = '0;
    assign limb_52_612 = limb_52_611[0]; // decl: <none>; prim: <none>
    assign limb_52_613 = {limb_52_612, limb_52_607, limb_52_602}; // decl: <none>; prim: <none>
    assign limb_53_614 = ({1'h0, s8_norm_mul_34_v0}); // decl: <none>; prim: <none>
    assign limb_53_615 = ({1'h0, s8_norm_mul_38_v0}); // decl: <none>; prim: <none>
    assign limb_53_616 = limb_53_614[63:0]; // decl: <none>; prim: <none>
    assign limb_53_617 = limb_53_615[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_618Core rtlzz_owner_618(.a(64'(limb_53_616)), .b(64'(rtlzz_pipe_617_s7)), .cin(1'h0), .value(limb_53_618));
    assign limb_53_619 = limb_53_618[63:0]; // decl: <none>; prim: <none>
    assign limb_53_620 = limb_53_618[64]; // decl: <none>; prim: <none>
    assign limb_53_621 = limb_53_614[127:64]; // decl: <none>; prim: <none>
    assign limb_53_622 = limb_53_615[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_623Core rtlzz_owner_623(.a(64'(limb_53_621)), .b(64'(rtlzz_pipe_622_s7)), .cin(limb_53_620), .value(limb_53_623));
    assign limb_53_624 = limb_53_623[63:0]; // decl: <none>; prim: <none>
    assign limb_53_625 = limb_53_623[64]; // decl: <none>; prim: <none>
    assign limb_53_626 = limb_53_614[128]; // decl: <none>; prim: <none>
    assign limb_53_627 = limb_53_615[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_628Core rtlzz_owner_628(.a(1'(limb_53_626)), .b(1'(rtlzz_pipe_627_s7)), .cin(limb_53_625), .value(limb_53_628[0:0]));
    assign limb_53_628[1:1] = '0;
    assign limb_53_629 = limb_53_628[0]; // decl: <none>; prim: <none>
    assign limb_53_630 = {limb_53_629, limb_53_624, limb_53_619}; // decl: <none>; prim: <none>
    assign limb_54_631 = ({1'h0, s8_norm_mul_42_v0}); // decl: <none>; prim: <none>
    assign limb_54_632 = ({1'h0, s8_norm_mul_46_v0}); // decl: <none>; prim: <none>
    assign limb_54_633 = limb_54_631[63:0]; // decl: <none>; prim: <none>
    assign limb_54_634 = limb_54_632[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_635Core rtlzz_owner_635(.a(64'(limb_54_633)), .b(64'(rtlzz_pipe_634_s4)), .cin(1'h0), .value(limb_54_635));
    assign limb_54_636 = limb_54_635[63:0]; // decl: <none>; prim: <none>
    assign limb_54_637 = limb_54_635[64]; // decl: <none>; prim: <none>
    assign limb_54_638 = limb_54_631[127:64]; // decl: <none>; prim: <none>
    assign limb_54_639 = limb_54_632[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_640Core rtlzz_owner_640(.a(64'(limb_54_638)), .b(64'(rtlzz_pipe_639_s4)), .cin(limb_54_637), .value(limb_54_640));
    assign limb_54_641 = limb_54_640[63:0]; // decl: <none>; prim: <none>
    assign limb_54_642 = limb_54_640[64]; // decl: <none>; prim: <none>
    assign limb_54_643 = limb_54_631[128]; // decl: <none>; prim: <none>
    assign limb_54_644 = limb_54_632[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_645Core rtlzz_owner_645(.a(1'(rtlzz_pipe_643_s5)), .b(1'(rtlzz_pipe_644_s5)), .cin(rtlzz_pipe_642_s5), .value(limb_54_645[0:0]));
    assign limb_54_645[1:1] = '0;
    assign limb_54_646 = limb_54_645[0]; // decl: <none>; prim: <none>
    assign limb_54_647 = {limb_54_646, rtlzz_pipe_641_s5, rtlzz_pipe_636_s5}; // decl: <none>; prim: <none>
    assign limb_55_648 = ({1'h0, s8_norm_mul_50_v0}); // decl: <none>; prim: <none>
    assign limb_55_649 = ({1'h0, s8_norm_mul_54_v0}); // decl: <none>; prim: <none>
    assign limb_55_650 = limb_55_648[63:0]; // decl: <none>; prim: <none>
    assign limb_55_651 = limb_55_649[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_652Core rtlzz_owner_652(.a(64'(rtlzz_pipe_650_s7)), .b(64'(limb_55_651)), .cin(1'h0), .value(limb_55_652));
    assign limb_55_653 = limb_55_652[63:0]; // decl: <none>; prim: <none>
    assign limb_55_654 = limb_55_652[64]; // decl: <none>; prim: <none>
    assign limb_55_655 = limb_55_648[127:64]; // decl: <none>; prim: <none>
    assign limb_55_656 = limb_55_649[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_657Core rtlzz_owner_657(.a(64'(rtlzz_pipe_655_s7)), .b(64'(limb_55_656)), .cin(limb_55_654), .value(limb_55_657));
    assign limb_55_658 = limb_55_657[63:0]; // decl: <none>; prim: <none>
    assign limb_55_659 = limb_55_657[64]; // decl: <none>; prim: <none>
    assign limb_55_660 = limb_55_648[128]; // decl: <none>; prim: <none>
    assign limb_55_661 = limb_55_649[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_662Core rtlzz_owner_662(.a(1'(rtlzz_pipe_660_s7)), .b(1'(limb_55_661)), .cin(limb_55_659), .value(limb_55_662[0:0]));
    assign limb_55_662[1:1] = '0;
    assign limb_55_663 = limb_55_662[0]; // decl: <none>; prim: <none>
    assign limb_55_664 = {limb_55_663, limb_55_658, limb_55_653}; // decl: <none>; prim: <none>
    assign limb_56_665 = ({1'h0, s8_norm_mul_58_v0}); // decl: <none>; prim: <none>
    assign limb_56_666 = ({1'h0, s8_norm_mul_62_v0}); // decl: <none>; prim: <none>
    assign limb_56_667 = limb_56_665[63:0]; // decl: <none>; prim: <none>
    assign limb_56_668 = limb_56_666[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_669Core rtlzz_owner_669(.a(64'(rtlzz_pipe_667_s6)), .b(64'(rtlzz_pipe_668_s6)), .cin(1'h0), .value(limb_56_669));
    assign limb_56_670 = limb_56_669[63:0]; // decl: <none>; prim: <none>
    assign limb_56_671 = limb_56_669[64]; // decl: <none>; prim: <none>
    assign limb_56_672 = limb_56_665[127:64]; // decl: <none>; prim: <none>
    assign limb_56_673 = limb_56_666[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_674Core rtlzz_owner_674(.a(64'(rtlzz_pipe_672_s6)), .b(64'(rtlzz_pipe_673_s6)), .cin(limb_56_671), .value(limb_56_674));
    assign limb_56_675 = limb_56_674[63:0]; // decl: <none>; prim: <none>
    assign limb_56_676 = limb_56_674[64]; // decl: <none>; prim: <none>
    assign limb_56_677 = limb_56_665[128]; // decl: <none>; prim: <none>
    assign limb_56_678 = limb_56_666[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_679Core rtlzz_owner_679(.a(1'(rtlzz_pipe_677_s6)), .b(1'(rtlzz_pipe_678_s6)), .cin(limb_56_676), .value(limb_56_679[0:0]));
    assign limb_56_679[1:1] = '0;
    assign limb_56_680 = limb_56_679[0]; // decl: <none>; prim: <none>
    assign limb_56_681 = {limb_56_680, limb_56_675, limb_56_670}; // decl: <none>; prim: <none>
    assign limb_57_682 = ({1'h0, s8_norm_add_64_v0}); // decl: <none>; prim: <none>
    assign limb_57_683 = ({1'h0, s8_norm_add_65_v0}); // decl: <none>; prim: <none>
    assign limb_57_684 = limb_57_682[63:0]; // decl: <none>; prim: <none>
    assign limb_57_685 = limb_57_683[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_686Core rtlzz_owner_686(.a(64'(rtlzz_pipe_684_s7)), .b(64'(limb_57_685)), .cin(1'h0), .value(limb_57_686));
    assign limb_57_687 = limb_57_686[63:0]; // decl: <none>; prim: <none>
    assign limb_57_688 = limb_57_686[64]; // decl: <none>; prim: <none>
    assign limb_57_689 = limb_57_682[127:64]; // decl: <none>; prim: <none>
    assign limb_57_690 = limb_57_683[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_691Core rtlzz_owner_691(.a(64'(rtlzz_pipe_689_s7)), .b(64'(limb_57_690)), .cin(limb_57_688), .value(limb_57_691));
    assign limb_57_692 = limb_57_691[63:0]; // decl: <none>; prim: <none>
    assign limb_57_693 = limb_57_691[64]; // decl: <none>; prim: <none>
    assign limb_57_694 = limb_57_682[129:128]; // decl: <none>; prim: <none>
    assign limb_57_695 = limb_57_683[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_696Core rtlzz_owner_696(.a(2'(rtlzz_pipe_694_s7)), .b(2'(limb_57_695)), .cin(limb_57_693), .value(limb_57_696[1:0]));
    assign limb_57_696[2:2] = '0;
    assign limb_57_697 = limb_57_696[1:0]; // decl: <none>; prim: <none>
    assign limb_57_698 = {limb_57_697, limb_57_692, limb_57_687}; // decl: <none>; prim: <none>
    assign limb_58_699 = ({1'h0, s8_norm_add_66_v0}); // decl: <none>; prim: <none>
    assign limb_58_700 = ({1'h0, s8_norm_add_67_v0}); // decl: <none>; prim: <none>
    assign limb_58_701 = limb_58_699[63:0]; // decl: <none>; prim: <none>
    assign limb_58_702 = limb_58_700[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_703Core rtlzz_owner_703(.a(64'(limb_58_701)), .b(64'(rtlzz_pipe_702_s7)), .cin(1'h0), .value(limb_58_703));
    assign limb_58_704 = limb_58_703[63:0]; // decl: <none>; prim: <none>
    assign limb_58_705 = limb_58_703[64]; // decl: <none>; prim: <none>
    assign limb_58_706 = limb_58_699[127:64]; // decl: <none>; prim: <none>
    assign limb_58_707 = limb_58_700[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_708Core rtlzz_owner_708(.a(64'(limb_58_706)), .b(64'(rtlzz_pipe_707_s7)), .cin(limb_58_705), .value(limb_58_708));
    assign limb_58_709 = limb_58_708[63:0]; // decl: <none>; prim: <none>
    assign limb_58_710 = limb_58_708[64]; // decl: <none>; prim: <none>
    assign limb_58_711 = limb_58_699[129:128]; // decl: <none>; prim: <none>
    assign limb_58_712 = limb_58_700[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_713Core rtlzz_owner_713(.a(2'(limb_58_711)), .b(2'(rtlzz_pipe_712_s7)), .cin(limb_58_710), .value(limb_58_713[1:0]));
    assign limb_58_713[2:2] = '0;
    assign limb_58_714 = limb_58_713[1:0]; // decl: <none>; prim: <none>
    assign limb_58_715 = {limb_58_714, limb_58_709, limb_58_704}; // decl: <none>; prim: <none>
    assign limb_59_716 = ({1'h0, s8_norm_add_68_v0}); // decl: <none>; prim: <none>
    assign limb_59_717 = ({1'h0, s8_norm_add_69_v0}); // decl: <none>; prim: <none>
    assign limb_59_718 = limb_59_716[63:0]; // decl: <none>; prim: <none>
    assign limb_59_719 = limb_59_717[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_720Core rtlzz_owner_720(.a(64'(limb_59_718)), .b(64'(rtlzz_pipe_719_s7)), .cin(1'h0), .value(limb_59_720));
    assign limb_59_721 = limb_59_720[63:0]; // decl: <none>; prim: <none>
    assign limb_59_722 = limb_59_720[64]; // decl: <none>; prim: <none>
    assign limb_59_723 = limb_59_716[127:64]; // decl: <none>; prim: <none>
    assign limb_59_724 = limb_59_717[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_725Core rtlzz_owner_725(.a(64'(limb_59_723)), .b(64'(rtlzz_pipe_724_s7)), .cin(limb_59_722), .value(limb_59_725));
    assign limb_59_726 = limb_59_725[63:0]; // decl: <none>; prim: <none>
    assign limb_59_727 = limb_59_725[64]; // decl: <none>; prim: <none>
    assign limb_59_728 = limb_59_716[129:128]; // decl: <none>; prim: <none>
    assign limb_59_729 = limb_59_717[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_730Core rtlzz_owner_730(.a(2'(limb_59_728)), .b(2'(rtlzz_pipe_729_s7)), .cin(limb_59_727), .value(limb_59_730[1:0]));
    assign limb_59_730[2:2] = '0;
    assign limb_59_731 = limb_59_730[1:0]; // decl: <none>; prim: <none>
    assign limb_59_732 = {limb_59_731, limb_59_726, limb_59_721}; // decl: <none>; prim: <none>
    assign limb_60_733 = ({1'h0, s8_norm_add_70_v0}); // decl: <none>; prim: <none>
    assign limb_60_734 = ({1'h0, s8_norm_add_71_v0}); // decl: <none>; prim: <none>
    assign limb_60_735 = limb_60_733[63:0]; // decl: <none>; prim: <none>
    assign limb_60_736 = limb_60_734[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_737Core rtlzz_owner_737(.a(64'(limb_60_735)), .b(64'(rtlzz_pipe_736_s7)), .cin(1'h0), .value(limb_60_737));
    assign limb_60_738 = limb_60_737[63:0]; // decl: <none>; prim: <none>
    assign limb_60_739 = limb_60_737[64]; // decl: <none>; prim: <none>
    assign limb_60_740 = limb_60_733[127:64]; // decl: <none>; prim: <none>
    assign limb_60_741 = limb_60_734[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_742Core rtlzz_owner_742(.a(64'(limb_60_740)), .b(64'(rtlzz_pipe_741_s7)), .cin(limb_60_739), .value(limb_60_742));
    assign limb_60_743 = limb_60_742[63:0]; // decl: <none>; prim: <none>
    assign limb_60_744 = limb_60_742[64]; // decl: <none>; prim: <none>
    assign limb_60_745 = limb_60_733[129:128]; // decl: <none>; prim: <none>
    assign limb_60_746 = limb_60_734[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_747Core rtlzz_owner_747(.a(2'(limb_60_745)), .b(2'(rtlzz_pipe_746_s7)), .cin(limb_60_744), .value(limb_60_747[1:0]));
    assign limb_60_747[2:2] = '0;
    assign limb_60_748 = limb_60_747[1:0]; // decl: <none>; prim: <none>
    assign limb_60_749 = {limb_60_748, limb_60_743, limb_60_738}; // decl: <none>; prim: <none>
    assign limb_61_750 = ({1'h0, s8_norm_add_72_v0}); // decl: <none>; prim: <none>
    assign limb_61_751 = ({1'h0, s8_norm_add_73_v0}); // decl: <none>; prim: <none>
    assign limb_61_752 = limb_61_750[63:0]; // decl: <none>; prim: <none>
    assign limb_61_753 = limb_61_751[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_754Core rtlzz_owner_754(.a(64'(limb_61_752)), .b(64'(limb_61_753)), .cin(1'h0), .value(limb_61_754));
    assign limb_61_755 = limb_61_754[63:0]; // decl: <none>; prim: <none>
    assign limb_61_756 = limb_61_754[64]; // decl: <none>; prim: <none>
    assign limb_61_757 = limb_61_750[127:64]; // decl: <none>; prim: <none>
    assign limb_61_758 = limb_61_751[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_759Core rtlzz_owner_759(.a(64'(limb_61_757)), .b(64'(limb_61_758)), .cin(limb_61_756), .value(limb_61_759));
    assign limb_61_760 = limb_61_759[63:0]; // decl: <none>; prim: <none>
    assign limb_61_761 = limb_61_759[64]; // decl: <none>; prim: <none>
    assign limb_61_762 = limb_61_750[130:128]; // decl: <none>; prim: <none>
    assign limb_61_763 = limb_61_751[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_764Core rtlzz_owner_764(.a(3'(limb_61_762)), .b(3'(limb_61_763)), .cin(limb_61_761), .value(limb_61_764[2:0]));
    assign limb_61_764[3:3] = '0;
    assign limb_61_765 = limb_61_764[2:0]; // decl: <none>; prim: <none>
    assign limb_61_766 = {limb_61_765, limb_61_760, limb_61_755}; // decl: <none>; prim: <none>
    assign limb_62_767 = ({1'h0, s8_norm_add_74_v0}); // decl: <none>; prim: <none>
    assign limb_62_768 = ({1'h0, s8_norm_add_75_v0}); // decl: <none>; prim: <none>
    assign limb_62_769 = limb_62_767[63:0]; // decl: <none>; prim: <none>
    assign limb_62_770 = limb_62_768[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_771Core rtlzz_owner_771(.a(64'(limb_62_769)), .b(64'(limb_62_770)), .cin(1'h0), .value(limb_62_771));
    assign limb_62_772 = limb_62_771[63:0]; // decl: <none>; prim: <none>
    assign limb_62_773 = limb_62_771[64]; // decl: <none>; prim: <none>
    assign limb_62_774 = limb_62_767[127:64]; // decl: <none>; prim: <none>
    assign limb_62_775 = limb_62_768[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_776Core rtlzz_owner_776(.a(64'(limb_62_774)), .b(64'(limb_62_775)), .cin(limb_62_773), .value(limb_62_776));
    assign limb_62_777 = limb_62_776[63:0]; // decl: <none>; prim: <none>
    assign limb_62_778 = limb_62_776[64]; // decl: <none>; prim: <none>
    assign limb_62_779 = limb_62_767[130:128]; // decl: <none>; prim: <none>
    assign limb_62_780 = limb_62_768[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_781Core rtlzz_owner_781(.a(3'(limb_62_779)), .b(3'(limb_62_780)), .cin(limb_62_778), .value(limb_62_781[2:0]));
    assign limb_62_781[3:3] = '0;
    assign limb_62_782 = limb_62_781[2:0]; // decl: <none>; prim: <none>
    assign limb_62_783 = {limb_62_782, limb_62_777, limb_62_772}; // decl: <none>; prim: <none>
    assign limb_63_784 = ({1'h0, s8_norm_add_76_v0}); // decl: <none>; prim: <none>
    assign limb_63_785 = ({1'h0, s8_norm_add_77_v0}); // decl: <none>; prim: <none>
    assign limb_63_786 = limb_63_784[63:0]; // decl: <none>; prim: <none>
    assign limb_63_787 = limb_63_785[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_788Core rtlzz_owner_788(.a(64'(limb_63_786)), .b(64'(limb_63_787)), .cin(1'h0), .value(limb_63_788));
    assign limb_63_789 = limb_63_788[63:0]; // decl: <none>; prim: <none>
    assign limb_63_790 = limb_63_788[64]; // decl: <none>; prim: <none>
    assign limb_63_791 = limb_63_784[127:64]; // decl: <none>; prim: <none>
    assign limb_63_792 = limb_63_785[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_793Core rtlzz_owner_793(.a(64'(limb_63_791)), .b(64'(limb_63_792)), .cin(limb_63_790), .value(limb_63_793));
    assign limb_63_794 = limb_63_793[63:0]; // decl: <none>; prim: <none>
    assign limb_63_795 = limb_63_793[64]; // decl: <none>; prim: <none>
    assign limb_63_796 = limb_63_784[131:128]; // decl: <none>; prim: <none>
    assign limb_63_797 = limb_63_785[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_798Core rtlzz_owner_798(.a(4'(limb_63_796)), .b(4'(limb_63_797)), .cin(limb_63_795), .value(limb_63_798[3:0]));
    assign limb_63_798[4:4] = '0;
    assign limb_63_799 = limb_63_798[3:0]; // decl: <none>; prim: <none>
    assign limb_63_800 = {limb_63_799, limb_63_794, limb_63_789}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_100_s2 <= 64'h0;
            rtlzz_pipe_100_s3 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_101_s2 <= 64'h0;
            rtlzz_pipe_101_s3 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_102_s3 <= 64'h0;
            rtlzz_pipe_102_s4 <= 64'h0;
            rtlzz_pipe_102_s5 <= 64'h0;
            rtlzz_pipe_102_s6 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_103_s3 <= 64'h0;
            rtlzz_pipe_103_s4 <= 64'h0;
            rtlzz_pipe_103_s5 <= 64'h0;
            rtlzz_pipe_103_s6 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_108_s1 <= 64'h0;
            rtlzz_pipe_108_s2 <= 64'h0;
            rtlzz_pipe_108_s3 <= 64'h0;
            rtlzz_pipe_108_s4 <= 64'h0;
            rtlzz_pipe_108_s5 <= 64'h0;
            rtlzz_pipe_109_s1 <= 64'h0;
            rtlzz_pipe_109_s2 <= 64'h0;
            rtlzz_pipe_109_s3 <= 64'h0;
            rtlzz_pipe_109_s4 <= 64'h0;
            rtlzz_pipe_109_s5 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_112_s3 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_113_s3 <= 64'h0;
            rtlzz_pipe_114_s1 <= 64'h0;
            rtlzz_pipe_114_s2 <= 64'h0;
            rtlzz_pipe_114_s3 <= 64'h0;
            rtlzz_pipe_114_s4 <= 64'h0;
            rtlzz_pipe_114_s5 <= 64'h0;
            rtlzz_pipe_114_s6 <= 64'h0;
            rtlzz_pipe_115_s1 <= 64'h0;
            rtlzz_pipe_115_s2 <= 64'h0;
            rtlzz_pipe_115_s3 <= 64'h0;
            rtlzz_pipe_115_s4 <= 64'h0;
            rtlzz_pipe_115_s5 <= 64'h0;
            rtlzz_pipe_115_s6 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_118_s2 <= 64'h0;
            rtlzz_pipe_118_s3 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_119_s2 <= 64'h0;
            rtlzz_pipe_119_s3 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_122_s4 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_123_s4 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_124_s6 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_125_s6 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_128_s2 <= 64'h0;
            rtlzz_pipe_128_s3 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_129_s2 <= 64'h0;
            rtlzz_pipe_129_s3 <= 64'h0;
            rtlzz_pipe_148_s1 <= 64'h0;
            rtlzz_pipe_152_s1 <= 96'h0;
            rtlzz_pipe_156_s1 <= 96'h0;
            rtlzz_pipe_160_s1 <= 128'h0;
            rtlzz_pipe_163_s2 <= 97'h0;
            rtlzz_pipe_166_s2 <= 129'h0;
            rtlzz_pipe_173_s4 <= 64'h0;
            rtlzz_pipe_177_s4 <= 96'h0;
            rtlzz_pipe_181_s4 <= 96'h0;
            rtlzz_pipe_185_s4 <= 128'h0;
            rtlzz_pipe_188_s5 <= 97'h0;
            rtlzz_pipe_191_s5 <= 129'h0;
            rtlzz_pipe_213_s7 <= 97'h0;
            rtlzz_pipe_216_s7 <= 129'h0;
            rtlzz_pipe_223_s1 <= 64'h0;
            rtlzz_pipe_227_s1 <= 96'h0;
            rtlzz_pipe_231_s1 <= 96'h0;
            rtlzz_pipe_235_s1 <= 128'h0;
            rtlzz_pipe_238_s2 <= 97'h0;
            rtlzz_pipe_241_s2 <= 129'h0;
            rtlzz_pipe_248_s4 <= 64'h0;
            rtlzz_pipe_252_s4 <= 96'h0;
            rtlzz_pipe_256_s4 <= 96'h0;
            rtlzz_pipe_260_s4 <= 128'h0;
            rtlzz_pipe_273_s6 <= 64'h0;
            rtlzz_pipe_273_s7 <= 64'h0;
            rtlzz_pipe_277_s6 <= 96'h0;
            rtlzz_pipe_277_s7 <= 96'h0;
            rtlzz_pipe_281_s6 <= 96'h0;
            rtlzz_pipe_281_s7 <= 96'h0;
            rtlzz_pipe_285_s6 <= 128'h0;
            rtlzz_pipe_285_s7 <= 128'h0;
            rtlzz_pipe_298_s1 <= 64'h0;
            rtlzz_pipe_302_s1 <= 96'h0;
            rtlzz_pipe_306_s1 <= 96'h0;
            rtlzz_pipe_310_s1 <= 128'h0;
            rtlzz_pipe_313_s2 <= 97'h0;
            rtlzz_pipe_316_s2 <= 129'h0;
            rtlzz_pipe_323_s4 <= 64'h0;
            rtlzz_pipe_323_s5 <= 64'h0;
            rtlzz_pipe_327_s4 <= 96'h0;
            rtlzz_pipe_327_s5 <= 96'h0;
            rtlzz_pipe_331_s4 <= 96'h0;
            rtlzz_pipe_331_s5 <= 96'h0;
            rtlzz_pipe_335_s4 <= 128'h0;
            rtlzz_pipe_335_s5 <= 128'h0;
            rtlzz_pipe_363_s7 <= 97'h0;
            rtlzz_pipe_366_s7 <= 129'h0;
            rtlzz_pipe_373_s1 <= 64'h0;
            rtlzz_pipe_377_s1 <= 96'h0;
            rtlzz_pipe_381_s1 <= 96'h0;
            rtlzz_pipe_385_s1 <= 128'h0;
            rtlzz_pipe_388_s2 <= 97'h0;
            rtlzz_pipe_391_s2 <= 129'h0;
            rtlzz_pipe_413_s4 <= 97'h0;
            rtlzz_pipe_416_s4 <= 129'h0;
            rtlzz_pipe_423_s1 <= 64'h0;
            rtlzz_pipe_427_s1 <= 96'h0;
            rtlzz_pipe_431_s1 <= 96'h0;
            rtlzz_pipe_435_s1 <= 128'h0;
            rtlzz_pipe_438_s2 <= 97'h0;
            rtlzz_pipe_441_s2 <= 129'h0;
            rtlzz_pipe_448_s5 <= 64'h0;
            rtlzz_pipe_452_s5 <= 96'h0;
            rtlzz_pipe_456_s5 <= 96'h0;
            rtlzz_pipe_460_s5 <= 128'h0;
            rtlzz_pipe_473_s7 <= 64'h0;
            rtlzz_pipe_477_s7 <= 96'h0;
            rtlzz_pipe_481_s7 <= 96'h0;
            rtlzz_pipe_485_s7 <= 128'h0;
            rtlzz_pipe_498_s1 <= 64'h0;
            rtlzz_pipe_502_s1 <= 96'h0;
            rtlzz_pipe_506_s1 <= 96'h0;
            rtlzz_pipe_510_s1 <= 128'h0;
            rtlzz_pipe_513_s2 <= 97'h0;
            rtlzz_pipe_516_s2 <= 129'h0;
            rtlzz_pipe_523_s4 <= 64'h0;
            rtlzz_pipe_527_s4 <= 96'h0;
            rtlzz_pipe_531_s4 <= 96'h0;
            rtlzz_pipe_535_s4 <= 128'h0;
            rtlzz_pipe_548_s3 <= 64'h0;
            rtlzz_pipe_548_s4 <= 64'h0;
            rtlzz_pipe_548_s5 <= 64'h0;
            rtlzz_pipe_548_s6 <= 64'h0;
            rtlzz_pipe_549_s6 <= 64'h0;
            rtlzz_pipe_553_s3 <= 64'h0;
            rtlzz_pipe_553_s4 <= 64'h0;
            rtlzz_pipe_553_s5 <= 64'h0;
            rtlzz_pipe_553_s6 <= 64'h0;
            rtlzz_pipe_554_s6 <= 64'h0;
            rtlzz_pipe_558_s3 <= 1'h0;
            rtlzz_pipe_558_s4 <= 1'h0;
            rtlzz_pipe_558_s5 <= 1'h0;
            rtlzz_pipe_558_s6 <= 1'h0;
            rtlzz_pipe_559_s6 <= 1'h0;
            rtlzz_pipe_566_s3 <= 64'h0;
            rtlzz_pipe_566_s4 <= 64'h0;
            rtlzz_pipe_566_s5 <= 64'h0;
            rtlzz_pipe_566_s6 <= 64'h0;
            rtlzz_pipe_566_s7 <= 64'h0;
            rtlzz_pipe_571_s3 <= 64'h0;
            rtlzz_pipe_571_s4 <= 64'h0;
            rtlzz_pipe_571_s5 <= 64'h0;
            rtlzz_pipe_571_s6 <= 64'h0;
            rtlzz_pipe_571_s7 <= 64'h0;
            rtlzz_pipe_576_s3 <= 1'h0;
            rtlzz_pipe_576_s4 <= 1'h0;
            rtlzz_pipe_576_s5 <= 1'h0;
            rtlzz_pipe_576_s6 <= 1'h0;
            rtlzz_pipe_576_s7 <= 1'h0;
            rtlzz_pipe_582_s5 <= 64'h0;
            rtlzz_pipe_582_s6 <= 64'h0;
            rtlzz_pipe_582_s7 <= 64'h0;
            rtlzz_pipe_587_s5 <= 64'h0;
            rtlzz_pipe_587_s6 <= 64'h0;
            rtlzz_pipe_587_s7 <= 64'h0;
            rtlzz_pipe_592_s5 <= 1'h0;
            rtlzz_pipe_592_s6 <= 1'h0;
            rtlzz_pipe_592_s7 <= 1'h0;
            rtlzz_pipe_599_s3 <= 64'h0;
            rtlzz_pipe_599_s4 <= 64'h0;
            rtlzz_pipe_599_s5 <= 64'h0;
            rtlzz_pipe_604_s3 <= 64'h0;
            rtlzz_pipe_604_s4 <= 64'h0;
            rtlzz_pipe_604_s5 <= 64'h0;
            rtlzz_pipe_609_s3 <= 1'h0;
            rtlzz_pipe_609_s4 <= 1'h0;
            rtlzz_pipe_609_s5 <= 1'h0;
            rtlzz_pipe_617_s3 <= 64'h0;
            rtlzz_pipe_617_s4 <= 64'h0;
            rtlzz_pipe_617_s5 <= 64'h0;
            rtlzz_pipe_617_s6 <= 64'h0;
            rtlzz_pipe_617_s7 <= 64'h0;
            rtlzz_pipe_622_s3 <= 64'h0;
            rtlzz_pipe_622_s4 <= 64'h0;
            rtlzz_pipe_622_s5 <= 64'h0;
            rtlzz_pipe_622_s6 <= 64'h0;
            rtlzz_pipe_622_s7 <= 64'h0;
            rtlzz_pipe_627_s3 <= 1'h0;
            rtlzz_pipe_627_s4 <= 1'h0;
            rtlzz_pipe_627_s5 <= 1'h0;
            rtlzz_pipe_627_s6 <= 1'h0;
            rtlzz_pipe_627_s7 <= 1'h0;
            rtlzz_pipe_634_s3 <= 64'h0;
            rtlzz_pipe_634_s4 <= 64'h0;
            rtlzz_pipe_636_s5 <= 64'h0;
            rtlzz_pipe_639_s3 <= 64'h0;
            rtlzz_pipe_639_s4 <= 64'h0;
            rtlzz_pipe_641_s5 <= 64'h0;
            rtlzz_pipe_642_s5 <= 1'h0;
            rtlzz_pipe_643_s5 <= 1'h0;
            rtlzz_pipe_644_s3 <= 1'h0;
            rtlzz_pipe_644_s4 <= 1'h0;
            rtlzz_pipe_644_s5 <= 1'h0;
            rtlzz_pipe_650_s6 <= 64'h0;
            rtlzz_pipe_650_s7 <= 64'h0;
            rtlzz_pipe_655_s6 <= 64'h0;
            rtlzz_pipe_655_s7 <= 64'h0;
            rtlzz_pipe_660_s6 <= 1'h0;
            rtlzz_pipe_660_s7 <= 1'h0;
            rtlzz_pipe_667_s3 <= 64'h0;
            rtlzz_pipe_667_s4 <= 64'h0;
            rtlzz_pipe_667_s5 <= 64'h0;
            rtlzz_pipe_667_s6 <= 64'h0;
            rtlzz_pipe_668_s5 <= 64'h0;
            rtlzz_pipe_668_s6 <= 64'h0;
            rtlzz_pipe_672_s3 <= 64'h0;
            rtlzz_pipe_672_s4 <= 64'h0;
            rtlzz_pipe_672_s5 <= 64'h0;
            rtlzz_pipe_672_s6 <= 64'h0;
            rtlzz_pipe_673_s5 <= 64'h0;
            rtlzz_pipe_673_s6 <= 64'h0;
            rtlzz_pipe_677_s3 <= 1'h0;
            rtlzz_pipe_677_s4 <= 1'h0;
            rtlzz_pipe_677_s5 <= 1'h0;
            rtlzz_pipe_677_s6 <= 1'h0;
            rtlzz_pipe_678_s5 <= 1'h0;
            rtlzz_pipe_678_s6 <= 1'h0;
            rtlzz_pipe_684_s7 <= 64'h0;
            rtlzz_pipe_689_s7 <= 64'h0;
            rtlzz_pipe_694_s7 <= 2'h0;
            rtlzz_pipe_702_s6 <= 64'h0;
            rtlzz_pipe_702_s7 <= 64'h0;
            rtlzz_pipe_707_s6 <= 64'h0;
            rtlzz_pipe_707_s7 <= 64'h0;
            rtlzz_pipe_712_s6 <= 2'h0;
            rtlzz_pipe_712_s7 <= 2'h0;
            rtlzz_pipe_719_s6 <= 64'h0;
            rtlzz_pipe_719_s7 <= 64'h0;
            rtlzz_pipe_724_s6 <= 64'h0;
            rtlzz_pipe_724_s7 <= 64'h0;
            rtlzz_pipe_729_s6 <= 2'h0;
            rtlzz_pipe_729_s7 <= 2'h0;
            rtlzz_pipe_736_s7 <= 64'h0;
            rtlzz_pipe_741_s7 <= 64'h0;
            rtlzz_pipe_746_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_100_s2 <= rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= rtlzz_pipe_100_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_101_s2 <= rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_101_s3 <= rtlzz_pipe_101_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_102_s3 <= rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_102_s4 <= rtlzz_pipe_102_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= rtlzz_pipe_102_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_102_s6 <= rtlzz_pipe_102_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_103_s4 <= rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_103_s5 <= rtlzz_pipe_103_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= rtlzz_pipe_103_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_108_s1 <= mul_precision_108; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_108_s2 <= rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_108_s3 <= rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_108_s4 <= rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_108_s5 <= rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_precision_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_109_s4 <= rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_109_s5 <= rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_113_s3 <= rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_114_s1 <= mul_precision_114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= rtlzz_pipe_114_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_114_s3 <= rtlzz_pipe_114_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_114_s4 <= rtlzz_pipe_114_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_114_s5 <= rtlzz_pipe_114_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_114_s6 <= rtlzz_pipe_114_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_115_s1 <= mul_precision_115; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_115_s3 <= rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_115_s4 <= rtlzz_pipe_115_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_115_s5 <= rtlzz_pipe_115_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_115_s6 <= rtlzz_pipe_115_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_118_s2 <= rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_118_s3 <= rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_119_s2 <= rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_119_s3 <= rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_122_s4 <= rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_123_s4 <= rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_124_s6 <= rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_125_s6 <= rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_128_s2 <= rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_128_s3 <= rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_129_s2 <= rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_129_s3 <= rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_130_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= mul_tree_130_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= mul_tree_130_156; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_160_s1 <= mul_tree_130_160; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= mul_tree_130_163; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_166_s2 <= mul_tree_130_166; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_173_s4 <= mul_tree_131_173; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_177_s4 <= mul_tree_131_177; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_181_s4 <= mul_tree_131_181; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_185_s4 <= mul_tree_131_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_188_s5 <= mul_tree_131_188; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_191_s5 <= mul_tree_131_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_213_s7 <= mul_tree_132_213; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_216_s7 <= mul_tree_132_216; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_223_s1 <= mul_tree_133_223; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_227_s1 <= mul_tree_133_227; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_231_s1 <= mul_tree_133_231; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= mul_tree_133_235; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_238_s2 <= mul_tree_133_238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_241_s2 <= mul_tree_133_241; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_248_s4 <= mul_tree_134_248; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_252_s4 <= mul_tree_134_252; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_256_s4 <= mul_tree_134_256; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_260_s4 <= mul_tree_134_260; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_273_s6 <= mul_tree_135_273; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_273_s7 <= rtlzz_pipe_273_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_277_s6 <= mul_tree_135_277; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_277_s7 <= rtlzz_pipe_277_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_281_s6 <= mul_tree_135_281; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_281_s7 <= rtlzz_pipe_281_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_285_s6 <= mul_tree_135_285; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_285_s7 <= rtlzz_pipe_285_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_298_s1 <= mul_tree_136_298; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_302_s1 <= mul_tree_136_302; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_306_s1 <= mul_tree_136_306; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_310_s1 <= mul_tree_136_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_313_s2 <= mul_tree_136_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_316_s2 <= mul_tree_136_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_323_s4 <= mul_tree_137_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_323_s5 <= rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_327_s4 <= mul_tree_137_327; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_327_s5 <= rtlzz_pipe_327_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= mul_tree_137_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_331_s5 <= rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= mul_tree_137_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_335_s5 <= rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_363_s7 <= mul_tree_138_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_366_s7 <= mul_tree_138_366; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_373_s1 <= mul_tree_139_373; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_377_s1 <= mul_tree_139_377; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_381_s1 <= mul_tree_139_381; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_385_s1 <= mul_tree_139_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_388_s2 <= mul_tree_139_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_391_s2 <= mul_tree_139_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_413_s4 <= mul_tree_140_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_416_s4 <= mul_tree_140_416; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_423_s1 <= mul_tree_141_423; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_427_s1 <= mul_tree_141_427; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_431_s1 <= mul_tree_141_431; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_435_s1 <= mul_tree_141_435; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_438_s2 <= mul_tree_141_438; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_441_s2 <= mul_tree_141_441; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_448_s5 <= mul_tree_142_448; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_452_s5 <= mul_tree_142_452; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_456_s5 <= mul_tree_142_456; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_460_s5 <= mul_tree_142_460; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_473_s7 <= mul_tree_143_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_477_s7 <= mul_tree_143_477; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_481_s7 <= mul_tree_143_481; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_485_s7 <= mul_tree_143_485; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_498_s1 <= mul_tree_144_498; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_502_s1 <= mul_tree_144_502; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_506_s1 <= mul_tree_144_506; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_510_s1 <= mul_tree_144_510; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_513_s2 <= mul_tree_144_513; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_516_s2 <= mul_tree_144_516; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_523_s4 <= mul_tree_145_523; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_527_s4 <= mul_tree_145_527; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_531_s4 <= mul_tree_145_531; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_535_s4 <= mul_tree_145_535; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_548_s3 <= limb_49_548; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_548_s4 <= rtlzz_pipe_548_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_548_s5 <= rtlzz_pipe_548_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_548_s6 <= rtlzz_pipe_548_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_549_s6 <= limb_49_549; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_553_s3 <= limb_49_553; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_553_s4 <= rtlzz_pipe_553_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_553_s5 <= rtlzz_pipe_553_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_553_s6 <= rtlzz_pipe_553_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_554_s6 <= limb_49_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_558_s3 <= limb_49_558; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_558_s4 <= rtlzz_pipe_558_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_558_s5 <= rtlzz_pipe_558_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_558_s6 <= rtlzz_pipe_558_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_559_s6 <= limb_49_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_566_s3 <= limb_50_566; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_566_s4 <= rtlzz_pipe_566_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_566_s5 <= rtlzz_pipe_566_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_566_s6 <= rtlzz_pipe_566_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_566_s7 <= rtlzz_pipe_566_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_571_s3 <= limb_50_571; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_571_s4 <= rtlzz_pipe_571_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_571_s5 <= rtlzz_pipe_571_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_571_s6 <= rtlzz_pipe_571_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_571_s7 <= rtlzz_pipe_571_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_576_s3 <= limb_50_576; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_576_s4 <= rtlzz_pipe_576_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_576_s5 <= rtlzz_pipe_576_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_576_s6 <= rtlzz_pipe_576_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_576_s7 <= rtlzz_pipe_576_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_582_s5 <= limb_51_582; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_582_s6 <= rtlzz_pipe_582_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_582_s7 <= rtlzz_pipe_582_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_587_s5 <= limb_51_587; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_587_s6 <= rtlzz_pipe_587_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_587_s7 <= rtlzz_pipe_587_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_592_s5 <= limb_51_592; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_592_s6 <= rtlzz_pipe_592_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_592_s7 <= rtlzz_pipe_592_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_599_s3 <= limb_52_599; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_599_s4 <= rtlzz_pipe_599_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_599_s5 <= rtlzz_pipe_599_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_604_s3 <= limb_52_604; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_604_s4 <= rtlzz_pipe_604_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_604_s5 <= rtlzz_pipe_604_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_609_s3 <= limb_52_609; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_609_s4 <= rtlzz_pipe_609_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_609_s5 <= rtlzz_pipe_609_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_617_s3 <= limb_53_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_617_s4 <= rtlzz_pipe_617_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_617_s5 <= rtlzz_pipe_617_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_617_s6 <= rtlzz_pipe_617_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_617_s7 <= rtlzz_pipe_617_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_622_s3 <= limb_53_622; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_622_s4 <= rtlzz_pipe_622_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_622_s5 <= rtlzz_pipe_622_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_622_s6 <= rtlzz_pipe_622_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_622_s7 <= rtlzz_pipe_622_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_627_s3 <= limb_53_627; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_627_s4 <= rtlzz_pipe_627_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_627_s5 <= rtlzz_pipe_627_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_627_s6 <= rtlzz_pipe_627_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_627_s7 <= rtlzz_pipe_627_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_634_s3 <= limb_54_634; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_634_s4 <= rtlzz_pipe_634_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_636_s5 <= limb_54_636; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_639_s3 <= limb_54_639; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_639_s4 <= rtlzz_pipe_639_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_641_s5 <= limb_54_641; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_642_s5 <= limb_54_642; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_643_s5 <= limb_54_643; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_644_s3 <= limb_54_644; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_644_s4 <= rtlzz_pipe_644_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_644_s5 <= rtlzz_pipe_644_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_650_s6 <= limb_55_650; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_650_s7 <= rtlzz_pipe_650_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_655_s6 <= limb_55_655; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_655_s7 <= rtlzz_pipe_655_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_660_s6 <= limb_55_660; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_660_s7 <= rtlzz_pipe_660_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_667_s3 <= limb_56_667; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_667_s4 <= rtlzz_pipe_667_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_667_s5 <= rtlzz_pipe_667_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_667_s6 <= rtlzz_pipe_667_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_668_s5 <= limb_56_668; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_668_s6 <= rtlzz_pipe_668_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_672_s3 <= limb_56_672; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_672_s4 <= rtlzz_pipe_672_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_672_s5 <= rtlzz_pipe_672_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_672_s6 <= rtlzz_pipe_672_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_673_s5 <= limb_56_673; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_673_s6 <= rtlzz_pipe_673_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_677_s3 <= limb_56_677; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_677_s4 <= rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_677_s5 <= rtlzz_pipe_677_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_677_s6 <= rtlzz_pipe_677_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_678_s5 <= limb_56_678; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_678_s6 <= rtlzz_pipe_678_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_684_s7 <= limb_57_684; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_689_s7 <= limb_57_689; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_694_s7 <= limb_57_694; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_702_s6 <= limb_58_702; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_702_s7 <= rtlzz_pipe_702_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_707_s6 <= limb_58_707; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_707_s7 <= rtlzz_pipe_707_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_712_s6 <= limb_58_712; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_712_s7 <= rtlzz_pipe_712_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_719_s6 <= limb_59_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_719_s7 <= rtlzz_pipe_719_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_724_s6 <= limb_59_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_724_s7 <= rtlzz_pipe_724_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_729_s6 <= limb_59_729; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_729_s7 <= rtlzz_pipe_729_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_736_s7 <= limb_60_736; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_741_s7 <= limb_60_741; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_746_s7 <= limb_60_746; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269_reduce(input wire [63:0] i905, input wire [95:0] i906, input wire [95:0] i907, input wire [127:0] i908, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i905[63], i905[62], i905[61], i905[60], i905[59], i905[58], i905[57], i905[56], i905[55], i905[54], i905[53], i905[52], i905[51], i905[50], i905[49], i905[48], i905[47], i905[46], i905[45], i905[44], i905[43], i905[42], i905[41], i905[40], i905[39], i905[38], i905[37], i905[36], i905[35], i905[34], i905[33], i905[32], i905[31], i905[30], i905[29], i905[28], i905[27], i905[26], i905[25], i905[24], i905[23], i905[22], i905[21], i905[20], i905[19], i905[18], i905[17], i905[16], i905[15], i905[14], i905[13], i905[12], i905[11], i905[10], i905[9], i905[8], i905[7], i905[6], i905[5], i905[4], i905[3], i905[2], i905[1], i905[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i906[95], i906[94], i906[93], i906[92], i906[91], i906[90], i906[89], i906[88], i906[87], i906[86], i906[85], i906[84], i906[83], i906[82], i906[81], i906[80], i906[79], i906[78], i906[77], i906[76], i906[75], i906[74], i906[73], i906[72], i906[71], i906[70], i906[69], i906[68], i906[67], i906[66], i906[65], i906[64], i906[63], i906[62], i906[61], i906[60], i906[59], i906[58], i906[57], i906[56], i906[55], i906[54], i906[53], i906[52], i906[51], i906[50], i906[49], i906[48], i906[47], i906[46], i906[45], i906[44], i906[43], i906[42], i906[41], i906[40], i906[39], i906[38], i906[37], i906[36], i906[35], i906[34], i906[33], i906[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i907[95], i907[94], i907[93], i907[92], i907[91], i907[90], i907[89], i907[88], i907[87], i907[86], i907[85], i907[84], i907[83], i907[82], i907[81], i907[80], i907[79], i907[78], i907[77], i907[76], i907[75], i907[74], i907[73], i907[72], i907[71], i907[70], i907[69], i907[68], i907[67], i907[66], i907[65], i907[64], i907[63], i907[62], i907[61], i907[60], i907[59], i907[58], i907[57], i907[56], i907[55], i907[54], i907[53], i907[52], i907[51], i907[50], i907[49], i907[48], i907[47], i907[46], i907[45], i907[44], i907[43], i907[42], i907[41], i907[40], i907[39], i907[38], i907[37], i907[36], i907[35], i907[34], i907[33], i907[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i908[127], i908[126], i908[125], i908[124], i908[123], i908[122], i908[121], i908[120], i908[119], i908[118], i908[117], i908[116], i908[115], i908[114], i908[113], i908[112], i908[111], i908[110], i908[109], i908[108], i908[107], i908[106], i908[105], i908[104], i908[103], i908[102], i908[101], i908[100], i908[99], i908[98], i908[97], i908[96], i908[95], i908[94], i908[93], i908[92], i908[91], i908[90], i908[89], i908[88], i908[87], i908[86], i908[85], i908[84], i908[83], i908[82], i908[81], i908[80], i908[79], i908[78], i908[77], i908[76], i908[75], i908[74], i908[73], i908[72], i908[71], i908[70], i908[69], i908[68], i908[67], i908[66], i908[65], i908[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294_reduce(input wire [63:0] i910, input wire [95:0] i912, input wire [95:0] i914, input wire [127:0] i916, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i910[63], i910[62], i910[61], i910[60], i910[59], i910[58], i910[57], i910[56], i910[55], i910[54], i910[53], i910[52], i910[51], i910[50], i910[49], i910[48], i910[47], i910[46], i910[45], i910[44], i910[43], i910[42], i910[41], i910[40], i910[39], i910[38], i910[37], i910[36], i910[35], i910[34], i910[33], i910[32], i910[31], i910[30], i910[29], i910[28], i910[27], i910[26], i910[25], i910[24], i910[23], i910[22], i910[21], i910[20], i910[19], i910[18], i910[17], i910[16], i910[15], i910[14], i910[13], i910[12], i910[11], i910[10], i910[9], i910[8], i910[7], i910[6], i910[5], i910[4], i910[3], i910[2], i910[1], i910[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i912[95], i912[94], i912[93], i912[92], i912[91], i912[90], i912[89], i912[88], i912[87], i912[86], i912[85], i912[84], i912[83], i912[82], i912[81], i912[80], i912[79], i912[78], i912[77], i912[76], i912[75], i912[74], i912[73], i912[72], i912[71], i912[70], i912[69], i912[68], i912[67], i912[66], i912[65], i912[64], i912[63], i912[62], i912[61], i912[60], i912[59], i912[58], i912[57], i912[56], i912[55], i912[54], i912[53], i912[52], i912[51], i912[50], i912[49], i912[48], i912[47], i912[46], i912[45], i912[44], i912[43], i912[42], i912[41], i912[40], i912[39], i912[38], i912[37], i912[36], i912[35], i912[34], i912[33], i912[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i914[95], i914[94], i914[93], i914[92], i914[91], i914[90], i914[89], i914[88], i914[87], i914[86], i914[85], i914[84], i914[83], i914[82], i914[81], i914[80], i914[79], i914[78], i914[77], i914[76], i914[75], i914[74], i914[73], i914[72], i914[71], i914[70], i914[69], i914[68], i914[67], i914[66], i914[65], i914[64], i914[63], i914[62], i914[61], i914[60], i914[59], i914[58], i914[57], i914[56], i914[55], i914[54], i914[53], i914[52], i914[51], i914[50], i914[49], i914[48], i914[47], i914[46], i914[45], i914[44], i914[43], i914[42], i914[41], i914[40], i914[39], i914[38], i914[37], i914[36], i914[35], i914[34], i914[33], i914[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i916[127], i916[126], i916[125], i916[124], i916[123], i916[122], i916[121], i916[120], i916[119], i916[118], i916[117], i916[116], i916[115], i916[114], i916[113], i916[112], i916[111], i916[110], i916[109], i916[108], i916[107], i916[106], i916[105], i916[104], i916[103], i916[102], i916[101], i916[100], i916[99], i916[98], i916[97], i916[96], i916[95], i916[94], i916[93], i916[92], i916[91], i916[90], i916[89], i916[88], i916[87], i916[86], i916[85], i916[84], i916[83], i916[82], i916[81], i916[80], i916[79], i916[78], i916[77], i916[76], i916[75], i916[74], i916[73], i916[72], i916[71], i916[70], i916[69], i916[68], i916[67], i916[66], i916[65], i916[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344_reduce(input wire [63:0] i924, input wire [95:0] i926, input wire [95:0] i928, input wire [127:0] i930, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i924[63], i924[62], i924[61], i924[60], i924[59], i924[58], i924[57], i924[56], i924[55], i924[54], i924[53], i924[52], i924[51], i924[50], i924[49], i924[48], i924[47], i924[46], i924[45], i924[44], i924[43], i924[42], i924[41], i924[40], i924[39], i924[38], i924[37], i924[36], i924[35], i924[34], i924[33], i924[32], i924[31], i924[30], i924[29], i924[28], i924[27], i924[26], i924[25], i924[24], i924[23], i924[22], i924[21], i924[20], i924[19], i924[18], i924[17], i924[16], i924[15], i924[14], i924[13], i924[12], i924[11], i924[10], i924[9], i924[8], i924[7], i924[6], i924[5], i924[4], i924[3], i924[2], i924[1], i924[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i926[95], i926[94], i926[93], i926[92], i926[91], i926[90], i926[89], i926[88], i926[87], i926[86], i926[85], i926[84], i926[83], i926[82], i926[81], i926[80], i926[79], i926[78], i926[77], i926[76], i926[75], i926[74], i926[73], i926[72], i926[71], i926[70], i926[69], i926[68], i926[67], i926[66], i926[65], i926[64], i926[63], i926[62], i926[61], i926[60], i926[59], i926[58], i926[57], i926[56], i926[55], i926[54], i926[53], i926[52], i926[51], i926[50], i926[49], i926[48], i926[47], i926[46], i926[45], i926[44], i926[43], i926[42], i926[41], i926[40], i926[39], i926[38], i926[37], i926[36], i926[35], i926[34], i926[33], i926[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i928[95], i928[94], i928[93], i928[92], i928[91], i928[90], i928[89], i928[88], i928[87], i928[86], i928[85], i928[84], i928[83], i928[82], i928[81], i928[80], i928[79], i928[78], i928[77], i928[76], i928[75], i928[74], i928[73], i928[72], i928[71], i928[70], i928[69], i928[68], i928[67], i928[66], i928[65], i928[64], i928[63], i928[62], i928[61], i928[60], i928[59], i928[58], i928[57], i928[56], i928[55], i928[54], i928[53], i928[52], i928[51], i928[50], i928[49], i928[48], i928[47], i928[46], i928[45], i928[44], i928[43], i928[42], i928[41], i928[40], i928[39], i928[38], i928[37], i928[36], i928[35], i928[34], i928[33], i928[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i930[127], i930[126], i930[125], i930[124], i930[123], i930[122], i930[121], i930[120], i930[119], i930[118], i930[117], i930[116], i930[115], i930[114], i930[113], i930[112], i930[111], i930[110], i930[109], i930[108], i930[107], i930[106], i930[105], i930[104], i930[103], i930[102], i930[101], i930[100], i930[99], i930[98], i930[97], i930[96], i930[95], i930[94], i930[93], i930[92], i930[91], i930[90], i930[89], i930[88], i930[87], i930[86], i930[85], i930[84], i930[83], i930[82], i930[81], i930[80], i930[79], i930[78], i930[77], i930[76], i930[75], i930[74], i930[73], i930[72], i930[71], i930[70], i930[69], i930[68], i930[67], i930[66], i930[65], i930[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_469_reduce(input wire [63:0] i947, input wire [95:0] i948, input wire [95:0] i949, input wire [127:0] i950, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i947[63], i947[62], i947[61], i947[60], i947[59], i947[58], i947[57], i947[56], i947[55], i947[54], i947[53], i947[52], i947[51], i947[50], i947[49], i947[48], i947[47], i947[46], i947[45], i947[44], i947[43], i947[42], i947[41], i947[40], i947[39], i947[38], i947[37], i947[36], i947[35], i947[34], i947[33], i947[32], i947[31], i947[30], i947[29], i947[28], i947[27], i947[26], i947[25], i947[24], i947[23], i947[22], i947[21], i947[20], i947[19], i947[18], i947[17], i947[16], i947[15], i947[14], i947[13], i947[12], i947[11], i947[10], i947[9], i947[8], i947[7], i947[6], i947[5], i947[4], i947[3], i947[2], i947[1], i947[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i948[95], i948[94], i948[93], i948[92], i948[91], i948[90], i948[89], i948[88], i948[87], i948[86], i948[85], i948[84], i948[83], i948[82], i948[81], i948[80], i948[79], i948[78], i948[77], i948[76], i948[75], i948[74], i948[73], i948[72], i948[71], i948[70], i948[69], i948[68], i948[67], i948[66], i948[65], i948[64], i948[63], i948[62], i948[61], i948[60], i948[59], i948[58], i948[57], i948[56], i948[55], i948[54], i948[53], i948[52], i948[51], i948[50], i948[49], i948[48], i948[47], i948[46], i948[45], i948[44], i948[43], i948[42], i948[41], i948[40], i948[39], i948[38], i948[37], i948[36], i948[35], i948[34], i948[33], i948[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i949[95], i949[94], i949[93], i949[92], i949[91], i949[90], i949[89], i949[88], i949[87], i949[86], i949[85], i949[84], i949[83], i949[82], i949[81], i949[80], i949[79], i949[78], i949[77], i949[76], i949[75], i949[74], i949[73], i949[72], i949[71], i949[70], i949[69], i949[68], i949[67], i949[66], i949[65], i949[64], i949[63], i949[62], i949[61], i949[60], i949[59], i949[58], i949[57], i949[56], i949[55], i949[54], i949[53], i949[52], i949[51], i949[50], i949[49], i949[48], i949[47], i949[46], i949[45], i949[44], i949[43], i949[42], i949[41], i949[40], i949[39], i949[38], i949[37], i949[36], i949[35], i949[34], i949[33], i949[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i950[127], i950[126], i950[125], i950[124], i950[123], i950[122], i950[121], i950[120], i950[119], i950[118], i950[117], i950[116], i950[115], i950[114], i950[113], i950[112], i950[111], i950[110], i950[109], i950[108], i950[107], i950[106], i950[105], i950[104], i950[103], i950[102], i950[101], i950[100], i950[99], i950[98], i950[97], i950[96], i950[95], i950[94], i950[93], i950[92], i950[91], i950[90], i950[89], i950[88], i950[87], i950[86], i950[85], i950[84], i950[83], i950[82], i950[81], i950[80], i950[79], i950[78], i950[77], i950[76], i950[75], i950[74], i950[73], i950[72], i950[71], i950[70], i950[69], i950[68], i950[67], i950[66], i950[65], i950[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_494_reduce(input wire [63:0] i951, input wire [95:0] i952, input wire [95:0] i953, input wire [127:0] i954, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i951[63], i951[62], i951[61], i951[60], i951[59], i951[58], i951[57], i951[56], i951[55], i951[54], i951[53], i951[52], i951[51], i951[50], i951[49], i951[48], i951[47], i951[46], i951[45], i951[44], i951[43], i951[42], i951[41], i951[40], i951[39], i951[38], i951[37], i951[36], i951[35], i951[34], i951[33], i951[32], i951[31], i951[30], i951[29], i951[28], i951[27], i951[26], i951[25], i951[24], i951[23], i951[22], i951[21], i951[20], i951[19], i951[18], i951[17], i951[16], i951[15], i951[14], i951[13], i951[12], i951[11], i951[10], i951[9], i951[8], i951[7], i951[6], i951[5], i951[4], i951[3], i951[2], i951[1], i951[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i952[95], i952[94], i952[93], i952[92], i952[91], i952[90], i952[89], i952[88], i952[87], i952[86], i952[85], i952[84], i952[83], i952[82], i952[81], i952[80], i952[79], i952[78], i952[77], i952[76], i952[75], i952[74], i952[73], i952[72], i952[71], i952[70], i952[69], i952[68], i952[67], i952[66], i952[65], i952[64], i952[63], i952[62], i952[61], i952[60], i952[59], i952[58], i952[57], i952[56], i952[55], i952[54], i952[53], i952[52], i952[51], i952[50], i952[49], i952[48], i952[47], i952[46], i952[45], i952[44], i952[43], i952[42], i952[41], i952[40], i952[39], i952[38], i952[37], i952[36], i952[35], i952[34], i952[33], i952[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i953[95], i953[94], i953[93], i953[92], i953[91], i953[90], i953[89], i953[88], i953[87], i953[86], i953[85], i953[84], i953[83], i953[82], i953[81], i953[80], i953[79], i953[78], i953[77], i953[76], i953[75], i953[74], i953[73], i953[72], i953[71], i953[70], i953[69], i953[68], i953[67], i953[66], i953[65], i953[64], i953[63], i953[62], i953[61], i953[60], i953[59], i953[58], i953[57], i953[56], i953[55], i953[54], i953[53], i953[52], i953[51], i953[50], i953[49], i953[48], i953[47], i953[46], i953[45], i953[44], i953[43], i953[42], i953[41], i953[40], i953[39], i953[38], i953[37], i953[36], i953[35], i953[34], i953[33], i953[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i954[127], i954[126], i954[125], i954[124], i954[123], i954[122], i954[121], i954[120], i954[119], i954[118], i954[117], i954[116], i954[115], i954[114], i954[113], i954[112], i954[111], i954[110], i954[109], i954[108], i954[107], i954[106], i954[105], i954[104], i954[103], i954[102], i954[101], i954[100], i954[99], i954[98], i954[97], i954[96], i954[95], i954[94], i954[93], i954[92], i954[91], i954[90], i954[89], i954[88], i954[87], i954[86], i954[85], i954[84], i954[83], i954[82], i954[81], i954[80], i954[79], i954[78], i954[77], i954[76], i954[75], i954[74], i954[73], i954[72], i954[71], i954[70], i954[69], i954[68], i954[67], i954[66], i954[65], i954[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_544_reduce(input wire [63:0] i961, input wire [95:0] i962, input wire [95:0] i963, input wire [127:0] i964, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i961[63], i961[62], i961[61], i961[60], i961[59], i961[58], i961[57], i961[56], i961[55], i961[54], i961[53], i961[52], i961[51], i961[50], i961[49], i961[48], i961[47], i961[46], i961[45], i961[44], i961[43], i961[42], i961[41], i961[40], i961[39], i961[38], i961[37], i961[36], i961[35], i961[34], i961[33], i961[32], i961[31], i961[30], i961[29], i961[28], i961[27], i961[26], i961[25], i961[24], i961[23], i961[22], i961[21], i961[20], i961[19], i961[18], i961[17], i961[16], i961[15], i961[14], i961[13], i961[12], i961[11], i961[10], i961[9], i961[8], i961[7], i961[6], i961[5], i961[4], i961[3], i961[2], i961[1], i961[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i962[95], i962[94], i962[93], i962[92], i962[91], i962[90], i962[89], i962[88], i962[87], i962[86], i962[85], i962[84], i962[83], i962[82], i962[81], i962[80], i962[79], i962[78], i962[77], i962[76], i962[75], i962[74], i962[73], i962[72], i962[71], i962[70], i962[69], i962[68], i962[67], i962[66], i962[65], i962[64], i962[63], i962[62], i962[61], i962[60], i962[59], i962[58], i962[57], i962[56], i962[55], i962[54], i962[53], i962[52], i962[51], i962[50], i962[49], i962[48], i962[47], i962[46], i962[45], i962[44], i962[43], i962[42], i962[41], i962[40], i962[39], i962[38], i962[37], i962[36], i962[35], i962[34], i962[33], i962[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i963[95], i963[94], i963[93], i963[92], i963[91], i963[90], i963[89], i963[88], i963[87], i963[86], i963[85], i963[84], i963[83], i963[82], i963[81], i963[80], i963[79], i963[78], i963[77], i963[76], i963[75], i963[74], i963[73], i963[72], i963[71], i963[70], i963[69], i963[68], i963[67], i963[66], i963[65], i963[64], i963[63], i963[62], i963[61], i963[60], i963[59], i963[58], i963[57], i963[56], i963[55], i963[54], i963[53], i963[52], i963[51], i963[50], i963[49], i963[48], i963[47], i963[46], i963[45], i963[44], i963[43], i963[42], i963[41], i963[40], i963[39], i963[38], i963[37], i963[36], i963[35], i963[34], i963[33], i963[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i964[127], i964[126], i964[125], i964[124], i964[123], i964[122], i964[121], i964[120], i964[119], i964[118], i964[117], i964[116], i964[115], i964[114], i964[113], i964[112], i964[111], i964[110], i964[109], i964[108], i964[107], i964[106], i964[105], i964[104], i964[103], i964[102], i964[101], i964[100], i964[99], i964[98], i964[97], i964[96], i964[95], i964[94], i964[93], i964[92], i964[91], i964[90], i964[89], i964[88], i964[87], i964[86], i964[85], i964[84], i964[83], i964[82], i964[81], i964[80], i964[79], i964[78], i964[77], i964[76], i964[75], i964[74], i964[73], i964[72], i964[71], i964[70], i964[69], i964[68], i964[67], i964[66], i964[65], i964[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_148();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_151();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_163();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_169();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_173();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_176();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_188();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_191();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_205();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_209();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_213();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_216();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_241();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_248();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_251();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_255();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_259();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_298();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_301();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_316();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_323();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_326();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_391();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_401();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_416();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_434();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_438();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_441();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_448();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_459();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_480();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_484();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_498();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_509();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_516();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_519();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_530();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_534();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_555Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_555();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_560Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_560();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_567Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_567();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_572();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_584Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_584();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_594Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_594();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_601Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_601();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_606Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_606();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_611Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_611();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_618Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_618();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_623Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_623();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_635Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_635();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_640Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_640();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_645Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_645();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_652Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_652();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_662Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_662();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_669Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_669();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_686Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_686();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_691Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_691();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_708Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_708();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_713Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_713();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_720Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_720();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_725Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_725();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_730Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_730();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_737Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_737();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_747Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_747();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_759Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_759();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_764Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_764();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_771Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_771();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_776Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_776();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_781Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_781();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_788Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_788();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_793Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_793();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_798Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h7)|4'h0);
wire [3:0] masked_b=((b&4'h7)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_798();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
