`timescale 1ns/1ps

module WorkloadCore(
    input logic [511:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [511:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [512:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:35; prim: /home/zyrv/vulsim/workload.cpp:13:24-13:35
    logic [512:0] limb_3_6; // decl: <none>; prim: <none>
    logic [512:0] limb_3_7; // decl: <none>; prim: <none>
    logic [127:0] limb_3_8; // decl: <none>; prim: <none>
    logic [127:0] limb_3_9; // decl: <none>; prim: <none>
    logic [128:0] limb_3_10; // decl: <none>; prim: <none>
    logic [127:0] limb_3_11; // decl: <none>; prim: <none>
    logic limb_3_12; // decl: <none>; prim: <none>
    logic [127:0] limb_3_13; // decl: <none>; prim: <none>
    logic [127:0] limb_3_14; // decl: <none>; prim: <none>
    logic [128:0] limb_3_15; // decl: <none>; prim: <none>
    logic [127:0] limb_3_16; // decl: <none>; prim: <none>
    logic limb_3_17; // decl: <none>; prim: <none>
    logic [127:0] limb_3_18; // decl: <none>; prim: <none>
    logic [127:0] limb_3_19; // decl: <none>; prim: <none>
    logic [128:0] limb_3_20; // decl: <none>; prim: <none>
    logic [127:0] limb_3_21; // decl: <none>; prim: <none>
    logic limb_3_22; // decl: <none>; prim: <none>
    logic [127:0] limb_3_23; // decl: <none>; prim: <none>
    logic [127:0] limb_3_24; // decl: <none>; prim: <none>
    logic [128:0] limb_3_25; // decl: <none>; prim: <none>
    logic [127:0] limb_3_26; // decl: <none>; prim: <none>
    logic limb_3_27; // decl: <none>; prim: <none>
    logic limb_3_28; // decl: <none>; prim: <none>
    logic limb_3_29; // decl: <none>; prim: <none>
    logic [1:0] limb_3_30; // decl: <none>; prim: <none>
    logic limb_3_31; // decl: <none>; prim: <none>
    logic [512:0] limb_3_32; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_11_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_11_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_11_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_16_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_17_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_21_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_22_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_23_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_28_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_28_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_29_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_29_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_add_2_v0 = limb_3_32; // decl: <none>; prim: <none>
    assign y = s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign limb_3_6 = ({1'h0, a}); // decl: <none>; prim: <none>
    assign limb_3_7 = ({1'h0, b}); // decl: <none>; prim: <none>
    assign limb_3_8 = limb_3_6[127:0]; // decl: <none>; prim: <none>
    assign limb_3_9 = limb_3_7[127:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_10Core rtlzz_owner_10(.a(128'(limb_3_8)), .b(128'(limb_3_9)), .cin(1'h0), .value(limb_3_10));
    assign limb_3_11 = limb_3_10[127:0]; // decl: <none>; prim: <none>
    assign limb_3_12 = limb_3_10[128]; // decl: <none>; prim: <none>
    assign limb_3_13 = limb_3_6[255:128]; // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_7[255:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(128'(rtlzz_pipe_13_s1)), .b(128'(rtlzz_pipe_14_s1)), .cin(rtlzz_pipe_12_s1), .value(limb_3_15));
    assign limb_3_16 = limb_3_15[127:0]; // decl: <none>; prim: <none>
    assign limb_3_17 = limb_3_15[128]; // decl: <none>; prim: <none>
    assign limb_3_18 = limb_3_6[383:256]; // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_7[383:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_20Core rtlzz_owner_20(.a(128'(rtlzz_pipe_18_s2)), .b(128'(rtlzz_pipe_19_s2)), .cin(rtlzz_pipe_17_s2), .value(limb_3_20));
    assign limb_3_21 = limb_3_20[127:0]; // decl: <none>; prim: <none>
    assign limb_3_22 = limb_3_20[128]; // decl: <none>; prim: <none>
    assign limb_3_23 = limb_3_6[511:384]; // decl: <none>; prim: <none>
    assign limb_3_24 = limb_3_7[511:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_25Core rtlzz_owner_25(.a(128'(rtlzz_pipe_23_s3)), .b(128'(rtlzz_pipe_24_s3)), .cin(rtlzz_pipe_22_s3), .value(limb_3_25));
    assign limb_3_26 = limb_3_25[127:0]; // decl: <none>; prim: <none>
    assign limb_3_27 = limb_3_25[128]; // decl: <none>; prim: <none>
    assign limb_3_28 = limb_3_6[512]; // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_7[512]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(1'(rtlzz_pipe_28_s3)), .b(1'(rtlzz_pipe_29_s3)), .cin(limb_3_27), .value(limb_3_30[0:0]));
    assign limb_3_30[1:1] = '0;
    assign limb_3_31 = limb_3_30[0]; // decl: <none>; prim: <none>
    assign limb_3_32 = {limb_3_31, limb_3_26, rtlzz_pipe_21_s3, rtlzz_pipe_16_s3, rtlzz_pipe_11_s3}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_11_s1 <= 128'h0;
            rtlzz_pipe_11_s2 <= 128'h0;
            rtlzz_pipe_11_s3 <= 128'h0;
            rtlzz_pipe_12_s1 <= 1'h0;
            rtlzz_pipe_13_s1 <= 128'h0;
            rtlzz_pipe_14_s1 <= 128'h0;
            rtlzz_pipe_16_s2 <= 128'h0;
            rtlzz_pipe_16_s3 <= 128'h0;
            rtlzz_pipe_17_s2 <= 1'h0;
            rtlzz_pipe_18_s1 <= 128'h0;
            rtlzz_pipe_18_s2 <= 128'h0;
            rtlzz_pipe_19_s1 <= 128'h0;
            rtlzz_pipe_19_s2 <= 128'h0;
            rtlzz_pipe_21_s3 <= 128'h0;
            rtlzz_pipe_22_s3 <= 1'h0;
            rtlzz_pipe_23_s1 <= 128'h0;
            rtlzz_pipe_23_s2 <= 128'h0;
            rtlzz_pipe_23_s3 <= 128'h0;
            rtlzz_pipe_24_s1 <= 128'h0;
            rtlzz_pipe_24_s2 <= 128'h0;
            rtlzz_pipe_24_s3 <= 128'h0;
            rtlzz_pipe_28_s1 <= 1'h0;
            rtlzz_pipe_28_s2 <= 1'h0;
            rtlzz_pipe_28_s3 <= 1'h0;
            rtlzz_pipe_29_s1 <= 1'h0;
            rtlzz_pipe_29_s2 <= 1'h0;
            rtlzz_pipe_29_s3 <= 1'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_11_s1 <= limb_3_11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= rtlzz_pipe_11_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_11_s3 <= rtlzz_pipe_11_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_12_s1 <= limb_3_12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_13_s1 <= limb_3_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_16_s2 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_16_s3 <= rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_17_s2 <= limb_3_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= limb_3_18; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_18_s2 <= rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_21_s3 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_22_s3 <= limb_3_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= limb_3_23; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_23_s2 <= rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= rtlzz_pipe_23_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_24_s1 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_28_s1 <= limb_3_28; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_28_s2 <= rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_28_s3 <= rtlzz_pipe_28_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= limb_3_29; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_29_s2 <= rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_29_s3 <= rtlzz_pipe_29_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(cin);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(cin);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_20();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [128:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(cin);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_25();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [511:0] a_data,input wire a_wen,input wire [511:0] b_data,input wire b_wen,output reg [512:0] y);
reg liv;wire cov;
reg [511:0] l_a;
reg [511:0] l_b;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;l_b<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
