`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [3:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_122; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_123; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_124; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_125; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_126; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_127; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_128; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_129; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_130; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_131; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_132; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_133; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_134; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_135; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_136; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_137; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_138; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_139; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_140; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_141; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_142; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_143; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_144; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_145; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_146; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_147; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_148; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_149; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_150; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_151; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_152; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_153; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_154; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_155; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_156; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_157; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_158; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_159; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_160; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_161; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_162; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_163; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_164; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_165; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_166; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_167; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_168; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_169; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_170; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_171; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_172; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_173; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_174; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_175; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_176; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_177; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_179; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_180; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_181; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_182; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_183; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_184; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_185; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_186; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_187; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_188; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_189; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_190; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_191; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_192; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_193; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_194; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_195; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_196; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_197; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_198; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_199; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_200; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_201; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_202; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_203; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_204; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_205; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_207; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_208; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_209; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_210; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_211; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_212; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_213; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_214; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_215; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_216; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_217; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_218; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_219; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_220; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_221; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_222; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_223; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_224; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_225; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_226; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_227; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_228; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_229; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_230; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_231; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_232; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_233; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_234; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_235; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_236; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_237; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_238; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_239; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_240; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_241; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_242; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_243; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_244; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_245; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_246; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_247; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_248; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_249; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_250; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_251; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_252; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_253; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_254; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_255; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_256; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_257; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_258; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_259; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_260; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_261; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_262; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_263; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_264; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_265; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_266; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_267; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_268; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_269; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_270; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_271; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_272; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_273; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_274; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_275; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_276; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_277; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_278; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_279; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_280; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_281; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_282; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_283; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_284; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_285; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_286; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_287; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_288; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_289; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_290; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_291; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_292; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_293; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_294; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_295; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_296; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_297; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_298; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_299; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_300; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_301; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_302; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_303; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_304; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_305; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_306; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_307; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_308; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_309; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_310; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_311; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_312; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_313; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_314; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_315; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_316; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_317; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_318; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_319; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_320; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_321; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_322; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_323; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_324; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_325; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_326; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_327; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_328; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_329; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_330; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_331; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_332; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_333; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_334; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_335; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_336; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_337; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_338; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_339; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_340; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_341; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_342; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_343; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_344; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_345; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_346; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_347; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_348; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_349; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_350; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_351; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_352; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_353; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_354; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_355; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_356; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_357; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_358; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_359; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_360; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_361; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_362; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_363; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_364; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_365; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_366; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_367; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_368; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_369; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_370; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_371; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_372; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_373; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_374; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_375; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_376; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_377; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_378; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_379; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_380; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_381; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_382; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_383; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_384; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_385; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_386; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_387; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_388; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_389; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_390; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_391; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_392; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_393; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_394; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_395; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_396; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_397; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_398; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_399; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_400; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_401; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_402; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_403; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_404; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_405; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_406; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_407; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_408; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_409; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_410; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_411; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_412; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_413; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_414; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_415; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_416; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_417; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_418; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_419; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_420; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_421; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_422; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_423; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_424; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_425; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_426; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_427; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_428; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_429; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_430; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_431; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_432; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_433; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_434; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_435; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_436; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_437; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_438; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_439; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_440; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_441; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_442; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_443; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_444; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_445; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_446; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_447; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_448; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_449; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_450; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_451; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_452; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_453; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_454; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_455; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_456; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_457; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [12:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_276_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_282_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_285_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_288_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_291_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_294_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_297_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_300_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_303_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_306_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_309_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_312_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_315_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_318_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_321_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_324_s1; // decl: <none>; prim: <none>
    logic [52:0] rtlzz_pipe_327_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_330_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_333_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_336_s1; // decl: <none>; prim: <none>
    logic [56:0] rtlzz_pipe_339_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_342_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_345_s1; // decl: <none>; prim: <none>
    logic [52:0] rtlzz_pipe_348_s1; // decl: <none>; prim: <none>
    logic [60:0] rtlzz_pipe_351_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_354_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_357_s1; // decl: <none>; prim: <none>
    logic [56:0] rtlzz_pipe_360_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_363_s1; // decl: <none>; prim: <none>
    logic [38:0] rtlzz_pipe_414_s2; // decl: <none>; prim: <none>
    logic [42:0] rtlzz_pipe_417_s2; // decl: <none>; prim: <none>
    logic [46:0] rtlzz_pipe_420_s2; // decl: <none>; prim: <none>
    logic [50:0] rtlzz_pipe_423_s2; // decl: <none>; prim: <none>
    logic [54:0] rtlzz_pipe_426_s2; // decl: <none>; prim: <none>
    logic [58:0] rtlzz_pipe_429_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_432_s2; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5_reduce rtlzz_reduce_5(.i459(rtlzz_pipe_2_s2), .i492(rtlzz_pipe_414_s2), .i493(rtlzz_pipe_417_s2), .i494(rtlzz_pipe_420_s2), .i495(rtlzz_pipe_423_s2), .i496(rtlzz_pipe_426_s2), .i497(rtlzz_pipe_429_s2), .i498(rtlzz_pipe_432_s2), .i499(rtlzz_pipe_435_s2), .y(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_457; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(4'(mul_tree_12_13)), .b(4'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(4'(mul_tree_12_16)), .b(4'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(4'(mul_tree_12_20)), .b(4'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(4'(mul_tree_12_24)), .b(4'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(4'(mul_tree_12_28)), .b(4'(mul_tree_12_29)), .cin(1'b0), .value(mul_tree_12_30));
    assign mul_tree_12_31 = {mul_tree_12_30, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(4'(mul_tree_12_32)), .b(4'(mul_tree_12_33)), .cin(1'b0), .value(mul_tree_12_34));
    assign mul_tree_12_35 = {mul_tree_12_34, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(4'(mul_tree_12_36)), .b(4'(mul_tree_12_37)), .cin(1'b0), .value(mul_tree_12_38));
    assign mul_tree_12_39 = {mul_tree_12_38, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(4'(mul_tree_12_40)), .b(4'(mul_tree_12_41)), .cin(1'b0), .value(mul_tree_12_42));
    assign mul_tree_12_43 = {mul_tree_12_42, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_46Core rtlzz_owner_46(.a(4'(mul_tree_12_44)), .b(4'(mul_tree_12_45)), .cin(1'b0), .value(mul_tree_12_46));
    assign mul_tree_12_47 = {mul_tree_12_46, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(4'(mul_tree_12_48)), .b(4'(mul_tree_12_49)), .cin(1'b0), .value(mul_tree_12_50));
    assign mul_tree_12_51 = {mul_tree_12_50, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(4'(mul_tree_12_52)), .b(4'(mul_tree_12_53)), .cin(1'b0), .value(mul_tree_12_54));
    assign mul_tree_12_55 = {mul_tree_12_54, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(4'(mul_tree_12_56)), .b(4'(mul_tree_12_57)), .cin(1'b0), .value(mul_tree_12_58));
    assign mul_tree_12_59 = {mul_tree_12_58, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_62Core rtlzz_owner_62(.a(4'(mul_tree_12_60)), .b(4'(mul_tree_12_61)), .cin(1'b0), .value(mul_tree_12_62));
    assign mul_tree_12_63 = {mul_tree_12_62, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_66Core rtlzz_owner_66(.a(4'(mul_tree_12_64)), .b(4'(mul_tree_12_65)), .cin(1'b0), .value(mul_tree_12_66));
    assign mul_tree_12_67 = {mul_tree_12_66, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(4'(mul_tree_12_68)), .b(4'(mul_tree_12_69)), .cin(1'b0), .value(mul_tree_12_70));
    assign mul_tree_12_71 = {mul_tree_12_70, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(4'(mul_tree_12_72)), .b(4'(mul_tree_12_73)), .cin(1'b0), .value(mul_tree_12_74));
    assign mul_tree_12_75 = {mul_tree_12_74, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_77 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(4'(mul_tree_12_76)), .b(4'(mul_tree_12_77)), .cin(1'b0), .value(mul_tree_12_78));
    assign mul_tree_12_79 = {mul_tree_12_78, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_80 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_81 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(4'(mul_tree_12_80)), .b(4'(mul_tree_12_81)), .cin(1'b0), .value(mul_tree_12_82));
    assign mul_tree_12_83 = {mul_tree_12_82, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_84 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_85 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(4'(mul_tree_12_84)), .b(4'(mul_tree_12_85)), .cin(1'b0), .value(mul_tree_12_86));
    assign mul_tree_12_87 = {mul_tree_12_86, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_88 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_89 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(4'(mul_tree_12_88)), .b(4'(mul_tree_12_89)), .cin(1'b0), .value(mul_tree_12_90));
    assign mul_tree_12_91 = {mul_tree_12_90, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_92 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_93 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(4'(mul_tree_12_92)), .b(4'(mul_tree_12_93)), .cin(1'b0), .value(mul_tree_12_94));
    assign mul_tree_12_95 = {mul_tree_12_94, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_96 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_97 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(4'(mul_tree_12_96)), .b(4'(mul_tree_12_97)), .cin(1'b0), .value(mul_tree_12_98));
    assign mul_tree_12_99 = {mul_tree_12_98, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_100 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_101 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(4'(mul_tree_12_100)), .b(4'(mul_tree_12_101)), .cin(1'b0), .value(mul_tree_12_102));
    assign mul_tree_12_103 = {mul_tree_12_102, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_104 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_105 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(4'(mul_tree_12_104)), .b(4'(mul_tree_12_105)), .cin(1'b0), .value(mul_tree_12_106));
    assign mul_tree_12_107 = {mul_tree_12_106, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_108 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_109 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(4'(mul_tree_12_108)), .b(4'(mul_tree_12_109)), .cin(1'b0), .value(mul_tree_12_110));
    assign mul_tree_12_111 = {mul_tree_12_110, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_112 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_113 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(4'(mul_tree_12_112)), .b(4'(mul_tree_12_113)), .cin(1'b0), .value(mul_tree_12_114));
    assign mul_tree_12_115 = {mul_tree_12_114, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_116 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_117 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(4'(mul_tree_12_116)), .b(4'(mul_tree_12_117)), .cin(1'b0), .value(mul_tree_12_118));
    assign mul_tree_12_119 = {mul_tree_12_118, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_120 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_122Core rtlzz_owner_122(.a(4'(mul_tree_12_120)), .b(4'(mul_tree_12_121)), .cin(1'b0), .value(mul_tree_12_122));
    assign mul_tree_12_123 = {mul_tree_12_122, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_124 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_125 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(4'(mul_tree_12_124)), .b(4'(mul_tree_12_125)), .cin(1'b0), .value(mul_tree_12_126));
    assign mul_tree_12_127 = {mul_tree_12_126, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_128 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_129 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(4'(mul_tree_12_128)), .b(4'(mul_tree_12_129)), .cin(1'b0), .value(mul_tree_12_130));
    assign mul_tree_12_131 = {mul_tree_12_130, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_132 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_133 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(4'(mul_tree_12_132)), .b(4'(mul_tree_12_133)), .cin(1'b0), .value(mul_tree_12_134));
    assign mul_tree_12_135 = {mul_tree_12_134, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_136 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_137 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(4'(mul_tree_12_136)), .b(4'(mul_tree_12_137)), .cin(1'b0), .value(mul_tree_12_138));
    assign mul_tree_12_139 = {mul_tree_12_138, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_140 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_141 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(4'(mul_tree_12_140)), .b(4'(mul_tree_12_141)), .cin(1'b0), .value(mul_tree_12_142));
    assign mul_tree_12_143 = {mul_tree_12_142, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_144 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_145 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_146Core rtlzz_owner_146(.a(4'(mul_tree_12_144)), .b(4'(mul_tree_12_145)), .cin(1'b0), .value(mul_tree_12_146));
    assign mul_tree_12_147 = {mul_tree_12_146, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_148 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_149 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_150Core rtlzz_owner_150(.a(4'(mul_tree_12_148)), .b(4'(mul_tree_12_149)), .cin(1'b0), .value(mul_tree_12_150));
    assign mul_tree_12_151 = {mul_tree_12_150, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_152 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_153 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(4'(mul_tree_12_152)), .b(4'(mul_tree_12_153)), .cin(1'b0), .value(mul_tree_12_154));
    assign mul_tree_12_155 = {mul_tree_12_154, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_156 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_157 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_158Core rtlzz_owner_158(.a(4'(mul_tree_12_156)), .b(4'(mul_tree_12_157)), .cin(1'b0), .value(mul_tree_12_158));
    assign mul_tree_12_159 = {mul_tree_12_158, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_160 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_161 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_162Core rtlzz_owner_162(.a(4'(mul_tree_12_160)), .b(4'(mul_tree_12_161)), .cin(1'b0), .value(mul_tree_12_162));
    assign mul_tree_12_163 = {mul_tree_12_162, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_164 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_165 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(4'(mul_tree_12_164)), .b(4'(mul_tree_12_165)), .cin(1'b0), .value(mul_tree_12_166));
    assign mul_tree_12_167 = {mul_tree_12_166, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_168 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_169 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(4'(mul_tree_12_168)), .b(4'(mul_tree_12_169)), .cin(1'b0), .value(mul_tree_12_170));
    assign mul_tree_12_171 = {mul_tree_12_170, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_172 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_173 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(4'(mul_tree_12_172)), .b(4'(mul_tree_12_173)), .cin(1'b0), .value(mul_tree_12_174));
    assign mul_tree_12_175 = {mul_tree_12_174, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_176 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_177 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_178Core rtlzz_owner_178(.a(4'(mul_tree_12_176)), .b(4'(mul_tree_12_177)), .cin(1'b0), .value(mul_tree_12_178));
    assign mul_tree_12_179 = {mul_tree_12_178, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_180 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_181 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_182Core rtlzz_owner_182(.a(4'(mul_tree_12_180)), .b(4'(mul_tree_12_181)), .cin(1'b0), .value(mul_tree_12_182));
    assign mul_tree_12_183 = {mul_tree_12_182, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_184 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_185 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_186Core rtlzz_owner_186(.a(4'(mul_tree_12_184)), .b(4'(mul_tree_12_185)), .cin(1'b0), .value(mul_tree_12_186));
    assign mul_tree_12_187 = {mul_tree_12_186, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_188 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_189 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_190Core rtlzz_owner_190(.a(4'(mul_tree_12_188)), .b(4'(mul_tree_12_189)), .cin(1'b0), .value(mul_tree_12_190));
    assign mul_tree_12_191 = {mul_tree_12_190, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_192 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_193 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(4'(mul_tree_12_192)), .b(4'(mul_tree_12_193)), .cin(1'b0), .value(mul_tree_12_194));
    assign mul_tree_12_195 = {mul_tree_12_194, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_196 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_197 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(4'(mul_tree_12_196)), .b(4'(mul_tree_12_197)), .cin(1'b0), .value(mul_tree_12_198));
    assign mul_tree_12_199 = {mul_tree_12_198, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_200 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_201 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_202Core rtlzz_owner_202(.a(4'(mul_tree_12_200)), .b(4'(mul_tree_12_201)), .cin(1'b0), .value(mul_tree_12_202));
    assign mul_tree_12_203 = {mul_tree_12_202, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_204 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_205 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(4'(mul_tree_12_204)), .b(4'(mul_tree_12_205)), .cin(1'b0), .value(mul_tree_12_206));
    assign mul_tree_12_207 = {mul_tree_12_206, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_208 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_209 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_210Core rtlzz_owner_210(.a(4'(mul_tree_12_208)), .b(4'(mul_tree_12_209)), .cin(1'b0), .value(mul_tree_12_210));
    assign mul_tree_12_211 = {mul_tree_12_210, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_212 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_213 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_214Core rtlzz_owner_214(.a(4'(mul_tree_12_212)), .b(4'(mul_tree_12_213)), .cin(1'b0), .value(mul_tree_12_214));
    assign mul_tree_12_215 = {mul_tree_12_214, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_216 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_217 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(4'(mul_tree_12_216)), .b(4'(mul_tree_12_217)), .cin(1'b0), .value(mul_tree_12_218));
    assign mul_tree_12_219 = {mul_tree_12_218, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_220 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_221 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_222Core rtlzz_owner_222(.a(4'(mul_tree_12_220)), .b(4'(mul_tree_12_221)), .cin(1'b0), .value(mul_tree_12_222));
    assign mul_tree_12_223 = {mul_tree_12_222, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_224 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_225 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(4'(mul_tree_12_224)), .b(4'(mul_tree_12_225)), .cin(1'b0), .value(mul_tree_12_226));
    assign mul_tree_12_227 = {mul_tree_12_226, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_228 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_229 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(4'(mul_tree_12_228)), .b(4'(mul_tree_12_229)), .cin(1'b0), .value(mul_tree_12_230));
    assign mul_tree_12_231 = {mul_tree_12_230, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_232 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_233 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(4'(mul_tree_12_232)), .b(4'(mul_tree_12_233)), .cin(1'b0), .value(mul_tree_12_234));
    assign mul_tree_12_235 = {mul_tree_12_234, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_236 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_237 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(4'(mul_tree_12_236)), .b(4'(mul_tree_12_237)), .cin(1'b0), .value(mul_tree_12_238));
    assign mul_tree_12_239 = {mul_tree_12_238, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_240 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_241 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_242Core rtlzz_owner_242(.a(4'(mul_tree_12_240)), .b(4'(mul_tree_12_241)), .cin(1'b0), .value(mul_tree_12_242));
    assign mul_tree_12_243 = {mul_tree_12_242, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_244 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_245 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_246Core rtlzz_owner_246(.a(4'(mul_tree_12_244)), .b(4'(mul_tree_12_245)), .cin(1'b0), .value(mul_tree_12_246));
    assign mul_tree_12_247 = {mul_tree_12_246, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_248 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_249 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_250Core rtlzz_owner_250(.a(4'(mul_tree_12_248)), .b(4'(mul_tree_12_249)), .cin(1'b0), .value(mul_tree_12_250));
    assign mul_tree_12_251 = {mul_tree_12_250, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_252 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_253 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_254Core rtlzz_owner_254(.a(4'(mul_tree_12_252)), .b(4'(mul_tree_12_253)), .cin(1'b0), .value(mul_tree_12_254));
    assign mul_tree_12_255 = {mul_tree_12_254, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_256 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_257 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_258Core rtlzz_owner_258(.a(4'(mul_tree_12_256)), .b(4'(mul_tree_12_257)), .cin(1'b0), .value(mul_tree_12_258));
    assign mul_tree_12_259 = {mul_tree_12_258, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_260 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_261 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_262Core rtlzz_owner_262(.a(4'(mul_tree_12_260)), .b(4'(mul_tree_12_261)), .cin(1'b0), .value(mul_tree_12_262));
    assign mul_tree_12_263 = {mul_tree_12_262, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_264 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_265 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_266Core rtlzz_owner_266(.a(4'(mul_tree_12_264)), .b(4'(mul_tree_12_265)), .cin(1'b0), .value(mul_tree_12_266));
    assign mul_tree_12_267 = {mul_tree_12_266, 56'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_268 = ({5'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_269 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_270Core rtlzz_owner_270(.a(8'(mul_tree_12_268)), .b(12'(mul_tree_12_269)), .cin(1'h0), .value(mul_tree_12_270));
    assign mul_tree_12_271 = ({5'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_272 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_273Core rtlzz_owner_273(.a(16'(mul_tree_12_271)), .b(20'(mul_tree_12_272)), .cin(1'h0), .value(mul_tree_12_273));
    assign mul_tree_12_274 = ({5'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_275 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(24'(mul_tree_12_274)), .b(28'(mul_tree_12_275)), .cin(1'h0), .value(mul_tree_12_276));
    assign mul_tree_12_277 = ({5'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_278 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_279Core rtlzz_owner_279(.a(32'(mul_tree_12_277)), .b(36'(mul_tree_12_278)), .cin(1'h0), .value(mul_tree_12_279));
    assign mul_tree_12_280 = ({5'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_281 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_282Core rtlzz_owner_282(.a(12'(mul_tree_12_280)), .b(16'(mul_tree_12_281)), .cin(1'h0), .value(mul_tree_12_282));
    assign mul_tree_12_283 = ({5'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_284 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_285Core rtlzz_owner_285(.a(20'(mul_tree_12_283)), .b(24'(mul_tree_12_284)), .cin(1'h0), .value(mul_tree_12_285));
    assign mul_tree_12_286 = ({5'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_287 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_288Core rtlzz_owner_288(.a(28'(mul_tree_12_286)), .b(32'(mul_tree_12_287)), .cin(1'h0), .value(mul_tree_12_288));
    assign mul_tree_12_289 = ({5'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_290 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_291Core rtlzz_owner_291(.a(36'(mul_tree_12_289)), .b(40'(mul_tree_12_290)), .cin(1'h0), .value(mul_tree_12_291));
    assign mul_tree_12_292 = ({5'h0, mul_tree_12_79}); // decl: <none>; prim: <none>
    assign mul_tree_12_293 = ({1'h0, mul_tree_12_83}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294Core rtlzz_owner_294(.a(16'(mul_tree_12_292)), .b(20'(mul_tree_12_293)), .cin(1'h0), .value(mul_tree_12_294));
    assign mul_tree_12_295 = ({5'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_296 = ({1'h0, mul_tree_12_91}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_297Core rtlzz_owner_297(.a(24'(mul_tree_12_295)), .b(28'(mul_tree_12_296)), .cin(1'h0), .value(mul_tree_12_297));
    assign mul_tree_12_298 = ({5'h0, mul_tree_12_95}); // decl: <none>; prim: <none>
    assign mul_tree_12_299 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_300Core rtlzz_owner_300(.a(32'(mul_tree_12_298)), .b(36'(mul_tree_12_299)), .cin(1'h0), .value(mul_tree_12_300));
    assign mul_tree_12_301 = ({5'h0, mul_tree_12_103}); // decl: <none>; prim: <none>
    assign mul_tree_12_302 = ({1'h0, mul_tree_12_107}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_303Core rtlzz_owner_303(.a(40'(mul_tree_12_301)), .b(44'(mul_tree_12_302)), .cin(1'h0), .value(mul_tree_12_303));
    assign mul_tree_12_304 = ({5'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_305 = ({1'h0, mul_tree_12_115}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_306Core rtlzz_owner_306(.a(20'(mul_tree_12_304)), .b(24'(mul_tree_12_305)), .cin(1'h0), .value(mul_tree_12_306));
    assign mul_tree_12_307 = ({5'h0, mul_tree_12_119}); // decl: <none>; prim: <none>
    assign mul_tree_12_308 = ({1'h0, mul_tree_12_123}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(28'(mul_tree_12_307)), .b(32'(mul_tree_12_308)), .cin(1'h0), .value(mul_tree_12_309));
    assign mul_tree_12_310 = ({5'h0, mul_tree_12_127}); // decl: <none>; prim: <none>
    assign mul_tree_12_311 = ({1'h0, mul_tree_12_131}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_312Core rtlzz_owner_312(.a(36'(mul_tree_12_310)), .b(40'(mul_tree_12_311)), .cin(1'h0), .value(mul_tree_12_312));
    assign mul_tree_12_313 = ({5'h0, mul_tree_12_135}); // decl: <none>; prim: <none>
    assign mul_tree_12_314 = ({1'h0, mul_tree_12_139}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_315Core rtlzz_owner_315(.a(44'(mul_tree_12_313)), .b(48'(mul_tree_12_314)), .cin(1'h0), .value(mul_tree_12_315));
    assign mul_tree_12_316 = ({5'h0, mul_tree_12_143}); // decl: <none>; prim: <none>
    assign mul_tree_12_317 = ({1'h0, mul_tree_12_147}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_318Core rtlzz_owner_318(.a(24'(mul_tree_12_316)), .b(28'(mul_tree_12_317)), .cin(1'h0), .value(mul_tree_12_318));
    assign mul_tree_12_319 = ({5'h0, mul_tree_12_151}); // decl: <none>; prim: <none>
    assign mul_tree_12_320 = ({1'h0, mul_tree_12_155}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_321Core rtlzz_owner_321(.a(32'(mul_tree_12_319)), .b(36'(mul_tree_12_320)), .cin(1'h0), .value(mul_tree_12_321));
    assign mul_tree_12_322 = ({5'h0, mul_tree_12_159}); // decl: <none>; prim: <none>
    assign mul_tree_12_323 = ({1'h0, mul_tree_12_163}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_324Core rtlzz_owner_324(.a(40'(mul_tree_12_322)), .b(44'(mul_tree_12_323)), .cin(1'h0), .value(mul_tree_12_324));
    assign mul_tree_12_325 = ({5'h0, mul_tree_12_167}); // decl: <none>; prim: <none>
    assign mul_tree_12_326 = ({1'h0, mul_tree_12_171}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_327Core rtlzz_owner_327(.a(48'(mul_tree_12_325)), .b(52'(mul_tree_12_326)), .cin(1'h0), .value(mul_tree_12_327));
    assign mul_tree_12_328 = ({5'h0, mul_tree_12_175}); // decl: <none>; prim: <none>
    assign mul_tree_12_329 = ({1'h0, mul_tree_12_179}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(28'(mul_tree_12_328)), .b(32'(mul_tree_12_329)), .cin(1'h0), .value(mul_tree_12_330));
    assign mul_tree_12_331 = ({5'h0, mul_tree_12_183}); // decl: <none>; prim: <none>
    assign mul_tree_12_332 = ({1'h0, mul_tree_12_187}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_333Core rtlzz_owner_333(.a(36'(mul_tree_12_331)), .b(40'(mul_tree_12_332)), .cin(1'h0), .value(mul_tree_12_333));
    assign mul_tree_12_334 = ({5'h0, mul_tree_12_191}); // decl: <none>; prim: <none>
    assign mul_tree_12_335 = ({1'h0, mul_tree_12_195}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_336Core rtlzz_owner_336(.a(44'(mul_tree_12_334)), .b(48'(mul_tree_12_335)), .cin(1'h0), .value(mul_tree_12_336));
    assign mul_tree_12_337 = ({5'h0, mul_tree_12_199}); // decl: <none>; prim: <none>
    assign mul_tree_12_338 = ({1'h0, mul_tree_12_203}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_339Core rtlzz_owner_339(.a(52'(mul_tree_12_337)), .b(56'(mul_tree_12_338)), .cin(1'h0), .value(mul_tree_12_339));
    assign mul_tree_12_340 = ({5'h0, mul_tree_12_207}); // decl: <none>; prim: <none>
    assign mul_tree_12_341 = ({1'h0, mul_tree_12_211}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_342Core rtlzz_owner_342(.a(32'(mul_tree_12_340)), .b(36'(mul_tree_12_341)), .cin(1'h0), .value(mul_tree_12_342));
    assign mul_tree_12_343 = ({5'h0, mul_tree_12_215}); // decl: <none>; prim: <none>
    assign mul_tree_12_344 = ({1'h0, mul_tree_12_219}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_345Core rtlzz_owner_345(.a(40'(mul_tree_12_343)), .b(44'(mul_tree_12_344)), .cin(1'h0), .value(mul_tree_12_345));
    assign mul_tree_12_346 = ({5'h0, mul_tree_12_223}); // decl: <none>; prim: <none>
    assign mul_tree_12_347 = ({1'h0, mul_tree_12_227}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(48'(mul_tree_12_346)), .b(52'(mul_tree_12_347)), .cin(1'h0), .value(mul_tree_12_348));
    assign mul_tree_12_349 = ({5'h0, mul_tree_12_231}); // decl: <none>; prim: <none>
    assign mul_tree_12_350 = ({1'h0, mul_tree_12_235}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(56'(mul_tree_12_349)), .b(60'(mul_tree_12_350)), .cin(1'h0), .value(mul_tree_12_351));
    assign mul_tree_12_352 = ({5'h0, mul_tree_12_239}); // decl: <none>; prim: <none>
    assign mul_tree_12_353 = ({1'h0, mul_tree_12_243}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(36'(mul_tree_12_352)), .b(40'(mul_tree_12_353)), .cin(1'h0), .value(mul_tree_12_354));
    assign mul_tree_12_355 = ({5'h0, mul_tree_12_247}); // decl: <none>; prim: <none>
    assign mul_tree_12_356 = ({1'h0, mul_tree_12_251}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_357Core rtlzz_owner_357(.a(44'(mul_tree_12_355)), .b(48'(mul_tree_12_356)), .cin(1'h0), .value(mul_tree_12_357));
    assign mul_tree_12_358 = ({5'h0, mul_tree_12_255}); // decl: <none>; prim: <none>
    assign mul_tree_12_359 = ({1'h0, mul_tree_12_259}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_360Core rtlzz_owner_360(.a(52'(mul_tree_12_358)), .b(56'(mul_tree_12_359)), .cin(1'h0), .value(mul_tree_12_360));
    assign mul_tree_12_361 = ({5'h0, mul_tree_12_263}); // decl: <none>; prim: <none>
    assign mul_tree_12_362 = ({1'h0, mul_tree_12_267}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_363Core rtlzz_owner_363(.a(60'(mul_tree_12_361)), .b(64'(mul_tree_12_362)), .cin(1'h0), .value(mul_tree_12_363[63:0]));
    assign mul_tree_12_363[64:64] = '0;
    assign mul_tree_12_364 = ({9'h0, rtlzz_pipe_270_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_365 = ({1'h0, rtlzz_pipe_273_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_367 = ({9'h0, rtlzz_pipe_276_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_368 = ({1'h0, rtlzz_pipe_279_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_370 = ({9'h0, rtlzz_pipe_282_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_371 = ({1'h0, rtlzz_pipe_285_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_373 = ({9'h0, rtlzz_pipe_288_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_374 = ({1'h0, rtlzz_pipe_291_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_376 = ({9'h0, rtlzz_pipe_294_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_377 = ({1'h0, rtlzz_pipe_297_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_379 = ({9'h0, rtlzz_pipe_300_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_380 = ({1'h0, rtlzz_pipe_303_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_382 = ({9'h0, rtlzz_pipe_306_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_383 = ({1'h0, rtlzz_pipe_309_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_385 = ({9'h0, rtlzz_pipe_312_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_386 = ({1'h0, rtlzz_pipe_315_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_388 = ({9'h0, rtlzz_pipe_318_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_389 = ({1'h0, rtlzz_pipe_321_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_391 = ({9'h0, rtlzz_pipe_324_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_392 = ({1'h0, rtlzz_pipe_327_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_394 = ({9'h0, rtlzz_pipe_330_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_395 = ({1'h0, rtlzz_pipe_333_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_397 = ({9'h0, rtlzz_pipe_336_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_398 = ({1'h0, rtlzz_pipe_339_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_400 = ({9'h0, rtlzz_pipe_342_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_401 = ({1'h0, rtlzz_pipe_345_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_403 = ({9'h0, rtlzz_pipe_348_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_404 = ({1'h0, rtlzz_pipe_351_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_406 = ({9'h0, rtlzz_pipe_354_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_407 = ({1'h0, rtlzz_pipe_357_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_409 = ({9'h0, rtlzz_pipe_360_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_410 = ({1'h0, rtlzz_pipe_363_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_412 = ({17'h0, mul_tree_12_366}); // decl: <none>; prim: <none>
    assign mul_tree_12_413 = ({1'h0, mul_tree_12_369}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_414_reduce rtlzz_reduce_414(.i460(rtlzz_pipe_270_s1), .i461(rtlzz_pipe_273_s1), .i462(rtlzz_pipe_276_s1), .i463(rtlzz_pipe_279_s1), .y(mul_tree_12_414));
    assign mul_tree_12_415 = ({17'h0, mul_tree_12_372}); // decl: <none>; prim: <none>
    assign mul_tree_12_416 = ({1'h0, mul_tree_12_375}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_417_reduce rtlzz_reduce_417(.i464(rtlzz_pipe_282_s1), .i465(rtlzz_pipe_285_s1), .i466(rtlzz_pipe_288_s1), .i467(rtlzz_pipe_291_s1), .y(mul_tree_12_417));
    assign mul_tree_12_418 = ({17'h0, mul_tree_12_378}); // decl: <none>; prim: <none>
    assign mul_tree_12_419 = ({1'h0, mul_tree_12_381}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_420_reduce rtlzz_reduce_420(.i468(rtlzz_pipe_294_s1), .i469(rtlzz_pipe_297_s1), .i470(rtlzz_pipe_300_s1), .i471(rtlzz_pipe_303_s1), .y(mul_tree_12_420));
    assign mul_tree_12_421 = ({17'h0, mul_tree_12_384}); // decl: <none>; prim: <none>
    assign mul_tree_12_422 = ({1'h0, mul_tree_12_387}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423_reduce rtlzz_reduce_423(.i472(rtlzz_pipe_306_s1), .i473(rtlzz_pipe_309_s1), .i474(rtlzz_pipe_312_s1), .i475(rtlzz_pipe_315_s1), .y(mul_tree_12_423));
    assign mul_tree_12_424 = ({17'h0, mul_tree_12_390}); // decl: <none>; prim: <none>
    assign mul_tree_12_425 = ({1'h0, mul_tree_12_393}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_426_reduce rtlzz_reduce_426(.i476(rtlzz_pipe_318_s1), .i477(rtlzz_pipe_321_s1), .i478(rtlzz_pipe_324_s1), .i479(rtlzz_pipe_327_s1), .y(mul_tree_12_426));
    assign mul_tree_12_427 = ({17'h0, mul_tree_12_396}); // decl: <none>; prim: <none>
    assign mul_tree_12_428 = ({1'h0, mul_tree_12_399}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_429_reduce rtlzz_reduce_429(.i480(rtlzz_pipe_330_s1), .i481(rtlzz_pipe_333_s1), .i482(rtlzz_pipe_336_s1), .i483(rtlzz_pipe_339_s1), .y(mul_tree_12_429));
    assign mul_tree_12_430 = ({17'h0, mul_tree_12_402}); // decl: <none>; prim: <none>
    assign mul_tree_12_431 = ({1'h0, mul_tree_12_405}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_432_reduce rtlzz_reduce_432(.i484(rtlzz_pipe_342_s1), .i485(rtlzz_pipe_345_s1), .i486(rtlzz_pipe_348_s1), .i487(rtlzz_pipe_351_s1), .y(mul_tree_12_432));
    assign mul_tree_12_433 = ({17'h0, mul_tree_12_408}); // decl: <none>; prim: <none>
    assign mul_tree_12_434 = ({1'h0, mul_tree_12_411}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_435_reduce rtlzz_reduce_435(.i488(rtlzz_pipe_354_s1), .i489(rtlzz_pipe_357_s1), .i490(rtlzz_pipe_360_s1), .i491(rtlzz_pipe_363_s1), .y(mul_tree_12_435));
    assign mul_tree_12_436 = ({5'h0, rtlzz_pipe_414_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_437 = ({1'h0, rtlzz_pipe_417_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_439 = ({5'h0, rtlzz_pipe_420_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_440 = ({1'h0, rtlzz_pipe_423_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_442 = ({5'h0, rtlzz_pipe_426_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_443 = ({1'h0, rtlzz_pipe_429_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_445 = ({5'h0, rtlzz_pipe_432_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_446 = ({1'h0, rtlzz_pipe_435_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_448 = ({9'h0, mul_tree_12_438}); // decl: <none>; prim: <none>
    assign mul_tree_12_449 = ({1'h0, mul_tree_12_441}); // decl: <none>; prim: <none>
    assign mul_tree_12_451 = ({9'h0, mul_tree_12_444}); // decl: <none>; prim: <none>
    assign mul_tree_12_452 = ({1'h0, mul_tree_12_447}); // decl: <none>; prim: <none>
    assign mul_tree_12_454 = ({17'h0, mul_tree_12_450}); // decl: <none>; prim: <none>
    assign mul_tree_12_455 = ({1'h0, mul_tree_12_453}); // decl: <none>; prim: <none>
    assign mul_tree_12_457 = mul_tree_12_456[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_270_s1 <= 13'h0;
            rtlzz_pipe_273_s1 <= 21'h0;
            rtlzz_pipe_276_s1 <= 29'h0;
            rtlzz_pipe_279_s1 <= 37'h0;
            rtlzz_pipe_282_s1 <= 17'h0;
            rtlzz_pipe_285_s1 <= 25'h0;
            rtlzz_pipe_288_s1 <= 33'h0;
            rtlzz_pipe_291_s1 <= 41'h0;
            rtlzz_pipe_294_s1 <= 21'h0;
            rtlzz_pipe_297_s1 <= 29'h0;
            rtlzz_pipe_300_s1 <= 37'h0;
            rtlzz_pipe_303_s1 <= 45'h0;
            rtlzz_pipe_306_s1 <= 25'h0;
            rtlzz_pipe_309_s1 <= 33'h0;
            rtlzz_pipe_312_s1 <= 41'h0;
            rtlzz_pipe_315_s1 <= 49'h0;
            rtlzz_pipe_318_s1 <= 29'h0;
            rtlzz_pipe_321_s1 <= 37'h0;
            rtlzz_pipe_324_s1 <= 45'h0;
            rtlzz_pipe_327_s1 <= 53'h0;
            rtlzz_pipe_330_s1 <= 33'h0;
            rtlzz_pipe_333_s1 <= 41'h0;
            rtlzz_pipe_336_s1 <= 49'h0;
            rtlzz_pipe_339_s1 <= 57'h0;
            rtlzz_pipe_342_s1 <= 37'h0;
            rtlzz_pipe_345_s1 <= 45'h0;
            rtlzz_pipe_348_s1 <= 53'h0;
            rtlzz_pipe_351_s1 <= 61'h0;
            rtlzz_pipe_354_s1 <= 41'h0;
            rtlzz_pipe_357_s1 <= 49'h0;
            rtlzz_pipe_360_s1 <= 57'h0;
            rtlzz_pipe_363_s1 <= 65'h0;
            rtlzz_pipe_414_s2 <= 39'h0;
            rtlzz_pipe_417_s2 <= 43'h0;
            rtlzz_pipe_420_s2 <= 47'h0;
            rtlzz_pipe_423_s2 <= 51'h0;
            rtlzz_pipe_426_s2 <= 55'h0;
            rtlzz_pipe_429_s2 <= 59'h0;
            rtlzz_pipe_432_s2 <= 63'h0;
            rtlzz_pipe_435_s2 <= 67'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= mul_tree_12_270; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= mul_tree_12_273; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_276_s1 <= mul_tree_12_276; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= mul_tree_12_279; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_282_s1 <= mul_tree_12_282; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_285_s1 <= mul_tree_12_285; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_288_s1 <= mul_tree_12_288; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_291_s1 <= mul_tree_12_291; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_294_s1 <= mul_tree_12_294; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_297_s1 <= mul_tree_12_297; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_300_s1 <= mul_tree_12_300; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_303_s1 <= mul_tree_12_303; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_306_s1 <= mul_tree_12_306; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_309_s1 <= mul_tree_12_309; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_312_s1 <= mul_tree_12_312; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_315_s1 <= mul_tree_12_315; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_318_s1 <= mul_tree_12_318; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_321_s1 <= mul_tree_12_321; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_324_s1 <= mul_tree_12_324; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_327_s1 <= mul_tree_12_327; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_330_s1 <= mul_tree_12_330; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_333_s1 <= mul_tree_12_333; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_336_s1 <= mul_tree_12_336; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_339_s1 <= mul_tree_12_339; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_342_s1 <= mul_tree_12_342; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_345_s1 <= mul_tree_12_345; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_348_s1 <= mul_tree_12_348; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_351_s1 <= mul_tree_12_351; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_354_s1 <= mul_tree_12_354; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_357_s1 <= mul_tree_12_357; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_360_s1 <= mul_tree_12_360; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_363_s1 <= mul_tree_12_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_414_s2 <= mul_tree_12_414; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_417_s2 <= mul_tree_12_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_420_s2 <= mul_tree_12_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_423_s2 <= mul_tree_12_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_426_s2 <= mul_tree_12_426; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_429_s2 <= mul_tree_12_429; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_432_s2 <= mul_tree_12_432; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_435_s2 <= mul_tree_12_435; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5_reduce(input wire [63:0] i459, input wire [38:0] i492, input wire [42:0] i493, input wire [46:0] i494, input wire [50:0] i495, input wire [54:0] i496, input wire [58:0] i497, input wire [62:0] i498, input wire [66:0] i499, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i492[38], i492[37], i492[36], i492[35], i492[34], i492[33], i492[32], i492[31], i492[30], i492[29], i492[28], i492[27], i492[26], i492[25], i492[24], i492[23], i492[22], i492[21], i492[20], i492[19], i492[18], i492[17], i492[16], i492[15], i492[14], i492[13], i492[12], i492[11], i492[10], i492[9], i492[8], i492[7], i492[6], i492[5], i492[4], i492[3], i492[2], i492[1], i492[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[42], i493[41], i493[40], i493[39], i493[38], i493[37], i493[36], i493[35], i493[34], i493[33], i493[32], i493[31], i493[30], i493[29], i493[28], i493[27], i493[26], i493[25], i493[24], i493[23], i493[22], i493[21], i493[20], i493[19], i493[18], i493[17], i493[16], i493[15], i493[14], i493[13], i493[12], i493[11], i493[10], i493[9], i493[8], i493[7], i493[6], i493[5], i493[4], i493[3], i493[2], i493[1], i493[0]};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i494[46], i494[45], i494[44], i494[43], i494[42], i494[41], i494[40], i494[39], i494[38], i494[37], i494[36], i494[35], i494[34], i494[33], i494[32], i494[31], i494[30], i494[29], i494[28], i494[27], i494[26], i494[25], i494[24], i494[23], i494[22], i494[21], i494[20], i494[19], i494[18], i494[17], i494[16], i494[15], i494[14], i494[13], i494[12], i494[11], i494[10], i494[9], i494[8], i494[7], i494[6], i494[5], i494[4], i494[3], i494[2], i494[1], i494[0]};
wire [63:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i495[50], i495[49], i495[48], i495[47], i495[46], i495[45], i495[44], i495[43], i495[42], i495[41], i495[40], i495[39], i495[38], i495[37], i495[36], i495[35], i495[34], i495[33], i495[32], i495[31], i495[30], i495[29], i495[28], i495[27], i495[26], i495[25], i495[24], i495[23], i495[22], i495[21], i495[20], i495[19], i495[18], i495[17], i495[16], i495[15], i495[14], i495[13], i495[12], i495[11], i495[10], i495[9], i495[8], i495[7], i495[6], i495[5], i495[4], i495[3], i495[2], i495[1], i495[0]};
wire [63:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i496[54], i496[53], i496[52], i496[51], i496[50], i496[49], i496[48], i496[47], i496[46], i496[45], i496[44], i496[43], i496[42], i496[41], i496[40], i496[39], i496[38], i496[37], i496[36], i496[35], i496[34], i496[33], i496[32], i496[31], i496[30], i496[29], i496[28], i496[27], i496[26], i496[25], i496[24], i496[23], i496[22], i496[21], i496[20], i496[19], i496[18], i496[17], i496[16], i496[15], i496[14], i496[13], i496[12], i496[11], i496[10], i496[9], i496[8], i496[7], i496[6], i496[5], i496[4], i496[3], i496[2], i496[1], i496[0]};
wire [63:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[58], i497[57], i497[56], i497[55], i497[54], i497[53], i497[52], i497[51], i497[50], i497[49], i497[48], i497[47], i497[46], i497[45], i497[44], i497[43], i497[42], i497[41], i497[40], i497[39], i497[38], i497[37], i497[36], i497[35], i497[34], i497[33], i497[32], i497[31], i497[30], i497[29], i497[28], i497[27], i497[26], i497[25], i497[24], i497[23], i497[22], i497[21], i497[20], i497[19], i497[18], i497[17], i497[16], i497[15], i497[14], i497[13], i497[12], i497[11], i497[10], i497[9], i497[8], i497[7], i497[6], i497[5], i497[4], i497[3], i497[2], i497[1], i497[0]};
wire [63:0] t6 = {1'b0, i498[62], i498[61], i498[60], i498[59], i498[58], i498[57], i498[56], i498[55], i498[54], i498[53], i498[52], i498[51], i498[50], i498[49], i498[48], i498[47], i498[46], i498[45], i498[44], i498[43], i498[42], i498[41], i498[40], i498[39], i498[38], i498[37], i498[36], i498[35], i498[34], i498[33], i498[32], i498[31], i498[30], i498[29], i498[28], i498[27], i498[26], i498[25], i498[24], i498[23], i498[22], i498[21], i498[20], i498[19], i498[18], i498[17], i498[16], i498[15], i498[14], i498[13], i498[12], i498[11], i498[10], i498[9], i498[8], i498[7], i498[6], i498[5], i498[4], i498[3], i498[2], i498[1], i498[0]};
wire [63:0] t7 = {i499[63], i499[62], i499[61], i499[60], i499[59], i499[58], i499[57], i499[56], i499[55], i499[54], i499[53], i499[52], i499[51], i499[50], i499[49], i499[48], i499[47], i499[46], i499[45], i499[44], i499[43], i499[42], i499[41], i499[40], i499[39], i499[38], i499[37], i499[36], i499[35], i499[34], i499[33], i499[32], i499[31], i499[30], i499[29], i499[28], i499[27], i499[26], i499[25], i499[24], i499[23], i499[22], i499[21], i499[20], i499[19], i499[18], i499[17], i499[16], i499[15], i499[14], i499[13], i499[12], i499[11], i499[10], i499[9], i499[8], i499[7], i499[6], i499[5], i499[4], i499[3], i499[2], i499[1], i499[0]};
wire [63:0] t8 = {i459[63], i459[62], i459[61], i459[60], i459[59], i459[58], i459[57], i459[56], i459[55], i459[54], i459[53], i459[52], i459[51], i459[50], i459[49], i459[48], i459[47], i459[46], i459[45], i459[44], i459[43], i459[42], i459[41], i459[40], i459[39], i459[38], i459[37], i459[36], i459[35], i459[34], i459[33], i459[32], i459[31], i459[30], i459[29], i459[28], i459[27], i459[26], i459[25], i459[24], i459[23], i459[22], i459[21], i459[20], i459[19], i459[18], i459[17], i459[16], i459[15], i459[14], i459[13], i459[12], i459[11], i459[10], i459[9], i459[8], i459[7], i459[6], i459[5], i459[4], i459[3], i459[2], i459[1], i459[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_414_reduce(input wire [12:0] i460, input wire [20:0] i461, input wire [28:0] i462, input wire [36:0] i463, output wire [38:0] y);
wire [38:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i460[12], i460[11], i460[10], i460[9], i460[8], i460[7], i460[6], i460[5], i460[4], i460[3], i460[2], i460[1], i460[0]};
wire [38:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i461[20], i461[19], i461[18], i461[17], i461[16], i461[15], i461[14], i461[13], i461[12], i461[11], i461[10], i461[9], i461[8], i461[7], i461[6], i461[5], i461[4], i461[3], i461[2], i461[1], i461[0]};
wire [38:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i462[28], i462[27], i462[26], i462[25], i462[24], i462[23], i462[22], i462[21], i462[20], i462[19], i462[18], i462[17], i462[16], i462[15], i462[14], i462[13], i462[12], i462[11], i462[10], i462[9], i462[8], i462[7], i462[6], i462[5], i462[4], i462[3], i462[2], i462[1], i462[0]};
wire [38:0] t3 = {1'b0, 1'b0, i463[36], i463[35], i463[34], i463[33], i463[32], i463[31], i463[30], i463[29], i463[28], i463[27], i463[26], i463[25], i463[24], i463[23], i463[22], i463[21], i463[20], i463[19], i463[18], i463[17], i463[16], i463[15], i463[14], i463[13], i463[12], i463[11], i463[10], i463[9], i463[8], i463[7], i463[6], i463[5], i463[4], i463[3], i463[2], i463[1], i463[0]};
wire [38:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_417_reduce(input wire [16:0] i464, input wire [24:0] i465, input wire [32:0] i466, input wire [40:0] i467, output wire [42:0] y);
wire [42:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i464[16], i464[15], i464[14], i464[13], i464[12], i464[11], i464[10], i464[9], i464[8], i464[7], i464[6], i464[5], i464[4], i464[3], i464[2], i464[1], i464[0]};
wire [42:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i465[24], i465[23], i465[22], i465[21], i465[20], i465[19], i465[18], i465[17], i465[16], i465[15], i465[14], i465[13], i465[12], i465[11], i465[10], i465[9], i465[8], i465[7], i465[6], i465[5], i465[4], i465[3], i465[2], i465[1], i465[0]};
wire [42:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i466[32], i466[31], i466[30], i466[29], i466[28], i466[27], i466[26], i466[25], i466[24], i466[23], i466[22], i466[21], i466[20], i466[19], i466[18], i466[17], i466[16], i466[15], i466[14], i466[13], i466[12], i466[11], i466[10], i466[9], i466[8], i466[7], i466[6], i466[5], i466[4], i466[3], i466[2], i466[1], i466[0]};
wire [42:0] t3 = {1'b0, 1'b0, i467[40], i467[39], i467[38], i467[37], i467[36], i467[35], i467[34], i467[33], i467[32], i467[31], i467[30], i467[29], i467[28], i467[27], i467[26], i467[25], i467[24], i467[23], i467[22], i467[21], i467[20], i467[19], i467[18], i467[17], i467[16], i467[15], i467[14], i467[13], i467[12], i467[11], i467[10], i467[9], i467[8], i467[7], i467[6], i467[5], i467[4], i467[3], i467[2], i467[1], i467[0]};
wire [42:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_420_reduce(input wire [20:0] i468, input wire [28:0] i469, input wire [36:0] i470, input wire [44:0] i471, output wire [46:0] y);
wire [46:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i468[20], i468[19], i468[18], i468[17], i468[16], i468[15], i468[14], i468[13], i468[12], i468[11], i468[10], i468[9], i468[8], i468[7], i468[6], i468[5], i468[4], i468[3], i468[2], i468[1], i468[0]};
wire [46:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i469[28], i469[27], i469[26], i469[25], i469[24], i469[23], i469[22], i469[21], i469[20], i469[19], i469[18], i469[17], i469[16], i469[15], i469[14], i469[13], i469[12], i469[11], i469[10], i469[9], i469[8], i469[7], i469[6], i469[5], i469[4], i469[3], i469[2], i469[1], i469[0]};
wire [46:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i470[36], i470[35], i470[34], i470[33], i470[32], i470[31], i470[30], i470[29], i470[28], i470[27], i470[26], i470[25], i470[24], i470[23], i470[22], i470[21], i470[20], i470[19], i470[18], i470[17], i470[16], i470[15], i470[14], i470[13], i470[12], i470[11], i470[10], i470[9], i470[8], i470[7], i470[6], i470[5], i470[4], i470[3], i470[2], i470[1], i470[0]};
wire [46:0] t3 = {1'b0, 1'b0, i471[44], i471[43], i471[42], i471[41], i471[40], i471[39], i471[38], i471[37], i471[36], i471[35], i471[34], i471[33], i471[32], i471[31], i471[30], i471[29], i471[28], i471[27], i471[26], i471[25], i471[24], i471[23], i471[22], i471[21], i471[20], i471[19], i471[18], i471[17], i471[16], i471[15], i471[14], i471[13], i471[12], i471[11], i471[10], i471[9], i471[8], i471[7], i471[6], i471[5], i471[4], i471[3], i471[2], i471[1], i471[0]};
wire [46:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423_reduce(input wire [24:0] i472, input wire [32:0] i473, input wire [40:0] i474, input wire [48:0] i475, output wire [50:0] y);
wire [50:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i472[24], i472[23], i472[22], i472[21], i472[20], i472[19], i472[18], i472[17], i472[16], i472[15], i472[14], i472[13], i472[12], i472[11], i472[10], i472[9], i472[8], i472[7], i472[6], i472[5], i472[4], i472[3], i472[2], i472[1], i472[0]};
wire [50:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i473[32], i473[31], i473[30], i473[29], i473[28], i473[27], i473[26], i473[25], i473[24], i473[23], i473[22], i473[21], i473[20], i473[19], i473[18], i473[17], i473[16], i473[15], i473[14], i473[13], i473[12], i473[11], i473[10], i473[9], i473[8], i473[7], i473[6], i473[5], i473[4], i473[3], i473[2], i473[1], i473[0]};
wire [50:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i474[40], i474[39], i474[38], i474[37], i474[36], i474[35], i474[34], i474[33], i474[32], i474[31], i474[30], i474[29], i474[28], i474[27], i474[26], i474[25], i474[24], i474[23], i474[22], i474[21], i474[20], i474[19], i474[18], i474[17], i474[16], i474[15], i474[14], i474[13], i474[12], i474[11], i474[10], i474[9], i474[8], i474[7], i474[6], i474[5], i474[4], i474[3], i474[2], i474[1], i474[0]};
wire [50:0] t3 = {1'b0, 1'b0, i475[48], i475[47], i475[46], i475[45], i475[44], i475[43], i475[42], i475[41], i475[40], i475[39], i475[38], i475[37], i475[36], i475[35], i475[34], i475[33], i475[32], i475[31], i475[30], i475[29], i475[28], i475[27], i475[26], i475[25], i475[24], i475[23], i475[22], i475[21], i475[20], i475[19], i475[18], i475[17], i475[16], i475[15], i475[14], i475[13], i475[12], i475[11], i475[10], i475[9], i475[8], i475[7], i475[6], i475[5], i475[4], i475[3], i475[2], i475[1], i475[0]};
wire [50:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426_reduce(input wire [28:0] i476, input wire [36:0] i477, input wire [44:0] i478, input wire [52:0] i479, output wire [54:0] y);
wire [54:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i476[28], i476[27], i476[26], i476[25], i476[24], i476[23], i476[22], i476[21], i476[20], i476[19], i476[18], i476[17], i476[16], i476[15], i476[14], i476[13], i476[12], i476[11], i476[10], i476[9], i476[8], i476[7], i476[6], i476[5], i476[4], i476[3], i476[2], i476[1], i476[0]};
wire [54:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i477[36], i477[35], i477[34], i477[33], i477[32], i477[31], i477[30], i477[29], i477[28], i477[27], i477[26], i477[25], i477[24], i477[23], i477[22], i477[21], i477[20], i477[19], i477[18], i477[17], i477[16], i477[15], i477[14], i477[13], i477[12], i477[11], i477[10], i477[9], i477[8], i477[7], i477[6], i477[5], i477[4], i477[3], i477[2], i477[1], i477[0]};
wire [54:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i478[44], i478[43], i478[42], i478[41], i478[40], i478[39], i478[38], i478[37], i478[36], i478[35], i478[34], i478[33], i478[32], i478[31], i478[30], i478[29], i478[28], i478[27], i478[26], i478[25], i478[24], i478[23], i478[22], i478[21], i478[20], i478[19], i478[18], i478[17], i478[16], i478[15], i478[14], i478[13], i478[12], i478[11], i478[10], i478[9], i478[8], i478[7], i478[6], i478[5], i478[4], i478[3], i478[2], i478[1], i478[0]};
wire [54:0] t3 = {1'b0, 1'b0, i479[52], i479[51], i479[50], i479[49], i479[48], i479[47], i479[46], i479[45], i479[44], i479[43], i479[42], i479[41], i479[40], i479[39], i479[38], i479[37], i479[36], i479[35], i479[34], i479[33], i479[32], i479[31], i479[30], i479[29], i479[28], i479[27], i479[26], i479[25], i479[24], i479[23], i479[22], i479[21], i479[20], i479[19], i479[18], i479[17], i479[16], i479[15], i479[14], i479[13], i479[12], i479[11], i479[10], i479[9], i479[8], i479[7], i479[6], i479[5], i479[4], i479[3], i479[2], i479[1], i479[0]};
wire [54:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_429_reduce(input wire [32:0] i480, input wire [40:0] i481, input wire [48:0] i482, input wire [56:0] i483, output wire [58:0] y);
wire [58:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i480[32], i480[31], i480[30], i480[29], i480[28], i480[27], i480[26], i480[25], i480[24], i480[23], i480[22], i480[21], i480[20], i480[19], i480[18], i480[17], i480[16], i480[15], i480[14], i480[13], i480[12], i480[11], i480[10], i480[9], i480[8], i480[7], i480[6], i480[5], i480[4], i480[3], i480[2], i480[1], i480[0]};
wire [58:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i481[40], i481[39], i481[38], i481[37], i481[36], i481[35], i481[34], i481[33], i481[32], i481[31], i481[30], i481[29], i481[28], i481[27], i481[26], i481[25], i481[24], i481[23], i481[22], i481[21], i481[20], i481[19], i481[18], i481[17], i481[16], i481[15], i481[14], i481[13], i481[12], i481[11], i481[10], i481[9], i481[8], i481[7], i481[6], i481[5], i481[4], i481[3], i481[2], i481[1], i481[0]};
wire [58:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i482[48], i482[47], i482[46], i482[45], i482[44], i482[43], i482[42], i482[41], i482[40], i482[39], i482[38], i482[37], i482[36], i482[35], i482[34], i482[33], i482[32], i482[31], i482[30], i482[29], i482[28], i482[27], i482[26], i482[25], i482[24], i482[23], i482[22], i482[21], i482[20], i482[19], i482[18], i482[17], i482[16], i482[15], i482[14], i482[13], i482[12], i482[11], i482[10], i482[9], i482[8], i482[7], i482[6], i482[5], i482[4], i482[3], i482[2], i482[1], i482[0]};
wire [58:0] t3 = {1'b0, 1'b0, i483[56], i483[55], i483[54], i483[53], i483[52], i483[51], i483[50], i483[49], i483[48], i483[47], i483[46], i483[45], i483[44], i483[43], i483[42], i483[41], i483[40], i483[39], i483[38], i483[37], i483[36], i483[35], i483[34], i483[33], i483[32], i483[31], i483[30], i483[29], i483[28], i483[27], i483[26], i483[25], i483[24], i483[23], i483[22], i483[21], i483[20], i483[19], i483[18], i483[17], i483[16], i483[15], i483[14], i483[13], i483[12], i483[11], i483[10], i483[9], i483[8], i483[7], i483[6], i483[5], i483[4], i483[3], i483[2], i483[1], i483[0]};
wire [58:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432_reduce(input wire [36:0] i484, input wire [44:0] i485, input wire [52:0] i486, input wire [60:0] i487, output wire [62:0] y);
wire [62:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i484[36], i484[35], i484[34], i484[33], i484[32], i484[31], i484[30], i484[29], i484[28], i484[27], i484[26], i484[25], i484[24], i484[23], i484[22], i484[21], i484[20], i484[19], i484[18], i484[17], i484[16], i484[15], i484[14], i484[13], i484[12], i484[11], i484[10], i484[9], i484[8], i484[7], i484[6], i484[5], i484[4], i484[3], i484[2], i484[1], i484[0]};
wire [62:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i485[44], i485[43], i485[42], i485[41], i485[40], i485[39], i485[38], i485[37], i485[36], i485[35], i485[34], i485[33], i485[32], i485[31], i485[30], i485[29], i485[28], i485[27], i485[26], i485[25], i485[24], i485[23], i485[22], i485[21], i485[20], i485[19], i485[18], i485[17], i485[16], i485[15], i485[14], i485[13], i485[12], i485[11], i485[10], i485[9], i485[8], i485[7], i485[6], i485[5], i485[4], i485[3], i485[2], i485[1], i485[0]};
wire [62:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i486[52], i486[51], i486[50], i486[49], i486[48], i486[47], i486[46], i486[45], i486[44], i486[43], i486[42], i486[41], i486[40], i486[39], i486[38], i486[37], i486[36], i486[35], i486[34], i486[33], i486[32], i486[31], i486[30], i486[29], i486[28], i486[27], i486[26], i486[25], i486[24], i486[23], i486[22], i486[21], i486[20], i486[19], i486[18], i486[17], i486[16], i486[15], i486[14], i486[13], i486[12], i486[11], i486[10], i486[9], i486[8], i486[7], i486[6], i486[5], i486[4], i486[3], i486[2], i486[1], i486[0]};
wire [62:0] t3 = {1'b0, 1'b0, i487[60], i487[59], i487[58], i487[57], i487[56], i487[55], i487[54], i487[53], i487[52], i487[51], i487[50], i487[49], i487[48], i487[47], i487[46], i487[45], i487[44], i487[43], i487[42], i487[41], i487[40], i487[39], i487[38], i487[37], i487[36], i487[35], i487[34], i487[33], i487[32], i487[31], i487[30], i487[29], i487[28], i487[27], i487[26], i487[25], i487[24], i487[23], i487[22], i487[21], i487[20], i487[19], i487[18], i487[17], i487[16], i487[15], i487[14], i487[13], i487[12], i487[11], i487[10], i487[9], i487[8], i487[7], i487[6], i487[5], i487[4], i487[3], i487[2], i487[1], i487[0]};
wire [62:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_435_reduce(input wire [40:0] i488, input wire [48:0] i489, input wire [56:0] i490, input wire [64:0] i491, output wire [66:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i488[40], i488[39], i488[38], i488[37], i488[36], i488[35], i488[34], i488[33], i488[32], i488[31], i488[30], i488[29], i488[28], i488[27], i488[26], i488[25], i488[24], i488[23], i488[22], i488[21], i488[20], i488[19], i488[18], i488[17], i488[16], i488[15], i488[14], i488[13], i488[12], i488[11], i488[10], i488[9], i488[8], i488[7], i488[6], i488[5], i488[4], i488[3], i488[2], i488[1], i488[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i489[48], i489[47], i489[46], i489[45], i489[44], i489[43], i489[42], i489[41], i489[40], i489[39], i489[38], i489[37], i489[36], i489[35], i489[34], i489[33], i489[32], i489[31], i489[30], i489[29], i489[28], i489[27], i489[26], i489[25], i489[24], i489[23], i489[22], i489[21], i489[20], i489[19], i489[18], i489[17], i489[16], i489[15], i489[14], i489[13], i489[12], i489[11], i489[10], i489[9], i489[8], i489[7], i489[6], i489[5], i489[4], i489[3], i489[2], i489[1], i489[0]};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[56], i490[55], i490[54], i490[53], i490[52], i490[51], i490[50], i490[49], i490[48], i490[47], i490[46], i490[45], i490[44], i490[43], i490[42], i490[41], i490[40], i490[39], i490[38], i490[37], i490[36], i490[35], i490[34], i490[33], i490[32], i490[31], i490[30], i490[29], i490[28], i490[27], i490[26], i490[25], i490[24], i490[23], i490[22], i490[21], i490[20], i490[19], i490[18], i490[17], i490[16], i490[15], i490[14], i490[13], i490[12], i490[11], i490[10], i490[9], i490[8], i490[7], i490[6], i490[5], i490[4], i490[3], i490[2], i490[1], i490[0]};
wire [63:0] t3 = {i491[63], i491[62], i491[61], i491[60], i491[59], i491[58], i491[57], i491[56], i491[55], i491[54], i491[53], i491[52], i491[51], i491[50], i491[49], i491[48], i491[47], i491[46], i491[45], i491[44], i491[43], i491[42], i491[41], i491[40], i491[39], i491[38], i491[37], i491[36], i491[35], i491[34], i491[33], i491[32], i491[31], i491[30], i491[29], i491[28], i491[27], i491[26], i491[25], i491[24], i491[23], i491[22], i491[21], i491[20], i491[19], i491[18], i491[17], i491[16], i491[15], i491[14], i491[13], i491[12], i491[11], i491[10], i491[9], i491[8], i491[7], i491[6], i491[5], i491[4], i491[3], i491[2], i491[1], i491[0]};
wire [63:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270Core(input wire [7:0] a,input wire [11:0] b,input wire cin,output wire [12:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [11:0] masked_b=((b&12'hff0)|12'h0);
wire [12:0] aa=13'(masked_b);
wire [12:0] bb=13'(masked_a);
wire [13:0] extended={1'b0,aa}+{1'b0,bb}+14'(1'b0);
wire [12:0] native_value=extended[12:0];
assign value=native_value[0+:13];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273Core(input wire [15:0] a,input wire [19:0] b,input wire cin,output wire [20:0] value);
wire [15:0] masked_a=((a&16'hff00)|16'h0);
wire [19:0] masked_b=((b&20'hff000)|20'h0);
wire [20:0] aa=21'(masked_b);
wire [20:0] bb=21'(masked_a);
wire [21:0] extended={1'b0,aa}+{1'b0,bb}+22'(1'b0);
wire [20:0] native_value=extended[20:0];
assign value=native_value[0+:21];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282Core(input wire [11:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [11:0] masked_a=((a&12'hff0)|12'h0);
wire [15:0] masked_b=((b&16'hff00)|16'h0);
wire [16:0] aa=17'(masked_b);
wire [16:0] bb=17'(masked_a);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_285Core(input wire [19:0] a,input wire [23:0] b,input wire cin,output wire [24:0] value);
wire [19:0] masked_a=((a&20'hff000)|20'h0);
wire [23:0] masked_b=((b&24'hff0000)|24'h0);
wire [24:0] aa=25'(masked_b);
wire [24:0] bb=25'(masked_a);
wire [25:0] extended={1'b0,aa}+{1'b0,bb}+26'(1'b0);
wire [24:0] native_value=extended[24:0];
assign value=native_value[0+:25];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_285();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294Core(input wire [15:0] a,input wire [19:0] b,input wire cin,output wire [20:0] value);
wire [15:0] masked_a=((a&16'hff00)|16'h0);
wire [19:0] masked_b=((b&20'hff000)|20'h0);
wire [20:0] aa=21'(masked_b);
wire [20:0] bb=21'(masked_a);
wire [21:0] extended={1'b0,aa}+{1'b0,bb}+22'(1'b0);
wire [20:0] native_value=extended[20:0];
assign value=native_value[0+:21];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_297Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_297();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306Core(input wire [19:0] a,input wire [23:0] b,input wire cin,output wire [24:0] value);
wire [19:0] masked_a=((a&20'hff000)|20'h0);
wire [23:0] masked_b=((b&24'hff0000)|24'h0);
wire [24:0] aa=25'(masked_b);
wire [24:0] bb=25'(masked_a);
wire [25:0] extended={1'b0,aa}+{1'b0,bb}+26'(1'b0);
wire [24:0] native_value=extended[24:0];
assign value=native_value[0+:25];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_318Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_318();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_321Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_321();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_324Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_324();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_327Core(input wire [47:0] a,input wire [51:0] b,input wire cin,output wire [52:0] value);
wire [47:0] masked_a=((a&48'hff0000000000)|48'h0);
wire [51:0] masked_b=((b&52'hff00000000000)|52'h0);
wire [52:0] aa=53'(masked_b);
wire [52:0] bb=53'(masked_a);
wire [53:0] extended={1'b0,aa}+{1'b0,bb}+54'(1'b0);
wire [52:0] native_value=extended[52:0];
assign value=native_value[0+:53];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_327();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_333Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_333();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_336Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_336();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_339Core(input wire [51:0] a,input wire [55:0] b,input wire cin,output wire [56:0] value);
wire [51:0] masked_a=((a&52'hff00000000000)|52'h0);
wire [55:0] masked_b=((b&56'hff000000000000)|56'h0);
wire [56:0] aa=57'(masked_b);
wire [56:0] bb=57'(masked_a);
wire [57:0] extended={1'b0,aa}+{1'b0,bb}+58'(1'b0);
wire [56:0] native_value=extended[56:0];
assign value=native_value[0+:57];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_339();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [47:0] a,input wire [51:0] b,input wire cin,output wire [52:0] value);
wire [47:0] masked_a=((a&48'hff0000000000)|48'h0);
wire [51:0] masked_b=((b&52'hff00000000000)|52'h0);
wire [52:0] aa=53'(masked_b);
wire [52:0] bb=53'(masked_a);
wire [53:0] extended={1'b0,aa}+{1'b0,bb}+54'(1'b0);
wire [52:0] native_value=extended[52:0];
assign value=native_value[0+:53];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [55:0] a,input wire [59:0] b,input wire cin,output wire [60:0] value);
wire [55:0] masked_a=((a&56'hff000000000000)|56'h0);
wire [59:0] masked_b=((b&60'hff0000000000000)|60'h0);
wire [60:0] aa=61'(masked_b);
wire [60:0] bb=61'(masked_a);
wire [61:0] extended={1'b0,aa}+{1'b0,bb}+62'(1'b0);
wire [60:0] native_value=extended[60:0];
assign value=native_value[0+:61];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360Core(input wire [51:0] a,input wire [55:0] b,input wire cin,output wire [56:0] value);
wire [51:0] masked_a=((a&52'hff00000000000)|52'h0);
wire [55:0] masked_b=((b&56'hff000000000000)|56'h0);
wire [56:0] aa=57'(masked_b);
wire [56:0] bb=57'(masked_a);
wire [57:0] extended={1'b0,aa}+{1'b0,bb}+58'(1'b0);
wire [56:0] native_value=extended[56:0];
assign value=native_value[0+:57];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363Core(input wire [59:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [59:0] masked_a=((a&60'hff0000000000000)|60'h0);
wire [63:0] masked_b=((b&64'hff00000000000000)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
