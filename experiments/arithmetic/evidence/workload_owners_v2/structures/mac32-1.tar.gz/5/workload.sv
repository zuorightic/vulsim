`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [3:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_122; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_123; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_124; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_125; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_126; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_127; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_128; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_129; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_130; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_131; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_132; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_133; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_134; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_135; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_136; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_137; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_138; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_139; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_140; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_141; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_142; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_143; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_144; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_145; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_146; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_147; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_148; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_149; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_150; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_151; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_152; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_153; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_154; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_155; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_156; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_157; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_158; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_159; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_160; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_161; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_162; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_163; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_164; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_165; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_166; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_167; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_168; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_169; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_170; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_171; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_172; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_173; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_174; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_175; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_176; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_177; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_179; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_180; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_181; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_182; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_183; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_184; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_185; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_186; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_187; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_188; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_189; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_190; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_191; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_192; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_193; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_194; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_195; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_196; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_197; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_198; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_199; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_200; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_201; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_202; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_203; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_204; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_205; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_207; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_208; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_209; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_210; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_211; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_212; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_213; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_214; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_215; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_216; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_217; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_218; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_219; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_220; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_221; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_222; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_223; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_224; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_225; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_226; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_227; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_228; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_229; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_230; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_231; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_232; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_233; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_234; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_235; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_236; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_237; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_238; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_239; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_240; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_241; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_242; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_243; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_244; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_245; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_246; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_247; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_248; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_249; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_250; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_251; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_252; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_253; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_254; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_255; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_256; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_257; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_258; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_259; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_260; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_261; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_262; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_263; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_264; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_265; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_266; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_267; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_268; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_269; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_270; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_271; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_272; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_273; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_274; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_275; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_276; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_277; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_278; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_279; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_280; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_281; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_282; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_283; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_284; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_285; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_286; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_287; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_288; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_289; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_290; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_291; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_292; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_293; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_294; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_295; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_296; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_297; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_298; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_299; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_300; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_301; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_302; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_303; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_304; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_305; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_306; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_307; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_308; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_309; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_310; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_311; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_312; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_313; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_314; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_315; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_316; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_317; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_318; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_319; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_320; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_321; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_322; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_323; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_324; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_325; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_326; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_327; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_328; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_329; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_330; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_331; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_332; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_333; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_334; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_335; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_336; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_337; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_338; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_339; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_340; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_341; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_342; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_343; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_344; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_345; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_346; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_347; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_348; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_349; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_350; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_351; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_352; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_353; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_354; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_355; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_356; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_357; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_358; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_359; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_360; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_361; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_362; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_363; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_364; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_365; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_366; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_367; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_368; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_369; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_370; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_371; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_372; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_373; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_374; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_375; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_376; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_377; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_378; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_379; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_380; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_381; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_382; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_383; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_384; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_385; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_386; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_387; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_388; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_389; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_390; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_391; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_392; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_393; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_394; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_395; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_396; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_397; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_398; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_399; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_400; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_401; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_402; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_403; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_404; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_405; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_406; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_407; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_408; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_409; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_410; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_411; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_412; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_413; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_414; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_415; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_416; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_417; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_418; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_419; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_420; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_421; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_422; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_423; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_424; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_425; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_426; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_427; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_428; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_429; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_430; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_431; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_432; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_433; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_434; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_435; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_436; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_437; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_438; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_439; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_440; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_441; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_442; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_443; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_444; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_445; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_446; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_447; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_448; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_449; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_450; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_451; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_452; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_453; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_454; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_455; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_456; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_457; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [21:0] rtlzz_pipe_366_s1; // decl: <none>; prim: <none>
    logic [37:0] rtlzz_pipe_369_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_372_s1; // decl: <none>; prim: <none>
    logic [41:0] rtlzz_pipe_375_s1; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_378_s1; // decl: <none>; prim: <none>
    logic [45:0] rtlzz_pipe_381_s1; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_384_s1; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_387_s1; // decl: <none>; prim: <none>
    logic [37:0] rtlzz_pipe_390_s1; // decl: <none>; prim: <none>
    logic [53:0] rtlzz_pipe_393_s1; // decl: <none>; prim: <none>
    logic [41:0] rtlzz_pipe_396_s1; // decl: <none>; prim: <none>
    logic [57:0] rtlzz_pipe_399_s1; // decl: <none>; prim: <none>
    logic [45:0] rtlzz_pipe_402_s1; // decl: <none>; prim: <none>
    logic [61:0] rtlzz_pipe_405_s1; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_408_s1; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_411_s1; // decl: <none>; prim: <none>
    logic [38:0] rtlzz_pipe_414_s2; // decl: <none>; prim: <none>
    logic [42:0] rtlzz_pipe_417_s2; // decl: <none>; prim: <none>
    logic [46:0] rtlzz_pipe_420_s2; // decl: <none>; prim: <none>
    logic [50:0] rtlzz_pipe_423_s2; // decl: <none>; prim: <none>
    logic [54:0] rtlzz_pipe_426_s2; // decl: <none>; prim: <none>
    logic [58:0] rtlzz_pipe_429_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_432_s2; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_435_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5_reduce rtlzz_reduce_5(.i459(rtlzz_pipe_2_s2), .i476(rtlzz_pipe_414_s2), .i477(rtlzz_pipe_417_s2), .i478(rtlzz_pipe_420_s2), .i479(rtlzz_pipe_423_s2), .i480(rtlzz_pipe_426_s2), .i481(rtlzz_pipe_429_s2), .i482(rtlzz_pipe_432_s2), .i483(rtlzz_pipe_435_s2), .y(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_457; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(4'(mul_tree_12_13)), .b(4'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(4'(mul_tree_12_16)), .b(4'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(4'(mul_tree_12_20)), .b(4'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(4'(mul_tree_12_24)), .b(4'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(4'(mul_tree_12_28)), .b(4'(mul_tree_12_29)), .cin(1'b0), .value(mul_tree_12_30));
    assign mul_tree_12_31 = {mul_tree_12_30, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(4'(mul_tree_12_32)), .b(4'(mul_tree_12_33)), .cin(1'b0), .value(mul_tree_12_34));
    assign mul_tree_12_35 = {mul_tree_12_34, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(4'(mul_tree_12_36)), .b(4'(mul_tree_12_37)), .cin(1'b0), .value(mul_tree_12_38));
    assign mul_tree_12_39 = {mul_tree_12_38, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(4'(mul_tree_12_40)), .b(4'(mul_tree_12_41)), .cin(1'b0), .value(mul_tree_12_42));
    assign mul_tree_12_43 = {mul_tree_12_42, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_46Core rtlzz_owner_46(.a(4'(mul_tree_12_44)), .b(4'(mul_tree_12_45)), .cin(1'b0), .value(mul_tree_12_46));
    assign mul_tree_12_47 = {mul_tree_12_46, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(4'(mul_tree_12_48)), .b(4'(mul_tree_12_49)), .cin(1'b0), .value(mul_tree_12_50));
    assign mul_tree_12_51 = {mul_tree_12_50, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(4'(mul_tree_12_52)), .b(4'(mul_tree_12_53)), .cin(1'b0), .value(mul_tree_12_54));
    assign mul_tree_12_55 = {mul_tree_12_54, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(4'(mul_tree_12_56)), .b(4'(mul_tree_12_57)), .cin(1'b0), .value(mul_tree_12_58));
    assign mul_tree_12_59 = {mul_tree_12_58, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_62Core rtlzz_owner_62(.a(4'(mul_tree_12_60)), .b(4'(mul_tree_12_61)), .cin(1'b0), .value(mul_tree_12_62));
    assign mul_tree_12_63 = {mul_tree_12_62, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_66Core rtlzz_owner_66(.a(4'(mul_tree_12_64)), .b(4'(mul_tree_12_65)), .cin(1'b0), .value(mul_tree_12_66));
    assign mul_tree_12_67 = {mul_tree_12_66, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(4'(mul_tree_12_68)), .b(4'(mul_tree_12_69)), .cin(1'b0), .value(mul_tree_12_70));
    assign mul_tree_12_71 = {mul_tree_12_70, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(4'(mul_tree_12_72)), .b(4'(mul_tree_12_73)), .cin(1'b0), .value(mul_tree_12_74));
    assign mul_tree_12_75 = {mul_tree_12_74, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_77 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(4'(mul_tree_12_76)), .b(4'(mul_tree_12_77)), .cin(1'b0), .value(mul_tree_12_78));
    assign mul_tree_12_79 = {mul_tree_12_78, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_80 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_81 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(4'(mul_tree_12_80)), .b(4'(mul_tree_12_81)), .cin(1'b0), .value(mul_tree_12_82));
    assign mul_tree_12_83 = {mul_tree_12_82, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_84 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_85 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(4'(mul_tree_12_84)), .b(4'(mul_tree_12_85)), .cin(1'b0), .value(mul_tree_12_86));
    assign mul_tree_12_87 = {mul_tree_12_86, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_88 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_89 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(4'(mul_tree_12_88)), .b(4'(mul_tree_12_89)), .cin(1'b0), .value(mul_tree_12_90));
    assign mul_tree_12_91 = {mul_tree_12_90, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_92 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_93 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(4'(mul_tree_12_92)), .b(4'(mul_tree_12_93)), .cin(1'b0), .value(mul_tree_12_94));
    assign mul_tree_12_95 = {mul_tree_12_94, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_96 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_97 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(4'(mul_tree_12_96)), .b(4'(mul_tree_12_97)), .cin(1'b0), .value(mul_tree_12_98));
    assign mul_tree_12_99 = {mul_tree_12_98, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_100 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_101 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(4'(mul_tree_12_100)), .b(4'(mul_tree_12_101)), .cin(1'b0), .value(mul_tree_12_102));
    assign mul_tree_12_103 = {mul_tree_12_102, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_104 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_105 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(4'(mul_tree_12_104)), .b(4'(mul_tree_12_105)), .cin(1'b0), .value(mul_tree_12_106));
    assign mul_tree_12_107 = {mul_tree_12_106, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_108 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_109 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(4'(mul_tree_12_108)), .b(4'(mul_tree_12_109)), .cin(1'b0), .value(mul_tree_12_110));
    assign mul_tree_12_111 = {mul_tree_12_110, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_112 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_113 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(4'(mul_tree_12_112)), .b(4'(mul_tree_12_113)), .cin(1'b0), .value(mul_tree_12_114));
    assign mul_tree_12_115 = {mul_tree_12_114, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_116 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_117 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(4'(mul_tree_12_116)), .b(4'(mul_tree_12_117)), .cin(1'b0), .value(mul_tree_12_118));
    assign mul_tree_12_119 = {mul_tree_12_118, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_120 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_122Core rtlzz_owner_122(.a(4'(mul_tree_12_120)), .b(4'(mul_tree_12_121)), .cin(1'b0), .value(mul_tree_12_122));
    assign mul_tree_12_123 = {mul_tree_12_122, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_124 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_125 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(4'(mul_tree_12_124)), .b(4'(mul_tree_12_125)), .cin(1'b0), .value(mul_tree_12_126));
    assign mul_tree_12_127 = {mul_tree_12_126, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_128 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_129 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(4'(mul_tree_12_128)), .b(4'(mul_tree_12_129)), .cin(1'b0), .value(mul_tree_12_130));
    assign mul_tree_12_131 = {mul_tree_12_130, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_132 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_133 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(4'(mul_tree_12_132)), .b(4'(mul_tree_12_133)), .cin(1'b0), .value(mul_tree_12_134));
    assign mul_tree_12_135 = {mul_tree_12_134, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_136 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_137 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(4'(mul_tree_12_136)), .b(4'(mul_tree_12_137)), .cin(1'b0), .value(mul_tree_12_138));
    assign mul_tree_12_139 = {mul_tree_12_138, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_140 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_141 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(4'(mul_tree_12_140)), .b(4'(mul_tree_12_141)), .cin(1'b0), .value(mul_tree_12_142));
    assign mul_tree_12_143 = {mul_tree_12_142, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_144 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_145 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_146Core rtlzz_owner_146(.a(4'(mul_tree_12_144)), .b(4'(mul_tree_12_145)), .cin(1'b0), .value(mul_tree_12_146));
    assign mul_tree_12_147 = {mul_tree_12_146, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_148 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_149 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_150Core rtlzz_owner_150(.a(4'(mul_tree_12_148)), .b(4'(mul_tree_12_149)), .cin(1'b0), .value(mul_tree_12_150));
    assign mul_tree_12_151 = {mul_tree_12_150, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_152 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_153 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(4'(mul_tree_12_152)), .b(4'(mul_tree_12_153)), .cin(1'b0), .value(mul_tree_12_154));
    assign mul_tree_12_155 = {mul_tree_12_154, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_156 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_157 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_158Core rtlzz_owner_158(.a(4'(mul_tree_12_156)), .b(4'(mul_tree_12_157)), .cin(1'b0), .value(mul_tree_12_158));
    assign mul_tree_12_159 = {mul_tree_12_158, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_160 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_161 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_162Core rtlzz_owner_162(.a(4'(mul_tree_12_160)), .b(4'(mul_tree_12_161)), .cin(1'b0), .value(mul_tree_12_162));
    assign mul_tree_12_163 = {mul_tree_12_162, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_164 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_165 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(4'(mul_tree_12_164)), .b(4'(mul_tree_12_165)), .cin(1'b0), .value(mul_tree_12_166));
    assign mul_tree_12_167 = {mul_tree_12_166, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_168 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_169 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(4'(mul_tree_12_168)), .b(4'(mul_tree_12_169)), .cin(1'b0), .value(mul_tree_12_170));
    assign mul_tree_12_171 = {mul_tree_12_170, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_172 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_173 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(4'(mul_tree_12_172)), .b(4'(mul_tree_12_173)), .cin(1'b0), .value(mul_tree_12_174));
    assign mul_tree_12_175 = {mul_tree_12_174, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_176 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_177 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_178Core rtlzz_owner_178(.a(4'(mul_tree_12_176)), .b(4'(mul_tree_12_177)), .cin(1'b0), .value(mul_tree_12_178));
    assign mul_tree_12_179 = {mul_tree_12_178, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_180 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_181 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_182Core rtlzz_owner_182(.a(4'(mul_tree_12_180)), .b(4'(mul_tree_12_181)), .cin(1'b0), .value(mul_tree_12_182));
    assign mul_tree_12_183 = {mul_tree_12_182, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_184 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_185 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_186Core rtlzz_owner_186(.a(4'(mul_tree_12_184)), .b(4'(mul_tree_12_185)), .cin(1'b0), .value(mul_tree_12_186));
    assign mul_tree_12_187 = {mul_tree_12_186, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_188 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_189 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_190Core rtlzz_owner_190(.a(4'(mul_tree_12_188)), .b(4'(mul_tree_12_189)), .cin(1'b0), .value(mul_tree_12_190));
    assign mul_tree_12_191 = {mul_tree_12_190, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_192 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_193 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(4'(mul_tree_12_192)), .b(4'(mul_tree_12_193)), .cin(1'b0), .value(mul_tree_12_194));
    assign mul_tree_12_195 = {mul_tree_12_194, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_196 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_197 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(4'(mul_tree_12_196)), .b(4'(mul_tree_12_197)), .cin(1'b0), .value(mul_tree_12_198));
    assign mul_tree_12_199 = {mul_tree_12_198, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_200 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_201 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_202Core rtlzz_owner_202(.a(4'(mul_tree_12_200)), .b(4'(mul_tree_12_201)), .cin(1'b0), .value(mul_tree_12_202));
    assign mul_tree_12_203 = {mul_tree_12_202, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_204 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_205 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(4'(mul_tree_12_204)), .b(4'(mul_tree_12_205)), .cin(1'b0), .value(mul_tree_12_206));
    assign mul_tree_12_207 = {mul_tree_12_206, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_208 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_209 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_210Core rtlzz_owner_210(.a(4'(mul_tree_12_208)), .b(4'(mul_tree_12_209)), .cin(1'b0), .value(mul_tree_12_210));
    assign mul_tree_12_211 = {mul_tree_12_210, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_212 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_213 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_214Core rtlzz_owner_214(.a(4'(mul_tree_12_212)), .b(4'(mul_tree_12_213)), .cin(1'b0), .value(mul_tree_12_214));
    assign mul_tree_12_215 = {mul_tree_12_214, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_216 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_217 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(4'(mul_tree_12_216)), .b(4'(mul_tree_12_217)), .cin(1'b0), .value(mul_tree_12_218));
    assign mul_tree_12_219 = {mul_tree_12_218, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_220 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_221 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_222Core rtlzz_owner_222(.a(4'(mul_tree_12_220)), .b(4'(mul_tree_12_221)), .cin(1'b0), .value(mul_tree_12_222));
    assign mul_tree_12_223 = {mul_tree_12_222, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_224 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_225 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(4'(mul_tree_12_224)), .b(4'(mul_tree_12_225)), .cin(1'b0), .value(mul_tree_12_226));
    assign mul_tree_12_227 = {mul_tree_12_226, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_228 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_229 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(4'(mul_tree_12_228)), .b(4'(mul_tree_12_229)), .cin(1'b0), .value(mul_tree_12_230));
    assign mul_tree_12_231 = {mul_tree_12_230, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_232 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_233 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(4'(mul_tree_12_232)), .b(4'(mul_tree_12_233)), .cin(1'b0), .value(mul_tree_12_234));
    assign mul_tree_12_235 = {mul_tree_12_234, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_236 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_237 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(4'(mul_tree_12_236)), .b(4'(mul_tree_12_237)), .cin(1'b0), .value(mul_tree_12_238));
    assign mul_tree_12_239 = {mul_tree_12_238, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_240 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_241 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_242Core rtlzz_owner_242(.a(4'(mul_tree_12_240)), .b(4'(mul_tree_12_241)), .cin(1'b0), .value(mul_tree_12_242));
    assign mul_tree_12_243 = {mul_tree_12_242, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_244 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_245 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_246Core rtlzz_owner_246(.a(4'(mul_tree_12_244)), .b(4'(mul_tree_12_245)), .cin(1'b0), .value(mul_tree_12_246));
    assign mul_tree_12_247 = {mul_tree_12_246, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_248 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_249 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_250Core rtlzz_owner_250(.a(4'(mul_tree_12_248)), .b(4'(mul_tree_12_249)), .cin(1'b0), .value(mul_tree_12_250));
    assign mul_tree_12_251 = {mul_tree_12_250, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_252 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_253 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_254Core rtlzz_owner_254(.a(4'(mul_tree_12_252)), .b(4'(mul_tree_12_253)), .cin(1'b0), .value(mul_tree_12_254));
    assign mul_tree_12_255 = {mul_tree_12_254, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_256 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_257 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_258Core rtlzz_owner_258(.a(4'(mul_tree_12_256)), .b(4'(mul_tree_12_257)), .cin(1'b0), .value(mul_tree_12_258));
    assign mul_tree_12_259 = {mul_tree_12_258, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_260 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_261 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_262Core rtlzz_owner_262(.a(4'(mul_tree_12_260)), .b(4'(mul_tree_12_261)), .cin(1'b0), .value(mul_tree_12_262));
    assign mul_tree_12_263 = {mul_tree_12_262, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_264 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_265 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_266Core rtlzz_owner_266(.a(4'(mul_tree_12_264)), .b(4'(mul_tree_12_265)), .cin(1'b0), .value(mul_tree_12_266));
    assign mul_tree_12_267 = {mul_tree_12_266, 56'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_268 = ({5'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_269 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    assign mul_tree_12_271 = ({5'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_272 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    assign mul_tree_12_274 = ({5'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_275 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    assign mul_tree_12_277 = ({5'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_278 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    assign mul_tree_12_280 = ({5'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_281 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    assign mul_tree_12_283 = ({5'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_284 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    assign mul_tree_12_286 = ({5'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_287 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    assign mul_tree_12_289 = ({5'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_290 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    assign mul_tree_12_292 = ({5'h0, mul_tree_12_79}); // decl: <none>; prim: <none>
    assign mul_tree_12_293 = ({1'h0, mul_tree_12_83}); // decl: <none>; prim: <none>
    assign mul_tree_12_295 = ({5'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_296 = ({1'h0, mul_tree_12_91}); // decl: <none>; prim: <none>
    assign mul_tree_12_298 = ({5'h0, mul_tree_12_95}); // decl: <none>; prim: <none>
    assign mul_tree_12_299 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    assign mul_tree_12_301 = ({5'h0, mul_tree_12_103}); // decl: <none>; prim: <none>
    assign mul_tree_12_302 = ({1'h0, mul_tree_12_107}); // decl: <none>; prim: <none>
    assign mul_tree_12_304 = ({5'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_305 = ({1'h0, mul_tree_12_115}); // decl: <none>; prim: <none>
    assign mul_tree_12_307 = ({5'h0, mul_tree_12_119}); // decl: <none>; prim: <none>
    assign mul_tree_12_308 = ({1'h0, mul_tree_12_123}); // decl: <none>; prim: <none>
    assign mul_tree_12_310 = ({5'h0, mul_tree_12_127}); // decl: <none>; prim: <none>
    assign mul_tree_12_311 = ({1'h0, mul_tree_12_131}); // decl: <none>; prim: <none>
    assign mul_tree_12_313 = ({5'h0, mul_tree_12_135}); // decl: <none>; prim: <none>
    assign mul_tree_12_314 = ({1'h0, mul_tree_12_139}); // decl: <none>; prim: <none>
    assign mul_tree_12_316 = ({5'h0, mul_tree_12_143}); // decl: <none>; prim: <none>
    assign mul_tree_12_317 = ({1'h0, mul_tree_12_147}); // decl: <none>; prim: <none>
    assign mul_tree_12_319 = ({5'h0, mul_tree_12_151}); // decl: <none>; prim: <none>
    assign mul_tree_12_320 = ({1'h0, mul_tree_12_155}); // decl: <none>; prim: <none>
    assign mul_tree_12_322 = ({5'h0, mul_tree_12_159}); // decl: <none>; prim: <none>
    assign mul_tree_12_323 = ({1'h0, mul_tree_12_163}); // decl: <none>; prim: <none>
    assign mul_tree_12_325 = ({5'h0, mul_tree_12_167}); // decl: <none>; prim: <none>
    assign mul_tree_12_326 = ({1'h0, mul_tree_12_171}); // decl: <none>; prim: <none>
    assign mul_tree_12_328 = ({5'h0, mul_tree_12_175}); // decl: <none>; prim: <none>
    assign mul_tree_12_329 = ({1'h0, mul_tree_12_179}); // decl: <none>; prim: <none>
    assign mul_tree_12_331 = ({5'h0, mul_tree_12_183}); // decl: <none>; prim: <none>
    assign mul_tree_12_332 = ({1'h0, mul_tree_12_187}); // decl: <none>; prim: <none>
    assign mul_tree_12_334 = ({5'h0, mul_tree_12_191}); // decl: <none>; prim: <none>
    assign mul_tree_12_335 = ({1'h0, mul_tree_12_195}); // decl: <none>; prim: <none>
    assign mul_tree_12_337 = ({5'h0, mul_tree_12_199}); // decl: <none>; prim: <none>
    assign mul_tree_12_338 = ({1'h0, mul_tree_12_203}); // decl: <none>; prim: <none>
    assign mul_tree_12_340 = ({5'h0, mul_tree_12_207}); // decl: <none>; prim: <none>
    assign mul_tree_12_341 = ({1'h0, mul_tree_12_211}); // decl: <none>; prim: <none>
    assign mul_tree_12_343 = ({5'h0, mul_tree_12_215}); // decl: <none>; prim: <none>
    assign mul_tree_12_344 = ({1'h0, mul_tree_12_219}); // decl: <none>; prim: <none>
    assign mul_tree_12_346 = ({5'h0, mul_tree_12_223}); // decl: <none>; prim: <none>
    assign mul_tree_12_347 = ({1'h0, mul_tree_12_227}); // decl: <none>; prim: <none>
    assign mul_tree_12_349 = ({5'h0, mul_tree_12_231}); // decl: <none>; prim: <none>
    assign mul_tree_12_350 = ({1'h0, mul_tree_12_235}); // decl: <none>; prim: <none>
    assign mul_tree_12_352 = ({5'h0, mul_tree_12_239}); // decl: <none>; prim: <none>
    assign mul_tree_12_353 = ({1'h0, mul_tree_12_243}); // decl: <none>; prim: <none>
    assign mul_tree_12_355 = ({5'h0, mul_tree_12_247}); // decl: <none>; prim: <none>
    assign mul_tree_12_356 = ({1'h0, mul_tree_12_251}); // decl: <none>; prim: <none>
    assign mul_tree_12_358 = ({5'h0, mul_tree_12_255}); // decl: <none>; prim: <none>
    assign mul_tree_12_359 = ({1'h0, mul_tree_12_259}); // decl: <none>; prim: <none>
    assign mul_tree_12_361 = ({5'h0, mul_tree_12_263}); // decl: <none>; prim: <none>
    assign mul_tree_12_362 = ({1'h0, mul_tree_12_267}); // decl: <none>; prim: <none>
    assign mul_tree_12_364 = ({9'h0, mul_tree_12_270}); // decl: <none>; prim: <none>
    assign mul_tree_12_365 = ({1'h0, mul_tree_12_273}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366_reduce rtlzz_reduce_366(.i15(mul_tree_12_15), .i18(mul_tree_12_18), .i22(mul_tree_12_22), .i26(mul_tree_12_26), .y(mul_tree_12_366));
    assign mul_tree_12_367 = ({9'h0, mul_tree_12_276}); // decl: <none>; prim: <none>
    assign mul_tree_12_368 = ({1'h0, mul_tree_12_279}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369_reduce rtlzz_reduce_369(.i30(mul_tree_12_30), .i34(mul_tree_12_34), .i38(mul_tree_12_38), .i42(mul_tree_12_42), .y(mul_tree_12_369));
    assign mul_tree_12_370 = ({9'h0, mul_tree_12_282}); // decl: <none>; prim: <none>
    assign mul_tree_12_371 = ({1'h0, mul_tree_12_285}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_372_reduce rtlzz_reduce_372(.i46(mul_tree_12_46), .i50(mul_tree_12_50), .i54(mul_tree_12_54), .i58(mul_tree_12_58), .y(mul_tree_12_372));
    assign mul_tree_12_373 = ({9'h0, mul_tree_12_288}); // decl: <none>; prim: <none>
    assign mul_tree_12_374 = ({1'h0, mul_tree_12_291}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_375_reduce rtlzz_reduce_375(.i62(mul_tree_12_62), .i66(mul_tree_12_66), .i70(mul_tree_12_70), .i74(mul_tree_12_74), .y(mul_tree_12_375));
    assign mul_tree_12_376 = ({9'h0, mul_tree_12_294}); // decl: <none>; prim: <none>
    assign mul_tree_12_377 = ({1'h0, mul_tree_12_297}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_378_reduce rtlzz_reduce_378(.i78(mul_tree_12_78), .i82(mul_tree_12_82), .i86(mul_tree_12_86), .i90(mul_tree_12_90), .y(mul_tree_12_378));
    assign mul_tree_12_379 = ({9'h0, mul_tree_12_300}); // decl: <none>; prim: <none>
    assign mul_tree_12_380 = ({1'h0, mul_tree_12_303}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_381_reduce rtlzz_reduce_381(.i94(mul_tree_12_94), .i98(mul_tree_12_98), .i102(mul_tree_12_102), .i106(mul_tree_12_106), .y(mul_tree_12_381));
    assign mul_tree_12_382 = ({9'h0, mul_tree_12_306}); // decl: <none>; prim: <none>
    assign mul_tree_12_383 = ({1'h0, mul_tree_12_309}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_384_reduce rtlzz_reduce_384(.i110(mul_tree_12_110), .i114(mul_tree_12_114), .i118(mul_tree_12_118), .i122(mul_tree_12_122), .y(mul_tree_12_384));
    assign mul_tree_12_385 = ({9'h0, mul_tree_12_312}); // decl: <none>; prim: <none>
    assign mul_tree_12_386 = ({1'h0, mul_tree_12_315}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387_reduce rtlzz_reduce_387(.i126(mul_tree_12_126), .i130(mul_tree_12_130), .i134(mul_tree_12_134), .i138(mul_tree_12_138), .y(mul_tree_12_387));
    assign mul_tree_12_388 = ({9'h0, mul_tree_12_318}); // decl: <none>; prim: <none>
    assign mul_tree_12_389 = ({1'h0, mul_tree_12_321}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_390_reduce rtlzz_reduce_390(.i142(mul_tree_12_142), .i146(mul_tree_12_146), .i150(mul_tree_12_150), .i154(mul_tree_12_154), .y(mul_tree_12_390));
    assign mul_tree_12_391 = ({9'h0, mul_tree_12_324}); // decl: <none>; prim: <none>
    assign mul_tree_12_392 = ({1'h0, mul_tree_12_327}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_393_reduce rtlzz_reduce_393(.i158(mul_tree_12_158), .i162(mul_tree_12_162), .i166(mul_tree_12_166), .i170(mul_tree_12_170), .y(mul_tree_12_393));
    assign mul_tree_12_394 = ({9'h0, mul_tree_12_330}); // decl: <none>; prim: <none>
    assign mul_tree_12_395 = ({1'h0, mul_tree_12_333}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_396_reduce rtlzz_reduce_396(.i174(mul_tree_12_174), .i178(mul_tree_12_178), .i182(mul_tree_12_182), .i186(mul_tree_12_186), .y(mul_tree_12_396));
    assign mul_tree_12_397 = ({9'h0, mul_tree_12_336}); // decl: <none>; prim: <none>
    assign mul_tree_12_398 = ({1'h0, mul_tree_12_339}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_399_reduce rtlzz_reduce_399(.i190(mul_tree_12_190), .i194(mul_tree_12_194), .i198(mul_tree_12_198), .i202(mul_tree_12_202), .y(mul_tree_12_399));
    assign mul_tree_12_400 = ({9'h0, mul_tree_12_342}); // decl: <none>; prim: <none>
    assign mul_tree_12_401 = ({1'h0, mul_tree_12_345}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_402_reduce rtlzz_reduce_402(.i206(mul_tree_12_206), .i210(mul_tree_12_210), .i214(mul_tree_12_214), .i218(mul_tree_12_218), .y(mul_tree_12_402));
    assign mul_tree_12_403 = ({9'h0, mul_tree_12_348}); // decl: <none>; prim: <none>
    assign mul_tree_12_404 = ({1'h0, mul_tree_12_351}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405_reduce rtlzz_reduce_405(.i222(mul_tree_12_222), .i226(mul_tree_12_226), .i230(mul_tree_12_230), .i234(mul_tree_12_234), .y(mul_tree_12_405));
    assign mul_tree_12_406 = ({9'h0, mul_tree_12_354}); // decl: <none>; prim: <none>
    assign mul_tree_12_407 = ({1'h0, mul_tree_12_357}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_408_reduce rtlzz_reduce_408(.i238(mul_tree_12_238), .i242(mul_tree_12_242), .i246(mul_tree_12_246), .i250(mul_tree_12_250), .y(mul_tree_12_408));
    assign mul_tree_12_409 = ({9'h0, mul_tree_12_360}); // decl: <none>; prim: <none>
    assign mul_tree_12_410 = ({1'h0, mul_tree_12_363}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_411_reduce rtlzz_reduce_411(.i254(mul_tree_12_254), .i258(mul_tree_12_258), .i262(mul_tree_12_262), .i266(mul_tree_12_266), .y(mul_tree_12_411));
    assign mul_tree_12_412 = ({17'h0, rtlzz_pipe_366_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_413 = ({1'h0, rtlzz_pipe_369_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_414Core rtlzz_owner_414(.a(22'(mul_tree_12_412)), .b(38'(mul_tree_12_413)), .cin(1'h0), .value(mul_tree_12_414));
    assign mul_tree_12_415 = ({17'h0, rtlzz_pipe_372_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_416 = ({1'h0, rtlzz_pipe_375_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_417Core rtlzz_owner_417(.a(26'(mul_tree_12_415)), .b(42'(mul_tree_12_416)), .cin(1'h0), .value(mul_tree_12_417));
    assign mul_tree_12_418 = ({17'h0, rtlzz_pipe_378_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_419 = ({1'h0, rtlzz_pipe_381_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_420Core rtlzz_owner_420(.a(30'(mul_tree_12_418)), .b(46'(mul_tree_12_419)), .cin(1'h0), .value(mul_tree_12_420));
    assign mul_tree_12_421 = ({17'h0, rtlzz_pipe_384_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_422 = ({1'h0, rtlzz_pipe_387_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(34'(mul_tree_12_421)), .b(50'(mul_tree_12_422)), .cin(1'h0), .value(mul_tree_12_423));
    assign mul_tree_12_424 = ({17'h0, rtlzz_pipe_390_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_425 = ({1'h0, rtlzz_pipe_393_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_426Core rtlzz_owner_426(.a(38'(mul_tree_12_424)), .b(54'(mul_tree_12_425)), .cin(1'h0), .value(mul_tree_12_426));
    assign mul_tree_12_427 = ({17'h0, rtlzz_pipe_396_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_428 = ({1'h0, rtlzz_pipe_399_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_429Core rtlzz_owner_429(.a(42'(mul_tree_12_427)), .b(58'(mul_tree_12_428)), .cin(1'h0), .value(mul_tree_12_429));
    assign mul_tree_12_430 = ({17'h0, rtlzz_pipe_402_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_431 = ({1'h0, rtlzz_pipe_405_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_432Core rtlzz_owner_432(.a(46'(mul_tree_12_430)), .b(62'(mul_tree_12_431)), .cin(1'h0), .value(mul_tree_12_432));
    assign mul_tree_12_433 = ({17'h0, rtlzz_pipe_408_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_434 = ({1'h0, rtlzz_pipe_411_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_435Core rtlzz_owner_435(.a(50'(mul_tree_12_433)), .b(66'(mul_tree_12_434)), .cin(1'h0), .value(mul_tree_12_435[63:0]));
    assign mul_tree_12_435[66:64] = '0;
    assign mul_tree_12_436 = ({5'h0, rtlzz_pipe_414_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_437 = ({1'h0, rtlzz_pipe_417_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_439 = ({5'h0, rtlzz_pipe_420_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_440 = ({1'h0, rtlzz_pipe_423_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_442 = ({5'h0, rtlzz_pipe_426_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_443 = ({1'h0, rtlzz_pipe_429_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_445 = ({5'h0, rtlzz_pipe_432_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_446 = ({1'h0, rtlzz_pipe_435_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_448 = ({9'h0, mul_tree_12_438}); // decl: <none>; prim: <none>
    assign mul_tree_12_449 = ({1'h0, mul_tree_12_441}); // decl: <none>; prim: <none>
    assign mul_tree_12_451 = ({9'h0, mul_tree_12_444}); // decl: <none>; prim: <none>
    assign mul_tree_12_452 = ({1'h0, mul_tree_12_447}); // decl: <none>; prim: <none>
    assign mul_tree_12_454 = ({17'h0, mul_tree_12_450}); // decl: <none>; prim: <none>
    assign mul_tree_12_455 = ({1'h0, mul_tree_12_453}); // decl: <none>; prim: <none>
    assign mul_tree_12_457 = mul_tree_12_456[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_366_s1 <= 22'h0;
            rtlzz_pipe_369_s1 <= 38'h0;
            rtlzz_pipe_372_s1 <= 26'h0;
            rtlzz_pipe_375_s1 <= 42'h0;
            rtlzz_pipe_378_s1 <= 30'h0;
            rtlzz_pipe_381_s1 <= 46'h0;
            rtlzz_pipe_384_s1 <= 34'h0;
            rtlzz_pipe_387_s1 <= 50'h0;
            rtlzz_pipe_390_s1 <= 38'h0;
            rtlzz_pipe_393_s1 <= 54'h0;
            rtlzz_pipe_396_s1 <= 42'h0;
            rtlzz_pipe_399_s1 <= 58'h0;
            rtlzz_pipe_402_s1 <= 46'h0;
            rtlzz_pipe_405_s1 <= 62'h0;
            rtlzz_pipe_408_s1 <= 50'h0;
            rtlzz_pipe_411_s1 <= 66'h0;
            rtlzz_pipe_414_s2 <= 39'h0;
            rtlzz_pipe_417_s2 <= 43'h0;
            rtlzz_pipe_420_s2 <= 47'h0;
            rtlzz_pipe_423_s2 <= 51'h0;
            rtlzz_pipe_426_s2 <= 55'h0;
            rtlzz_pipe_429_s2 <= 59'h0;
            rtlzz_pipe_432_s2 <= 63'h0;
            rtlzz_pipe_435_s2 <= 67'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_366_s1 <= mul_tree_12_366; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_369_s1 <= mul_tree_12_369; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_372_s1 <= mul_tree_12_372; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_375_s1 <= mul_tree_12_375; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_378_s1 <= mul_tree_12_378; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_381_s1 <= mul_tree_12_381; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_384_s1 <= mul_tree_12_384; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_387_s1 <= mul_tree_12_387; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_390_s1 <= mul_tree_12_390; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_393_s1 <= mul_tree_12_393; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_396_s1 <= mul_tree_12_396; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_399_s1 <= mul_tree_12_399; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_402_s1 <= mul_tree_12_402; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_405_s1 <= mul_tree_12_405; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_408_s1 <= mul_tree_12_408; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_411_s1 <= mul_tree_12_411; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_414_s2 <= mul_tree_12_414; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_417_s2 <= mul_tree_12_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_420_s2 <= mul_tree_12_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_423_s2 <= mul_tree_12_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_426_s2 <= mul_tree_12_426; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_429_s2 <= mul_tree_12_429; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_432_s2 <= mul_tree_12_432; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_435_s2 <= mul_tree_12_435; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5_reduce(input wire [63:0] i459, input wire [38:0] i476, input wire [42:0] i477, input wire [46:0] i478, input wire [50:0] i479, input wire [54:0] i480, input wire [58:0] i481, input wire [62:0] i482, input wire [66:0] i483, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i476[38], i476[37], i476[36], i476[35], i476[34], i476[33], i476[32], i476[31], i476[30], i476[29], i476[28], i476[27], i476[26], i476[25], i476[24], i476[23], i476[22], i476[21], i476[20], i476[19], i476[18], i476[17], i476[16], i476[15], i476[14], i476[13], i476[12], i476[11], i476[10], i476[9], i476[8], i476[7], i476[6], i476[5], i476[4], i476[3], i476[2], i476[1], i476[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i477[42], i477[41], i477[40], i477[39], i477[38], i477[37], i477[36], i477[35], i477[34], i477[33], i477[32], i477[31], i477[30], i477[29], i477[28], i477[27], i477[26], i477[25], i477[24], i477[23], i477[22], i477[21], i477[20], i477[19], i477[18], i477[17], i477[16], i477[15], i477[14], i477[13], i477[12], i477[11], i477[10], i477[9], i477[8], i477[7], i477[6], i477[5], i477[4], i477[3], i477[2], i477[1], i477[0]};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i478[46], i478[45], i478[44], i478[43], i478[42], i478[41], i478[40], i478[39], i478[38], i478[37], i478[36], i478[35], i478[34], i478[33], i478[32], i478[31], i478[30], i478[29], i478[28], i478[27], i478[26], i478[25], i478[24], i478[23], i478[22], i478[21], i478[20], i478[19], i478[18], i478[17], i478[16], i478[15], i478[14], i478[13], i478[12], i478[11], i478[10], i478[9], i478[8], i478[7], i478[6], i478[5], i478[4], i478[3], i478[2], i478[1], i478[0]};
wire [63:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i479[50], i479[49], i479[48], i479[47], i479[46], i479[45], i479[44], i479[43], i479[42], i479[41], i479[40], i479[39], i479[38], i479[37], i479[36], i479[35], i479[34], i479[33], i479[32], i479[31], i479[30], i479[29], i479[28], i479[27], i479[26], i479[25], i479[24], i479[23], i479[22], i479[21], i479[20], i479[19], i479[18], i479[17], i479[16], i479[15], i479[14], i479[13], i479[12], i479[11], i479[10], i479[9], i479[8], i479[7], i479[6], i479[5], i479[4], i479[3], i479[2], i479[1], i479[0]};
wire [63:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i480[54], i480[53], i480[52], i480[51], i480[50], i480[49], i480[48], i480[47], i480[46], i480[45], i480[44], i480[43], i480[42], i480[41], i480[40], i480[39], i480[38], i480[37], i480[36], i480[35], i480[34], i480[33], i480[32], i480[31], i480[30], i480[29], i480[28], i480[27], i480[26], i480[25], i480[24], i480[23], i480[22], i480[21], i480[20], i480[19], i480[18], i480[17], i480[16], i480[15], i480[14], i480[13], i480[12], i480[11], i480[10], i480[9], i480[8], i480[7], i480[6], i480[5], i480[4], i480[3], i480[2], i480[1], i480[0]};
wire [63:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i481[58], i481[57], i481[56], i481[55], i481[54], i481[53], i481[52], i481[51], i481[50], i481[49], i481[48], i481[47], i481[46], i481[45], i481[44], i481[43], i481[42], i481[41], i481[40], i481[39], i481[38], i481[37], i481[36], i481[35], i481[34], i481[33], i481[32], i481[31], i481[30], i481[29], i481[28], i481[27], i481[26], i481[25], i481[24], i481[23], i481[22], i481[21], i481[20], i481[19], i481[18], i481[17], i481[16], i481[15], i481[14], i481[13], i481[12], i481[11], i481[10], i481[9], i481[8], i481[7], i481[6], i481[5], i481[4], i481[3], i481[2], i481[1], i481[0]};
wire [63:0] t6 = {1'b0, i482[62], i482[61], i482[60], i482[59], i482[58], i482[57], i482[56], i482[55], i482[54], i482[53], i482[52], i482[51], i482[50], i482[49], i482[48], i482[47], i482[46], i482[45], i482[44], i482[43], i482[42], i482[41], i482[40], i482[39], i482[38], i482[37], i482[36], i482[35], i482[34], i482[33], i482[32], i482[31], i482[30], i482[29], i482[28], i482[27], i482[26], i482[25], i482[24], i482[23], i482[22], i482[21], i482[20], i482[19], i482[18], i482[17], i482[16], i482[15], i482[14], i482[13], i482[12], i482[11], i482[10], i482[9], i482[8], i482[7], i482[6], i482[5], i482[4], i482[3], i482[2], i482[1], i482[0]};
wire [63:0] t7 = {i483[63], i483[62], i483[61], i483[60], i483[59], i483[58], i483[57], i483[56], i483[55], i483[54], i483[53], i483[52], i483[51], i483[50], i483[49], i483[48], i483[47], i483[46], i483[45], i483[44], i483[43], i483[42], i483[41], i483[40], i483[39], i483[38], i483[37], i483[36], i483[35], i483[34], i483[33], i483[32], i483[31], i483[30], i483[29], i483[28], i483[27], i483[26], i483[25], i483[24], i483[23], i483[22], i483[21], i483[20], i483[19], i483[18], i483[17], i483[16], i483[15], i483[14], i483[13], i483[12], i483[11], i483[10], i483[9], i483[8], i483[7], i483[6], i483[5], i483[4], i483[3], i483[2], i483[1], i483[0]};
wire [63:0] t8 = {i459[63], i459[62], i459[61], i459[60], i459[59], i459[58], i459[57], i459[56], i459[55], i459[54], i459[53], i459[52], i459[51], i459[50], i459[49], i459[48], i459[47], i459[46], i459[45], i459[44], i459[43], i459[42], i459[41], i459[40], i459[39], i459[38], i459[37], i459[36], i459[35], i459[34], i459[33], i459[32], i459[31], i459[30], i459[29], i459[28], i459[27], i459[26], i459[25], i459[24], i459[23], i459[22], i459[21], i459[20], i459[19], i459[18], i459[17], i459[16], i459[15], i459[14], i459[13], i459[12], i459[11], i459[10], i459[9], i459[8], i459[7], i459[6], i459[5], i459[4], i459[3], i459[2], i459[1], i459[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366_reduce(input wire [7:0] i15, input wire [7:0] i18, input wire [7:0] i22, input wire [7:0] i26, output wire [21:0] y);
wire [21:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i15[7], i15[6], i15[5], i15[4], i15[3], i15[2], i15[1], i15[0]};
wire [21:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i18[7], i18[6], i18[5], i18[4], i18[3], i18[2], i18[1], i18[0], 1'b0, 1'b0, 1'b0, 1'b0};
wire [21:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i22[7], i22[6], i22[5], i22[4], i22[3], i22[2], i22[1], i22[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [21:0] t3 = {1'b0, 1'b0, i26[7], i26[6], i26[5], i26[4], i26[3], i26[2], i26[1], i26[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [21:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369_reduce(input wire [7:0] i30, input wire [7:0] i34, input wire [7:0] i38, input wire [7:0] i42, output wire [37:0] y);
wire [37:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i30[7], i30[6], i30[5], i30[4], i30[3], i30[2], i30[1], i30[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i34[7], i34[6], i34[5], i34[4], i34[3], i34[2], i34[1], i34[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i38[7], i38[6], i38[5], i38[4], i38[3], i38[2], i38[1], i38[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t3 = {1'b0, 1'b0, i42[7], i42[6], i42[5], i42[4], i42[3], i42[2], i42[1], i42[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_372_reduce(input wire [7:0] i46, input wire [7:0] i50, input wire [7:0] i54, input wire [7:0] i58, output wire [25:0] y);
wire [25:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i46[7], i46[6], i46[5], i46[4], i46[3], i46[2], i46[1], i46[0], 1'b0, 1'b0, 1'b0, 1'b0};
wire [25:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i50[7], i50[6], i50[5], i50[4], i50[3], i50[2], i50[1], i50[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [25:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i54[7], i54[6], i54[5], i54[4], i54[3], i54[2], i54[1], i54[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [25:0] t3 = {1'b0, 1'b0, i58[7], i58[6], i58[5], i58[4], i58[3], i58[2], i58[1], i58[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [25:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_375_reduce(input wire [7:0] i62, input wire [7:0] i66, input wire [7:0] i70, input wire [7:0] i74, output wire [41:0] y);
wire [41:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i62[7], i62[6], i62[5], i62[4], i62[3], i62[2], i62[1], i62[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i66[7], i66[6], i66[5], i66[4], i66[3], i66[2], i66[1], i66[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i70[7], i70[6], i70[5], i70[4], i70[3], i70[2], i70[1], i70[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t3 = {1'b0, 1'b0, i74[7], i74[6], i74[5], i74[4], i74[3], i74[2], i74[1], i74[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_378_reduce(input wire [7:0] i78, input wire [7:0] i82, input wire [7:0] i86, input wire [7:0] i90, output wire [29:0] y);
wire [29:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i78[7], i78[6], i78[5], i78[4], i78[3], i78[2], i78[1], i78[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [29:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i82[7], i82[6], i82[5], i82[4], i82[3], i82[2], i82[1], i82[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [29:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i86[7], i86[6], i86[5], i86[4], i86[3], i86[2], i86[1], i86[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [29:0] t3 = {1'b0, 1'b0, i90[7], i90[6], i90[5], i90[4], i90[3], i90[2], i90[1], i90[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [29:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381_reduce(input wire [7:0] i94, input wire [7:0] i98, input wire [7:0] i102, input wire [7:0] i106, output wire [45:0] y);
wire [45:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i94[7], i94[6], i94[5], i94[4], i94[3], i94[2], i94[1], i94[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i98[7], i98[6], i98[5], i98[4], i98[3], i98[2], i98[1], i98[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i102[7], i102[6], i102[5], i102[4], i102[3], i102[2], i102[1], i102[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t3 = {1'b0, 1'b0, i106[7], i106[6], i106[5], i106[4], i106[3], i106[2], i106[1], i106[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384_reduce(input wire [7:0] i110, input wire [7:0] i114, input wire [7:0] i118, input wire [7:0] i122, output wire [33:0] y);
wire [33:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i110[7], i110[6], i110[5], i110[4], i110[3], i110[2], i110[1], i110[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [33:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i114[7], i114[6], i114[5], i114[4], i114[3], i114[2], i114[1], i114[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [33:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i118[7], i118[6], i118[5], i118[4], i118[3], i118[2], i118[1], i118[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [33:0] t3 = {1'b0, 1'b0, i122[7], i122[6], i122[5], i122[4], i122[3], i122[2], i122[1], i122[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [33:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387_reduce(input wire [7:0] i126, input wire [7:0] i130, input wire [7:0] i134, input wire [7:0] i138, output wire [49:0] y);
wire [49:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i126[7], i126[6], i126[5], i126[4], i126[3], i126[2], i126[1], i126[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i130[7], i130[6], i130[5], i130[4], i130[3], i130[2], i130[1], i130[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i134[7], i134[6], i134[5], i134[4], i134[3], i134[2], i134[1], i134[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t3 = {1'b0, 1'b0, i138[7], i138[6], i138[5], i138[4], i138[3], i138[2], i138[1], i138[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390_reduce(input wire [7:0] i142, input wire [7:0] i146, input wire [7:0] i150, input wire [7:0] i154, output wire [37:0] y);
wire [37:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i142[7], i142[6], i142[5], i142[4], i142[3], i142[2], i142[1], i142[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i146[7], i146[6], i146[5], i146[4], i146[3], i146[2], i146[1], i146[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i150[7], i150[6], i150[5], i150[4], i150[3], i150[2], i150[1], i150[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] t3 = {1'b0, 1'b0, i154[7], i154[6], i154[5], i154[4], i154[3], i154[2], i154[1], i154[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [37:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393_reduce(input wire [7:0] i158, input wire [7:0] i162, input wire [7:0] i166, input wire [7:0] i170, output wire [53:0] y);
wire [53:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i158[7], i158[6], i158[5], i158[4], i158[3], i158[2], i158[1], i158[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [53:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i162[7], i162[6], i162[5], i162[4], i162[3], i162[2], i162[1], i162[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [53:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i166[7], i166[6], i166[5], i166[4], i166[3], i166[2], i166[1], i166[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [53:0] t3 = {1'b0, 1'b0, i170[7], i170[6], i170[5], i170[4], i170[3], i170[2], i170[1], i170[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [53:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_396_reduce(input wire [7:0] i174, input wire [7:0] i178, input wire [7:0] i182, input wire [7:0] i186, output wire [41:0] y);
wire [41:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i174[7], i174[6], i174[5], i174[4], i174[3], i174[2], i174[1], i174[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i178[7], i178[6], i178[5], i178[4], i178[3], i178[2], i178[1], i178[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i182[7], i182[6], i182[5], i182[4], i182[3], i182[2], i182[1], i182[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] t3 = {1'b0, 1'b0, i186[7], i186[6], i186[5], i186[4], i186[3], i186[2], i186[1], i186[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [41:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_399_reduce(input wire [7:0] i190, input wire [7:0] i194, input wire [7:0] i198, input wire [7:0] i202, output wire [57:0] y);
wire [57:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i190[7], i190[6], i190[5], i190[4], i190[3], i190[2], i190[1], i190[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i194[7], i194[6], i194[5], i194[4], i194[3], i194[2], i194[1], i194[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i198[7], i198[6], i198[5], i198[4], i198[3], i198[2], i198[1], i198[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] t3 = {1'b0, 1'b0, i202[7], i202[6], i202[5], i202[4], i202[3], i202[2], i202[1], i202[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [57:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402_reduce(input wire [7:0] i206, input wire [7:0] i210, input wire [7:0] i214, input wire [7:0] i218, output wire [45:0] y);
wire [45:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i206[7], i206[6], i206[5], i206[4], i206[3], i206[2], i206[1], i206[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i210[7], i210[6], i210[5], i210[4], i210[3], i210[2], i210[1], i210[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i214[7], i214[6], i214[5], i214[4], i214[3], i214[2], i214[1], i214[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] t3 = {1'b0, 1'b0, i218[7], i218[6], i218[5], i218[4], i218[3], i218[2], i218[1], i218[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [45:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405_reduce(input wire [7:0] i222, input wire [7:0] i226, input wire [7:0] i230, input wire [7:0] i234, output wire [61:0] y);
wire [61:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i222[7], i222[6], i222[5], i222[4], i222[3], i222[2], i222[1], i222[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [61:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i226[7], i226[6], i226[5], i226[4], i226[3], i226[2], i226[1], i226[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [61:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i230[7], i230[6], i230[5], i230[4], i230[3], i230[2], i230[1], i230[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [61:0] t3 = {1'b0, 1'b0, i234[7], i234[6], i234[5], i234[4], i234[3], i234[2], i234[1], i234[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [61:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408_reduce(input wire [7:0] i238, input wire [7:0] i242, input wire [7:0] i246, input wire [7:0] i250, output wire [49:0] y);
wire [49:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i238[7], i238[6], i238[5], i238[4], i238[3], i238[2], i238[1], i238[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i242[7], i242[6], i242[5], i242[4], i242[3], i242[2], i242[1], i242[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i246[7], i246[6], i246[5], i246[4], i246[3], i246[2], i246[1], i246[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] t3 = {1'b0, 1'b0, i250[7], i250[6], i250[5], i250[4], i250[3], i250[2], i250[1], i250[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [49:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_411_reduce(input wire [7:0] i254, input wire [7:0] i258, input wire [7:0] i262, input wire [7:0] i266, output wire [65:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i254[7], i254[6], i254[5], i254[4], i254[3], i254[2], i254[1], i254[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i258[7], i258[6], i258[5], i258[4], i258[3], i258[2], i258[1], i258[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, i262[7], i262[6], i262[5], i262[4], i262[3], i262[2], i262[1], i262[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] t3 = {i266[7], i266[6], i266[5], i266[4], i266[3], i266[2], i266[1], i266[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [63:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_414Core(input wire [21:0] a,input wire [37:0] b,input wire cin,output wire [38:0] value);
wire [21:0] masked_a=((a&22'h3fffff)|22'h0);
wire [37:0] masked_b=((b&38'h3fffffffff)|38'h0);
wire [38:0] aa=39'(masked_b);
wire [38:0] bb=39'(masked_a);
wire [39:0] extended={1'b0,aa}+{1'b0,bb}+40'(1'b0);
wire [38:0] native_value=extended[38:0];
assign value=native_value[0+:39];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_414();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_417Core(input wire [25:0] a,input wire [41:0] b,input wire cin,output wire [42:0] value);
wire [25:0] masked_a=((a&26'h3ffffff)|26'h0);
wire [41:0] masked_b=((b&42'h3ffffffffff)|42'h0);
wire [42:0] aa=43'(masked_b);
wire [42:0] bb=43'(masked_a);
wire [43:0] extended={1'b0,aa}+{1'b0,bb}+44'(1'b0);
wire [42:0] native_value=extended[42:0];
assign value=native_value[0+:43];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_417();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_420Core(input wire [29:0] a,input wire [45:0] b,input wire cin,output wire [46:0] value);
wire [29:0] masked_a=((a&30'h3fffffff)|30'h0);
wire [45:0] masked_b=((b&46'h3fffffffffff)|46'h0);
wire [46:0] aa=47'(masked_b);
wire [46:0] bb=47'(masked_a);
wire [47:0] extended={1'b0,aa}+{1'b0,bb}+48'(1'b0);
wire [46:0] native_value=extended[46:0];
assign value=native_value[0+:47];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_420();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [33:0] a,input wire [49:0] b,input wire cin,output wire [50:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [49:0] masked_b=((b&50'h3ffffffffffff)|50'h0);
wire [50:0] aa=51'(masked_b);
wire [50:0] bb=51'(masked_a);
wire [51:0] extended={1'b0,aa}+{1'b0,bb}+52'(1'b0);
wire [50:0] native_value=extended[50:0];
assign value=native_value[0+:51];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426Core(input wire [37:0] a,input wire [53:0] b,input wire cin,output wire [54:0] value);
wire [37:0] masked_a=((a&38'h3fffffffff)|38'h0);
wire [53:0] masked_b=((b&54'h3fffffffffffff)|54'h0);
wire [54:0] aa=55'(masked_b);
wire [54:0] bb=55'(masked_a);
wire [55:0] extended={1'b0,aa}+{1'b0,bb}+56'(1'b0);
wire [54:0] native_value=extended[54:0];
assign value=native_value[0+:55];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_426();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_429Core(input wire [41:0] a,input wire [57:0] b,input wire cin,output wire [58:0] value);
wire [41:0] masked_a=((a&42'h3ffffffffff)|42'h0);
wire [57:0] masked_b=((b&58'h3ffffffffffffff)|58'h0);
wire [58:0] aa=59'(masked_b);
wire [58:0] bb=59'(masked_a);
wire [59:0] extended={1'b0,aa}+{1'b0,bb}+60'(1'b0);
wire [58:0] native_value=extended[58:0];
assign value=native_value[0+:59];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_429();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432Core(input wire [45:0] a,input wire [61:0] b,input wire cin,output wire [62:0] value);
wire [45:0] masked_a=((a&46'h3fffffffffff)|46'h0);
wire [61:0] masked_b=((b&62'h3fffffffffffffff)|62'h0);
wire [62:0] aa=63'(masked_b);
wire [62:0] bb=63'(masked_a);
wire [63:0] extended={1'b0,aa}+{1'b0,bb}+64'(1'b0);
wire [62:0] native_value=extended[62:0];
assign value=native_value[0+:63];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_432();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_435Core(input wire [49:0] a,input wire [65:0] b,input wire cin,output wire [63:0] value);
wire [49:0] masked_a=((a&50'h3ffffffffffff)|50'h0);
wire [65:0] masked_b=((b&66'h3ffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_b);
wire [65:0] bb=66'(masked_a);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_435();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
