`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [3:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_122; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_123; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_124; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_125; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_126; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_127; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_128; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_129; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_130; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_131; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_132; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_133; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_134; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_135; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_136; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_137; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_138; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_139; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_140; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_141; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_142; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_143; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_144; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_145; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_146; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_147; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_148; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_149; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_150; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_151; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_152; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_153; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_154; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_155; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_156; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_157; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_158; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_159; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_160; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_161; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_162; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_163; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_164; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_165; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_166; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_167; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_168; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_169; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_170; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_171; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_172; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_173; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_174; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_12_175; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_176; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_177; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_178; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_179; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_180; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_181; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_182; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_183; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_184; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_185; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_186; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_187; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_188; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_189; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_190; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_191; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_192; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_193; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_194; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_195; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_196; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_197; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_198; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_199; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_200; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_201; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_202; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_203; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_204; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_205; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_206; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_207; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_208; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_209; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_210; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_211; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_212; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_213; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_214; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_215; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_216; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_217; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_218; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_219; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_220; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_221; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_222; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_223; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_224; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_225; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_226; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_227; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_228; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_229; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_230; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_231; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_232; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_233; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_234; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_235; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_236; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_237; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_238; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_239; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_240; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_241; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_242; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_243; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_244; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_245; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_246; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_247; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_248; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_249; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_250; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_251; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_252; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_253; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_254; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_255; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_256; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_257; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_258; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_259; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_260; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_261; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_262; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_263; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_264; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_265; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_266; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_267; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_268; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_269; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_270; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_271; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_272; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_273; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_274; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_275; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_276; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_277; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_278; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_279; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_280; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_281; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_282; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_283; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_284; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_285; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_286; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_287; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_288; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_289; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_290; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_291; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_292; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_293; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_12_294; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_295; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_296; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_297; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_298; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_299; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_300; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_301; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_302; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_303; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_304; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_305; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_306; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_307; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_308; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_309; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_310; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_311; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_312; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_313; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_314; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_315; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_316; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_317; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_12_318; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_319; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_320; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_321; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_322; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_323; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_324; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_325; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_326; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_327; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_328; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_329; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_330; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_331; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_332; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_333; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_334; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_335; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_336; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_337; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_338; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_339; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_340; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_341; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_342; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_343; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_344; // decl: <none>; prim: <none>
    logic [44:0] mul_tree_12_345; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_346; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_347; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_348; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_349; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_350; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_351; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_352; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_353; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_354; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_355; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_356; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_357; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_358; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_359; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_360; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_361; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_362; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_363; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_364; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_365; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_12_366; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_367; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_368; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_369; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_370; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_371; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_372; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_373; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_374; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_375; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_376; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_377; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_378; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_379; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_380; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_381; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_382; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_383; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_12_384; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_385; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_386; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_387; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_388; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_389; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_390; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_391; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_392; // decl: <none>; prim: <none>
    logic [53:0] mul_tree_12_393; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_394; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_395; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_396; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_397; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_398; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_399; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_400; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_401; // decl: <none>; prim: <none>
    logic [45:0] mul_tree_12_402; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_403; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_404; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_405; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_406; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_407; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_408; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_409; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_410; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_411; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_412; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_413; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_414; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_415; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_416; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_417; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_418; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_419; // decl: <none>; prim: <none>
    logic [46:0] mul_tree_12_420; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_421; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_422; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_423; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_424; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_425; // decl: <none>; prim: <none>
    logic [54:0] mul_tree_12_426; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_427; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_428; // decl: <none>; prim: <none>
    logic [58:0] mul_tree_12_429; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_430; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_431; // decl: <none>; prim: <none>
    logic [62:0] mul_tree_12_432; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_433; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_434; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_435; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_436; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_437; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_438; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_439; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_440; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_441; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_442; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_443; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_444; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_445; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_446; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_447; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_448; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_449; // decl: <none>; prim: <none>
    logic [52:0] mul_tree_12_450; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_451; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_452; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_12_453; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_454; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_455; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_12_456; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_457; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [12:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_276_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_282_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_285_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_288_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_291_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_294_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_297_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_300_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_303_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_306_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_309_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_312_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_315_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_318_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_321_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_324_s1; // decl: <none>; prim: <none>
    logic [52:0] rtlzz_pipe_327_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_330_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_333_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_336_s1; // decl: <none>; prim: <none>
    logic [56:0] rtlzz_pipe_339_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_342_s1; // decl: <none>; prim: <none>
    logic [44:0] rtlzz_pipe_345_s1; // decl: <none>; prim: <none>
    logic [52:0] rtlzz_pipe_348_s1; // decl: <none>; prim: <none>
    logic [60:0] rtlzz_pipe_351_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_354_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_357_s1; // decl: <none>; prim: <none>
    logic [56:0] rtlzz_pipe_360_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_363_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_366_s2; // decl: <none>; prim: <none>
    logic [37:0] rtlzz_pipe_369_s2; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_372_s2; // decl: <none>; prim: <none>
    logic [41:0] rtlzz_pipe_375_s2; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_378_s2; // decl: <none>; prim: <none>
    logic [45:0] rtlzz_pipe_381_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_384_s2; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_387_s2; // decl: <none>; prim: <none>
    logic [37:0] rtlzz_pipe_390_s2; // decl: <none>; prim: <none>
    logic [53:0] rtlzz_pipe_393_s2; // decl: <none>; prim: <none>
    logic [41:0] rtlzz_pipe_396_s2; // decl: <none>; prim: <none>
    logic [57:0] rtlzz_pipe_399_s2; // decl: <none>; prim: <none>
    logic [45:0] rtlzz_pipe_402_s2; // decl: <none>; prim: <none>
    logic [61:0] rtlzz_pipe_405_s2; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_408_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_411_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_5_reduce rtlzz_reduce_5(.i459(rtlzz_pipe_2_s2), .i492(rtlzz_pipe_366_s2), .i493(rtlzz_pipe_369_s2), .i494(rtlzz_pipe_372_s2), .i495(rtlzz_pipe_375_s2), .i496(rtlzz_pipe_378_s2), .i497(rtlzz_pipe_381_s2), .i498(rtlzz_pipe_384_s2), .i499(rtlzz_pipe_387_s2), .i500(rtlzz_pipe_390_s2), .i501(rtlzz_pipe_393_s2), .i502(rtlzz_pipe_396_s2), .i503(rtlzz_pipe_399_s2), .i504(rtlzz_pipe_402_s2), .i505(rtlzz_pipe_405_s2), .i506(rtlzz_pipe_408_s2), .i507(rtlzz_pipe_411_s2), .y(s8_norm_add_4_v0));
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_457; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(4'(mul_tree_12_13)), .b(4'(mul_tree_12_14)), .cin(1'b0), .value(mul_tree_12_15));
    assign mul_tree_12_16 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_18Core rtlzz_owner_18(.a(4'(mul_tree_12_16)), .b(4'(mul_tree_12_17)), .cin(1'b0), .value(mul_tree_12_18));
    assign mul_tree_12_19 = {mul_tree_12_18, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_22Core rtlzz_owner_22(.a(4'(mul_tree_12_20)), .b(4'(mul_tree_12_21)), .cin(1'b0), .value(mul_tree_12_22));
    assign mul_tree_12_23 = {mul_tree_12_22, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_26Core rtlzz_owner_26(.a(4'(mul_tree_12_24)), .b(4'(mul_tree_12_25)), .cin(1'b0), .value(mul_tree_12_26));
    assign mul_tree_12_27 = {mul_tree_12_26, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_30Core rtlzz_owner_30(.a(4'(mul_tree_12_28)), .b(4'(mul_tree_12_29)), .cin(1'b0), .value(mul_tree_12_30));
    assign mul_tree_12_31 = {mul_tree_12_30, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_34Core rtlzz_owner_34(.a(4'(mul_tree_12_32)), .b(4'(mul_tree_12_33)), .cin(1'b0), .value(mul_tree_12_34));
    assign mul_tree_12_35 = {mul_tree_12_34, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(4'(mul_tree_12_36)), .b(4'(mul_tree_12_37)), .cin(1'b0), .value(mul_tree_12_38));
    assign mul_tree_12_39 = {mul_tree_12_38, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = mul_precision_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_42Core rtlzz_owner_42(.a(4'(mul_tree_12_40)), .b(4'(mul_tree_12_41)), .cin(1'b0), .value(mul_tree_12_42));
    assign mul_tree_12_43 = {mul_tree_12_42, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_46Core rtlzz_owner_46(.a(4'(mul_tree_12_44)), .b(4'(mul_tree_12_45)), .cin(1'b0), .value(mul_tree_12_46));
    assign mul_tree_12_47 = {mul_tree_12_46, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_50Core rtlzz_owner_50(.a(4'(mul_tree_12_48)), .b(4'(mul_tree_12_49)), .cin(1'b0), .value(mul_tree_12_50));
    assign mul_tree_12_51 = {mul_tree_12_50, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_54Core rtlzz_owner_54(.a(4'(mul_tree_12_52)), .b(4'(mul_tree_12_53)), .cin(1'b0), .value(mul_tree_12_54));
    assign mul_tree_12_55 = {mul_tree_12_54, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_58Core rtlzz_owner_58(.a(4'(mul_tree_12_56)), .b(4'(mul_tree_12_57)), .cin(1'b0), .value(mul_tree_12_58));
    assign mul_tree_12_59 = {mul_tree_12_58, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_62Core rtlzz_owner_62(.a(4'(mul_tree_12_60)), .b(4'(mul_tree_12_61)), .cin(1'b0), .value(mul_tree_12_62));
    assign mul_tree_12_63 = {mul_tree_12_62, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_66Core rtlzz_owner_66(.a(4'(mul_tree_12_64)), .b(4'(mul_tree_12_65)), .cin(1'b0), .value(mul_tree_12_66));
    assign mul_tree_12_67 = {mul_tree_12_66, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_70Core rtlzz_owner_70(.a(4'(mul_tree_12_68)), .b(4'(mul_tree_12_69)), .cin(1'b0), .value(mul_tree_12_70));
    assign mul_tree_12_71 = {mul_tree_12_70, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = mul_precision_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_74Core rtlzz_owner_74(.a(4'(mul_tree_12_72)), .b(4'(mul_tree_12_73)), .cin(1'b0), .value(mul_tree_12_74));
    assign mul_tree_12_75 = {mul_tree_12_74, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_77 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(4'(mul_tree_12_76)), .b(4'(mul_tree_12_77)), .cin(1'b0), .value(mul_tree_12_78));
    assign mul_tree_12_79 = {mul_tree_12_78, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_80 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_81 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_82Core rtlzz_owner_82(.a(4'(mul_tree_12_80)), .b(4'(mul_tree_12_81)), .cin(1'b0), .value(mul_tree_12_82));
    assign mul_tree_12_83 = {mul_tree_12_82, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_84 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_85 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_86Core rtlzz_owner_86(.a(4'(mul_tree_12_84)), .b(4'(mul_tree_12_85)), .cin(1'b0), .value(mul_tree_12_86));
    assign mul_tree_12_87 = {mul_tree_12_86, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_88 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_89 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_90Core rtlzz_owner_90(.a(4'(mul_tree_12_88)), .b(4'(mul_tree_12_89)), .cin(1'b0), .value(mul_tree_12_90));
    assign mul_tree_12_91 = {mul_tree_12_90, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_92 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_93 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_94Core rtlzz_owner_94(.a(4'(mul_tree_12_92)), .b(4'(mul_tree_12_93)), .cin(1'b0), .value(mul_tree_12_94));
    assign mul_tree_12_95 = {mul_tree_12_94, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_96 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_97 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_98Core rtlzz_owner_98(.a(4'(mul_tree_12_96)), .b(4'(mul_tree_12_97)), .cin(1'b0), .value(mul_tree_12_98));
    assign mul_tree_12_99 = {mul_tree_12_98, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_100 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_101 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_102Core rtlzz_owner_102(.a(4'(mul_tree_12_100)), .b(4'(mul_tree_12_101)), .cin(1'b0), .value(mul_tree_12_102));
    assign mul_tree_12_103 = {mul_tree_12_102, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_104 = mul_precision_10[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_105 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_106Core rtlzz_owner_106(.a(4'(mul_tree_12_104)), .b(4'(mul_tree_12_105)), .cin(1'b0), .value(mul_tree_12_106));
    assign mul_tree_12_107 = {mul_tree_12_106, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_108 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_109 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_110Core rtlzz_owner_110(.a(4'(mul_tree_12_108)), .b(4'(mul_tree_12_109)), .cin(1'b0), .value(mul_tree_12_110));
    assign mul_tree_12_111 = {mul_tree_12_110, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_112 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_113 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_114Core rtlzz_owner_114(.a(4'(mul_tree_12_112)), .b(4'(mul_tree_12_113)), .cin(1'b0), .value(mul_tree_12_114));
    assign mul_tree_12_115 = {mul_tree_12_114, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_116 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_117 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_118Core rtlzz_owner_118(.a(4'(mul_tree_12_116)), .b(4'(mul_tree_12_117)), .cin(1'b0), .value(mul_tree_12_118));
    assign mul_tree_12_119 = {mul_tree_12_118, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_120 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_122Core rtlzz_owner_122(.a(4'(mul_tree_12_120)), .b(4'(mul_tree_12_121)), .cin(1'b0), .value(mul_tree_12_122));
    assign mul_tree_12_123 = {mul_tree_12_122, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_124 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_125 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_126Core rtlzz_owner_126(.a(4'(mul_tree_12_124)), .b(4'(mul_tree_12_125)), .cin(1'b0), .value(mul_tree_12_126));
    assign mul_tree_12_127 = {mul_tree_12_126, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_128 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_129 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(4'(mul_tree_12_128)), .b(4'(mul_tree_12_129)), .cin(1'b0), .value(mul_tree_12_130));
    assign mul_tree_12_131 = {mul_tree_12_130, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_132 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_133 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(4'(mul_tree_12_132)), .b(4'(mul_tree_12_133)), .cin(1'b0), .value(mul_tree_12_134));
    assign mul_tree_12_135 = {mul_tree_12_134, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_136 = mul_precision_10[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_137 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(4'(mul_tree_12_136)), .b(4'(mul_tree_12_137)), .cin(1'b0), .value(mul_tree_12_138));
    assign mul_tree_12_139 = {mul_tree_12_138, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_140 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_141 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(4'(mul_tree_12_140)), .b(4'(mul_tree_12_141)), .cin(1'b0), .value(mul_tree_12_142));
    assign mul_tree_12_143 = {mul_tree_12_142, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_144 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_145 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_146Core rtlzz_owner_146(.a(4'(mul_tree_12_144)), .b(4'(mul_tree_12_145)), .cin(1'b0), .value(mul_tree_12_146));
    assign mul_tree_12_147 = {mul_tree_12_146, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_148 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_149 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_150Core rtlzz_owner_150(.a(4'(mul_tree_12_148)), .b(4'(mul_tree_12_149)), .cin(1'b0), .value(mul_tree_12_150));
    assign mul_tree_12_151 = {mul_tree_12_150, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_152 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_153 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_154Core rtlzz_owner_154(.a(4'(mul_tree_12_152)), .b(4'(mul_tree_12_153)), .cin(1'b0), .value(mul_tree_12_154));
    assign mul_tree_12_155 = {mul_tree_12_154, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_156 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_157 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_158Core rtlzz_owner_158(.a(4'(mul_tree_12_156)), .b(4'(mul_tree_12_157)), .cin(1'b0), .value(mul_tree_12_158));
    assign mul_tree_12_159 = {mul_tree_12_158, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_160 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_161 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_162Core rtlzz_owner_162(.a(4'(mul_tree_12_160)), .b(4'(mul_tree_12_161)), .cin(1'b0), .value(mul_tree_12_162));
    assign mul_tree_12_163 = {mul_tree_12_162, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_164 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_165 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_166Core rtlzz_owner_166(.a(4'(mul_tree_12_164)), .b(4'(mul_tree_12_165)), .cin(1'b0), .value(mul_tree_12_166));
    assign mul_tree_12_167 = {mul_tree_12_166, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_168 = mul_precision_10[19:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_169 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_170Core rtlzz_owner_170(.a(4'(mul_tree_12_168)), .b(4'(mul_tree_12_169)), .cin(1'b0), .value(mul_tree_12_170));
    assign mul_tree_12_171 = {mul_tree_12_170, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_172 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_173 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_174Core rtlzz_owner_174(.a(4'(mul_tree_12_172)), .b(4'(mul_tree_12_173)), .cin(1'b0), .value(mul_tree_12_174));
    assign mul_tree_12_175 = {mul_tree_12_174, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_176 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_177 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_178Core rtlzz_owner_178(.a(4'(mul_tree_12_176)), .b(4'(mul_tree_12_177)), .cin(1'b0), .value(mul_tree_12_178));
    assign mul_tree_12_179 = {mul_tree_12_178, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_180 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_181 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_182Core rtlzz_owner_182(.a(4'(mul_tree_12_180)), .b(4'(mul_tree_12_181)), .cin(1'b0), .value(mul_tree_12_182));
    assign mul_tree_12_183 = {mul_tree_12_182, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_184 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_185 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_186Core rtlzz_owner_186(.a(4'(mul_tree_12_184)), .b(4'(mul_tree_12_185)), .cin(1'b0), .value(mul_tree_12_186));
    assign mul_tree_12_187 = {mul_tree_12_186, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_188 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_189 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_190Core rtlzz_owner_190(.a(4'(mul_tree_12_188)), .b(4'(mul_tree_12_189)), .cin(1'b0), .value(mul_tree_12_190));
    assign mul_tree_12_191 = {mul_tree_12_190, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_192 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_193 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(4'(mul_tree_12_192)), .b(4'(mul_tree_12_193)), .cin(1'b0), .value(mul_tree_12_194));
    assign mul_tree_12_195 = {mul_tree_12_194, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_196 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_197 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_198Core rtlzz_owner_198(.a(4'(mul_tree_12_196)), .b(4'(mul_tree_12_197)), .cin(1'b0), .value(mul_tree_12_198));
    assign mul_tree_12_199 = {mul_tree_12_198, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_200 = mul_precision_10[23:20]; // decl: <none>; prim: <none>
    assign mul_tree_12_201 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_202Core rtlzz_owner_202(.a(4'(mul_tree_12_200)), .b(4'(mul_tree_12_201)), .cin(1'b0), .value(mul_tree_12_202));
    assign mul_tree_12_203 = {mul_tree_12_202, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_204 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_205 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(4'(mul_tree_12_204)), .b(4'(mul_tree_12_205)), .cin(1'b0), .value(mul_tree_12_206));
    assign mul_tree_12_207 = {mul_tree_12_206, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_208 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_209 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_210Core rtlzz_owner_210(.a(4'(mul_tree_12_208)), .b(4'(mul_tree_12_209)), .cin(1'b0), .value(mul_tree_12_210));
    assign mul_tree_12_211 = {mul_tree_12_210, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_212 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_213 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_214Core rtlzz_owner_214(.a(4'(mul_tree_12_212)), .b(4'(mul_tree_12_213)), .cin(1'b0), .value(mul_tree_12_214));
    assign mul_tree_12_215 = {mul_tree_12_214, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_216 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_217 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(4'(mul_tree_12_216)), .b(4'(mul_tree_12_217)), .cin(1'b0), .value(mul_tree_12_218));
    assign mul_tree_12_219 = {mul_tree_12_218, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_220 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_221 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_222Core rtlzz_owner_222(.a(4'(mul_tree_12_220)), .b(4'(mul_tree_12_221)), .cin(1'b0), .value(mul_tree_12_222));
    assign mul_tree_12_223 = {mul_tree_12_222, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_224 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_225 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_226Core rtlzz_owner_226(.a(4'(mul_tree_12_224)), .b(4'(mul_tree_12_225)), .cin(1'b0), .value(mul_tree_12_226));
    assign mul_tree_12_227 = {mul_tree_12_226, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_228 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_229 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_230Core rtlzz_owner_230(.a(4'(mul_tree_12_228)), .b(4'(mul_tree_12_229)), .cin(1'b0), .value(mul_tree_12_230));
    assign mul_tree_12_231 = {mul_tree_12_230, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_232 = mul_precision_10[27:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_233 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_234Core rtlzz_owner_234(.a(4'(mul_tree_12_232)), .b(4'(mul_tree_12_233)), .cin(1'b0), .value(mul_tree_12_234));
    assign mul_tree_12_235 = {mul_tree_12_234, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_236 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_237 = mul_precision_11[3:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_238Core rtlzz_owner_238(.a(4'(mul_tree_12_236)), .b(4'(mul_tree_12_237)), .cin(1'b0), .value(mul_tree_12_238));
    assign mul_tree_12_239 = {mul_tree_12_238, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_240 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_241 = mul_precision_11[7:4]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_242Core rtlzz_owner_242(.a(4'(mul_tree_12_240)), .b(4'(mul_tree_12_241)), .cin(1'b0), .value(mul_tree_12_242));
    assign mul_tree_12_243 = {mul_tree_12_242, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_244 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_245 = mul_precision_11[11:8]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_246Core rtlzz_owner_246(.a(4'(mul_tree_12_244)), .b(4'(mul_tree_12_245)), .cin(1'b0), .value(mul_tree_12_246));
    assign mul_tree_12_247 = {mul_tree_12_246, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_248 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_249 = mul_precision_11[15:12]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_250Core rtlzz_owner_250(.a(4'(mul_tree_12_248)), .b(4'(mul_tree_12_249)), .cin(1'b0), .value(mul_tree_12_250));
    assign mul_tree_12_251 = {mul_tree_12_250, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_252 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_253 = mul_precision_11[19:16]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_254Core rtlzz_owner_254(.a(4'(mul_tree_12_252)), .b(4'(mul_tree_12_253)), .cin(1'b0), .value(mul_tree_12_254));
    assign mul_tree_12_255 = {mul_tree_12_254, 44'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_256 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_257 = mul_precision_11[23:20]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_258Core rtlzz_owner_258(.a(4'(mul_tree_12_256)), .b(4'(mul_tree_12_257)), .cin(1'b0), .value(mul_tree_12_258));
    assign mul_tree_12_259 = {mul_tree_12_258, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_260 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_261 = mul_precision_11[27:24]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_262Core rtlzz_owner_262(.a(4'(mul_tree_12_260)), .b(4'(mul_tree_12_261)), .cin(1'b0), .value(mul_tree_12_262));
    assign mul_tree_12_263 = {mul_tree_12_262, 52'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_264 = mul_precision_10[31:28]; // decl: <none>; prim: <none>
    assign mul_tree_12_265 = mul_precision_11[31:28]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_266Core rtlzz_owner_266(.a(4'(mul_tree_12_264)), .b(4'(mul_tree_12_265)), .cin(1'b0), .value(mul_tree_12_266));
    assign mul_tree_12_267 = {mul_tree_12_266, 56'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_268 = ({5'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_269 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_270Core rtlzz_owner_270(.a(8'(mul_tree_12_268)), .b(12'(mul_tree_12_269)), .cin(1'h0), .value(mul_tree_12_270));
    assign mul_tree_12_271 = ({5'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_272 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_273Core rtlzz_owner_273(.a(16'(mul_tree_12_271)), .b(20'(mul_tree_12_272)), .cin(1'h0), .value(mul_tree_12_273));
    assign mul_tree_12_274 = ({5'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_275 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_276Core rtlzz_owner_276(.a(24'(mul_tree_12_274)), .b(28'(mul_tree_12_275)), .cin(1'h0), .value(mul_tree_12_276));
    assign mul_tree_12_277 = ({5'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_278 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_279Core rtlzz_owner_279(.a(32'(mul_tree_12_277)), .b(36'(mul_tree_12_278)), .cin(1'h0), .value(mul_tree_12_279));
    assign mul_tree_12_280 = ({5'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_281 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_282Core rtlzz_owner_282(.a(12'(mul_tree_12_280)), .b(16'(mul_tree_12_281)), .cin(1'h0), .value(mul_tree_12_282));
    assign mul_tree_12_283 = ({5'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_284 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_285Core rtlzz_owner_285(.a(20'(mul_tree_12_283)), .b(24'(mul_tree_12_284)), .cin(1'h0), .value(mul_tree_12_285));
    assign mul_tree_12_286 = ({5'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_287 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_288Core rtlzz_owner_288(.a(28'(mul_tree_12_286)), .b(32'(mul_tree_12_287)), .cin(1'h0), .value(mul_tree_12_288));
    assign mul_tree_12_289 = ({5'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_290 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_291Core rtlzz_owner_291(.a(36'(mul_tree_12_289)), .b(40'(mul_tree_12_290)), .cin(1'h0), .value(mul_tree_12_291));
    assign mul_tree_12_292 = ({5'h0, mul_tree_12_79}); // decl: <none>; prim: <none>
    assign mul_tree_12_293 = ({1'h0, mul_tree_12_83}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_294Core rtlzz_owner_294(.a(16'(mul_tree_12_292)), .b(20'(mul_tree_12_293)), .cin(1'h0), .value(mul_tree_12_294));
    assign mul_tree_12_295 = ({5'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_296 = ({1'h0, mul_tree_12_91}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_297Core rtlzz_owner_297(.a(24'(mul_tree_12_295)), .b(28'(mul_tree_12_296)), .cin(1'h0), .value(mul_tree_12_297));
    assign mul_tree_12_298 = ({5'h0, mul_tree_12_95}); // decl: <none>; prim: <none>
    assign mul_tree_12_299 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_300Core rtlzz_owner_300(.a(32'(mul_tree_12_298)), .b(36'(mul_tree_12_299)), .cin(1'h0), .value(mul_tree_12_300));
    assign mul_tree_12_301 = ({5'h0, mul_tree_12_103}); // decl: <none>; prim: <none>
    assign mul_tree_12_302 = ({1'h0, mul_tree_12_107}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_303Core rtlzz_owner_303(.a(40'(mul_tree_12_301)), .b(44'(mul_tree_12_302)), .cin(1'h0), .value(mul_tree_12_303));
    assign mul_tree_12_304 = ({5'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_305 = ({1'h0, mul_tree_12_115}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_306Core rtlzz_owner_306(.a(20'(mul_tree_12_304)), .b(24'(mul_tree_12_305)), .cin(1'h0), .value(mul_tree_12_306));
    assign mul_tree_12_307 = ({5'h0, mul_tree_12_119}); // decl: <none>; prim: <none>
    assign mul_tree_12_308 = ({1'h0, mul_tree_12_123}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_309Core rtlzz_owner_309(.a(28'(mul_tree_12_307)), .b(32'(mul_tree_12_308)), .cin(1'h0), .value(mul_tree_12_309));
    assign mul_tree_12_310 = ({5'h0, mul_tree_12_127}); // decl: <none>; prim: <none>
    assign mul_tree_12_311 = ({1'h0, mul_tree_12_131}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_312Core rtlzz_owner_312(.a(36'(mul_tree_12_310)), .b(40'(mul_tree_12_311)), .cin(1'h0), .value(mul_tree_12_312));
    assign mul_tree_12_313 = ({5'h0, mul_tree_12_135}); // decl: <none>; prim: <none>
    assign mul_tree_12_314 = ({1'h0, mul_tree_12_139}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_315Core rtlzz_owner_315(.a(44'(mul_tree_12_313)), .b(48'(mul_tree_12_314)), .cin(1'h0), .value(mul_tree_12_315));
    assign mul_tree_12_316 = ({5'h0, mul_tree_12_143}); // decl: <none>; prim: <none>
    assign mul_tree_12_317 = ({1'h0, mul_tree_12_147}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_318Core rtlzz_owner_318(.a(24'(mul_tree_12_316)), .b(28'(mul_tree_12_317)), .cin(1'h0), .value(mul_tree_12_318));
    assign mul_tree_12_319 = ({5'h0, mul_tree_12_151}); // decl: <none>; prim: <none>
    assign mul_tree_12_320 = ({1'h0, mul_tree_12_155}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_321Core rtlzz_owner_321(.a(32'(mul_tree_12_319)), .b(36'(mul_tree_12_320)), .cin(1'h0), .value(mul_tree_12_321));
    assign mul_tree_12_322 = ({5'h0, mul_tree_12_159}); // decl: <none>; prim: <none>
    assign mul_tree_12_323 = ({1'h0, mul_tree_12_163}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_324Core rtlzz_owner_324(.a(40'(mul_tree_12_322)), .b(44'(mul_tree_12_323)), .cin(1'h0), .value(mul_tree_12_324));
    assign mul_tree_12_325 = ({5'h0, mul_tree_12_167}); // decl: <none>; prim: <none>
    assign mul_tree_12_326 = ({1'h0, mul_tree_12_171}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_327Core rtlzz_owner_327(.a(48'(mul_tree_12_325)), .b(52'(mul_tree_12_326)), .cin(1'h0), .value(mul_tree_12_327));
    assign mul_tree_12_328 = ({5'h0, mul_tree_12_175}); // decl: <none>; prim: <none>
    assign mul_tree_12_329 = ({1'h0, mul_tree_12_179}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(28'(mul_tree_12_328)), .b(32'(mul_tree_12_329)), .cin(1'h0), .value(mul_tree_12_330));
    assign mul_tree_12_331 = ({5'h0, mul_tree_12_183}); // decl: <none>; prim: <none>
    assign mul_tree_12_332 = ({1'h0, mul_tree_12_187}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_333Core rtlzz_owner_333(.a(36'(mul_tree_12_331)), .b(40'(mul_tree_12_332)), .cin(1'h0), .value(mul_tree_12_333));
    assign mul_tree_12_334 = ({5'h0, mul_tree_12_191}); // decl: <none>; prim: <none>
    assign mul_tree_12_335 = ({1'h0, mul_tree_12_195}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_336Core rtlzz_owner_336(.a(44'(mul_tree_12_334)), .b(48'(mul_tree_12_335)), .cin(1'h0), .value(mul_tree_12_336));
    assign mul_tree_12_337 = ({5'h0, mul_tree_12_199}); // decl: <none>; prim: <none>
    assign mul_tree_12_338 = ({1'h0, mul_tree_12_203}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_339Core rtlzz_owner_339(.a(52'(mul_tree_12_337)), .b(56'(mul_tree_12_338)), .cin(1'h0), .value(mul_tree_12_339));
    assign mul_tree_12_340 = ({5'h0, mul_tree_12_207}); // decl: <none>; prim: <none>
    assign mul_tree_12_341 = ({1'h0, mul_tree_12_211}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_342Core rtlzz_owner_342(.a(32'(mul_tree_12_340)), .b(36'(mul_tree_12_341)), .cin(1'h0), .value(mul_tree_12_342));
    assign mul_tree_12_343 = ({5'h0, mul_tree_12_215}); // decl: <none>; prim: <none>
    assign mul_tree_12_344 = ({1'h0, mul_tree_12_219}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_345Core rtlzz_owner_345(.a(40'(mul_tree_12_343)), .b(44'(mul_tree_12_344)), .cin(1'h0), .value(mul_tree_12_345));
    assign mul_tree_12_346 = ({5'h0, mul_tree_12_223}); // decl: <none>; prim: <none>
    assign mul_tree_12_347 = ({1'h0, mul_tree_12_227}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(48'(mul_tree_12_346)), .b(52'(mul_tree_12_347)), .cin(1'h0), .value(mul_tree_12_348));
    assign mul_tree_12_349 = ({5'h0, mul_tree_12_231}); // decl: <none>; prim: <none>
    assign mul_tree_12_350 = ({1'h0, mul_tree_12_235}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(56'(mul_tree_12_349)), .b(60'(mul_tree_12_350)), .cin(1'h0), .value(mul_tree_12_351));
    assign mul_tree_12_352 = ({5'h0, mul_tree_12_239}); // decl: <none>; prim: <none>
    assign mul_tree_12_353 = ({1'h0, mul_tree_12_243}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(36'(mul_tree_12_352)), .b(40'(mul_tree_12_353)), .cin(1'h0), .value(mul_tree_12_354));
    assign mul_tree_12_355 = ({5'h0, mul_tree_12_247}); // decl: <none>; prim: <none>
    assign mul_tree_12_356 = ({1'h0, mul_tree_12_251}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_357Core rtlzz_owner_357(.a(44'(mul_tree_12_355)), .b(48'(mul_tree_12_356)), .cin(1'h0), .value(mul_tree_12_357));
    assign mul_tree_12_358 = ({5'h0, mul_tree_12_255}); // decl: <none>; prim: <none>
    assign mul_tree_12_359 = ({1'h0, mul_tree_12_259}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_360Core rtlzz_owner_360(.a(52'(mul_tree_12_358)), .b(56'(mul_tree_12_359)), .cin(1'h0), .value(mul_tree_12_360));
    assign mul_tree_12_361 = ({5'h0, mul_tree_12_263}); // decl: <none>; prim: <none>
    assign mul_tree_12_362 = ({1'h0, mul_tree_12_267}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_363Core rtlzz_owner_363(.a(60'(mul_tree_12_361)), .b(64'(mul_tree_12_362)), .cin(1'h0), .value(mul_tree_12_363[63:0]));
    assign mul_tree_12_363[64:64] = '0;
    assign mul_tree_12_364 = ({9'h0, rtlzz_pipe_270_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_365 = ({1'h0, rtlzz_pipe_273_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_366Core rtlzz_owner_366(.a(13'(mul_tree_12_364)), .b(21'(mul_tree_12_365)), .cin(1'h0), .value(mul_tree_12_366));
    assign mul_tree_12_367 = ({9'h0, rtlzz_pipe_276_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_368 = ({1'h0, rtlzz_pipe_279_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(29'(mul_tree_12_367)), .b(37'(mul_tree_12_368)), .cin(1'h0), .value(mul_tree_12_369));
    assign mul_tree_12_370 = ({9'h0, rtlzz_pipe_282_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_371 = ({1'h0, rtlzz_pipe_285_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_372Core rtlzz_owner_372(.a(17'(mul_tree_12_370)), .b(25'(mul_tree_12_371)), .cin(1'h0), .value(mul_tree_12_372));
    assign mul_tree_12_373 = ({9'h0, rtlzz_pipe_288_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_374 = ({1'h0, rtlzz_pipe_291_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_375Core rtlzz_owner_375(.a(33'(mul_tree_12_373)), .b(41'(mul_tree_12_374)), .cin(1'h0), .value(mul_tree_12_375));
    assign mul_tree_12_376 = ({9'h0, rtlzz_pipe_294_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_377 = ({1'h0, rtlzz_pipe_297_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_378Core rtlzz_owner_378(.a(21'(mul_tree_12_376)), .b(29'(mul_tree_12_377)), .cin(1'h0), .value(mul_tree_12_378));
    assign mul_tree_12_379 = ({9'h0, rtlzz_pipe_300_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_380 = ({1'h0, rtlzz_pipe_303_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_381Core rtlzz_owner_381(.a(37'(mul_tree_12_379)), .b(45'(mul_tree_12_380)), .cin(1'h0), .value(mul_tree_12_381));
    assign mul_tree_12_382 = ({9'h0, rtlzz_pipe_306_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_383 = ({1'h0, rtlzz_pipe_309_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_384Core rtlzz_owner_384(.a(25'(mul_tree_12_382)), .b(33'(mul_tree_12_383)), .cin(1'h0), .value(mul_tree_12_384));
    assign mul_tree_12_385 = ({9'h0, rtlzz_pipe_312_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_386 = ({1'h0, rtlzz_pipe_315_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387Core rtlzz_owner_387(.a(41'(mul_tree_12_385)), .b(49'(mul_tree_12_386)), .cin(1'h0), .value(mul_tree_12_387));
    assign mul_tree_12_388 = ({9'h0, rtlzz_pipe_318_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_389 = ({1'h0, rtlzz_pipe_321_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_390Core rtlzz_owner_390(.a(29'(mul_tree_12_388)), .b(37'(mul_tree_12_389)), .cin(1'h0), .value(mul_tree_12_390));
    assign mul_tree_12_391 = ({9'h0, rtlzz_pipe_324_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_392 = ({1'h0, rtlzz_pipe_327_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_393Core rtlzz_owner_393(.a(45'(mul_tree_12_391)), .b(53'(mul_tree_12_392)), .cin(1'h0), .value(mul_tree_12_393));
    assign mul_tree_12_394 = ({9'h0, rtlzz_pipe_330_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_395 = ({1'h0, rtlzz_pipe_333_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_396Core rtlzz_owner_396(.a(33'(mul_tree_12_394)), .b(41'(mul_tree_12_395)), .cin(1'h0), .value(mul_tree_12_396));
    assign mul_tree_12_397 = ({9'h0, rtlzz_pipe_336_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_398 = ({1'h0, rtlzz_pipe_339_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_399Core rtlzz_owner_399(.a(49'(mul_tree_12_397)), .b(57'(mul_tree_12_398)), .cin(1'h0), .value(mul_tree_12_399));
    assign mul_tree_12_400 = ({9'h0, rtlzz_pipe_342_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_401 = ({1'h0, rtlzz_pipe_345_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_402Core rtlzz_owner_402(.a(37'(mul_tree_12_400)), .b(45'(mul_tree_12_401)), .cin(1'h0), .value(mul_tree_12_402));
    assign mul_tree_12_403 = ({9'h0, rtlzz_pipe_348_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_404 = ({1'h0, rtlzz_pipe_351_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405Core rtlzz_owner_405(.a(53'(mul_tree_12_403)), .b(61'(mul_tree_12_404)), .cin(1'h0), .value(mul_tree_12_405));
    assign mul_tree_12_406 = ({9'h0, rtlzz_pipe_354_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_407 = ({1'h0, rtlzz_pipe_357_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_408Core rtlzz_owner_408(.a(41'(mul_tree_12_406)), .b(49'(mul_tree_12_407)), .cin(1'h0), .value(mul_tree_12_408));
    assign mul_tree_12_409 = ({9'h0, rtlzz_pipe_360_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_410 = ({1'h0, rtlzz_pipe_363_s1}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_411Core rtlzz_owner_411(.a(57'(mul_tree_12_409)), .b(65'(mul_tree_12_410)), .cin(1'h0), .value(mul_tree_12_411[63:0]));
    assign mul_tree_12_411[65:64] = '0;
    assign mul_tree_12_412 = ({17'h0, rtlzz_pipe_366_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_413 = ({1'h0, rtlzz_pipe_369_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_415 = ({17'h0, rtlzz_pipe_372_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_416 = ({1'h0, rtlzz_pipe_375_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_418 = ({17'h0, rtlzz_pipe_378_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_419 = ({1'h0, rtlzz_pipe_381_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_421 = ({17'h0, rtlzz_pipe_384_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_422 = ({1'h0, rtlzz_pipe_387_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_424 = ({17'h0, rtlzz_pipe_390_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_425 = ({1'h0, rtlzz_pipe_393_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_427 = ({17'h0, rtlzz_pipe_396_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_428 = ({1'h0, rtlzz_pipe_399_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_430 = ({17'h0, rtlzz_pipe_402_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_431 = ({1'h0, rtlzz_pipe_405_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_433 = ({17'h0, rtlzz_pipe_408_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_434 = ({1'h0, rtlzz_pipe_411_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_436 = ({5'h0, mul_tree_12_414}); // decl: <none>; prim: <none>
    assign mul_tree_12_437 = ({1'h0, mul_tree_12_417}); // decl: <none>; prim: <none>
    assign mul_tree_12_439 = ({5'h0, mul_tree_12_420}); // decl: <none>; prim: <none>
    assign mul_tree_12_440 = ({1'h0, mul_tree_12_423}); // decl: <none>; prim: <none>
    assign mul_tree_12_442 = ({5'h0, mul_tree_12_426}); // decl: <none>; prim: <none>
    assign mul_tree_12_443 = ({1'h0, mul_tree_12_429}); // decl: <none>; prim: <none>
    assign mul_tree_12_445 = ({5'h0, mul_tree_12_432}); // decl: <none>; prim: <none>
    assign mul_tree_12_446 = ({1'h0, mul_tree_12_435}); // decl: <none>; prim: <none>
    assign mul_tree_12_448 = ({9'h0, mul_tree_12_438}); // decl: <none>; prim: <none>
    assign mul_tree_12_449 = ({1'h0, mul_tree_12_441}); // decl: <none>; prim: <none>
    assign mul_tree_12_451 = ({9'h0, mul_tree_12_444}); // decl: <none>; prim: <none>
    assign mul_tree_12_452 = ({1'h0, mul_tree_12_447}); // decl: <none>; prim: <none>
    assign mul_tree_12_454 = ({17'h0, mul_tree_12_450}); // decl: <none>; prim: <none>
    assign mul_tree_12_455 = ({1'h0, mul_tree_12_453}); // decl: <none>; prim: <none>
    assign mul_tree_12_457 = mul_tree_12_456[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_270_s1 <= 13'h0;
            rtlzz_pipe_273_s1 <= 21'h0;
            rtlzz_pipe_276_s1 <= 29'h0;
            rtlzz_pipe_279_s1 <= 37'h0;
            rtlzz_pipe_282_s1 <= 17'h0;
            rtlzz_pipe_285_s1 <= 25'h0;
            rtlzz_pipe_288_s1 <= 33'h0;
            rtlzz_pipe_291_s1 <= 41'h0;
            rtlzz_pipe_294_s1 <= 21'h0;
            rtlzz_pipe_297_s1 <= 29'h0;
            rtlzz_pipe_300_s1 <= 37'h0;
            rtlzz_pipe_303_s1 <= 45'h0;
            rtlzz_pipe_306_s1 <= 25'h0;
            rtlzz_pipe_309_s1 <= 33'h0;
            rtlzz_pipe_312_s1 <= 41'h0;
            rtlzz_pipe_315_s1 <= 49'h0;
            rtlzz_pipe_318_s1 <= 29'h0;
            rtlzz_pipe_321_s1 <= 37'h0;
            rtlzz_pipe_324_s1 <= 45'h0;
            rtlzz_pipe_327_s1 <= 53'h0;
            rtlzz_pipe_330_s1 <= 33'h0;
            rtlzz_pipe_333_s1 <= 41'h0;
            rtlzz_pipe_336_s1 <= 49'h0;
            rtlzz_pipe_339_s1 <= 57'h0;
            rtlzz_pipe_342_s1 <= 37'h0;
            rtlzz_pipe_345_s1 <= 45'h0;
            rtlzz_pipe_348_s1 <= 53'h0;
            rtlzz_pipe_351_s1 <= 61'h0;
            rtlzz_pipe_354_s1 <= 41'h0;
            rtlzz_pipe_357_s1 <= 49'h0;
            rtlzz_pipe_360_s1 <= 57'h0;
            rtlzz_pipe_363_s1 <= 65'h0;
            rtlzz_pipe_366_s2 <= 22'h0;
            rtlzz_pipe_369_s2 <= 38'h0;
            rtlzz_pipe_372_s2 <= 26'h0;
            rtlzz_pipe_375_s2 <= 42'h0;
            rtlzz_pipe_378_s2 <= 30'h0;
            rtlzz_pipe_381_s2 <= 46'h0;
            rtlzz_pipe_384_s2 <= 34'h0;
            rtlzz_pipe_387_s2 <= 50'h0;
            rtlzz_pipe_390_s2 <= 38'h0;
            rtlzz_pipe_393_s2 <= 54'h0;
            rtlzz_pipe_396_s2 <= 42'h0;
            rtlzz_pipe_399_s2 <= 58'h0;
            rtlzz_pipe_402_s2 <= 46'h0;
            rtlzz_pipe_405_s2 <= 62'h0;
            rtlzz_pipe_408_s2 <= 50'h0;
            rtlzz_pipe_411_s2 <= 66'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= mul_tree_12_270; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= mul_tree_12_273; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_276_s1 <= mul_tree_12_276; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= mul_tree_12_279; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_282_s1 <= mul_tree_12_282; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_285_s1 <= mul_tree_12_285; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_288_s1 <= mul_tree_12_288; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_291_s1 <= mul_tree_12_291; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_294_s1 <= mul_tree_12_294; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_297_s1 <= mul_tree_12_297; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_300_s1 <= mul_tree_12_300; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_303_s1 <= mul_tree_12_303; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_306_s1 <= mul_tree_12_306; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_309_s1 <= mul_tree_12_309; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_312_s1 <= mul_tree_12_312; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_315_s1 <= mul_tree_12_315; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_318_s1 <= mul_tree_12_318; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_321_s1 <= mul_tree_12_321; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_324_s1 <= mul_tree_12_324; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_327_s1 <= mul_tree_12_327; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_330_s1 <= mul_tree_12_330; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_333_s1 <= mul_tree_12_333; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_336_s1 <= mul_tree_12_336; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_339_s1 <= mul_tree_12_339; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_342_s1 <= mul_tree_12_342; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_345_s1 <= mul_tree_12_345; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_348_s1 <= mul_tree_12_348; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_351_s1 <= mul_tree_12_351; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_354_s1 <= mul_tree_12_354; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_357_s1 <= mul_tree_12_357; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_360_s1 <= mul_tree_12_360; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_363_s1 <= mul_tree_12_363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_366_s2 <= mul_tree_12_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_369_s2 <= mul_tree_12_369; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_372_s2 <= mul_tree_12_372; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_375_s2 <= mul_tree_12_375; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_378_s2 <= mul_tree_12_378; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_381_s2 <= mul_tree_12_381; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_384_s2 <= mul_tree_12_384; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_387_s2 <= mul_tree_12_387; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_390_s2 <= mul_tree_12_390; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_393_s2 <= mul_tree_12_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_396_s2 <= mul_tree_12_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_399_s2 <= mul_tree_12_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_402_s2 <= mul_tree_12_402; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_405_s2 <= mul_tree_12_405; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_408_s2 <= mul_tree_12_408; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_411_s2 <= mul_tree_12_411; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_5_reduce(input wire [63:0] i459, input wire [21:0] i492, input wire [37:0] i493, input wire [25:0] i494, input wire [41:0] i495, input wire [29:0] i496, input wire [45:0] i497, input wire [33:0] i498, input wire [49:0] i499, input wire [37:0] i500, input wire [53:0] i501, input wire [41:0] i502, input wire [57:0] i503, input wire [45:0] i504, input wire [61:0] i505, input wire [49:0] i506, input wire [65:0] i507, output wire [63:0] y);
wire [63:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i492[21], i492[20], i492[19], i492[18], i492[17], i492[16], i492[15], i492[14], i492[13], i492[12], i492[11], i492[10], i492[9], i492[8], i492[7], i492[6], i492[5], i492[4], i492[3], i492[2], i492[1], i492[0]};
wire [63:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[37], i493[36], i493[35], i493[34], i493[33], i493[32], i493[31], i493[30], i493[29], i493[28], i493[27], i493[26], i493[25], i493[24], i493[23], i493[22], i493[21], i493[20], i493[19], i493[18], i493[17], i493[16], i493[15], i493[14], i493[13], i493[12], i493[11], i493[10], i493[9], i493[8], i493[7], i493[6], i493[5], i493[4], i493[3], i493[2], i493[1], i493[0]};
wire [63:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i494[25], i494[24], i494[23], i494[22], i494[21], i494[20], i494[19], i494[18], i494[17], i494[16], i494[15], i494[14], i494[13], i494[12], i494[11], i494[10], i494[9], i494[8], i494[7], i494[6], i494[5], i494[4], i494[3], i494[2], i494[1], i494[0]};
wire [63:0] t3 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i495[41], i495[40], i495[39], i495[38], i495[37], i495[36], i495[35], i495[34], i495[33], i495[32], i495[31], i495[30], i495[29], i495[28], i495[27], i495[26], i495[25], i495[24], i495[23], i495[22], i495[21], i495[20], i495[19], i495[18], i495[17], i495[16], i495[15], i495[14], i495[13], i495[12], i495[11], i495[10], i495[9], i495[8], i495[7], i495[6], i495[5], i495[4], i495[3], i495[2], i495[1], i495[0]};
wire [63:0] t4 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i496[29], i496[28], i496[27], i496[26], i496[25], i496[24], i496[23], i496[22], i496[21], i496[20], i496[19], i496[18], i496[17], i496[16], i496[15], i496[14], i496[13], i496[12], i496[11], i496[10], i496[9], i496[8], i496[7], i496[6], i496[5], i496[4], i496[3], i496[2], i496[1], i496[0]};
wire [63:0] t5 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[45], i497[44], i497[43], i497[42], i497[41], i497[40], i497[39], i497[38], i497[37], i497[36], i497[35], i497[34], i497[33], i497[32], i497[31], i497[30], i497[29], i497[28], i497[27], i497[26], i497[25], i497[24], i497[23], i497[22], i497[21], i497[20], i497[19], i497[18], i497[17], i497[16], i497[15], i497[14], i497[13], i497[12], i497[11], i497[10], i497[9], i497[8], i497[7], i497[6], i497[5], i497[4], i497[3], i497[2], i497[1], i497[0]};
wire [63:0] t6 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i498[33], i498[32], i498[31], i498[30], i498[29], i498[28], i498[27], i498[26], i498[25], i498[24], i498[23], i498[22], i498[21], i498[20], i498[19], i498[18], i498[17], i498[16], i498[15], i498[14], i498[13], i498[12], i498[11], i498[10], i498[9], i498[8], i498[7], i498[6], i498[5], i498[4], i498[3], i498[2], i498[1], i498[0]};
wire [63:0] t7 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i499[49], i499[48], i499[47], i499[46], i499[45], i499[44], i499[43], i499[42], i499[41], i499[40], i499[39], i499[38], i499[37], i499[36], i499[35], i499[34], i499[33], i499[32], i499[31], i499[30], i499[29], i499[28], i499[27], i499[26], i499[25], i499[24], i499[23], i499[22], i499[21], i499[20], i499[19], i499[18], i499[17], i499[16], i499[15], i499[14], i499[13], i499[12], i499[11], i499[10], i499[9], i499[8], i499[7], i499[6], i499[5], i499[4], i499[3], i499[2], i499[1], i499[0]};
wire [63:0] t8 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i500[37], i500[36], i500[35], i500[34], i500[33], i500[32], i500[31], i500[30], i500[29], i500[28], i500[27], i500[26], i500[25], i500[24], i500[23], i500[22], i500[21], i500[20], i500[19], i500[18], i500[17], i500[16], i500[15], i500[14], i500[13], i500[12], i500[11], i500[10], i500[9], i500[8], i500[7], i500[6], i500[5], i500[4], i500[3], i500[2], i500[1], i500[0]};
wire [63:0] t9 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i501[53], i501[52], i501[51], i501[50], i501[49], i501[48], i501[47], i501[46], i501[45], i501[44], i501[43], i501[42], i501[41], i501[40], i501[39], i501[38], i501[37], i501[36], i501[35], i501[34], i501[33], i501[32], i501[31], i501[30], i501[29], i501[28], i501[27], i501[26], i501[25], i501[24], i501[23], i501[22], i501[21], i501[20], i501[19], i501[18], i501[17], i501[16], i501[15], i501[14], i501[13], i501[12], i501[11], i501[10], i501[9], i501[8], i501[7], i501[6], i501[5], i501[4], i501[3], i501[2], i501[1], i501[0]};
wire [63:0] t10 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i502[41], i502[40], i502[39], i502[38], i502[37], i502[36], i502[35], i502[34], i502[33], i502[32], i502[31], i502[30], i502[29], i502[28], i502[27], i502[26], i502[25], i502[24], i502[23], i502[22], i502[21], i502[20], i502[19], i502[18], i502[17], i502[16], i502[15], i502[14], i502[13], i502[12], i502[11], i502[10], i502[9], i502[8], i502[7], i502[6], i502[5], i502[4], i502[3], i502[2], i502[1], i502[0]};
wire [63:0] t11 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i503[57], i503[56], i503[55], i503[54], i503[53], i503[52], i503[51], i503[50], i503[49], i503[48], i503[47], i503[46], i503[45], i503[44], i503[43], i503[42], i503[41], i503[40], i503[39], i503[38], i503[37], i503[36], i503[35], i503[34], i503[33], i503[32], i503[31], i503[30], i503[29], i503[28], i503[27], i503[26], i503[25], i503[24], i503[23], i503[22], i503[21], i503[20], i503[19], i503[18], i503[17], i503[16], i503[15], i503[14], i503[13], i503[12], i503[11], i503[10], i503[9], i503[8], i503[7], i503[6], i503[5], i503[4], i503[3], i503[2], i503[1], i503[0]};
wire [63:0] t12 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i504[45], i504[44], i504[43], i504[42], i504[41], i504[40], i504[39], i504[38], i504[37], i504[36], i504[35], i504[34], i504[33], i504[32], i504[31], i504[30], i504[29], i504[28], i504[27], i504[26], i504[25], i504[24], i504[23], i504[22], i504[21], i504[20], i504[19], i504[18], i504[17], i504[16], i504[15], i504[14], i504[13], i504[12], i504[11], i504[10], i504[9], i504[8], i504[7], i504[6], i504[5], i504[4], i504[3], i504[2], i504[1], i504[0]};
wire [63:0] t13 = {1'b0, 1'b0, i505[61], i505[60], i505[59], i505[58], i505[57], i505[56], i505[55], i505[54], i505[53], i505[52], i505[51], i505[50], i505[49], i505[48], i505[47], i505[46], i505[45], i505[44], i505[43], i505[42], i505[41], i505[40], i505[39], i505[38], i505[37], i505[36], i505[35], i505[34], i505[33], i505[32], i505[31], i505[30], i505[29], i505[28], i505[27], i505[26], i505[25], i505[24], i505[23], i505[22], i505[21], i505[20], i505[19], i505[18], i505[17], i505[16], i505[15], i505[14], i505[13], i505[12], i505[11], i505[10], i505[9], i505[8], i505[7], i505[6], i505[5], i505[4], i505[3], i505[2], i505[1], i505[0]};
wire [63:0] t14 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i506[49], i506[48], i506[47], i506[46], i506[45], i506[44], i506[43], i506[42], i506[41], i506[40], i506[39], i506[38], i506[37], i506[36], i506[35], i506[34], i506[33], i506[32], i506[31], i506[30], i506[29], i506[28], i506[27], i506[26], i506[25], i506[24], i506[23], i506[22], i506[21], i506[20], i506[19], i506[18], i506[17], i506[16], i506[15], i506[14], i506[13], i506[12], i506[11], i506[10], i506[9], i506[8], i506[7], i506[6], i506[5], i506[4], i506[3], i506[2], i506[1], i506[0]};
wire [63:0] t15 = {i507[63], i507[62], i507[61], i507[60], i507[59], i507[58], i507[57], i507[56], i507[55], i507[54], i507[53], i507[52], i507[51], i507[50], i507[49], i507[48], i507[47], i507[46], i507[45], i507[44], i507[43], i507[42], i507[41], i507[40], i507[39], i507[38], i507[37], i507[36], i507[35], i507[34], i507[33], i507[32], i507[31], i507[30], i507[29], i507[28], i507[27], i507[26], i507[25], i507[24], i507[23], i507[22], i507[21], i507[20], i507[19], i507[18], i507[17], i507[16], i507[15], i507[14], i507[13], i507[12], i507[11], i507[10], i507[9], i507[8], i507[7], i507[6], i507[5], i507[4], i507[3], i507[2], i507[1], i507[0]};
wire [63:0] t16 = {i459[63], i459[62], i459[61], i459[60], i459[59], i459[58], i459[57], i459[56], i459[55], i459[54], i459[53], i459[52], i459[51], i459[50], i459[49], i459[48], i459[47], i459[46], i459[45], i459[44], i459[43], i459[42], i459[41], i459[40], i459[39], i459[38], i459[37], i459[36], i459[35], i459[34], i459[33], i459[32], i459[31], i459[30], i459[29], i459[28], i459[27], i459[26], i459[25], i459[24], i459[23], i459[22], i459[21], i459[20], i459[19], i459[18], i459[17], i459[16], i459[15], i459[14], i459[13], i459[12], i459[11], i459[10], i459[9], i459[8], i459[7], i459[6], i459[5], i459[4], i459[3], i459[2], i459[1], i459[0]};
wire [63:0] sum = t0 + t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14 + t15 + t16;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_18();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_22();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_26();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_30();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_34();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_42();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_46();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_50();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_54();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_58();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_62();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_66();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_70();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_74();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_82();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_86();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_90();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_94();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_98();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_102();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_106();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_118();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_122();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_126();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_146();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_158();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_162();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_166();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_178();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_182();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_186();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_190();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_198();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_202();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_214();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_222();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_226();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_238();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_242();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_246();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_250();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_258();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [7:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [7:0] aa=8'(masked_a);
wire [7:0] bb=8'(masked_b);
wire [7:0] native_value=aa*bb;
assign value=native_value[0+:8];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_266();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270Core(input wire [7:0] a,input wire [11:0] b,input wire cin,output wire [12:0] value);
wire [7:0] masked_a=((a&8'hff)|8'h0);
wire [11:0] masked_b=((b&12'hff0)|12'h0);
wire [12:0] aa=13'(masked_b);
wire [12:0] bb=13'(masked_a);
wire [13:0] extended={1'b0,aa}+{1'b0,bb}+14'(1'b0);
wire [12:0] native_value=extended[12:0];
assign value=native_value[0+:13];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_270();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273Core(input wire [15:0] a,input wire [19:0] b,input wire cin,output wire [20:0] value);
wire [15:0] masked_a=((a&16'hff00)|16'h0);
wire [19:0] masked_b=((b&20'hff000)|20'h0);
wire [20:0] aa=21'(masked_b);
wire [20:0] bb=21'(masked_a);
wire [21:0] extended={1'b0,aa}+{1'b0,bb}+22'(1'b0);
wire [20:0] native_value=extended[20:0];
assign value=native_value[0+:21];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_273();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_276();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282Core(input wire [11:0] a,input wire [15:0] b,input wire cin,output wire [16:0] value);
wire [11:0] masked_a=((a&12'hff0)|12'h0);
wire [15:0] masked_b=((b&16'hff00)|16'h0);
wire [16:0] aa=17'(masked_b);
wire [16:0] bb=17'(masked_a);
wire [17:0] extended={1'b0,aa}+{1'b0,bb}+18'(1'b0);
wire [16:0] native_value=extended[16:0];
assign value=native_value[0+:17];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_282();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_285Core(input wire [19:0] a,input wire [23:0] b,input wire cin,output wire [24:0] value);
wire [19:0] masked_a=((a&20'hff000)|20'h0);
wire [23:0] masked_b=((b&24'hff0000)|24'h0);
wire [24:0] aa=25'(masked_b);
wire [24:0] bb=25'(masked_a);
wire [25:0] extended={1'b0,aa}+{1'b0,bb}+26'(1'b0);
wire [24:0] native_value=extended[24:0];
assign value=native_value[0+:25];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_285();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_288();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294Core(input wire [15:0] a,input wire [19:0] b,input wire cin,output wire [20:0] value);
wire [15:0] masked_a=((a&16'hff00)|16'h0);
wire [19:0] masked_b=((b&20'hff000)|20'h0);
wire [20:0] aa=21'(masked_b);
wire [20:0] bb=21'(masked_a);
wire [21:0] extended={1'b0,aa}+{1'b0,bb}+22'(1'b0);
wire [20:0] native_value=extended[20:0];
assign value=native_value[0+:21];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_297Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_297();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306Core(input wire [19:0] a,input wire [23:0] b,input wire cin,output wire [24:0] value);
wire [19:0] masked_a=((a&20'hff000)|20'h0);
wire [23:0] masked_b=((b&24'hff0000)|24'h0);
wire [24:0] aa=25'(masked_b);
wire [24:0] bb=25'(masked_a);
wire [25:0] extended={1'b0,aa}+{1'b0,bb}+26'(1'b0);
wire [24:0] native_value=extended[24:0];
assign value=native_value[0+:25];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_306();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_312();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_315();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_318Core(input wire [23:0] a,input wire [27:0] b,input wire cin,output wire [28:0] value);
wire [23:0] masked_a=((a&24'hff0000)|24'h0);
wire [27:0] masked_b=((b&28'hff00000)|28'h0);
wire [28:0] aa=29'(masked_b);
wire [28:0] bb=29'(masked_a);
wire [29:0] extended={1'b0,aa}+{1'b0,bb}+30'(1'b0);
wire [28:0] native_value=extended[28:0];
assign value=native_value[0+:29];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_318();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_321Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_321();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_324Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_324();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_327Core(input wire [47:0] a,input wire [51:0] b,input wire cin,output wire [52:0] value);
wire [47:0] masked_a=((a&48'hff0000000000)|48'h0);
wire [51:0] masked_b=((b&52'hff00000000000)|52'h0);
wire [52:0] aa=53'(masked_b);
wire [52:0] bb=53'(masked_a);
wire [53:0] extended={1'b0,aa}+{1'b0,bb}+54'(1'b0);
wire [52:0] native_value=extended[52:0];
assign value=native_value[0+:53];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_327();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [27:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [27:0] masked_a=((a&28'hff00000)|28'h0);
wire [31:0] masked_b=((b&32'hff000000)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_333Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_333();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_336Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_336();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_339Core(input wire [51:0] a,input wire [55:0] b,input wire cin,output wire [56:0] value);
wire [51:0] masked_a=((a&52'hff00000000000)|52'h0);
wire [55:0] masked_b=((b&56'hff000000000000)|56'h0);
wire [56:0] aa=57'(masked_b);
wire [56:0] bb=57'(masked_a);
wire [57:0] extended={1'b0,aa}+{1'b0,bb}+58'(1'b0);
wire [56:0] native_value=extended[56:0];
assign value=native_value[0+:57];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_339();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342Core(input wire [31:0] a,input wire [35:0] b,input wire cin,output wire [36:0] value);
wire [31:0] masked_a=((a&32'hff000000)|32'h0);
wire [35:0] masked_b=((b&36'hff0000000)|36'h0);
wire [36:0] aa=37'(masked_b);
wire [36:0] bb=37'(masked_a);
wire [37:0] extended={1'b0,aa}+{1'b0,bb}+38'(1'b0);
wire [36:0] native_value=extended[36:0];
assign value=native_value[0+:37];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345Core(input wire [39:0] a,input wire [43:0] b,input wire cin,output wire [44:0] value);
wire [39:0] masked_a=((a&40'hff00000000)|40'h0);
wire [43:0] masked_b=((b&44'hff000000000)|44'h0);
wire [44:0] aa=45'(masked_b);
wire [44:0] bb=45'(masked_a);
wire [45:0] extended={1'b0,aa}+{1'b0,bb}+46'(1'b0);
wire [44:0] native_value=extended[44:0];
assign value=native_value[0+:45];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [47:0] a,input wire [51:0] b,input wire cin,output wire [52:0] value);
wire [47:0] masked_a=((a&48'hff0000000000)|48'h0);
wire [51:0] masked_b=((b&52'hff00000000000)|52'h0);
wire [52:0] aa=53'(masked_b);
wire [52:0] bb=53'(masked_a);
wire [53:0] extended={1'b0,aa}+{1'b0,bb}+54'(1'b0);
wire [52:0] native_value=extended[52:0];
assign value=native_value[0+:53];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [55:0] a,input wire [59:0] b,input wire cin,output wire [60:0] value);
wire [55:0] masked_a=((a&56'hff000000000000)|56'h0);
wire [59:0] masked_b=((b&60'hff0000000000000)|60'h0);
wire [60:0] aa=61'(masked_b);
wire [60:0] bb=61'(masked_a);
wire [61:0] extended={1'b0,aa}+{1'b0,bb}+62'(1'b0);
wire [60:0] native_value=extended[60:0];
assign value=native_value[0+:61];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [35:0] a,input wire [39:0] b,input wire cin,output wire [40:0] value);
wire [35:0] masked_a=((a&36'hff0000000)|36'h0);
wire [39:0] masked_b=((b&40'hff00000000)|40'h0);
wire [40:0] aa=41'(masked_b);
wire [40:0] bb=41'(masked_a);
wire [41:0] extended={1'b0,aa}+{1'b0,bb}+42'(1'b0);
wire [40:0] native_value=extended[40:0];
assign value=native_value[0+:41];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357Core(input wire [43:0] a,input wire [47:0] b,input wire cin,output wire [48:0] value);
wire [43:0] masked_a=((a&44'hff000000000)|44'h0);
wire [47:0] masked_b=((b&48'hff0000000000)|48'h0);
wire [48:0] aa=49'(masked_b);
wire [48:0] bb=49'(masked_a);
wire [49:0] extended={1'b0,aa}+{1'b0,bb}+50'(1'b0);
wire [48:0] native_value=extended[48:0];
assign value=native_value[0+:49];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360Core(input wire [51:0] a,input wire [55:0] b,input wire cin,output wire [56:0] value);
wire [51:0] masked_a=((a&52'hff00000000000)|52'h0);
wire [55:0] masked_b=((b&56'hff000000000000)|56'h0);
wire [56:0] aa=57'(masked_b);
wire [56:0] bb=57'(masked_a);
wire [57:0] extended={1'b0,aa}+{1'b0,bb}+58'(1'b0);
wire [56:0] native_value=extended[56:0];
assign value=native_value[0+:57];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_360();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363Core(input wire [59:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [59:0] masked_a=((a&60'hff0000000000000)|60'h0);
wire [63:0] masked_b=((b&64'hff00000000000000)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b0);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_363();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366Core(input wire [12:0] a,input wire [20:0] b,input wire cin,output wire [21:0] value);
wire [12:0] masked_a=((a&13'h1fff)|13'h0);
wire [20:0] masked_b=((b&21'h1fffff)|21'h0);
wire [21:0] aa=22'(masked_b);
wire [21:0] bb=22'(masked_a);
wire [22:0] extended={1'b0,aa}+{1'b0,bb}+23'(1'b0);
wire [21:0] native_value=extended[21:0];
assign value=native_value[0+:22];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_366();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [28:0] a,input wire [36:0] b,input wire cin,output wire [37:0] value);
wire [28:0] masked_a=((a&29'h1fffffff)|29'h0);
wire [36:0] masked_b=((b&37'h1fffffffff)|37'h0);
wire [37:0] aa=38'(masked_b);
wire [37:0] bb=38'(masked_a);
wire [38:0] extended={1'b0,aa}+{1'b0,bb}+39'(1'b0);
wire [37:0] native_value=extended[37:0];
assign value=native_value[0+:38];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_372Core(input wire [16:0] a,input wire [24:0] b,input wire cin,output wire [25:0] value);
wire [16:0] masked_a=((a&17'h1ffff)|17'h0);
wire [24:0] masked_b=((b&25'h1ffffff)|25'h0);
wire [25:0] aa=26'(masked_b);
wire [25:0] bb=26'(masked_a);
wire [26:0] extended={1'b0,aa}+{1'b0,bb}+27'(1'b0);
wire [25:0] native_value=extended[25:0];
assign value=native_value[0+:26];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_372();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_375Core(input wire [32:0] a,input wire [40:0] b,input wire cin,output wire [41:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [40:0] masked_b=((b&41'h1ffffffffff)|41'h0);
wire [41:0] aa=42'(masked_b);
wire [41:0] bb=42'(masked_a);
wire [42:0] extended={1'b0,aa}+{1'b0,bb}+43'(1'b0);
wire [41:0] native_value=extended[41:0];
assign value=native_value[0+:42];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_375();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_378Core(input wire [20:0] a,input wire [28:0] b,input wire cin,output wire [29:0] value);
wire [20:0] masked_a=((a&21'h1fffff)|21'h0);
wire [28:0] masked_b=((b&29'h1fffffff)|29'h0);
wire [29:0] aa=30'(masked_b);
wire [29:0] bb=30'(masked_a);
wire [30:0] extended={1'b0,aa}+{1'b0,bb}+31'(1'b0);
wire [29:0] native_value=extended[29:0];
assign value=native_value[0+:30];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_378();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381Core(input wire [36:0] a,input wire [44:0] b,input wire cin,output wire [45:0] value);
wire [36:0] masked_a=((a&37'h1fffffffff)|37'h0);
wire [44:0] masked_b=((b&45'h1fffffffffff)|45'h0);
wire [45:0] aa=46'(masked_b);
wire [45:0] bb=46'(masked_a);
wire [46:0] extended={1'b0,aa}+{1'b0,bb}+47'(1'b0);
wire [45:0] native_value=extended[45:0];
assign value=native_value[0+:46];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384Core(input wire [24:0] a,input wire [32:0] b,input wire cin,output wire [33:0] value);
wire [24:0] masked_a=((a&25'h1ffffff)|25'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [33:0] aa=34'(masked_b);
wire [33:0] bb=34'(masked_a);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_384();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387Core(input wire [40:0] a,input wire [48:0] b,input wire cin,output wire [49:0] value);
wire [40:0] masked_a=((a&41'h1ffffffffff)|41'h0);
wire [48:0] masked_b=((b&49'h1ffffffffffff)|49'h0);
wire [49:0] aa=50'(masked_b);
wire [49:0] bb=50'(masked_a);
wire [50:0] extended={1'b0,aa}+{1'b0,bb}+51'(1'b0);
wire [49:0] native_value=extended[49:0];
assign value=native_value[0+:50];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390Core(input wire [28:0] a,input wire [36:0] b,input wire cin,output wire [37:0] value);
wire [28:0] masked_a=((a&29'h1fffffff)|29'h0);
wire [36:0] masked_b=((b&37'h1fffffffff)|37'h0);
wire [37:0] aa=38'(masked_b);
wire [37:0] bb=38'(masked_a);
wire [38:0] extended={1'b0,aa}+{1'b0,bb}+39'(1'b0);
wire [37:0] native_value=extended[37:0];
assign value=native_value[0+:38];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393Core(input wire [44:0] a,input wire [52:0] b,input wire cin,output wire [53:0] value);
wire [44:0] masked_a=((a&45'h1fffffffffff)|45'h0);
wire [52:0] masked_b=((b&53'h1fffffffffffff)|53'h0);
wire [53:0] aa=54'(masked_b);
wire [53:0] bb=54'(masked_a);
wire [54:0] extended={1'b0,aa}+{1'b0,bb}+55'(1'b0);
wire [53:0] native_value=extended[53:0];
assign value=native_value[0+:54];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_396Core(input wire [32:0] a,input wire [40:0] b,input wire cin,output wire [41:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [40:0] masked_b=((b&41'h1ffffffffff)|41'h0);
wire [41:0] aa=42'(masked_b);
wire [41:0] bb=42'(masked_a);
wire [42:0] extended={1'b0,aa}+{1'b0,bb}+43'(1'b0);
wire [41:0] native_value=extended[41:0];
assign value=native_value[0+:42];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_396();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_399Core(input wire [48:0] a,input wire [56:0] b,input wire cin,output wire [57:0] value);
wire [48:0] masked_a=((a&49'h1ffffffffffff)|49'h0);
wire [56:0] masked_b=((b&57'h1ffffffffffffff)|57'h0);
wire [57:0] aa=58'(masked_b);
wire [57:0] bb=58'(masked_a);
wire [58:0] extended={1'b0,aa}+{1'b0,bb}+59'(1'b0);
wire [57:0] native_value=extended[57:0];
assign value=native_value[0+:58];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_399();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402Core(input wire [36:0] a,input wire [44:0] b,input wire cin,output wire [45:0] value);
wire [36:0] masked_a=((a&37'h1fffffffff)|37'h0);
wire [44:0] masked_b=((b&45'h1fffffffffff)|45'h0);
wire [45:0] aa=46'(masked_b);
wire [45:0] bb=46'(masked_a);
wire [46:0] extended={1'b0,aa}+{1'b0,bb}+47'(1'b0);
wire [45:0] native_value=extended[45:0];
assign value=native_value[0+:46];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405Core(input wire [52:0] a,input wire [60:0] b,input wire cin,output wire [61:0] value);
wire [52:0] masked_a=((a&53'h1fffffffffffff)|53'h0);
wire [60:0] masked_b=((b&61'h1fffffffffffffff)|61'h0);
wire [61:0] aa=62'(masked_b);
wire [61:0] bb=62'(masked_a);
wire [62:0] extended={1'b0,aa}+{1'b0,bb}+63'(1'b0);
wire [61:0] native_value=extended[61:0];
assign value=native_value[0+:62];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408Core(input wire [40:0] a,input wire [48:0] b,input wire cin,output wire [49:0] value);
wire [40:0] masked_a=((a&41'h1ffffffffff)|41'h0);
wire [48:0] masked_b=((b&49'h1ffffffffffff)|49'h0);
wire [49:0] aa=50'(masked_b);
wire [49:0] bb=50'(masked_a);
wire [50:0] extended={1'b0,aa}+{1'b0,bb}+51'(1'b0);
wire [49:0] native_value=extended[49:0];
assign value=native_value[0+:50];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_411Core(input wire [56:0] a,input wire [64:0] b,input wire cin,output wire [63:0] value);
wire [56:0] masked_a=((a&57'h1ffffffffffffff)|57'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_411();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
