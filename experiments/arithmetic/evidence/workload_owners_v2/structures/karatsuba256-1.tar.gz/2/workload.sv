`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [31:0] limb_13_360; // decl: <none>; prim: <none>
    logic [31:0] limb_13_361; // decl: <none>; prim: <none>
    logic [32:0] limb_13_362; // decl: <none>; prim: <none>
    logic [31:0] limb_13_363; // decl: <none>; prim: <none>
    logic limb_13_364; // decl: <none>; prim: <none>
    logic [31:0] limb_13_365; // decl: <none>; prim: <none>
    logic [31:0] limb_13_366; // decl: <none>; prim: <none>
    logic [32:0] limb_13_367; // decl: <none>; prim: <none>
    logic [31:0] limb_13_368; // decl: <none>; prim: <none>
    logic limb_13_369; // decl: <none>; prim: <none>
    logic limb_13_370; // decl: <none>; prim: <none>
    logic limb_13_371; // decl: <none>; prim: <none>
    logic [1:0] limb_13_372; // decl: <none>; prim: <none>
    logic limb_13_373; // decl: <none>; prim: <none>
    logic [64:0] limb_13_374; // decl: <none>; prim: <none>
    logic [31:0] limb_15_375; // decl: <none>; prim: <none>
    logic [31:0] limb_15_376; // decl: <none>; prim: <none>
    logic [32:0] limb_15_377; // decl: <none>; prim: <none>
    logic [31:0] limb_15_378; // decl: <none>; prim: <none>
    logic limb_15_379; // decl: <none>; prim: <none>
    logic [31:0] limb_15_380; // decl: <none>; prim: <none>
    logic [31:0] limb_15_381; // decl: <none>; prim: <none>
    logic [32:0] limb_15_382; // decl: <none>; prim: <none>
    logic [31:0] limb_15_383; // decl: <none>; prim: <none>
    logic limb_15_384; // decl: <none>; prim: <none>
    logic limb_15_385; // decl: <none>; prim: <none>
    logic limb_15_386; // decl: <none>; prim: <none>
    logic [1:0] limb_15_387; // decl: <none>; prim: <none>
    logic limb_15_388; // decl: <none>; prim: <none>
    logic [64:0] limb_15_389; // decl: <none>; prim: <none>
    logic [31:0] limb_21_390; // decl: <none>; prim: <none>
    logic [31:0] limb_21_391; // decl: <none>; prim: <none>
    logic [32:0] limb_21_392; // decl: <none>; prim: <none>
    logic [31:0] limb_21_393; // decl: <none>; prim: <none>
    logic limb_21_394; // decl: <none>; prim: <none>
    logic [1:0] limb_21_395; // decl: <none>; prim: <none>
    logic [1:0] limb_21_396; // decl: <none>; prim: <none>
    logic [2:0] limb_21_397; // decl: <none>; prim: <none>
    logic [1:0] limb_21_398; // decl: <none>; prim: <none>
    logic [33:0] limb_21_399; // decl: <none>; prim: <none>
    logic [31:0] limb_23_400; // decl: <none>; prim: <none>
    logic [31:0] limb_23_401; // decl: <none>; prim: <none>
    logic [32:0] limb_23_402; // decl: <none>; prim: <none>
    logic [31:0] limb_23_403; // decl: <none>; prim: <none>
    logic limb_23_404; // decl: <none>; prim: <none>
    logic [1:0] limb_23_405; // decl: <none>; prim: <none>
    logic [1:0] limb_23_406; // decl: <none>; prim: <none>
    logic [2:0] limb_23_407; // decl: <none>; prim: <none>
    logic [1:0] limb_23_408; // decl: <none>; prim: <none>
    logic [33:0] limb_23_409; // decl: <none>; prim: <none>
    logic [31:0] limb_29_410; // decl: <none>; prim: <none>
    logic [31:0] limb_29_411; // decl: <none>; prim: <none>
    logic [31:0] limb_29_412; // decl: <none>; prim: <none>
    logic [32:0] limb_29_413; // decl: <none>; prim: <none>
    logic [31:0] limb_29_414; // decl: <none>; prim: <none>
    logic limb_29_415; // decl: <none>; prim: <none>
    logic [31:0] limb_29_416; // decl: <none>; prim: <none>
    logic [31:0] limb_29_417; // decl: <none>; prim: <none>
    logic [31:0] limb_29_418; // decl: <none>; prim: <none>
    logic [32:0] limb_29_419; // decl: <none>; prim: <none>
    logic [31:0] limb_29_420; // decl: <none>; prim: <none>
    logic limb_29_421; // decl: <none>; prim: <none>
    logic [3:0] limb_29_422; // decl: <none>; prim: <none>
    logic [3:0] limb_29_423; // decl: <none>; prim: <none>
    logic [3:0] limb_29_424; // decl: <none>; prim: <none>
    logic [4:0] limb_29_425; // decl: <none>; prim: <none>
    logic [3:0] limb_29_426; // decl: <none>; prim: <none>
    logic [67:0] limb_29_427; // decl: <none>; prim: <none>
    logic [31:0] limb_31_428; // decl: <none>; prim: <none>
    logic [31:0] limb_31_429; // decl: <none>; prim: <none>
    logic [31:0] limb_31_430; // decl: <none>; prim: <none>
    logic [32:0] limb_31_431; // decl: <none>; prim: <none>
    logic [31:0] limb_31_432; // decl: <none>; prim: <none>
    logic limb_31_433; // decl: <none>; prim: <none>
    logic [31:0] limb_31_434; // decl: <none>; prim: <none>
    logic [31:0] limb_31_435; // decl: <none>; prim: <none>
    logic [31:0] limb_31_436; // decl: <none>; prim: <none>
    logic [32:0] limb_31_437; // decl: <none>; prim: <none>
    logic [31:0] limb_31_438; // decl: <none>; prim: <none>
    logic limb_31_439; // decl: <none>; prim: <none>
    logic [3:0] limb_31_440; // decl: <none>; prim: <none>
    logic [3:0] limb_31_441; // decl: <none>; prim: <none>
    logic [3:0] limb_31_442; // decl: <none>; prim: <none>
    logic [4:0] limb_31_443; // decl: <none>; prim: <none>
    logic [3:0] limb_31_444; // decl: <none>; prim: <none>
    logic [67:0] limb_31_445; // decl: <none>; prim: <none>
    logic [31:0] limb_38_446; // decl: <none>; prim: <none>
    logic [31:0] limb_38_447; // decl: <none>; prim: <none>
    logic [31:0] limb_38_448; // decl: <none>; prim: <none>
    logic [32:0] limb_38_449; // decl: <none>; prim: <none>
    logic [31:0] limb_38_450; // decl: <none>; prim: <none>
    logic limb_38_451; // decl: <none>; prim: <none>
    logic [31:0] limb_38_452; // decl: <none>; prim: <none>
    logic [31:0] limb_38_453; // decl: <none>; prim: <none>
    logic [31:0] limb_38_454; // decl: <none>; prim: <none>
    logic [32:0] limb_38_455; // decl: <none>; prim: <none>
    logic [31:0] limb_38_456; // decl: <none>; prim: <none>
    logic limb_38_457; // decl: <none>; prim: <none>
    logic [31:0] limb_38_458; // decl: <none>; prim: <none>
    logic [31:0] limb_38_459; // decl: <none>; prim: <none>
    logic [31:0] limb_38_460; // decl: <none>; prim: <none>
    logic [32:0] limb_38_461; // decl: <none>; prim: <none>
    logic [31:0] limb_38_462; // decl: <none>; prim: <none>
    logic limb_38_463; // decl: <none>; prim: <none>
    logic [31:0] limb_38_464; // decl: <none>; prim: <none>
    logic [31:0] limb_38_465; // decl: <none>; prim: <none>
    logic [31:0] limb_38_466; // decl: <none>; prim: <none>
    logic [32:0] limb_38_467; // decl: <none>; prim: <none>
    logic [31:0] limb_38_468; // decl: <none>; prim: <none>
    logic limb_38_469; // decl: <none>; prim: <none>
    logic [1:0] limb_38_470; // decl: <none>; prim: <none>
    logic [1:0] limb_38_471; // decl: <none>; prim: <none>
    logic [1:0] limb_38_472; // decl: <none>; prim: <none>
    logic [2:0] limb_38_473; // decl: <none>; prim: <none>
    logic [1:0] limb_38_474; // decl: <none>; prim: <none>
    logic [129:0] limb_38_475; // decl: <none>; prim: <none>
    logic [31:0] limb_40_476; // decl: <none>; prim: <none>
    logic [31:0] limb_40_477; // decl: <none>; prim: <none>
    logic [31:0] limb_40_478; // decl: <none>; prim: <none>
    logic [32:0] limb_40_479; // decl: <none>; prim: <none>
    logic [31:0] limb_40_480; // decl: <none>; prim: <none>
    logic limb_40_481; // decl: <none>; prim: <none>
    logic [31:0] limb_40_482; // decl: <none>; prim: <none>
    logic [31:0] limb_40_483; // decl: <none>; prim: <none>
    logic [31:0] limb_40_484; // decl: <none>; prim: <none>
    logic [32:0] limb_40_485; // decl: <none>; prim: <none>
    logic [31:0] limb_40_486; // decl: <none>; prim: <none>
    logic limb_40_487; // decl: <none>; prim: <none>
    logic [31:0] limb_40_488; // decl: <none>; prim: <none>
    logic [31:0] limb_40_489; // decl: <none>; prim: <none>
    logic [31:0] limb_40_490; // decl: <none>; prim: <none>
    logic [32:0] limb_40_491; // decl: <none>; prim: <none>
    logic [31:0] limb_40_492; // decl: <none>; prim: <none>
    logic limb_40_493; // decl: <none>; prim: <none>
    logic [31:0] limb_40_494; // decl: <none>; prim: <none>
    logic [31:0] limb_40_495; // decl: <none>; prim: <none>
    logic [31:0] limb_40_496; // decl: <none>; prim: <none>
    logic [32:0] limb_40_497; // decl: <none>; prim: <none>
    logic [31:0] limb_40_498; // decl: <none>; prim: <none>
    logic limb_40_499; // decl: <none>; prim: <none>
    logic [1:0] limb_40_500; // decl: <none>; prim: <none>
    logic [1:0] limb_40_501; // decl: <none>; prim: <none>
    logic [1:0] limb_40_502; // decl: <none>; prim: <none>
    logic [2:0] limb_40_503; // decl: <none>; prim: <none>
    logic [1:0] limb_40_504; // decl: <none>; prim: <none>
    logic [129:0] limb_40_505; // decl: <none>; prim: <none>
    logic [31:0] limb_51_506; // decl: <none>; prim: <none>
    logic [31:0] limb_51_507; // decl: <none>; prim: <none>
    logic [32:0] limb_51_508; // decl: <none>; prim: <none>
    logic [31:0] limb_51_509; // decl: <none>; prim: <none>
    logic limb_51_510; // decl: <none>; prim: <none>
    logic [31:0] limb_51_511; // decl: <none>; prim: <none>
    logic [31:0] limb_51_512; // decl: <none>; prim: <none>
    logic [32:0] limb_51_513; // decl: <none>; prim: <none>
    logic [31:0] limb_51_514; // decl: <none>; prim: <none>
    logic limb_51_515; // decl: <none>; prim: <none>
    logic limb_51_516; // decl: <none>; prim: <none>
    logic limb_51_517; // decl: <none>; prim: <none>
    logic [1:0] limb_51_518; // decl: <none>; prim: <none>
    logic limb_51_519; // decl: <none>; prim: <none>
    logic [64:0] limb_51_520; // decl: <none>; prim: <none>
    logic [31:0] limb_53_521; // decl: <none>; prim: <none>
    logic [31:0] limb_53_522; // decl: <none>; prim: <none>
    logic [32:0] limb_53_523; // decl: <none>; prim: <none>
    logic [31:0] limb_53_524; // decl: <none>; prim: <none>
    logic limb_53_525; // decl: <none>; prim: <none>
    logic [31:0] limb_53_526; // decl: <none>; prim: <none>
    logic [31:0] limb_53_527; // decl: <none>; prim: <none>
    logic [32:0] limb_53_528; // decl: <none>; prim: <none>
    logic [31:0] limb_53_529; // decl: <none>; prim: <none>
    logic limb_53_530; // decl: <none>; prim: <none>
    logic limb_53_531; // decl: <none>; prim: <none>
    logic limb_53_532; // decl: <none>; prim: <none>
    logic [1:0] limb_53_533; // decl: <none>; prim: <none>
    logic limb_53_534; // decl: <none>; prim: <none>
    logic [64:0] limb_53_535; // decl: <none>; prim: <none>
    logic [31:0] limb_59_536; // decl: <none>; prim: <none>
    logic [31:0] limb_59_537; // decl: <none>; prim: <none>
    logic [32:0] limb_59_538; // decl: <none>; prim: <none>
    logic [31:0] limb_59_539; // decl: <none>; prim: <none>
    logic limb_59_540; // decl: <none>; prim: <none>
    logic [1:0] limb_59_541; // decl: <none>; prim: <none>
    logic [1:0] limb_59_542; // decl: <none>; prim: <none>
    logic [2:0] limb_59_543; // decl: <none>; prim: <none>
    logic [1:0] limb_59_544; // decl: <none>; prim: <none>
    logic [33:0] limb_59_545; // decl: <none>; prim: <none>
    logic [31:0] limb_61_546; // decl: <none>; prim: <none>
    logic [31:0] limb_61_547; // decl: <none>; prim: <none>
    logic [32:0] limb_61_548; // decl: <none>; prim: <none>
    logic [31:0] limb_61_549; // decl: <none>; prim: <none>
    logic limb_61_550; // decl: <none>; prim: <none>
    logic [1:0] limb_61_551; // decl: <none>; prim: <none>
    logic [1:0] limb_61_552; // decl: <none>; prim: <none>
    logic [2:0] limb_61_553; // decl: <none>; prim: <none>
    logic [1:0] limb_61_554; // decl: <none>; prim: <none>
    logic [33:0] limb_61_555; // decl: <none>; prim: <none>
    logic [31:0] limb_67_556; // decl: <none>; prim: <none>
    logic [31:0] limb_67_557; // decl: <none>; prim: <none>
    logic [31:0] limb_67_558; // decl: <none>; prim: <none>
    logic [32:0] limb_67_559; // decl: <none>; prim: <none>
    logic [31:0] limb_67_560; // decl: <none>; prim: <none>
    logic limb_67_561; // decl: <none>; prim: <none>
    logic [31:0] limb_67_562; // decl: <none>; prim: <none>
    logic [31:0] limb_67_563; // decl: <none>; prim: <none>
    logic [31:0] limb_67_564; // decl: <none>; prim: <none>
    logic [32:0] limb_67_565; // decl: <none>; prim: <none>
    logic [31:0] limb_67_566; // decl: <none>; prim: <none>
    logic limb_67_567; // decl: <none>; prim: <none>
    logic [3:0] limb_67_568; // decl: <none>; prim: <none>
    logic [3:0] limb_67_569; // decl: <none>; prim: <none>
    logic [3:0] limb_67_570; // decl: <none>; prim: <none>
    logic [4:0] limb_67_571; // decl: <none>; prim: <none>
    logic [3:0] limb_67_572; // decl: <none>; prim: <none>
    logic [67:0] limb_67_573; // decl: <none>; prim: <none>
    logic [31:0] limb_69_574; // decl: <none>; prim: <none>
    logic [31:0] limb_69_575; // decl: <none>; prim: <none>
    logic [31:0] limb_69_576; // decl: <none>; prim: <none>
    logic [32:0] limb_69_577; // decl: <none>; prim: <none>
    logic [31:0] limb_69_578; // decl: <none>; prim: <none>
    logic limb_69_579; // decl: <none>; prim: <none>
    logic [31:0] limb_69_580; // decl: <none>; prim: <none>
    logic [31:0] limb_69_581; // decl: <none>; prim: <none>
    logic [31:0] limb_69_582; // decl: <none>; prim: <none>
    logic [32:0] limb_69_583; // decl: <none>; prim: <none>
    logic [31:0] limb_69_584; // decl: <none>; prim: <none>
    logic limb_69_585; // decl: <none>; prim: <none>
    logic [3:0] limb_69_586; // decl: <none>; prim: <none>
    logic [3:0] limb_69_587; // decl: <none>; prim: <none>
    logic [3:0] limb_69_588; // decl: <none>; prim: <none>
    logic [4:0] limb_69_589; // decl: <none>; prim: <none>
    logic [3:0] limb_69_590; // decl: <none>; prim: <none>
    logic [67:0] limb_69_591; // decl: <none>; prim: <none>
    logic [31:0] limb_76_592; // decl: <none>; prim: <none>
    logic [31:0] limb_76_593; // decl: <none>; prim: <none>
    logic [31:0] limb_76_594; // decl: <none>; prim: <none>
    logic [32:0] limb_76_595; // decl: <none>; prim: <none>
    logic [31:0] limb_76_596; // decl: <none>; prim: <none>
    logic limb_76_597; // decl: <none>; prim: <none>
    logic [31:0] limb_76_598; // decl: <none>; prim: <none>
    logic [31:0] limb_76_599; // decl: <none>; prim: <none>
    logic [31:0] limb_76_600; // decl: <none>; prim: <none>
    logic [32:0] limb_76_601; // decl: <none>; prim: <none>
    logic [31:0] limb_76_602; // decl: <none>; prim: <none>
    logic limb_76_603; // decl: <none>; prim: <none>
    logic [31:0] limb_76_604; // decl: <none>; prim: <none>
    logic [31:0] limb_76_605; // decl: <none>; prim: <none>
    logic [31:0] limb_76_606; // decl: <none>; prim: <none>
    logic [32:0] limb_76_607; // decl: <none>; prim: <none>
    logic [31:0] limb_76_608; // decl: <none>; prim: <none>
    logic limb_76_609; // decl: <none>; prim: <none>
    logic [31:0] limb_76_610; // decl: <none>; prim: <none>
    logic [31:0] limb_76_611; // decl: <none>; prim: <none>
    logic [31:0] limb_76_612; // decl: <none>; prim: <none>
    logic [32:0] limb_76_613; // decl: <none>; prim: <none>
    logic [31:0] limb_76_614; // decl: <none>; prim: <none>
    logic limb_76_615; // decl: <none>; prim: <none>
    logic [1:0] limb_76_616; // decl: <none>; prim: <none>
    logic [1:0] limb_76_617; // decl: <none>; prim: <none>
    logic [1:0] limb_76_618; // decl: <none>; prim: <none>
    logic [2:0] limb_76_619; // decl: <none>; prim: <none>
    logic [1:0] limb_76_620; // decl: <none>; prim: <none>
    logic [129:0] limb_76_621; // decl: <none>; prim: <none>
    logic [31:0] limb_78_622; // decl: <none>; prim: <none>
    logic [31:0] limb_78_623; // decl: <none>; prim: <none>
    logic [31:0] limb_78_624; // decl: <none>; prim: <none>
    logic [32:0] limb_78_625; // decl: <none>; prim: <none>
    logic [31:0] limb_78_626; // decl: <none>; prim: <none>
    logic limb_78_627; // decl: <none>; prim: <none>
    logic [31:0] limb_78_628; // decl: <none>; prim: <none>
    logic [31:0] limb_78_629; // decl: <none>; prim: <none>
    logic [31:0] limb_78_630; // decl: <none>; prim: <none>
    logic [32:0] limb_78_631; // decl: <none>; prim: <none>
    logic [31:0] limb_78_632; // decl: <none>; prim: <none>
    logic limb_78_633; // decl: <none>; prim: <none>
    logic [31:0] limb_78_634; // decl: <none>; prim: <none>
    logic [31:0] limb_78_635; // decl: <none>; prim: <none>
    logic [31:0] limb_78_636; // decl: <none>; prim: <none>
    logic [32:0] limb_78_637; // decl: <none>; prim: <none>
    logic [31:0] limb_78_638; // decl: <none>; prim: <none>
    logic limb_78_639; // decl: <none>; prim: <none>
    logic [31:0] limb_78_640; // decl: <none>; prim: <none>
    logic [31:0] limb_78_641; // decl: <none>; prim: <none>
    logic [31:0] limb_78_642; // decl: <none>; prim: <none>
    logic [32:0] limb_78_643; // decl: <none>; prim: <none>
    logic [31:0] limb_78_644; // decl: <none>; prim: <none>
    logic limb_78_645; // decl: <none>; prim: <none>
    logic [1:0] limb_78_646; // decl: <none>; prim: <none>
    logic [1:0] limb_78_647; // decl: <none>; prim: <none>
    logic [1:0] limb_78_648; // decl: <none>; prim: <none>
    logic [2:0] limb_78_649; // decl: <none>; prim: <none>
    logic [1:0] limb_78_650; // decl: <none>; prim: <none>
    logic [129:0] limb_78_651; // decl: <none>; prim: <none>
    logic [31:0] limb_85_652; // decl: <none>; prim: <none>
    logic [31:0] limb_85_653; // decl: <none>; prim: <none>
    logic [32:0] limb_85_654; // decl: <none>; prim: <none>
    logic [31:0] limb_85_655; // decl: <none>; prim: <none>
    logic limb_85_656; // decl: <none>; prim: <none>
    logic [31:0] limb_85_657; // decl: <none>; prim: <none>
    logic [31:0] limb_85_658; // decl: <none>; prim: <none>
    logic [32:0] limb_85_659; // decl: <none>; prim: <none>
    logic [31:0] limb_85_660; // decl: <none>; prim: <none>
    logic limb_85_661; // decl: <none>; prim: <none>
    logic [31:0] limb_85_662; // decl: <none>; prim: <none>
    logic [31:0] limb_85_663; // decl: <none>; prim: <none>
    logic [32:0] limb_85_664; // decl: <none>; prim: <none>
    logic [31:0] limb_85_665; // decl: <none>; prim: <none>
    logic limb_85_666; // decl: <none>; prim: <none>
    logic [31:0] limb_85_667; // decl: <none>; prim: <none>
    logic [31:0] limb_85_668; // decl: <none>; prim: <none>
    logic [32:0] limb_85_669; // decl: <none>; prim: <none>
    logic [31:0] limb_85_670; // decl: <none>; prim: <none>
    logic limb_85_671; // decl: <none>; prim: <none>
    logic limb_85_672; // decl: <none>; prim: <none>
    logic limb_85_673; // decl: <none>; prim: <none>
    logic [1:0] limb_85_674; // decl: <none>; prim: <none>
    logic limb_85_675; // decl: <none>; prim: <none>
    logic [128:0] limb_85_676; // decl: <none>; prim: <none>
    logic [31:0] limb_87_677; // decl: <none>; prim: <none>
    logic [31:0] limb_87_678; // decl: <none>; prim: <none>
    logic [32:0] limb_87_679; // decl: <none>; prim: <none>
    logic [31:0] limb_87_680; // decl: <none>; prim: <none>
    logic limb_87_681; // decl: <none>; prim: <none>
    logic [31:0] limb_87_682; // decl: <none>; prim: <none>
    logic [31:0] limb_87_683; // decl: <none>; prim: <none>
    logic [32:0] limb_87_684; // decl: <none>; prim: <none>
    logic [31:0] limb_87_685; // decl: <none>; prim: <none>
    logic limb_87_686; // decl: <none>; prim: <none>
    logic [31:0] limb_87_687; // decl: <none>; prim: <none>
    logic [31:0] limb_87_688; // decl: <none>; prim: <none>
    logic [32:0] limb_87_689; // decl: <none>; prim: <none>
    logic [31:0] limb_87_690; // decl: <none>; prim: <none>
    logic limb_87_691; // decl: <none>; prim: <none>
    logic [31:0] limb_87_692; // decl: <none>; prim: <none>
    logic [31:0] limb_87_693; // decl: <none>; prim: <none>
    logic [32:0] limb_87_694; // decl: <none>; prim: <none>
    logic [31:0] limb_87_695; // decl: <none>; prim: <none>
    logic limb_87_696; // decl: <none>; prim: <none>
    logic limb_87_697; // decl: <none>; prim: <none>
    logic limb_87_698; // decl: <none>; prim: <none>
    logic [1:0] limb_87_699; // decl: <none>; prim: <none>
    logic limb_87_700; // decl: <none>; prim: <none>
    logic [128:0] limb_87_701; // decl: <none>; prim: <none>
    logic [31:0] limb_95_702; // decl: <none>; prim: <none>
    logic [31:0] limb_95_703; // decl: <none>; prim: <none>
    logic [32:0] limb_95_704; // decl: <none>; prim: <none>
    logic [31:0] limb_95_705; // decl: <none>; prim: <none>
    logic limb_95_706; // decl: <none>; prim: <none>
    logic [1:0] limb_95_707; // decl: <none>; prim: <none>
    logic [1:0] limb_95_708; // decl: <none>; prim: <none>
    logic [2:0] limb_95_709; // decl: <none>; prim: <none>
    logic [1:0] limb_95_710; // decl: <none>; prim: <none>
    logic [33:0] limb_95_711; // decl: <none>; prim: <none>
    logic [31:0] limb_97_712; // decl: <none>; prim: <none>
    logic [31:0] limb_97_713; // decl: <none>; prim: <none>
    logic [32:0] limb_97_714; // decl: <none>; prim: <none>
    logic [31:0] limb_97_715; // decl: <none>; prim: <none>
    logic limb_97_716; // decl: <none>; prim: <none>
    logic [1:0] limb_97_717; // decl: <none>; prim: <none>
    logic [1:0] limb_97_718; // decl: <none>; prim: <none>
    logic [2:0] limb_97_719; // decl: <none>; prim: <none>
    logic [1:0] limb_97_720; // decl: <none>; prim: <none>
    logic [33:0] limb_97_721; // decl: <none>; prim: <none>
    logic [31:0] limb_103_722; // decl: <none>; prim: <none>
    logic [31:0] limb_103_723; // decl: <none>; prim: <none>
    logic [31:0] limb_103_724; // decl: <none>; prim: <none>
    logic [32:0] limb_103_725; // decl: <none>; prim: <none>
    logic [31:0] limb_103_726; // decl: <none>; prim: <none>
    logic limb_103_727; // decl: <none>; prim: <none>
    logic [31:0] limb_103_728; // decl: <none>; prim: <none>
    logic [31:0] limb_103_729; // decl: <none>; prim: <none>
    logic [31:0] limb_103_730; // decl: <none>; prim: <none>
    logic [32:0] limb_103_731; // decl: <none>; prim: <none>
    logic [31:0] limb_103_732; // decl: <none>; prim: <none>
    logic limb_103_733; // decl: <none>; prim: <none>
    logic [3:0] limb_103_734; // decl: <none>; prim: <none>
    logic [3:0] limb_103_735; // decl: <none>; prim: <none>
    logic [3:0] limb_103_736; // decl: <none>; prim: <none>
    logic [4:0] limb_103_737; // decl: <none>; prim: <none>
    logic [3:0] limb_103_738; // decl: <none>; prim: <none>
    logic [67:0] limb_103_739; // decl: <none>; prim: <none>
    logic [31:0] limb_105_740; // decl: <none>; prim: <none>
    logic [31:0] limb_105_741; // decl: <none>; prim: <none>
    logic [31:0] limb_105_742; // decl: <none>; prim: <none>
    logic [32:0] limb_105_743; // decl: <none>; prim: <none>
    logic [31:0] limb_105_744; // decl: <none>; prim: <none>
    logic limb_105_745; // decl: <none>; prim: <none>
    logic [31:0] limb_105_746; // decl: <none>; prim: <none>
    logic [31:0] limb_105_747; // decl: <none>; prim: <none>
    logic [31:0] limb_105_748; // decl: <none>; prim: <none>
    logic [32:0] limb_105_749; // decl: <none>; prim: <none>
    logic [31:0] limb_105_750; // decl: <none>; prim: <none>
    logic limb_105_751; // decl: <none>; prim: <none>
    logic [3:0] limb_105_752; // decl: <none>; prim: <none>
    logic [3:0] limb_105_753; // decl: <none>; prim: <none>
    logic [3:0] limb_105_754; // decl: <none>; prim: <none>
    logic [4:0] limb_105_755; // decl: <none>; prim: <none>
    logic [3:0] limb_105_756; // decl: <none>; prim: <none>
    logic [67:0] limb_105_757; // decl: <none>; prim: <none>
    logic [31:0] limb_113_758; // decl: <none>; prim: <none>
    logic [31:0] limb_113_759; // decl: <none>; prim: <none>
    logic [32:0] limb_113_760; // decl: <none>; prim: <none>
    logic [31:0] limb_113_761; // decl: <none>; prim: <none>
    logic limb_113_762; // decl: <none>; prim: <none>
    logic [31:0] limb_113_763; // decl: <none>; prim: <none>
    logic [31:0] limb_113_764; // decl: <none>; prim: <none>
    logic [32:0] limb_113_765; // decl: <none>; prim: <none>
    logic [31:0] limb_113_766; // decl: <none>; prim: <none>
    logic limb_113_767; // decl: <none>; prim: <none>
    logic [1:0] limb_113_768; // decl: <none>; prim: <none>
    logic [1:0] limb_113_769; // decl: <none>; prim: <none>
    logic [2:0] limb_113_770; // decl: <none>; prim: <none>
    logic [1:0] limb_113_771; // decl: <none>; prim: <none>
    logic [65:0] limb_113_772; // decl: <none>; prim: <none>
    logic [31:0] limb_115_773; // decl: <none>; prim: <none>
    logic [31:0] limb_115_774; // decl: <none>; prim: <none>
    logic [32:0] limb_115_775; // decl: <none>; prim: <none>
    logic [31:0] limb_115_776; // decl: <none>; prim: <none>
    logic limb_115_777; // decl: <none>; prim: <none>
    logic [31:0] limb_115_778; // decl: <none>; prim: <none>
    logic [31:0] limb_115_779; // decl: <none>; prim: <none>
    logic [32:0] limb_115_780; // decl: <none>; prim: <none>
    logic [31:0] limb_115_781; // decl: <none>; prim: <none>
    logic limb_115_782; // decl: <none>; prim: <none>
    logic [1:0] limb_115_783; // decl: <none>; prim: <none>
    logic [1:0] limb_115_784; // decl: <none>; prim: <none>
    logic [2:0] limb_115_785; // decl: <none>; prim: <none>
    logic [1:0] limb_115_786; // decl: <none>; prim: <none>
    logic [65:0] limb_115_787; // decl: <none>; prim: <none>
    logic [31:0] limb_121_788; // decl: <none>; prim: <none>
    logic [31:0] limb_121_789; // decl: <none>; prim: <none>
    logic [32:0] limb_121_790; // decl: <none>; prim: <none>
    logic [31:0] limb_121_791; // decl: <none>; prim: <none>
    logic limb_121_792; // decl: <none>; prim: <none>
    logic [1:0] limb_121_793; // decl: <none>; prim: <none>
    logic [1:0] limb_121_794; // decl: <none>; prim: <none>
    logic [2:0] limb_121_795; // decl: <none>; prim: <none>
    logic [1:0] limb_121_796; // decl: <none>; prim: <none>
    logic [33:0] limb_121_797; // decl: <none>; prim: <none>
    logic [31:0] limb_123_798; // decl: <none>; prim: <none>
    logic [31:0] limb_123_799; // decl: <none>; prim: <none>
    logic [32:0] limb_123_800; // decl: <none>; prim: <none>
    logic [31:0] limb_123_801; // decl: <none>; prim: <none>
    logic limb_123_802; // decl: <none>; prim: <none>
    logic [1:0] limb_123_803; // decl: <none>; prim: <none>
    logic [1:0] limb_123_804; // decl: <none>; prim: <none>
    logic [2:0] limb_123_805; // decl: <none>; prim: <none>
    logic [1:0] limb_123_806; // decl: <none>; prim: <none>
    logic [33:0] limb_123_807; // decl: <none>; prim: <none>
    logic [31:0] limb_129_808; // decl: <none>; prim: <none>
    logic [31:0] limb_129_809; // decl: <none>; prim: <none>
    logic [31:0] limb_129_810; // decl: <none>; prim: <none>
    logic [32:0] limb_129_811; // decl: <none>; prim: <none>
    logic [31:0] limb_129_812; // decl: <none>; prim: <none>
    logic limb_129_813; // decl: <none>; prim: <none>
    logic [31:0] limb_129_814; // decl: <none>; prim: <none>
    logic [31:0] limb_129_815; // decl: <none>; prim: <none>
    logic [31:0] limb_129_816; // decl: <none>; prim: <none>
    logic [32:0] limb_129_817; // decl: <none>; prim: <none>
    logic [31:0] limb_129_818; // decl: <none>; prim: <none>
    logic limb_129_819; // decl: <none>; prim: <none>
    logic [3:0] limb_129_820; // decl: <none>; prim: <none>
    logic [3:0] limb_129_821; // decl: <none>; prim: <none>
    logic [3:0] limb_129_822; // decl: <none>; prim: <none>
    logic [4:0] limb_129_823; // decl: <none>; prim: <none>
    logic [3:0] limb_129_824; // decl: <none>; prim: <none>
    logic [67:0] limb_129_825; // decl: <none>; prim: <none>
    logic [31:0] limb_131_826; // decl: <none>; prim: <none>
    logic [31:0] limb_131_827; // decl: <none>; prim: <none>
    logic [31:0] limb_131_828; // decl: <none>; prim: <none>
    logic [32:0] limb_131_829; // decl: <none>; prim: <none>
    logic [31:0] limb_131_830; // decl: <none>; prim: <none>
    logic limb_131_831; // decl: <none>; prim: <none>
    logic [31:0] limb_131_832; // decl: <none>; prim: <none>
    logic [31:0] limb_131_833; // decl: <none>; prim: <none>
    logic [31:0] limb_131_834; // decl: <none>; prim: <none>
    logic [32:0] limb_131_835; // decl: <none>; prim: <none>
    logic [31:0] limb_131_836; // decl: <none>; prim: <none>
    logic limb_131_837; // decl: <none>; prim: <none>
    logic [3:0] limb_131_838; // decl: <none>; prim: <none>
    logic [3:0] limb_131_839; // decl: <none>; prim: <none>
    logic [3:0] limb_131_840; // decl: <none>; prim: <none>
    logic [4:0] limb_131_841; // decl: <none>; prim: <none>
    logic [3:0] limb_131_842; // decl: <none>; prim: <none>
    logic [67:0] limb_131_843; // decl: <none>; prim: <none>
    logic [31:0] limb_138_844; // decl: <none>; prim: <none>
    logic [31:0] limb_138_845; // decl: <none>; prim: <none>
    logic [31:0] limb_138_846; // decl: <none>; prim: <none>
    logic [32:0] limb_138_847; // decl: <none>; prim: <none>
    logic [31:0] limb_138_848; // decl: <none>; prim: <none>
    logic limb_138_849; // decl: <none>; prim: <none>
    logic [31:0] limb_138_850; // decl: <none>; prim: <none>
    logic [31:0] limb_138_851; // decl: <none>; prim: <none>
    logic [31:0] limb_138_852; // decl: <none>; prim: <none>
    logic [32:0] limb_138_853; // decl: <none>; prim: <none>
    logic [31:0] limb_138_854; // decl: <none>; prim: <none>
    logic limb_138_855; // decl: <none>; prim: <none>
    logic [31:0] limb_138_856; // decl: <none>; prim: <none>
    logic [31:0] limb_138_857; // decl: <none>; prim: <none>
    logic [31:0] limb_138_858; // decl: <none>; prim: <none>
    logic [32:0] limb_138_859; // decl: <none>; prim: <none>
    logic [31:0] limb_138_860; // decl: <none>; prim: <none>
    logic limb_138_861; // decl: <none>; prim: <none>
    logic [31:0] limb_138_862; // decl: <none>; prim: <none>
    logic [31:0] limb_138_863; // decl: <none>; prim: <none>
    logic [31:0] limb_138_864; // decl: <none>; prim: <none>
    logic [32:0] limb_138_865; // decl: <none>; prim: <none>
    logic [31:0] limb_138_866; // decl: <none>; prim: <none>
    logic limb_138_867; // decl: <none>; prim: <none>
    logic [3:0] limb_138_868; // decl: <none>; prim: <none>
    logic [3:0] limb_138_869; // decl: <none>; prim: <none>
    logic [3:0] limb_138_870; // decl: <none>; prim: <none>
    logic [4:0] limb_138_871; // decl: <none>; prim: <none>
    logic [3:0] limb_138_872; // decl: <none>; prim: <none>
    logic [131:0] limb_138_873; // decl: <none>; prim: <none>
    logic [31:0] limb_140_874; // decl: <none>; prim: <none>
    logic [31:0] limb_140_875; // decl: <none>; prim: <none>
    logic [31:0] limb_140_876; // decl: <none>; prim: <none>
    logic [32:0] limb_140_877; // decl: <none>; prim: <none>
    logic [31:0] limb_140_878; // decl: <none>; prim: <none>
    logic limb_140_879; // decl: <none>; prim: <none>
    logic [31:0] limb_140_880; // decl: <none>; prim: <none>
    logic [31:0] limb_140_881; // decl: <none>; prim: <none>
    logic [31:0] limb_140_882; // decl: <none>; prim: <none>
    logic [32:0] limb_140_883; // decl: <none>; prim: <none>
    logic [31:0] limb_140_884; // decl: <none>; prim: <none>
    logic limb_140_885; // decl: <none>; prim: <none>
    logic [31:0] limb_140_886; // decl: <none>; prim: <none>
    logic [31:0] limb_140_887; // decl: <none>; prim: <none>
    logic [31:0] limb_140_888; // decl: <none>; prim: <none>
    logic [32:0] limb_140_889; // decl: <none>; prim: <none>
    logic [31:0] limb_140_890; // decl: <none>; prim: <none>
    logic limb_140_891; // decl: <none>; prim: <none>
    logic [31:0] limb_140_892; // decl: <none>; prim: <none>
    logic [31:0] limb_140_893; // decl: <none>; prim: <none>
    logic [31:0] limb_140_894; // decl: <none>; prim: <none>
    logic [32:0] limb_140_895; // decl: <none>; prim: <none>
    logic [31:0] limb_140_896; // decl: <none>; prim: <none>
    logic limb_140_897; // decl: <none>; prim: <none>
    logic [3:0] limb_140_898; // decl: <none>; prim: <none>
    logic [3:0] limb_140_899; // decl: <none>; prim: <none>
    logic [3:0] limb_140_900; // decl: <none>; prim: <none>
    logic [4:0] limb_140_901; // decl: <none>; prim: <none>
    logic [3:0] limb_140_902; // decl: <none>; prim: <none>
    logic [131:0] limb_140_903; // decl: <none>; prim: <none>
    logic [31:0] limb_147_904; // decl: <none>; prim: <none>
    logic [31:0] limb_147_905; // decl: <none>; prim: <none>
    logic [31:0] limb_147_906; // decl: <none>; prim: <none>
    logic [32:0] limb_147_907; // decl: <none>; prim: <none>
    logic [31:0] limb_147_908; // decl: <none>; prim: <none>
    logic limb_147_909; // decl: <none>; prim: <none>
    logic [31:0] limb_147_910; // decl: <none>; prim: <none>
    logic [31:0] limb_147_911; // decl: <none>; prim: <none>
    logic [31:0] limb_147_912; // decl: <none>; prim: <none>
    logic [32:0] limb_147_913; // decl: <none>; prim: <none>
    logic [31:0] limb_147_914; // decl: <none>; prim: <none>
    logic limb_147_915; // decl: <none>; prim: <none>
    logic [31:0] limb_147_916; // decl: <none>; prim: <none>
    logic [31:0] limb_147_917; // decl: <none>; prim: <none>
    logic [31:0] limb_147_918; // decl: <none>; prim: <none>
    logic [32:0] limb_147_919; // decl: <none>; prim: <none>
    logic [31:0] limb_147_920; // decl: <none>; prim: <none>
    logic limb_147_921; // decl: <none>; prim: <none>
    logic [31:0] limb_147_922; // decl: <none>; prim: <none>
    logic [31:0] limb_147_923; // decl: <none>; prim: <none>
    logic [31:0] limb_147_924; // decl: <none>; prim: <none>
    logic [32:0] limb_147_925; // decl: <none>; prim: <none>
    logic [31:0] limb_147_926; // decl: <none>; prim: <none>
    logic limb_147_927; // decl: <none>; prim: <none>
    logic [31:0] limb_147_928; // decl: <none>; prim: <none>
    logic [31:0] limb_147_929; // decl: <none>; prim: <none>
    logic [31:0] limb_147_930; // decl: <none>; prim: <none>
    logic [32:0] limb_147_931; // decl: <none>; prim: <none>
    logic [31:0] limb_147_932; // decl: <none>; prim: <none>
    logic limb_147_933; // decl: <none>; prim: <none>
    logic [31:0] limb_147_934; // decl: <none>; prim: <none>
    logic [31:0] limb_147_935; // decl: <none>; prim: <none>
    logic [31:0] limb_147_936; // decl: <none>; prim: <none>
    logic [32:0] limb_147_937; // decl: <none>; prim: <none>
    logic [31:0] limb_147_938; // decl: <none>; prim: <none>
    logic limb_147_939; // decl: <none>; prim: <none>
    logic [31:0] limb_147_940; // decl: <none>; prim: <none>
    logic [31:0] limb_147_941; // decl: <none>; prim: <none>
    logic [31:0] limb_147_942; // decl: <none>; prim: <none>
    logic [32:0] limb_147_943; // decl: <none>; prim: <none>
    logic [31:0] limb_147_944; // decl: <none>; prim: <none>
    logic limb_147_945; // decl: <none>; prim: <none>
    logic [31:0] limb_147_946; // decl: <none>; prim: <none>
    logic [31:0] limb_147_947; // decl: <none>; prim: <none>
    logic [31:0] limb_147_948; // decl: <none>; prim: <none>
    logic [32:0] limb_147_949; // decl: <none>; prim: <none>
    logic [31:0] limb_147_950; // decl: <none>; prim: <none>
    logic limb_147_951; // decl: <none>; prim: <none>
    logic [1:0] limb_147_952; // decl: <none>; prim: <none>
    logic [1:0] limb_147_953; // decl: <none>; prim: <none>
    logic [1:0] limb_147_954; // decl: <none>; prim: <none>
    logic [2:0] limb_147_955; // decl: <none>; prim: <none>
    logic [1:0] limb_147_956; // decl: <none>; prim: <none>
    logic [257:0] limb_147_957; // decl: <none>; prim: <none>
    logic [31:0] limb_149_958; // decl: <none>; prim: <none>
    logic [31:0] limb_149_959; // decl: <none>; prim: <none>
    logic [31:0] limb_149_960; // decl: <none>; prim: <none>
    logic [32:0] limb_149_961; // decl: <none>; prim: <none>
    logic [31:0] limb_149_962; // decl: <none>; prim: <none>
    logic limb_149_963; // decl: <none>; prim: <none>
    logic [31:0] limb_149_964; // decl: <none>; prim: <none>
    logic [31:0] limb_149_965; // decl: <none>; prim: <none>
    logic [31:0] limb_149_966; // decl: <none>; prim: <none>
    logic [32:0] limb_149_967; // decl: <none>; prim: <none>
    logic [31:0] limb_149_968; // decl: <none>; prim: <none>
    logic limb_149_969; // decl: <none>; prim: <none>
    logic [31:0] limb_149_970; // decl: <none>; prim: <none>
    logic [31:0] limb_149_971; // decl: <none>; prim: <none>
    logic [31:0] limb_149_972; // decl: <none>; prim: <none>
    logic [32:0] limb_149_973; // decl: <none>; prim: <none>
    logic [31:0] limb_149_974; // decl: <none>; prim: <none>
    logic limb_149_975; // decl: <none>; prim: <none>
    logic [31:0] limb_149_976; // decl: <none>; prim: <none>
    logic [31:0] limb_149_977; // decl: <none>; prim: <none>
    logic [31:0] limb_149_978; // decl: <none>; prim: <none>
    logic [32:0] limb_149_979; // decl: <none>; prim: <none>
    logic [31:0] limb_149_980; // decl: <none>; prim: <none>
    logic limb_149_981; // decl: <none>; prim: <none>
    logic [31:0] limb_149_982; // decl: <none>; prim: <none>
    logic [31:0] limb_149_983; // decl: <none>; prim: <none>
    logic [31:0] limb_149_984; // decl: <none>; prim: <none>
    logic [32:0] limb_149_985; // decl: <none>; prim: <none>
    logic [31:0] limb_149_986; // decl: <none>; prim: <none>
    logic limb_149_987; // decl: <none>; prim: <none>
    logic [31:0] limb_149_988; // decl: <none>; prim: <none>
    logic [31:0] limb_149_989; // decl: <none>; prim: <none>
    logic [31:0] limb_149_990; // decl: <none>; prim: <none>
    logic [32:0] limb_149_991; // decl: <none>; prim: <none>
    logic [31:0] limb_149_992; // decl: <none>; prim: <none>
    logic limb_149_993; // decl: <none>; prim: <none>
    logic [31:0] limb_149_994; // decl: <none>; prim: <none>
    logic [31:0] limb_149_995; // decl: <none>; prim: <none>
    logic [31:0] limb_149_996; // decl: <none>; prim: <none>
    logic [32:0] limb_149_997; // decl: <none>; prim: <none>
    logic [31:0] limb_149_998; // decl: <none>; prim: <none>
    logic limb_149_999; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1000; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1001; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1002; // decl: <none>; prim: <none>
    logic [32:0] limb_149_1003; // decl: <none>; prim: <none>
    logic [31:0] limb_149_1004; // decl: <none>; prim: <none>
    logic limb_149_1005; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1006; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1007; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1008; // decl: <none>; prim: <none>
    logic [2:0] limb_149_1009; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1010; // decl: <none>; prim: <none>
    logic [257:0] limb_149_1011; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1012; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1013; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1014; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1015; // decl: <none>; prim: <none>
    logic limb_157_1016; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1017; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1018; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1019; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1020; // decl: <none>; prim: <none>
    logic limb_157_1021; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1022; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1023; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1024; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1025; // decl: <none>; prim: <none>
    logic limb_157_1026; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1027; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1028; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1029; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1030; // decl: <none>; prim: <none>
    logic limb_157_1031; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1032; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1033; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1034; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1035; // decl: <none>; prim: <none>
    logic limb_157_1036; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1037; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1038; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1039; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1040; // decl: <none>; prim: <none>
    logic limb_157_1041; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1042; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1043; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1044; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1045; // decl: <none>; prim: <none>
    logic limb_157_1046; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1047; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1048; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1049; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1050; // decl: <none>; prim: <none>
    logic limb_157_1051; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1052; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1053; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1054; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1055; // decl: <none>; prim: <none>
    logic limb_157_1056; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1057; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1058; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1059; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1060; // decl: <none>; prim: <none>
    logic limb_157_1061; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1062; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1063; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1064; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1065; // decl: <none>; prim: <none>
    logic limb_157_1066; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1067; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1068; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1069; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1070; // decl: <none>; prim: <none>
    logic limb_157_1071; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1072; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1073; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1074; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1075; // decl: <none>; prim: <none>
    logic limb_157_1076; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1077; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1078; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1079; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1080; // decl: <none>; prim: <none>
    logic limb_157_1081; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1082; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1083; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1084; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1085; // decl: <none>; prim: <none>
    logic limb_157_1086; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1087; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1088; // decl: <none>; prim: <none>
    logic [32:0] limb_157_1089; // decl: <none>; prim: <none>
    logic [31:0] limb_157_1090; // decl: <none>; prim: <none>
    logic limb_157_1091; // decl: <none>; prim: <none>
    logic limb_157_1092; // decl: <none>; prim: <none>
    logic limb_157_1093; // decl: <none>; prim: <none>
    logic [1:0] limb_157_1094; // decl: <none>; prim: <none>
    logic limb_157_1095; // decl: <none>; prim: <none>
    logic [512:0] limb_157_1096; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1097; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1098; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1099; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1100; // decl: <none>; prim: <none>
    logic limb_216_1101; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1102; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1103; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1104; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1105; // decl: <none>; prim: <none>
    logic limb_216_1106; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1107; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1108; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1109; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1110; // decl: <none>; prim: <none>
    logic limb_216_1111; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1112; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1113; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1114; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1115; // decl: <none>; prim: <none>
    logic limb_216_1116; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1117; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1118; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1119; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1120; // decl: <none>; prim: <none>
    logic limb_216_1121; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1122; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1123; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1124; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1125; // decl: <none>; prim: <none>
    logic limb_216_1126; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1127; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1128; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1129; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1130; // decl: <none>; prim: <none>
    logic limb_216_1131; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1132; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1133; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1134; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1135; // decl: <none>; prim: <none>
    logic limb_216_1136; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1137; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1138; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1139; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1140; // decl: <none>; prim: <none>
    logic limb_216_1141; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1142; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1143; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1144; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1145; // decl: <none>; prim: <none>
    logic limb_216_1146; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1147; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1148; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1149; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1150; // decl: <none>; prim: <none>
    logic limb_216_1151; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1152; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1153; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1154; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1155; // decl: <none>; prim: <none>
    logic limb_216_1156; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1157; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1158; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1159; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1160; // decl: <none>; prim: <none>
    logic limb_216_1161; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1162; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1163; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1164; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1165; // decl: <none>; prim: <none>
    logic limb_216_1166; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1167; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1168; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1169; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1170; // decl: <none>; prim: <none>
    logic limb_216_1171; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1172; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1173; // decl: <none>; prim: <none>
    logic [32:0] limb_216_1174; // decl: <none>; prim: <none>
    logic [31:0] limb_216_1175; // decl: <none>; prim: <none>
    logic [511:0] limb_216_1176; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1177; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1178; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1179; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1180; // decl: <none>; prim: <none>
    logic limb_217_1181; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1182; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1183; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1184; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1185; // decl: <none>; prim: <none>
    logic limb_217_1186; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1187; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1188; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1189; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1190; // decl: <none>; prim: <none>
    logic limb_217_1191; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1192; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1193; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1194; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1195; // decl: <none>; prim: <none>
    logic limb_217_1196; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1197; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1198; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1199; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1200; // decl: <none>; prim: <none>
    logic limb_217_1201; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1202; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1203; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1204; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1205; // decl: <none>; prim: <none>
    logic limb_217_1206; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1207; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1208; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1209; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1210; // decl: <none>; prim: <none>
    logic limb_217_1211; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1212; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1213; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1214; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1215; // decl: <none>; prim: <none>
    logic limb_217_1216; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1217; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1218; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1219; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1220; // decl: <none>; prim: <none>
    logic limb_217_1221; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1222; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1223; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1224; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1225; // decl: <none>; prim: <none>
    logic limb_217_1226; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1227; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1228; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1229; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1230; // decl: <none>; prim: <none>
    logic limb_217_1231; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1232; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1233; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1234; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1235; // decl: <none>; prim: <none>
    logic limb_217_1236; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1237; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1238; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1239; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1240; // decl: <none>; prim: <none>
    logic limb_217_1241; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1242; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1243; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1244; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1245; // decl: <none>; prim: <none>
    logic limb_217_1246; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1247; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1248; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1249; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1250; // decl: <none>; prim: <none>
    logic limb_217_1251; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1252; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1253; // decl: <none>; prim: <none>
    logic [32:0] limb_217_1254; // decl: <none>; prim: <none>
    logic [31:0] limb_217_1255; // decl: <none>; prim: <none>
    logic [511:0] limb_217_1256; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1257; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1258; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1259; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1260; // decl: <none>; prim: <none>
    logic limb_218_1261; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1262; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1263; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1264; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1265; // decl: <none>; prim: <none>
    logic limb_218_1266; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1267; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1268; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1269; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1270; // decl: <none>; prim: <none>
    logic limb_218_1271; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1272; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1273; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1274; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1275; // decl: <none>; prim: <none>
    logic limb_218_1276; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1277; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1278; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1279; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1280; // decl: <none>; prim: <none>
    logic limb_218_1281; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1282; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1283; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1284; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1285; // decl: <none>; prim: <none>
    logic limb_218_1286; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1287; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1288; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1289; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1290; // decl: <none>; prim: <none>
    logic limb_218_1291; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1292; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1293; // decl: <none>; prim: <none>
    logic [32:0] limb_218_1294; // decl: <none>; prim: <none>
    logic [31:0] limb_218_1295; // decl: <none>; prim: <none>
    logic limb_218_1296; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1297; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1298; // decl: <none>; prim: <none>
    logic [2:0] limb_218_1299; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1300; // decl: <none>; prim: <none>
    logic [257:0] limb_218_1301; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1302; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1303; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1304; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1305; // decl: <none>; prim: <none>
    logic limb_219_1306; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1307; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1308; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1309; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1310; // decl: <none>; prim: <none>
    logic limb_219_1311; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1312; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1313; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1314; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1315; // decl: <none>; prim: <none>
    logic limb_219_1316; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1317; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1318; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1319; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1320; // decl: <none>; prim: <none>
    logic limb_219_1321; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1322; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1323; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1324; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1325; // decl: <none>; prim: <none>
    logic limb_219_1326; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1327; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1328; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1329; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1330; // decl: <none>; prim: <none>
    logic limb_219_1331; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1332; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1333; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1334; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1335; // decl: <none>; prim: <none>
    logic limb_219_1336; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1337; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1338; // decl: <none>; prim: <none>
    logic [32:0] limb_219_1339; // decl: <none>; prim: <none>
    logic [31:0] limb_219_1340; // decl: <none>; prim: <none>
    logic limb_219_1341; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1342; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1343; // decl: <none>; prim: <none>
    logic [2:0] limb_219_1344; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1345; // decl: <none>; prim: <none>
    logic [257:0] limb_219_1346; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1347; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1348; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1349; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1350; // decl: <none>; prim: <none>
    logic limb_220_1351; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1352; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1353; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1354; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1355; // decl: <none>; prim: <none>
    logic limb_220_1356; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1357; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1358; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1359; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1360; // decl: <none>; prim: <none>
    logic limb_220_1361; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1362; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1363; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1364; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1365; // decl: <none>; prim: <none>
    logic limb_220_1366; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1367; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1368; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1369; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1370; // decl: <none>; prim: <none>
    logic limb_220_1371; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1372; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1373; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1374; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1375; // decl: <none>; prim: <none>
    logic limb_220_1376; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1377; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1378; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1379; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1380; // decl: <none>; prim: <none>
    logic limb_220_1381; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1382; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1383; // decl: <none>; prim: <none>
    logic [32:0] limb_220_1384; // decl: <none>; prim: <none>
    logic [31:0] limb_220_1385; // decl: <none>; prim: <none>
    logic [255:0] limb_220_1386; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1387; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1388; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1389; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1390; // decl: <none>; prim: <none>
    logic limb_221_1391; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1392; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1393; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1394; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1395; // decl: <none>; prim: <none>
    logic limb_221_1396; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1397; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1398; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1399; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1400; // decl: <none>; prim: <none>
    logic limb_221_1401; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1402; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1403; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1404; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1405; // decl: <none>; prim: <none>
    logic limb_221_1406; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1407; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1408; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1409; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1410; // decl: <none>; prim: <none>
    logic limb_221_1411; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1412; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1413; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1414; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1415; // decl: <none>; prim: <none>
    logic limb_221_1416; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1417; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1418; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1419; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1420; // decl: <none>; prim: <none>
    logic limb_221_1421; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1422; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1423; // decl: <none>; prim: <none>
    logic [32:0] limb_221_1424; // decl: <none>; prim: <none>
    logic [31:0] limb_221_1425; // decl: <none>; prim: <none>
    logic [255:0] limb_221_1426; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1427; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1428; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1429; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1430; // decl: <none>; prim: <none>
    logic limb_222_1431; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1432; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1433; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1434; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1435; // decl: <none>; prim: <none>
    logic limb_222_1436; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1437; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1438; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1439; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1440; // decl: <none>; prim: <none>
    logic limb_222_1441; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1442; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1443; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1444; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1445; // decl: <none>; prim: <none>
    logic limb_222_1446; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1447; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1448; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1449; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1450; // decl: <none>; prim: <none>
    logic limb_222_1451; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1452; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1453; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1454; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1455; // decl: <none>; prim: <none>
    logic limb_222_1456; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1457; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1458; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1459; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1460; // decl: <none>; prim: <none>
    logic limb_222_1461; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1462; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1463; // decl: <none>; prim: <none>
    logic [32:0] limb_222_1464; // decl: <none>; prim: <none>
    logic [31:0] limb_222_1465; // decl: <none>; prim: <none>
    logic [255:0] limb_222_1466; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1467; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1468; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1469; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1470; // decl: <none>; prim: <none>
    logic limb_223_1471; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1472; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1473; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1474; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1475; // decl: <none>; prim: <none>
    logic limb_223_1476; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1477; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1478; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1479; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1480; // decl: <none>; prim: <none>
    logic limb_223_1481; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1482; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1483; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1484; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1485; // decl: <none>; prim: <none>
    logic limb_223_1486; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1487; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1488; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1489; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1490; // decl: <none>; prim: <none>
    logic limb_223_1491; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1492; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1493; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1494; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1495; // decl: <none>; prim: <none>
    logic limb_223_1496; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1497; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1498; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1499; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1500; // decl: <none>; prim: <none>
    logic limb_223_1501; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1502; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1503; // decl: <none>; prim: <none>
    logic [32:0] limb_223_1504; // decl: <none>; prim: <none>
    logic [31:0] limb_223_1505; // decl: <none>; prim: <none>
    logic [255:0] limb_223_1506; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1507; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1508; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1509; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1510; // decl: <none>; prim: <none>
    logic limb_224_1511; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1512; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1513; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1514; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1515; // decl: <none>; prim: <none>
    logic limb_224_1516; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1517; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1518; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1519; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1520; // decl: <none>; prim: <none>
    logic limb_224_1521; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1522; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1523; // decl: <none>; prim: <none>
    logic [32:0] limb_224_1524; // decl: <none>; prim: <none>
    logic [31:0] limb_224_1525; // decl: <none>; prim: <none>
    logic limb_224_1526; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1527; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1528; // decl: <none>; prim: <none>
    logic [4:0] limb_224_1529; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1530; // decl: <none>; prim: <none>
    logic [131:0] limb_224_1531; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1532; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1533; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1534; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1535; // decl: <none>; prim: <none>
    logic limb_225_1536; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1537; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1538; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1539; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1540; // decl: <none>; prim: <none>
    logic limb_225_1541; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1542; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1543; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1544; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1545; // decl: <none>; prim: <none>
    logic limb_225_1546; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1547; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1548; // decl: <none>; prim: <none>
    logic [32:0] limb_225_1549; // decl: <none>; prim: <none>
    logic [31:0] limb_225_1550; // decl: <none>; prim: <none>
    logic limb_225_1551; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1552; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1553; // decl: <none>; prim: <none>
    logic [4:0] limb_225_1554; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1555; // decl: <none>; prim: <none>
    logic [131:0] limb_225_1556; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1557; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1558; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1559; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1560; // decl: <none>; prim: <none>
    logic limb_226_1561; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1562; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1563; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1564; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1565; // decl: <none>; prim: <none>
    logic limb_226_1566; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1567; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1568; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1569; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1570; // decl: <none>; prim: <none>
    logic limb_226_1571; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1572; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1573; // decl: <none>; prim: <none>
    logic [32:0] limb_226_1574; // decl: <none>; prim: <none>
    logic [31:0] limb_226_1575; // decl: <none>; prim: <none>
    logic limb_226_1576; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1577; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1578; // decl: <none>; prim: <none>
    logic [2:0] limb_226_1579; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1580; // decl: <none>; prim: <none>
    logic [129:0] limb_226_1581; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1582; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1583; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1584; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1585; // decl: <none>; prim: <none>
    logic limb_227_1586; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1587; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1588; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1589; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1590; // decl: <none>; prim: <none>
    logic limb_227_1591; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1592; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1593; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1594; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1595; // decl: <none>; prim: <none>
    logic limb_227_1596; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1597; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1598; // decl: <none>; prim: <none>
    logic [32:0] limb_227_1599; // decl: <none>; prim: <none>
    logic [31:0] limb_227_1600; // decl: <none>; prim: <none>
    logic limb_227_1601; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1602; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1603; // decl: <none>; prim: <none>
    logic [2:0] limb_227_1604; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1605; // decl: <none>; prim: <none>
    logic [129:0] limb_227_1606; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1607; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1608; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1609; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1610; // decl: <none>; prim: <none>
    logic limb_228_1611; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1612; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1613; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1614; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1615; // decl: <none>; prim: <none>
    logic limb_228_1616; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1617; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1618; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1619; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1620; // decl: <none>; prim: <none>
    logic limb_228_1621; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1622; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1623; // decl: <none>; prim: <none>
    logic [32:0] limb_228_1624; // decl: <none>; prim: <none>
    logic [31:0] limb_228_1625; // decl: <none>; prim: <none>
    logic limb_228_1626; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1627; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1628; // decl: <none>; prim: <none>
    logic [2:0] limb_228_1629; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1630; // decl: <none>; prim: <none>
    logic [129:0] limb_228_1631; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1632; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1633; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1634; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1635; // decl: <none>; prim: <none>
    logic limb_229_1636; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1637; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1638; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1639; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1640; // decl: <none>; prim: <none>
    logic limb_229_1641; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1642; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1643; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1644; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1645; // decl: <none>; prim: <none>
    logic limb_229_1646; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1647; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1648; // decl: <none>; prim: <none>
    logic [32:0] limb_229_1649; // decl: <none>; prim: <none>
    logic [31:0] limb_229_1650; // decl: <none>; prim: <none>
    logic limb_229_1651; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1652; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1653; // decl: <none>; prim: <none>
    logic [2:0] limb_229_1654; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1655; // decl: <none>; prim: <none>
    logic [129:0] limb_229_1656; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1657; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1658; // decl: <none>; prim: <none>
    logic [32:0] limb_230_1659; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1660; // decl: <none>; prim: <none>
    logic limb_230_1661; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1662; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1663; // decl: <none>; prim: <none>
    logic [32:0] limb_230_1664; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1665; // decl: <none>; prim: <none>
    logic limb_230_1666; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1667; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1668; // decl: <none>; prim: <none>
    logic [32:0] limb_230_1669; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1670; // decl: <none>; prim: <none>
    logic limb_230_1671; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1672; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1673; // decl: <none>; prim: <none>
    logic [32:0] limb_230_1674; // decl: <none>; prim: <none>
    logic [31:0] limb_230_1675; // decl: <none>; prim: <none>
    logic limb_230_1676; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1677; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1678; // decl: <none>; prim: <none>
    logic [2:0] limb_230_1679; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1680; // decl: <none>; prim: <none>
    logic [129:0] limb_230_1681; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1682; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1683; // decl: <none>; prim: <none>
    logic [32:0] limb_231_1684; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1685; // decl: <none>; prim: <none>
    logic limb_231_1686; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1687; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1688; // decl: <none>; prim: <none>
    logic [32:0] limb_231_1689; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1690; // decl: <none>; prim: <none>
    logic limb_231_1691; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1692; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1693; // decl: <none>; prim: <none>
    logic [32:0] limb_231_1694; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1695; // decl: <none>; prim: <none>
    logic limb_231_1696; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1697; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1698; // decl: <none>; prim: <none>
    logic [32:0] limb_231_1699; // decl: <none>; prim: <none>
    logic [31:0] limb_231_1700; // decl: <none>; prim: <none>
    logic limb_231_1701; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1702; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1703; // decl: <none>; prim: <none>
    logic [2:0] limb_231_1704; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1705; // decl: <none>; prim: <none>
    logic [129:0] limb_231_1706; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_296_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_296_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_308_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s7; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_174_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_174_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_174_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] rtlzz_pipe_44_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [31:0] rtlzz_pipe_360_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_360_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_365_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_365_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_370_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_370_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_301_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_375_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_378_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_380_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_383_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_384_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_385_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_385_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_386_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_269_s7; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_170_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_390_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_395_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_304_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_430_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_436_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_442_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_448_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_454_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_460_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_466_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_471_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_478_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_478_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_484_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_484_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_490_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_490_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_496_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_496_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_502_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_502_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_507_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_512_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_517_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_313_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_522_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_527_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_532_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_319_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_594_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_600_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_606_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_612_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_618_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_652_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_652_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_655_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_657_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_660_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_662_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_665_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_666_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_667_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_668_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_672_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_672_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_672_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_673_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_284_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_677_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_677_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_682_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_682_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_682_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_687_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_687_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_687_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_692_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_692_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_692_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_697_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_697_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_697_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_283_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_287_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_202_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_724_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_730_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_736_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_773_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_778_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_783_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s6; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_211_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_828_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_834_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_840_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_876_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_876_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_882_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_882_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_888_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_888_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_894_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_894_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_900_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_900_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1013_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1018_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1023_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1028_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1033_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1038_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1043_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1048_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1053_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1058_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1063_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1068_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1073_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1078_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1083_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1088_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1093_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1257_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1262_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1267_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1272_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1277_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1282_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1287_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1292_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1297_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1347_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1352_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1357_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1362_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1367_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1372_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1377_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1382_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1508_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1513_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1518_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1523_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1528_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_846_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_852_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_858_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_864_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_870_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1302_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1305_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1307_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1310_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1312_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1315_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1317_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1320_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1322_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1325_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1327_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1330_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1332_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1335_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1336_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1337_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1337_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_1338_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1342_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1342_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1343_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = limb_13_374; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = limb_15_389; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__32_v0 = (__beopt_width_545 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (__beopt_width_546 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign s8_norm_add_36_v0 = limb_21_399; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_add_39_v0 = limb_23_409; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (rtlzz_pipe_170_s7 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = limb_29_427; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = limb_31_445; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (rtlzz_pipe_173_s7 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (rtlzz_pipe_174_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = limb_38_475; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__76_v0 = (__beopt_width_562 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = limb_40_505; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (s8_norm_mul_14_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_44_s7 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = limb_51_520; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = limb_53_535; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__117_v0 = (__beopt_width_573 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (__beopt_width_579 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign s8_norm_add_98_v0 = limb_59_545; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_add_101_v0 = limb_61_555; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = limb_67_573; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = limb_69_591; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = limb_76_621; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = limb_78_651; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__164_v0 = (s8_norm_mul_72_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = limb_85_676; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = limb_87_701; // decl: <none>; prim: <none>
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (tmp_workload_top_int_66__243_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (__beopt_width_603 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign s8_norm_add_152_v0 = limb_95_711; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_add_155_v0 = limb_97_721; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (__beopt_width_609 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = limb_103_739; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = limb_105_757; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__223_v0 = (rtlzz_pipe_202_s5 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (__beopt_width_612 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (__beopt_width_617 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = limb_113_772; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = limb_115_787; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__252_v0 = (s8_norm_add_177_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s6 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (__beopt_width_627 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign s8_norm_add_195_v0 = limb_121_797; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_add_198_v0 = limb_123_807; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = limb_129_825; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = limb_131_843; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = limb_138_873; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = limb_140_903; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__305_v0 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = limb_147_957; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = limb_149_1011; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = limb_157_1096; // decl: <none>; prim: <none>
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = limb_216_1176; // decl: <none>; prim: <none>
    assign __beopt_width_294 = limb_217_1256; // decl: <none>; prim: <none>
    assign __beopt_width_295 = limb_218_1301; // decl: <none>; prim: <none>
    assign __beopt_width_297 = limb_219_1346; // decl: <none>; prim: <none>
    assign __beopt_width_299 = limb_220_1386; // decl: <none>; prim: <none>
    assign __beopt_width_301 = limb_221_1426; // decl: <none>; prim: <none>
    assign __beopt_width_302 = limb_222_1466; // decl: <none>; prim: <none>
    assign __beopt_width_303 = limb_223_1506; // decl: <none>; prim: <none>
    assign __beopt_width_305 = limb_224_1531; // decl: <none>; prim: <none>
    assign __beopt_width_307 = limb_225_1556; // decl: <none>; prim: <none>
    assign __beopt_width_309 = limb_226_1581; // decl: <none>; prim: <none>
    assign __beopt_width_310 = limb_227_1606; // decl: <none>; prim: <none>
    assign __beopt_width_311 = limb_228_1631; // decl: <none>; prim: <none>
    assign __beopt_width_313 = limb_229_1656; // decl: <none>; prim: <none>
    assign __beopt_width_315 = limb_230_1681; // decl: <none>; prim: <none>
    assign __beopt_width_317 = limb_231_1706; // decl: <none>; prim: <none>
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (rtlzz_pipe_265_s5 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (rtlzz_pipe_268_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (rtlzz_pipe_269_s7 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s6 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s7 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (__beopt_width_353 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s1 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (__beopt_width_362 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (rtlzz_pipe_278_s2 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (rtlzz_pipe_279_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (__beopt_width_396 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (rtlzz_pipe_283_s5 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s4 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (__beopt_width_406 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (__beopt_width_410 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (rtlzz_pipe_287_s5 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (__beopt_width_417 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (__beopt_width_420 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (__beopt_width_423 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s6 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_343Core rtlzz_owner_343(.a(64'(rtlzz_pipe_292_s3)), .b(64'(rtlzz_pipe_293_s3)), .cin(1'b0), .value(arith_original_343));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_344Core rtlzz_owner_344(.a(64'(rtlzz_pipe_295_s5)), .b(64'(rtlzz_pipe_296_s5)), .cin(1'b0), .value(arith_original_344));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_345Core rtlzz_owner_345(.a(33'(rtlzz_pipe_298_s6)), .b(33'(mul_precision_299)), .cin(1'b0), .value(arith_original_345));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_346Core rtlzz_owner_346(.a(32'(rtlzz_pipe_301_s6)), .b(32'(mul_precision_302)), .cin(1'b0), .value(arith_original_346));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_347Core rtlzz_owner_347(.a(34'(rtlzz_pipe_304_s7)), .b(34'(mul_precision_305)), .cin(1'b0), .value(arith_original_347));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_348Core rtlzz_owner_348(.a(64'(rtlzz_pipe_307_s6)), .b(64'(rtlzz_pipe_308_s6)), .cin(1'b0), .value(arith_original_348));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_349Core rtlzz_owner_349(.a(64'(rtlzz_pipe_310_s7)), .b(64'(mul_precision_311)), .cin(1'b0), .value(arith_original_349));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_350Core rtlzz_owner_350(.a(33'(rtlzz_pipe_313_s7)), .b(33'(mul_precision_314)), .cin(1'b0), .value(arith_original_350));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_351Core rtlzz_owner_351(.a(32'(rtlzz_pipe_316_s7)), .b(32'(mul_precision_317)), .cin(1'b0), .value(arith_original_351));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_352Core rtlzz_owner_352(.a(34'(rtlzz_pipe_319_s7)), .b(34'(mul_precision_320)), .cin(1'b0), .value(arith_original_352));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_353Core rtlzz_owner_353(.a(33'(rtlzz_pipe_322_s4)), .b(33'(mul_precision_323)), .cin(1'b0), .value(arith_original_353));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(32'(rtlzz_pipe_325_s5)), .b(32'(mul_precision_326)), .cin(1'b0), .value(arith_original_354));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_355Core rtlzz_owner_355(.a(34'(rtlzz_pipe_328_s5)), .b(34'(mul_precision_329)), .cin(1'b0), .value(arith_original_355));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_356Core rtlzz_owner_356(.a(64'(mul_precision_331)), .b(64'(mul_precision_332)), .cin(1'b0), .value(arith_original_356));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_357Core rtlzz_owner_357(.a(33'(rtlzz_pipe_334_s6)), .b(33'(mul_precision_335)), .cin(1'b0), .value(arith_original_357));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_358Core rtlzz_owner_358(.a(33'(rtlzz_pipe_337_s5)), .b(33'(mul_precision_338)), .cin(1'b0), .value(arith_original_358));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(34'(rtlzz_pipe_340_s6)), .b(34'(mul_precision_341)), .cin(1'b0), .value(arith_original_359));
    assign limb_13_360 = tmp_workload_top_int_65__18_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_13_361 = __beopt_width_312[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_362Core rtlzz_owner_362(.a(32'(rtlzz_pipe_360_s4)), .b(32'(limb_13_361)), .cin(1'h0), .value(limb_13_362));
    assign limb_13_363 = limb_13_362[31:0]; // decl: <none>; prim: <none>
    assign limb_13_364 = limb_13_362[32]; // decl: <none>; prim: <none>
    assign limb_13_365 = tmp_workload_top_int_65__18_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_13_366 = __beopt_width_312[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_367Core rtlzz_owner_367(.a(32'(rtlzz_pipe_365_s4)), .b(32'(limb_13_366)), .cin(limb_13_364), .value(limb_13_367));
    assign limb_13_368 = limb_13_367[31:0]; // decl: <none>; prim: <none>
    assign limb_13_369 = limb_13_367[32]; // decl: <none>; prim: <none>
    assign limb_13_370 = tmp_workload_top_int_65__18_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_371 = __beopt_width_312[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_372Core rtlzz_owner_372(.a(1'(rtlzz_pipe_370_s4)), .b(1'(limb_13_371)), .cin(limb_13_369), .value(limb_13_372[0:0]));
    assign limb_13_372[1:1] = '0;
    assign limb_13_373 = limb_13_372[0]; // decl: <none>; prim: <none>
    assign limb_13_374 = {limb_13_373, limb_13_368, limb_13_363}; // decl: <none>; prim: <none>
    assign limb_15_375 = tmp_workload_top_int_65__23_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_15_376 = __beopt_width_318[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_377Core rtlzz_owner_377(.a(32'(rtlzz_pipe_375_s5)), .b(32'(limb_15_376)), .cin(1'h0), .value(limb_15_377));
    assign limb_15_378 = limb_15_377[31:0]; // decl: <none>; prim: <none>
    assign limb_15_379 = limb_15_377[32]; // decl: <none>; prim: <none>
    assign limb_15_380 = tmp_workload_top_int_65__23_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_15_381 = __beopt_width_318[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_382Core rtlzz_owner_382(.a(32'(rtlzz_pipe_380_s5)), .b(32'(limb_15_381)), .cin(limb_15_379), .value(limb_15_382));
    assign limb_15_383 = limb_15_382[31:0]; // decl: <none>; prim: <none>
    assign limb_15_384 = limb_15_382[32]; // decl: <none>; prim: <none>
    assign limb_15_385 = tmp_workload_top_int_65__23_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_386 = __beopt_width_318[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387Core rtlzz_owner_387(.a(1'(rtlzz_pipe_385_s6)), .b(1'(rtlzz_pipe_386_s6)), .cin(rtlzz_pipe_384_s6), .value(limb_15_387[0:0]));
    assign limb_15_387[1:1] = '0;
    assign limb_15_388 = limb_15_387[0]; // decl: <none>; prim: <none>
    assign limb_15_389 = {limb_15_388, rtlzz_pipe_383_s6, rtlzz_pipe_378_s6}; // decl: <none>; prim: <none>
    assign limb_21_390 = tmp_workload_top_int_34__42_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_21_391 = __beopt_width_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_392Core rtlzz_owner_392(.a(32'(rtlzz_pipe_390_s6)), .b(32'(limb_21_391)), .cin(1'h0), .value(limb_21_392));
    assign limb_21_393 = limb_21_392[31:0]; // decl: <none>; prim: <none>
    assign limb_21_394 = limb_21_392[32]; // decl: <none>; prim: <none>
    assign limb_21_395 = tmp_workload_top_int_34__42_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_21_396 = __beopt_width_332[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_397Core rtlzz_owner_397(.a(2'(rtlzz_pipe_395_s6)), .b(2'(limb_21_396)), .cin(limb_21_394), .value(limb_21_397[1:0]));
    assign limb_21_397[2:2] = '0;
    assign limb_21_398 = limb_21_397[1:0]; // decl: <none>; prim: <none>
    assign limb_21_399 = {limb_21_398, limb_21_393}; // decl: <none>; prim: <none>
    assign limb_23_400 = tmp_workload_top_int_34__47_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_23_401 = __beopt_width_336[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_402Core rtlzz_owner_402(.a(32'(limb_23_400)), .b(32'(limb_23_401)), .cin(1'h0), .value(limb_23_402));
    assign limb_23_403 = limb_23_402[31:0]; // decl: <none>; prim: <none>
    assign limb_23_404 = limb_23_402[32]; // decl: <none>; prim: <none>
    assign limb_23_405 = tmp_workload_top_int_34__47_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_23_406 = __beopt_width_336[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_407Core rtlzz_owner_407(.a(2'(limb_23_405)), .b(2'(limb_23_406)), .cin(limb_23_404), .value(limb_23_407[1:0]));
    assign limb_23_407[2:2] = '0;
    assign limb_23_408 = limb_23_407[1:0]; // decl: <none>; prim: <none>
    assign limb_23_409 = {limb_23_408, limb_23_403}; // decl: <none>; prim: <none>
    assign limb_29_410 = n20_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_29_411 = tmp_workload_top_int_68__57_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_29_412 = (~limb_29_411); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_413Core rtlzz_owner_413(.a(32'(limb_29_410)), .b(32'(limb_29_412)), .cin(1'h1), .value(limb_29_413));
    assign limb_29_414 = limb_29_413[31:0]; // decl: <none>; prim: <none>
    assign limb_29_415 = limb_29_413[32]; // decl: <none>; prim: <none>
    assign limb_29_416 = n20_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_29_417 = tmp_workload_top_int_68__57_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_29_418 = (~limb_29_417); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(32'(limb_29_416)), .b(32'(limb_29_418)), .cin(limb_29_415), .value(limb_29_419));
    assign limb_29_420 = limb_29_419[31:0]; // decl: <none>; prim: <none>
    assign limb_29_421 = limb_29_419[32]; // decl: <none>; prim: <none>
    assign limb_29_422 = n20_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_423 = tmp_workload_top_int_68__57_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_424 = (~limb_29_423); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_425Core rtlzz_owner_425(.a(4'(limb_29_422)), .b(4'(limb_29_424)), .cin(limb_29_421), .value(limb_29_425[3:0]));
    assign limb_29_425[4:4] = '0;
    assign limb_29_426 = limb_29_425[3:0]; // decl: <none>; prim: <none>
    assign limb_29_427 = {limb_29_426, limb_29_420, limb_29_414}; // decl: <none>; prim: <none>
    assign limb_31_428 = s8_norm_sub_45_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_31_429 = tmp_workload_top_int_68__60_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_31_430 = (~limb_31_429); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_431Core rtlzz_owner_431(.a(32'(limb_31_428)), .b(32'(rtlzz_pipe_430_s7)), .cin(1'h1), .value(limb_31_431));
    assign limb_31_432 = limb_31_431[31:0]; // decl: <none>; prim: <none>
    assign limb_31_433 = limb_31_431[32]; // decl: <none>; prim: <none>
    assign limb_31_434 = s8_norm_sub_45_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_31_435 = tmp_workload_top_int_68__60_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_31_436 = (~limb_31_435); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_437Core rtlzz_owner_437(.a(32'(limb_31_434)), .b(32'(rtlzz_pipe_436_s7)), .cin(limb_31_433), .value(limb_31_437));
    assign limb_31_438 = limb_31_437[31:0]; // decl: <none>; prim: <none>
    assign limb_31_439 = limb_31_437[32]; // decl: <none>; prim: <none>
    assign limb_31_440 = s8_norm_sub_45_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_441 = tmp_workload_top_int_68__60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_442 = (~limb_31_441); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_443Core rtlzz_owner_443(.a(4'(limb_31_440)), .b(4'(rtlzz_pipe_442_s7)), .cin(limb_31_439), .value(limb_31_443[3:0]));
    assign limb_31_443[4:4] = '0;
    assign limb_31_444 = limb_31_443[3:0]; // decl: <none>; prim: <none>
    assign limb_31_445 = {limb_31_444, limb_31_438, limb_31_432}; // decl: <none>; prim: <none>
    assign limb_38_446 = __beopt_width_317[31:0]; // decl: <none>; prim: <none>
    assign limb_38_447 = tmp_workload_top_int_130__73_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_38_448 = (~limb_38_447); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_449Core rtlzz_owner_449(.a(32'(limb_38_446)), .b(32'(rtlzz_pipe_448_s7)), .cin(1'h1), .value(limb_38_449));
    assign limb_38_450 = limb_38_449[31:0]; // decl: <none>; prim: <none>
    assign limb_38_451 = limb_38_449[32]; // decl: <none>; prim: <none>
    assign limb_38_452 = __beopt_width_317[63:32]; // decl: <none>; prim: <none>
    assign limb_38_453 = tmp_workload_top_int_130__73_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_38_454 = (~limb_38_453); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_455Core rtlzz_owner_455(.a(32'(limb_38_452)), .b(32'(rtlzz_pipe_454_s7)), .cin(limb_38_451), .value(limb_38_455));
    assign limb_38_456 = limb_38_455[31:0]; // decl: <none>; prim: <none>
    assign limb_38_457 = limb_38_455[32]; // decl: <none>; prim: <none>
    assign limb_38_458 = __beopt_width_317[95:64]; // decl: <none>; prim: <none>
    assign limb_38_459 = tmp_workload_top_int_130__73_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_38_460 = (~limb_38_459); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_461Core rtlzz_owner_461(.a(32'(limb_38_458)), .b(32'(rtlzz_pipe_460_s7)), .cin(limb_38_457), .value(limb_38_461));
    assign limb_38_462 = limb_38_461[31:0]; // decl: <none>; prim: <none>
    assign limb_38_463 = limb_38_461[32]; // decl: <none>; prim: <none>
    assign limb_38_464 = __beopt_width_317[127:96]; // decl: <none>; prim: <none>
    assign limb_38_465 = tmp_workload_top_int_130__73_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_38_466 = (~limb_38_465); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_467Core rtlzz_owner_467(.a(32'(limb_38_464)), .b(32'(rtlzz_pipe_466_s7)), .cin(limb_38_463), .value(limb_38_467));
    assign limb_38_468 = limb_38_467[31:0]; // decl: <none>; prim: <none>
    assign limb_38_469 = limb_38_467[32]; // decl: <none>; prim: <none>
    assign limb_38_470 = __beopt_width_317[129:128]; // decl: <none>; prim: <none>
    assign limb_38_471 = tmp_workload_top_int_130__73_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_38_472 = (~rtlzz_pipe_471_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_473Core rtlzz_owner_473(.a(2'(limb_38_470)), .b(2'(limb_38_472)), .cin(limb_38_469), .value(limb_38_473[1:0]));
    assign limb_38_473[2:2] = '0;
    assign limb_38_474 = limb_38_473[1:0]; // decl: <none>; prim: <none>
    assign limb_38_475 = {limb_38_474, limb_38_468, limb_38_462, limb_38_456, limb_38_450}; // decl: <none>; prim: <none>
    assign limb_40_476 = s8_norm_sub_56_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_40_477 = tmp_workload_top_int_130__76_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_40_478 = (~limb_40_477); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_479Core rtlzz_owner_479(.a(32'(limb_40_476)), .b(32'(rtlzz_pipe_478_s7)), .cin(1'h1), .value(limb_40_479));
    assign limb_40_480 = limb_40_479[31:0]; // decl: <none>; prim: <none>
    assign limb_40_481 = limb_40_479[32]; // decl: <none>; prim: <none>
    assign limb_40_482 = s8_norm_sub_56_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_40_483 = tmp_workload_top_int_130__76_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_40_484 = (~limb_40_483); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_485Core rtlzz_owner_485(.a(32'(limb_40_482)), .b(32'(rtlzz_pipe_484_s7)), .cin(limb_40_481), .value(limb_40_485));
    assign limb_40_486 = limb_40_485[31:0]; // decl: <none>; prim: <none>
    assign limb_40_487 = limb_40_485[32]; // decl: <none>; prim: <none>
    assign limb_40_488 = s8_norm_sub_56_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_40_489 = tmp_workload_top_int_130__76_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_40_490 = (~limb_40_489); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_491Core rtlzz_owner_491(.a(32'(limb_40_488)), .b(32'(rtlzz_pipe_490_s7)), .cin(limb_40_487), .value(limb_40_491));
    assign limb_40_492 = limb_40_491[31:0]; // decl: <none>; prim: <none>
    assign limb_40_493 = limb_40_491[32]; // decl: <none>; prim: <none>
    assign limb_40_494 = s8_norm_sub_56_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_40_495 = tmp_workload_top_int_130__76_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_40_496 = (~limb_40_495); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_497Core rtlzz_owner_497(.a(32'(limb_40_494)), .b(32'(rtlzz_pipe_496_s7)), .cin(limb_40_493), .value(limb_40_497));
    assign limb_40_498 = limb_40_497[31:0]; // decl: <none>; prim: <none>
    assign limb_40_499 = limb_40_497[32]; // decl: <none>; prim: <none>
    assign limb_40_500 = s8_norm_sub_56_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_501 = tmp_workload_top_int_130__76_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_502 = (~limb_40_501); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_503Core rtlzz_owner_503(.a(2'(limb_40_500)), .b(2'(rtlzz_pipe_502_s7)), .cin(limb_40_499), .value(limb_40_503[1:0]));
    assign limb_40_503[2:2] = '0;
    assign limb_40_504 = limb_40_503[1:0]; // decl: <none>; prim: <none>
    assign limb_40_505 = {limb_40_504, limb_40_498, limb_40_492, limb_40_486, limb_40_480}; // decl: <none>; prim: <none>
    assign limb_51_506 = tmp_workload_top_int_65__103_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_51_507 = __beopt_width_352[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_508Core rtlzz_owner_508(.a(32'(limb_51_506)), .b(32'(rtlzz_pipe_507_s6)), .cin(1'h0), .value(limb_51_508));
    assign limb_51_509 = limb_51_508[31:0]; // decl: <none>; prim: <none>
    assign limb_51_510 = limb_51_508[32]; // decl: <none>; prim: <none>
    assign limb_51_511 = tmp_workload_top_int_65__103_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_51_512 = __beopt_width_352[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_513Core rtlzz_owner_513(.a(32'(limb_51_511)), .b(32'(rtlzz_pipe_512_s6)), .cin(limb_51_510), .value(limb_51_513));
    assign limb_51_514 = limb_51_513[31:0]; // decl: <none>; prim: <none>
    assign limb_51_515 = limb_51_513[32]; // decl: <none>; prim: <none>
    assign limb_51_516 = tmp_workload_top_int_65__103_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_517 = __beopt_width_352[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_518Core rtlzz_owner_518(.a(1'(limb_51_516)), .b(1'(rtlzz_pipe_517_s6)), .cin(limb_51_515), .value(limb_51_518[0:0]));
    assign limb_51_518[1:1] = '0;
    assign limb_51_519 = limb_51_518[0]; // decl: <none>; prim: <none>
    assign limb_51_520 = {limb_51_519, limb_51_514, limb_51_509}; // decl: <none>; prim: <none>
    assign limb_53_521 = tmp_workload_top_int_65__108_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_53_522 = __beopt_width_357[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_523Core rtlzz_owner_523(.a(32'(limb_53_521)), .b(32'(rtlzz_pipe_522_s7)), .cin(1'h0), .value(limb_53_523));
    assign limb_53_524 = limb_53_523[31:0]; // decl: <none>; prim: <none>
    assign limb_53_525 = limb_53_523[32]; // decl: <none>; prim: <none>
    assign limb_53_526 = tmp_workload_top_int_65__108_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_53_527 = __beopt_width_357[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_528Core rtlzz_owner_528(.a(32'(limb_53_526)), .b(32'(rtlzz_pipe_527_s7)), .cin(limb_53_525), .value(limb_53_528));
    assign limb_53_529 = limb_53_528[31:0]; // decl: <none>; prim: <none>
    assign limb_53_530 = limb_53_528[32]; // decl: <none>; prim: <none>
    assign limb_53_531 = tmp_workload_top_int_65__108_v0[64]; // decl: <none>; prim: <none>
    assign limb_53_532 = __beopt_width_357[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_533Core rtlzz_owner_533(.a(1'(limb_53_531)), .b(1'(rtlzz_pipe_532_s7)), .cin(limb_53_530), .value(limb_53_533[0:0]));
    assign limb_53_533[1:1] = '0;
    assign limb_53_534 = limb_53_533[0]; // decl: <none>; prim: <none>
    assign limb_53_535 = {limb_53_534, limb_53_529, limb_53_524}; // decl: <none>; prim: <none>
    assign limb_59_536 = tmp_workload_top_int_34__127_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_59_537 = __beopt_width_367[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_538Core rtlzz_owner_538(.a(32'(limb_59_536)), .b(32'(limb_59_537)), .cin(1'h0), .value(limb_59_538));
    assign limb_59_539 = limb_59_538[31:0]; // decl: <none>; prim: <none>
    assign limb_59_540 = limb_59_538[32]; // decl: <none>; prim: <none>
    assign limb_59_541 = tmp_workload_top_int_34__127_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_59_542 = __beopt_width_367[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_543Core rtlzz_owner_543(.a(2'(limb_59_541)), .b(2'(limb_59_542)), .cin(limb_59_540), .value(limb_59_543[1:0]));
    assign limb_59_543[2:2] = '0;
    assign limb_59_544 = limb_59_543[1:0]; // decl: <none>; prim: <none>
    assign limb_59_545 = {limb_59_544, limb_59_539}; // decl: <none>; prim: <none>
    assign limb_61_546 = tmp_workload_top_int_34__132_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_61_547 = __beopt_width_370[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_548Core rtlzz_owner_548(.a(32'(limb_61_546)), .b(32'(limb_61_547)), .cin(1'h0), .value(limb_61_548));
    assign limb_61_549 = limb_61_548[31:0]; // decl: <none>; prim: <none>
    assign limb_61_550 = limb_61_548[32]; // decl: <none>; prim: <none>
    assign limb_61_551 = tmp_workload_top_int_34__132_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_61_552 = __beopt_width_370[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_553Core rtlzz_owner_553(.a(2'(limb_61_551)), .b(2'(limb_61_552)), .cin(limb_61_550), .value(limb_61_553[1:0]));
    assign limb_61_553[2:2] = '0;
    assign limb_61_554 = limb_61_553[1:0]; // decl: <none>; prim: <none>
    assign limb_61_555 = {limb_61_554, limb_61_549}; // decl: <none>; prim: <none>
    assign limb_67_556 = n41_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_67_557 = tmp_workload_top_int_68__142_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_67_558 = (~limb_67_557); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_559Core rtlzz_owner_559(.a(32'(limb_67_556)), .b(32'(limb_67_558)), .cin(1'h1), .value(limb_67_559));
    assign limb_67_560 = limb_67_559[31:0]; // decl: <none>; prim: <none>
    assign limb_67_561 = limb_67_559[32]; // decl: <none>; prim: <none>
    assign limb_67_562 = n41_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_67_563 = tmp_workload_top_int_68__142_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_67_564 = (~limb_67_563); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_565Core rtlzz_owner_565(.a(32'(limb_67_562)), .b(32'(limb_67_564)), .cin(limb_67_561), .value(limb_67_565));
    assign limb_67_566 = limb_67_565[31:0]; // decl: <none>; prim: <none>
    assign limb_67_567 = limb_67_565[32]; // decl: <none>; prim: <none>
    assign limb_67_568 = n41_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_569 = tmp_workload_top_int_68__142_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_570 = (~limb_67_569); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_571Core rtlzz_owner_571(.a(4'(limb_67_568)), .b(4'(limb_67_570)), .cin(limb_67_567), .value(limb_67_571[3:0]));
    assign limb_67_571[4:4] = '0;
    assign limb_67_572 = limb_67_571[3:0]; // decl: <none>; prim: <none>
    assign limb_67_573 = {limb_67_572, limb_67_566, limb_67_560}; // decl: <none>; prim: <none>
    assign limb_69_574 = s8_norm_sub_107_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_69_575 = tmp_workload_top_int_68__145_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_69_576 = (~limb_69_575); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_577Core rtlzz_owner_577(.a(32'(limb_69_574)), .b(32'(limb_69_576)), .cin(1'h1), .value(limb_69_577));
    assign limb_69_578 = limb_69_577[31:0]; // decl: <none>; prim: <none>
    assign limb_69_579 = limb_69_577[32]; // decl: <none>; prim: <none>
    assign limb_69_580 = s8_norm_sub_107_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_69_581 = tmp_workload_top_int_68__145_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_69_582 = (~limb_69_581); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_583Core rtlzz_owner_583(.a(32'(limb_69_580)), .b(32'(limb_69_582)), .cin(limb_69_579), .value(limb_69_583));
    assign limb_69_584 = limb_69_583[31:0]; // decl: <none>; prim: <none>
    assign limb_69_585 = limb_69_583[32]; // decl: <none>; prim: <none>
    assign limb_69_586 = s8_norm_sub_107_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_587 = tmp_workload_top_int_68__145_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_588 = (~limb_69_587); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589Core rtlzz_owner_589(.a(4'(limb_69_586)), .b(4'(limb_69_588)), .cin(limb_69_585), .value(limb_69_589[3:0]));
    assign limb_69_589[4:4] = '0;
    assign limb_69_590 = limb_69_589[3:0]; // decl: <none>; prim: <none>
    assign limb_69_591 = {limb_69_590, limb_69_584, limb_69_578}; // decl: <none>; prim: <none>
    assign limb_76_592 = __beopt_width_313[31:0]; // decl: <none>; prim: <none>
    assign limb_76_593 = tmp_workload_top_int_130__158_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_76_594 = (~limb_76_593); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_595Core rtlzz_owner_595(.a(32'(limb_76_592)), .b(32'(rtlzz_pipe_594_s7)), .cin(1'h1), .value(limb_76_595));
    assign limb_76_596 = limb_76_595[31:0]; // decl: <none>; prim: <none>
    assign limb_76_597 = limb_76_595[32]; // decl: <none>; prim: <none>
    assign limb_76_598 = __beopt_width_313[63:32]; // decl: <none>; prim: <none>
    assign limb_76_599 = tmp_workload_top_int_130__158_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_76_600 = (~limb_76_599); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_601Core rtlzz_owner_601(.a(32'(limb_76_598)), .b(32'(rtlzz_pipe_600_s7)), .cin(limb_76_597), .value(limb_76_601));
    assign limb_76_602 = limb_76_601[31:0]; // decl: <none>; prim: <none>
    assign limb_76_603 = limb_76_601[32]; // decl: <none>; prim: <none>
    assign limb_76_604 = __beopt_width_313[95:64]; // decl: <none>; prim: <none>
    assign limb_76_605 = tmp_workload_top_int_130__158_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_76_606 = (~limb_76_605); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_607Core rtlzz_owner_607(.a(32'(limb_76_604)), .b(32'(rtlzz_pipe_606_s7)), .cin(limb_76_603), .value(limb_76_607));
    assign limb_76_608 = limb_76_607[31:0]; // decl: <none>; prim: <none>
    assign limb_76_609 = limb_76_607[32]; // decl: <none>; prim: <none>
    assign limb_76_610 = __beopt_width_313[127:96]; // decl: <none>; prim: <none>
    assign limb_76_611 = tmp_workload_top_int_130__158_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_76_612 = (~limb_76_611); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_613Core rtlzz_owner_613(.a(32'(limb_76_610)), .b(32'(rtlzz_pipe_612_s7)), .cin(limb_76_609), .value(limb_76_613));
    assign limb_76_614 = limb_76_613[31:0]; // decl: <none>; prim: <none>
    assign limb_76_615 = limb_76_613[32]; // decl: <none>; prim: <none>
    assign limb_76_616 = __beopt_width_313[129:128]; // decl: <none>; prim: <none>
    assign limb_76_617 = tmp_workload_top_int_130__158_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_76_618 = (~limb_76_617); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_619Core rtlzz_owner_619(.a(2'(limb_76_616)), .b(2'(rtlzz_pipe_618_s7)), .cin(limb_76_615), .value(limb_76_619[1:0]));
    assign limb_76_619[2:2] = '0;
    assign limb_76_620 = limb_76_619[1:0]; // decl: <none>; prim: <none>
    assign limb_76_621 = {limb_76_620, limb_76_614, limb_76_608, limb_76_602, limb_76_596}; // decl: <none>; prim: <none>
    assign limb_78_622 = s8_norm_sub_118_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_78_623 = tmp_workload_top_int_130__161_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_78_624 = (~limb_78_623); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_625Core rtlzz_owner_625(.a(32'(limb_78_622)), .b(32'(limb_78_624)), .cin(1'h1), .value(limb_78_625));
    assign limb_78_626 = limb_78_625[31:0]; // decl: <none>; prim: <none>
    assign limb_78_627 = limb_78_625[32]; // decl: <none>; prim: <none>
    assign limb_78_628 = s8_norm_sub_118_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_78_629 = tmp_workload_top_int_130__161_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_78_630 = (~limb_78_629); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_631Core rtlzz_owner_631(.a(32'(limb_78_628)), .b(32'(limb_78_630)), .cin(limb_78_627), .value(limb_78_631));
    assign limb_78_632 = limb_78_631[31:0]; // decl: <none>; prim: <none>
    assign limb_78_633 = limb_78_631[32]; // decl: <none>; prim: <none>
    assign limb_78_634 = s8_norm_sub_118_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_78_635 = tmp_workload_top_int_130__161_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_78_636 = (~limb_78_635); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_637Core rtlzz_owner_637(.a(32'(limb_78_634)), .b(32'(limb_78_636)), .cin(limb_78_633), .value(limb_78_637));
    assign limb_78_638 = limb_78_637[31:0]; // decl: <none>; prim: <none>
    assign limb_78_639 = limb_78_637[32]; // decl: <none>; prim: <none>
    assign limb_78_640 = s8_norm_sub_118_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_78_641 = tmp_workload_top_int_130__161_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_78_642 = (~limb_78_641); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_643Core rtlzz_owner_643(.a(32'(limb_78_640)), .b(32'(limb_78_642)), .cin(limb_78_639), .value(limb_78_643));
    assign limb_78_644 = limb_78_643[31:0]; // decl: <none>; prim: <none>
    assign limb_78_645 = limb_78_643[32]; // decl: <none>; prim: <none>
    assign limb_78_646 = s8_norm_sub_118_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_647 = tmp_workload_top_int_130__161_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_648 = (~limb_78_647); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_649Core rtlzz_owner_649(.a(2'(limb_78_646)), .b(2'(limb_78_648)), .cin(limb_78_645), .value(limb_78_649[1:0]));
    assign limb_78_649[2:2] = '0;
    assign limb_78_650 = limb_78_649[1:0]; // decl: <none>; prim: <none>
    assign limb_78_651 = {limb_78_650, limb_78_644, limb_78_638, limb_78_632, limb_78_626}; // decl: <none>; prim: <none>
    assign limb_85_652 = tmp_workload_top_int_129__174_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_85_653 = __beopt_width_374[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_654Core rtlzz_owner_654(.a(32'(rtlzz_pipe_652_s2)), .b(32'(limb_85_653)), .cin(1'h0), .value(limb_85_654));
    assign limb_85_655 = limb_85_654[31:0]; // decl: <none>; prim: <none>
    assign limb_85_656 = limb_85_654[32]; // decl: <none>; prim: <none>
    assign limb_85_657 = tmp_workload_top_int_129__174_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_85_658 = __beopt_width_374[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_659Core rtlzz_owner_659(.a(32'(rtlzz_pipe_657_s2)), .b(32'(limb_85_658)), .cin(limb_85_656), .value(limb_85_659));
    assign limb_85_660 = limb_85_659[31:0]; // decl: <none>; prim: <none>
    assign limb_85_661 = limb_85_659[32]; // decl: <none>; prim: <none>
    assign limb_85_662 = tmp_workload_top_int_129__174_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_85_663 = __beopt_width_374[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_664Core rtlzz_owner_664(.a(32'(rtlzz_pipe_662_s2)), .b(32'(limb_85_663)), .cin(limb_85_661), .value(limb_85_664));
    assign limb_85_665 = limb_85_664[31:0]; // decl: <none>; prim: <none>
    assign limb_85_666 = limb_85_664[32]; // decl: <none>; prim: <none>
    assign limb_85_667 = tmp_workload_top_int_129__174_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_85_668 = __beopt_width_374[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_669Core rtlzz_owner_669(.a(32'(rtlzz_pipe_667_s3)), .b(32'(rtlzz_pipe_668_s3)), .cin(rtlzz_pipe_666_s3), .value(limb_85_669));
    assign limb_85_670 = limb_85_669[31:0]; // decl: <none>; prim: <none>
    assign limb_85_671 = limb_85_669[32]; // decl: <none>; prim: <none>
    assign limb_85_672 = tmp_workload_top_int_129__174_v0[128]; // decl: <none>; prim: <none>
    assign limb_85_673 = __beopt_width_374[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_674Core rtlzz_owner_674(.a(1'(rtlzz_pipe_672_s3)), .b(1'(rtlzz_pipe_673_s3)), .cin(limb_85_671), .value(limb_85_674[0:0]));
    assign limb_85_674[1:1] = '0;
    assign limb_85_675 = limb_85_674[0]; // decl: <none>; prim: <none>
    assign limb_85_676 = {limb_85_675, limb_85_670, rtlzz_pipe_665_s3, rtlzz_pipe_660_s3, rtlzz_pipe_655_s3}; // decl: <none>; prim: <none>
    assign limb_87_677 = tmp_workload_top_int_129__179_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_87_678 = __beopt_width_378[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_679Core rtlzz_owner_679(.a(32'(rtlzz_pipe_677_s4)), .b(32'(limb_87_678)), .cin(1'h0), .value(limb_87_679));
    assign limb_87_680 = limb_87_679[31:0]; // decl: <none>; prim: <none>
    assign limb_87_681 = limb_87_679[32]; // decl: <none>; prim: <none>
    assign limb_87_682 = tmp_workload_top_int_129__179_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_87_683 = __beopt_width_378[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_684Core rtlzz_owner_684(.a(32'(rtlzz_pipe_682_s4)), .b(32'(limb_87_683)), .cin(limb_87_681), .value(limb_87_684));
    assign limb_87_685 = limb_87_684[31:0]; // decl: <none>; prim: <none>
    assign limb_87_686 = limb_87_684[32]; // decl: <none>; prim: <none>
    assign limb_87_687 = tmp_workload_top_int_129__179_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_87_688 = __beopt_width_378[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_689Core rtlzz_owner_689(.a(32'(rtlzz_pipe_687_s4)), .b(32'(limb_87_688)), .cin(limb_87_686), .value(limb_87_689));
    assign limb_87_690 = limb_87_689[31:0]; // decl: <none>; prim: <none>
    assign limb_87_691 = limb_87_689[32]; // decl: <none>; prim: <none>
    assign limb_87_692 = tmp_workload_top_int_129__179_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_87_693 = __beopt_width_378[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_694Core rtlzz_owner_694(.a(32'(rtlzz_pipe_692_s4)), .b(32'(limb_87_693)), .cin(limb_87_691), .value(limb_87_694));
    assign limb_87_695 = limb_87_694[31:0]; // decl: <none>; prim: <none>
    assign limb_87_696 = limb_87_694[32]; // decl: <none>; prim: <none>
    assign limb_87_697 = tmp_workload_top_int_129__179_v0[128]; // decl: <none>; prim: <none>
    assign limb_87_698 = __beopt_width_378[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_699Core rtlzz_owner_699(.a(1'(rtlzz_pipe_697_s4)), .b(1'(limb_87_698)), .cin(limb_87_696), .value(limb_87_699[0:0]));
    assign limb_87_699[1:1] = '0;
    assign limb_87_700 = limb_87_699[0]; // decl: <none>; prim: <none>
    assign limb_87_701 = {limb_87_700, limb_87_695, limb_87_690, limb_87_685, limb_87_680}; // decl: <none>; prim: <none>
    assign limb_95_702 = tmp_workload_top_int_34__202_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_95_703 = __beopt_width_388[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_704Core rtlzz_owner_704(.a(32'(limb_95_702)), .b(32'(limb_95_703)), .cin(1'h0), .value(limb_95_704));
    assign limb_95_705 = limb_95_704[31:0]; // decl: <none>; prim: <none>
    assign limb_95_706 = limb_95_704[32]; // decl: <none>; prim: <none>
    assign limb_95_707 = tmp_workload_top_int_34__202_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_95_708 = __beopt_width_388[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_709Core rtlzz_owner_709(.a(2'(limb_95_707)), .b(2'(limb_95_708)), .cin(limb_95_706), .value(limb_95_709[1:0]));
    assign limb_95_709[2:2] = '0;
    assign limb_95_710 = limb_95_709[1:0]; // decl: <none>; prim: <none>
    assign limb_95_711 = {limb_95_710, limb_95_705}; // decl: <none>; prim: <none>
    assign limb_97_712 = tmp_workload_top_int_34__207_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_97_713 = __beopt_width_391[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_714Core rtlzz_owner_714(.a(32'(limb_97_712)), .b(32'(limb_97_713)), .cin(1'h0), .value(limb_97_714));
    assign limb_97_715 = limb_97_714[31:0]; // decl: <none>; prim: <none>
    assign limb_97_716 = limb_97_714[32]; // decl: <none>; prim: <none>
    assign limb_97_717 = tmp_workload_top_int_34__207_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_97_718 = __beopt_width_391[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_719Core rtlzz_owner_719(.a(2'(limb_97_717)), .b(2'(limb_97_718)), .cin(limb_97_716), .value(limb_97_719[1:0]));
    assign limb_97_719[2:2] = '0;
    assign limb_97_720 = limb_97_719[1:0]; // decl: <none>; prim: <none>
    assign limb_97_721 = {limb_97_720, limb_97_715}; // decl: <none>; prim: <none>
    assign limb_103_722 = n60_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_103_723 = tmp_workload_top_int_68__217_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_103_724 = (~limb_103_723); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_725Core rtlzz_owner_725(.a(32'(limb_103_722)), .b(32'(rtlzz_pipe_724_s5)), .cin(1'h1), .value(limb_103_725));
    assign limb_103_726 = limb_103_725[31:0]; // decl: <none>; prim: <none>
    assign limb_103_727 = limb_103_725[32]; // decl: <none>; prim: <none>
    assign limb_103_728 = n60_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_103_729 = tmp_workload_top_int_68__217_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_103_730 = (~limb_103_729); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_731Core rtlzz_owner_731(.a(32'(limb_103_728)), .b(32'(rtlzz_pipe_730_s5)), .cin(limb_103_727), .value(limb_103_731));
    assign limb_103_732 = limb_103_731[31:0]; // decl: <none>; prim: <none>
    assign limb_103_733 = limb_103_731[32]; // decl: <none>; prim: <none>
    assign limb_103_734 = n60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_735 = tmp_workload_top_int_68__217_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_736 = (~limb_103_735); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_737Core rtlzz_owner_737(.a(4'(limb_103_734)), .b(4'(rtlzz_pipe_736_s5)), .cin(limb_103_733), .value(limb_103_737[3:0]));
    assign limb_103_737[4:4] = '0;
    assign limb_103_738 = limb_103_737[3:0]; // decl: <none>; prim: <none>
    assign limb_103_739 = {limb_103_738, limb_103_732, limb_103_726}; // decl: <none>; prim: <none>
    assign limb_105_740 = s8_norm_sub_161_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_105_741 = tmp_workload_top_int_68__220_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_105_742 = (~limb_105_741); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_743Core rtlzz_owner_743(.a(32'(limb_105_740)), .b(32'(limb_105_742)), .cin(1'h1), .value(limb_105_743));
    assign limb_105_744 = limb_105_743[31:0]; // decl: <none>; prim: <none>
    assign limb_105_745 = limb_105_743[32]; // decl: <none>; prim: <none>
    assign limb_105_746 = s8_norm_sub_161_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_105_747 = tmp_workload_top_int_68__220_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_105_748 = (~limb_105_747); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_749Core rtlzz_owner_749(.a(32'(limb_105_746)), .b(32'(limb_105_748)), .cin(limb_105_745), .value(limb_105_749));
    assign limb_105_750 = limb_105_749[31:0]; // decl: <none>; prim: <none>
    assign limb_105_751 = limb_105_749[32]; // decl: <none>; prim: <none>
    assign limb_105_752 = s8_norm_sub_161_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_753 = tmp_workload_top_int_68__220_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_754 = (~limb_105_753); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_755Core rtlzz_owner_755(.a(4'(limb_105_752)), .b(4'(limb_105_754)), .cin(limb_105_751), .value(limb_105_755[3:0]));
    assign limb_105_755[4:4] = '0;
    assign limb_105_756 = limb_105_755[3:0]; // decl: <none>; prim: <none>
    assign limb_105_757 = {limb_105_756, limb_105_750, limb_105_744}; // decl: <none>; prim: <none>
    assign limb_113_758 = tmp_workload_top_int_66__238_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_113_759 = __beopt_width_401[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_760Core rtlzz_owner_760(.a(32'(limb_113_758)), .b(32'(limb_113_759)), .cin(1'h0), .value(limb_113_760));
    assign limb_113_761 = limb_113_760[31:0]; // decl: <none>; prim: <none>
    assign limb_113_762 = limb_113_760[32]; // decl: <none>; prim: <none>
    assign limb_113_763 = tmp_workload_top_int_66__238_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_113_764 = __beopt_width_401[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_765Core rtlzz_owner_765(.a(32'(limb_113_763)), .b(32'(limb_113_764)), .cin(limb_113_762), .value(limb_113_765));
    assign limb_113_766 = limb_113_765[31:0]; // decl: <none>; prim: <none>
    assign limb_113_767 = limb_113_765[32]; // decl: <none>; prim: <none>
    assign limb_113_768 = tmp_workload_top_int_66__238_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_113_769 = __beopt_width_401[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_770Core rtlzz_owner_770(.a(2'(limb_113_768)), .b(2'(limb_113_769)), .cin(limb_113_767), .value(limb_113_770[1:0]));
    assign limb_113_770[2:2] = '0;
    assign limb_113_771 = limb_113_770[1:0]; // decl: <none>; prim: <none>
    assign limb_113_772 = {limb_113_771, limb_113_766, limb_113_761}; // decl: <none>; prim: <none>
    assign limb_115_773 = tmp_workload_top_int_66__243_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_115_774 = __beopt_width_404[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_775Core rtlzz_owner_775(.a(32'(rtlzz_pipe_773_s5)), .b(32'(limb_115_774)), .cin(1'h0), .value(limb_115_775));
    assign limb_115_776 = limb_115_775[31:0]; // decl: <none>; prim: <none>
    assign limb_115_777 = limb_115_775[32]; // decl: <none>; prim: <none>
    assign limb_115_778 = tmp_workload_top_int_66__243_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_115_779 = __beopt_width_404[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_780Core rtlzz_owner_780(.a(32'(rtlzz_pipe_778_s5)), .b(32'(limb_115_779)), .cin(limb_115_777), .value(limb_115_780));
    assign limb_115_781 = limb_115_780[31:0]; // decl: <none>; prim: <none>
    assign limb_115_782 = limb_115_780[32]; // decl: <none>; prim: <none>
    assign limb_115_783 = tmp_workload_top_int_66__243_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_115_784 = __beopt_width_404[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_785Core rtlzz_owner_785(.a(2'(rtlzz_pipe_783_s5)), .b(2'(limb_115_784)), .cin(limb_115_782), .value(limb_115_785[1:0]));
    assign limb_115_785[2:2] = '0;
    assign limb_115_786 = limb_115_785[1:0]; // decl: <none>; prim: <none>
    assign limb_115_787 = {limb_115_786, limb_115_781, limb_115_776}; // decl: <none>; prim: <none>
    assign limb_121_788 = tmp_workload_top_int_34__262_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_121_789 = __beopt_width_416[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_790Core rtlzz_owner_790(.a(32'(limb_121_788)), .b(32'(limb_121_789)), .cin(1'h0), .value(limb_121_790));
    assign limb_121_791 = limb_121_790[31:0]; // decl: <none>; prim: <none>
    assign limb_121_792 = limb_121_790[32]; // decl: <none>; prim: <none>
    assign limb_121_793 = tmp_workload_top_int_34__262_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_121_794 = __beopt_width_416[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_795Core rtlzz_owner_795(.a(2'(limb_121_793)), .b(2'(limb_121_794)), .cin(limb_121_792), .value(limb_121_795[1:0]));
    assign limb_121_795[2:2] = '0;
    assign limb_121_796 = limb_121_795[1:0]; // decl: <none>; prim: <none>
    assign limb_121_797 = {limb_121_796, limb_121_791}; // decl: <none>; prim: <none>
    assign limb_123_798 = tmp_workload_top_int_34__267_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_123_799 = __beopt_width_424[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_800Core rtlzz_owner_800(.a(32'(limb_123_798)), .b(32'(limb_123_799)), .cin(1'h0), .value(limb_123_800));
    assign limb_123_801 = limb_123_800[31:0]; // decl: <none>; prim: <none>
    assign limb_123_802 = limb_123_800[32]; // decl: <none>; prim: <none>
    assign limb_123_803 = tmp_workload_top_int_34__267_v0[33:32]; // decl: <none>; prim: <none>
    assign limb_123_804 = __beopt_width_424[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_805Core rtlzz_owner_805(.a(2'(limb_123_803)), .b(2'(limb_123_804)), .cin(limb_123_802), .value(limb_123_805[1:0]));
    assign limb_123_805[2:2] = '0;
    assign limb_123_806 = limb_123_805[1:0]; // decl: <none>; prim: <none>
    assign limb_123_807 = {limb_123_806, limb_123_801}; // decl: <none>; prim: <none>
    assign limb_129_808 = n74_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_129_809 = tmp_workload_top_int_68__277_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_129_810 = (~limb_129_809); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_811Core rtlzz_owner_811(.a(32'(limb_129_808)), .b(32'(limb_129_810)), .cin(1'h1), .value(limb_129_811));
    assign limb_129_812 = limb_129_811[31:0]; // decl: <none>; prim: <none>
    assign limb_129_813 = limb_129_811[32]; // decl: <none>; prim: <none>
    assign limb_129_814 = n74_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_129_815 = tmp_workload_top_int_68__277_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_129_816 = (~limb_129_815); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_817Core rtlzz_owner_817(.a(32'(limb_129_814)), .b(32'(limb_129_816)), .cin(limb_129_813), .value(limb_129_817));
    assign limb_129_818 = limb_129_817[31:0]; // decl: <none>; prim: <none>
    assign limb_129_819 = limb_129_817[32]; // decl: <none>; prim: <none>
    assign limb_129_820 = n74_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_821 = tmp_workload_top_int_68__277_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_822 = (~limb_129_821); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_823Core rtlzz_owner_823(.a(4'(limb_129_820)), .b(4'(limb_129_822)), .cin(limb_129_819), .value(limb_129_823[3:0]));
    assign limb_129_823[4:4] = '0;
    assign limb_129_824 = limb_129_823[3:0]; // decl: <none>; prim: <none>
    assign limb_129_825 = {limb_129_824, limb_129_818, limb_129_812}; // decl: <none>; prim: <none>
    assign limb_131_826 = s8_norm_sub_204_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_131_827 = tmp_workload_top_int_68__280_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_131_828 = (~limb_131_827); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_829Core rtlzz_owner_829(.a(32'(limb_131_826)), .b(32'(rtlzz_pipe_828_s6)), .cin(1'h1), .value(limb_131_829));
    assign limb_131_830 = limb_131_829[31:0]; // decl: <none>; prim: <none>
    assign limb_131_831 = limb_131_829[32]; // decl: <none>; prim: <none>
    assign limb_131_832 = s8_norm_sub_204_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_131_833 = tmp_workload_top_int_68__280_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_131_834 = (~limb_131_833); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_835Core rtlzz_owner_835(.a(32'(limb_131_832)), .b(32'(rtlzz_pipe_834_s6)), .cin(limb_131_831), .value(limb_131_835));
    assign limb_131_836 = limb_131_835[31:0]; // decl: <none>; prim: <none>
    assign limb_131_837 = limb_131_835[32]; // decl: <none>; prim: <none>
    assign limb_131_838 = s8_norm_sub_204_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_839 = tmp_workload_top_int_68__280_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_840 = (~limb_131_839); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_841Core rtlzz_owner_841(.a(4'(limb_131_838)), .b(4'(rtlzz_pipe_840_s6)), .cin(limb_131_837), .value(limb_131_841[3:0]));
    assign limb_131_841[4:4] = '0;
    assign limb_131_842 = limb_131_841[3:0]; // decl: <none>; prim: <none>
    assign limb_131_843 = {limb_131_842, limb_131_836, limb_131_830}; // decl: <none>; prim: <none>
    assign limb_138_844 = __beopt_width_307[31:0]; // decl: <none>; prim: <none>
    assign limb_138_845 = tmp_workload_top_int_132__293_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_138_846 = (~limb_138_845); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_847Core rtlzz_owner_847(.a(32'(limb_138_844)), .b(32'(rtlzz_pipe_846_s6)), .cin(1'h1), .value(limb_138_847));
    assign limb_138_848 = limb_138_847[31:0]; // decl: <none>; prim: <none>
    assign limb_138_849 = limb_138_847[32]; // decl: <none>; prim: <none>
    assign limb_138_850 = __beopt_width_307[63:32]; // decl: <none>; prim: <none>
    assign limb_138_851 = tmp_workload_top_int_132__293_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_138_852 = (~limb_138_851); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_853Core rtlzz_owner_853(.a(32'(limb_138_850)), .b(32'(rtlzz_pipe_852_s6)), .cin(limb_138_849), .value(limb_138_853));
    assign limb_138_854 = limb_138_853[31:0]; // decl: <none>; prim: <none>
    assign limb_138_855 = limb_138_853[32]; // decl: <none>; prim: <none>
    assign limb_138_856 = __beopt_width_307[95:64]; // decl: <none>; prim: <none>
    assign limb_138_857 = tmp_workload_top_int_132__293_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_138_858 = (~limb_138_857); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_859Core rtlzz_owner_859(.a(32'(limb_138_856)), .b(32'(rtlzz_pipe_858_s6)), .cin(limb_138_855), .value(limb_138_859));
    assign limb_138_860 = limb_138_859[31:0]; // decl: <none>; prim: <none>
    assign limb_138_861 = limb_138_859[32]; // decl: <none>; prim: <none>
    assign limb_138_862 = __beopt_width_307[127:96]; // decl: <none>; prim: <none>
    assign limb_138_863 = tmp_workload_top_int_132__293_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_138_864 = (~limb_138_863); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_865Core rtlzz_owner_865(.a(32'(limb_138_862)), .b(32'(rtlzz_pipe_864_s6)), .cin(limb_138_861), .value(limb_138_865));
    assign limb_138_866 = limb_138_865[31:0]; // decl: <none>; prim: <none>
    assign limb_138_867 = limb_138_865[32]; // decl: <none>; prim: <none>
    assign limb_138_868 = __beopt_width_307[131:128]; // decl: <none>; prim: <none>
    assign limb_138_869 = tmp_workload_top_int_132__293_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_138_870 = (~limb_138_869); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_871Core rtlzz_owner_871(.a(4'(limb_138_868)), .b(4'(rtlzz_pipe_870_s6)), .cin(limb_138_867), .value(limb_138_871[3:0]));
    assign limb_138_871[4:4] = '0;
    assign limb_138_872 = limb_138_871[3:0]; // decl: <none>; prim: <none>
    assign limb_138_873 = {limb_138_872, limb_138_866, limb_138_860, limb_138_854, limb_138_848}; // decl: <none>; prim: <none>
    assign limb_140_874 = s8_norm_sub_215_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_140_875 = tmp_workload_top_int_132__296_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_140_876 = (~limb_140_875); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_877Core rtlzz_owner_877(.a(32'(limb_140_874)), .b(32'(rtlzz_pipe_876_s6)), .cin(1'h1), .value(limb_140_877));
    assign limb_140_878 = limb_140_877[31:0]; // decl: <none>; prim: <none>
    assign limb_140_879 = limb_140_877[32]; // decl: <none>; prim: <none>
    assign limb_140_880 = s8_norm_sub_215_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_140_881 = tmp_workload_top_int_132__296_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_140_882 = (~limb_140_881); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_883Core rtlzz_owner_883(.a(32'(limb_140_880)), .b(32'(rtlzz_pipe_882_s6)), .cin(limb_140_879), .value(limb_140_883));
    assign limb_140_884 = limb_140_883[31:0]; // decl: <none>; prim: <none>
    assign limb_140_885 = limb_140_883[32]; // decl: <none>; prim: <none>
    assign limb_140_886 = s8_norm_sub_215_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_140_887 = tmp_workload_top_int_132__296_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_140_888 = (~limb_140_887); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_889Core rtlzz_owner_889(.a(32'(limb_140_886)), .b(32'(rtlzz_pipe_888_s6)), .cin(limb_140_885), .value(limb_140_889));
    assign limb_140_890 = limb_140_889[31:0]; // decl: <none>; prim: <none>
    assign limb_140_891 = limb_140_889[32]; // decl: <none>; prim: <none>
    assign limb_140_892 = s8_norm_sub_215_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_140_893 = tmp_workload_top_int_132__296_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_140_894 = (~limb_140_893); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_895Core rtlzz_owner_895(.a(32'(limb_140_892)), .b(32'(rtlzz_pipe_894_s6)), .cin(limb_140_891), .value(limb_140_895));
    assign limb_140_896 = limb_140_895[31:0]; // decl: <none>; prim: <none>
    assign limb_140_897 = limb_140_895[32]; // decl: <none>; prim: <none>
    assign limb_140_898 = s8_norm_sub_215_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_899 = tmp_workload_top_int_132__296_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_900 = (~limb_140_899); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_901Core rtlzz_owner_901(.a(4'(limb_140_898)), .b(4'(rtlzz_pipe_900_s6)), .cin(limb_140_897), .value(limb_140_901[3:0]));
    assign limb_140_901[4:4] = '0;
    assign limb_140_902 = limb_140_901[3:0]; // decl: <none>; prim: <none>
    assign limb_140_903 = {limb_140_902, limb_140_896, limb_140_890, limb_140_884, limb_140_878}; // decl: <none>; prim: <none>
    assign limb_147_904 = __beopt_width_297[31:0]; // decl: <none>; prim: <none>
    assign limb_147_905 = tmp_workload_top_int_258__309_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_147_906 = (~limb_147_905); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_907Core rtlzz_owner_907(.a(32'(limb_147_904)), .b(32'(limb_147_906)), .cin(1'h1), .value(limb_147_907));
    assign limb_147_908 = limb_147_907[31:0]; // decl: <none>; prim: <none>
    assign limb_147_909 = limb_147_907[32]; // decl: <none>; prim: <none>
    assign limb_147_910 = __beopt_width_297[63:32]; // decl: <none>; prim: <none>
    assign limb_147_911 = tmp_workload_top_int_258__309_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_147_912 = (~limb_147_911); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_913Core rtlzz_owner_913(.a(32'(limb_147_910)), .b(32'(limb_147_912)), .cin(limb_147_909), .value(limb_147_913));
    assign limb_147_914 = limb_147_913[31:0]; // decl: <none>; prim: <none>
    assign limb_147_915 = limb_147_913[32]; // decl: <none>; prim: <none>
    assign limb_147_916 = __beopt_width_297[95:64]; // decl: <none>; prim: <none>
    assign limb_147_917 = tmp_workload_top_int_258__309_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_147_918 = (~limb_147_917); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_919Core rtlzz_owner_919(.a(32'(limb_147_916)), .b(32'(limb_147_918)), .cin(limb_147_915), .value(limb_147_919));
    assign limb_147_920 = limb_147_919[31:0]; // decl: <none>; prim: <none>
    assign limb_147_921 = limb_147_919[32]; // decl: <none>; prim: <none>
    assign limb_147_922 = __beopt_width_297[127:96]; // decl: <none>; prim: <none>
    assign limb_147_923 = tmp_workload_top_int_258__309_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_147_924 = (~limb_147_923); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_925Core rtlzz_owner_925(.a(32'(limb_147_922)), .b(32'(limb_147_924)), .cin(limb_147_921), .value(limb_147_925));
    assign limb_147_926 = limb_147_925[31:0]; // decl: <none>; prim: <none>
    assign limb_147_927 = limb_147_925[32]; // decl: <none>; prim: <none>
    assign limb_147_928 = __beopt_width_297[159:128]; // decl: <none>; prim: <none>
    assign limb_147_929 = tmp_workload_top_int_258__309_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_147_930 = (~limb_147_929); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_931Core rtlzz_owner_931(.a(32'(limb_147_928)), .b(32'(limb_147_930)), .cin(limb_147_927), .value(limb_147_931));
    assign limb_147_932 = limb_147_931[31:0]; // decl: <none>; prim: <none>
    assign limb_147_933 = limb_147_931[32]; // decl: <none>; prim: <none>
    assign limb_147_934 = __beopt_width_297[191:160]; // decl: <none>; prim: <none>
    assign limb_147_935 = tmp_workload_top_int_258__309_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_147_936 = (~limb_147_935); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_937Core rtlzz_owner_937(.a(32'(limb_147_934)), .b(32'(limb_147_936)), .cin(limb_147_933), .value(limb_147_937));
    assign limb_147_938 = limb_147_937[31:0]; // decl: <none>; prim: <none>
    assign limb_147_939 = limb_147_937[32]; // decl: <none>; prim: <none>
    assign limb_147_940 = __beopt_width_297[223:192]; // decl: <none>; prim: <none>
    assign limb_147_941 = tmp_workload_top_int_258__309_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_147_942 = (~limb_147_941); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_943Core rtlzz_owner_943(.a(32'(limb_147_940)), .b(32'(limb_147_942)), .cin(limb_147_939), .value(limb_147_943));
    assign limb_147_944 = limb_147_943[31:0]; // decl: <none>; prim: <none>
    assign limb_147_945 = limb_147_943[32]; // decl: <none>; prim: <none>
    assign limb_147_946 = __beopt_width_297[255:224]; // decl: <none>; prim: <none>
    assign limb_147_947 = tmp_workload_top_int_258__309_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_147_948 = (~limb_147_947); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_949Core rtlzz_owner_949(.a(32'(limb_147_946)), .b(32'(limb_147_948)), .cin(limb_147_945), .value(limb_147_949));
    assign limb_147_950 = limb_147_949[31:0]; // decl: <none>; prim: <none>
    assign limb_147_951 = limb_147_949[32]; // decl: <none>; prim: <none>
    assign limb_147_952 = __beopt_width_297[257:256]; // decl: <none>; prim: <none>
    assign limb_147_953 = tmp_workload_top_int_258__309_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_147_954 = (~limb_147_953); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_955Core rtlzz_owner_955(.a(2'(limb_147_952)), .b(2'(limb_147_954)), .cin(limb_147_951), .value(limb_147_955[1:0]));
    assign limb_147_955[2:2] = '0;
    assign limb_147_956 = limb_147_955[1:0]; // decl: <none>; prim: <none>
    assign limb_147_957 = {limb_147_956, limb_147_950, limb_147_944, limb_147_938, limb_147_932, limb_147_926, limb_147_920, limb_147_914, limb_147_908}; // decl: <none>; prim: <none>
    assign limb_149_958 = s8_norm_sub_226_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_149_959 = tmp_workload_top_int_258__312_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_149_960 = (~limb_149_959); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_961Core rtlzz_owner_961(.a(32'(limb_149_958)), .b(32'(limb_149_960)), .cin(1'h1), .value(limb_149_961));
    assign limb_149_962 = limb_149_961[31:0]; // decl: <none>; prim: <none>
    assign limb_149_963 = limb_149_961[32]; // decl: <none>; prim: <none>
    assign limb_149_964 = s8_norm_sub_226_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_149_965 = tmp_workload_top_int_258__312_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_149_966 = (~limb_149_965); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_967Core rtlzz_owner_967(.a(32'(limb_149_964)), .b(32'(limb_149_966)), .cin(limb_149_963), .value(limb_149_967));
    assign limb_149_968 = limb_149_967[31:0]; // decl: <none>; prim: <none>
    assign limb_149_969 = limb_149_967[32]; // decl: <none>; prim: <none>
    assign limb_149_970 = s8_norm_sub_226_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_149_971 = tmp_workload_top_int_258__312_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_149_972 = (~limb_149_971); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_973Core rtlzz_owner_973(.a(32'(limb_149_970)), .b(32'(limb_149_972)), .cin(limb_149_969), .value(limb_149_973));
    assign limb_149_974 = limb_149_973[31:0]; // decl: <none>; prim: <none>
    assign limb_149_975 = limb_149_973[32]; // decl: <none>; prim: <none>
    assign limb_149_976 = s8_norm_sub_226_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_149_977 = tmp_workload_top_int_258__312_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_149_978 = (~limb_149_977); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_979Core rtlzz_owner_979(.a(32'(limb_149_976)), .b(32'(limb_149_978)), .cin(limb_149_975), .value(limb_149_979));
    assign limb_149_980 = limb_149_979[31:0]; // decl: <none>; prim: <none>
    assign limb_149_981 = limb_149_979[32]; // decl: <none>; prim: <none>
    assign limb_149_982 = s8_norm_sub_226_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_149_983 = tmp_workload_top_int_258__312_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_149_984 = (~limb_149_983); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_985Core rtlzz_owner_985(.a(32'(limb_149_982)), .b(32'(limb_149_984)), .cin(limb_149_981), .value(limb_149_985));
    assign limb_149_986 = limb_149_985[31:0]; // decl: <none>; prim: <none>
    assign limb_149_987 = limb_149_985[32]; // decl: <none>; prim: <none>
    assign limb_149_988 = s8_norm_sub_226_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_149_989 = tmp_workload_top_int_258__312_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_149_990 = (~limb_149_989); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_991Core rtlzz_owner_991(.a(32'(limb_149_988)), .b(32'(limb_149_990)), .cin(limb_149_987), .value(limb_149_991));
    assign limb_149_992 = limb_149_991[31:0]; // decl: <none>; prim: <none>
    assign limb_149_993 = limb_149_991[32]; // decl: <none>; prim: <none>
    assign limb_149_994 = s8_norm_sub_226_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_149_995 = tmp_workload_top_int_258__312_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_149_996 = (~limb_149_995); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_997Core rtlzz_owner_997(.a(32'(limb_149_994)), .b(32'(limb_149_996)), .cin(limb_149_993), .value(limb_149_997));
    assign limb_149_998 = limb_149_997[31:0]; // decl: <none>; prim: <none>
    assign limb_149_999 = limb_149_997[32]; // decl: <none>; prim: <none>
    assign limb_149_1000 = s8_norm_sub_226_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_149_1001 = tmp_workload_top_int_258__312_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_149_1002 = (~limb_149_1001); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1003Core rtlzz_owner_1003(.a(32'(limb_149_1000)), .b(32'(limb_149_1002)), .cin(limb_149_999), .value(limb_149_1003));
    assign limb_149_1004 = limb_149_1003[31:0]; // decl: <none>; prim: <none>
    assign limb_149_1005 = limb_149_1003[32]; // decl: <none>; prim: <none>
    assign limb_149_1006 = s8_norm_sub_226_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1007 = tmp_workload_top_int_258__312_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1008 = (~limb_149_1007); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1009Core rtlzz_owner_1009(.a(2'(limb_149_1006)), .b(2'(limb_149_1008)), .cin(limb_149_1005), .value(limb_149_1009[1:0]));
    assign limb_149_1009[2:2] = '0;
    assign limb_149_1010 = limb_149_1009[1:0]; // decl: <none>; prim: <none>
    assign limb_149_1011 = {limb_149_1010, limb_149_1004, limb_149_998, limb_149_992, limb_149_986, limb_149_980, limb_149_974, limb_149_968, limb_149_962}; // decl: <none>; prim: <none>
    assign limb_157_1012 = tmp_workload_top_int_513__325_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1013 = tmp_workload_top_int_513__327_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1014Core rtlzz_owner_1014(.a(32'(limb_157_1012)), .b(32'(rtlzz_pipe_1013_s7)), .cin(1'h0), .value(limb_157_1014));
    assign limb_157_1015 = limb_157_1014[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1016 = limb_157_1014[32]; // decl: <none>; prim: <none>
    assign limb_157_1017 = tmp_workload_top_int_513__325_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_157_1018 = tmp_workload_top_int_513__327_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1019Core rtlzz_owner_1019(.a(32'(limb_157_1017)), .b(32'(rtlzz_pipe_1018_s7)), .cin(limb_157_1016), .value(limb_157_1019));
    assign limb_157_1020 = limb_157_1019[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1021 = limb_157_1019[32]; // decl: <none>; prim: <none>
    assign limb_157_1022 = tmp_workload_top_int_513__325_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_157_1023 = tmp_workload_top_int_513__327_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1024Core rtlzz_owner_1024(.a(32'(limb_157_1022)), .b(32'(rtlzz_pipe_1023_s7)), .cin(limb_157_1021), .value(limb_157_1024));
    assign limb_157_1025 = limb_157_1024[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1026 = limb_157_1024[32]; // decl: <none>; prim: <none>
    assign limb_157_1027 = tmp_workload_top_int_513__325_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_157_1028 = tmp_workload_top_int_513__327_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1029Core rtlzz_owner_1029(.a(32'(limb_157_1027)), .b(32'(rtlzz_pipe_1028_s7)), .cin(limb_157_1026), .value(limb_157_1029));
    assign limb_157_1030 = limb_157_1029[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1031 = limb_157_1029[32]; // decl: <none>; prim: <none>
    assign limb_157_1032 = tmp_workload_top_int_513__325_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_157_1033 = tmp_workload_top_int_513__327_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1034Core rtlzz_owner_1034(.a(32'(limb_157_1032)), .b(32'(rtlzz_pipe_1033_s7)), .cin(limb_157_1031), .value(limb_157_1034));
    assign limb_157_1035 = limb_157_1034[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1036 = limb_157_1034[32]; // decl: <none>; prim: <none>
    assign limb_157_1037 = tmp_workload_top_int_513__325_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_157_1038 = tmp_workload_top_int_513__327_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1039Core rtlzz_owner_1039(.a(32'(limb_157_1037)), .b(32'(rtlzz_pipe_1038_s7)), .cin(limb_157_1036), .value(limb_157_1039));
    assign limb_157_1040 = limb_157_1039[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1041 = limb_157_1039[32]; // decl: <none>; prim: <none>
    assign limb_157_1042 = tmp_workload_top_int_513__325_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_157_1043 = tmp_workload_top_int_513__327_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1044Core rtlzz_owner_1044(.a(32'(limb_157_1042)), .b(32'(rtlzz_pipe_1043_s7)), .cin(limb_157_1041), .value(limb_157_1044));
    assign limb_157_1045 = limb_157_1044[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1046 = limb_157_1044[32]; // decl: <none>; prim: <none>
    assign limb_157_1047 = tmp_workload_top_int_513__325_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_157_1048 = tmp_workload_top_int_513__327_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1049Core rtlzz_owner_1049(.a(32'(limb_157_1047)), .b(32'(rtlzz_pipe_1048_s7)), .cin(limb_157_1046), .value(limb_157_1049));
    assign limb_157_1050 = limb_157_1049[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1051 = limb_157_1049[32]; // decl: <none>; prim: <none>
    assign limb_157_1052 = tmp_workload_top_int_513__325_v0[287:256]; // decl: <none>; prim: <none>
    assign limb_157_1053 = tmp_workload_top_int_513__327_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1054Core rtlzz_owner_1054(.a(32'(limb_157_1052)), .b(32'(rtlzz_pipe_1053_s7)), .cin(limb_157_1051), .value(limb_157_1054));
    assign limb_157_1055 = limb_157_1054[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1056 = limb_157_1054[32]; // decl: <none>; prim: <none>
    assign limb_157_1057 = tmp_workload_top_int_513__325_v0[319:288]; // decl: <none>; prim: <none>
    assign limb_157_1058 = tmp_workload_top_int_513__327_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1059Core rtlzz_owner_1059(.a(32'(limb_157_1057)), .b(32'(rtlzz_pipe_1058_s7)), .cin(limb_157_1056), .value(limb_157_1059));
    assign limb_157_1060 = limb_157_1059[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1061 = limb_157_1059[32]; // decl: <none>; prim: <none>
    assign limb_157_1062 = tmp_workload_top_int_513__325_v0[351:320]; // decl: <none>; prim: <none>
    assign limb_157_1063 = tmp_workload_top_int_513__327_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1064Core rtlzz_owner_1064(.a(32'(limb_157_1062)), .b(32'(rtlzz_pipe_1063_s7)), .cin(limb_157_1061), .value(limb_157_1064));
    assign limb_157_1065 = limb_157_1064[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1066 = limb_157_1064[32]; // decl: <none>; prim: <none>
    assign limb_157_1067 = tmp_workload_top_int_513__325_v0[383:352]; // decl: <none>; prim: <none>
    assign limb_157_1068 = tmp_workload_top_int_513__327_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1069Core rtlzz_owner_1069(.a(32'(limb_157_1067)), .b(32'(rtlzz_pipe_1068_s7)), .cin(limb_157_1066), .value(limb_157_1069));
    assign limb_157_1070 = limb_157_1069[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1071 = limb_157_1069[32]; // decl: <none>; prim: <none>
    assign limb_157_1072 = tmp_workload_top_int_513__325_v0[415:384]; // decl: <none>; prim: <none>
    assign limb_157_1073 = tmp_workload_top_int_513__327_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1074Core rtlzz_owner_1074(.a(32'(limb_157_1072)), .b(32'(rtlzz_pipe_1073_s7)), .cin(limb_157_1071), .value(limb_157_1074));
    assign limb_157_1075 = limb_157_1074[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1076 = limb_157_1074[32]; // decl: <none>; prim: <none>
    assign limb_157_1077 = tmp_workload_top_int_513__325_v0[447:416]; // decl: <none>; prim: <none>
    assign limb_157_1078 = tmp_workload_top_int_513__327_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1079Core rtlzz_owner_1079(.a(32'(limb_157_1077)), .b(32'(rtlzz_pipe_1078_s7)), .cin(limb_157_1076), .value(limb_157_1079));
    assign limb_157_1080 = limb_157_1079[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1081 = limb_157_1079[32]; // decl: <none>; prim: <none>
    assign limb_157_1082 = tmp_workload_top_int_513__325_v0[479:448]; // decl: <none>; prim: <none>
    assign limb_157_1083 = tmp_workload_top_int_513__327_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1084Core rtlzz_owner_1084(.a(32'(limb_157_1082)), .b(32'(rtlzz_pipe_1083_s7)), .cin(limb_157_1081), .value(limb_157_1084));
    assign limb_157_1085 = limb_157_1084[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1086 = limb_157_1084[32]; // decl: <none>; prim: <none>
    assign limb_157_1087 = tmp_workload_top_int_513__325_v0[511:480]; // decl: <none>; prim: <none>
    assign limb_157_1088 = tmp_workload_top_int_513__327_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1089Core rtlzz_owner_1089(.a(32'(limb_157_1087)), .b(32'(rtlzz_pipe_1088_s7)), .cin(limb_157_1086), .value(limb_157_1089));
    assign limb_157_1090 = limb_157_1089[31:0]; // decl: <none>; prim: <none>
    assign limb_157_1091 = limb_157_1089[32]; // decl: <none>; prim: <none>
    assign limb_157_1092 = tmp_workload_top_int_513__325_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_1093 = tmp_workload_top_int_513__327_v0[512]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1094Core rtlzz_owner_1094(.a(1'(limb_157_1092)), .b(1'(rtlzz_pipe_1093_s7)), .cin(limb_157_1091), .value(limb_157_1094[0:0]));
    assign limb_157_1094[1:1] = '0;
    assign limb_157_1095 = limb_157_1094[0]; // decl: <none>; prim: <none>
    assign limb_157_1096 = {limb_157_1095, limb_157_1090, limb_157_1085, limb_157_1080, limb_157_1075, limb_157_1070, limb_157_1065, limb_157_1060, limb_157_1055, limb_157_1050, limb_157_1045, limb_157_1040, limb_157_1035, limb_157_1030, limb_157_1025, limb_157_1020, limb_157_1015}; // decl: <none>; prim: <none>
    assign limb_216_1097 = tmp_workload_top_int_512__315_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1098 = s8_norm_shift_234_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1099Core rtlzz_owner_1099(.a(32'(limb_216_1097)), .b(32'(limb_216_1098)), .cin(1'h0), .value(limb_216_1099));
    assign limb_216_1100 = limb_216_1099[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1101 = limb_216_1099[32]; // decl: <none>; prim: <none>
    assign limb_216_1102 = tmp_workload_top_int_512__315_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_216_1103 = s8_norm_shift_234_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1104Core rtlzz_owner_1104(.a(32'(limb_216_1102)), .b(32'(limb_216_1103)), .cin(limb_216_1101), .value(limb_216_1104));
    assign limb_216_1105 = limb_216_1104[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1106 = limb_216_1104[32]; // decl: <none>; prim: <none>
    assign limb_216_1107 = tmp_workload_top_int_512__315_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_216_1108 = s8_norm_shift_234_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1109Core rtlzz_owner_1109(.a(32'(limb_216_1107)), .b(32'(limb_216_1108)), .cin(limb_216_1106), .value(limb_216_1109));
    assign limb_216_1110 = limb_216_1109[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1111 = limb_216_1109[32]; // decl: <none>; prim: <none>
    assign limb_216_1112 = tmp_workload_top_int_512__315_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_216_1113 = s8_norm_shift_234_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1114Core rtlzz_owner_1114(.a(32'(limb_216_1112)), .b(32'(limb_216_1113)), .cin(limb_216_1111), .value(limb_216_1114));
    assign limb_216_1115 = limb_216_1114[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1116 = limb_216_1114[32]; // decl: <none>; prim: <none>
    assign limb_216_1117 = tmp_workload_top_int_512__315_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_216_1118 = s8_norm_shift_234_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1119Core rtlzz_owner_1119(.a(32'(limb_216_1117)), .b(32'(limb_216_1118)), .cin(limb_216_1116), .value(limb_216_1119));
    assign limb_216_1120 = limb_216_1119[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1121 = limb_216_1119[32]; // decl: <none>; prim: <none>
    assign limb_216_1122 = tmp_workload_top_int_512__315_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_216_1123 = s8_norm_shift_234_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1124Core rtlzz_owner_1124(.a(32'(limb_216_1122)), .b(32'(limb_216_1123)), .cin(limb_216_1121), .value(limb_216_1124));
    assign limb_216_1125 = limb_216_1124[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1126 = limb_216_1124[32]; // decl: <none>; prim: <none>
    assign limb_216_1127 = tmp_workload_top_int_512__315_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_216_1128 = s8_norm_shift_234_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1129Core rtlzz_owner_1129(.a(32'(limb_216_1127)), .b(32'(limb_216_1128)), .cin(limb_216_1126), .value(limb_216_1129));
    assign limb_216_1130 = limb_216_1129[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1131 = limb_216_1129[32]; // decl: <none>; prim: <none>
    assign limb_216_1132 = tmp_workload_top_int_512__315_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_216_1133 = s8_norm_shift_234_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1134Core rtlzz_owner_1134(.a(32'(limb_216_1132)), .b(32'(limb_216_1133)), .cin(limb_216_1131), .value(limb_216_1134));
    assign limb_216_1135 = limb_216_1134[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1136 = limb_216_1134[32]; // decl: <none>; prim: <none>
    assign limb_216_1137 = tmp_workload_top_int_512__315_v0[287:256]; // decl: <none>; prim: <none>
    assign limb_216_1138 = s8_norm_shift_234_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1139Core rtlzz_owner_1139(.a(32'(limb_216_1137)), .b(32'(limb_216_1138)), .cin(limb_216_1136), .value(limb_216_1139));
    assign limb_216_1140 = limb_216_1139[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1141 = limb_216_1139[32]; // decl: <none>; prim: <none>
    assign limb_216_1142 = tmp_workload_top_int_512__315_v0[319:288]; // decl: <none>; prim: <none>
    assign limb_216_1143 = s8_norm_shift_234_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1144Core rtlzz_owner_1144(.a(32'(limb_216_1142)), .b(32'(limb_216_1143)), .cin(limb_216_1141), .value(limb_216_1144));
    assign limb_216_1145 = limb_216_1144[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1146 = limb_216_1144[32]; // decl: <none>; prim: <none>
    assign limb_216_1147 = tmp_workload_top_int_512__315_v0[351:320]; // decl: <none>; prim: <none>
    assign limb_216_1148 = s8_norm_shift_234_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1149Core rtlzz_owner_1149(.a(32'(limb_216_1147)), .b(32'(limb_216_1148)), .cin(limb_216_1146), .value(limb_216_1149));
    assign limb_216_1150 = limb_216_1149[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1151 = limb_216_1149[32]; // decl: <none>; prim: <none>
    assign limb_216_1152 = tmp_workload_top_int_512__315_v0[383:352]; // decl: <none>; prim: <none>
    assign limb_216_1153 = s8_norm_shift_234_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1154Core rtlzz_owner_1154(.a(32'(limb_216_1152)), .b(32'(limb_216_1153)), .cin(limb_216_1151), .value(limb_216_1154));
    assign limb_216_1155 = limb_216_1154[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1156 = limb_216_1154[32]; // decl: <none>; prim: <none>
    assign limb_216_1157 = tmp_workload_top_int_512__315_v0[415:384]; // decl: <none>; prim: <none>
    assign limb_216_1158 = s8_norm_shift_234_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1159Core rtlzz_owner_1159(.a(32'(limb_216_1157)), .b(32'(limb_216_1158)), .cin(limb_216_1156), .value(limb_216_1159));
    assign limb_216_1160 = limb_216_1159[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1161 = limb_216_1159[32]; // decl: <none>; prim: <none>
    assign limb_216_1162 = tmp_workload_top_int_512__315_v0[447:416]; // decl: <none>; prim: <none>
    assign limb_216_1163 = s8_norm_shift_234_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1164Core rtlzz_owner_1164(.a(32'(limb_216_1162)), .b(32'(limb_216_1163)), .cin(limb_216_1161), .value(limb_216_1164));
    assign limb_216_1165 = limb_216_1164[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1166 = limb_216_1164[32]; // decl: <none>; prim: <none>
    assign limb_216_1167 = tmp_workload_top_int_512__315_v0[479:448]; // decl: <none>; prim: <none>
    assign limb_216_1168 = s8_norm_shift_234_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1169Core rtlzz_owner_1169(.a(32'(limb_216_1167)), .b(32'(limb_216_1168)), .cin(limb_216_1166), .value(limb_216_1169));
    assign limb_216_1170 = limb_216_1169[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1171 = limb_216_1169[32]; // decl: <none>; prim: <none>
    assign limb_216_1172 = tmp_workload_top_int_512__315_v0[511:480]; // decl: <none>; prim: <none>
    assign limb_216_1173 = s8_norm_shift_234_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1174Core rtlzz_owner_1174(.a(32'(limb_216_1172)), .b(32'(limb_216_1173)), .cin(limb_216_1171), .value(limb_216_1174[31:0]));
    assign limb_216_1174[32:32] = '0;
    assign limb_216_1175 = limb_216_1174[31:0]; // decl: <none>; prim: <none>
    assign limb_216_1176 = {limb_216_1175, limb_216_1170, limb_216_1165, limb_216_1160, limb_216_1155, limb_216_1150, limb_216_1145, limb_216_1140, limb_216_1135, limb_216_1130, limb_216_1125, limb_216_1120, limb_216_1115, limb_216_1110, limb_216_1105, limb_216_1100}; // decl: <none>; prim: <none>
    assign limb_217_1177 = __beopt_width_292[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1178 = s8_norm_shift_231_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1179Core rtlzz_owner_1179(.a(32'(limb_217_1177)), .b(32'(limb_217_1178)), .cin(1'h0), .value(limb_217_1179));
    assign limb_217_1180 = limb_217_1179[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1181 = limb_217_1179[32]; // decl: <none>; prim: <none>
    assign limb_217_1182 = __beopt_width_292[63:32]; // decl: <none>; prim: <none>
    assign limb_217_1183 = s8_norm_shift_231_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1184Core rtlzz_owner_1184(.a(32'(limb_217_1182)), .b(32'(limb_217_1183)), .cin(limb_217_1181), .value(limb_217_1184));
    assign limb_217_1185 = limb_217_1184[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1186 = limb_217_1184[32]; // decl: <none>; prim: <none>
    assign limb_217_1187 = __beopt_width_292[95:64]; // decl: <none>; prim: <none>
    assign limb_217_1188 = s8_norm_shift_231_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1189Core rtlzz_owner_1189(.a(32'(limb_217_1187)), .b(32'(limb_217_1188)), .cin(limb_217_1186), .value(limb_217_1189));
    assign limb_217_1190 = limb_217_1189[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1191 = limb_217_1189[32]; // decl: <none>; prim: <none>
    assign limb_217_1192 = __beopt_width_292[127:96]; // decl: <none>; prim: <none>
    assign limb_217_1193 = s8_norm_shift_231_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1194Core rtlzz_owner_1194(.a(32'(limb_217_1192)), .b(32'(limb_217_1193)), .cin(limb_217_1191), .value(limb_217_1194));
    assign limb_217_1195 = limb_217_1194[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1196 = limb_217_1194[32]; // decl: <none>; prim: <none>
    assign limb_217_1197 = __beopt_width_292[159:128]; // decl: <none>; prim: <none>
    assign limb_217_1198 = s8_norm_shift_231_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1199Core rtlzz_owner_1199(.a(32'(limb_217_1197)), .b(32'(limb_217_1198)), .cin(limb_217_1196), .value(limb_217_1199));
    assign limb_217_1200 = limb_217_1199[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1201 = limb_217_1199[32]; // decl: <none>; prim: <none>
    assign limb_217_1202 = __beopt_width_292[191:160]; // decl: <none>; prim: <none>
    assign limb_217_1203 = s8_norm_shift_231_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1204Core rtlzz_owner_1204(.a(32'(limb_217_1202)), .b(32'(limb_217_1203)), .cin(limb_217_1201), .value(limb_217_1204));
    assign limb_217_1205 = limb_217_1204[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1206 = limb_217_1204[32]; // decl: <none>; prim: <none>
    assign limb_217_1207 = __beopt_width_292[223:192]; // decl: <none>; prim: <none>
    assign limb_217_1208 = s8_norm_shift_231_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1209Core rtlzz_owner_1209(.a(32'(limb_217_1207)), .b(32'(limb_217_1208)), .cin(limb_217_1206), .value(limb_217_1209));
    assign limb_217_1210 = limb_217_1209[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1211 = limb_217_1209[32]; // decl: <none>; prim: <none>
    assign limb_217_1212 = __beopt_width_292[255:224]; // decl: <none>; prim: <none>
    assign limb_217_1213 = s8_norm_shift_231_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1214Core rtlzz_owner_1214(.a(32'(limb_217_1212)), .b(32'(limb_217_1213)), .cin(limb_217_1211), .value(limb_217_1214));
    assign limb_217_1215 = limb_217_1214[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1216 = limb_217_1214[32]; // decl: <none>; prim: <none>
    assign limb_217_1217 = __beopt_width_292[287:256]; // decl: <none>; prim: <none>
    assign limb_217_1218 = s8_norm_shift_231_v0[287:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1219Core rtlzz_owner_1219(.a(32'(limb_217_1217)), .b(32'(limb_217_1218)), .cin(limb_217_1216), .value(limb_217_1219));
    assign limb_217_1220 = limb_217_1219[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1221 = limb_217_1219[32]; // decl: <none>; prim: <none>
    assign limb_217_1222 = __beopt_width_292[319:288]; // decl: <none>; prim: <none>
    assign limb_217_1223 = s8_norm_shift_231_v0[319:288]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1224Core rtlzz_owner_1224(.a(32'(limb_217_1222)), .b(32'(limb_217_1223)), .cin(limb_217_1221), .value(limb_217_1224));
    assign limb_217_1225 = limb_217_1224[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1226 = limb_217_1224[32]; // decl: <none>; prim: <none>
    assign limb_217_1227 = __beopt_width_292[351:320]; // decl: <none>; prim: <none>
    assign limb_217_1228 = s8_norm_shift_231_v0[351:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1229Core rtlzz_owner_1229(.a(32'(limb_217_1227)), .b(32'(limb_217_1228)), .cin(limb_217_1226), .value(limb_217_1229));
    assign limb_217_1230 = limb_217_1229[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1231 = limb_217_1229[32]; // decl: <none>; prim: <none>
    assign limb_217_1232 = __beopt_width_292[383:352]; // decl: <none>; prim: <none>
    assign limb_217_1233 = s8_norm_shift_231_v0[383:352]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1234Core rtlzz_owner_1234(.a(32'(limb_217_1232)), .b(32'(limb_217_1233)), .cin(limb_217_1231), .value(limb_217_1234));
    assign limb_217_1235 = limb_217_1234[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1236 = limb_217_1234[32]; // decl: <none>; prim: <none>
    assign limb_217_1237 = __beopt_width_292[415:384]; // decl: <none>; prim: <none>
    assign limb_217_1238 = s8_norm_shift_231_v0[415:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1239Core rtlzz_owner_1239(.a(32'(limb_217_1237)), .b(32'(limb_217_1238)), .cin(limb_217_1236), .value(limb_217_1239));
    assign limb_217_1240 = limb_217_1239[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1241 = limb_217_1239[32]; // decl: <none>; prim: <none>
    assign limb_217_1242 = __beopt_width_292[447:416]; // decl: <none>; prim: <none>
    assign limb_217_1243 = s8_norm_shift_231_v0[447:416]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1244Core rtlzz_owner_1244(.a(32'(limb_217_1242)), .b(32'(limb_217_1243)), .cin(limb_217_1241), .value(limb_217_1244));
    assign limb_217_1245 = limb_217_1244[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1246 = limb_217_1244[32]; // decl: <none>; prim: <none>
    assign limb_217_1247 = __beopt_width_292[479:448]; // decl: <none>; prim: <none>
    assign limb_217_1248 = s8_norm_shift_231_v0[479:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1249Core rtlzz_owner_1249(.a(32'(limb_217_1247)), .b(32'(limb_217_1248)), .cin(limb_217_1246), .value(limb_217_1249));
    assign limb_217_1250 = limb_217_1249[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1251 = limb_217_1249[32]; // decl: <none>; prim: <none>
    assign limb_217_1252 = __beopt_width_292[511:480]; // decl: <none>; prim: <none>
    assign limb_217_1253 = s8_norm_shift_231_v0[511:480]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1254Core rtlzz_owner_1254(.a(32'(limb_217_1252)), .b(32'(limb_217_1253)), .cin(limb_217_1251), .value(limb_217_1254[31:0]));
    assign limb_217_1254[32:32] = '0;
    assign limb_217_1255 = limb_217_1254[31:0]; // decl: <none>; prim: <none>
    assign limb_217_1256 = {limb_217_1255, limb_217_1250, limb_217_1245, limb_217_1240, limb_217_1235, limb_217_1230, limb_217_1225, limb_217_1220, limb_217_1215, limb_217_1210, limb_217_1205, limb_217_1200, limb_217_1195, limb_217_1190, limb_217_1185, limb_217_1180}; // decl: <none>; prim: <none>
    assign limb_218_1257 = s8_norm_shift_223_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1258 = tmp_workload_top_int_258__299_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1259Core rtlzz_owner_1259(.a(32'(rtlzz_pipe_1257_s5)), .b(32'(limb_218_1258)), .cin(1'h0), .value(limb_218_1259));
    assign limb_218_1260 = limb_218_1259[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1261 = limb_218_1259[32]; // decl: <none>; prim: <none>
    assign limb_218_1262 = s8_norm_shift_223_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_218_1263 = tmp_workload_top_int_258__299_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1264Core rtlzz_owner_1264(.a(32'(rtlzz_pipe_1262_s5)), .b(32'(limb_218_1263)), .cin(limb_218_1261), .value(limb_218_1264));
    assign limb_218_1265 = limb_218_1264[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1266 = limb_218_1264[32]; // decl: <none>; prim: <none>
    assign limb_218_1267 = s8_norm_shift_223_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_218_1268 = tmp_workload_top_int_258__299_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1269Core rtlzz_owner_1269(.a(32'(rtlzz_pipe_1267_s5)), .b(32'(limb_218_1268)), .cin(limb_218_1266), .value(limb_218_1269));
    assign limb_218_1270 = limb_218_1269[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1271 = limb_218_1269[32]; // decl: <none>; prim: <none>
    assign limb_218_1272 = s8_norm_shift_223_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_218_1273 = tmp_workload_top_int_258__299_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1274Core rtlzz_owner_1274(.a(32'(rtlzz_pipe_1272_s5)), .b(32'(limb_218_1273)), .cin(limb_218_1271), .value(limb_218_1274));
    assign limb_218_1275 = limb_218_1274[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1276 = limb_218_1274[32]; // decl: <none>; prim: <none>
    assign limb_218_1277 = s8_norm_shift_223_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_218_1278 = tmp_workload_top_int_258__299_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1279Core rtlzz_owner_1279(.a(32'(rtlzz_pipe_1277_s5)), .b(32'(limb_218_1278)), .cin(limb_218_1276), .value(limb_218_1279));
    assign limb_218_1280 = limb_218_1279[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1281 = limb_218_1279[32]; // decl: <none>; prim: <none>
    assign limb_218_1282 = s8_norm_shift_223_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_218_1283 = tmp_workload_top_int_258__299_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1284Core rtlzz_owner_1284(.a(32'(rtlzz_pipe_1282_s5)), .b(32'(limb_218_1283)), .cin(limb_218_1281), .value(limb_218_1284));
    assign limb_218_1285 = limb_218_1284[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1286 = limb_218_1284[32]; // decl: <none>; prim: <none>
    assign limb_218_1287 = s8_norm_shift_223_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_218_1288 = tmp_workload_top_int_258__299_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1289Core rtlzz_owner_1289(.a(32'(rtlzz_pipe_1287_s5)), .b(32'(limb_218_1288)), .cin(limb_218_1286), .value(limb_218_1289));
    assign limb_218_1290 = limb_218_1289[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1291 = limb_218_1289[32]; // decl: <none>; prim: <none>
    assign limb_218_1292 = s8_norm_shift_223_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_218_1293 = tmp_workload_top_int_258__299_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1294Core rtlzz_owner_1294(.a(32'(rtlzz_pipe_1292_s5)), .b(32'(limb_218_1293)), .cin(limb_218_1291), .value(limb_218_1294));
    assign limb_218_1295 = limb_218_1294[31:0]; // decl: <none>; prim: <none>
    assign limb_218_1296 = limb_218_1294[32]; // decl: <none>; prim: <none>
    assign limb_218_1297 = s8_norm_shift_223_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_1298 = tmp_workload_top_int_258__299_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1299Core rtlzz_owner_1299(.a(2'(rtlzz_pipe_1297_s5)), .b(2'(limb_218_1298)), .cin(limb_218_1296), .value(limb_218_1299[1:0]));
    assign limb_218_1299[2:2] = '0;
    assign limb_218_1300 = limb_218_1299[1:0]; // decl: <none>; prim: <none>
    assign limb_218_1301 = {limb_218_1300, limb_218_1295, limb_218_1290, limb_218_1285, limb_218_1280, limb_218_1275, limb_218_1270, limb_218_1265, limb_218_1260}; // decl: <none>; prim: <none>
    assign limb_219_1302 = __beopt_width_295[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1303 = s8_norm_shift_220_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1304Core rtlzz_owner_1304(.a(32'(rtlzz_pipe_1302_s6)), .b(32'(limb_219_1303)), .cin(1'h0), .value(limb_219_1304));
    assign limb_219_1305 = limb_219_1304[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1306 = limb_219_1304[32]; // decl: <none>; prim: <none>
    assign limb_219_1307 = __beopt_width_295[63:32]; // decl: <none>; prim: <none>
    assign limb_219_1308 = s8_norm_shift_220_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1309Core rtlzz_owner_1309(.a(32'(rtlzz_pipe_1307_s6)), .b(32'(limb_219_1308)), .cin(limb_219_1306), .value(limb_219_1309));
    assign limb_219_1310 = limb_219_1309[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1311 = limb_219_1309[32]; // decl: <none>; prim: <none>
    assign limb_219_1312 = __beopt_width_295[95:64]; // decl: <none>; prim: <none>
    assign limb_219_1313 = s8_norm_shift_220_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1314Core rtlzz_owner_1314(.a(32'(rtlzz_pipe_1312_s6)), .b(32'(limb_219_1313)), .cin(limb_219_1311), .value(limb_219_1314));
    assign limb_219_1315 = limb_219_1314[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1316 = limb_219_1314[32]; // decl: <none>; prim: <none>
    assign limb_219_1317 = __beopt_width_295[127:96]; // decl: <none>; prim: <none>
    assign limb_219_1318 = s8_norm_shift_220_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1319Core rtlzz_owner_1319(.a(32'(rtlzz_pipe_1317_s6)), .b(32'(limb_219_1318)), .cin(limb_219_1316), .value(limb_219_1319));
    assign limb_219_1320 = limb_219_1319[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1321 = limb_219_1319[32]; // decl: <none>; prim: <none>
    assign limb_219_1322 = __beopt_width_295[159:128]; // decl: <none>; prim: <none>
    assign limb_219_1323 = s8_norm_shift_220_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1324Core rtlzz_owner_1324(.a(32'(rtlzz_pipe_1322_s6)), .b(32'(limb_219_1323)), .cin(limb_219_1321), .value(limb_219_1324));
    assign limb_219_1325 = limb_219_1324[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1326 = limb_219_1324[32]; // decl: <none>; prim: <none>
    assign limb_219_1327 = __beopt_width_295[191:160]; // decl: <none>; prim: <none>
    assign limb_219_1328 = s8_norm_shift_220_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1329Core rtlzz_owner_1329(.a(32'(rtlzz_pipe_1327_s6)), .b(32'(limb_219_1328)), .cin(limb_219_1326), .value(limb_219_1329));
    assign limb_219_1330 = limb_219_1329[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1331 = limb_219_1329[32]; // decl: <none>; prim: <none>
    assign limb_219_1332 = __beopt_width_295[223:192]; // decl: <none>; prim: <none>
    assign limb_219_1333 = s8_norm_shift_220_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1334Core rtlzz_owner_1334(.a(32'(rtlzz_pipe_1332_s6)), .b(32'(limb_219_1333)), .cin(limb_219_1331), .value(limb_219_1334));
    assign limb_219_1335 = limb_219_1334[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1336 = limb_219_1334[32]; // decl: <none>; prim: <none>
    assign limb_219_1337 = __beopt_width_295[255:224]; // decl: <none>; prim: <none>
    assign limb_219_1338 = s8_norm_shift_220_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1339Core rtlzz_owner_1339(.a(32'(rtlzz_pipe_1337_s7)), .b(32'(rtlzz_pipe_1338_s7)), .cin(rtlzz_pipe_1336_s7), .value(limb_219_1339));
    assign limb_219_1340 = limb_219_1339[31:0]; // decl: <none>; prim: <none>
    assign limb_219_1341 = limb_219_1339[32]; // decl: <none>; prim: <none>
    assign limb_219_1342 = __beopt_width_295[257:256]; // decl: <none>; prim: <none>
    assign limb_219_1343 = s8_norm_shift_220_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1344Core rtlzz_owner_1344(.a(2'(rtlzz_pipe_1342_s7)), .b(2'(rtlzz_pipe_1343_s7)), .cin(limb_219_1341), .value(limb_219_1344[1:0]));
    assign limb_219_1344[2:2] = '0;
    assign limb_219_1345 = limb_219_1344[1:0]; // decl: <none>; prim: <none>
    assign limb_219_1346 = {limb_219_1345, limb_219_1340, rtlzz_pipe_1335_s7, rtlzz_pipe_1330_s7, rtlzz_pipe_1325_s7, rtlzz_pipe_1320_s7, rtlzz_pipe_1315_s7, rtlzz_pipe_1310_s7, rtlzz_pipe_1305_s7}; // decl: <none>; prim: <none>
    assign limb_220_1347 = tmp_workload_top_int_256__164_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1348 = s8_norm_shift_126_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1349Core rtlzz_owner_1349(.a(32'(rtlzz_pipe_1347_s7)), .b(32'(limb_220_1348)), .cin(1'h0), .value(limb_220_1349));
    assign limb_220_1350 = limb_220_1349[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1351 = limb_220_1349[32]; // decl: <none>; prim: <none>
    assign limb_220_1352 = tmp_workload_top_int_256__164_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_220_1353 = s8_norm_shift_126_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1354Core rtlzz_owner_1354(.a(32'(rtlzz_pipe_1352_s7)), .b(32'(limb_220_1353)), .cin(limb_220_1351), .value(limb_220_1354));
    assign limb_220_1355 = limb_220_1354[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1356 = limb_220_1354[32]; // decl: <none>; prim: <none>
    assign limb_220_1357 = tmp_workload_top_int_256__164_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_220_1358 = s8_norm_shift_126_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1359Core rtlzz_owner_1359(.a(32'(rtlzz_pipe_1357_s7)), .b(32'(limb_220_1358)), .cin(limb_220_1356), .value(limb_220_1359));
    assign limb_220_1360 = limb_220_1359[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1361 = limb_220_1359[32]; // decl: <none>; prim: <none>
    assign limb_220_1362 = tmp_workload_top_int_256__164_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_220_1363 = s8_norm_shift_126_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1364Core rtlzz_owner_1364(.a(32'(rtlzz_pipe_1362_s7)), .b(32'(limb_220_1363)), .cin(limb_220_1361), .value(limb_220_1364));
    assign limb_220_1365 = limb_220_1364[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1366 = limb_220_1364[32]; // decl: <none>; prim: <none>
    assign limb_220_1367 = tmp_workload_top_int_256__164_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_220_1368 = s8_norm_shift_126_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1369Core rtlzz_owner_1369(.a(32'(rtlzz_pipe_1367_s7)), .b(32'(limb_220_1368)), .cin(limb_220_1366), .value(limb_220_1369));
    assign limb_220_1370 = limb_220_1369[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1371 = limb_220_1369[32]; // decl: <none>; prim: <none>
    assign limb_220_1372 = tmp_workload_top_int_256__164_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_220_1373 = s8_norm_shift_126_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1374Core rtlzz_owner_1374(.a(32'(rtlzz_pipe_1372_s7)), .b(32'(limb_220_1373)), .cin(limb_220_1371), .value(limb_220_1374));
    assign limb_220_1375 = limb_220_1374[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1376 = limb_220_1374[32]; // decl: <none>; prim: <none>
    assign limb_220_1377 = tmp_workload_top_int_256__164_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_220_1378 = s8_norm_shift_126_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1379Core rtlzz_owner_1379(.a(32'(rtlzz_pipe_1377_s7)), .b(32'(limb_220_1378)), .cin(limb_220_1376), .value(limb_220_1379));
    assign limb_220_1380 = limb_220_1379[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1381 = limb_220_1379[32]; // decl: <none>; prim: <none>
    assign limb_220_1382 = tmp_workload_top_int_256__164_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_220_1383 = s8_norm_shift_126_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1384Core rtlzz_owner_1384(.a(32'(rtlzz_pipe_1382_s7)), .b(32'(limb_220_1383)), .cin(limb_220_1381), .value(limb_220_1384[31:0]));
    assign limb_220_1384[32:32] = '0;
    assign limb_220_1385 = limb_220_1384[31:0]; // decl: <none>; prim: <none>
    assign limb_220_1386 = {limb_220_1385, limb_220_1380, limb_220_1375, limb_220_1370, limb_220_1365, limb_220_1360, limb_220_1355, limb_220_1350}; // decl: <none>; prim: <none>
    assign limb_221_1387 = __beopt_width_299[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1388 = s8_norm_shift_123_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1389Core rtlzz_owner_1389(.a(32'(limb_221_1387)), .b(32'(limb_221_1388)), .cin(1'h0), .value(limb_221_1389));
    assign limb_221_1390 = limb_221_1389[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1391 = limb_221_1389[32]; // decl: <none>; prim: <none>
    assign limb_221_1392 = __beopt_width_299[63:32]; // decl: <none>; prim: <none>
    assign limb_221_1393 = s8_norm_shift_123_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1394Core rtlzz_owner_1394(.a(32'(limb_221_1392)), .b(32'(limb_221_1393)), .cin(limb_221_1391), .value(limb_221_1394));
    assign limb_221_1395 = limb_221_1394[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1396 = limb_221_1394[32]; // decl: <none>; prim: <none>
    assign limb_221_1397 = __beopt_width_299[95:64]; // decl: <none>; prim: <none>
    assign limb_221_1398 = s8_norm_shift_123_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1399Core rtlzz_owner_1399(.a(32'(limb_221_1397)), .b(32'(limb_221_1398)), .cin(limb_221_1396), .value(limb_221_1399));
    assign limb_221_1400 = limb_221_1399[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1401 = limb_221_1399[32]; // decl: <none>; prim: <none>
    assign limb_221_1402 = __beopt_width_299[127:96]; // decl: <none>; prim: <none>
    assign limb_221_1403 = s8_norm_shift_123_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1404Core rtlzz_owner_1404(.a(32'(limb_221_1402)), .b(32'(limb_221_1403)), .cin(limb_221_1401), .value(limb_221_1404));
    assign limb_221_1405 = limb_221_1404[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1406 = limb_221_1404[32]; // decl: <none>; prim: <none>
    assign limb_221_1407 = __beopt_width_299[159:128]; // decl: <none>; prim: <none>
    assign limb_221_1408 = s8_norm_shift_123_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1409Core rtlzz_owner_1409(.a(32'(limb_221_1407)), .b(32'(limb_221_1408)), .cin(limb_221_1406), .value(limb_221_1409));
    assign limb_221_1410 = limb_221_1409[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1411 = limb_221_1409[32]; // decl: <none>; prim: <none>
    assign limb_221_1412 = __beopt_width_299[191:160]; // decl: <none>; prim: <none>
    assign limb_221_1413 = s8_norm_shift_123_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1414Core rtlzz_owner_1414(.a(32'(limb_221_1412)), .b(32'(limb_221_1413)), .cin(limb_221_1411), .value(limb_221_1414));
    assign limb_221_1415 = limb_221_1414[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1416 = limb_221_1414[32]; // decl: <none>; prim: <none>
    assign limb_221_1417 = __beopt_width_299[223:192]; // decl: <none>; prim: <none>
    assign limb_221_1418 = s8_norm_shift_123_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1419Core rtlzz_owner_1419(.a(32'(limb_221_1417)), .b(32'(limb_221_1418)), .cin(limb_221_1416), .value(limb_221_1419));
    assign limb_221_1420 = limb_221_1419[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1421 = limb_221_1419[32]; // decl: <none>; prim: <none>
    assign limb_221_1422 = __beopt_width_299[255:224]; // decl: <none>; prim: <none>
    assign limb_221_1423 = s8_norm_shift_123_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1424Core rtlzz_owner_1424(.a(32'(limb_221_1422)), .b(32'(limb_221_1423)), .cin(limb_221_1421), .value(limb_221_1424[31:0]));
    assign limb_221_1424[32:32] = '0;
    assign limb_221_1425 = limb_221_1424[31:0]; // decl: <none>; prim: <none>
    assign limb_221_1426 = {limb_221_1425, limb_221_1420, limb_221_1415, limb_221_1410, limb_221_1405, limb_221_1400, limb_221_1395, limb_221_1390}; // decl: <none>; prim: <none>
    assign limb_222_1427 = tmp_workload_top_int_256__79_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1428 = s8_norm_shift_64_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1429Core rtlzz_owner_1429(.a(32'(limb_222_1427)), .b(32'(limb_222_1428)), .cin(1'h0), .value(limb_222_1429));
    assign limb_222_1430 = limb_222_1429[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1431 = limb_222_1429[32]; // decl: <none>; prim: <none>
    assign limb_222_1432 = tmp_workload_top_int_256__79_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_222_1433 = s8_norm_shift_64_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1434Core rtlzz_owner_1434(.a(32'(limb_222_1432)), .b(32'(limb_222_1433)), .cin(limb_222_1431), .value(limb_222_1434));
    assign limb_222_1435 = limb_222_1434[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1436 = limb_222_1434[32]; // decl: <none>; prim: <none>
    assign limb_222_1437 = tmp_workload_top_int_256__79_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_222_1438 = s8_norm_shift_64_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1439Core rtlzz_owner_1439(.a(32'(limb_222_1437)), .b(32'(limb_222_1438)), .cin(limb_222_1436), .value(limb_222_1439));
    assign limb_222_1440 = limb_222_1439[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1441 = limb_222_1439[32]; // decl: <none>; prim: <none>
    assign limb_222_1442 = tmp_workload_top_int_256__79_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_222_1443 = s8_norm_shift_64_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1444Core rtlzz_owner_1444(.a(32'(limb_222_1442)), .b(32'(limb_222_1443)), .cin(limb_222_1441), .value(limb_222_1444));
    assign limb_222_1445 = limb_222_1444[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1446 = limb_222_1444[32]; // decl: <none>; prim: <none>
    assign limb_222_1447 = tmp_workload_top_int_256__79_v0[159:128]; // decl: <none>; prim: <none>
    assign limb_222_1448 = s8_norm_shift_64_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1449Core rtlzz_owner_1449(.a(32'(limb_222_1447)), .b(32'(limb_222_1448)), .cin(limb_222_1446), .value(limb_222_1449));
    assign limb_222_1450 = limb_222_1449[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1451 = limb_222_1449[32]; // decl: <none>; prim: <none>
    assign limb_222_1452 = tmp_workload_top_int_256__79_v0[191:160]; // decl: <none>; prim: <none>
    assign limb_222_1453 = s8_norm_shift_64_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1454Core rtlzz_owner_1454(.a(32'(limb_222_1452)), .b(32'(limb_222_1453)), .cin(limb_222_1451), .value(limb_222_1454));
    assign limb_222_1455 = limb_222_1454[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1456 = limb_222_1454[32]; // decl: <none>; prim: <none>
    assign limb_222_1457 = tmp_workload_top_int_256__79_v0[223:192]; // decl: <none>; prim: <none>
    assign limb_222_1458 = s8_norm_shift_64_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1459Core rtlzz_owner_1459(.a(32'(limb_222_1457)), .b(32'(limb_222_1458)), .cin(limb_222_1456), .value(limb_222_1459));
    assign limb_222_1460 = limb_222_1459[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1461 = limb_222_1459[32]; // decl: <none>; prim: <none>
    assign limb_222_1462 = tmp_workload_top_int_256__79_v0[255:224]; // decl: <none>; prim: <none>
    assign limb_222_1463 = s8_norm_shift_64_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1464Core rtlzz_owner_1464(.a(32'(limb_222_1462)), .b(32'(limb_222_1463)), .cin(limb_222_1461), .value(limb_222_1464[31:0]));
    assign limb_222_1464[32:32] = '0;
    assign limb_222_1465 = limb_222_1464[31:0]; // decl: <none>; prim: <none>
    assign limb_222_1466 = {limb_222_1465, limb_222_1460, limb_222_1455, limb_222_1450, limb_222_1445, limb_222_1440, limb_222_1435, limb_222_1430}; // decl: <none>; prim: <none>
    assign limb_223_1467 = __beopt_width_302[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1468 = s8_norm_shift_61_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1469Core rtlzz_owner_1469(.a(32'(limb_223_1467)), .b(32'(limb_223_1468)), .cin(1'h0), .value(limb_223_1469));
    assign limb_223_1470 = limb_223_1469[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1471 = limb_223_1469[32]; // decl: <none>; prim: <none>
    assign limb_223_1472 = __beopt_width_302[63:32]; // decl: <none>; prim: <none>
    assign limb_223_1473 = s8_norm_shift_61_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1474Core rtlzz_owner_1474(.a(32'(limb_223_1472)), .b(32'(limb_223_1473)), .cin(limb_223_1471), .value(limb_223_1474));
    assign limb_223_1475 = limb_223_1474[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1476 = limb_223_1474[32]; // decl: <none>; prim: <none>
    assign limb_223_1477 = __beopt_width_302[95:64]; // decl: <none>; prim: <none>
    assign limb_223_1478 = s8_norm_shift_61_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1479Core rtlzz_owner_1479(.a(32'(limb_223_1477)), .b(32'(limb_223_1478)), .cin(limb_223_1476), .value(limb_223_1479));
    assign limb_223_1480 = limb_223_1479[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1481 = limb_223_1479[32]; // decl: <none>; prim: <none>
    assign limb_223_1482 = __beopt_width_302[127:96]; // decl: <none>; prim: <none>
    assign limb_223_1483 = s8_norm_shift_61_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1484Core rtlzz_owner_1484(.a(32'(limb_223_1482)), .b(32'(limb_223_1483)), .cin(limb_223_1481), .value(limb_223_1484));
    assign limb_223_1485 = limb_223_1484[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1486 = limb_223_1484[32]; // decl: <none>; prim: <none>
    assign limb_223_1487 = __beopt_width_302[159:128]; // decl: <none>; prim: <none>
    assign limb_223_1488 = s8_norm_shift_61_v0[159:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1489Core rtlzz_owner_1489(.a(32'(limb_223_1487)), .b(32'(limb_223_1488)), .cin(limb_223_1486), .value(limb_223_1489));
    assign limb_223_1490 = limb_223_1489[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1491 = limb_223_1489[32]; // decl: <none>; prim: <none>
    assign limb_223_1492 = __beopt_width_302[191:160]; // decl: <none>; prim: <none>
    assign limb_223_1493 = s8_norm_shift_61_v0[191:160]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1494Core rtlzz_owner_1494(.a(32'(limb_223_1492)), .b(32'(limb_223_1493)), .cin(limb_223_1491), .value(limb_223_1494));
    assign limb_223_1495 = limb_223_1494[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1496 = limb_223_1494[32]; // decl: <none>; prim: <none>
    assign limb_223_1497 = __beopt_width_302[223:192]; // decl: <none>; prim: <none>
    assign limb_223_1498 = s8_norm_shift_61_v0[223:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1499Core rtlzz_owner_1499(.a(32'(limb_223_1497)), .b(32'(limb_223_1498)), .cin(limb_223_1496), .value(limb_223_1499));
    assign limb_223_1500 = limb_223_1499[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1501 = limb_223_1499[32]; // decl: <none>; prim: <none>
    assign limb_223_1502 = __beopt_width_302[255:224]; // decl: <none>; prim: <none>
    assign limb_223_1503 = s8_norm_shift_61_v0[255:224]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1504Core rtlzz_owner_1504(.a(32'(limb_223_1502)), .b(32'(limb_223_1503)), .cin(limb_223_1501), .value(limb_223_1504[31:0]));
    assign limb_223_1504[32:32] = '0;
    assign limb_223_1505 = limb_223_1504[31:0]; // decl: <none>; prim: <none>
    assign limb_223_1506 = {limb_223_1505, limb_223_1500, limb_223_1495, limb_223_1490, limb_223_1485, limb_223_1480, limb_223_1475, limb_223_1470}; // decl: <none>; prim: <none>
    assign limb_224_1507 = tmp_workload_top_int_132__283_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1508 = s8_norm_shift_212_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1509Core rtlzz_owner_1509(.a(32'(limb_224_1507)), .b(32'(rtlzz_pipe_1508_s6)), .cin(1'h0), .value(limb_224_1509));
    assign limb_224_1510 = limb_224_1509[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1511 = limb_224_1509[32]; // decl: <none>; prim: <none>
    assign limb_224_1512 = tmp_workload_top_int_132__283_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_224_1513 = s8_norm_shift_212_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1514Core rtlzz_owner_1514(.a(32'(limb_224_1512)), .b(32'(rtlzz_pipe_1513_s6)), .cin(limb_224_1511), .value(limb_224_1514));
    assign limb_224_1515 = limb_224_1514[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1516 = limb_224_1514[32]; // decl: <none>; prim: <none>
    assign limb_224_1517 = tmp_workload_top_int_132__283_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_224_1518 = s8_norm_shift_212_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1519Core rtlzz_owner_1519(.a(32'(limb_224_1517)), .b(32'(rtlzz_pipe_1518_s6)), .cin(limb_224_1516), .value(limb_224_1519));
    assign limb_224_1520 = limb_224_1519[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1521 = limb_224_1519[32]; // decl: <none>; prim: <none>
    assign limb_224_1522 = tmp_workload_top_int_132__283_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_224_1523 = s8_norm_shift_212_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1524Core rtlzz_owner_1524(.a(32'(limb_224_1522)), .b(32'(rtlzz_pipe_1523_s6)), .cin(limb_224_1521), .value(limb_224_1524));
    assign limb_224_1525 = limb_224_1524[31:0]; // decl: <none>; prim: <none>
    assign limb_224_1526 = limb_224_1524[32]; // decl: <none>; prim: <none>
    assign limb_224_1527 = tmp_workload_top_int_132__283_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_1528 = s8_norm_shift_212_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1529Core rtlzz_owner_1529(.a(4'(limb_224_1527)), .b(4'(rtlzz_pipe_1528_s6)), .cin(limb_224_1526), .value(limb_224_1529[3:0]));
    assign limb_224_1529[4:4] = '0;
    assign limb_224_1530 = limb_224_1529[3:0]; // decl: <none>; prim: <none>
    assign limb_224_1531 = {limb_224_1530, limb_224_1525, limb_224_1520, limb_224_1515, limb_224_1510}; // decl: <none>; prim: <none>
    assign limb_225_1532 = __beopt_width_305[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1533 = s8_norm_shift_209_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1534Core rtlzz_owner_1534(.a(32'(limb_225_1532)), .b(32'(limb_225_1533)), .cin(1'h0), .value(limb_225_1534));
    assign limb_225_1535 = limb_225_1534[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1536 = limb_225_1534[32]; // decl: <none>; prim: <none>
    assign limb_225_1537 = __beopt_width_305[63:32]; // decl: <none>; prim: <none>
    assign limb_225_1538 = s8_norm_shift_209_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1539Core rtlzz_owner_1539(.a(32'(limb_225_1537)), .b(32'(limb_225_1538)), .cin(limb_225_1536), .value(limb_225_1539));
    assign limb_225_1540 = limb_225_1539[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1541 = limb_225_1539[32]; // decl: <none>; prim: <none>
    assign limb_225_1542 = __beopt_width_305[95:64]; // decl: <none>; prim: <none>
    assign limb_225_1543 = s8_norm_shift_209_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1544Core rtlzz_owner_1544(.a(32'(limb_225_1542)), .b(32'(limb_225_1543)), .cin(limb_225_1541), .value(limb_225_1544));
    assign limb_225_1545 = limb_225_1544[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1546 = limb_225_1544[32]; // decl: <none>; prim: <none>
    assign limb_225_1547 = __beopt_width_305[127:96]; // decl: <none>; prim: <none>
    assign limb_225_1548 = s8_norm_shift_209_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1549Core rtlzz_owner_1549(.a(32'(limb_225_1547)), .b(32'(limb_225_1548)), .cin(limb_225_1546), .value(limb_225_1549));
    assign limb_225_1550 = limb_225_1549[31:0]; // decl: <none>; prim: <none>
    assign limb_225_1551 = limb_225_1549[32]; // decl: <none>; prim: <none>
    assign limb_225_1552 = __beopt_width_305[131:128]; // decl: <none>; prim: <none>
    assign limb_225_1553 = s8_norm_shift_209_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1554Core rtlzz_owner_1554(.a(4'(limb_225_1552)), .b(4'(limb_225_1553)), .cin(limb_225_1551), .value(limb_225_1554[3:0]));
    assign limb_225_1554[4:4] = '0;
    assign limb_225_1555 = limb_225_1554[3:0]; // decl: <none>; prim: <none>
    assign limb_225_1556 = {limb_225_1555, limb_225_1550, limb_225_1545, limb_225_1540, limb_225_1535}; // decl: <none>; prim: <none>
    assign limb_226_1557 = tmp_workload_top_int_130__223_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1558 = s8_norm_shift_169_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1559Core rtlzz_owner_1559(.a(32'(limb_226_1557)), .b(32'(limb_226_1558)), .cin(1'h0), .value(limb_226_1559));
    assign limb_226_1560 = limb_226_1559[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1561 = limb_226_1559[32]; // decl: <none>; prim: <none>
    assign limb_226_1562 = tmp_workload_top_int_130__223_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_226_1563 = s8_norm_shift_169_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1564Core rtlzz_owner_1564(.a(32'(limb_226_1562)), .b(32'(limb_226_1563)), .cin(limb_226_1561), .value(limb_226_1564));
    assign limb_226_1565 = limb_226_1564[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1566 = limb_226_1564[32]; // decl: <none>; prim: <none>
    assign limb_226_1567 = tmp_workload_top_int_130__223_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_226_1568 = s8_norm_shift_169_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1569Core rtlzz_owner_1569(.a(32'(limb_226_1567)), .b(32'(limb_226_1568)), .cin(limb_226_1566), .value(limb_226_1569));
    assign limb_226_1570 = limb_226_1569[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1571 = limb_226_1569[32]; // decl: <none>; prim: <none>
    assign limb_226_1572 = tmp_workload_top_int_130__223_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_226_1573 = s8_norm_shift_169_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1574Core rtlzz_owner_1574(.a(32'(limb_226_1572)), .b(32'(limb_226_1573)), .cin(limb_226_1571), .value(limb_226_1574));
    assign limb_226_1575 = limb_226_1574[31:0]; // decl: <none>; prim: <none>
    assign limb_226_1576 = limb_226_1574[32]; // decl: <none>; prim: <none>
    assign limb_226_1577 = tmp_workload_top_int_130__223_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1578 = s8_norm_shift_169_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1579Core rtlzz_owner_1579(.a(2'(limb_226_1577)), .b(2'(limb_226_1578)), .cin(limb_226_1576), .value(limb_226_1579[1:0]));
    assign limb_226_1579[2:2] = '0;
    assign limb_226_1580 = limb_226_1579[1:0]; // decl: <none>; prim: <none>
    assign limb_226_1581 = {limb_226_1580, limb_226_1575, limb_226_1570, limb_226_1565, limb_226_1560}; // decl: <none>; prim: <none>
    assign limb_227_1582 = __beopt_width_309[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1583 = s8_norm_shift_166_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1584Core rtlzz_owner_1584(.a(32'(limb_227_1582)), .b(32'(limb_227_1583)), .cin(1'h0), .value(limb_227_1584));
    assign limb_227_1585 = limb_227_1584[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1586 = limb_227_1584[32]; // decl: <none>; prim: <none>
    assign limb_227_1587 = __beopt_width_309[63:32]; // decl: <none>; prim: <none>
    assign limb_227_1588 = s8_norm_shift_166_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1589Core rtlzz_owner_1589(.a(32'(limb_227_1587)), .b(32'(limb_227_1588)), .cin(limb_227_1586), .value(limb_227_1589));
    assign limb_227_1590 = limb_227_1589[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1591 = limb_227_1589[32]; // decl: <none>; prim: <none>
    assign limb_227_1592 = __beopt_width_309[95:64]; // decl: <none>; prim: <none>
    assign limb_227_1593 = s8_norm_shift_166_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1594Core rtlzz_owner_1594(.a(32'(limb_227_1592)), .b(32'(limb_227_1593)), .cin(limb_227_1591), .value(limb_227_1594));
    assign limb_227_1595 = limb_227_1594[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1596 = limb_227_1594[32]; // decl: <none>; prim: <none>
    assign limb_227_1597 = __beopt_width_309[127:96]; // decl: <none>; prim: <none>
    assign limb_227_1598 = s8_norm_shift_166_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1599Core rtlzz_owner_1599(.a(32'(limb_227_1597)), .b(32'(limb_227_1598)), .cin(limb_227_1596), .value(limb_227_1599));
    assign limb_227_1600 = limb_227_1599[31:0]; // decl: <none>; prim: <none>
    assign limb_227_1601 = limb_227_1599[32]; // decl: <none>; prim: <none>
    assign limb_227_1602 = __beopt_width_309[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1603 = s8_norm_shift_166_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1604Core rtlzz_owner_1604(.a(2'(limb_227_1602)), .b(2'(limb_227_1603)), .cin(limb_227_1601), .value(limb_227_1604[1:0]));
    assign limb_227_1604[2:2] = '0;
    assign limb_227_1605 = limb_227_1604[1:0]; // decl: <none>; prim: <none>
    assign limb_227_1606 = {limb_227_1605, limb_227_1600, limb_227_1595, limb_227_1590, limb_227_1585}; // decl: <none>; prim: <none>
    assign limb_228_1607 = tmp_workload_top_int_130__148_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1608 = s8_norm_shift_115_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1609Core rtlzz_owner_1609(.a(32'(limb_228_1607)), .b(32'(limb_228_1608)), .cin(1'h0), .value(limb_228_1609));
    assign limb_228_1610 = limb_228_1609[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1611 = limb_228_1609[32]; // decl: <none>; prim: <none>
    assign limb_228_1612 = tmp_workload_top_int_130__148_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_228_1613 = s8_norm_shift_115_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1614Core rtlzz_owner_1614(.a(32'(limb_228_1612)), .b(32'(limb_228_1613)), .cin(limb_228_1611), .value(limb_228_1614));
    assign limb_228_1615 = limb_228_1614[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1616 = limb_228_1614[32]; // decl: <none>; prim: <none>
    assign limb_228_1617 = tmp_workload_top_int_130__148_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_228_1618 = s8_norm_shift_115_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1619Core rtlzz_owner_1619(.a(32'(limb_228_1617)), .b(32'(limb_228_1618)), .cin(limb_228_1616), .value(limb_228_1619));
    assign limb_228_1620 = limb_228_1619[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1621 = limb_228_1619[32]; // decl: <none>; prim: <none>
    assign limb_228_1622 = tmp_workload_top_int_130__148_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_228_1623 = s8_norm_shift_115_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1624Core rtlzz_owner_1624(.a(32'(limb_228_1622)), .b(32'(limb_228_1623)), .cin(limb_228_1621), .value(limb_228_1624));
    assign limb_228_1625 = limb_228_1624[31:0]; // decl: <none>; prim: <none>
    assign limb_228_1626 = limb_228_1624[32]; // decl: <none>; prim: <none>
    assign limb_228_1627 = tmp_workload_top_int_130__148_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1628 = s8_norm_shift_115_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1629Core rtlzz_owner_1629(.a(2'(limb_228_1627)), .b(2'(limb_228_1628)), .cin(limb_228_1626), .value(limb_228_1629[1:0]));
    assign limb_228_1629[2:2] = '0;
    assign limb_228_1630 = limb_228_1629[1:0]; // decl: <none>; prim: <none>
    assign limb_228_1631 = {limb_228_1630, limb_228_1625, limb_228_1620, limb_228_1615, limb_228_1610}; // decl: <none>; prim: <none>
    assign limb_229_1632 = __beopt_width_311[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1633 = s8_norm_shift_112_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1634Core rtlzz_owner_1634(.a(32'(limb_229_1632)), .b(32'(limb_229_1633)), .cin(1'h0), .value(limb_229_1634));
    assign limb_229_1635 = limb_229_1634[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1636 = limb_229_1634[32]; // decl: <none>; prim: <none>
    assign limb_229_1637 = __beopt_width_311[63:32]; // decl: <none>; prim: <none>
    assign limb_229_1638 = s8_norm_shift_112_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1639Core rtlzz_owner_1639(.a(32'(limb_229_1637)), .b(32'(limb_229_1638)), .cin(limb_229_1636), .value(limb_229_1639));
    assign limb_229_1640 = limb_229_1639[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1641 = limb_229_1639[32]; // decl: <none>; prim: <none>
    assign limb_229_1642 = __beopt_width_311[95:64]; // decl: <none>; prim: <none>
    assign limb_229_1643 = s8_norm_shift_112_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1644Core rtlzz_owner_1644(.a(32'(limb_229_1642)), .b(32'(limb_229_1643)), .cin(limb_229_1641), .value(limb_229_1644));
    assign limb_229_1645 = limb_229_1644[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1646 = limb_229_1644[32]; // decl: <none>; prim: <none>
    assign limb_229_1647 = __beopt_width_311[127:96]; // decl: <none>; prim: <none>
    assign limb_229_1648 = s8_norm_shift_112_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1649Core rtlzz_owner_1649(.a(32'(limb_229_1647)), .b(32'(limb_229_1648)), .cin(limb_229_1646), .value(limb_229_1649));
    assign limb_229_1650 = limb_229_1649[31:0]; // decl: <none>; prim: <none>
    assign limb_229_1651 = limb_229_1649[32]; // decl: <none>; prim: <none>
    assign limb_229_1652 = __beopt_width_311[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1653 = s8_norm_shift_112_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1654Core rtlzz_owner_1654(.a(2'(limb_229_1652)), .b(2'(limb_229_1653)), .cin(limb_229_1651), .value(limb_229_1654[1:0]));
    assign limb_229_1654[2:2] = '0;
    assign limb_229_1655 = limb_229_1654[1:0]; // decl: <none>; prim: <none>
    assign limb_229_1656 = {limb_229_1655, limb_229_1650, limb_229_1645, limb_229_1640, limb_229_1635}; // decl: <none>; prim: <none>
    assign limb_230_1657 = tmp_workload_top_int_130__63_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_230_1658 = s8_norm_shift_53_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1659Core rtlzz_owner_1659(.a(32'(limb_230_1657)), .b(32'(limb_230_1658)), .cin(1'h0), .value(limb_230_1659));
    assign limb_230_1660 = limb_230_1659[31:0]; // decl: <none>; prim: <none>
    assign limb_230_1661 = limb_230_1659[32]; // decl: <none>; prim: <none>
    assign limb_230_1662 = tmp_workload_top_int_130__63_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_230_1663 = s8_norm_shift_53_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1664Core rtlzz_owner_1664(.a(32'(limb_230_1662)), .b(32'(limb_230_1663)), .cin(limb_230_1661), .value(limb_230_1664));
    assign limb_230_1665 = limb_230_1664[31:0]; // decl: <none>; prim: <none>
    assign limb_230_1666 = limb_230_1664[32]; // decl: <none>; prim: <none>
    assign limb_230_1667 = tmp_workload_top_int_130__63_v0[95:64]; // decl: <none>; prim: <none>
    assign limb_230_1668 = s8_norm_shift_53_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1669Core rtlzz_owner_1669(.a(32'(limb_230_1667)), .b(32'(limb_230_1668)), .cin(limb_230_1666), .value(limb_230_1669));
    assign limb_230_1670 = limb_230_1669[31:0]; // decl: <none>; prim: <none>
    assign limb_230_1671 = limb_230_1669[32]; // decl: <none>; prim: <none>
    assign limb_230_1672 = tmp_workload_top_int_130__63_v0[127:96]; // decl: <none>; prim: <none>
    assign limb_230_1673 = s8_norm_shift_53_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1674Core rtlzz_owner_1674(.a(32'(limb_230_1672)), .b(32'(limb_230_1673)), .cin(limb_230_1671), .value(limb_230_1674));
    assign limb_230_1675 = limb_230_1674[31:0]; // decl: <none>; prim: <none>
    assign limb_230_1676 = limb_230_1674[32]; // decl: <none>; prim: <none>
    assign limb_230_1677 = tmp_workload_top_int_130__63_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1678 = s8_norm_shift_53_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1679Core rtlzz_owner_1679(.a(2'(limb_230_1677)), .b(2'(limb_230_1678)), .cin(limb_230_1676), .value(limb_230_1679[1:0]));
    assign limb_230_1679[2:2] = '0;
    assign limb_230_1680 = limb_230_1679[1:0]; // decl: <none>; prim: <none>
    assign limb_230_1681 = {limb_230_1680, limb_230_1675, limb_230_1670, limb_230_1665, limb_230_1660}; // decl: <none>; prim: <none>
    assign limb_231_1682 = __beopt_width_315[31:0]; // decl: <none>; prim: <none>
    assign limb_231_1683 = s8_norm_shift_50_v0[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1684Core rtlzz_owner_1684(.a(32'(limb_231_1682)), .b(32'(limb_231_1683)), .cin(1'h0), .value(limb_231_1684));
    assign limb_231_1685 = limb_231_1684[31:0]; // decl: <none>; prim: <none>
    assign limb_231_1686 = limb_231_1684[32]; // decl: <none>; prim: <none>
    assign limb_231_1687 = __beopt_width_315[63:32]; // decl: <none>; prim: <none>
    assign limb_231_1688 = s8_norm_shift_50_v0[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1689Core rtlzz_owner_1689(.a(32'(limb_231_1687)), .b(32'(limb_231_1688)), .cin(limb_231_1686), .value(limb_231_1689));
    assign limb_231_1690 = limb_231_1689[31:0]; // decl: <none>; prim: <none>
    assign limb_231_1691 = limb_231_1689[32]; // decl: <none>; prim: <none>
    assign limb_231_1692 = __beopt_width_315[95:64]; // decl: <none>; prim: <none>
    assign limb_231_1693 = s8_norm_shift_50_v0[95:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1694Core rtlzz_owner_1694(.a(32'(limb_231_1692)), .b(32'(limb_231_1693)), .cin(limb_231_1691), .value(limb_231_1694));
    assign limb_231_1695 = limb_231_1694[31:0]; // decl: <none>; prim: <none>
    assign limb_231_1696 = limb_231_1694[32]; // decl: <none>; prim: <none>
    assign limb_231_1697 = __beopt_width_315[127:96]; // decl: <none>; prim: <none>
    assign limb_231_1698 = s8_norm_shift_50_v0[127:96]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1699Core rtlzz_owner_1699(.a(32'(limb_231_1697)), .b(32'(limb_231_1698)), .cin(limb_231_1696), .value(limb_231_1699));
    assign limb_231_1700 = limb_231_1699[31:0]; // decl: <none>; prim: <none>
    assign limb_231_1701 = limb_231_1699[32]; // decl: <none>; prim: <none>
    assign limb_231_1702 = __beopt_width_315[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1703 = s8_norm_shift_50_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1704Core rtlzz_owner_1704(.a(2'(limb_231_1702)), .b(2'(limb_231_1703)), .cin(limb_231_1701), .value(limb_231_1704[1:0]));
    assign limb_231_1704[2:2] = '0;
    assign limb_231_1705 = limb_231_1704[1:0]; // decl: <none>; prim: <none>
    assign limb_231_1706 = {limb_231_1705, limb_231_1700, limb_231_1695, limb_231_1690, limb_231_1685}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_265_s1 <= 65'h0;
            rtlzz_pipe_265_s2 <= 65'h0;
            rtlzz_pipe_265_s3 <= 65'h0;
            rtlzz_pipe_265_s4 <= 65'h0;
            rtlzz_pipe_265_s5 <= 65'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_270_s2 <= 128'h0;
            rtlzz_pipe_270_s3 <= 128'h0;
            rtlzz_pipe_270_s4 <= 128'h0;
            rtlzz_pipe_270_s5 <= 128'h0;
            rtlzz_pipe_270_s6 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_271_s3 <= 128'h0;
            rtlzz_pipe_271_s4 <= 128'h0;
            rtlzz_pipe_271_s5 <= 128'h0;
            rtlzz_pipe_271_s6 <= 128'h0;
            rtlzz_pipe_271_s7 <= 128'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_278_s1 <= 129'h0;
            rtlzz_pipe_278_s2 <= 129'h0;
            rtlzz_pipe_279_s1 <= 129'h0;
            rtlzz_pipe_279_s2 <= 129'h0;
            rtlzz_pipe_279_s3 <= 129'h0;
            rtlzz_pipe_279_s4 <= 129'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_292_s3 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_293_s3 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_295_s4 <= 64'h0;
            rtlzz_pipe_295_s5 <= 64'h0;
            rtlzz_pipe_296_s4 <= 64'h0;
            rtlzz_pipe_296_s5 <= 64'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_307_s6 <= 64'h0;
            rtlzz_pipe_308_s6 <= 64'h0;
            rtlzz_pipe_310_s7 <= 64'h0;
            rtlzz_pipe_10_s4 <= 256'h0;
            rtlzz_pipe_10_s5 <= 256'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_10_s7 <= 256'h0;
            rtlzz_pipe_174_s4 <= 130'h0;
            rtlzz_pipe_174_s5 <= 130'h0;
            rtlzz_pipe_174_s6 <= 130'h0;
            rtlzz_pipe_44_s6 <= 256'h0;
            rtlzz_pipe_44_s7 <= 256'h0;
            rtlzz_pipe_360_s3 <= 32'h0;
            rtlzz_pipe_360_s4 <= 32'h0;
            rtlzz_pipe_365_s3 <= 32'h0;
            rtlzz_pipe_365_s4 <= 32'h0;
            rtlzz_pipe_370_s3 <= 1'h0;
            rtlzz_pipe_370_s4 <= 1'h0;
            rtlzz_pipe_168_s5 <= 34'h0;
            rtlzz_pipe_266_s5 <= 64'h0;
            rtlzz_pipe_268_s5 <= 34'h0;
            rtlzz_pipe_268_s6 <= 34'h0;
            rtlzz_pipe_298_s5 <= 33'h0;
            rtlzz_pipe_298_s6 <= 33'h0;
            rtlzz_pipe_301_s6 <= 32'h0;
            rtlzz_pipe_375_s5 <= 32'h0;
            rtlzz_pipe_378_s6 <= 32'h0;
            rtlzz_pipe_380_s5 <= 32'h0;
            rtlzz_pipe_383_s6 <= 32'h0;
            rtlzz_pipe_384_s6 <= 1'h0;
            rtlzz_pipe_385_s5 <= 1'h0;
            rtlzz_pipe_385_s6 <= 1'h0;
            rtlzz_pipe_386_s6 <= 1'h0;
            rtlzz_pipe_169_s7 <= 34'h0;
            rtlzz_pipe_269_s7 <= 34'h0;
            rtlzz_pipe_170_s7 <= 68'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_173_s7 <= 130'h0;
            rtlzz_pipe_390_s6 <= 32'h0;
            rtlzz_pipe_395_s6 <= 2'h0;
            rtlzz_pipe_304_s7 <= 34'h0;
            rtlzz_pipe_430_s7 <= 32'hffffffff;
            rtlzz_pipe_436_s7 <= 32'hffffffff;
            rtlzz_pipe_442_s7 <= 4'hf;
            rtlzz_pipe_448_s7 <= 32'hffffffff;
            rtlzz_pipe_454_s7 <= 32'hffffffff;
            rtlzz_pipe_460_s7 <= 32'hffffffff;
            rtlzz_pipe_466_s7 <= 32'hffffffff;
            rtlzz_pipe_471_s7 <= 2'h0;
            rtlzz_pipe_478_s6 <= 32'hffffffff;
            rtlzz_pipe_478_s7 <= 32'hffffffff;
            rtlzz_pipe_484_s6 <= 32'hffffffff;
            rtlzz_pipe_484_s7 <= 32'hffffffff;
            rtlzz_pipe_490_s6 <= 32'hffffffff;
            rtlzz_pipe_490_s7 <= 32'hffffffff;
            rtlzz_pipe_496_s6 <= 32'hffffffff;
            rtlzz_pipe_496_s7 <= 32'hffffffff;
            rtlzz_pipe_502_s6 <= 2'h3;
            rtlzz_pipe_502_s7 <= 2'h3;
            rtlzz_pipe_507_s1 <= 32'h0;
            rtlzz_pipe_507_s2 <= 32'h0;
            rtlzz_pipe_507_s3 <= 32'h0;
            rtlzz_pipe_507_s4 <= 32'h0;
            rtlzz_pipe_507_s5 <= 32'h0;
            rtlzz_pipe_507_s6 <= 32'h0;
            rtlzz_pipe_512_s1 <= 32'h0;
            rtlzz_pipe_512_s2 <= 32'h0;
            rtlzz_pipe_512_s3 <= 32'h0;
            rtlzz_pipe_512_s4 <= 32'h0;
            rtlzz_pipe_512_s5 <= 32'h0;
            rtlzz_pipe_512_s6 <= 32'h0;
            rtlzz_pipe_517_s1 <= 1'h0;
            rtlzz_pipe_517_s2 <= 1'h0;
            rtlzz_pipe_517_s3 <= 1'h0;
            rtlzz_pipe_517_s4 <= 1'h0;
            rtlzz_pipe_517_s5 <= 1'h0;
            rtlzz_pipe_517_s6 <= 1'h0;
            rtlzz_pipe_313_s7 <= 33'h0;
            rtlzz_pipe_316_s7 <= 32'h0;
            rtlzz_pipe_522_s2 <= 32'h0;
            rtlzz_pipe_522_s3 <= 32'h0;
            rtlzz_pipe_522_s4 <= 32'h0;
            rtlzz_pipe_522_s5 <= 32'h0;
            rtlzz_pipe_522_s6 <= 32'h0;
            rtlzz_pipe_522_s7 <= 32'h0;
            rtlzz_pipe_527_s2 <= 32'h0;
            rtlzz_pipe_527_s3 <= 32'h0;
            rtlzz_pipe_527_s4 <= 32'h0;
            rtlzz_pipe_527_s5 <= 32'h0;
            rtlzz_pipe_527_s6 <= 32'h0;
            rtlzz_pipe_527_s7 <= 32'h0;
            rtlzz_pipe_532_s2 <= 1'h0;
            rtlzz_pipe_532_s3 <= 1'h0;
            rtlzz_pipe_532_s4 <= 1'h0;
            rtlzz_pipe_532_s5 <= 1'h0;
            rtlzz_pipe_532_s6 <= 1'h0;
            rtlzz_pipe_532_s7 <= 1'h0;
            rtlzz_pipe_319_s7 <= 34'h0;
            rtlzz_pipe_594_s7 <= 32'hffffffff;
            rtlzz_pipe_600_s7 <= 32'hffffffff;
            rtlzz_pipe_606_s7 <= 32'hffffffff;
            rtlzz_pipe_612_s7 <= 32'hffffffff;
            rtlzz_pipe_618_s7 <= 2'h3;
            rtlzz_pipe_652_s1 <= 32'h0;
            rtlzz_pipe_652_s2 <= 32'h0;
            rtlzz_pipe_655_s3 <= 32'h0;
            rtlzz_pipe_657_s1 <= 32'h0;
            rtlzz_pipe_657_s2 <= 32'h0;
            rtlzz_pipe_660_s3 <= 32'h0;
            rtlzz_pipe_662_s1 <= 32'h0;
            rtlzz_pipe_662_s2 <= 32'h0;
            rtlzz_pipe_665_s3 <= 32'h0;
            rtlzz_pipe_666_s3 <= 1'h0;
            rtlzz_pipe_667_s1 <= 32'h0;
            rtlzz_pipe_667_s2 <= 32'h0;
            rtlzz_pipe_667_s3 <= 32'h0;
            rtlzz_pipe_668_s3 <= 32'h0;
            rtlzz_pipe_672_s1 <= 1'h0;
            rtlzz_pipe_672_s2 <= 1'h0;
            rtlzz_pipe_672_s3 <= 1'h0;
            rtlzz_pipe_673_s3 <= 1'h0;
            rtlzz_pipe_280_s4 <= 64'h0;
            rtlzz_pipe_284_s4 <= 128'h0;
            rtlzz_pipe_322_s4 <= 33'h0;
            rtlzz_pipe_325_s5 <= 32'h0;
            rtlzz_pipe_677_s2 <= 32'h0;
            rtlzz_pipe_677_s3 <= 32'h0;
            rtlzz_pipe_677_s4 <= 32'h0;
            rtlzz_pipe_682_s2 <= 32'h0;
            rtlzz_pipe_682_s3 <= 32'h0;
            rtlzz_pipe_682_s4 <= 32'h0;
            rtlzz_pipe_687_s2 <= 32'h0;
            rtlzz_pipe_687_s3 <= 32'h0;
            rtlzz_pipe_687_s4 <= 32'h0;
            rtlzz_pipe_692_s2 <= 32'h0;
            rtlzz_pipe_692_s3 <= 32'h0;
            rtlzz_pipe_692_s4 <= 32'h0;
            rtlzz_pipe_697_s2 <= 1'h0;
            rtlzz_pipe_697_s3 <= 1'h0;
            rtlzz_pipe_697_s4 <= 1'h0;
            rtlzz_pipe_199_s5 <= 34'h0;
            rtlzz_pipe_281_s5 <= 64'h0;
            rtlzz_pipe_283_s5 <= 34'h0;
            rtlzz_pipe_287_s5 <= 66'h0;
            rtlzz_pipe_202_s5 <= 130'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_328_s5 <= 34'h0;
            rtlzz_pipe_724_s5 <= 32'hffffffff;
            rtlzz_pipe_730_s5 <= 32'hffffffff;
            rtlzz_pipe_736_s5 <= 4'hf;
            rtlzz_pipe_334_s4 <= 33'h0;
            rtlzz_pipe_334_s5 <= 33'h0;
            rtlzz_pipe_334_s6 <= 33'h0;
            rtlzz_pipe_337_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_773_s5 <= 32'h0;
            rtlzz_pipe_778_s5 <= 32'h0;
            rtlzz_pipe_783_s5 <= 2'h0;
            rtlzz_pipe_115_s6 <= 66'h0;
            rtlzz_pipe_211_s6 <= 34'h0;
            rtlzz_pipe_291_s6 <= 34'h0;
            rtlzz_pipe_340_s4 <= 34'h0;
            rtlzz_pipe_340_s5 <= 34'h0;
            rtlzz_pipe_340_s6 <= 34'h0;
            rtlzz_pipe_828_s6 <= 32'hffffffff;
            rtlzz_pipe_834_s6 <= 32'hffffffff;
            rtlzz_pipe_840_s6 <= 4'hf;
            rtlzz_pipe_876_s5 <= 32'hffffffff;
            rtlzz_pipe_876_s6 <= 32'hffffffff;
            rtlzz_pipe_882_s5 <= 32'hffffffff;
            rtlzz_pipe_882_s6 <= 32'hffffffff;
            rtlzz_pipe_888_s5 <= 32'hffffffff;
            rtlzz_pipe_888_s6 <= 32'hffffffff;
            rtlzz_pipe_894_s5 <= 32'hffffffff;
            rtlzz_pipe_894_s6 <= 32'hffffffff;
            rtlzz_pipe_900_s5 <= 4'hf;
            rtlzz_pipe_900_s6 <= 4'hf;
            rtlzz_pipe_1013_s1 <= 32'h0;
            rtlzz_pipe_1013_s2 <= 32'h0;
            rtlzz_pipe_1013_s3 <= 32'h0;
            rtlzz_pipe_1013_s4 <= 32'h0;
            rtlzz_pipe_1013_s5 <= 32'h0;
            rtlzz_pipe_1013_s6 <= 32'h0;
            rtlzz_pipe_1013_s7 <= 32'h0;
            rtlzz_pipe_1018_s1 <= 32'h0;
            rtlzz_pipe_1018_s2 <= 32'h0;
            rtlzz_pipe_1018_s3 <= 32'h0;
            rtlzz_pipe_1018_s4 <= 32'h0;
            rtlzz_pipe_1018_s5 <= 32'h0;
            rtlzz_pipe_1018_s6 <= 32'h0;
            rtlzz_pipe_1018_s7 <= 32'h0;
            rtlzz_pipe_1023_s1 <= 32'h0;
            rtlzz_pipe_1023_s2 <= 32'h0;
            rtlzz_pipe_1023_s3 <= 32'h0;
            rtlzz_pipe_1023_s4 <= 32'h0;
            rtlzz_pipe_1023_s5 <= 32'h0;
            rtlzz_pipe_1023_s6 <= 32'h0;
            rtlzz_pipe_1023_s7 <= 32'h0;
            rtlzz_pipe_1028_s1 <= 32'h0;
            rtlzz_pipe_1028_s2 <= 32'h0;
            rtlzz_pipe_1028_s3 <= 32'h0;
            rtlzz_pipe_1028_s4 <= 32'h0;
            rtlzz_pipe_1028_s5 <= 32'h0;
            rtlzz_pipe_1028_s6 <= 32'h0;
            rtlzz_pipe_1028_s7 <= 32'h0;
            rtlzz_pipe_1033_s1 <= 32'h0;
            rtlzz_pipe_1033_s2 <= 32'h0;
            rtlzz_pipe_1033_s3 <= 32'h0;
            rtlzz_pipe_1033_s4 <= 32'h0;
            rtlzz_pipe_1033_s5 <= 32'h0;
            rtlzz_pipe_1033_s6 <= 32'h0;
            rtlzz_pipe_1033_s7 <= 32'h0;
            rtlzz_pipe_1038_s1 <= 32'h0;
            rtlzz_pipe_1038_s2 <= 32'h0;
            rtlzz_pipe_1038_s3 <= 32'h0;
            rtlzz_pipe_1038_s4 <= 32'h0;
            rtlzz_pipe_1038_s5 <= 32'h0;
            rtlzz_pipe_1038_s6 <= 32'h0;
            rtlzz_pipe_1038_s7 <= 32'h0;
            rtlzz_pipe_1043_s1 <= 32'h0;
            rtlzz_pipe_1043_s2 <= 32'h0;
            rtlzz_pipe_1043_s3 <= 32'h0;
            rtlzz_pipe_1043_s4 <= 32'h0;
            rtlzz_pipe_1043_s5 <= 32'h0;
            rtlzz_pipe_1043_s6 <= 32'h0;
            rtlzz_pipe_1043_s7 <= 32'h0;
            rtlzz_pipe_1048_s1 <= 32'h0;
            rtlzz_pipe_1048_s2 <= 32'h0;
            rtlzz_pipe_1048_s3 <= 32'h0;
            rtlzz_pipe_1048_s4 <= 32'h0;
            rtlzz_pipe_1048_s5 <= 32'h0;
            rtlzz_pipe_1048_s6 <= 32'h0;
            rtlzz_pipe_1048_s7 <= 32'h0;
            rtlzz_pipe_1053_s1 <= 32'h0;
            rtlzz_pipe_1053_s2 <= 32'h0;
            rtlzz_pipe_1053_s3 <= 32'h0;
            rtlzz_pipe_1053_s4 <= 32'h0;
            rtlzz_pipe_1053_s5 <= 32'h0;
            rtlzz_pipe_1053_s6 <= 32'h0;
            rtlzz_pipe_1053_s7 <= 32'h0;
            rtlzz_pipe_1058_s1 <= 32'h0;
            rtlzz_pipe_1058_s2 <= 32'h0;
            rtlzz_pipe_1058_s3 <= 32'h0;
            rtlzz_pipe_1058_s4 <= 32'h0;
            rtlzz_pipe_1058_s5 <= 32'h0;
            rtlzz_pipe_1058_s6 <= 32'h0;
            rtlzz_pipe_1058_s7 <= 32'h0;
            rtlzz_pipe_1063_s1 <= 32'h0;
            rtlzz_pipe_1063_s2 <= 32'h0;
            rtlzz_pipe_1063_s3 <= 32'h0;
            rtlzz_pipe_1063_s4 <= 32'h0;
            rtlzz_pipe_1063_s5 <= 32'h0;
            rtlzz_pipe_1063_s6 <= 32'h0;
            rtlzz_pipe_1063_s7 <= 32'h0;
            rtlzz_pipe_1068_s1 <= 32'h0;
            rtlzz_pipe_1068_s2 <= 32'h0;
            rtlzz_pipe_1068_s3 <= 32'h0;
            rtlzz_pipe_1068_s4 <= 32'h0;
            rtlzz_pipe_1068_s5 <= 32'h0;
            rtlzz_pipe_1068_s6 <= 32'h0;
            rtlzz_pipe_1068_s7 <= 32'h0;
            rtlzz_pipe_1073_s1 <= 32'h0;
            rtlzz_pipe_1073_s2 <= 32'h0;
            rtlzz_pipe_1073_s3 <= 32'h0;
            rtlzz_pipe_1073_s4 <= 32'h0;
            rtlzz_pipe_1073_s5 <= 32'h0;
            rtlzz_pipe_1073_s6 <= 32'h0;
            rtlzz_pipe_1073_s7 <= 32'h0;
            rtlzz_pipe_1078_s1 <= 32'h0;
            rtlzz_pipe_1078_s2 <= 32'h0;
            rtlzz_pipe_1078_s3 <= 32'h0;
            rtlzz_pipe_1078_s4 <= 32'h0;
            rtlzz_pipe_1078_s5 <= 32'h0;
            rtlzz_pipe_1078_s6 <= 32'h0;
            rtlzz_pipe_1078_s7 <= 32'h0;
            rtlzz_pipe_1083_s1 <= 32'h0;
            rtlzz_pipe_1083_s2 <= 32'h0;
            rtlzz_pipe_1083_s3 <= 32'h0;
            rtlzz_pipe_1083_s4 <= 32'h0;
            rtlzz_pipe_1083_s5 <= 32'h0;
            rtlzz_pipe_1083_s6 <= 32'h0;
            rtlzz_pipe_1083_s7 <= 32'h0;
            rtlzz_pipe_1088_s1 <= 32'h0;
            rtlzz_pipe_1088_s2 <= 32'h0;
            rtlzz_pipe_1088_s3 <= 32'h0;
            rtlzz_pipe_1088_s4 <= 32'h0;
            rtlzz_pipe_1088_s5 <= 32'h0;
            rtlzz_pipe_1088_s6 <= 32'h0;
            rtlzz_pipe_1088_s7 <= 32'h0;
            rtlzz_pipe_1093_s1 <= 1'h0;
            rtlzz_pipe_1093_s2 <= 1'h0;
            rtlzz_pipe_1093_s3 <= 1'h0;
            rtlzz_pipe_1093_s4 <= 1'h0;
            rtlzz_pipe_1093_s5 <= 1'h0;
            rtlzz_pipe_1093_s6 <= 1'h0;
            rtlzz_pipe_1093_s7 <= 1'h0;
            rtlzz_pipe_1257_s5 <= 32'h0;
            rtlzz_pipe_1262_s5 <= 32'h0;
            rtlzz_pipe_1267_s5 <= 32'h0;
            rtlzz_pipe_1272_s5 <= 32'h0;
            rtlzz_pipe_1277_s5 <= 32'h0;
            rtlzz_pipe_1282_s5 <= 32'h0;
            rtlzz_pipe_1287_s5 <= 32'h0;
            rtlzz_pipe_1292_s5 <= 32'h0;
            rtlzz_pipe_1297_s5 <= 2'h0;
            rtlzz_pipe_1347_s7 <= 32'h0;
            rtlzz_pipe_1352_s7 <= 32'h0;
            rtlzz_pipe_1357_s7 <= 32'h0;
            rtlzz_pipe_1362_s7 <= 32'h0;
            rtlzz_pipe_1367_s7 <= 32'h0;
            rtlzz_pipe_1372_s7 <= 32'h0;
            rtlzz_pipe_1377_s7 <= 32'h0;
            rtlzz_pipe_1382_s7 <= 32'h0;
            rtlzz_pipe_1508_s6 <= 32'h0;
            rtlzz_pipe_1513_s6 <= 32'h0;
            rtlzz_pipe_1518_s6 <= 32'h0;
            rtlzz_pipe_1523_s6 <= 32'h0;
            rtlzz_pipe_1528_s6 <= 4'h0;
            rtlzz_pipe_846_s6 <= 32'hffffffff;
            rtlzz_pipe_852_s6 <= 32'hffffffff;
            rtlzz_pipe_858_s6 <= 32'hffffffff;
            rtlzz_pipe_864_s6 <= 32'hffffffff;
            rtlzz_pipe_870_s6 <= 4'hf;
            rtlzz_pipe_1302_s6 <= 32'h0;
            rtlzz_pipe_1305_s7 <= 32'h0;
            rtlzz_pipe_1307_s6 <= 32'h0;
            rtlzz_pipe_1310_s7 <= 32'h0;
            rtlzz_pipe_1312_s6 <= 32'h0;
            rtlzz_pipe_1315_s7 <= 32'h0;
            rtlzz_pipe_1317_s6 <= 32'h0;
            rtlzz_pipe_1320_s7 <= 32'h0;
            rtlzz_pipe_1322_s6 <= 32'h0;
            rtlzz_pipe_1325_s7 <= 32'h0;
            rtlzz_pipe_1327_s6 <= 32'h0;
            rtlzz_pipe_1330_s7 <= 32'h0;
            rtlzz_pipe_1332_s6 <= 32'h0;
            rtlzz_pipe_1335_s7 <= 32'h0;
            rtlzz_pipe_1336_s7 <= 1'h0;
            rtlzz_pipe_1337_s6 <= 32'h0;
            rtlzz_pipe_1337_s7 <= 32'h0;
            rtlzz_pipe_1338_s7 <= 32'h0;
            rtlzz_pipe_1342_s6 <= 2'h0;
            rtlzz_pipe_1342_s7 <= 2'h0;
            rtlzz_pipe_1343_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= __beopt_width_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_265_s2 <= rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_265_s3 <= rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_265_s4 <= rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_265_s5 <= rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_270_s2 <= rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_270_s3 <= rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_270_s4 <= rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_270_s5 <= rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_270_s6 <= rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_271_s3 <= rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_271_s4 <= rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_271_s5 <= rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_271_s6 <= rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_271_s7 <= rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_278_s1 <= __beopt_width_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_278_s2 <= rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= __beopt_width_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_279_s2 <= rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_279_s3 <= rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_279_s4 <= rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_292_s3 <= rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_293_s3 <= rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_295_s4 <= rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_295_s5 <= rtlzz_pipe_295_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_296_s4 <= mul_precision_296; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_296_s5 <= rtlzz_pipe_296_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_307_s6 <= rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_308_s6 <= mul_precision_308; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_310_s7 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_10_s4 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_10_s5 <= rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_174_s4 <= __beopt_width_561; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_174_s5 <= rtlzz_pipe_174_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_174_s6 <= rtlzz_pipe_174_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_44_s6 <= tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_44_s7 <= rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_360_s3 <= limb_13_360; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_360_s4 <= rtlzz_pipe_360_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_365_s3 <= limb_13_365; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_365_s4 <= rtlzz_pipe_365_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_370_s3 <= limb_13_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_370_s4 <= rtlzz_pipe_370_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_168_s5 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_268_s5 <= __beopt_width_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_268_s6 <= rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_298_s5 <= mul_precision_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_298_s6 <= rtlzz_pipe_298_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_301_s6 <= mul_precision_301; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_375_s5 <= limb_15_375; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_378_s6 <= limb_15_378; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_380_s5 <= limb_15_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_383_s6 <= limb_15_383; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_384_s6 <= limb_15_384; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_385_s5 <= limb_15_385; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_385_s6 <= rtlzz_pipe_385_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_386_s6 <= limb_15_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_169_s7 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_269_s7 <= __beopt_width_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_170_s7 <= __beopt_width_557; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_173_s7 <= __beopt_width_560; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_390_s6 <= limb_21_390; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_395_s6 <= limb_21_395; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_304_s7 <= mul_precision_304; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_430_s7 <= limb_31_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_436_s7 <= limb_31_436; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_442_s7 <= limb_31_442; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_448_s7 <= limb_38_448; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_454_s7 <= limb_38_454; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_460_s7 <= limb_38_460; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_466_s7 <= limb_38_466; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_471_s7 <= limb_38_471; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_478_s6 <= limb_40_478; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_478_s7 <= rtlzz_pipe_478_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_484_s6 <= limb_40_484; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_484_s7 <= rtlzz_pipe_484_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_490_s6 <= limb_40_490; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_490_s7 <= rtlzz_pipe_490_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_496_s6 <= limb_40_496; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_496_s7 <= rtlzz_pipe_496_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_502_s6 <= limb_40_502; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_502_s7 <= rtlzz_pipe_502_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_507_s1 <= limb_51_507; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_507_s2 <= rtlzz_pipe_507_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_507_s3 <= rtlzz_pipe_507_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_507_s4 <= rtlzz_pipe_507_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_507_s5 <= rtlzz_pipe_507_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_507_s6 <= rtlzz_pipe_507_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_512_s1 <= limb_51_512; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_512_s2 <= rtlzz_pipe_512_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_512_s3 <= rtlzz_pipe_512_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_512_s4 <= rtlzz_pipe_512_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_512_s5 <= rtlzz_pipe_512_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_512_s6 <= rtlzz_pipe_512_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_517_s1 <= limb_51_517; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_517_s2 <= rtlzz_pipe_517_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_517_s3 <= rtlzz_pipe_517_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_517_s4 <= rtlzz_pipe_517_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_517_s5 <= rtlzz_pipe_517_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_517_s6 <= rtlzz_pipe_517_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_313_s7 <= mul_precision_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_316_s7 <= mul_precision_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_522_s2 <= limb_53_522; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_522_s3 <= rtlzz_pipe_522_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_522_s4 <= rtlzz_pipe_522_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_522_s5 <= rtlzz_pipe_522_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_522_s6 <= rtlzz_pipe_522_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_522_s7 <= rtlzz_pipe_522_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_527_s2 <= limb_53_527; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_527_s3 <= rtlzz_pipe_527_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_527_s4 <= rtlzz_pipe_527_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_527_s5 <= rtlzz_pipe_527_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_527_s6 <= rtlzz_pipe_527_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_527_s7 <= rtlzz_pipe_527_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_532_s2 <= limb_53_532; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_532_s3 <= rtlzz_pipe_532_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_532_s4 <= rtlzz_pipe_532_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_532_s5 <= rtlzz_pipe_532_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_532_s6 <= rtlzz_pipe_532_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_532_s7 <= rtlzz_pipe_532_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_319_s7 <= mul_precision_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_594_s7 <= limb_76_594; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_600_s7 <= limb_76_600; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_606_s7 <= limb_76_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_612_s7 <= limb_76_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_618_s7 <= limb_76_618; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_652_s1 <= limb_85_652; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_652_s2 <= rtlzz_pipe_652_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_655_s3 <= limb_85_655; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_657_s1 <= limb_85_657; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_657_s2 <= rtlzz_pipe_657_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_660_s3 <= limb_85_660; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_662_s1 <= limb_85_662; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_662_s2 <= rtlzz_pipe_662_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_665_s3 <= limb_85_665; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_666_s3 <= limb_85_666; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_667_s1 <= limb_85_667; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_667_s2 <= rtlzz_pipe_667_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_667_s3 <= rtlzz_pipe_667_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_668_s3 <= limb_85_668; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_672_s1 <= limb_85_672; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_672_s2 <= rtlzz_pipe_672_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_672_s3 <= rtlzz_pipe_672_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_673_s3 <= limb_85_673; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_280_s4 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_284_s4 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_322_s4 <= mul_precision_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_325_s5 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_677_s2 <= limb_87_677; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_677_s3 <= rtlzz_pipe_677_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_677_s4 <= rtlzz_pipe_677_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_682_s2 <= limb_87_682; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_682_s3 <= rtlzz_pipe_682_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_682_s4 <= rtlzz_pipe_682_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_687_s2 <= limb_87_687; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_687_s3 <= rtlzz_pipe_687_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_687_s4 <= rtlzz_pipe_687_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_692_s2 <= limb_87_692; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_692_s3 <= rtlzz_pipe_692_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_692_s4 <= rtlzz_pipe_692_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_697_s2 <= limb_87_697; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_697_s3 <= rtlzz_pipe_697_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_697_s4 <= rtlzz_pipe_697_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_199_s5 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_281_s5 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_283_s5 <= __beopt_width_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_287_s5 <= __beopt_width_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_202_s5 <= __beopt_width_611; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_328_s5 <= rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_724_s5 <= limb_103_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_730_s5 <= limb_103_730; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_736_s5 <= limb_103_736; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_334_s4 <= mul_precision_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_334_s6 <= rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_337_s4 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_773_s5 <= limb_115_773; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_778_s5 <= limb_115_778; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_783_s5 <= limb_115_783; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_115_s6 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_211_s6 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_291_s6 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_340_s4 <= mul_precision_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_340_s5 <= rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_828_s6 <= limb_131_828; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_834_s6 <= limb_131_834; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_840_s6 <= limb_131_840; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_876_s5 <= limb_140_876; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_876_s6 <= rtlzz_pipe_876_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_882_s5 <= limb_140_882; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_882_s6 <= rtlzz_pipe_882_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_888_s5 <= limb_140_888; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_888_s6 <= rtlzz_pipe_888_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_894_s5 <= limb_140_894; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_894_s6 <= rtlzz_pipe_894_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_900_s5 <= limb_140_900; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_900_s6 <= rtlzz_pipe_900_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1013_s1 <= limb_157_1013; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1013_s2 <= rtlzz_pipe_1013_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1013_s3 <= rtlzz_pipe_1013_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1013_s4 <= rtlzz_pipe_1013_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1013_s5 <= rtlzz_pipe_1013_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1013_s6 <= rtlzz_pipe_1013_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1013_s7 <= rtlzz_pipe_1013_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1018_s1 <= limb_157_1018; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1018_s2 <= rtlzz_pipe_1018_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1018_s3 <= rtlzz_pipe_1018_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1018_s4 <= rtlzz_pipe_1018_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1018_s5 <= rtlzz_pipe_1018_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1018_s6 <= rtlzz_pipe_1018_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1018_s7 <= rtlzz_pipe_1018_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1023_s1 <= limb_157_1023; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1023_s2 <= rtlzz_pipe_1023_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1023_s3 <= rtlzz_pipe_1023_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1023_s4 <= rtlzz_pipe_1023_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1023_s5 <= rtlzz_pipe_1023_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1023_s6 <= rtlzz_pipe_1023_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1023_s7 <= rtlzz_pipe_1023_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1028_s1 <= limb_157_1028; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1028_s2 <= rtlzz_pipe_1028_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1028_s3 <= rtlzz_pipe_1028_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1028_s4 <= rtlzz_pipe_1028_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1028_s5 <= rtlzz_pipe_1028_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1028_s6 <= rtlzz_pipe_1028_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1028_s7 <= rtlzz_pipe_1028_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1033_s1 <= limb_157_1033; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1033_s2 <= rtlzz_pipe_1033_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1033_s3 <= rtlzz_pipe_1033_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1033_s4 <= rtlzz_pipe_1033_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1033_s5 <= rtlzz_pipe_1033_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1033_s6 <= rtlzz_pipe_1033_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1033_s7 <= rtlzz_pipe_1033_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1038_s1 <= limb_157_1038; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1038_s2 <= rtlzz_pipe_1038_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1038_s3 <= rtlzz_pipe_1038_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1038_s4 <= rtlzz_pipe_1038_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1038_s5 <= rtlzz_pipe_1038_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1038_s6 <= rtlzz_pipe_1038_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1038_s7 <= rtlzz_pipe_1038_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1043_s1 <= limb_157_1043; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1043_s2 <= rtlzz_pipe_1043_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1043_s3 <= rtlzz_pipe_1043_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1043_s4 <= rtlzz_pipe_1043_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1043_s5 <= rtlzz_pipe_1043_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1043_s6 <= rtlzz_pipe_1043_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1043_s7 <= rtlzz_pipe_1043_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1048_s1 <= limb_157_1048; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1048_s2 <= rtlzz_pipe_1048_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1048_s3 <= rtlzz_pipe_1048_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1048_s4 <= rtlzz_pipe_1048_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1048_s5 <= rtlzz_pipe_1048_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1048_s6 <= rtlzz_pipe_1048_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1048_s7 <= rtlzz_pipe_1048_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1053_s1 <= limb_157_1053; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1053_s2 <= rtlzz_pipe_1053_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1053_s3 <= rtlzz_pipe_1053_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1053_s4 <= rtlzz_pipe_1053_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1053_s5 <= rtlzz_pipe_1053_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1053_s6 <= rtlzz_pipe_1053_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1053_s7 <= rtlzz_pipe_1053_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1058_s1 <= limb_157_1058; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1058_s2 <= rtlzz_pipe_1058_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1058_s3 <= rtlzz_pipe_1058_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1058_s4 <= rtlzz_pipe_1058_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1058_s5 <= rtlzz_pipe_1058_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1058_s6 <= rtlzz_pipe_1058_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1058_s7 <= rtlzz_pipe_1058_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1063_s1 <= limb_157_1063; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1063_s2 <= rtlzz_pipe_1063_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1063_s3 <= rtlzz_pipe_1063_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1063_s4 <= rtlzz_pipe_1063_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1063_s5 <= rtlzz_pipe_1063_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1063_s6 <= rtlzz_pipe_1063_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1063_s7 <= rtlzz_pipe_1063_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1068_s1 <= limb_157_1068; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1068_s2 <= rtlzz_pipe_1068_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1068_s3 <= rtlzz_pipe_1068_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1068_s4 <= rtlzz_pipe_1068_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1068_s5 <= rtlzz_pipe_1068_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1068_s6 <= rtlzz_pipe_1068_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1068_s7 <= rtlzz_pipe_1068_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1073_s1 <= limb_157_1073; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1073_s2 <= rtlzz_pipe_1073_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1073_s3 <= rtlzz_pipe_1073_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1073_s4 <= rtlzz_pipe_1073_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1073_s5 <= rtlzz_pipe_1073_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1073_s6 <= rtlzz_pipe_1073_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1073_s7 <= rtlzz_pipe_1073_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1078_s1 <= limb_157_1078; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1078_s2 <= rtlzz_pipe_1078_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1078_s3 <= rtlzz_pipe_1078_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1078_s4 <= rtlzz_pipe_1078_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1078_s5 <= rtlzz_pipe_1078_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1078_s6 <= rtlzz_pipe_1078_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1078_s7 <= rtlzz_pipe_1078_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1083_s1 <= limb_157_1083; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1083_s2 <= rtlzz_pipe_1083_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1083_s3 <= rtlzz_pipe_1083_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1083_s4 <= rtlzz_pipe_1083_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1083_s5 <= rtlzz_pipe_1083_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1083_s6 <= rtlzz_pipe_1083_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1083_s7 <= rtlzz_pipe_1083_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1088_s1 <= limb_157_1088; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1088_s2 <= rtlzz_pipe_1088_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1088_s3 <= rtlzz_pipe_1088_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1088_s4 <= rtlzz_pipe_1088_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1088_s5 <= rtlzz_pipe_1088_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1088_s6 <= rtlzz_pipe_1088_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1088_s7 <= rtlzz_pipe_1088_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1093_s1 <= limb_157_1093; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1093_s2 <= rtlzz_pipe_1093_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1093_s3 <= rtlzz_pipe_1093_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1093_s4 <= rtlzz_pipe_1093_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1093_s5 <= rtlzz_pipe_1093_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1093_s6 <= rtlzz_pipe_1093_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1093_s7 <= rtlzz_pipe_1093_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1257_s5 <= limb_218_1257; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1262_s5 <= limb_218_1262; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1267_s5 <= limb_218_1267; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1272_s5 <= limb_218_1272; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1277_s5 <= limb_218_1277; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1282_s5 <= limb_218_1282; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1287_s5 <= limb_218_1287; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1292_s5 <= limb_218_1292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1297_s5 <= limb_218_1297; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1347_s7 <= limb_220_1347; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1352_s7 <= limb_220_1352; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1357_s7 <= limb_220_1357; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1362_s7 <= limb_220_1362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1367_s7 <= limb_220_1367; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1372_s7 <= limb_220_1372; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1377_s7 <= limb_220_1377; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1382_s7 <= limb_220_1382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1508_s6 <= limb_224_1508; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1513_s6 <= limb_224_1513; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1518_s6 <= limb_224_1518; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1523_s6 <= limb_224_1523; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1528_s6 <= limb_224_1528; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_846_s6 <= limb_138_846; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_852_s6 <= limb_138_852; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_858_s6 <= limb_138_858; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_864_s6 <= limb_138_864; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_870_s6 <= limb_138_870; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1302_s6 <= limb_219_1302; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1305_s7 <= limb_219_1305; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1307_s6 <= limb_219_1307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1310_s7 <= limb_219_1310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1312_s6 <= limb_219_1312; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1315_s7 <= limb_219_1315; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1317_s6 <= limb_219_1317; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1320_s7 <= limb_219_1320; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1322_s6 <= limb_219_1322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1325_s7 <= limb_219_1325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1327_s6 <= limb_219_1327; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1330_s7 <= limb_219_1330; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1332_s6 <= limb_219_1332; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1335_s7 <= limb_219_1335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1336_s7 <= limb_219_1336; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1337_s6 <= limb_219_1337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1337_s7 <= rtlzz_pipe_1337_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1338_s7 <= limb_219_1338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1342_s6 <= limb_219_1342; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1342_s7 <= rtlzz_pipe_1342_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1343_s7 <= limb_219_1343; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_343();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_344();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_345();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_346();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_348();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_350();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_351();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_352();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_353();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_356Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_356();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_357();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358Core(input wire [32:0] a,input wire [32:0] b,input wire cin,output wire [65:0] value);
wire [32:0] masked_a=((a&33'h1ffffffff)|33'h0);
wire [32:0] masked_b=((b&33'h1ffffffff)|33'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [65:0] native_value=aa*bb;
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_358();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [67:0] value);
wire [33:0] masked_a=((a&34'h3ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h3ffffffff)|34'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [67:0] native_value=aa*bb;
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_367();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_372Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_372();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_377Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_377();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_382();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_392Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_392();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_397();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_407Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_407();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_413();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_425Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_425();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_431Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_431();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_449Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_449();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_455();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_467Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_467();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_473();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_479Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_479();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_485Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_485();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_491();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_503Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_503();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_508Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_508();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_513();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_523();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_528Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_528();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_533Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_533();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_538();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_548Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_548();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_553Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_553();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_559Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_559();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_565Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_565();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_577();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_595Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_595();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_601Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_601();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_613Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_613();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_619Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_619();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_625Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_625();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_631();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_637Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_637();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_643Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_643();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_654Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_654();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_659Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_659();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_664Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_664();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_669Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_669();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_679();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_684Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_684();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_689Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_689();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_694Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_694();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_704Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_704();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_709Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_709();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_714Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_714();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_719Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_719();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_725Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_725();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_737Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_737();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_743Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_743();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_749Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_749();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_755Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_755();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_765Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_765();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_770Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_770();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_775Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_775();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_780Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_780();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_785Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_785();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_795Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_795();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_800Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_800();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_805Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_805();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_817Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_817();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_823Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_823();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_829Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_829();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_835();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_841Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_841();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_847Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_847();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_853Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_853();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_859Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_859();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_865Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_865();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_871Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_871();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_877Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_877();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_883Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_883();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_889();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_895Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_895();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_907();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_913Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_913();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_919Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_919();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_925Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_925();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_931Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_931();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_937Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_937();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_943Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_943();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_949Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_949();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_955Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_955();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_961Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b1);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_961();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_967Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_967();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_973Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_973();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_979Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_979();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_985Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_985();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_991Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_991();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_997Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_997();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1003Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1003();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1009Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1009();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1014Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1014();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1019Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1019();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1024Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1024();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1029Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1029();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1034Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1034();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1039Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1039();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1044Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1044();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1049Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1049();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1054Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1054();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1059Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1059();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1069Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1069();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1074Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1074();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1079Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1079();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1084();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1089Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1089();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1094Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1094();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1099Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1099();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1104Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1104();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1109Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1109();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1114Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1114();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1119Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1119();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1124Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1124();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1134Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1139Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1149Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1154Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1154();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1159Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1159();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1164Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1164();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1169Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1169();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1174Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1174();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1179Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1179();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1184Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1189Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1189();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1194Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1199Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1199();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1204Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1204();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1209Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1209();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1214Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1214();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1219Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1219();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1224Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1224();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1229Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1229();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1234Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1234();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1239Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1239();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1244Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1244();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1249Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1249();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1254Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1254();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1259Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1259();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1264Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1264();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1269Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1269();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1274Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1279Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h3)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1279();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1284();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1289Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1289();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1294Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'h0)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1294();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1299Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1299();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1304Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1304();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1309Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1309();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1314Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1314();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1319Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1319();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1324Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1324();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1329Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1329();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1334Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1334();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1339Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1339();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1344Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1344();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1349Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1349();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1354Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1359Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1364Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1364();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1369Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1374Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1374();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1379Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1379();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1384Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1384();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1389Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1389();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1394Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1399Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1399();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1404Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1404();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1409Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1409();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1414Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1414();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1419Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1424Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1424();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1429Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1429();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1434Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1434();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1439Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1439();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1444Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1444();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1449Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1449();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1454Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1454();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1459Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1459();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1464Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_b);
wire [31:0] bb=32'(masked_a);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1464();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1469Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1469();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1474Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1474();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1479Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1479();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1484Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1484();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1489Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1489();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1494Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1494();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1499Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1499();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1504Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [31:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [31:0] aa=32'(masked_a);
wire [31:0] bb=32'(masked_b);
wire [32:0] extended={1'b0,aa}+{1'b0,bb}+33'(cin);
wire [31:0] native_value=extended[31:0];
assign value=native_value[0+:32];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1504();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1509Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1509();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1514Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1514();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1519Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1519();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1524Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1524();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1529Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h0)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_b);
wire [3:0] bb=4'(masked_a);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1529();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1534Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1534();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1539Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1539();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1544Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1544();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1549Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1549();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1554Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1554();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1559Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1559();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1564Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1564();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1569Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1569();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1574Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1574();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1579Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1579();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1584Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1584();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1589Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1589();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1594Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1594();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1599Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1599();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1604Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1604();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1609Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1609();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1614Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1614();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1619Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1619();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1624Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1624();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1629Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1629();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1634Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1634();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1639Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1639();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1644Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1644();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1649Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1649();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1654Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1654();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1659Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1659();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1664Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1664();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1669Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h3)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1669();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1674Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'h0)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_b);
wire [32:0] bb=33'(masked_a);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1679Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1679();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1684Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(1'b0);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1684();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1689Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1689();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1694Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1694();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1699Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [33:0] extended={1'b0,aa}+{1'b0,bb}+34'(cin);
wire [32:0] native_value=extended[32:0];
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1699();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1704Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1704();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
