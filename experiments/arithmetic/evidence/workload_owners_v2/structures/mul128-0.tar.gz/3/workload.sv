`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_8_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_8_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_8_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_9_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_10Core rtlzz_owner_10(.a(128'(rtlzz_pipe_8_s3)), .b(128'(rtlzz_pipe_9_s3)), .cin(1'b0), .value(arith_original_10));
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_8_s1 <= 128'h0;
            rtlzz_pipe_8_s2 <= 128'h0;
            rtlzz_pipe_8_s3 <= 128'h0;
            rtlzz_pipe_9_s1 <= 128'h0;
            rtlzz_pipe_9_s2 <= 128'h0;
            rtlzz_pipe_9_s3 <= 128'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_8_s1 <= mul_precision_8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_8_s2 <= rtlzz_pipe_8_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_8_s3 <= rtlzz_pipe_8_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_9_s1 <= mul_precision_9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_9_s2 <= rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_9_s3 <= rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10Core(input wire [127:0] a,input wire [127:0] b,input wire cin,output wire [255:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [255:0] aa=256'(masked_a);
wire [255:0] bb=256'(masked_b);
wire [255:0] native_value=aa*bb;
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_10();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
