`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] limb_49_146; // decl: <none>; prim: <none>
    logic [128:0] limb_49_147; // decl: <none>; prim: <none>
    logic [63:0] limb_49_148; // decl: <none>; prim: <none>
    logic [63:0] limb_49_149; // decl: <none>; prim: <none>
    logic [64:0] limb_49_150; // decl: <none>; prim: <none>
    logic [63:0] limb_49_151; // decl: <none>; prim: <none>
    logic limb_49_152; // decl: <none>; prim: <none>
    logic [63:0] limb_49_153; // decl: <none>; prim: <none>
    logic [63:0] limb_49_154; // decl: <none>; prim: <none>
    logic [64:0] limb_49_155; // decl: <none>; prim: <none>
    logic [63:0] limb_49_156; // decl: <none>; prim: <none>
    logic limb_49_157; // decl: <none>; prim: <none>
    logic limb_49_158; // decl: <none>; prim: <none>
    logic limb_49_159; // decl: <none>; prim: <none>
    logic [1:0] limb_49_160; // decl: <none>; prim: <none>
    logic limb_49_161; // decl: <none>; prim: <none>
    logic [128:0] limb_49_162; // decl: <none>; prim: <none>
    logic [128:0] limb_50_163; // decl: <none>; prim: <none>
    logic [128:0] limb_50_164; // decl: <none>; prim: <none>
    logic [63:0] limb_50_165; // decl: <none>; prim: <none>
    logic [63:0] limb_50_166; // decl: <none>; prim: <none>
    logic [64:0] limb_50_167; // decl: <none>; prim: <none>
    logic [63:0] limb_50_168; // decl: <none>; prim: <none>
    logic limb_50_169; // decl: <none>; prim: <none>
    logic [63:0] limb_50_170; // decl: <none>; prim: <none>
    logic [63:0] limb_50_171; // decl: <none>; prim: <none>
    logic [64:0] limb_50_172; // decl: <none>; prim: <none>
    logic [63:0] limb_50_173; // decl: <none>; prim: <none>
    logic limb_50_174; // decl: <none>; prim: <none>
    logic limb_50_175; // decl: <none>; prim: <none>
    logic limb_50_176; // decl: <none>; prim: <none>
    logic [1:0] limb_50_177; // decl: <none>; prim: <none>
    logic limb_50_178; // decl: <none>; prim: <none>
    logic [128:0] limb_50_179; // decl: <none>; prim: <none>
    logic [128:0] limb_51_180; // decl: <none>; prim: <none>
    logic [128:0] limb_51_181; // decl: <none>; prim: <none>
    logic [63:0] limb_51_182; // decl: <none>; prim: <none>
    logic [63:0] limb_51_183; // decl: <none>; prim: <none>
    logic [64:0] limb_51_184; // decl: <none>; prim: <none>
    logic [63:0] limb_51_185; // decl: <none>; prim: <none>
    logic limb_51_186; // decl: <none>; prim: <none>
    logic [63:0] limb_51_187; // decl: <none>; prim: <none>
    logic [63:0] limb_51_188; // decl: <none>; prim: <none>
    logic [64:0] limb_51_189; // decl: <none>; prim: <none>
    logic [63:0] limb_51_190; // decl: <none>; prim: <none>
    logic limb_51_191; // decl: <none>; prim: <none>
    logic limb_51_192; // decl: <none>; prim: <none>
    logic limb_51_193; // decl: <none>; prim: <none>
    logic [1:0] limb_51_194; // decl: <none>; prim: <none>
    logic limb_51_195; // decl: <none>; prim: <none>
    logic [128:0] limb_51_196; // decl: <none>; prim: <none>
    logic [128:0] limb_52_197; // decl: <none>; prim: <none>
    logic [128:0] limb_52_198; // decl: <none>; prim: <none>
    logic [63:0] limb_52_199; // decl: <none>; prim: <none>
    logic [63:0] limb_52_200; // decl: <none>; prim: <none>
    logic [64:0] limb_52_201; // decl: <none>; prim: <none>
    logic [63:0] limb_52_202; // decl: <none>; prim: <none>
    logic limb_52_203; // decl: <none>; prim: <none>
    logic [63:0] limb_52_204; // decl: <none>; prim: <none>
    logic [63:0] limb_52_205; // decl: <none>; prim: <none>
    logic [64:0] limb_52_206; // decl: <none>; prim: <none>
    logic [63:0] limb_52_207; // decl: <none>; prim: <none>
    logic limb_52_208; // decl: <none>; prim: <none>
    logic limb_52_209; // decl: <none>; prim: <none>
    logic limb_52_210; // decl: <none>; prim: <none>
    logic [1:0] limb_52_211; // decl: <none>; prim: <none>
    logic limb_52_212; // decl: <none>; prim: <none>
    logic [128:0] limb_52_213; // decl: <none>; prim: <none>
    logic [128:0] limb_53_214; // decl: <none>; prim: <none>
    logic [128:0] limb_53_215; // decl: <none>; prim: <none>
    logic [63:0] limb_53_216; // decl: <none>; prim: <none>
    logic [63:0] limb_53_217; // decl: <none>; prim: <none>
    logic [64:0] limb_53_218; // decl: <none>; prim: <none>
    logic [63:0] limb_53_219; // decl: <none>; prim: <none>
    logic limb_53_220; // decl: <none>; prim: <none>
    logic [63:0] limb_53_221; // decl: <none>; prim: <none>
    logic [63:0] limb_53_222; // decl: <none>; prim: <none>
    logic [64:0] limb_53_223; // decl: <none>; prim: <none>
    logic [63:0] limb_53_224; // decl: <none>; prim: <none>
    logic limb_53_225; // decl: <none>; prim: <none>
    logic limb_53_226; // decl: <none>; prim: <none>
    logic limb_53_227; // decl: <none>; prim: <none>
    logic [1:0] limb_53_228; // decl: <none>; prim: <none>
    logic limb_53_229; // decl: <none>; prim: <none>
    logic [128:0] limb_53_230; // decl: <none>; prim: <none>
    logic [128:0] limb_54_231; // decl: <none>; prim: <none>
    logic [128:0] limb_54_232; // decl: <none>; prim: <none>
    logic [63:0] limb_54_233; // decl: <none>; prim: <none>
    logic [63:0] limb_54_234; // decl: <none>; prim: <none>
    logic [64:0] limb_54_235; // decl: <none>; prim: <none>
    logic [63:0] limb_54_236; // decl: <none>; prim: <none>
    logic limb_54_237; // decl: <none>; prim: <none>
    logic [63:0] limb_54_238; // decl: <none>; prim: <none>
    logic [63:0] limb_54_239; // decl: <none>; prim: <none>
    logic [64:0] limb_54_240; // decl: <none>; prim: <none>
    logic [63:0] limb_54_241; // decl: <none>; prim: <none>
    logic limb_54_242; // decl: <none>; prim: <none>
    logic limb_54_243; // decl: <none>; prim: <none>
    logic limb_54_244; // decl: <none>; prim: <none>
    logic [1:0] limb_54_245; // decl: <none>; prim: <none>
    logic limb_54_246; // decl: <none>; prim: <none>
    logic [128:0] limb_54_247; // decl: <none>; prim: <none>
    logic [128:0] limb_55_248; // decl: <none>; prim: <none>
    logic [128:0] limb_55_249; // decl: <none>; prim: <none>
    logic [63:0] limb_55_250; // decl: <none>; prim: <none>
    logic [63:0] limb_55_251; // decl: <none>; prim: <none>
    logic [64:0] limb_55_252; // decl: <none>; prim: <none>
    logic [63:0] limb_55_253; // decl: <none>; prim: <none>
    logic limb_55_254; // decl: <none>; prim: <none>
    logic [63:0] limb_55_255; // decl: <none>; prim: <none>
    logic [63:0] limb_55_256; // decl: <none>; prim: <none>
    logic [64:0] limb_55_257; // decl: <none>; prim: <none>
    logic [63:0] limb_55_258; // decl: <none>; prim: <none>
    logic limb_55_259; // decl: <none>; prim: <none>
    logic limb_55_260; // decl: <none>; prim: <none>
    logic limb_55_261; // decl: <none>; prim: <none>
    logic [1:0] limb_55_262; // decl: <none>; prim: <none>
    logic limb_55_263; // decl: <none>; prim: <none>
    logic [128:0] limb_55_264; // decl: <none>; prim: <none>
    logic [128:0] limb_56_265; // decl: <none>; prim: <none>
    logic [128:0] limb_56_266; // decl: <none>; prim: <none>
    logic [63:0] limb_56_267; // decl: <none>; prim: <none>
    logic [63:0] limb_56_268; // decl: <none>; prim: <none>
    logic [64:0] limb_56_269; // decl: <none>; prim: <none>
    logic [63:0] limb_56_270; // decl: <none>; prim: <none>
    logic limb_56_271; // decl: <none>; prim: <none>
    logic [63:0] limb_56_272; // decl: <none>; prim: <none>
    logic [63:0] limb_56_273; // decl: <none>; prim: <none>
    logic [64:0] limb_56_274; // decl: <none>; prim: <none>
    logic [63:0] limb_56_275; // decl: <none>; prim: <none>
    logic limb_56_276; // decl: <none>; prim: <none>
    logic limb_56_277; // decl: <none>; prim: <none>
    logic limb_56_278; // decl: <none>; prim: <none>
    logic [1:0] limb_56_279; // decl: <none>; prim: <none>
    logic limb_56_280; // decl: <none>; prim: <none>
    logic [128:0] limb_56_281; // decl: <none>; prim: <none>
    logic [129:0] limb_57_282; // decl: <none>; prim: <none>
    logic [129:0] limb_57_283; // decl: <none>; prim: <none>
    logic [63:0] limb_57_284; // decl: <none>; prim: <none>
    logic [63:0] limb_57_285; // decl: <none>; prim: <none>
    logic [64:0] limb_57_286; // decl: <none>; prim: <none>
    logic [63:0] limb_57_287; // decl: <none>; prim: <none>
    logic limb_57_288; // decl: <none>; prim: <none>
    logic [63:0] limb_57_289; // decl: <none>; prim: <none>
    logic [63:0] limb_57_290; // decl: <none>; prim: <none>
    logic [64:0] limb_57_291; // decl: <none>; prim: <none>
    logic [63:0] limb_57_292; // decl: <none>; prim: <none>
    logic limb_57_293; // decl: <none>; prim: <none>
    logic [1:0] limb_57_294; // decl: <none>; prim: <none>
    logic [1:0] limb_57_295; // decl: <none>; prim: <none>
    logic [2:0] limb_57_296; // decl: <none>; prim: <none>
    logic [1:0] limb_57_297; // decl: <none>; prim: <none>
    logic [129:0] limb_57_298; // decl: <none>; prim: <none>
    logic [129:0] limb_58_299; // decl: <none>; prim: <none>
    logic [129:0] limb_58_300; // decl: <none>; prim: <none>
    logic [63:0] limb_58_301; // decl: <none>; prim: <none>
    logic [63:0] limb_58_302; // decl: <none>; prim: <none>
    logic [64:0] limb_58_303; // decl: <none>; prim: <none>
    logic [63:0] limb_58_304; // decl: <none>; prim: <none>
    logic limb_58_305; // decl: <none>; prim: <none>
    logic [63:0] limb_58_306; // decl: <none>; prim: <none>
    logic [63:0] limb_58_307; // decl: <none>; prim: <none>
    logic [64:0] limb_58_308; // decl: <none>; prim: <none>
    logic [63:0] limb_58_309; // decl: <none>; prim: <none>
    logic limb_58_310; // decl: <none>; prim: <none>
    logic [1:0] limb_58_311; // decl: <none>; prim: <none>
    logic [1:0] limb_58_312; // decl: <none>; prim: <none>
    logic [2:0] limb_58_313; // decl: <none>; prim: <none>
    logic [1:0] limb_58_314; // decl: <none>; prim: <none>
    logic [129:0] limb_58_315; // decl: <none>; prim: <none>
    logic [129:0] limb_59_316; // decl: <none>; prim: <none>
    logic [129:0] limb_59_317; // decl: <none>; prim: <none>
    logic [63:0] limb_59_318; // decl: <none>; prim: <none>
    logic [63:0] limb_59_319; // decl: <none>; prim: <none>
    logic [64:0] limb_59_320; // decl: <none>; prim: <none>
    logic [63:0] limb_59_321; // decl: <none>; prim: <none>
    logic limb_59_322; // decl: <none>; prim: <none>
    logic [63:0] limb_59_323; // decl: <none>; prim: <none>
    logic [63:0] limb_59_324; // decl: <none>; prim: <none>
    logic [64:0] limb_59_325; // decl: <none>; prim: <none>
    logic [63:0] limb_59_326; // decl: <none>; prim: <none>
    logic limb_59_327; // decl: <none>; prim: <none>
    logic [1:0] limb_59_328; // decl: <none>; prim: <none>
    logic [1:0] limb_59_329; // decl: <none>; prim: <none>
    logic [2:0] limb_59_330; // decl: <none>; prim: <none>
    logic [1:0] limb_59_331; // decl: <none>; prim: <none>
    logic [129:0] limb_59_332; // decl: <none>; prim: <none>
    logic [129:0] limb_60_333; // decl: <none>; prim: <none>
    logic [129:0] limb_60_334; // decl: <none>; prim: <none>
    logic [63:0] limb_60_335; // decl: <none>; prim: <none>
    logic [63:0] limb_60_336; // decl: <none>; prim: <none>
    logic [64:0] limb_60_337; // decl: <none>; prim: <none>
    logic [63:0] limb_60_338; // decl: <none>; prim: <none>
    logic limb_60_339; // decl: <none>; prim: <none>
    logic [63:0] limb_60_340; // decl: <none>; prim: <none>
    logic [63:0] limb_60_341; // decl: <none>; prim: <none>
    logic [64:0] limb_60_342; // decl: <none>; prim: <none>
    logic [63:0] limb_60_343; // decl: <none>; prim: <none>
    logic limb_60_344; // decl: <none>; prim: <none>
    logic [1:0] limb_60_345; // decl: <none>; prim: <none>
    logic [1:0] limb_60_346; // decl: <none>; prim: <none>
    logic [2:0] limb_60_347; // decl: <none>; prim: <none>
    logic [1:0] limb_60_348; // decl: <none>; prim: <none>
    logic [129:0] limb_60_349; // decl: <none>; prim: <none>
    logic [130:0] limb_61_350; // decl: <none>; prim: <none>
    logic [130:0] limb_61_351; // decl: <none>; prim: <none>
    logic [63:0] limb_61_352; // decl: <none>; prim: <none>
    logic [63:0] limb_61_353; // decl: <none>; prim: <none>
    logic [64:0] limb_61_354; // decl: <none>; prim: <none>
    logic [63:0] limb_61_355; // decl: <none>; prim: <none>
    logic limb_61_356; // decl: <none>; prim: <none>
    logic [63:0] limb_61_357; // decl: <none>; prim: <none>
    logic [63:0] limb_61_358; // decl: <none>; prim: <none>
    logic [64:0] limb_61_359; // decl: <none>; prim: <none>
    logic [63:0] limb_61_360; // decl: <none>; prim: <none>
    logic limb_61_361; // decl: <none>; prim: <none>
    logic [2:0] limb_61_362; // decl: <none>; prim: <none>
    logic [2:0] limb_61_363; // decl: <none>; prim: <none>
    logic [3:0] limb_61_364; // decl: <none>; prim: <none>
    logic [2:0] limb_61_365; // decl: <none>; prim: <none>
    logic [130:0] limb_61_366; // decl: <none>; prim: <none>
    logic [130:0] limb_62_367; // decl: <none>; prim: <none>
    logic [130:0] limb_62_368; // decl: <none>; prim: <none>
    logic [63:0] limb_62_369; // decl: <none>; prim: <none>
    logic [63:0] limb_62_370; // decl: <none>; prim: <none>
    logic [64:0] limb_62_371; // decl: <none>; prim: <none>
    logic [63:0] limb_62_372; // decl: <none>; prim: <none>
    logic limb_62_373; // decl: <none>; prim: <none>
    logic [63:0] limb_62_374; // decl: <none>; prim: <none>
    logic [63:0] limb_62_375; // decl: <none>; prim: <none>
    logic [64:0] limb_62_376; // decl: <none>; prim: <none>
    logic [63:0] limb_62_377; // decl: <none>; prim: <none>
    logic limb_62_378; // decl: <none>; prim: <none>
    logic [2:0] limb_62_379; // decl: <none>; prim: <none>
    logic [2:0] limb_62_380; // decl: <none>; prim: <none>
    logic [3:0] limb_62_381; // decl: <none>; prim: <none>
    logic [2:0] limb_62_382; // decl: <none>; prim: <none>
    logic [130:0] limb_62_383; // decl: <none>; prim: <none>
    logic [131:0] limb_63_384; // decl: <none>; prim: <none>
    logic [131:0] limb_63_385; // decl: <none>; prim: <none>
    logic [63:0] limb_63_386; // decl: <none>; prim: <none>
    logic [63:0] limb_63_387; // decl: <none>; prim: <none>
    logic [64:0] limb_63_388; // decl: <none>; prim: <none>
    logic [63:0] limb_63_389; // decl: <none>; prim: <none>
    logic limb_63_390; // decl: <none>; prim: <none>
    logic [63:0] limb_63_391; // decl: <none>; prim: <none>
    logic [63:0] limb_63_392; // decl: <none>; prim: <none>
    logic [64:0] limb_63_393; // decl: <none>; prim: <none>
    logic [63:0] limb_63_394; // decl: <none>; prim: <none>
    logic limb_63_395; // decl: <none>; prim: <none>
    logic [3:0] limb_63_396; // decl: <none>; prim: <none>
    logic [3:0] limb_63_397; // decl: <none>; prim: <none>
    logic [4:0] limb_63_398; // decl: <none>; prim: <none>
    logic [3:0] limb_63_399; // decl: <none>; prim: <none>
    logic [131:0] limb_63_400; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_108_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_109_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_126_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_151_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_151_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_152_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_153_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_153_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_154_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_156_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_157_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_158_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_158_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_158_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_159_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_159_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_165_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_165_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_166_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_168_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_170_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_170_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_170_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_170_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_171_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_171_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_171_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_173_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_174_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_175_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_175_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_175_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_175_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_176_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_176_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_176_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_176_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_182_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_185_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_187_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_190_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_191_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_192_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_192_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_193_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_199_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_204_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_209_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_216_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_219_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_219_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_220_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_221_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_221_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_222_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_224_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_225_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_226_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_226_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_226_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_227_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_227_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_233_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_236_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_237_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_238_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_238_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_239_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_243_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_243_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_244_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_250_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_253_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_254_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_255_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_255_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_256_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_260_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_260_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_261_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_267_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_272_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_277_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_284_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_284_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_284_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_284_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_289_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_289_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_294_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_294_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_294_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_294_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_301_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_306_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_311_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_318_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_321_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_321_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_322_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_323_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_324_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_326_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_327_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_328_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_329_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_329_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_335_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_340_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_345_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_369_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_374_s7; // decl: <none>; prim: <none>
    logic [2:0] rtlzz_pipe_379_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    assign s8_norm_add_64_v0 = limb_49_162; // decl: <none>; prim: <none>
    assign s8_norm_add_65_v0 = limb_50_179; // decl: <none>; prim: <none>
    assign s8_norm_add_66_v0 = limb_51_196; // decl: <none>; prim: <none>
    assign s8_norm_add_67_v0 = limb_52_213; // decl: <none>; prim: <none>
    assign s8_norm_add_68_v0 = limb_53_230; // decl: <none>; prim: <none>
    assign s8_norm_add_69_v0 = limb_54_247; // decl: <none>; prim: <none>
    assign s8_norm_add_70_v0 = limb_55_264; // decl: <none>; prim: <none>
    assign s8_norm_add_71_v0 = limb_56_281; // decl: <none>; prim: <none>
    assign s8_norm_add_72_v0 = limb_57_298; // decl: <none>; prim: <none>
    assign s8_norm_add_73_v0 = limb_58_315; // decl: <none>; prim: <none>
    assign s8_norm_add_74_v0 = limb_59_332; // decl: <none>; prim: <none>
    assign s8_norm_add_75_v0 = limb_60_349; // decl: <none>; prim: <none>
    assign s8_norm_add_76_v0 = limb_61_366; // decl: <none>; prim: <none>
    assign s8_norm_add_77_v0 = limb_62_383; // decl: <none>; prim: <none>
    assign s8_norm_add_78_v0 = limb_63_400; // decl: <none>; prim: <none>
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_130Core rtlzz_owner_130(.a(64'(mul_precision_98)), .b(64'(mul_precision_99)), .cin(1'b0), .value(arith_original_130));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(64'(rtlzz_pipe_100_s1)), .b(64'(rtlzz_pipe_101_s1)), .cin(1'b0), .value(arith_original_131));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_132Core rtlzz_owner_132(.a(64'(rtlzz_pipe_102_s2)), .b(64'(rtlzz_pipe_103_s2)), .cin(1'b0), .value(arith_original_132));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_133Core rtlzz_owner_133(.a(64'(rtlzz_pipe_104_s3)), .b(64'(rtlzz_pipe_105_s3)), .cin(1'b0), .value(arith_original_133));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_134Core rtlzz_owner_134(.a(64'(rtlzz_pipe_106_s4)), .b(64'(rtlzz_pipe_107_s4)), .cin(1'b0), .value(arith_original_134));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_135Core rtlzz_owner_135(.a(64'(rtlzz_pipe_108_s5)), .b(64'(rtlzz_pipe_109_s5)), .cin(1'b0), .value(arith_original_135));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_136Core rtlzz_owner_136(.a(64'(rtlzz_pipe_110_s6)), .b(64'(rtlzz_pipe_111_s6)), .cin(1'b0), .value(arith_original_136));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_137Core rtlzz_owner_137(.a(64'(rtlzz_pipe_112_s7)), .b(64'(rtlzz_pipe_113_s7)), .cin(1'b0), .value(arith_original_137));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(64'(mul_precision_114)), .b(64'(mul_precision_115)), .cin(1'b0), .value(arith_original_138));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_139Core rtlzz_owner_139(.a(64'(rtlzz_pipe_116_s1)), .b(64'(rtlzz_pipe_117_s1)), .cin(1'b0), .value(arith_original_139));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(64'(rtlzz_pipe_118_s2)), .b(64'(rtlzz_pipe_119_s2)), .cin(1'b0), .value(arith_original_140));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_141Core rtlzz_owner_141(.a(64'(rtlzz_pipe_120_s3)), .b(64'(rtlzz_pipe_121_s3)), .cin(1'b0), .value(arith_original_141));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_142Core rtlzz_owner_142(.a(64'(rtlzz_pipe_122_s4)), .b(64'(rtlzz_pipe_123_s4)), .cin(1'b0), .value(arith_original_142));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_143Core rtlzz_owner_143(.a(64'(rtlzz_pipe_124_s5)), .b(64'(rtlzz_pipe_125_s5)), .cin(1'b0), .value(arith_original_143));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_144Core rtlzz_owner_144(.a(64'(rtlzz_pipe_126_s6)), .b(64'(rtlzz_pipe_127_s6)), .cin(1'b0), .value(arith_original_144));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_145Core rtlzz_owner_145(.a(64'(rtlzz_pipe_128_s7)), .b(64'(rtlzz_pipe_129_s7)), .cin(1'b0), .value(arith_original_145));
    assign limb_49_146 = ({1'h0, s8_norm_mul_2_v0}); // decl: <none>; prim: <none>
    assign limb_49_147 = ({1'h0, s8_norm_mul_6_v0}); // decl: <none>; prim: <none>
    assign limb_49_148 = limb_49_146[63:0]; // decl: <none>; prim: <none>
    assign limb_49_149 = limb_49_147[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_150Core rtlzz_owner_150(.a(64'(rtlzz_pipe_148_s1)), .b(64'(limb_49_149)), .cin(1'h0), .value(limb_49_150));
    assign limb_49_151 = limb_49_150[63:0]; // decl: <none>; prim: <none>
    assign limb_49_152 = limb_49_150[64]; // decl: <none>; prim: <none>
    assign limb_49_153 = limb_49_146[127:64]; // decl: <none>; prim: <none>
    assign limb_49_154 = limb_49_147[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_155Core rtlzz_owner_155(.a(64'(rtlzz_pipe_153_s2)), .b(64'(rtlzz_pipe_154_s2)), .cin(rtlzz_pipe_152_s2), .value(limb_49_155));
    assign limb_49_156 = limb_49_155[63:0]; // decl: <none>; prim: <none>
    assign limb_49_157 = limb_49_155[64]; // decl: <none>; prim: <none>
    assign limb_49_158 = limb_49_146[128]; // decl: <none>; prim: <none>
    assign limb_49_159 = limb_49_147[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_160Core rtlzz_owner_160(.a(1'(rtlzz_pipe_158_s3)), .b(1'(rtlzz_pipe_159_s3)), .cin(rtlzz_pipe_157_s3), .value(limb_49_160[0:0]));
    assign limb_49_160[1:1] = '0;
    assign limb_49_161 = limb_49_160[0]; // decl: <none>; prim: <none>
    assign limb_49_162 = {limb_49_161, rtlzz_pipe_156_s3, rtlzz_pipe_151_s3}; // decl: <none>; prim: <none>
    assign limb_50_163 = ({1'h0, s8_norm_mul_10_v0}); // decl: <none>; prim: <none>
    assign limb_50_164 = ({1'h0, s8_norm_mul_14_v0}); // decl: <none>; prim: <none>
    assign limb_50_165 = limb_50_163[63:0]; // decl: <none>; prim: <none>
    assign limb_50_166 = limb_50_164[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_167Core rtlzz_owner_167(.a(64'(rtlzz_pipe_165_s4)), .b(64'(rtlzz_pipe_166_s4)), .cin(1'h0), .value(limb_50_167));
    assign limb_50_168 = limb_50_167[63:0]; // decl: <none>; prim: <none>
    assign limb_50_169 = limb_50_167[64]; // decl: <none>; prim: <none>
    assign limb_50_170 = limb_50_163[127:64]; // decl: <none>; prim: <none>
    assign limb_50_171 = limb_50_164[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_172Core rtlzz_owner_172(.a(64'(rtlzz_pipe_170_s6)), .b(64'(rtlzz_pipe_171_s6)), .cin(rtlzz_pipe_169_s6), .value(limb_50_172));
    assign limb_50_173 = limb_50_172[63:0]; // decl: <none>; prim: <none>
    assign limb_50_174 = limb_50_172[64]; // decl: <none>; prim: <none>
    assign limb_50_175 = limb_50_163[128]; // decl: <none>; prim: <none>
    assign limb_50_176 = limb_50_164[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_177Core rtlzz_owner_177(.a(1'(rtlzz_pipe_175_s7)), .b(1'(rtlzz_pipe_176_s7)), .cin(rtlzz_pipe_174_s7), .value(limb_50_177[0:0]));
    assign limb_50_177[1:1] = '0;
    assign limb_50_178 = limb_50_177[0]; // decl: <none>; prim: <none>
    assign limb_50_179 = {limb_50_178, rtlzz_pipe_173_s7, rtlzz_pipe_168_s7}; // decl: <none>; prim: <none>
    assign limb_51_180 = ({1'h0, s8_norm_mul_18_v0}); // decl: <none>; prim: <none>
    assign limb_51_181 = ({1'h0, s8_norm_mul_22_v0}); // decl: <none>; prim: <none>
    assign limb_51_182 = limb_51_180[63:0]; // decl: <none>; prim: <none>
    assign limb_51_183 = limb_51_181[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_184Core rtlzz_owner_184(.a(64'(rtlzz_pipe_182_s5)), .b(64'(limb_51_183)), .cin(1'h0), .value(limb_51_184));
    assign limb_51_185 = limb_51_184[63:0]; // decl: <none>; prim: <none>
    assign limb_51_186 = limb_51_184[64]; // decl: <none>; prim: <none>
    assign limb_51_187 = limb_51_180[127:64]; // decl: <none>; prim: <none>
    assign limb_51_188 = limb_51_181[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_189Core rtlzz_owner_189(.a(64'(rtlzz_pipe_187_s5)), .b(64'(limb_51_188)), .cin(limb_51_186), .value(limb_51_189));
    assign limb_51_190 = limb_51_189[63:0]; // decl: <none>; prim: <none>
    assign limb_51_191 = limb_51_189[64]; // decl: <none>; prim: <none>
    assign limb_51_192 = limb_51_180[128]; // decl: <none>; prim: <none>
    assign limb_51_193 = limb_51_181[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_194Core rtlzz_owner_194(.a(1'(rtlzz_pipe_192_s6)), .b(1'(rtlzz_pipe_193_s6)), .cin(rtlzz_pipe_191_s6), .value(limb_51_194[0:0]));
    assign limb_51_194[1:1] = '0;
    assign limb_51_195 = limb_51_194[0]; // decl: <none>; prim: <none>
    assign limb_51_196 = {limb_51_195, rtlzz_pipe_190_s6, rtlzz_pipe_185_s6}; // decl: <none>; prim: <none>
    assign limb_52_197 = ({1'h0, s8_norm_mul_26_v0}); // decl: <none>; prim: <none>
    assign limb_52_198 = ({1'h0, s8_norm_mul_30_v0}); // decl: <none>; prim: <none>
    assign limb_52_199 = limb_52_197[63:0]; // decl: <none>; prim: <none>
    assign limb_52_200 = limb_52_198[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_201Core rtlzz_owner_201(.a(64'(rtlzz_pipe_199_s7)), .b(64'(limb_52_200)), .cin(1'h0), .value(limb_52_201));
    assign limb_52_202 = limb_52_201[63:0]; // decl: <none>; prim: <none>
    assign limb_52_203 = limb_52_201[64]; // decl: <none>; prim: <none>
    assign limb_52_204 = limb_52_197[127:64]; // decl: <none>; prim: <none>
    assign limb_52_205 = limb_52_198[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_206Core rtlzz_owner_206(.a(64'(rtlzz_pipe_204_s7)), .b(64'(limb_52_205)), .cin(limb_52_203), .value(limb_52_206));
    assign limb_52_207 = limb_52_206[63:0]; // decl: <none>; prim: <none>
    assign limb_52_208 = limb_52_206[64]; // decl: <none>; prim: <none>
    assign limb_52_209 = limb_52_197[128]; // decl: <none>; prim: <none>
    assign limb_52_210 = limb_52_198[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_211Core rtlzz_owner_211(.a(1'(rtlzz_pipe_209_s7)), .b(1'(limb_52_210)), .cin(limb_52_208), .value(limb_52_211[0:0]));
    assign limb_52_211[1:1] = '0;
    assign limb_52_212 = limb_52_211[0]; // decl: <none>; prim: <none>
    assign limb_52_213 = {limb_52_212, limb_52_207, limb_52_202}; // decl: <none>; prim: <none>
    assign limb_53_214 = ({1'h0, s8_norm_mul_34_v0}); // decl: <none>; prim: <none>
    assign limb_53_215 = ({1'h0, s8_norm_mul_38_v0}); // decl: <none>; prim: <none>
    assign limb_53_216 = limb_53_214[63:0]; // decl: <none>; prim: <none>
    assign limb_53_217 = limb_53_215[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_218Core rtlzz_owner_218(.a(64'(rtlzz_pipe_216_s1)), .b(64'(limb_53_217)), .cin(1'h0), .value(limb_53_218));
    assign limb_53_219 = limb_53_218[63:0]; // decl: <none>; prim: <none>
    assign limb_53_220 = limb_53_218[64]; // decl: <none>; prim: <none>
    assign limb_53_221 = limb_53_214[127:64]; // decl: <none>; prim: <none>
    assign limb_53_222 = limb_53_215[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223Core rtlzz_owner_223(.a(64'(rtlzz_pipe_221_s2)), .b(64'(rtlzz_pipe_222_s2)), .cin(rtlzz_pipe_220_s2), .value(limb_53_223));
    assign limb_53_224 = limb_53_223[63:0]; // decl: <none>; prim: <none>
    assign limb_53_225 = limb_53_223[64]; // decl: <none>; prim: <none>
    assign limb_53_226 = limb_53_214[128]; // decl: <none>; prim: <none>
    assign limb_53_227 = limb_53_215[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_228Core rtlzz_owner_228(.a(1'(rtlzz_pipe_226_s3)), .b(1'(rtlzz_pipe_227_s3)), .cin(rtlzz_pipe_225_s3), .value(limb_53_228[0:0]));
    assign limb_53_228[1:1] = '0;
    assign limb_53_229 = limb_53_228[0]; // decl: <none>; prim: <none>
    assign limb_53_230 = {limb_53_229, rtlzz_pipe_224_s3, rtlzz_pipe_219_s3}; // decl: <none>; prim: <none>
    assign limb_54_231 = ({1'h0, s8_norm_mul_42_v0}); // decl: <none>; prim: <none>
    assign limb_54_232 = ({1'h0, s8_norm_mul_46_v0}); // decl: <none>; prim: <none>
    assign limb_54_233 = limb_54_231[63:0]; // decl: <none>; prim: <none>
    assign limb_54_234 = limb_54_232[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_235Core rtlzz_owner_235(.a(64'(rtlzz_pipe_233_s3)), .b(64'(limb_54_234)), .cin(1'h0), .value(limb_54_235));
    assign limb_54_236 = limb_54_235[63:0]; // decl: <none>; prim: <none>
    assign limb_54_237 = limb_54_235[64]; // decl: <none>; prim: <none>
    assign limb_54_238 = limb_54_231[127:64]; // decl: <none>; prim: <none>
    assign limb_54_239 = limb_54_232[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_240Core rtlzz_owner_240(.a(64'(rtlzz_pipe_238_s4)), .b(64'(rtlzz_pipe_239_s4)), .cin(rtlzz_pipe_237_s4), .value(limb_54_240));
    assign limb_54_241 = limb_54_240[63:0]; // decl: <none>; prim: <none>
    assign limb_54_242 = limb_54_240[64]; // decl: <none>; prim: <none>
    assign limb_54_243 = limb_54_231[128]; // decl: <none>; prim: <none>
    assign limb_54_244 = limb_54_232[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_245Core rtlzz_owner_245(.a(1'(rtlzz_pipe_243_s4)), .b(1'(rtlzz_pipe_244_s4)), .cin(limb_54_242), .value(limb_54_245[0:0]));
    assign limb_54_245[1:1] = '0;
    assign limb_54_246 = limb_54_245[0]; // decl: <none>; prim: <none>
    assign limb_54_247 = {limb_54_246, limb_54_241, rtlzz_pipe_236_s4}; // decl: <none>; prim: <none>
    assign limb_55_248 = ({1'h0, s8_norm_mul_50_v0}); // decl: <none>; prim: <none>
    assign limb_55_249 = ({1'h0, s8_norm_mul_54_v0}); // decl: <none>; prim: <none>
    assign limb_55_250 = limb_55_248[63:0]; // decl: <none>; prim: <none>
    assign limb_55_251 = limb_55_249[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_252Core rtlzz_owner_252(.a(64'(rtlzz_pipe_250_s5)), .b(64'(limb_55_251)), .cin(1'h0), .value(limb_55_252));
    assign limb_55_253 = limb_55_252[63:0]; // decl: <none>; prim: <none>
    assign limb_55_254 = limb_55_252[64]; // decl: <none>; prim: <none>
    assign limb_55_255 = limb_55_248[127:64]; // decl: <none>; prim: <none>
    assign limb_55_256 = limb_55_249[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_257Core rtlzz_owner_257(.a(64'(rtlzz_pipe_255_s6)), .b(64'(rtlzz_pipe_256_s6)), .cin(rtlzz_pipe_254_s6), .value(limb_55_257));
    assign limb_55_258 = limb_55_257[63:0]; // decl: <none>; prim: <none>
    assign limb_55_259 = limb_55_257[64]; // decl: <none>; prim: <none>
    assign limb_55_260 = limb_55_248[128]; // decl: <none>; prim: <none>
    assign limb_55_261 = limb_55_249[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_262Core rtlzz_owner_262(.a(1'(rtlzz_pipe_260_s6)), .b(1'(rtlzz_pipe_261_s6)), .cin(limb_55_259), .value(limb_55_262[0:0]));
    assign limb_55_262[1:1] = '0;
    assign limb_55_263 = limb_55_262[0]; // decl: <none>; prim: <none>
    assign limb_55_264 = {limb_55_263, limb_55_258, rtlzz_pipe_253_s6}; // decl: <none>; prim: <none>
    assign limb_56_265 = ({1'h0, s8_norm_mul_58_v0}); // decl: <none>; prim: <none>
    assign limb_56_266 = ({1'h0, s8_norm_mul_62_v0}); // decl: <none>; prim: <none>
    assign limb_56_267 = limb_56_265[63:0]; // decl: <none>; prim: <none>
    assign limb_56_268 = limb_56_266[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_269Core rtlzz_owner_269(.a(64'(rtlzz_pipe_267_s7)), .b(64'(limb_56_268)), .cin(1'h0), .value(limb_56_269));
    assign limb_56_270 = limb_56_269[63:0]; // decl: <none>; prim: <none>
    assign limb_56_271 = limb_56_269[64]; // decl: <none>; prim: <none>
    assign limb_56_272 = limb_56_265[127:64]; // decl: <none>; prim: <none>
    assign limb_56_273 = limb_56_266[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_274Core rtlzz_owner_274(.a(64'(rtlzz_pipe_272_s7)), .b(64'(limb_56_273)), .cin(limb_56_271), .value(limb_56_274));
    assign limb_56_275 = limb_56_274[63:0]; // decl: <none>; prim: <none>
    assign limb_56_276 = limb_56_274[64]; // decl: <none>; prim: <none>
    assign limb_56_277 = limb_56_265[128]; // decl: <none>; prim: <none>
    assign limb_56_278 = limb_56_266[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_279Core rtlzz_owner_279(.a(1'(rtlzz_pipe_277_s7)), .b(1'(limb_56_278)), .cin(limb_56_276), .value(limb_56_279[0:0]));
    assign limb_56_279[1:1] = '0;
    assign limb_56_280 = limb_56_279[0]; // decl: <none>; prim: <none>
    assign limb_56_281 = {limb_56_280, limb_56_275, limb_56_270}; // decl: <none>; prim: <none>
    assign limb_57_282 = ({1'h0, s8_norm_add_64_v0}); // decl: <none>; prim: <none>
    assign limb_57_283 = ({1'h0, s8_norm_add_65_v0}); // decl: <none>; prim: <none>
    assign limb_57_284 = limb_57_282[63:0]; // decl: <none>; prim: <none>
    assign limb_57_285 = limb_57_283[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_286Core rtlzz_owner_286(.a(64'(rtlzz_pipe_284_s7)), .b(64'(limb_57_285)), .cin(1'h0), .value(limb_57_286));
    assign limb_57_287 = limb_57_286[63:0]; // decl: <none>; prim: <none>
    assign limb_57_288 = limb_57_286[64]; // decl: <none>; prim: <none>
    assign limb_57_289 = limb_57_282[127:64]; // decl: <none>; prim: <none>
    assign limb_57_290 = limb_57_283[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_291Core rtlzz_owner_291(.a(64'(rtlzz_pipe_289_s7)), .b(64'(limb_57_290)), .cin(limb_57_288), .value(limb_57_291));
    assign limb_57_292 = limb_57_291[63:0]; // decl: <none>; prim: <none>
    assign limb_57_293 = limb_57_291[64]; // decl: <none>; prim: <none>
    assign limb_57_294 = limb_57_282[129:128]; // decl: <none>; prim: <none>
    assign limb_57_295 = limb_57_283[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_296Core rtlzz_owner_296(.a(2'(rtlzz_pipe_294_s7)), .b(2'(limb_57_295)), .cin(limb_57_293), .value(limb_57_296[1:0]));
    assign limb_57_296[2:2] = '0;
    assign limb_57_297 = limb_57_296[1:0]; // decl: <none>; prim: <none>
    assign limb_57_298 = {limb_57_297, limb_57_292, limb_57_287}; // decl: <none>; prim: <none>
    assign limb_58_299 = ({1'h0, s8_norm_add_66_v0}); // decl: <none>; prim: <none>
    assign limb_58_300 = ({1'h0, s8_norm_add_67_v0}); // decl: <none>; prim: <none>
    assign limb_58_301 = limb_58_299[63:0]; // decl: <none>; prim: <none>
    assign limb_58_302 = limb_58_300[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_303Core rtlzz_owner_303(.a(64'(rtlzz_pipe_301_s7)), .b(64'(limb_58_302)), .cin(1'h0), .value(limb_58_303));
    assign limb_58_304 = limb_58_303[63:0]; // decl: <none>; prim: <none>
    assign limb_58_305 = limb_58_303[64]; // decl: <none>; prim: <none>
    assign limb_58_306 = limb_58_299[127:64]; // decl: <none>; prim: <none>
    assign limb_58_307 = limb_58_300[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_308Core rtlzz_owner_308(.a(64'(rtlzz_pipe_306_s7)), .b(64'(limb_58_307)), .cin(limb_58_305), .value(limb_58_308));
    assign limb_58_309 = limb_58_308[63:0]; // decl: <none>; prim: <none>
    assign limb_58_310 = limb_58_308[64]; // decl: <none>; prim: <none>
    assign limb_58_311 = limb_58_299[129:128]; // decl: <none>; prim: <none>
    assign limb_58_312 = limb_58_300[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_313Core rtlzz_owner_313(.a(2'(rtlzz_pipe_311_s7)), .b(2'(limb_58_312)), .cin(limb_58_310), .value(limb_58_313[1:0]));
    assign limb_58_313[2:2] = '0;
    assign limb_58_314 = limb_58_313[1:0]; // decl: <none>; prim: <none>
    assign limb_58_315 = {limb_58_314, limb_58_309, limb_58_304}; // decl: <none>; prim: <none>
    assign limb_59_316 = ({1'h0, s8_norm_add_68_v0}); // decl: <none>; prim: <none>
    assign limb_59_317 = ({1'h0, s8_norm_add_69_v0}); // decl: <none>; prim: <none>
    assign limb_59_318 = limb_59_316[63:0]; // decl: <none>; prim: <none>
    assign limb_59_319 = limb_59_317[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_320Core rtlzz_owner_320(.a(64'(rtlzz_pipe_318_s4)), .b(64'(limb_59_319)), .cin(1'h0), .value(limb_59_320));
    assign limb_59_321 = limb_59_320[63:0]; // decl: <none>; prim: <none>
    assign limb_59_322 = limb_59_320[64]; // decl: <none>; prim: <none>
    assign limb_59_323 = limb_59_316[127:64]; // decl: <none>; prim: <none>
    assign limb_59_324 = limb_59_317[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_325Core rtlzz_owner_325(.a(64'(rtlzz_pipe_323_s5)), .b(64'(rtlzz_pipe_324_s5)), .cin(rtlzz_pipe_322_s5), .value(limb_59_325));
    assign limb_59_326 = limb_59_325[63:0]; // decl: <none>; prim: <none>
    assign limb_59_327 = limb_59_325[64]; // decl: <none>; prim: <none>
    assign limb_59_328 = limb_59_316[129:128]; // decl: <none>; prim: <none>
    assign limb_59_329 = limb_59_317[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_330Core rtlzz_owner_330(.a(2'(rtlzz_pipe_328_s6)), .b(2'(rtlzz_pipe_329_s6)), .cin(rtlzz_pipe_327_s6), .value(limb_59_330[1:0]));
    assign limb_59_330[2:2] = '0;
    assign limb_59_331 = limb_59_330[1:0]; // decl: <none>; prim: <none>
    assign limb_59_332 = {limb_59_331, rtlzz_pipe_326_s6, rtlzz_pipe_321_s6}; // decl: <none>; prim: <none>
    assign limb_60_333 = ({1'h0, s8_norm_add_70_v0}); // decl: <none>; prim: <none>
    assign limb_60_334 = ({1'h0, s8_norm_add_71_v0}); // decl: <none>; prim: <none>
    assign limb_60_335 = limb_60_333[63:0]; // decl: <none>; prim: <none>
    assign limb_60_336 = limb_60_334[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_337Core rtlzz_owner_337(.a(64'(rtlzz_pipe_335_s7)), .b(64'(limb_60_336)), .cin(1'h0), .value(limb_60_337));
    assign limb_60_338 = limb_60_337[63:0]; // decl: <none>; prim: <none>
    assign limb_60_339 = limb_60_337[64]; // decl: <none>; prim: <none>
    assign limb_60_340 = limb_60_333[127:64]; // decl: <none>; prim: <none>
    assign limb_60_341 = limb_60_334[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_342Core rtlzz_owner_342(.a(64'(rtlzz_pipe_340_s7)), .b(64'(limb_60_341)), .cin(limb_60_339), .value(limb_60_342));
    assign limb_60_343 = limb_60_342[63:0]; // decl: <none>; prim: <none>
    assign limb_60_344 = limb_60_342[64]; // decl: <none>; prim: <none>
    assign limb_60_345 = limb_60_333[129:128]; // decl: <none>; prim: <none>
    assign limb_60_346 = limb_60_334[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_347Core rtlzz_owner_347(.a(2'(rtlzz_pipe_345_s7)), .b(2'(limb_60_346)), .cin(limb_60_344), .value(limb_60_347[1:0]));
    assign limb_60_347[2:2] = '0;
    assign limb_60_348 = limb_60_347[1:0]; // decl: <none>; prim: <none>
    assign limb_60_349 = {limb_60_348, limb_60_343, limb_60_338}; // decl: <none>; prim: <none>
    assign limb_61_350 = ({1'h0, s8_norm_add_72_v0}); // decl: <none>; prim: <none>
    assign limb_61_351 = ({1'h0, s8_norm_add_73_v0}); // decl: <none>; prim: <none>
    assign limb_61_352 = limb_61_350[63:0]; // decl: <none>; prim: <none>
    assign limb_61_353 = limb_61_351[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_354Core rtlzz_owner_354(.a(64'(limb_61_352)), .b(64'(limb_61_353)), .cin(1'h0), .value(limb_61_354));
    assign limb_61_355 = limb_61_354[63:0]; // decl: <none>; prim: <none>
    assign limb_61_356 = limb_61_354[64]; // decl: <none>; prim: <none>
    assign limb_61_357 = limb_61_350[127:64]; // decl: <none>; prim: <none>
    assign limb_61_358 = limb_61_351[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_359Core rtlzz_owner_359(.a(64'(limb_61_357)), .b(64'(limb_61_358)), .cin(limb_61_356), .value(limb_61_359));
    assign limb_61_360 = limb_61_359[63:0]; // decl: <none>; prim: <none>
    assign limb_61_361 = limb_61_359[64]; // decl: <none>; prim: <none>
    assign limb_61_362 = limb_61_350[130:128]; // decl: <none>; prim: <none>
    assign limb_61_363 = limb_61_351[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_364Core rtlzz_owner_364(.a(3'(limb_61_362)), .b(3'(limb_61_363)), .cin(limb_61_361), .value(limb_61_364[2:0]));
    assign limb_61_364[3:3] = '0;
    assign limb_61_365 = limb_61_364[2:0]; // decl: <none>; prim: <none>
    assign limb_61_366 = {limb_61_365, limb_61_360, limb_61_355}; // decl: <none>; prim: <none>
    assign limb_62_367 = ({1'h0, s8_norm_add_74_v0}); // decl: <none>; prim: <none>
    assign limb_62_368 = ({1'h0, s8_norm_add_75_v0}); // decl: <none>; prim: <none>
    assign limb_62_369 = limb_62_367[63:0]; // decl: <none>; prim: <none>
    assign limb_62_370 = limb_62_368[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_371Core rtlzz_owner_371(.a(64'(rtlzz_pipe_369_s7)), .b(64'(limb_62_370)), .cin(1'h0), .value(limb_62_371));
    assign limb_62_372 = limb_62_371[63:0]; // decl: <none>; prim: <none>
    assign limb_62_373 = limb_62_371[64]; // decl: <none>; prim: <none>
    assign limb_62_374 = limb_62_367[127:64]; // decl: <none>; prim: <none>
    assign limb_62_375 = limb_62_368[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_376Core rtlzz_owner_376(.a(64'(rtlzz_pipe_374_s7)), .b(64'(limb_62_375)), .cin(limb_62_373), .value(limb_62_376));
    assign limb_62_377 = limb_62_376[63:0]; // decl: <none>; prim: <none>
    assign limb_62_378 = limb_62_376[64]; // decl: <none>; prim: <none>
    assign limb_62_379 = limb_62_367[130:128]; // decl: <none>; prim: <none>
    assign limb_62_380 = limb_62_368[130:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_381Core rtlzz_owner_381(.a(3'(rtlzz_pipe_379_s7)), .b(3'(limb_62_380)), .cin(limb_62_378), .value(limb_62_381[2:0]));
    assign limb_62_381[3:3] = '0;
    assign limb_62_382 = limb_62_381[2:0]; // decl: <none>; prim: <none>
    assign limb_62_383 = {limb_62_382, limb_62_377, limb_62_372}; // decl: <none>; prim: <none>
    assign limb_63_384 = ({1'h0, s8_norm_add_76_v0}); // decl: <none>; prim: <none>
    assign limb_63_385 = ({1'h0, s8_norm_add_77_v0}); // decl: <none>; prim: <none>
    assign limb_63_386 = limb_63_384[63:0]; // decl: <none>; prim: <none>
    assign limb_63_387 = limb_63_385[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_388Core rtlzz_owner_388(.a(64'(limb_63_386)), .b(64'(limb_63_387)), .cin(1'h0), .value(limb_63_388));
    assign limb_63_389 = limb_63_388[63:0]; // decl: <none>; prim: <none>
    assign limb_63_390 = limb_63_388[64]; // decl: <none>; prim: <none>
    assign limb_63_391 = limb_63_384[127:64]; // decl: <none>; prim: <none>
    assign limb_63_392 = limb_63_385[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_393Core rtlzz_owner_393(.a(64'(limb_63_391)), .b(64'(limb_63_392)), .cin(limb_63_390), .value(limb_63_393));
    assign limb_63_394 = limb_63_393[63:0]; // decl: <none>; prim: <none>
    assign limb_63_395 = limb_63_393[64]; // decl: <none>; prim: <none>
    assign limb_63_396 = limb_63_384[131:128]; // decl: <none>; prim: <none>
    assign limb_63_397 = limb_63_385[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(4'(limb_63_396)), .b(4'(limb_63_397)), .cin(limb_63_395), .value(limb_63_398[3:0]));
    assign limb_63_398[4:4] = '0;
    assign limb_63_399 = limb_63_398[3:0]; // decl: <none>; prim: <none>
    assign limb_63_400 = {limb_63_399, limb_63_394, limb_63_389}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_104_s1 <= 64'h0;
            rtlzz_pipe_104_s2 <= 64'h0;
            rtlzz_pipe_104_s3 <= 64'h0;
            rtlzz_pipe_105_s1 <= 64'h0;
            rtlzz_pipe_105_s2 <= 64'h0;
            rtlzz_pipe_105_s3 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_106_s4 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_107_s4 <= 64'h0;
            rtlzz_pipe_108_s1 <= 64'h0;
            rtlzz_pipe_108_s2 <= 64'h0;
            rtlzz_pipe_108_s3 <= 64'h0;
            rtlzz_pipe_108_s4 <= 64'h0;
            rtlzz_pipe_108_s5 <= 64'h0;
            rtlzz_pipe_109_s1 <= 64'h0;
            rtlzz_pipe_109_s2 <= 64'h0;
            rtlzz_pipe_109_s3 <= 64'h0;
            rtlzz_pipe_109_s4 <= 64'h0;
            rtlzz_pipe_109_s5 <= 64'h0;
            rtlzz_pipe_110_s1 <= 64'h0;
            rtlzz_pipe_110_s2 <= 64'h0;
            rtlzz_pipe_110_s3 <= 64'h0;
            rtlzz_pipe_110_s4 <= 64'h0;
            rtlzz_pipe_110_s5 <= 64'h0;
            rtlzz_pipe_110_s6 <= 64'h0;
            rtlzz_pipe_111_s1 <= 64'h0;
            rtlzz_pipe_111_s2 <= 64'h0;
            rtlzz_pipe_111_s3 <= 64'h0;
            rtlzz_pipe_111_s4 <= 64'h0;
            rtlzz_pipe_111_s5 <= 64'h0;
            rtlzz_pipe_111_s6 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_112_s3 <= 64'h0;
            rtlzz_pipe_112_s4 <= 64'h0;
            rtlzz_pipe_112_s5 <= 64'h0;
            rtlzz_pipe_112_s6 <= 64'h0;
            rtlzz_pipe_112_s7 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_113_s3 <= 64'h0;
            rtlzz_pipe_113_s4 <= 64'h0;
            rtlzz_pipe_113_s5 <= 64'h0;
            rtlzz_pipe_113_s6 <= 64'h0;
            rtlzz_pipe_113_s7 <= 64'h0;
            rtlzz_pipe_116_s1 <= 64'h0;
            rtlzz_pipe_117_s1 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_118_s2 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_119_s2 <= 64'h0;
            rtlzz_pipe_120_s1 <= 64'h0;
            rtlzz_pipe_120_s2 <= 64'h0;
            rtlzz_pipe_120_s3 <= 64'h0;
            rtlzz_pipe_121_s1 <= 64'h0;
            rtlzz_pipe_121_s2 <= 64'h0;
            rtlzz_pipe_121_s3 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_122_s4 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_123_s4 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_126_s1 <= 64'h0;
            rtlzz_pipe_126_s2 <= 64'h0;
            rtlzz_pipe_126_s3 <= 64'h0;
            rtlzz_pipe_126_s4 <= 64'h0;
            rtlzz_pipe_126_s5 <= 64'h0;
            rtlzz_pipe_126_s6 <= 64'h0;
            rtlzz_pipe_127_s1 <= 64'h0;
            rtlzz_pipe_127_s2 <= 64'h0;
            rtlzz_pipe_127_s3 <= 64'h0;
            rtlzz_pipe_127_s4 <= 64'h0;
            rtlzz_pipe_127_s5 <= 64'h0;
            rtlzz_pipe_127_s6 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_128_s2 <= 64'h0;
            rtlzz_pipe_128_s3 <= 64'h0;
            rtlzz_pipe_128_s4 <= 64'h0;
            rtlzz_pipe_128_s5 <= 64'h0;
            rtlzz_pipe_128_s6 <= 64'h0;
            rtlzz_pipe_128_s7 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_129_s2 <= 64'h0;
            rtlzz_pipe_129_s3 <= 64'h0;
            rtlzz_pipe_129_s4 <= 64'h0;
            rtlzz_pipe_129_s5 <= 64'h0;
            rtlzz_pipe_129_s6 <= 64'h0;
            rtlzz_pipe_129_s7 <= 64'h0;
            rtlzz_pipe_148_s1 <= 64'h0;
            rtlzz_pipe_151_s2 <= 64'h0;
            rtlzz_pipe_151_s3 <= 64'h0;
            rtlzz_pipe_152_s2 <= 1'h0;
            rtlzz_pipe_153_s1 <= 64'h0;
            rtlzz_pipe_153_s2 <= 64'h0;
            rtlzz_pipe_154_s2 <= 64'h0;
            rtlzz_pipe_156_s3 <= 64'h0;
            rtlzz_pipe_157_s3 <= 1'h0;
            rtlzz_pipe_158_s1 <= 1'h0;
            rtlzz_pipe_158_s2 <= 1'h0;
            rtlzz_pipe_158_s3 <= 1'h0;
            rtlzz_pipe_159_s2 <= 1'h0;
            rtlzz_pipe_159_s3 <= 1'h0;
            rtlzz_pipe_165_s3 <= 64'h0;
            rtlzz_pipe_165_s4 <= 64'h0;
            rtlzz_pipe_166_s4 <= 64'h0;
            rtlzz_pipe_168_s5 <= 64'h0;
            rtlzz_pipe_168_s6 <= 64'h0;
            rtlzz_pipe_168_s7 <= 64'h0;
            rtlzz_pipe_169_s5 <= 1'h0;
            rtlzz_pipe_169_s6 <= 1'h0;
            rtlzz_pipe_170_s3 <= 64'h0;
            rtlzz_pipe_170_s4 <= 64'h0;
            rtlzz_pipe_170_s5 <= 64'h0;
            rtlzz_pipe_170_s6 <= 64'h0;
            rtlzz_pipe_171_s4 <= 64'h0;
            rtlzz_pipe_171_s5 <= 64'h0;
            rtlzz_pipe_171_s6 <= 64'h0;
            rtlzz_pipe_173_s7 <= 64'h0;
            rtlzz_pipe_174_s7 <= 1'h0;
            rtlzz_pipe_175_s3 <= 1'h0;
            rtlzz_pipe_175_s4 <= 1'h0;
            rtlzz_pipe_175_s5 <= 1'h0;
            rtlzz_pipe_175_s6 <= 1'h0;
            rtlzz_pipe_175_s7 <= 1'h0;
            rtlzz_pipe_176_s4 <= 1'h0;
            rtlzz_pipe_176_s5 <= 1'h0;
            rtlzz_pipe_176_s6 <= 1'h0;
            rtlzz_pipe_176_s7 <= 1'h0;
            rtlzz_pipe_182_s5 <= 64'h0;
            rtlzz_pipe_185_s6 <= 64'h0;
            rtlzz_pipe_187_s5 <= 64'h0;
            rtlzz_pipe_190_s6 <= 64'h0;
            rtlzz_pipe_191_s6 <= 1'h0;
            rtlzz_pipe_192_s5 <= 1'h0;
            rtlzz_pipe_192_s6 <= 1'h0;
            rtlzz_pipe_193_s6 <= 1'h0;
            rtlzz_pipe_199_s7 <= 64'h0;
            rtlzz_pipe_204_s7 <= 64'h0;
            rtlzz_pipe_209_s7 <= 1'h0;
            rtlzz_pipe_216_s1 <= 64'h0;
            rtlzz_pipe_219_s2 <= 64'h0;
            rtlzz_pipe_219_s3 <= 64'h0;
            rtlzz_pipe_220_s2 <= 1'h0;
            rtlzz_pipe_221_s1 <= 64'h0;
            rtlzz_pipe_221_s2 <= 64'h0;
            rtlzz_pipe_222_s2 <= 64'h0;
            rtlzz_pipe_224_s3 <= 64'h0;
            rtlzz_pipe_225_s3 <= 1'h0;
            rtlzz_pipe_226_s1 <= 1'h0;
            rtlzz_pipe_226_s2 <= 1'h0;
            rtlzz_pipe_226_s3 <= 1'h0;
            rtlzz_pipe_227_s2 <= 1'h0;
            rtlzz_pipe_227_s3 <= 1'h0;
            rtlzz_pipe_233_s3 <= 64'h0;
            rtlzz_pipe_236_s4 <= 64'h0;
            rtlzz_pipe_237_s4 <= 1'h0;
            rtlzz_pipe_238_s3 <= 64'h0;
            rtlzz_pipe_238_s4 <= 64'h0;
            rtlzz_pipe_239_s4 <= 64'h0;
            rtlzz_pipe_243_s3 <= 1'h0;
            rtlzz_pipe_243_s4 <= 1'h0;
            rtlzz_pipe_244_s4 <= 1'h0;
            rtlzz_pipe_250_s5 <= 64'h0;
            rtlzz_pipe_253_s6 <= 64'h0;
            rtlzz_pipe_254_s6 <= 1'h0;
            rtlzz_pipe_255_s5 <= 64'h0;
            rtlzz_pipe_255_s6 <= 64'h0;
            rtlzz_pipe_256_s6 <= 64'h0;
            rtlzz_pipe_260_s5 <= 1'h0;
            rtlzz_pipe_260_s6 <= 1'h0;
            rtlzz_pipe_261_s6 <= 1'h0;
            rtlzz_pipe_267_s7 <= 64'h0;
            rtlzz_pipe_272_s7 <= 64'h0;
            rtlzz_pipe_277_s7 <= 1'h0;
            rtlzz_pipe_284_s4 <= 64'h0;
            rtlzz_pipe_284_s5 <= 64'h0;
            rtlzz_pipe_284_s6 <= 64'h0;
            rtlzz_pipe_284_s7 <= 64'h0;
            rtlzz_pipe_289_s4 <= 64'h0;
            rtlzz_pipe_289_s5 <= 64'h0;
            rtlzz_pipe_289_s6 <= 64'h0;
            rtlzz_pipe_289_s7 <= 64'h0;
            rtlzz_pipe_294_s4 <= 2'h0;
            rtlzz_pipe_294_s5 <= 2'h0;
            rtlzz_pipe_294_s6 <= 2'h0;
            rtlzz_pipe_294_s7 <= 2'h0;
            rtlzz_pipe_301_s7 <= 64'h0;
            rtlzz_pipe_306_s7 <= 64'h0;
            rtlzz_pipe_311_s7 <= 2'h0;
            rtlzz_pipe_318_s4 <= 64'h0;
            rtlzz_pipe_321_s5 <= 64'h0;
            rtlzz_pipe_321_s6 <= 64'h0;
            rtlzz_pipe_322_s5 <= 1'h0;
            rtlzz_pipe_323_s4 <= 64'h0;
            rtlzz_pipe_323_s5 <= 64'h0;
            rtlzz_pipe_324_s5 <= 64'h0;
            rtlzz_pipe_326_s6 <= 64'h0;
            rtlzz_pipe_327_s6 <= 1'h0;
            rtlzz_pipe_328_s4 <= 2'h0;
            rtlzz_pipe_328_s5 <= 2'h0;
            rtlzz_pipe_328_s6 <= 2'h0;
            rtlzz_pipe_329_s5 <= 2'h0;
            rtlzz_pipe_329_s6 <= 2'h0;
            rtlzz_pipe_335_s7 <= 64'h0;
            rtlzz_pipe_340_s7 <= 64'h0;
            rtlzz_pipe_345_s7 <= 2'h0;
            rtlzz_pipe_369_s7 <= 64'h0;
            rtlzz_pipe_374_s7 <= 64'h0;
            rtlzz_pipe_379_s7 <= 3'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_104_s1 <= mul_precision_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_104_s3 <= rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_precision_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_105_s2 <= rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_105_s3 <= rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_106_s4 <= rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_107_s4 <= rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_108_s1 <= mul_precision_108; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_108_s2 <= rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_108_s3 <= rtlzz_pipe_108_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_108_s4 <= rtlzz_pipe_108_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_108_s5 <= rtlzz_pipe_108_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_109_s1 <= mul_precision_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= rtlzz_pipe_109_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_109_s4 <= rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_109_s5 <= rtlzz_pipe_109_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_110_s1 <= mul_precision_110; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_110_s2 <= rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_110_s3 <= rtlzz_pipe_110_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_110_s4 <= rtlzz_pipe_110_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_110_s5 <= rtlzz_pipe_110_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_110_s6 <= rtlzz_pipe_110_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_precision_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_111_s2 <= rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_111_s3 <= rtlzz_pipe_111_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_111_s4 <= rtlzz_pipe_111_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_111_s5 <= rtlzz_pipe_111_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= rtlzz_pipe_111_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_112_s3 <= rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_112_s4 <= rtlzz_pipe_112_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_112_s5 <= rtlzz_pipe_112_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_112_s6 <= rtlzz_pipe_112_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_112_s7 <= rtlzz_pipe_112_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_113_s3 <= rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_113_s4 <= rtlzz_pipe_113_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_113_s5 <= rtlzz_pipe_113_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_113_s6 <= rtlzz_pipe_113_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_113_s7 <= rtlzz_pipe_113_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_116_s1 <= mul_precision_116; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_precision_117; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_118_s2 <= rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_119_s2 <= rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_120_s1 <= mul_precision_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_120_s2 <= rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_120_s3 <= rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_precision_121; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_121_s2 <= rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_121_s3 <= rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_122_s4 <= rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_123_s4 <= rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_126_s1 <= mul_precision_126; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_126_s2 <= rtlzz_pipe_126_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_126_s3 <= rtlzz_pipe_126_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_126_s4 <= rtlzz_pipe_126_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_126_s5 <= rtlzz_pipe_126_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_126_s6 <= rtlzz_pipe_126_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_127_s1 <= mul_precision_127; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_127_s2 <= rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_127_s3 <= rtlzz_pipe_127_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_127_s4 <= rtlzz_pipe_127_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_127_s5 <= rtlzz_pipe_127_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_127_s6 <= rtlzz_pipe_127_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_128_s2 <= rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_128_s3 <= rtlzz_pipe_128_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_128_s4 <= rtlzz_pipe_128_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_128_s5 <= rtlzz_pipe_128_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_128_s6 <= rtlzz_pipe_128_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_128_s7 <= rtlzz_pipe_128_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_129_s2 <= rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_129_s3 <= rtlzz_pipe_129_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_129_s4 <= rtlzz_pipe_129_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_129_s5 <= rtlzz_pipe_129_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_129_s6 <= rtlzz_pipe_129_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_129_s7 <= rtlzz_pipe_129_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= limb_49_148; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_151_s2 <= limb_49_151; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_151_s3 <= rtlzz_pipe_151_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_152_s2 <= limb_49_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_153_s1 <= limb_49_153; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_153_s2 <= rtlzz_pipe_153_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_154_s2 <= limb_49_154; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_156_s3 <= limb_49_156; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_157_s3 <= limb_49_157; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_158_s1 <= limb_49_158; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_158_s2 <= rtlzz_pipe_158_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_158_s3 <= rtlzz_pipe_158_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_159_s2 <= limb_49_159; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_159_s3 <= rtlzz_pipe_159_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_165_s3 <= limb_50_165; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_165_s4 <= rtlzz_pipe_165_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_166_s4 <= limb_50_166; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_168_s5 <= limb_50_168; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_168_s6 <= rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_168_s7 <= rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_169_s5 <= limb_50_169; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_170_s3 <= limb_50_170; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_170_s4 <= rtlzz_pipe_170_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_170_s5 <= rtlzz_pipe_170_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_170_s6 <= rtlzz_pipe_170_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_171_s4 <= limb_50_171; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_171_s5 <= rtlzz_pipe_171_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_171_s6 <= rtlzz_pipe_171_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_173_s7 <= limb_50_173; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_174_s7 <= limb_50_174; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_175_s3 <= limb_50_175; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_175_s4 <= rtlzz_pipe_175_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_175_s5 <= rtlzz_pipe_175_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_175_s6 <= rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_175_s7 <= rtlzz_pipe_175_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_176_s4 <= limb_50_176; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_176_s5 <= rtlzz_pipe_176_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_176_s6 <= rtlzz_pipe_176_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_176_s7 <= rtlzz_pipe_176_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_182_s5 <= limb_51_182; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_185_s6 <= limb_51_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_187_s5 <= limb_51_187; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_190_s6 <= limb_51_190; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_191_s6 <= limb_51_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_192_s5 <= limb_51_192; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_192_s6 <= rtlzz_pipe_192_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_193_s6 <= limb_51_193; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_199_s7 <= limb_52_199; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_204_s7 <= limb_52_204; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_209_s7 <= limb_52_209; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_216_s1 <= limb_53_216; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_219_s2 <= limb_53_219; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_219_s3 <= rtlzz_pipe_219_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_220_s2 <= limb_53_220; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_221_s1 <= limb_53_221; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_221_s2 <= rtlzz_pipe_221_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_222_s2 <= limb_53_222; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_224_s3 <= limb_53_224; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_225_s3 <= limb_53_225; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_226_s1 <= limb_53_226; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_226_s2 <= rtlzz_pipe_226_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_226_s3 <= rtlzz_pipe_226_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_227_s2 <= limb_53_227; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_227_s3 <= rtlzz_pipe_227_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_233_s3 <= limb_54_233; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_236_s4 <= limb_54_236; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_237_s4 <= limb_54_237; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_238_s3 <= limb_54_238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_238_s4 <= rtlzz_pipe_238_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_239_s4 <= limb_54_239; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_243_s3 <= limb_54_243; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_243_s4 <= rtlzz_pipe_243_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_244_s4 <= limb_54_244; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_250_s5 <= limb_55_250; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_253_s6 <= limb_55_253; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_254_s6 <= limb_55_254; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_255_s5 <= limb_55_255; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_255_s6 <= rtlzz_pipe_255_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_256_s6 <= limb_55_256; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_260_s5 <= limb_55_260; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_260_s6 <= rtlzz_pipe_260_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_261_s6 <= limb_55_261; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_267_s7 <= limb_56_267; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_272_s7 <= limb_56_272; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_277_s7 <= limb_56_277; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_284_s4 <= limb_57_284; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_284_s5 <= rtlzz_pipe_284_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_284_s6 <= rtlzz_pipe_284_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_284_s7 <= rtlzz_pipe_284_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_289_s4 <= limb_57_289; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_289_s6 <= rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_289_s7 <= rtlzz_pipe_289_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_294_s4 <= limb_57_294; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_294_s5 <= rtlzz_pipe_294_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_294_s6 <= rtlzz_pipe_294_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_294_s7 <= rtlzz_pipe_294_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_301_s7 <= limb_58_301; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_306_s7 <= limb_58_306; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_311_s7 <= limb_58_311; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_318_s4 <= limb_59_318; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_321_s5 <= limb_59_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_321_s6 <= rtlzz_pipe_321_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_322_s5 <= limb_59_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_323_s4 <= limb_59_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_323_s5 <= rtlzz_pipe_323_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_324_s5 <= limb_59_324; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_326_s6 <= limb_59_326; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_327_s6 <= limb_59_327; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= limb_59_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_328_s5 <= rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_328_s6 <= rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_329_s5 <= limb_59_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_329_s6 <= rtlzz_pipe_329_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_335_s7 <= limb_60_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_340_s7 <= limb_60_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_345_s7 <= limb_60_345; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_369_s7 <= limb_62_369; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_374_s7 <= limb_62_374; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_379_s7 <= limb_62_379; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_132();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_133();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_134();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_136();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_137();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_139();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_141();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_142();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_143();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_144();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_145();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_167();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_172();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_177Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_177();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_184();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_189Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_189();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_194();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_201();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_206();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_211Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_211();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_218();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_228();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_235Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_235();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_245Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_245();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_252();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_257Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_257();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_262();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_269();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_274();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_279();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_286();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_291();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_296Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_296();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_303();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_308();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_313();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_320();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_337();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_342();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h1)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_347();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_354();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_359();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_364();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_371Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_371();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_376();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381Core(input wire [2:0] a,input wire [2:0] b,input wire cin,output wire [2:0] value);
wire [2:0] masked_a=((a&3'h3)|3'h0);
wire [2:0] masked_b=((b&3'h3)|3'h0);
wire [2:0] aa=3'(masked_a);
wire [2:0] bb=3'(masked_b);
wire [3:0] extended={1'b0,aa}+{1'b0,bb}+4'(cin);
wire [2:0] native_value=extended[2:0];
assign value=native_value[0+:3];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_381();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_388();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_393();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h7)|4'h0);
wire [3:0] masked_b=((b&4'h7)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
