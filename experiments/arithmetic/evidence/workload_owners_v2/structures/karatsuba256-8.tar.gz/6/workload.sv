`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_360; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_361; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_362; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_363; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_364; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_365; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_366; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_367; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_368; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_369; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_373; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_374; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_375; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_376; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_377; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_378; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_379; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_382; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_383; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_384; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_385; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_386; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_387; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_388; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_389; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_390; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_391; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_392; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_393; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_394; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_398; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_399; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_400; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_401; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_402; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_403; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_404; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_405; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_406; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_407; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_408; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_409; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_410; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_411; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_345_412; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_413; // decl: <none>; prim: <none>
    logic mul_tree_345_414; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_415; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_416; // decl: <none>; prim: <none>
    logic mul_tree_345_417; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_418; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_419; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_420; // decl: <none>; prim: <none>
    logic mul_tree_345_421; // decl: <none>; prim: <none>
    logic mul_tree_345_422; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_345_423; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_424; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_425; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_426; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_427; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_428; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_429; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_430; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_431; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_432; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_433; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_434; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_435; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_436; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_346_437; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_438; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_439; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_347_440; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_441; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_442; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_443; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_444; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_446; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_447; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_448; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_449; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_450; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_347_451; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_452; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_453; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_454; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_455; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_456; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_457; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_458; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_459; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_460; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_461; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_462; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_463; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_464; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_465; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_466; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_467; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_468; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_469; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_471; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_472; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_476; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_477; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_478; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_479; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_480; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_481; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_482; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_483; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_484; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_485; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_486; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_487; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_488; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_489; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_490; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_491; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_492; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_493; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_494; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_496; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_497; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_501; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_502; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_503; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_504; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_505; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_506; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_507; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_508; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_509; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_510; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_511; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_512; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_513; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_514; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_350_515; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_516; // decl: <none>; prim: <none>
    logic mul_tree_350_517; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_518; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_519; // decl: <none>; prim: <none>
    logic mul_tree_350_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_521; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_522; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_523; // decl: <none>; prim: <none>
    logic mul_tree_350_524; // decl: <none>; prim: <none>
    logic mul_tree_350_525; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_350_526; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_527; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_528; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_529; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_530; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_531; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_532; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_533; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_534; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_535; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_536; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_537; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_538; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_539; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_351_540; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_541; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_542; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_352_543; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_544; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_545; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_546; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_547; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_548; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_549; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_550; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_551; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_552; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_553; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_352_554; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_555; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_556; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_557; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_558; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_559; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_560; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_561; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_562; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_563; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_564; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_565; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_566; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_567; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_353_568; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_569; // decl: <none>; prim: <none>
    logic mul_tree_353_570; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_571; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_572; // decl: <none>; prim: <none>
    logic mul_tree_353_573; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_574; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_575; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_576; // decl: <none>; prim: <none>
    logic mul_tree_353_577; // decl: <none>; prim: <none>
    logic mul_tree_353_578; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_353_579; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_580; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_581; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_582; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_583; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_584; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_585; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_586; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_587; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_588; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_589; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_590; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_591; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_592; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_354_593; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_594; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_595; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_355_596; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_597; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_598; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_599; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_600; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_601; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_602; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_603; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_604; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_605; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_606; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_355_607; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_608; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_609; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_610; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_611; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_612; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_613; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_614; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_615; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_616; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_617; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_618; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_619; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_620; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_621; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_622; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_623; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_624; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_625; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_626; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_627; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_628; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_629; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_630; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_631; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_632; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_633; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_634; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_635; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_636; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_637; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_638; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_639; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_640; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_641; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_642; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_643; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_644; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_645; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_357_646; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_647; // decl: <none>; prim: <none>
    logic mul_tree_357_648; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_649; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_650; // decl: <none>; prim: <none>
    logic mul_tree_357_651; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_652; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_653; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_654; // decl: <none>; prim: <none>
    logic mul_tree_357_655; // decl: <none>; prim: <none>
    logic mul_tree_357_656; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_357_657; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_658; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_659; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_660; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_661; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_662; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_663; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_664; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_665; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_666; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_667; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_668; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_669; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_670; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_358_671; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_672; // decl: <none>; prim: <none>
    logic mul_tree_358_673; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_674; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_675; // decl: <none>; prim: <none>
    logic mul_tree_358_676; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_677; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_678; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_679; // decl: <none>; prim: <none>
    logic mul_tree_358_680; // decl: <none>; prim: <none>
    logic mul_tree_358_681; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_358_682; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_683; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_684; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_685; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_686; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_687; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_688; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_689; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_690; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_691; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_692; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_693; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_694; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_695; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_359_696; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_697; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_698; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_699; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_700; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_701; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_702; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_703; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_704; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_705; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_706; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_359_707; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_708; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_709; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_710; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_711; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_712; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_713; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_714; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_715; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_716; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_717; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_718; // decl: <none>; prim: <none>
    logic [63:0] limb_13_719; // decl: <none>; prim: <none>
    logic [63:0] limb_13_720; // decl: <none>; prim: <none>
    logic [64:0] limb_13_721; // decl: <none>; prim: <none>
    logic [63:0] limb_13_722; // decl: <none>; prim: <none>
    logic limb_13_723; // decl: <none>; prim: <none>
    logic limb_13_724; // decl: <none>; prim: <none>
    logic limb_13_725; // decl: <none>; prim: <none>
    logic [1:0] limb_13_726; // decl: <none>; prim: <none>
    logic limb_13_727; // decl: <none>; prim: <none>
    logic [64:0] limb_13_728; // decl: <none>; prim: <none>
    logic [63:0] limb_15_729; // decl: <none>; prim: <none>
    logic [63:0] limb_15_730; // decl: <none>; prim: <none>
    logic [64:0] limb_15_731; // decl: <none>; prim: <none>
    logic [63:0] limb_15_732; // decl: <none>; prim: <none>
    logic limb_15_733; // decl: <none>; prim: <none>
    logic limb_15_734; // decl: <none>; prim: <none>
    logic limb_15_735; // decl: <none>; prim: <none>
    logic [1:0] limb_15_736; // decl: <none>; prim: <none>
    logic limb_15_737; // decl: <none>; prim: <none>
    logic [64:0] limb_15_738; // decl: <none>; prim: <none>
    logic [63:0] limb_29_739; // decl: <none>; prim: <none>
    logic [63:0] limb_29_740; // decl: <none>; prim: <none>
    logic [63:0] limb_29_741; // decl: <none>; prim: <none>
    logic [64:0] limb_29_742; // decl: <none>; prim: <none>
    logic [63:0] limb_29_743; // decl: <none>; prim: <none>
    logic limb_29_744; // decl: <none>; prim: <none>
    logic [3:0] limb_29_745; // decl: <none>; prim: <none>
    logic [3:0] limb_29_746; // decl: <none>; prim: <none>
    logic [3:0] limb_29_747; // decl: <none>; prim: <none>
    logic [4:0] limb_29_748; // decl: <none>; prim: <none>
    logic [3:0] limb_29_749; // decl: <none>; prim: <none>
    logic [67:0] limb_29_750; // decl: <none>; prim: <none>
    logic [63:0] limb_31_751; // decl: <none>; prim: <none>
    logic [63:0] limb_31_752; // decl: <none>; prim: <none>
    logic [63:0] limb_31_753; // decl: <none>; prim: <none>
    logic [64:0] limb_31_754; // decl: <none>; prim: <none>
    logic [63:0] limb_31_755; // decl: <none>; prim: <none>
    logic limb_31_756; // decl: <none>; prim: <none>
    logic [3:0] limb_31_757; // decl: <none>; prim: <none>
    logic [3:0] limb_31_758; // decl: <none>; prim: <none>
    logic [3:0] limb_31_759; // decl: <none>; prim: <none>
    logic [4:0] limb_31_760; // decl: <none>; prim: <none>
    logic [3:0] limb_31_761; // decl: <none>; prim: <none>
    logic [67:0] limb_31_762; // decl: <none>; prim: <none>
    logic [63:0] limb_38_763; // decl: <none>; prim: <none>
    logic [63:0] limb_38_764; // decl: <none>; prim: <none>
    logic [63:0] limb_38_765; // decl: <none>; prim: <none>
    logic [64:0] limb_38_766; // decl: <none>; prim: <none>
    logic [63:0] limb_38_767; // decl: <none>; prim: <none>
    logic limb_38_768; // decl: <none>; prim: <none>
    logic [63:0] limb_38_769; // decl: <none>; prim: <none>
    logic [63:0] limb_38_770; // decl: <none>; prim: <none>
    logic [63:0] limb_38_771; // decl: <none>; prim: <none>
    logic [64:0] limb_38_772; // decl: <none>; prim: <none>
    logic [63:0] limb_38_773; // decl: <none>; prim: <none>
    logic limb_38_774; // decl: <none>; prim: <none>
    logic [1:0] limb_38_775; // decl: <none>; prim: <none>
    logic [1:0] limb_38_776; // decl: <none>; prim: <none>
    logic [1:0] limb_38_777; // decl: <none>; prim: <none>
    logic [2:0] limb_38_778; // decl: <none>; prim: <none>
    logic [1:0] limb_38_779; // decl: <none>; prim: <none>
    logic [129:0] limb_38_780; // decl: <none>; prim: <none>
    logic [63:0] limb_40_781; // decl: <none>; prim: <none>
    logic [63:0] limb_40_782; // decl: <none>; prim: <none>
    logic [63:0] limb_40_783; // decl: <none>; prim: <none>
    logic [64:0] limb_40_784; // decl: <none>; prim: <none>
    logic [63:0] limb_40_785; // decl: <none>; prim: <none>
    logic limb_40_786; // decl: <none>; prim: <none>
    logic [63:0] limb_40_787; // decl: <none>; prim: <none>
    logic [63:0] limb_40_788; // decl: <none>; prim: <none>
    logic [63:0] limb_40_789; // decl: <none>; prim: <none>
    logic [64:0] limb_40_790; // decl: <none>; prim: <none>
    logic [63:0] limb_40_791; // decl: <none>; prim: <none>
    logic limb_40_792; // decl: <none>; prim: <none>
    logic [1:0] limb_40_793; // decl: <none>; prim: <none>
    logic [1:0] limb_40_794; // decl: <none>; prim: <none>
    logic [1:0] limb_40_795; // decl: <none>; prim: <none>
    logic [2:0] limb_40_796; // decl: <none>; prim: <none>
    logic [1:0] limb_40_797; // decl: <none>; prim: <none>
    logic [129:0] limb_40_798; // decl: <none>; prim: <none>
    logic [63:0] limb_51_799; // decl: <none>; prim: <none>
    logic [63:0] limb_51_800; // decl: <none>; prim: <none>
    logic [64:0] limb_51_801; // decl: <none>; prim: <none>
    logic [63:0] limb_51_802; // decl: <none>; prim: <none>
    logic limb_51_803; // decl: <none>; prim: <none>
    logic limb_51_804; // decl: <none>; prim: <none>
    logic limb_51_805; // decl: <none>; prim: <none>
    logic [1:0] limb_51_806; // decl: <none>; prim: <none>
    logic limb_51_807; // decl: <none>; prim: <none>
    logic [64:0] limb_51_808; // decl: <none>; prim: <none>
    logic [63:0] limb_53_809; // decl: <none>; prim: <none>
    logic [63:0] limb_53_810; // decl: <none>; prim: <none>
    logic [64:0] limb_53_811; // decl: <none>; prim: <none>
    logic [63:0] limb_53_812; // decl: <none>; prim: <none>
    logic limb_53_813; // decl: <none>; prim: <none>
    logic limb_53_814; // decl: <none>; prim: <none>
    logic limb_53_815; // decl: <none>; prim: <none>
    logic [1:0] limb_53_816; // decl: <none>; prim: <none>
    logic limb_53_817; // decl: <none>; prim: <none>
    logic [64:0] limb_53_818; // decl: <none>; prim: <none>
    logic [63:0] limb_67_819; // decl: <none>; prim: <none>
    logic [63:0] limb_67_820; // decl: <none>; prim: <none>
    logic [63:0] limb_67_821; // decl: <none>; prim: <none>
    logic [64:0] limb_67_822; // decl: <none>; prim: <none>
    logic [63:0] limb_67_823; // decl: <none>; prim: <none>
    logic limb_67_824; // decl: <none>; prim: <none>
    logic [3:0] limb_67_825; // decl: <none>; prim: <none>
    logic [3:0] limb_67_826; // decl: <none>; prim: <none>
    logic [3:0] limb_67_827; // decl: <none>; prim: <none>
    logic [4:0] limb_67_828; // decl: <none>; prim: <none>
    logic [3:0] limb_67_829; // decl: <none>; prim: <none>
    logic [67:0] limb_67_830; // decl: <none>; prim: <none>
    logic [63:0] limb_69_831; // decl: <none>; prim: <none>
    logic [63:0] limb_69_832; // decl: <none>; prim: <none>
    logic [63:0] limb_69_833; // decl: <none>; prim: <none>
    logic [64:0] limb_69_834; // decl: <none>; prim: <none>
    logic [63:0] limb_69_835; // decl: <none>; prim: <none>
    logic limb_69_836; // decl: <none>; prim: <none>
    logic [3:0] limb_69_837; // decl: <none>; prim: <none>
    logic [3:0] limb_69_838; // decl: <none>; prim: <none>
    logic [3:0] limb_69_839; // decl: <none>; prim: <none>
    logic [4:0] limb_69_840; // decl: <none>; prim: <none>
    logic [3:0] limb_69_841; // decl: <none>; prim: <none>
    logic [67:0] limb_69_842; // decl: <none>; prim: <none>
    logic [63:0] limb_76_843; // decl: <none>; prim: <none>
    logic [63:0] limb_76_844; // decl: <none>; prim: <none>
    logic [63:0] limb_76_845; // decl: <none>; prim: <none>
    logic [64:0] limb_76_846; // decl: <none>; prim: <none>
    logic [63:0] limb_76_847; // decl: <none>; prim: <none>
    logic limb_76_848; // decl: <none>; prim: <none>
    logic [63:0] limb_76_849; // decl: <none>; prim: <none>
    logic [63:0] limb_76_850; // decl: <none>; prim: <none>
    logic [63:0] limb_76_851; // decl: <none>; prim: <none>
    logic [64:0] limb_76_852; // decl: <none>; prim: <none>
    logic [63:0] limb_76_853; // decl: <none>; prim: <none>
    logic limb_76_854; // decl: <none>; prim: <none>
    logic [1:0] limb_76_855; // decl: <none>; prim: <none>
    logic [1:0] limb_76_856; // decl: <none>; prim: <none>
    logic [1:0] limb_76_857; // decl: <none>; prim: <none>
    logic [2:0] limb_76_858; // decl: <none>; prim: <none>
    logic [1:0] limb_76_859; // decl: <none>; prim: <none>
    logic [129:0] limb_76_860; // decl: <none>; prim: <none>
    logic [63:0] limb_78_861; // decl: <none>; prim: <none>
    logic [63:0] limb_78_862; // decl: <none>; prim: <none>
    logic [63:0] limb_78_863; // decl: <none>; prim: <none>
    logic [64:0] limb_78_864; // decl: <none>; prim: <none>
    logic [63:0] limb_78_865; // decl: <none>; prim: <none>
    logic limb_78_866; // decl: <none>; prim: <none>
    logic [63:0] limb_78_867; // decl: <none>; prim: <none>
    logic [63:0] limb_78_868; // decl: <none>; prim: <none>
    logic [63:0] limb_78_869; // decl: <none>; prim: <none>
    logic [64:0] limb_78_870; // decl: <none>; prim: <none>
    logic [63:0] limb_78_871; // decl: <none>; prim: <none>
    logic limb_78_872; // decl: <none>; prim: <none>
    logic [1:0] limb_78_873; // decl: <none>; prim: <none>
    logic [1:0] limb_78_874; // decl: <none>; prim: <none>
    logic [1:0] limb_78_875; // decl: <none>; prim: <none>
    logic [2:0] limb_78_876; // decl: <none>; prim: <none>
    logic [1:0] limb_78_877; // decl: <none>; prim: <none>
    logic [129:0] limb_78_878; // decl: <none>; prim: <none>
    logic [63:0] limb_85_879; // decl: <none>; prim: <none>
    logic [63:0] limb_85_880; // decl: <none>; prim: <none>
    logic [64:0] limb_85_881; // decl: <none>; prim: <none>
    logic [63:0] limb_85_882; // decl: <none>; prim: <none>
    logic limb_85_883; // decl: <none>; prim: <none>
    logic [63:0] limb_85_884; // decl: <none>; prim: <none>
    logic [63:0] limb_85_885; // decl: <none>; prim: <none>
    logic [64:0] limb_85_886; // decl: <none>; prim: <none>
    logic [63:0] limb_85_887; // decl: <none>; prim: <none>
    logic limb_85_888; // decl: <none>; prim: <none>
    logic limb_85_889; // decl: <none>; prim: <none>
    logic limb_85_890; // decl: <none>; prim: <none>
    logic [1:0] limb_85_891; // decl: <none>; prim: <none>
    logic limb_85_892; // decl: <none>; prim: <none>
    logic [128:0] limb_85_893; // decl: <none>; prim: <none>
    logic [63:0] limb_87_894; // decl: <none>; prim: <none>
    logic [63:0] limb_87_895; // decl: <none>; prim: <none>
    logic [64:0] limb_87_896; // decl: <none>; prim: <none>
    logic [63:0] limb_87_897; // decl: <none>; prim: <none>
    logic limb_87_898; // decl: <none>; prim: <none>
    logic [63:0] limb_87_899; // decl: <none>; prim: <none>
    logic [63:0] limb_87_900; // decl: <none>; prim: <none>
    logic [64:0] limb_87_901; // decl: <none>; prim: <none>
    logic [63:0] limb_87_902; // decl: <none>; prim: <none>
    logic limb_87_903; // decl: <none>; prim: <none>
    logic limb_87_904; // decl: <none>; prim: <none>
    logic limb_87_905; // decl: <none>; prim: <none>
    logic [1:0] limb_87_906; // decl: <none>; prim: <none>
    logic limb_87_907; // decl: <none>; prim: <none>
    logic [128:0] limb_87_908; // decl: <none>; prim: <none>
    logic [63:0] limb_103_909; // decl: <none>; prim: <none>
    logic [63:0] limb_103_910; // decl: <none>; prim: <none>
    logic [63:0] limb_103_911; // decl: <none>; prim: <none>
    logic [64:0] limb_103_912; // decl: <none>; prim: <none>
    logic [63:0] limb_103_913; // decl: <none>; prim: <none>
    logic limb_103_914; // decl: <none>; prim: <none>
    logic [3:0] limb_103_915; // decl: <none>; prim: <none>
    logic [3:0] limb_103_916; // decl: <none>; prim: <none>
    logic [3:0] limb_103_917; // decl: <none>; prim: <none>
    logic [4:0] limb_103_918; // decl: <none>; prim: <none>
    logic [3:0] limb_103_919; // decl: <none>; prim: <none>
    logic [67:0] limb_103_920; // decl: <none>; prim: <none>
    logic [63:0] limb_105_921; // decl: <none>; prim: <none>
    logic [63:0] limb_105_922; // decl: <none>; prim: <none>
    logic [63:0] limb_105_923; // decl: <none>; prim: <none>
    logic [64:0] limb_105_924; // decl: <none>; prim: <none>
    logic [63:0] limb_105_925; // decl: <none>; prim: <none>
    logic limb_105_926; // decl: <none>; prim: <none>
    logic [3:0] limb_105_927; // decl: <none>; prim: <none>
    logic [3:0] limb_105_928; // decl: <none>; prim: <none>
    logic [3:0] limb_105_929; // decl: <none>; prim: <none>
    logic [4:0] limb_105_930; // decl: <none>; prim: <none>
    logic [3:0] limb_105_931; // decl: <none>; prim: <none>
    logic [67:0] limb_105_932; // decl: <none>; prim: <none>
    logic [63:0] limb_113_933; // decl: <none>; prim: <none>
    logic [63:0] limb_113_934; // decl: <none>; prim: <none>
    logic [64:0] limb_113_935; // decl: <none>; prim: <none>
    logic [63:0] limb_113_936; // decl: <none>; prim: <none>
    logic limb_113_937; // decl: <none>; prim: <none>
    logic [1:0] limb_113_938; // decl: <none>; prim: <none>
    logic [1:0] limb_113_939; // decl: <none>; prim: <none>
    logic [2:0] limb_113_940; // decl: <none>; prim: <none>
    logic [1:0] limb_113_941; // decl: <none>; prim: <none>
    logic [65:0] limb_113_942; // decl: <none>; prim: <none>
    logic [63:0] limb_115_943; // decl: <none>; prim: <none>
    logic [63:0] limb_115_944; // decl: <none>; prim: <none>
    logic [64:0] limb_115_945; // decl: <none>; prim: <none>
    logic [63:0] limb_115_946; // decl: <none>; prim: <none>
    logic limb_115_947; // decl: <none>; prim: <none>
    logic [1:0] limb_115_948; // decl: <none>; prim: <none>
    logic [1:0] limb_115_949; // decl: <none>; prim: <none>
    logic [2:0] limb_115_950; // decl: <none>; prim: <none>
    logic [1:0] limb_115_951; // decl: <none>; prim: <none>
    logic [65:0] limb_115_952; // decl: <none>; prim: <none>
    logic [63:0] limb_129_953; // decl: <none>; prim: <none>
    logic [63:0] limb_129_954; // decl: <none>; prim: <none>
    logic [63:0] limb_129_955; // decl: <none>; prim: <none>
    logic [64:0] limb_129_956; // decl: <none>; prim: <none>
    logic [63:0] limb_129_957; // decl: <none>; prim: <none>
    logic limb_129_958; // decl: <none>; prim: <none>
    logic [3:0] limb_129_959; // decl: <none>; prim: <none>
    logic [3:0] limb_129_960; // decl: <none>; prim: <none>
    logic [3:0] limb_129_961; // decl: <none>; prim: <none>
    logic [4:0] limb_129_962; // decl: <none>; prim: <none>
    logic [3:0] limb_129_963; // decl: <none>; prim: <none>
    logic [67:0] limb_129_964; // decl: <none>; prim: <none>
    logic [63:0] limb_131_965; // decl: <none>; prim: <none>
    logic [63:0] limb_131_966; // decl: <none>; prim: <none>
    logic [63:0] limb_131_967; // decl: <none>; prim: <none>
    logic [64:0] limb_131_968; // decl: <none>; prim: <none>
    logic [63:0] limb_131_969; // decl: <none>; prim: <none>
    logic limb_131_970; // decl: <none>; prim: <none>
    logic [3:0] limb_131_971; // decl: <none>; prim: <none>
    logic [3:0] limb_131_972; // decl: <none>; prim: <none>
    logic [3:0] limb_131_973; // decl: <none>; prim: <none>
    logic [4:0] limb_131_974; // decl: <none>; prim: <none>
    logic [3:0] limb_131_975; // decl: <none>; prim: <none>
    logic [67:0] limb_131_976; // decl: <none>; prim: <none>
    logic [63:0] limb_138_977; // decl: <none>; prim: <none>
    logic [63:0] limb_138_978; // decl: <none>; prim: <none>
    logic [63:0] limb_138_979; // decl: <none>; prim: <none>
    logic [64:0] limb_138_980; // decl: <none>; prim: <none>
    logic [63:0] limb_138_981; // decl: <none>; prim: <none>
    logic limb_138_982; // decl: <none>; prim: <none>
    logic [63:0] limb_138_983; // decl: <none>; prim: <none>
    logic [63:0] limb_138_984; // decl: <none>; prim: <none>
    logic [63:0] limb_138_985; // decl: <none>; prim: <none>
    logic [64:0] limb_138_986; // decl: <none>; prim: <none>
    logic [63:0] limb_138_987; // decl: <none>; prim: <none>
    logic limb_138_988; // decl: <none>; prim: <none>
    logic [3:0] limb_138_989; // decl: <none>; prim: <none>
    logic [3:0] limb_138_990; // decl: <none>; prim: <none>
    logic [3:0] limb_138_991; // decl: <none>; prim: <none>
    logic [4:0] limb_138_992; // decl: <none>; prim: <none>
    logic [3:0] limb_138_993; // decl: <none>; prim: <none>
    logic [131:0] limb_138_994; // decl: <none>; prim: <none>
    logic [63:0] limb_140_995; // decl: <none>; prim: <none>
    logic [63:0] limb_140_996; // decl: <none>; prim: <none>
    logic [63:0] limb_140_997; // decl: <none>; prim: <none>
    logic [64:0] limb_140_998; // decl: <none>; prim: <none>
    logic [63:0] limb_140_999; // decl: <none>; prim: <none>
    logic limb_140_1000; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1001; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1002; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1003; // decl: <none>; prim: <none>
    logic [64:0] limb_140_1004; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1005; // decl: <none>; prim: <none>
    logic limb_140_1006; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1007; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1008; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1009; // decl: <none>; prim: <none>
    logic [4:0] limb_140_1010; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1011; // decl: <none>; prim: <none>
    logic [131:0] limb_140_1012; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1013; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1014; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1015; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1016; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1017; // decl: <none>; prim: <none>
    logic limb_147_1018; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1019; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1020; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1021; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1022; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1023; // decl: <none>; prim: <none>
    logic limb_147_1024; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1025; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1026; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1027; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1028; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1029; // decl: <none>; prim: <none>
    logic limb_147_1030; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1031; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1032; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1033; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1034; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1035; // decl: <none>; prim: <none>
    logic limb_147_1036; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1037; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1038; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1039; // decl: <none>; prim: <none>
    logic [2:0] limb_147_1040; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1041; // decl: <none>; prim: <none>
    logic [257:0] limb_147_1042; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1043; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1044; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1045; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1046; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1047; // decl: <none>; prim: <none>
    logic limb_149_1048; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1049; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1050; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1051; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1052; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1053; // decl: <none>; prim: <none>
    logic limb_149_1054; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1055; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1056; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1057; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1058; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1059; // decl: <none>; prim: <none>
    logic limb_149_1060; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1061; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1062; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1063; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1064; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1065; // decl: <none>; prim: <none>
    logic limb_149_1066; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1067; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1068; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1069; // decl: <none>; prim: <none>
    logic [2:0] limb_149_1070; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1071; // decl: <none>; prim: <none>
    logic [257:0] limb_149_1072; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1073; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1074; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1075; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1076; // decl: <none>; prim: <none>
    logic limb_157_1077; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1078; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1079; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1080; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1081; // decl: <none>; prim: <none>
    logic limb_157_1082; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1083; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1084; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1085; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1086; // decl: <none>; prim: <none>
    logic limb_157_1087; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1088; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1089; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1090; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1091; // decl: <none>; prim: <none>
    logic limb_157_1092; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1093; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1094; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1095; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1096; // decl: <none>; prim: <none>
    logic limb_157_1097; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1098; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1099; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1100; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1101; // decl: <none>; prim: <none>
    logic limb_157_1102; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1103; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1104; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1105; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1106; // decl: <none>; prim: <none>
    logic limb_157_1107; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1108; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1109; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1110; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1111; // decl: <none>; prim: <none>
    logic limb_157_1112; // decl: <none>; prim: <none>
    logic limb_157_1113; // decl: <none>; prim: <none>
    logic limb_157_1114; // decl: <none>; prim: <none>
    logic [1:0] limb_157_1115; // decl: <none>; prim: <none>
    logic limb_157_1116; // decl: <none>; prim: <none>
    logic [512:0] limb_157_1117; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1118; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1119; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1120; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1121; // decl: <none>; prim: <none>
    logic limb_216_1122; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1123; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1124; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1125; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1126; // decl: <none>; prim: <none>
    logic limb_216_1127; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1128; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1129; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1130; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1131; // decl: <none>; prim: <none>
    logic limb_216_1132; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1133; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1134; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1135; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1136; // decl: <none>; prim: <none>
    logic limb_216_1137; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1138; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1139; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1140; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1141; // decl: <none>; prim: <none>
    logic limb_216_1142; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1143; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1144; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1145; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1146; // decl: <none>; prim: <none>
    logic limb_216_1147; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1148; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1149; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1150; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1151; // decl: <none>; prim: <none>
    logic limb_216_1152; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1153; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1154; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1155; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1156; // decl: <none>; prim: <none>
    logic [511:0] limb_216_1157; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1158; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1159; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1160; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1161; // decl: <none>; prim: <none>
    logic limb_217_1162; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1163; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1164; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1165; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1166; // decl: <none>; prim: <none>
    logic limb_217_1167; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1168; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1169; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1170; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1171; // decl: <none>; prim: <none>
    logic limb_217_1172; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1173; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1174; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1175; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1176; // decl: <none>; prim: <none>
    logic limb_217_1177; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1178; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1179; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1180; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1181; // decl: <none>; prim: <none>
    logic limb_217_1182; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1183; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1184; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1185; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1186; // decl: <none>; prim: <none>
    logic limb_217_1187; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1188; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1189; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1190; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1191; // decl: <none>; prim: <none>
    logic limb_217_1192; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1193; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1194; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1195; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1196; // decl: <none>; prim: <none>
    logic [511:0] limb_217_1197; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1198; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1199; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1200; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1201; // decl: <none>; prim: <none>
    logic limb_218_1202; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1203; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1204; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1205; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1206; // decl: <none>; prim: <none>
    logic limb_218_1207; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1208; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1209; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1210; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1211; // decl: <none>; prim: <none>
    logic limb_218_1212; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1213; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1214; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1215; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1216; // decl: <none>; prim: <none>
    logic limb_218_1217; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1218; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1219; // decl: <none>; prim: <none>
    logic [2:0] limb_218_1220; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1221; // decl: <none>; prim: <none>
    logic [257:0] limb_218_1222; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1223; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1224; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1225; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1226; // decl: <none>; prim: <none>
    logic limb_219_1227; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1228; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1229; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1230; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1231; // decl: <none>; prim: <none>
    logic limb_219_1232; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1233; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1234; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1235; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1236; // decl: <none>; prim: <none>
    logic limb_219_1237; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1238; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1239; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1240; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1241; // decl: <none>; prim: <none>
    logic limb_219_1242; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1243; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1244; // decl: <none>; prim: <none>
    logic [2:0] limb_219_1245; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1246; // decl: <none>; prim: <none>
    logic [257:0] limb_219_1247; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1248; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1249; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1250; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1251; // decl: <none>; prim: <none>
    logic limb_220_1252; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1253; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1254; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1255; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1256; // decl: <none>; prim: <none>
    logic limb_220_1257; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1258; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1259; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1260; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1261; // decl: <none>; prim: <none>
    logic limb_220_1262; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1263; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1264; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1265; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1266; // decl: <none>; prim: <none>
    logic [255:0] limb_220_1267; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1268; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1269; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1270; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1271; // decl: <none>; prim: <none>
    logic limb_221_1272; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1273; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1274; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1275; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1276; // decl: <none>; prim: <none>
    logic limb_221_1277; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1278; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1279; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1280; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1281; // decl: <none>; prim: <none>
    logic limb_221_1282; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1283; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1284; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1285; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1286; // decl: <none>; prim: <none>
    logic [255:0] limb_221_1287; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1288; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1289; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1290; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1291; // decl: <none>; prim: <none>
    logic limb_222_1292; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1293; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1294; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1295; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1296; // decl: <none>; prim: <none>
    logic limb_222_1297; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1298; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1299; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1300; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1301; // decl: <none>; prim: <none>
    logic limb_222_1302; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1303; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1304; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1305; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1306; // decl: <none>; prim: <none>
    logic [255:0] limb_222_1307; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1308; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1309; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1310; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1311; // decl: <none>; prim: <none>
    logic limb_223_1312; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1313; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1314; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1315; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1316; // decl: <none>; prim: <none>
    logic limb_223_1317; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1318; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1319; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1320; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1321; // decl: <none>; prim: <none>
    logic limb_223_1322; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1323; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1324; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1325; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1326; // decl: <none>; prim: <none>
    logic [255:0] limb_223_1327; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1328; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1329; // decl: <none>; prim: <none>
    logic [64:0] limb_224_1330; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1331; // decl: <none>; prim: <none>
    logic limb_224_1332; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1333; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1334; // decl: <none>; prim: <none>
    logic [64:0] limb_224_1335; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1336; // decl: <none>; prim: <none>
    logic limb_224_1337; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1338; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1339; // decl: <none>; prim: <none>
    logic [4:0] limb_224_1340; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1341; // decl: <none>; prim: <none>
    logic [131:0] limb_224_1342; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1343; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1344; // decl: <none>; prim: <none>
    logic [64:0] limb_225_1345; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1346; // decl: <none>; prim: <none>
    logic limb_225_1347; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1348; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1349; // decl: <none>; prim: <none>
    logic [64:0] limb_225_1350; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1351; // decl: <none>; prim: <none>
    logic limb_225_1352; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1353; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1354; // decl: <none>; prim: <none>
    logic [4:0] limb_225_1355; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1356; // decl: <none>; prim: <none>
    logic [131:0] limb_225_1357; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1358; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1359; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1360; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1361; // decl: <none>; prim: <none>
    logic limb_226_1362; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1363; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1364; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1365; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1366; // decl: <none>; prim: <none>
    logic limb_226_1367; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1368; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1369; // decl: <none>; prim: <none>
    logic [2:0] limb_226_1370; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1371; // decl: <none>; prim: <none>
    logic [129:0] limb_226_1372; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1373; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1374; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1375; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1376; // decl: <none>; prim: <none>
    logic limb_227_1377; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1378; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1379; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1380; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1381; // decl: <none>; prim: <none>
    logic limb_227_1382; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1383; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1384; // decl: <none>; prim: <none>
    logic [2:0] limb_227_1385; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1386; // decl: <none>; prim: <none>
    logic [129:0] limb_227_1387; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1388; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1389; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1390; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1391; // decl: <none>; prim: <none>
    logic limb_228_1392; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1393; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1394; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1395; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1396; // decl: <none>; prim: <none>
    logic limb_228_1397; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1398; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1399; // decl: <none>; prim: <none>
    logic [2:0] limb_228_1400; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1401; // decl: <none>; prim: <none>
    logic [129:0] limb_228_1402; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1403; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1404; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1405; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1406; // decl: <none>; prim: <none>
    logic limb_229_1407; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1408; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1409; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1410; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1411; // decl: <none>; prim: <none>
    logic limb_229_1412; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1413; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1414; // decl: <none>; prim: <none>
    logic [2:0] limb_229_1415; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1416; // decl: <none>; prim: <none>
    logic [129:0] limb_229_1417; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1418; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1419; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1420; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1421; // decl: <none>; prim: <none>
    logic limb_230_1422; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1423; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1424; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1425; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1426; // decl: <none>; prim: <none>
    logic limb_230_1427; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1428; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1429; // decl: <none>; prim: <none>
    logic [2:0] limb_230_1430; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1431; // decl: <none>; prim: <none>
    logic [129:0] limb_230_1432; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1433; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1434; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1435; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1436; // decl: <none>; prim: <none>
    logic limb_231_1437; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1438; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1439; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1440; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1441; // decl: <none>; prim: <none>
    logic limb_231_1442; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1443; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1444; // decl: <none>; prim: <none>
    logic [2:0] limb_231_1445; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1446; // decl: <none>; prim: <none>
    logic [129:0] limb_231_1447; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_362_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_366_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_370_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_374_s5; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_174_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_387_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_391_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_395_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_399_s4; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s7; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [129:0] rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_175_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_465_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_469_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_473_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_477_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_48_s7; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [63:0] rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_719_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_20_s6; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [63:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_729_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_734_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_269_s6; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_427_s6; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_739_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_745_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_747_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_753_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_753_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_759_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_759_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_765_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_771_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_777_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_783_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_788_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_794_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_184_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_274_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_246_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [32:0] rtlzz_pipe_313_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_845_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_851_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_857_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_879_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_879_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_884_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_884_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_889_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_889_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_198_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_894_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_894_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_899_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_899_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_904_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_904_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_283_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_287_s4; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_200_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
    logic [131:0] rtlzz_pipe_214_s4; // decl: <none>; prim: <none>
    logic [131:0] rtlzz_pipe_214_s5; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_144_s4; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] rtlzz_pipe_144_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [63:0] rtlzz_pipe_921_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_922_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_927_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_928_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_933_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_933_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_938_s3; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_938_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_120_s5; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] rtlzz_pipe_288_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_290_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_943_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_948_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s5; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_122_s5; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] rtlzz_pipe_122_s6; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [65:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_955_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_961_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_997_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1003_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1009_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1328_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1333_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1338_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1358_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1358_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1363_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1363_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1368_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1368_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_979_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_985_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_991_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1223_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1226_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1228_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1231_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1232_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1233_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1233_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1234_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1238_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1238_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1239_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1243_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1243_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1244_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = limb_13_728; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = limb_15_738; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__32_v0 = (__beopt_width_545 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (__beopt_width_546 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_21Core rtlzz_owner_21(.a(34'(rtlzz_pipe_20_s6)), .b(34'(__beopt_width_332)), .cin(1'b0), .value(s8_norm_add_36_v0));
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(34'(tmp_workload_top_int_34__47_v0)), .b(34'(__beopt_width_336)), .cin(1'b0), .value(s8_norm_add_39_v0));
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = limb_29_750; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = limb_31_762; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (rtlzz_pipe_173_s7 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (rtlzz_pipe_174_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = limb_38_780; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__76_v0 = (rtlzz_pipe_175_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = limb_40_798; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__85_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = limb_51_808; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = limb_53_818; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__117_v0 = (__beopt_width_573 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (rtlzz_pipe_184_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_59Core rtlzz_owner_59(.a(34'(tmp_workload_top_int_34__127_v0)), .b(34'(rtlzz_pipe_246_s7)), .cin(1'b0), .value(s8_norm_add_98_v0));
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(34'(tmp_workload_top_int_34__132_v0)), .b(34'(__beopt_width_370)), .cin(1'b0), .value(s8_norm_add_101_v0));
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = limb_67_830; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = limb_69_842; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = limb_76_860; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = limb_78_878; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__164_v0 = (rtlzz_pipe_48_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = limb_85_893; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = limb_87_908; // decl: <none>; prim: <none>
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (tmp_workload_top_int_66__243_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(34'(tmp_workload_top_int_34__202_v0)), .b(34'(__beopt_width_388)), .cin(1'b0), .value(s8_norm_add_152_v0));
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s4 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(34'(tmp_workload_top_int_34__207_v0)), .b(34'(__beopt_width_391)), .cin(1'b0), .value(s8_norm_add_155_v0));
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (rtlzz_pipe_200_s4 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = limb_103_920; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = limb_105_932; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__223_v0 = (__beopt_width_611 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s5 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (__beopt_width_617 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = limb_113_942; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = limb_115_952; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__252_v0 = (s8_norm_add_177_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (__beopt_width_627 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_121Core rtlzz_owner_121(.a(34'(rtlzz_pipe_120_s5)), .b(34'(__beopt_width_416)), .cin(1'b0), .value(s8_norm_add_195_v0));
    assign tmp_workload_top_int_34__267_v0 = (__beopt_width_630 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(34'(rtlzz_pipe_122_s6)), .b(34'(__beopt_width_424)), .cin(1'b0), .value(s8_norm_add_198_v0));
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = limb_129_964; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = limb_131_976; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = limb_138_994; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__296_v0 = (rtlzz_pipe_214_s5 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = limb_140_1012; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (rtlzz_pipe_144_s5 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = limb_147_1042; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = limb_149_1072; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = limb_157_1117; // decl: <none>; prim: <none>
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = limb_216_1157; // decl: <none>; prim: <none>
    assign __beopt_width_294 = limb_217_1197; // decl: <none>; prim: <none>
    assign __beopt_width_295 = limb_218_1222; // decl: <none>; prim: <none>
    assign __beopt_width_297 = limb_219_1247; // decl: <none>; prim: <none>
    assign __beopt_width_299 = limb_220_1267; // decl: <none>; prim: <none>
    assign __beopt_width_301 = limb_221_1287; // decl: <none>; prim: <none>
    assign __beopt_width_302 = limb_222_1307; // decl: <none>; prim: <none>
    assign __beopt_width_303 = limb_223_1327; // decl: <none>; prim: <none>
    assign __beopt_width_305 = limb_224_1342; // decl: <none>; prim: <none>
    assign __beopt_width_307 = limb_225_1357; // decl: <none>; prim: <none>
    assign __beopt_width_309 = limb_226_1372; // decl: <none>; prim: <none>
    assign __beopt_width_310 = limb_227_1387; // decl: <none>; prim: <none>
    assign __beopt_width_311 = limb_228_1402; // decl: <none>; prim: <none>
    assign __beopt_width_313 = limb_229_1417; // decl: <none>; prim: <none>
    assign __beopt_width_315 = limb_230_1432; // decl: <none>; prim: <none>
    assign __beopt_width_317 = limb_231_1447; // decl: <none>; prim: <none>
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (rtlzz_pipe_265_s5 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (rtlzz_pipe_268_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (rtlzz_pipe_269_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s6 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s7 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (__beopt_width_353 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s1 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (rtlzz_pipe_274_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (rtlzz_pipe_278_s2 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (rtlzz_pipe_279_s3 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s3 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (rtlzz_pipe_283_s4 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (__beopt_width_403 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (__beopt_width_406 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s4 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (rtlzz_pipe_287_s4 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (rtlzz_pipe_288_s5 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s6 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (rtlzz_pipe_290_s5 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s6 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = mul_tree_343_384; // decl: <none>; prim: <none>
    assign arith_original_344 = mul_tree_344_409; // decl: <none>; prim: <none>
    assign arith_original_345 = mul_tree_345_434; // decl: <none>; prim: <none>
    assign arith_original_346 = mul_tree_346_437; // decl: <none>; prim: <none>
    assign arith_original_347 = mul_tree_347_462; // decl: <none>; prim: <none>
    assign arith_original_348 = mul_tree_348_487; // decl: <none>; prim: <none>
    assign arith_original_349 = mul_tree_349_512; // decl: <none>; prim: <none>
    assign arith_original_350 = mul_tree_350_537; // decl: <none>; prim: <none>
    assign arith_original_351 = mul_tree_351_540; // decl: <none>; prim: <none>
    assign arith_original_352 = mul_tree_352_565; // decl: <none>; prim: <none>
    assign arith_original_353 = mul_tree_353_590; // decl: <none>; prim: <none>
    assign arith_original_354 = mul_tree_354_593; // decl: <none>; prim: <none>
    assign arith_original_355 = mul_tree_355_618; // decl: <none>; prim: <none>
    assign arith_original_356 = mul_tree_356_643; // decl: <none>; prim: <none>
    assign arith_original_357 = mul_tree_357_668; // decl: <none>; prim: <none>
    assign arith_original_358 = mul_tree_358_693; // decl: <none>; prim: <none>
    assign arith_original_359 = mul_tree_359_718; // decl: <none>; prim: <none>
    assign mul_tree_343_360 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_361 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_362Core rtlzz_owner_362(.a(32'(mul_tree_343_360)), .b(32'(mul_tree_343_361)), .cin(1'b0), .value(mul_tree_343_362));
    assign mul_tree_343_363 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_364 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_365Core rtlzz_owner_365(.a(32'(mul_tree_343_363)), .b(32'(mul_tree_343_364)), .cin(1'b0), .value(mul_tree_343_365));
    assign mul_tree_343_366 = {mul_tree_343_365, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_367 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_368 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(32'(mul_tree_343_367)), .b(32'(mul_tree_343_368)), .cin(1'b0), .value(mul_tree_343_369));
    assign mul_tree_343_370 = {mul_tree_343_369, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_371 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_372 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_343_371)), .b(32'(mul_tree_343_372)), .cin(1'b0), .value(mul_tree_343_373));
    assign mul_tree_343_374 = {mul_tree_343_373, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_375 = ({33'h0, rtlzz_pipe_362_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_376 = ({1'h0, rtlzz_pipe_366_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_378 = ({33'h0, rtlzz_pipe_370_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_379 = ({1'h0, rtlzz_pipe_374_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_381 = ({33'h0, mul_tree_343_377}); // decl: <none>; prim: <none>
    assign mul_tree_343_382 = ({1'h0, mul_tree_343_380}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_383_reduce rtlzz_reduce_383(.i1521(rtlzz_pipe_362_s5), .i1522(rtlzz_pipe_366_s5), .i1523(rtlzz_pipe_370_s5), .i1524(rtlzz_pipe_374_s5), .y(mul_tree_343_383));
    assign mul_tree_343_384 = mul_tree_343_383[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_385 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_386 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387Core rtlzz_owner_387(.a(32'(mul_tree_344_385)), .b(32'(mul_tree_344_386)), .cin(1'b0), .value(mul_tree_344_387));
    assign mul_tree_344_388 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_389 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_390Core rtlzz_owner_390(.a(32'(mul_tree_344_388)), .b(32'(mul_tree_344_389)), .cin(1'b0), .value(mul_tree_344_390));
    assign mul_tree_344_391 = {mul_tree_344_390, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_392 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_393 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(32'(mul_tree_344_392)), .b(32'(mul_tree_344_393)), .cin(1'b0), .value(mul_tree_344_394));
    assign mul_tree_344_395 = {mul_tree_344_394, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_396 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_397 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_344_396)), .b(32'(mul_tree_344_397)), .cin(1'b0), .value(mul_tree_344_398));
    assign mul_tree_344_399 = {mul_tree_344_398, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_400 = ({33'h0, rtlzz_pipe_387_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_401 = ({1'h0, rtlzz_pipe_391_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_403 = ({33'h0, rtlzz_pipe_395_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_404 = ({1'h0, rtlzz_pipe_399_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_406 = ({33'h0, mul_tree_344_402}); // decl: <none>; prim: <none>
    assign mul_tree_344_407 = ({1'h0, mul_tree_344_405}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_408_reduce rtlzz_reduce_408(.i1528(rtlzz_pipe_387_s4), .i1529(rtlzz_pipe_391_s4), .i1530(rtlzz_pipe_395_s4), .i1531(rtlzz_pipe_399_s4), .y(mul_tree_344_408));
    assign mul_tree_344_409 = mul_tree_344_408[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_410 = rtlzz_pipe_298_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_411 = mul_precision_299[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412Core rtlzz_owner_412(.a(32'(mul_tree_345_410)), .b(32'(mul_tree_345_411)), .cin(1'b0), .value(mul_tree_345_412));
    assign mul_tree_345_413 = rtlzz_pipe_298_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_414 = mul_precision_299[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(32'(mul_tree_345_413)), .b(1'(mul_tree_345_414)), .cin(1'b0), .value(mul_tree_345_415));
    assign mul_tree_345_416 = {mul_tree_345_415, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_417 = rtlzz_pipe_298_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_418 = mul_precision_299[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(1'(mul_tree_345_417)), .b(32'(mul_tree_345_418)), .cin(1'b0), .value(mul_tree_345_419));
    assign mul_tree_345_420 = {mul_tree_345_419, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_421 = rtlzz_pipe_298_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_422 = mul_precision_299[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(1'(mul_tree_345_421)), .b(1'(mul_tree_345_422)), .cin(1'b0), .value(mul_tree_345_423));
    assign mul_tree_345_424 = {mul_tree_345_423, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_425 = ({2'h0, mul_tree_345_412}); // decl: <none>; prim: <none>
    assign mul_tree_345_426 = ({1'h0, mul_tree_345_416}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_427Core rtlzz_owner_427(.a(64'(mul_tree_345_425)), .b(65'(mul_tree_345_426)), .cin(1'h0), .value(mul_tree_345_427));
    assign mul_tree_345_428 = ({2'h0, mul_tree_345_420}); // decl: <none>; prim: <none>
    assign mul_tree_345_429 = ({1'h0, mul_tree_345_424}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_430Core rtlzz_owner_430(.a(65'(mul_tree_345_428)), .b(66'(mul_tree_345_429)), .cin(1'h0), .value(mul_tree_345_430[65:0]));
    assign mul_tree_345_430[66:66] = '0;
    assign mul_tree_345_431 = ({2'h0, rtlzz_pipe_427_s6}); // decl: <none>; prim: <none>
    assign mul_tree_345_432 = ({1'h0, rtlzz_pipe_430_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433Core rtlzz_owner_433(.a(66'(mul_tree_345_431)), .b(67'(mul_tree_345_432)), .cin(1'h0), .value(mul_tree_345_433[65:0]));
    assign mul_tree_345_433[67:66] = '0;
    assign mul_tree_345_434 = mul_tree_345_433[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_435 = mul_precision_301[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_436 = mul_precision_302[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_437Core rtlzz_owner_437(.a(32'(mul_tree_346_435)), .b(32'(mul_tree_346_436)), .cin(1'b0), .value(mul_tree_346_437));
    assign mul_tree_347_438 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_439 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_440Core rtlzz_owner_440(.a(32'(mul_tree_347_438)), .b(32'(mul_tree_347_439)), .cin(1'b0), .value(mul_tree_347_440));
    assign mul_tree_347_441 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_442 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_443Core rtlzz_owner_443(.a(32'(mul_tree_347_441)), .b(2'(mul_tree_347_442)), .cin(1'b0), .value(mul_tree_347_443));
    assign mul_tree_347_444 = {mul_tree_347_443, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_445 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_446 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_447Core rtlzz_owner_447(.a(2'(mul_tree_347_445)), .b(32'(mul_tree_347_446)), .cin(1'b0), .value(mul_tree_347_447));
    assign mul_tree_347_448 = {mul_tree_347_447, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_449 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_450 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(2'(mul_tree_347_449)), .b(2'(mul_tree_347_450)), .cin(1'b0), .value(mul_tree_347_451));
    assign mul_tree_347_452 = {mul_tree_347_451, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_453 = ({3'h0, mul_tree_347_440}); // decl: <none>; prim: <none>
    assign mul_tree_347_454 = ({1'h0, mul_tree_347_444}); // decl: <none>; prim: <none>
    assign mul_tree_347_456 = ({3'h0, mul_tree_347_448}); // decl: <none>; prim: <none>
    assign mul_tree_347_457 = ({1'h0, mul_tree_347_452}); // decl: <none>; prim: <none>
    assign mul_tree_347_459 = ({3'h0, mul_tree_347_455}); // decl: <none>; prim: <none>
    assign mul_tree_347_460 = ({1'h0, mul_tree_347_458}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_461_reduce rtlzz_reduce_461(.i440(mul_tree_347_440), .i443(mul_tree_347_443), .i447(mul_tree_347_447), .i451(mul_tree_347_451), .y(mul_tree_347_461));
    assign mul_tree_347_462 = mul_tree_347_461[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_463 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_464 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_465Core rtlzz_owner_465(.a(32'(mul_tree_348_463)), .b(32'(mul_tree_348_464)), .cin(1'b0), .value(mul_tree_348_465));
    assign mul_tree_348_466 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_467 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_468Core rtlzz_owner_468(.a(32'(mul_tree_348_466)), .b(32'(mul_tree_348_467)), .cin(1'b0), .value(mul_tree_348_468));
    assign mul_tree_348_469 = {mul_tree_348_468, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_470 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_471 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_472Core rtlzz_owner_472(.a(32'(mul_tree_348_470)), .b(32'(mul_tree_348_471)), .cin(1'b0), .value(mul_tree_348_472));
    assign mul_tree_348_473 = {mul_tree_348_472, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_474 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_475 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_348_474)), .b(32'(mul_tree_348_475)), .cin(1'b0), .value(mul_tree_348_476));
    assign mul_tree_348_477 = {mul_tree_348_476, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_478 = ({33'h0, rtlzz_pipe_465_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_479 = ({1'h0, rtlzz_pipe_469_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_481 = ({33'h0, rtlzz_pipe_473_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_482 = ({1'h0, rtlzz_pipe_477_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_484 = ({33'h0, mul_tree_348_480}); // decl: <none>; prim: <none>
    assign mul_tree_348_485 = ({1'h0, mul_tree_348_483}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_486_reduce rtlzz_reduce_486(.i1537(rtlzz_pipe_465_s6), .i1538(rtlzz_pipe_469_s6), .i1539(rtlzz_pipe_473_s6), .i1540(rtlzz_pipe_477_s6), .y(mul_tree_348_486));
    assign mul_tree_348_487 = mul_tree_348_486[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_488 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_489 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_490Core rtlzz_owner_490(.a(32'(mul_tree_349_488)), .b(32'(mul_tree_349_489)), .cin(1'b0), .value(mul_tree_349_490));
    assign mul_tree_349_491 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_492 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_493Core rtlzz_owner_493(.a(32'(mul_tree_349_491)), .b(32'(mul_tree_349_492)), .cin(1'b0), .value(mul_tree_349_493));
    assign mul_tree_349_494 = {mul_tree_349_493, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_495 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_496 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_497Core rtlzz_owner_497(.a(32'(mul_tree_349_495)), .b(32'(mul_tree_349_496)), .cin(1'b0), .value(mul_tree_349_497));
    assign mul_tree_349_498 = {mul_tree_349_497, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_499 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_500 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_349_499)), .b(32'(mul_tree_349_500)), .cin(1'b0), .value(mul_tree_349_501));
    assign mul_tree_349_502 = {mul_tree_349_501, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_503 = ({33'h0, mul_tree_349_490}); // decl: <none>; prim: <none>
    assign mul_tree_349_504 = ({1'h0, mul_tree_349_494}); // decl: <none>; prim: <none>
    assign mul_tree_349_506 = ({33'h0, mul_tree_349_498}); // decl: <none>; prim: <none>
    assign mul_tree_349_507 = ({1'h0, mul_tree_349_502}); // decl: <none>; prim: <none>
    assign mul_tree_349_509 = ({33'h0, mul_tree_349_505}); // decl: <none>; prim: <none>
    assign mul_tree_349_510 = ({1'h0, mul_tree_349_508}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_511_reduce rtlzz_reduce_511(.i490(mul_tree_349_490), .i493(mul_tree_349_493), .i497(mul_tree_349_497), .i501(mul_tree_349_501), .y(mul_tree_349_511));
    assign mul_tree_349_512 = mul_tree_349_511[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_513 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_514 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_515Core rtlzz_owner_515(.a(32'(mul_tree_350_513)), .b(32'(mul_tree_350_514)), .cin(1'b0), .value(mul_tree_350_515));
    assign mul_tree_350_516 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_517 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_518Core rtlzz_owner_518(.a(32'(mul_tree_350_516)), .b(1'(mul_tree_350_517)), .cin(1'b0), .value(mul_tree_350_518));
    assign mul_tree_350_519 = {mul_tree_350_518, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_520 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_521 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_522Core rtlzz_owner_522(.a(1'(mul_tree_350_520)), .b(32'(mul_tree_350_521)), .cin(1'b0), .value(mul_tree_350_522));
    assign mul_tree_350_523 = {mul_tree_350_522, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_524 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_525 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(1'(mul_tree_350_524)), .b(1'(mul_tree_350_525)), .cin(1'b0), .value(mul_tree_350_526));
    assign mul_tree_350_527 = {mul_tree_350_526, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_528 = ({2'h0, mul_tree_350_515}); // decl: <none>; prim: <none>
    assign mul_tree_350_529 = ({1'h0, mul_tree_350_519}); // decl: <none>; prim: <none>
    assign mul_tree_350_531 = ({2'h0, mul_tree_350_523}); // decl: <none>; prim: <none>
    assign mul_tree_350_532 = ({1'h0, mul_tree_350_527}); // decl: <none>; prim: <none>
    assign mul_tree_350_534 = ({2'h0, mul_tree_350_530}); // decl: <none>; prim: <none>
    assign mul_tree_350_535 = ({1'h0, mul_tree_350_533}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_536_reduce rtlzz_reduce_536(.i515(mul_tree_350_515), .i518(mul_tree_350_518), .i522(mul_tree_350_522), .i526(mul_tree_350_526), .y(mul_tree_350_536));
    assign mul_tree_350_537 = mul_tree_350_536[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_538 = mul_precision_316[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_539 = mul_precision_317[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_540Core rtlzz_owner_540(.a(32'(mul_tree_351_538)), .b(32'(mul_tree_351_539)), .cin(1'b0), .value(mul_tree_351_540));
    assign mul_tree_352_541 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_542 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_543Core rtlzz_owner_543(.a(32'(mul_tree_352_541)), .b(32'(mul_tree_352_542)), .cin(1'b0), .value(mul_tree_352_543));
    assign mul_tree_352_544 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_545 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_546Core rtlzz_owner_546(.a(32'(mul_tree_352_544)), .b(2'(mul_tree_352_545)), .cin(1'b0), .value(mul_tree_352_546));
    assign mul_tree_352_547 = {mul_tree_352_546, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_548 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_549 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(2'(mul_tree_352_548)), .b(32'(mul_tree_352_549)), .cin(1'b0), .value(mul_tree_352_550));
    assign mul_tree_352_551 = {mul_tree_352_550, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_552 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_553 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_554Core rtlzz_owner_554(.a(2'(mul_tree_352_552)), .b(2'(mul_tree_352_553)), .cin(1'b0), .value(mul_tree_352_554));
    assign mul_tree_352_555 = {mul_tree_352_554, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_556 = ({3'h0, mul_tree_352_543}); // decl: <none>; prim: <none>
    assign mul_tree_352_557 = ({1'h0, mul_tree_352_547}); // decl: <none>; prim: <none>
    assign mul_tree_352_559 = ({3'h0, mul_tree_352_551}); // decl: <none>; prim: <none>
    assign mul_tree_352_560 = ({1'h0, mul_tree_352_555}); // decl: <none>; prim: <none>
    assign mul_tree_352_562 = ({3'h0, mul_tree_352_558}); // decl: <none>; prim: <none>
    assign mul_tree_352_563 = ({1'h0, mul_tree_352_561}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_564_reduce rtlzz_reduce_564(.i543(mul_tree_352_543), .i546(mul_tree_352_546), .i550(mul_tree_352_550), .i554(mul_tree_352_554), .y(mul_tree_352_564));
    assign mul_tree_352_565 = mul_tree_352_564[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_566 = rtlzz_pipe_322_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_567 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_568Core rtlzz_owner_568(.a(32'(mul_tree_353_566)), .b(32'(mul_tree_353_567)), .cin(1'b0), .value(mul_tree_353_568));
    assign mul_tree_353_569 = rtlzz_pipe_322_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_570 = mul_precision_323[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_571Core rtlzz_owner_571(.a(32'(mul_tree_353_569)), .b(1'(mul_tree_353_570)), .cin(1'b0), .value(mul_tree_353_571));
    assign mul_tree_353_572 = {mul_tree_353_571, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_573 = rtlzz_pipe_322_s3[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_574 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_575Core rtlzz_owner_575(.a(1'(mul_tree_353_573)), .b(32'(mul_tree_353_574)), .cin(1'b0), .value(mul_tree_353_575));
    assign mul_tree_353_576 = {mul_tree_353_575, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_577 = rtlzz_pipe_322_s3[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_578 = mul_precision_323[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_579Core rtlzz_owner_579(.a(1'(mul_tree_353_577)), .b(1'(mul_tree_353_578)), .cin(1'b0), .value(mul_tree_353_579));
    assign mul_tree_353_580 = {mul_tree_353_579, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_581 = ({2'h0, mul_tree_353_568}); // decl: <none>; prim: <none>
    assign mul_tree_353_582 = ({1'h0, mul_tree_353_572}); // decl: <none>; prim: <none>
    assign mul_tree_353_584 = ({2'h0, mul_tree_353_576}); // decl: <none>; prim: <none>
    assign mul_tree_353_585 = ({1'h0, mul_tree_353_580}); // decl: <none>; prim: <none>
    assign mul_tree_353_587 = ({2'h0, mul_tree_353_583}); // decl: <none>; prim: <none>
    assign mul_tree_353_588 = ({1'h0, mul_tree_353_586}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589_reduce rtlzz_reduce_589(.i568(mul_tree_353_568), .i571(mul_tree_353_571), .i575(mul_tree_353_575), .i579(mul_tree_353_579), .y(mul_tree_353_589));
    assign mul_tree_353_590 = mul_tree_353_589[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_591 = rtlzz_pipe_325_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_592 = mul_precision_326[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_593Core rtlzz_owner_593(.a(32'(mul_tree_354_591)), .b(32'(mul_tree_354_592)), .cin(1'b0), .value(mul_tree_354_593));
    assign mul_tree_355_594 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_595 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_596Core rtlzz_owner_596(.a(32'(mul_tree_355_594)), .b(32'(mul_tree_355_595)), .cin(1'b0), .value(mul_tree_355_596));
    assign mul_tree_355_597 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_598 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_599Core rtlzz_owner_599(.a(32'(mul_tree_355_597)), .b(2'(mul_tree_355_598)), .cin(1'b0), .value(mul_tree_355_599));
    assign mul_tree_355_600 = {mul_tree_355_599, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_601 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_602 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_603Core rtlzz_owner_603(.a(2'(mul_tree_355_601)), .b(32'(mul_tree_355_602)), .cin(1'b0), .value(mul_tree_355_603));
    assign mul_tree_355_604 = {mul_tree_355_603, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_605 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_606 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_607Core rtlzz_owner_607(.a(2'(mul_tree_355_605)), .b(2'(mul_tree_355_606)), .cin(1'b0), .value(mul_tree_355_607));
    assign mul_tree_355_608 = {mul_tree_355_607, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_609 = ({3'h0, mul_tree_355_596}); // decl: <none>; prim: <none>
    assign mul_tree_355_610 = ({1'h0, mul_tree_355_600}); // decl: <none>; prim: <none>
    assign mul_tree_355_612 = ({3'h0, mul_tree_355_604}); // decl: <none>; prim: <none>
    assign mul_tree_355_613 = ({1'h0, mul_tree_355_608}); // decl: <none>; prim: <none>
    assign mul_tree_355_615 = ({3'h0, mul_tree_355_611}); // decl: <none>; prim: <none>
    assign mul_tree_355_616 = ({1'h0, mul_tree_355_614}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_617_reduce rtlzz_reduce_617(.i596(mul_tree_355_596), .i599(mul_tree_355_599), .i603(mul_tree_355_603), .i607(mul_tree_355_607), .y(mul_tree_355_617));
    assign mul_tree_355_618 = mul_tree_355_617[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_619 = rtlzz_pipe_331_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_620 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_621Core rtlzz_owner_621(.a(32'(mul_tree_356_619)), .b(32'(mul_tree_356_620)), .cin(1'b0), .value(mul_tree_356_621));
    assign mul_tree_356_622 = rtlzz_pipe_331_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_623 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_624Core rtlzz_owner_624(.a(32'(mul_tree_356_622)), .b(32'(mul_tree_356_623)), .cin(1'b0), .value(mul_tree_356_624));
    assign mul_tree_356_625 = {mul_tree_356_624, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_626 = rtlzz_pipe_331_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_627 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_628Core rtlzz_owner_628(.a(32'(mul_tree_356_626)), .b(32'(mul_tree_356_627)), .cin(1'b0), .value(mul_tree_356_628));
    assign mul_tree_356_629 = {mul_tree_356_628, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_630 = rtlzz_pipe_331_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_631 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_632Core rtlzz_owner_632(.a(32'(mul_tree_356_630)), .b(32'(mul_tree_356_631)), .cin(1'b0), .value(mul_tree_356_632));
    assign mul_tree_356_633 = {mul_tree_356_632, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_634 = ({33'h0, mul_tree_356_621}); // decl: <none>; prim: <none>
    assign mul_tree_356_635 = ({1'h0, mul_tree_356_625}); // decl: <none>; prim: <none>
    assign mul_tree_356_637 = ({33'h0, mul_tree_356_629}); // decl: <none>; prim: <none>
    assign mul_tree_356_638 = ({1'h0, mul_tree_356_633}); // decl: <none>; prim: <none>
    assign mul_tree_356_640 = ({33'h0, mul_tree_356_636}); // decl: <none>; prim: <none>
    assign mul_tree_356_641 = ({1'h0, mul_tree_356_639}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_642_reduce rtlzz_reduce_642(.i621(mul_tree_356_621), .i624(mul_tree_356_624), .i628(mul_tree_356_628), .i632(mul_tree_356_632), .y(mul_tree_356_642));
    assign mul_tree_356_643 = mul_tree_356_642[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_644 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_645 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_646Core rtlzz_owner_646(.a(32'(mul_tree_357_644)), .b(32'(mul_tree_357_645)), .cin(1'b0), .value(mul_tree_357_646));
    assign mul_tree_357_647 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_648 = mul_precision_335[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_649Core rtlzz_owner_649(.a(32'(mul_tree_357_647)), .b(1'(mul_tree_357_648)), .cin(1'b0), .value(mul_tree_357_649));
    assign mul_tree_357_650 = {mul_tree_357_649, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_651 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_652 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_653Core rtlzz_owner_653(.a(1'(mul_tree_357_651)), .b(32'(mul_tree_357_652)), .cin(1'b0), .value(mul_tree_357_653));
    assign mul_tree_357_654 = {mul_tree_357_653, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_655 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_656 = mul_precision_335[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_657Core rtlzz_owner_657(.a(1'(mul_tree_357_655)), .b(1'(mul_tree_357_656)), .cin(1'b0), .value(mul_tree_357_657));
    assign mul_tree_357_658 = {mul_tree_357_657, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_659 = ({2'h0, mul_tree_357_646}); // decl: <none>; prim: <none>
    assign mul_tree_357_660 = ({1'h0, mul_tree_357_650}); // decl: <none>; prim: <none>
    assign mul_tree_357_662 = ({2'h0, mul_tree_357_654}); // decl: <none>; prim: <none>
    assign mul_tree_357_663 = ({1'h0, mul_tree_357_658}); // decl: <none>; prim: <none>
    assign mul_tree_357_665 = ({2'h0, mul_tree_357_661}); // decl: <none>; prim: <none>
    assign mul_tree_357_666 = ({1'h0, mul_tree_357_664}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_667_reduce rtlzz_reduce_667(.i646(mul_tree_357_646), .i649(mul_tree_357_649), .i653(mul_tree_357_653), .i657(mul_tree_357_657), .y(mul_tree_357_667));
    assign mul_tree_357_668 = mul_tree_357_667[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_669 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_670 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_671Core rtlzz_owner_671(.a(32'(mul_tree_358_669)), .b(32'(mul_tree_358_670)), .cin(1'b0), .value(mul_tree_358_671));
    assign mul_tree_358_672 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_673 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_674Core rtlzz_owner_674(.a(32'(mul_tree_358_672)), .b(1'(mul_tree_358_673)), .cin(1'b0), .value(mul_tree_358_674));
    assign mul_tree_358_675 = {mul_tree_358_674, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_676 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_677 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_678Core rtlzz_owner_678(.a(1'(mul_tree_358_676)), .b(32'(mul_tree_358_677)), .cin(1'b0), .value(mul_tree_358_678));
    assign mul_tree_358_679 = {mul_tree_358_678, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_680 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_681 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_682Core rtlzz_owner_682(.a(1'(mul_tree_358_680)), .b(1'(mul_tree_358_681)), .cin(1'b0), .value(mul_tree_358_682));
    assign mul_tree_358_683 = {mul_tree_358_682, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_684 = ({2'h0, mul_tree_358_671}); // decl: <none>; prim: <none>
    assign mul_tree_358_685 = ({1'h0, mul_tree_358_675}); // decl: <none>; prim: <none>
    assign mul_tree_358_687 = ({2'h0, mul_tree_358_679}); // decl: <none>; prim: <none>
    assign mul_tree_358_688 = ({1'h0, mul_tree_358_683}); // decl: <none>; prim: <none>
    assign mul_tree_358_690 = ({2'h0, mul_tree_358_686}); // decl: <none>; prim: <none>
    assign mul_tree_358_691 = ({1'h0, mul_tree_358_689}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_692_reduce rtlzz_reduce_692(.i671(mul_tree_358_671), .i674(mul_tree_358_674), .i678(mul_tree_358_678), .i682(mul_tree_358_682), .y(mul_tree_358_692));
    assign mul_tree_358_693 = mul_tree_358_692[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_694 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_695 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_696Core rtlzz_owner_696(.a(32'(mul_tree_359_694)), .b(32'(mul_tree_359_695)), .cin(1'b0), .value(mul_tree_359_696));
    assign mul_tree_359_697 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_698 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_699Core rtlzz_owner_699(.a(32'(mul_tree_359_697)), .b(2'(mul_tree_359_698)), .cin(1'b0), .value(mul_tree_359_699));
    assign mul_tree_359_700 = {mul_tree_359_699, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_701 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_702 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_703Core rtlzz_owner_703(.a(2'(mul_tree_359_701)), .b(32'(mul_tree_359_702)), .cin(1'b0), .value(mul_tree_359_703));
    assign mul_tree_359_704 = {mul_tree_359_703, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_705 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_706 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_707Core rtlzz_owner_707(.a(2'(mul_tree_359_705)), .b(2'(mul_tree_359_706)), .cin(1'b0), .value(mul_tree_359_707));
    assign mul_tree_359_708 = {mul_tree_359_707, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_709 = ({3'h0, mul_tree_359_696}); // decl: <none>; prim: <none>
    assign mul_tree_359_710 = ({1'h0, mul_tree_359_700}); // decl: <none>; prim: <none>
    assign mul_tree_359_712 = ({3'h0, mul_tree_359_704}); // decl: <none>; prim: <none>
    assign mul_tree_359_713 = ({1'h0, mul_tree_359_708}); // decl: <none>; prim: <none>
    assign mul_tree_359_715 = ({3'h0, mul_tree_359_711}); // decl: <none>; prim: <none>
    assign mul_tree_359_716 = ({1'h0, mul_tree_359_714}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_717_reduce rtlzz_reduce_717(.i696(mul_tree_359_696), .i699(mul_tree_359_699), .i703(mul_tree_359_703), .i707(mul_tree_359_707), .y(mul_tree_359_717));
    assign mul_tree_359_718 = mul_tree_359_717[67:0]; // decl: <none>; prim: <none>
    assign limb_13_719 = tmp_workload_top_int_65__18_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_13_720 = __beopt_width_312[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_721Core rtlzz_owner_721(.a(64'(rtlzz_pipe_719_s4)), .b(64'(limb_13_720)), .cin(1'h0), .value(limb_13_721));
    assign limb_13_722 = limb_13_721[63:0]; // decl: <none>; prim: <none>
    assign limb_13_723 = limb_13_721[64]; // decl: <none>; prim: <none>
    assign limb_13_724 = tmp_workload_top_int_65__18_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_725 = __beopt_width_312[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_726Core rtlzz_owner_726(.a(1'(rtlzz_pipe_724_s4)), .b(1'(limb_13_725)), .cin(limb_13_723), .value(limb_13_726[0:0]));
    assign limb_13_726[1:1] = '0;
    assign limb_13_727 = limb_13_726[0]; // decl: <none>; prim: <none>
    assign limb_13_728 = {limb_13_727, limb_13_722}; // decl: <none>; prim: <none>
    assign limb_15_729 = tmp_workload_top_int_65__23_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_15_730 = __beopt_width_318[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_731Core rtlzz_owner_731(.a(64'(rtlzz_pipe_729_s5)), .b(64'(limb_15_730)), .cin(1'h0), .value(limb_15_731));
    assign limb_15_732 = limb_15_731[63:0]; // decl: <none>; prim: <none>
    assign limb_15_733 = limb_15_731[64]; // decl: <none>; prim: <none>
    assign limb_15_734 = tmp_workload_top_int_65__23_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_735 = __beopt_width_318[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_736Core rtlzz_owner_736(.a(1'(rtlzz_pipe_734_s5)), .b(1'(limb_15_735)), .cin(limb_15_733), .value(limb_15_736[0:0]));
    assign limb_15_736[1:1] = '0;
    assign limb_15_737 = limb_15_736[0]; // decl: <none>; prim: <none>
    assign limb_15_738 = {limb_15_737, limb_15_732}; // decl: <none>; prim: <none>
    assign limb_29_739 = n20_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_740 = tmp_workload_top_int_68__57_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_741 = (~rtlzz_pipe_740_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_742Core rtlzz_owner_742(.a(64'(rtlzz_pipe_739_s7)), .b(64'(limb_29_741)), .cin(1'h1), .value(limb_29_742));
    assign limb_29_743 = limb_29_742[63:0]; // decl: <none>; prim: <none>
    assign limb_29_744 = limb_29_742[64]; // decl: <none>; prim: <none>
    assign limb_29_745 = n20_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_746 = tmp_workload_top_int_68__57_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_747 = (~limb_29_746); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_748Core rtlzz_owner_748(.a(4'(rtlzz_pipe_745_s7)), .b(4'(rtlzz_pipe_747_s7)), .cin(limb_29_744), .value(limb_29_748[3:0]));
    assign limb_29_748[4:4] = '0;
    assign limb_29_749 = limb_29_748[3:0]; // decl: <none>; prim: <none>
    assign limb_29_750 = {limb_29_749, limb_29_743}; // decl: <none>; prim: <none>
    assign limb_31_751 = s8_norm_sub_45_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_752 = tmp_workload_top_int_68__60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_753 = (~limb_31_752); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_754Core rtlzz_owner_754(.a(64'(limb_31_751)), .b(64'(rtlzz_pipe_753_s7)), .cin(1'h1), .value(limb_31_754));
    assign limb_31_755 = limb_31_754[63:0]; // decl: <none>; prim: <none>
    assign limb_31_756 = limb_31_754[64]; // decl: <none>; prim: <none>
    assign limb_31_757 = s8_norm_sub_45_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_758 = tmp_workload_top_int_68__60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_759 = (~limb_31_758); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_760Core rtlzz_owner_760(.a(4'(limb_31_757)), .b(4'(rtlzz_pipe_759_s7)), .cin(limb_31_756), .value(limb_31_760[3:0]));
    assign limb_31_760[4:4] = '0;
    assign limb_31_761 = limb_31_760[3:0]; // decl: <none>; prim: <none>
    assign limb_31_762 = {limb_31_761, limb_31_755}; // decl: <none>; prim: <none>
    assign limb_38_763 = __beopt_width_317[63:0]; // decl: <none>; prim: <none>
    assign limb_38_764 = tmp_workload_top_int_130__73_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_38_765 = (~limb_38_764); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_766Core rtlzz_owner_766(.a(64'(limb_38_763)), .b(64'(rtlzz_pipe_765_s7)), .cin(1'h1), .value(limb_38_766));
    assign limb_38_767 = limb_38_766[63:0]; // decl: <none>; prim: <none>
    assign limb_38_768 = limb_38_766[64]; // decl: <none>; prim: <none>
    assign limb_38_769 = __beopt_width_317[127:64]; // decl: <none>; prim: <none>
    assign limb_38_770 = tmp_workload_top_int_130__73_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_38_771 = (~limb_38_770); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_772Core rtlzz_owner_772(.a(64'(limb_38_769)), .b(64'(rtlzz_pipe_771_s7)), .cin(limb_38_768), .value(limb_38_772));
    assign limb_38_773 = limb_38_772[63:0]; // decl: <none>; prim: <none>
    assign limb_38_774 = limb_38_772[64]; // decl: <none>; prim: <none>
    assign limb_38_775 = __beopt_width_317[129:128]; // decl: <none>; prim: <none>
    assign limb_38_776 = tmp_workload_top_int_130__73_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_38_777 = (~limb_38_776); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_778Core rtlzz_owner_778(.a(2'(limb_38_775)), .b(2'(rtlzz_pipe_777_s7)), .cin(limb_38_774), .value(limb_38_778[1:0]));
    assign limb_38_778[2:2] = '0;
    assign limb_38_779 = limb_38_778[1:0]; // decl: <none>; prim: <none>
    assign limb_38_780 = {limb_38_779, limb_38_773, limb_38_767}; // decl: <none>; prim: <none>
    assign limb_40_781 = s8_norm_sub_56_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_782 = tmp_workload_top_int_130__76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_783 = (~limb_40_782); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_784Core rtlzz_owner_784(.a(64'(limb_40_781)), .b(64'(rtlzz_pipe_783_s7)), .cin(1'h1), .value(limb_40_784));
    assign limb_40_785 = limb_40_784[63:0]; // decl: <none>; prim: <none>
    assign limb_40_786 = limb_40_784[64]; // decl: <none>; prim: <none>
    assign limb_40_787 = s8_norm_sub_56_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_788 = tmp_workload_top_int_130__76_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_789 = (~rtlzz_pipe_788_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_790Core rtlzz_owner_790(.a(64'(limb_40_787)), .b(64'(limb_40_789)), .cin(limb_40_786), .value(limb_40_790));
    assign limb_40_791 = limb_40_790[63:0]; // decl: <none>; prim: <none>
    assign limb_40_792 = limb_40_790[64]; // decl: <none>; prim: <none>
    assign limb_40_793 = s8_norm_sub_56_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_794 = tmp_workload_top_int_130__76_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_795 = (~rtlzz_pipe_794_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_796Core rtlzz_owner_796(.a(2'(limb_40_793)), .b(2'(limb_40_795)), .cin(limb_40_792), .value(limb_40_796[1:0]));
    assign limb_40_796[2:2] = '0;
    assign limb_40_797 = limb_40_796[1:0]; // decl: <none>; prim: <none>
    assign limb_40_798 = {limb_40_797, limb_40_791, limb_40_785}; // decl: <none>; prim: <none>
    assign limb_51_799 = tmp_workload_top_int_65__103_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_51_800 = __beopt_width_352[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_801Core rtlzz_owner_801(.a(64'(limb_51_799)), .b(64'(rtlzz_pipe_800_s6)), .cin(1'h0), .value(limb_51_801));
    assign limb_51_802 = limb_51_801[63:0]; // decl: <none>; prim: <none>
    assign limb_51_803 = limb_51_801[64]; // decl: <none>; prim: <none>
    assign limb_51_804 = tmp_workload_top_int_65__103_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_805 = __beopt_width_352[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_806Core rtlzz_owner_806(.a(1'(limb_51_804)), .b(1'(rtlzz_pipe_805_s6)), .cin(limb_51_803), .value(limb_51_806[0:0]));
    assign limb_51_806[1:1] = '0;
    assign limb_51_807 = limb_51_806[0]; // decl: <none>; prim: <none>
    assign limb_51_808 = {limb_51_807, limb_51_802}; // decl: <none>; prim: <none>
    assign limb_53_809 = tmp_workload_top_int_65__108_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_53_810 = __beopt_width_357[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_811Core rtlzz_owner_811(.a(64'(limb_53_809)), .b(64'(rtlzz_pipe_810_s7)), .cin(1'h0), .value(limb_53_811));
    assign limb_53_812 = limb_53_811[63:0]; // decl: <none>; prim: <none>
    assign limb_53_813 = limb_53_811[64]; // decl: <none>; prim: <none>
    assign limb_53_814 = tmp_workload_top_int_65__108_v0[64]; // decl: <none>; prim: <none>
    assign limb_53_815 = __beopt_width_357[64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_816Core rtlzz_owner_816(.a(1'(limb_53_814)), .b(1'(rtlzz_pipe_815_s7)), .cin(limb_53_813), .value(limb_53_816[0:0]));
    assign limb_53_816[1:1] = '0;
    assign limb_53_817 = limb_53_816[0]; // decl: <none>; prim: <none>
    assign limb_53_818 = {limb_53_817, limb_53_812}; // decl: <none>; prim: <none>
    assign limb_67_819 = n41_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_820 = tmp_workload_top_int_68__142_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_821 = (~limb_67_820); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_822Core rtlzz_owner_822(.a(64'(limb_67_819)), .b(64'(limb_67_821)), .cin(1'h1), .value(limb_67_822));
    assign limb_67_823 = limb_67_822[63:0]; // decl: <none>; prim: <none>
    assign limb_67_824 = limb_67_822[64]; // decl: <none>; prim: <none>
    assign limb_67_825 = n41_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_826 = tmp_workload_top_int_68__142_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_827 = (~limb_67_826); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_828Core rtlzz_owner_828(.a(4'(limb_67_825)), .b(4'(limb_67_827)), .cin(limb_67_824), .value(limb_67_828[3:0]));
    assign limb_67_828[4:4] = '0;
    assign limb_67_829 = limb_67_828[3:0]; // decl: <none>; prim: <none>
    assign limb_67_830 = {limb_67_829, limb_67_823}; // decl: <none>; prim: <none>
    assign limb_69_831 = s8_norm_sub_107_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_832 = tmp_workload_top_int_68__145_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_833 = (~limb_69_832); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_834Core rtlzz_owner_834(.a(64'(limb_69_831)), .b(64'(limb_69_833)), .cin(1'h1), .value(limb_69_834));
    assign limb_69_835 = limb_69_834[63:0]; // decl: <none>; prim: <none>
    assign limb_69_836 = limb_69_834[64]; // decl: <none>; prim: <none>
    assign limb_69_837 = s8_norm_sub_107_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_838 = tmp_workload_top_int_68__145_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_839 = (~limb_69_838); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_840Core rtlzz_owner_840(.a(4'(limb_69_837)), .b(4'(limb_69_839)), .cin(limb_69_836), .value(limb_69_840[3:0]));
    assign limb_69_840[4:4] = '0;
    assign limb_69_841 = limb_69_840[3:0]; // decl: <none>; prim: <none>
    assign limb_69_842 = {limb_69_841, limb_69_835}; // decl: <none>; prim: <none>
    assign limb_76_843 = __beopt_width_313[63:0]; // decl: <none>; prim: <none>
    assign limb_76_844 = tmp_workload_top_int_130__158_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_76_845 = (~limb_76_844); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_846Core rtlzz_owner_846(.a(64'(limb_76_843)), .b(64'(rtlzz_pipe_845_s7)), .cin(1'h1), .value(limb_76_846));
    assign limb_76_847 = limb_76_846[63:0]; // decl: <none>; prim: <none>
    assign limb_76_848 = limb_76_846[64]; // decl: <none>; prim: <none>
    assign limb_76_849 = __beopt_width_313[127:64]; // decl: <none>; prim: <none>
    assign limb_76_850 = tmp_workload_top_int_130__158_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_76_851 = (~limb_76_850); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_852Core rtlzz_owner_852(.a(64'(limb_76_849)), .b(64'(rtlzz_pipe_851_s7)), .cin(limb_76_848), .value(limb_76_852));
    assign limb_76_853 = limb_76_852[63:0]; // decl: <none>; prim: <none>
    assign limb_76_854 = limb_76_852[64]; // decl: <none>; prim: <none>
    assign limb_76_855 = __beopt_width_313[129:128]; // decl: <none>; prim: <none>
    assign limb_76_856 = tmp_workload_top_int_130__158_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_76_857 = (~limb_76_856); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_858Core rtlzz_owner_858(.a(2'(limb_76_855)), .b(2'(rtlzz_pipe_857_s7)), .cin(limb_76_854), .value(limb_76_858[1:0]));
    assign limb_76_858[2:2] = '0;
    assign limb_76_859 = limb_76_858[1:0]; // decl: <none>; prim: <none>
    assign limb_76_860 = {limb_76_859, limb_76_853, limb_76_847}; // decl: <none>; prim: <none>
    assign limb_78_861 = s8_norm_sub_118_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_862 = tmp_workload_top_int_130__161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_863 = (~limb_78_862); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_864Core rtlzz_owner_864(.a(64'(limb_78_861)), .b(64'(limb_78_863)), .cin(1'h1), .value(limb_78_864));
    assign limb_78_865 = limb_78_864[63:0]; // decl: <none>; prim: <none>
    assign limb_78_866 = limb_78_864[64]; // decl: <none>; prim: <none>
    assign limb_78_867 = s8_norm_sub_118_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_868 = tmp_workload_top_int_130__161_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_869 = (~limb_78_868); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_870Core rtlzz_owner_870(.a(64'(limb_78_867)), .b(64'(limb_78_869)), .cin(limb_78_866), .value(limb_78_870));
    assign limb_78_871 = limb_78_870[63:0]; // decl: <none>; prim: <none>
    assign limb_78_872 = limb_78_870[64]; // decl: <none>; prim: <none>
    assign limb_78_873 = s8_norm_sub_118_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_874 = tmp_workload_top_int_130__161_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_875 = (~limb_78_874); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_876Core rtlzz_owner_876(.a(2'(limb_78_873)), .b(2'(limb_78_875)), .cin(limb_78_872), .value(limb_78_876[1:0]));
    assign limb_78_876[2:2] = '0;
    assign limb_78_877 = limb_78_876[1:0]; // decl: <none>; prim: <none>
    assign limb_78_878 = {limb_78_877, limb_78_871, limb_78_865}; // decl: <none>; prim: <none>
    assign limb_85_879 = tmp_workload_top_int_129__174_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_85_880 = __beopt_width_374[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_881Core rtlzz_owner_881(.a(64'(rtlzz_pipe_879_s2)), .b(64'(limb_85_880)), .cin(1'h0), .value(limb_85_881));
    assign limb_85_882 = limb_85_881[63:0]; // decl: <none>; prim: <none>
    assign limb_85_883 = limb_85_881[64]; // decl: <none>; prim: <none>
    assign limb_85_884 = tmp_workload_top_int_129__174_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_85_885 = __beopt_width_374[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_886Core rtlzz_owner_886(.a(64'(rtlzz_pipe_884_s2)), .b(64'(limb_85_885)), .cin(limb_85_883), .value(limb_85_886));
    assign limb_85_887 = limb_85_886[63:0]; // decl: <none>; prim: <none>
    assign limb_85_888 = limb_85_886[64]; // decl: <none>; prim: <none>
    assign limb_85_889 = tmp_workload_top_int_129__174_v0[128]; // decl: <none>; prim: <none>
    assign limb_85_890 = __beopt_width_374[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_891Core rtlzz_owner_891(.a(1'(rtlzz_pipe_889_s2)), .b(1'(limb_85_890)), .cin(limb_85_888), .value(limb_85_891[0:0]));
    assign limb_85_891[1:1] = '0;
    assign limb_85_892 = limb_85_891[0]; // decl: <none>; prim: <none>
    assign limb_85_893 = {limb_85_892, limb_85_887, limb_85_882}; // decl: <none>; prim: <none>
    assign limb_87_894 = tmp_workload_top_int_129__179_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_87_895 = __beopt_width_378[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_896Core rtlzz_owner_896(.a(64'(rtlzz_pipe_894_s3)), .b(64'(limb_87_895)), .cin(1'h0), .value(limb_87_896));
    assign limb_87_897 = limb_87_896[63:0]; // decl: <none>; prim: <none>
    assign limb_87_898 = limb_87_896[64]; // decl: <none>; prim: <none>
    assign limb_87_899 = tmp_workload_top_int_129__179_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_87_900 = __beopt_width_378[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_901Core rtlzz_owner_901(.a(64'(rtlzz_pipe_899_s3)), .b(64'(limb_87_900)), .cin(limb_87_898), .value(limb_87_901));
    assign limb_87_902 = limb_87_901[63:0]; // decl: <none>; prim: <none>
    assign limb_87_903 = limb_87_901[64]; // decl: <none>; prim: <none>
    assign limb_87_904 = tmp_workload_top_int_129__179_v0[128]; // decl: <none>; prim: <none>
    assign limb_87_905 = __beopt_width_378[128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_906Core rtlzz_owner_906(.a(1'(rtlzz_pipe_904_s3)), .b(1'(limb_87_905)), .cin(limb_87_903), .value(limb_87_906[0:0]));
    assign limb_87_906[1:1] = '0;
    assign limb_87_907 = limb_87_906[0]; // decl: <none>; prim: <none>
    assign limb_87_908 = {limb_87_907, limb_87_902, limb_87_897}; // decl: <none>; prim: <none>
    assign limb_103_909 = n60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_910 = tmp_workload_top_int_68__217_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_911 = (~limb_103_910); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_912Core rtlzz_owner_912(.a(64'(limb_103_909)), .b(64'(limb_103_911)), .cin(1'h1), .value(limb_103_912));
    assign limb_103_913 = limb_103_912[63:0]; // decl: <none>; prim: <none>
    assign limb_103_914 = limb_103_912[64]; // decl: <none>; prim: <none>
    assign limb_103_915 = n60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_916 = tmp_workload_top_int_68__217_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_917 = (~limb_103_916); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_918Core rtlzz_owner_918(.a(4'(limb_103_915)), .b(4'(limb_103_917)), .cin(limb_103_914), .value(limb_103_918[3:0]));
    assign limb_103_918[4:4] = '0;
    assign limb_103_919 = limb_103_918[3:0]; // decl: <none>; prim: <none>
    assign limb_103_920 = {limb_103_919, limb_103_913}; // decl: <none>; prim: <none>
    assign limb_105_921 = s8_norm_sub_161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_922 = tmp_workload_top_int_68__220_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_923 = (~rtlzz_pipe_922_s5); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_924Core rtlzz_owner_924(.a(64'(rtlzz_pipe_921_s5)), .b(64'(limb_105_923)), .cin(1'h1), .value(limb_105_924));
    assign limb_105_925 = limb_105_924[63:0]; // decl: <none>; prim: <none>
    assign limb_105_926 = limb_105_924[64]; // decl: <none>; prim: <none>
    assign limb_105_927 = s8_norm_sub_161_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_928 = tmp_workload_top_int_68__220_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_929 = (~rtlzz_pipe_928_s5); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_930Core rtlzz_owner_930(.a(4'(rtlzz_pipe_927_s5)), .b(4'(limb_105_929)), .cin(limb_105_926), .value(limb_105_930[3:0]));
    assign limb_105_930[4:4] = '0;
    assign limb_105_931 = limb_105_930[3:0]; // decl: <none>; prim: <none>
    assign limb_105_932 = {limb_105_931, limb_105_925}; // decl: <none>; prim: <none>
    assign limb_113_933 = tmp_workload_top_int_66__238_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_113_934 = __beopt_width_401[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_935Core rtlzz_owner_935(.a(64'(rtlzz_pipe_933_s4)), .b(64'(limb_113_934)), .cin(1'h0), .value(limb_113_935));
    assign limb_113_936 = limb_113_935[63:0]; // decl: <none>; prim: <none>
    assign limb_113_937 = limb_113_935[64]; // decl: <none>; prim: <none>
    assign limb_113_938 = tmp_workload_top_int_66__238_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_113_939 = __beopt_width_401[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_940Core rtlzz_owner_940(.a(2'(rtlzz_pipe_938_s4)), .b(2'(limb_113_939)), .cin(limb_113_937), .value(limb_113_940[1:0]));
    assign limb_113_940[2:2] = '0;
    assign limb_113_941 = limb_113_940[1:0]; // decl: <none>; prim: <none>
    assign limb_113_942 = {limb_113_941, limb_113_936}; // decl: <none>; prim: <none>
    assign limb_115_943 = tmp_workload_top_int_66__243_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_115_944 = __beopt_width_404[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_945Core rtlzz_owner_945(.a(64'(rtlzz_pipe_943_s4)), .b(64'(limb_115_944)), .cin(1'h0), .value(limb_115_945));
    assign limb_115_946 = limb_115_945[63:0]; // decl: <none>; prim: <none>
    assign limb_115_947 = limb_115_945[64]; // decl: <none>; prim: <none>
    assign limb_115_948 = tmp_workload_top_int_66__243_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_115_949 = __beopt_width_404[65:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_950Core rtlzz_owner_950(.a(2'(rtlzz_pipe_948_s4)), .b(2'(limb_115_949)), .cin(limb_115_947), .value(limb_115_950[1:0]));
    assign limb_115_950[2:2] = '0;
    assign limb_115_951 = limb_115_950[1:0]; // decl: <none>; prim: <none>
    assign limb_115_952 = {limb_115_951, limb_115_946}; // decl: <none>; prim: <none>
    assign limb_129_953 = n74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_954 = tmp_workload_top_int_68__277_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_955 = (~limb_129_954); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_956Core rtlzz_owner_956(.a(64'(limb_129_953)), .b(64'(rtlzz_pipe_955_s6)), .cin(1'h1), .value(limb_129_956));
    assign limb_129_957 = limb_129_956[63:0]; // decl: <none>; prim: <none>
    assign limb_129_958 = limb_129_956[64]; // decl: <none>; prim: <none>
    assign limb_129_959 = n74_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_960 = tmp_workload_top_int_68__277_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_961 = (~limb_129_960); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_962Core rtlzz_owner_962(.a(4'(limb_129_959)), .b(4'(rtlzz_pipe_961_s6)), .cin(limb_129_958), .value(limb_129_962[3:0]));
    assign limb_129_962[4:4] = '0;
    assign limb_129_963 = limb_129_962[3:0]; // decl: <none>; prim: <none>
    assign limb_129_964 = {limb_129_963, limb_129_957}; // decl: <none>; prim: <none>
    assign limb_131_965 = s8_norm_sub_204_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_966 = tmp_workload_top_int_68__280_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_967 = (~limb_131_966); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_968Core rtlzz_owner_968(.a(64'(limb_131_965)), .b(64'(limb_131_967)), .cin(1'h1), .value(limb_131_968));
    assign limb_131_969 = limb_131_968[63:0]; // decl: <none>; prim: <none>
    assign limb_131_970 = limb_131_968[64]; // decl: <none>; prim: <none>
    assign limb_131_971 = s8_norm_sub_204_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_972 = tmp_workload_top_int_68__280_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_973 = (~limb_131_972); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_974Core rtlzz_owner_974(.a(4'(limb_131_971)), .b(4'(limb_131_973)), .cin(limb_131_970), .value(limb_131_974[3:0]));
    assign limb_131_974[4:4] = '0;
    assign limb_131_975 = limb_131_974[3:0]; // decl: <none>; prim: <none>
    assign limb_131_976 = {limb_131_975, limb_131_969}; // decl: <none>; prim: <none>
    assign limb_138_977 = __beopt_width_307[63:0]; // decl: <none>; prim: <none>
    assign limb_138_978 = tmp_workload_top_int_132__293_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_138_979 = (~limb_138_978); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_980Core rtlzz_owner_980(.a(64'(limb_138_977)), .b(64'(rtlzz_pipe_979_s6)), .cin(1'h1), .value(limb_138_980));
    assign limb_138_981 = limb_138_980[63:0]; // decl: <none>; prim: <none>
    assign limb_138_982 = limb_138_980[64]; // decl: <none>; prim: <none>
    assign limb_138_983 = __beopt_width_307[127:64]; // decl: <none>; prim: <none>
    assign limb_138_984 = tmp_workload_top_int_132__293_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_138_985 = (~limb_138_984); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_986Core rtlzz_owner_986(.a(64'(limb_138_983)), .b(64'(rtlzz_pipe_985_s6)), .cin(limb_138_982), .value(limb_138_986));
    assign limb_138_987 = limb_138_986[63:0]; // decl: <none>; prim: <none>
    assign limb_138_988 = limb_138_986[64]; // decl: <none>; prim: <none>
    assign limb_138_989 = __beopt_width_307[131:128]; // decl: <none>; prim: <none>
    assign limb_138_990 = tmp_workload_top_int_132__293_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_138_991 = (~limb_138_990); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_992Core rtlzz_owner_992(.a(4'(limb_138_989)), .b(4'(rtlzz_pipe_991_s6)), .cin(limb_138_988), .value(limb_138_992[3:0]));
    assign limb_138_992[4:4] = '0;
    assign limb_138_993 = limb_138_992[3:0]; // decl: <none>; prim: <none>
    assign limb_138_994 = {limb_138_993, limb_138_987, limb_138_981}; // decl: <none>; prim: <none>
    assign limb_140_995 = s8_norm_sub_215_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_996 = tmp_workload_top_int_132__296_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_997 = (~limb_140_996); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_998Core rtlzz_owner_998(.a(64'(limb_140_995)), .b(64'(rtlzz_pipe_997_s6)), .cin(1'h1), .value(limb_140_998));
    assign limb_140_999 = limb_140_998[63:0]; // decl: <none>; prim: <none>
    assign limb_140_1000 = limb_140_998[64]; // decl: <none>; prim: <none>
    assign limb_140_1001 = s8_norm_sub_215_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_1002 = tmp_workload_top_int_132__296_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_1003 = (~limb_140_1002); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1004Core rtlzz_owner_1004(.a(64'(limb_140_1001)), .b(64'(rtlzz_pipe_1003_s6)), .cin(limb_140_1000), .value(limb_140_1004));
    assign limb_140_1005 = limb_140_1004[63:0]; // decl: <none>; prim: <none>
    assign limb_140_1006 = limb_140_1004[64]; // decl: <none>; prim: <none>
    assign limb_140_1007 = s8_norm_sub_215_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1008 = tmp_workload_top_int_132__296_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1009 = (~limb_140_1008); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1010Core rtlzz_owner_1010(.a(4'(limb_140_1007)), .b(4'(rtlzz_pipe_1009_s6)), .cin(limb_140_1006), .value(limb_140_1010[3:0]));
    assign limb_140_1010[4:4] = '0;
    assign limb_140_1011 = limb_140_1010[3:0]; // decl: <none>; prim: <none>
    assign limb_140_1012 = {limb_140_1011, limb_140_1005, limb_140_999}; // decl: <none>; prim: <none>
    assign limb_147_1013 = __beopt_width_297[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1014 = tmp_workload_top_int_258__309_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1015 = (~limb_147_1014); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1016Core rtlzz_owner_1016(.a(64'(limb_147_1013)), .b(64'(limb_147_1015)), .cin(1'h1), .value(limb_147_1016));
    assign limb_147_1017 = limb_147_1016[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1018 = limb_147_1016[64]; // decl: <none>; prim: <none>
    assign limb_147_1019 = __beopt_width_297[127:64]; // decl: <none>; prim: <none>
    assign limb_147_1020 = tmp_workload_top_int_258__309_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_147_1021 = (~limb_147_1020); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1022Core rtlzz_owner_1022(.a(64'(limb_147_1019)), .b(64'(limb_147_1021)), .cin(limb_147_1018), .value(limb_147_1022));
    assign limb_147_1023 = limb_147_1022[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1024 = limb_147_1022[64]; // decl: <none>; prim: <none>
    assign limb_147_1025 = __beopt_width_297[191:128]; // decl: <none>; prim: <none>
    assign limb_147_1026 = tmp_workload_top_int_258__309_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_147_1027 = (~limb_147_1026); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1028Core rtlzz_owner_1028(.a(64'(limb_147_1025)), .b(64'(limb_147_1027)), .cin(limb_147_1024), .value(limb_147_1028));
    assign limb_147_1029 = limb_147_1028[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1030 = limb_147_1028[64]; // decl: <none>; prim: <none>
    assign limb_147_1031 = __beopt_width_297[255:192]; // decl: <none>; prim: <none>
    assign limb_147_1032 = tmp_workload_top_int_258__309_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_147_1033 = (~limb_147_1032); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1034Core rtlzz_owner_1034(.a(64'(limb_147_1031)), .b(64'(limb_147_1033)), .cin(limb_147_1030), .value(limb_147_1034));
    assign limb_147_1035 = limb_147_1034[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1036 = limb_147_1034[64]; // decl: <none>; prim: <none>
    assign limb_147_1037 = __beopt_width_297[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1038 = tmp_workload_top_int_258__309_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1039 = (~limb_147_1038); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1040Core rtlzz_owner_1040(.a(2'(limb_147_1037)), .b(2'(limb_147_1039)), .cin(limb_147_1036), .value(limb_147_1040[1:0]));
    assign limb_147_1040[2:2] = '0;
    assign limb_147_1041 = limb_147_1040[1:0]; // decl: <none>; prim: <none>
    assign limb_147_1042 = {limb_147_1041, limb_147_1035, limb_147_1029, limb_147_1023, limb_147_1017}; // decl: <none>; prim: <none>
    assign limb_149_1043 = s8_norm_sub_226_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1044 = tmp_workload_top_int_258__312_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1045 = (~limb_149_1044); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1046Core rtlzz_owner_1046(.a(64'(limb_149_1043)), .b(64'(limb_149_1045)), .cin(1'h1), .value(limb_149_1046));
    assign limb_149_1047 = limb_149_1046[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1048 = limb_149_1046[64]; // decl: <none>; prim: <none>
    assign limb_149_1049 = s8_norm_sub_226_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_1050 = tmp_workload_top_int_258__312_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_1051 = (~limb_149_1050); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1052Core rtlzz_owner_1052(.a(64'(limb_149_1049)), .b(64'(limb_149_1051)), .cin(limb_149_1048), .value(limb_149_1052));
    assign limb_149_1053 = limb_149_1052[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1054 = limb_149_1052[64]; // decl: <none>; prim: <none>
    assign limb_149_1055 = s8_norm_sub_226_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_1056 = tmp_workload_top_int_258__312_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_1057 = (~limb_149_1056); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1058Core rtlzz_owner_1058(.a(64'(limb_149_1055)), .b(64'(limb_149_1057)), .cin(limb_149_1054), .value(limb_149_1058));
    assign limb_149_1059 = limb_149_1058[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1060 = limb_149_1058[64]; // decl: <none>; prim: <none>
    assign limb_149_1061 = s8_norm_sub_226_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_1062 = tmp_workload_top_int_258__312_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_1063 = (~limb_149_1062); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1064Core rtlzz_owner_1064(.a(64'(limb_149_1061)), .b(64'(limb_149_1063)), .cin(limb_149_1060), .value(limb_149_1064));
    assign limb_149_1065 = limb_149_1064[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1066 = limb_149_1064[64]; // decl: <none>; prim: <none>
    assign limb_149_1067 = s8_norm_sub_226_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1068 = tmp_workload_top_int_258__312_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1069 = (~limb_149_1068); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1070Core rtlzz_owner_1070(.a(2'(limb_149_1067)), .b(2'(limb_149_1069)), .cin(limb_149_1066), .value(limb_149_1070[1:0]));
    assign limb_149_1070[2:2] = '0;
    assign limb_149_1071 = limb_149_1070[1:0]; // decl: <none>; prim: <none>
    assign limb_149_1072 = {limb_149_1071, limb_149_1065, limb_149_1059, limb_149_1053, limb_149_1047}; // decl: <none>; prim: <none>
    assign limb_157_1073 = tmp_workload_top_int_513__325_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1074 = tmp_workload_top_int_513__327_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1075Core rtlzz_owner_1075(.a(64'(limb_157_1073)), .b(64'(rtlzz_pipe_1074_s7)), .cin(1'h0), .value(limb_157_1075));
    assign limb_157_1076 = limb_157_1075[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1077 = limb_157_1075[64]; // decl: <none>; prim: <none>
    assign limb_157_1078 = tmp_workload_top_int_513__325_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_157_1079 = tmp_workload_top_int_513__327_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1080Core rtlzz_owner_1080(.a(64'(limb_157_1078)), .b(64'(rtlzz_pipe_1079_s7)), .cin(limb_157_1077), .value(limb_157_1080));
    assign limb_157_1081 = limb_157_1080[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1082 = limb_157_1080[64]; // decl: <none>; prim: <none>
    assign limb_157_1083 = tmp_workload_top_int_513__325_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_157_1084 = tmp_workload_top_int_513__327_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1085Core rtlzz_owner_1085(.a(64'(limb_157_1083)), .b(64'(rtlzz_pipe_1084_s7)), .cin(limb_157_1082), .value(limb_157_1085));
    assign limb_157_1086 = limb_157_1085[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1087 = limb_157_1085[64]; // decl: <none>; prim: <none>
    assign limb_157_1088 = tmp_workload_top_int_513__325_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_157_1089 = tmp_workload_top_int_513__327_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1090Core rtlzz_owner_1090(.a(64'(limb_157_1088)), .b(64'(rtlzz_pipe_1089_s7)), .cin(limb_157_1087), .value(limb_157_1090));
    assign limb_157_1091 = limb_157_1090[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1092 = limb_157_1090[64]; // decl: <none>; prim: <none>
    assign limb_157_1093 = tmp_workload_top_int_513__325_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_157_1094 = tmp_workload_top_int_513__327_v0[319:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1095Core rtlzz_owner_1095(.a(64'(limb_157_1093)), .b(64'(rtlzz_pipe_1094_s7)), .cin(limb_157_1092), .value(limb_157_1095));
    assign limb_157_1096 = limb_157_1095[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1097 = limb_157_1095[64]; // decl: <none>; prim: <none>
    assign limb_157_1098 = tmp_workload_top_int_513__325_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_157_1099 = tmp_workload_top_int_513__327_v0[383:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1100Core rtlzz_owner_1100(.a(64'(limb_157_1098)), .b(64'(rtlzz_pipe_1099_s7)), .cin(limb_157_1097), .value(limb_157_1100));
    assign limb_157_1101 = limb_157_1100[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1102 = limb_157_1100[64]; // decl: <none>; prim: <none>
    assign limb_157_1103 = tmp_workload_top_int_513__325_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_157_1104 = tmp_workload_top_int_513__327_v0[447:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1105Core rtlzz_owner_1105(.a(64'(limb_157_1103)), .b(64'(rtlzz_pipe_1104_s7)), .cin(limb_157_1102), .value(limb_157_1105));
    assign limb_157_1106 = limb_157_1105[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1107 = limb_157_1105[64]; // decl: <none>; prim: <none>
    assign limb_157_1108 = tmp_workload_top_int_513__325_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_157_1109 = tmp_workload_top_int_513__327_v0[511:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1110Core rtlzz_owner_1110(.a(64'(limb_157_1108)), .b(64'(rtlzz_pipe_1109_s7)), .cin(limb_157_1107), .value(limb_157_1110));
    assign limb_157_1111 = limb_157_1110[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1112 = limb_157_1110[64]; // decl: <none>; prim: <none>
    assign limb_157_1113 = tmp_workload_top_int_513__325_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_1114 = tmp_workload_top_int_513__327_v0[512]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1115Core rtlzz_owner_1115(.a(1'(limb_157_1113)), .b(1'(rtlzz_pipe_1114_s7)), .cin(limb_157_1112), .value(limb_157_1115[0:0]));
    assign limb_157_1115[1:1] = '0;
    assign limb_157_1116 = limb_157_1115[0]; // decl: <none>; prim: <none>
    assign limb_157_1117 = {limb_157_1116, limb_157_1111, limb_157_1106, limb_157_1101, limb_157_1096, limb_157_1091, limb_157_1086, limb_157_1081, limb_157_1076}; // decl: <none>; prim: <none>
    assign limb_216_1118 = tmp_workload_top_int_512__315_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1119 = s8_norm_shift_234_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1120Core rtlzz_owner_1120(.a(64'(limb_216_1118)), .b(64'(limb_216_1119)), .cin(1'h0), .value(limb_216_1120));
    assign limb_216_1121 = limb_216_1120[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1122 = limb_216_1120[64]; // decl: <none>; prim: <none>
    assign limb_216_1123 = tmp_workload_top_int_512__315_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_216_1124 = s8_norm_shift_234_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1125Core rtlzz_owner_1125(.a(64'(limb_216_1123)), .b(64'(limb_216_1124)), .cin(limb_216_1122), .value(limb_216_1125));
    assign limb_216_1126 = limb_216_1125[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1127 = limb_216_1125[64]; // decl: <none>; prim: <none>
    assign limb_216_1128 = tmp_workload_top_int_512__315_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_216_1129 = s8_norm_shift_234_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1130Core rtlzz_owner_1130(.a(64'(limb_216_1128)), .b(64'(limb_216_1129)), .cin(limb_216_1127), .value(limb_216_1130));
    assign limb_216_1131 = limb_216_1130[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1132 = limb_216_1130[64]; // decl: <none>; prim: <none>
    assign limb_216_1133 = tmp_workload_top_int_512__315_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_216_1134 = s8_norm_shift_234_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1135Core rtlzz_owner_1135(.a(64'(limb_216_1133)), .b(64'(limb_216_1134)), .cin(limb_216_1132), .value(limb_216_1135));
    assign limb_216_1136 = limb_216_1135[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1137 = limb_216_1135[64]; // decl: <none>; prim: <none>
    assign limb_216_1138 = tmp_workload_top_int_512__315_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_216_1139 = s8_norm_shift_234_v0[319:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1140Core rtlzz_owner_1140(.a(64'(limb_216_1138)), .b(64'(limb_216_1139)), .cin(limb_216_1137), .value(limb_216_1140));
    assign limb_216_1141 = limb_216_1140[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1142 = limb_216_1140[64]; // decl: <none>; prim: <none>
    assign limb_216_1143 = tmp_workload_top_int_512__315_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_216_1144 = s8_norm_shift_234_v0[383:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1145Core rtlzz_owner_1145(.a(64'(limb_216_1143)), .b(64'(limb_216_1144)), .cin(limb_216_1142), .value(limb_216_1145));
    assign limb_216_1146 = limb_216_1145[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1147 = limb_216_1145[64]; // decl: <none>; prim: <none>
    assign limb_216_1148 = tmp_workload_top_int_512__315_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_216_1149 = s8_norm_shift_234_v0[447:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1150Core rtlzz_owner_1150(.a(64'(limb_216_1148)), .b(64'(limb_216_1149)), .cin(limb_216_1147), .value(limb_216_1150));
    assign limb_216_1151 = limb_216_1150[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1152 = limb_216_1150[64]; // decl: <none>; prim: <none>
    assign limb_216_1153 = tmp_workload_top_int_512__315_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_216_1154 = s8_norm_shift_234_v0[511:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1155Core rtlzz_owner_1155(.a(64'(limb_216_1153)), .b(64'(limb_216_1154)), .cin(limb_216_1152), .value(limb_216_1155[63:0]));
    assign limb_216_1155[64:64] = '0;
    assign limb_216_1156 = limb_216_1155[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1157 = {limb_216_1156, limb_216_1151, limb_216_1146, limb_216_1141, limb_216_1136, limb_216_1131, limb_216_1126, limb_216_1121}; // decl: <none>; prim: <none>
    assign limb_217_1158 = __beopt_width_292[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1159 = s8_norm_shift_231_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1160Core rtlzz_owner_1160(.a(64'(limb_217_1158)), .b(64'(limb_217_1159)), .cin(1'h0), .value(limb_217_1160));
    assign limb_217_1161 = limb_217_1160[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1162 = limb_217_1160[64]; // decl: <none>; prim: <none>
    assign limb_217_1163 = __beopt_width_292[127:64]; // decl: <none>; prim: <none>
    assign limb_217_1164 = s8_norm_shift_231_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1165Core rtlzz_owner_1165(.a(64'(limb_217_1163)), .b(64'(limb_217_1164)), .cin(limb_217_1162), .value(limb_217_1165));
    assign limb_217_1166 = limb_217_1165[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1167 = limb_217_1165[64]; // decl: <none>; prim: <none>
    assign limb_217_1168 = __beopt_width_292[191:128]; // decl: <none>; prim: <none>
    assign limb_217_1169 = s8_norm_shift_231_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1170Core rtlzz_owner_1170(.a(64'(limb_217_1168)), .b(64'(limb_217_1169)), .cin(limb_217_1167), .value(limb_217_1170));
    assign limb_217_1171 = limb_217_1170[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1172 = limb_217_1170[64]; // decl: <none>; prim: <none>
    assign limb_217_1173 = __beopt_width_292[255:192]; // decl: <none>; prim: <none>
    assign limb_217_1174 = s8_norm_shift_231_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1175Core rtlzz_owner_1175(.a(64'(limb_217_1173)), .b(64'(limb_217_1174)), .cin(limb_217_1172), .value(limb_217_1175));
    assign limb_217_1176 = limb_217_1175[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1177 = limb_217_1175[64]; // decl: <none>; prim: <none>
    assign limb_217_1178 = __beopt_width_292[319:256]; // decl: <none>; prim: <none>
    assign limb_217_1179 = s8_norm_shift_231_v0[319:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1180Core rtlzz_owner_1180(.a(64'(limb_217_1178)), .b(64'(limb_217_1179)), .cin(limb_217_1177), .value(limb_217_1180));
    assign limb_217_1181 = limb_217_1180[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1182 = limb_217_1180[64]; // decl: <none>; prim: <none>
    assign limb_217_1183 = __beopt_width_292[383:320]; // decl: <none>; prim: <none>
    assign limb_217_1184 = s8_norm_shift_231_v0[383:320]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1185Core rtlzz_owner_1185(.a(64'(limb_217_1183)), .b(64'(limb_217_1184)), .cin(limb_217_1182), .value(limb_217_1185));
    assign limb_217_1186 = limb_217_1185[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1187 = limb_217_1185[64]; // decl: <none>; prim: <none>
    assign limb_217_1188 = __beopt_width_292[447:384]; // decl: <none>; prim: <none>
    assign limb_217_1189 = s8_norm_shift_231_v0[447:384]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1190Core rtlzz_owner_1190(.a(64'(limb_217_1188)), .b(64'(limb_217_1189)), .cin(limb_217_1187), .value(limb_217_1190));
    assign limb_217_1191 = limb_217_1190[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1192 = limb_217_1190[64]; // decl: <none>; prim: <none>
    assign limb_217_1193 = __beopt_width_292[511:448]; // decl: <none>; prim: <none>
    assign limb_217_1194 = s8_norm_shift_231_v0[511:448]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1195Core rtlzz_owner_1195(.a(64'(limb_217_1193)), .b(64'(limb_217_1194)), .cin(limb_217_1192), .value(limb_217_1195[63:0]));
    assign limb_217_1195[64:64] = '0;
    assign limb_217_1196 = limb_217_1195[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1197 = {limb_217_1196, limb_217_1191, limb_217_1186, limb_217_1181, limb_217_1176, limb_217_1171, limb_217_1166, limb_217_1161}; // decl: <none>; prim: <none>
    assign limb_218_1198 = s8_norm_shift_223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1199 = tmp_workload_top_int_258__299_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1200Core rtlzz_owner_1200(.a(64'(limb_218_1198)), .b(64'(limb_218_1199)), .cin(1'h0), .value(limb_218_1200));
    assign limb_218_1201 = limb_218_1200[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1202 = limb_218_1200[64]; // decl: <none>; prim: <none>
    assign limb_218_1203 = s8_norm_shift_223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_218_1204 = tmp_workload_top_int_258__299_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1205Core rtlzz_owner_1205(.a(64'(limb_218_1203)), .b(64'(limb_218_1204)), .cin(limb_218_1202), .value(limb_218_1205));
    assign limb_218_1206 = limb_218_1205[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1207 = limb_218_1205[64]; // decl: <none>; prim: <none>
    assign limb_218_1208 = s8_norm_shift_223_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_218_1209 = tmp_workload_top_int_258__299_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1210Core rtlzz_owner_1210(.a(64'(limb_218_1208)), .b(64'(limb_218_1209)), .cin(limb_218_1207), .value(limb_218_1210));
    assign limb_218_1211 = limb_218_1210[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1212 = limb_218_1210[64]; // decl: <none>; prim: <none>
    assign limb_218_1213 = s8_norm_shift_223_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_218_1214 = tmp_workload_top_int_258__299_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1215Core rtlzz_owner_1215(.a(64'(limb_218_1213)), .b(64'(limb_218_1214)), .cin(limb_218_1212), .value(limb_218_1215));
    assign limb_218_1216 = limb_218_1215[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1217 = limb_218_1215[64]; // decl: <none>; prim: <none>
    assign limb_218_1218 = s8_norm_shift_223_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_1219 = tmp_workload_top_int_258__299_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1220Core rtlzz_owner_1220(.a(2'(limb_218_1218)), .b(2'(limb_218_1219)), .cin(limb_218_1217), .value(limb_218_1220[1:0]));
    assign limb_218_1220[2:2] = '0;
    assign limb_218_1221 = limb_218_1220[1:0]; // decl: <none>; prim: <none>
    assign limb_218_1222 = {limb_218_1221, limb_218_1216, limb_218_1211, limb_218_1206, limb_218_1201}; // decl: <none>; prim: <none>
    assign limb_219_1223 = __beopt_width_295[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1224 = s8_norm_shift_220_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1225Core rtlzz_owner_1225(.a(64'(rtlzz_pipe_1223_s6)), .b(64'(limb_219_1224)), .cin(1'h0), .value(limb_219_1225));
    assign limb_219_1226 = limb_219_1225[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1227 = limb_219_1225[64]; // decl: <none>; prim: <none>
    assign limb_219_1228 = __beopt_width_295[127:64]; // decl: <none>; prim: <none>
    assign limb_219_1229 = s8_norm_shift_220_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1230Core rtlzz_owner_1230(.a(64'(rtlzz_pipe_1228_s6)), .b(64'(limb_219_1229)), .cin(limb_219_1227), .value(limb_219_1230));
    assign limb_219_1231 = limb_219_1230[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1232 = limb_219_1230[64]; // decl: <none>; prim: <none>
    assign limb_219_1233 = __beopt_width_295[191:128]; // decl: <none>; prim: <none>
    assign limb_219_1234 = s8_norm_shift_220_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1235Core rtlzz_owner_1235(.a(64'(rtlzz_pipe_1233_s7)), .b(64'(rtlzz_pipe_1234_s7)), .cin(rtlzz_pipe_1232_s7), .value(limb_219_1235));
    assign limb_219_1236 = limb_219_1235[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1237 = limb_219_1235[64]; // decl: <none>; prim: <none>
    assign limb_219_1238 = __beopt_width_295[255:192]; // decl: <none>; prim: <none>
    assign limb_219_1239 = s8_norm_shift_220_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1240Core rtlzz_owner_1240(.a(64'(rtlzz_pipe_1238_s7)), .b(64'(rtlzz_pipe_1239_s7)), .cin(limb_219_1237), .value(limb_219_1240));
    assign limb_219_1241 = limb_219_1240[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1242 = limb_219_1240[64]; // decl: <none>; prim: <none>
    assign limb_219_1243 = __beopt_width_295[257:256]; // decl: <none>; prim: <none>
    assign limb_219_1244 = s8_norm_shift_220_v0[257:256]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1245Core rtlzz_owner_1245(.a(2'(rtlzz_pipe_1243_s7)), .b(2'(rtlzz_pipe_1244_s7)), .cin(limb_219_1242), .value(limb_219_1245[1:0]));
    assign limb_219_1245[2:2] = '0;
    assign limb_219_1246 = limb_219_1245[1:0]; // decl: <none>; prim: <none>
    assign limb_219_1247 = {limb_219_1246, limb_219_1241, limb_219_1236, rtlzz_pipe_1231_s7, rtlzz_pipe_1226_s7}; // decl: <none>; prim: <none>
    assign limb_220_1248 = tmp_workload_top_int_256__164_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1249 = s8_norm_shift_126_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1250Core rtlzz_owner_1250(.a(64'(limb_220_1248)), .b(64'(limb_220_1249)), .cin(1'h0), .value(limb_220_1250));
    assign limb_220_1251 = limb_220_1250[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1252 = limb_220_1250[64]; // decl: <none>; prim: <none>
    assign limb_220_1253 = tmp_workload_top_int_256__164_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_220_1254 = s8_norm_shift_126_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1255Core rtlzz_owner_1255(.a(64'(limb_220_1253)), .b(64'(limb_220_1254)), .cin(limb_220_1252), .value(limb_220_1255));
    assign limb_220_1256 = limb_220_1255[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1257 = limb_220_1255[64]; // decl: <none>; prim: <none>
    assign limb_220_1258 = tmp_workload_top_int_256__164_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_220_1259 = s8_norm_shift_126_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1260Core rtlzz_owner_1260(.a(64'(limb_220_1258)), .b(64'(limb_220_1259)), .cin(limb_220_1257), .value(limb_220_1260));
    assign limb_220_1261 = limb_220_1260[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1262 = limb_220_1260[64]; // decl: <none>; prim: <none>
    assign limb_220_1263 = tmp_workload_top_int_256__164_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_220_1264 = s8_norm_shift_126_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1265Core rtlzz_owner_1265(.a(64'(limb_220_1263)), .b(64'(limb_220_1264)), .cin(limb_220_1262), .value(limb_220_1265[63:0]));
    assign limb_220_1265[64:64] = '0;
    assign limb_220_1266 = limb_220_1265[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1267 = {limb_220_1266, limb_220_1261, limb_220_1256, limb_220_1251}; // decl: <none>; prim: <none>
    assign limb_221_1268 = __beopt_width_299[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1269 = s8_norm_shift_123_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1270Core rtlzz_owner_1270(.a(64'(limb_221_1268)), .b(64'(limb_221_1269)), .cin(1'h0), .value(limb_221_1270));
    assign limb_221_1271 = limb_221_1270[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1272 = limb_221_1270[64]; // decl: <none>; prim: <none>
    assign limb_221_1273 = __beopt_width_299[127:64]; // decl: <none>; prim: <none>
    assign limb_221_1274 = s8_norm_shift_123_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1275Core rtlzz_owner_1275(.a(64'(limb_221_1273)), .b(64'(limb_221_1274)), .cin(limb_221_1272), .value(limb_221_1275));
    assign limb_221_1276 = limb_221_1275[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1277 = limb_221_1275[64]; // decl: <none>; prim: <none>
    assign limb_221_1278 = __beopt_width_299[191:128]; // decl: <none>; prim: <none>
    assign limb_221_1279 = s8_norm_shift_123_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1280Core rtlzz_owner_1280(.a(64'(limb_221_1278)), .b(64'(limb_221_1279)), .cin(limb_221_1277), .value(limb_221_1280));
    assign limb_221_1281 = limb_221_1280[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1282 = limb_221_1280[64]; // decl: <none>; prim: <none>
    assign limb_221_1283 = __beopt_width_299[255:192]; // decl: <none>; prim: <none>
    assign limb_221_1284 = s8_norm_shift_123_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1285Core rtlzz_owner_1285(.a(64'(limb_221_1283)), .b(64'(limb_221_1284)), .cin(limb_221_1282), .value(limb_221_1285[63:0]));
    assign limb_221_1285[64:64] = '0;
    assign limb_221_1286 = limb_221_1285[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1287 = {limb_221_1286, limb_221_1281, limb_221_1276, limb_221_1271}; // decl: <none>; prim: <none>
    assign limb_222_1288 = tmp_workload_top_int_256__79_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1289 = s8_norm_shift_64_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1290Core rtlzz_owner_1290(.a(64'(limb_222_1288)), .b(64'(limb_222_1289)), .cin(1'h0), .value(limb_222_1290));
    assign limb_222_1291 = limb_222_1290[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1292 = limb_222_1290[64]; // decl: <none>; prim: <none>
    assign limb_222_1293 = tmp_workload_top_int_256__79_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_222_1294 = s8_norm_shift_64_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1295Core rtlzz_owner_1295(.a(64'(limb_222_1293)), .b(64'(limb_222_1294)), .cin(limb_222_1292), .value(limb_222_1295));
    assign limb_222_1296 = limb_222_1295[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1297 = limb_222_1295[64]; // decl: <none>; prim: <none>
    assign limb_222_1298 = tmp_workload_top_int_256__79_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_222_1299 = s8_norm_shift_64_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1300Core rtlzz_owner_1300(.a(64'(limb_222_1298)), .b(64'(limb_222_1299)), .cin(limb_222_1297), .value(limb_222_1300));
    assign limb_222_1301 = limb_222_1300[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1302 = limb_222_1300[64]; // decl: <none>; prim: <none>
    assign limb_222_1303 = tmp_workload_top_int_256__79_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_222_1304 = s8_norm_shift_64_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1305Core rtlzz_owner_1305(.a(64'(limb_222_1303)), .b(64'(limb_222_1304)), .cin(limb_222_1302), .value(limb_222_1305[63:0]));
    assign limb_222_1305[64:64] = '0;
    assign limb_222_1306 = limb_222_1305[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1307 = {limb_222_1306, limb_222_1301, limb_222_1296, limb_222_1291}; // decl: <none>; prim: <none>
    assign limb_223_1308 = __beopt_width_302[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1309 = s8_norm_shift_61_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1310Core rtlzz_owner_1310(.a(64'(limb_223_1308)), .b(64'(limb_223_1309)), .cin(1'h0), .value(limb_223_1310));
    assign limb_223_1311 = limb_223_1310[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1312 = limb_223_1310[64]; // decl: <none>; prim: <none>
    assign limb_223_1313 = __beopt_width_302[127:64]; // decl: <none>; prim: <none>
    assign limb_223_1314 = s8_norm_shift_61_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1315Core rtlzz_owner_1315(.a(64'(limb_223_1313)), .b(64'(limb_223_1314)), .cin(limb_223_1312), .value(limb_223_1315));
    assign limb_223_1316 = limb_223_1315[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1317 = limb_223_1315[64]; // decl: <none>; prim: <none>
    assign limb_223_1318 = __beopt_width_302[191:128]; // decl: <none>; prim: <none>
    assign limb_223_1319 = s8_norm_shift_61_v0[191:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1320Core rtlzz_owner_1320(.a(64'(limb_223_1318)), .b(64'(limb_223_1319)), .cin(limb_223_1317), .value(limb_223_1320));
    assign limb_223_1321 = limb_223_1320[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1322 = limb_223_1320[64]; // decl: <none>; prim: <none>
    assign limb_223_1323 = __beopt_width_302[255:192]; // decl: <none>; prim: <none>
    assign limb_223_1324 = s8_norm_shift_61_v0[255:192]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1325Core rtlzz_owner_1325(.a(64'(limb_223_1323)), .b(64'(limb_223_1324)), .cin(limb_223_1322), .value(limb_223_1325[63:0]));
    assign limb_223_1325[64:64] = '0;
    assign limb_223_1326 = limb_223_1325[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1327 = {limb_223_1326, limb_223_1321, limb_223_1316, limb_223_1311}; // decl: <none>; prim: <none>
    assign limb_224_1328 = tmp_workload_top_int_132__283_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1329 = s8_norm_shift_212_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1330Core rtlzz_owner_1330(.a(64'(rtlzz_pipe_1328_s6)), .b(64'(limb_224_1329)), .cin(1'h0), .value(limb_224_1330));
    assign limb_224_1331 = limb_224_1330[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1332 = limb_224_1330[64]; // decl: <none>; prim: <none>
    assign limb_224_1333 = tmp_workload_top_int_132__283_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_224_1334 = s8_norm_shift_212_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1335Core rtlzz_owner_1335(.a(64'(rtlzz_pipe_1333_s6)), .b(64'(limb_224_1334)), .cin(limb_224_1332), .value(limb_224_1335));
    assign limb_224_1336 = limb_224_1335[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1337 = limb_224_1335[64]; // decl: <none>; prim: <none>
    assign limb_224_1338 = tmp_workload_top_int_132__283_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_1339 = s8_norm_shift_212_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1340Core rtlzz_owner_1340(.a(4'(rtlzz_pipe_1338_s6)), .b(4'(limb_224_1339)), .cin(limb_224_1337), .value(limb_224_1340[3:0]));
    assign limb_224_1340[4:4] = '0;
    assign limb_224_1341 = limb_224_1340[3:0]; // decl: <none>; prim: <none>
    assign limb_224_1342 = {limb_224_1341, limb_224_1336, limb_224_1331}; // decl: <none>; prim: <none>
    assign limb_225_1343 = __beopt_width_305[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1344 = s8_norm_shift_209_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1345Core rtlzz_owner_1345(.a(64'(limb_225_1343)), .b(64'(limb_225_1344)), .cin(1'h0), .value(limb_225_1345));
    assign limb_225_1346 = limb_225_1345[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1347 = limb_225_1345[64]; // decl: <none>; prim: <none>
    assign limb_225_1348 = __beopt_width_305[127:64]; // decl: <none>; prim: <none>
    assign limb_225_1349 = s8_norm_shift_209_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1350Core rtlzz_owner_1350(.a(64'(limb_225_1348)), .b(64'(limb_225_1349)), .cin(limb_225_1347), .value(limb_225_1350));
    assign limb_225_1351 = limb_225_1350[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1352 = limb_225_1350[64]; // decl: <none>; prim: <none>
    assign limb_225_1353 = __beopt_width_305[131:128]; // decl: <none>; prim: <none>
    assign limb_225_1354 = s8_norm_shift_209_v0[131:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1355Core rtlzz_owner_1355(.a(4'(limb_225_1353)), .b(4'(limb_225_1354)), .cin(limb_225_1352), .value(limb_225_1355[3:0]));
    assign limb_225_1355[4:4] = '0;
    assign limb_225_1356 = limb_225_1355[3:0]; // decl: <none>; prim: <none>
    assign limb_225_1357 = {limb_225_1356, limb_225_1351, limb_225_1346}; // decl: <none>; prim: <none>
    assign limb_226_1358 = tmp_workload_top_int_130__223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1359 = s8_norm_shift_169_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1360Core rtlzz_owner_1360(.a(64'(rtlzz_pipe_1358_s5)), .b(64'(limb_226_1359)), .cin(1'h0), .value(limb_226_1360));
    assign limb_226_1361 = limb_226_1360[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1362 = limb_226_1360[64]; // decl: <none>; prim: <none>
    assign limb_226_1363 = tmp_workload_top_int_130__223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_226_1364 = s8_norm_shift_169_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1365Core rtlzz_owner_1365(.a(64'(rtlzz_pipe_1363_s5)), .b(64'(limb_226_1364)), .cin(limb_226_1362), .value(limb_226_1365));
    assign limb_226_1366 = limb_226_1365[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1367 = limb_226_1365[64]; // decl: <none>; prim: <none>
    assign limb_226_1368 = tmp_workload_top_int_130__223_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1369 = s8_norm_shift_169_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1370Core rtlzz_owner_1370(.a(2'(rtlzz_pipe_1368_s5)), .b(2'(limb_226_1369)), .cin(limb_226_1367), .value(limb_226_1370[1:0]));
    assign limb_226_1370[2:2] = '0;
    assign limb_226_1371 = limb_226_1370[1:0]; // decl: <none>; prim: <none>
    assign limb_226_1372 = {limb_226_1371, limb_226_1366, limb_226_1361}; // decl: <none>; prim: <none>
    assign limb_227_1373 = __beopt_width_309[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1374 = s8_norm_shift_166_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1375Core rtlzz_owner_1375(.a(64'(limb_227_1373)), .b(64'(limb_227_1374)), .cin(1'h0), .value(limb_227_1375));
    assign limb_227_1376 = limb_227_1375[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1377 = limb_227_1375[64]; // decl: <none>; prim: <none>
    assign limb_227_1378 = __beopt_width_309[127:64]; // decl: <none>; prim: <none>
    assign limb_227_1379 = s8_norm_shift_166_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1380Core rtlzz_owner_1380(.a(64'(limb_227_1378)), .b(64'(limb_227_1379)), .cin(limb_227_1377), .value(limb_227_1380));
    assign limb_227_1381 = limb_227_1380[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1382 = limb_227_1380[64]; // decl: <none>; prim: <none>
    assign limb_227_1383 = __beopt_width_309[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1384 = s8_norm_shift_166_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1385Core rtlzz_owner_1385(.a(2'(limb_227_1383)), .b(2'(limb_227_1384)), .cin(limb_227_1382), .value(limb_227_1385[1:0]));
    assign limb_227_1385[2:2] = '0;
    assign limb_227_1386 = limb_227_1385[1:0]; // decl: <none>; prim: <none>
    assign limb_227_1387 = {limb_227_1386, limb_227_1381, limb_227_1376}; // decl: <none>; prim: <none>
    assign limb_228_1388 = tmp_workload_top_int_130__148_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1389 = s8_norm_shift_115_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1390Core rtlzz_owner_1390(.a(64'(limb_228_1388)), .b(64'(limb_228_1389)), .cin(1'h0), .value(limb_228_1390));
    assign limb_228_1391 = limb_228_1390[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1392 = limb_228_1390[64]; // decl: <none>; prim: <none>
    assign limb_228_1393 = tmp_workload_top_int_130__148_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_228_1394 = s8_norm_shift_115_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1395Core rtlzz_owner_1395(.a(64'(limb_228_1393)), .b(64'(limb_228_1394)), .cin(limb_228_1392), .value(limb_228_1395));
    assign limb_228_1396 = limb_228_1395[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1397 = limb_228_1395[64]; // decl: <none>; prim: <none>
    assign limb_228_1398 = tmp_workload_top_int_130__148_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1399 = s8_norm_shift_115_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1400Core rtlzz_owner_1400(.a(2'(limb_228_1398)), .b(2'(limb_228_1399)), .cin(limb_228_1397), .value(limb_228_1400[1:0]));
    assign limb_228_1400[2:2] = '0;
    assign limb_228_1401 = limb_228_1400[1:0]; // decl: <none>; prim: <none>
    assign limb_228_1402 = {limb_228_1401, limb_228_1396, limb_228_1391}; // decl: <none>; prim: <none>
    assign limb_229_1403 = __beopt_width_311[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1404 = s8_norm_shift_112_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1405Core rtlzz_owner_1405(.a(64'(limb_229_1403)), .b(64'(limb_229_1404)), .cin(1'h0), .value(limb_229_1405));
    assign limb_229_1406 = limb_229_1405[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1407 = limb_229_1405[64]; // decl: <none>; prim: <none>
    assign limb_229_1408 = __beopt_width_311[127:64]; // decl: <none>; prim: <none>
    assign limb_229_1409 = s8_norm_shift_112_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1410Core rtlzz_owner_1410(.a(64'(limb_229_1408)), .b(64'(limb_229_1409)), .cin(limb_229_1407), .value(limb_229_1410));
    assign limb_229_1411 = limb_229_1410[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1412 = limb_229_1410[64]; // decl: <none>; prim: <none>
    assign limb_229_1413 = __beopt_width_311[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1414 = s8_norm_shift_112_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1415Core rtlzz_owner_1415(.a(2'(limb_229_1413)), .b(2'(limb_229_1414)), .cin(limb_229_1412), .value(limb_229_1415[1:0]));
    assign limb_229_1415[2:2] = '0;
    assign limb_229_1416 = limb_229_1415[1:0]; // decl: <none>; prim: <none>
    assign limb_229_1417 = {limb_229_1416, limb_229_1411, limb_229_1406}; // decl: <none>; prim: <none>
    assign limb_230_1418 = tmp_workload_top_int_130__63_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1419 = s8_norm_shift_53_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1420Core rtlzz_owner_1420(.a(64'(limb_230_1418)), .b(64'(limb_230_1419)), .cin(1'h0), .value(limb_230_1420));
    assign limb_230_1421 = limb_230_1420[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1422 = limb_230_1420[64]; // decl: <none>; prim: <none>
    assign limb_230_1423 = tmp_workload_top_int_130__63_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_230_1424 = s8_norm_shift_53_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1425Core rtlzz_owner_1425(.a(64'(limb_230_1423)), .b(64'(limb_230_1424)), .cin(limb_230_1422), .value(limb_230_1425));
    assign limb_230_1426 = limb_230_1425[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1427 = limb_230_1425[64]; // decl: <none>; prim: <none>
    assign limb_230_1428 = tmp_workload_top_int_130__63_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1429 = s8_norm_shift_53_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1430Core rtlzz_owner_1430(.a(2'(limb_230_1428)), .b(2'(limb_230_1429)), .cin(limb_230_1427), .value(limb_230_1430[1:0]));
    assign limb_230_1430[2:2] = '0;
    assign limb_230_1431 = limb_230_1430[1:0]; // decl: <none>; prim: <none>
    assign limb_230_1432 = {limb_230_1431, limb_230_1426, limb_230_1421}; // decl: <none>; prim: <none>
    assign limb_231_1433 = __beopt_width_315[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1434 = s8_norm_shift_50_v0[63:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1435Core rtlzz_owner_1435(.a(64'(limb_231_1433)), .b(64'(limb_231_1434)), .cin(1'h0), .value(limb_231_1435));
    assign limb_231_1436 = limb_231_1435[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1437 = limb_231_1435[64]; // decl: <none>; prim: <none>
    assign limb_231_1438 = __beopt_width_315[127:64]; // decl: <none>; prim: <none>
    assign limb_231_1439 = s8_norm_shift_50_v0[127:64]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1440Core rtlzz_owner_1440(.a(64'(limb_231_1438)), .b(64'(limb_231_1439)), .cin(limb_231_1437), .value(limb_231_1440));
    assign limb_231_1441 = limb_231_1440[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1442 = limb_231_1440[64]; // decl: <none>; prim: <none>
    assign limb_231_1443 = __beopt_width_315[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1444 = s8_norm_shift_50_v0[129:128]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_1445Core rtlzz_owner_1445(.a(2'(limb_231_1443)), .b(2'(limb_231_1444)), .cin(limb_231_1442), .value(limb_231_1445[1:0]));
    assign limb_231_1445[2:2] = '0;
    assign limb_231_1446 = limb_231_1445[1:0]; // decl: <none>; prim: <none>
    assign limb_231_1447 = {limb_231_1446, limb_231_1441, limb_231_1436}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_265_s1 <= 65'h0;
            rtlzz_pipe_265_s2 <= 65'h0;
            rtlzz_pipe_265_s3 <= 65'h0;
            rtlzz_pipe_265_s4 <= 65'h0;
            rtlzz_pipe_265_s5 <= 65'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_270_s2 <= 128'h0;
            rtlzz_pipe_270_s3 <= 128'h0;
            rtlzz_pipe_270_s4 <= 128'h0;
            rtlzz_pipe_270_s5 <= 128'h0;
            rtlzz_pipe_270_s6 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_271_s3 <= 128'h0;
            rtlzz_pipe_271_s4 <= 128'h0;
            rtlzz_pipe_271_s5 <= 128'h0;
            rtlzz_pipe_271_s6 <= 128'h0;
            rtlzz_pipe_271_s7 <= 128'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_278_s1 <= 129'h0;
            rtlzz_pipe_278_s2 <= 129'h0;
            rtlzz_pipe_279_s1 <= 129'h0;
            rtlzz_pipe_279_s2 <= 129'h0;
            rtlzz_pipe_279_s3 <= 129'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_292_s3 <= 64'h0;
            rtlzz_pipe_292_s4 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_293_s3 <= 64'h0;
            rtlzz_pipe_293_s4 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s7 <= 64'h0;
            rtlzz_pipe_362_s5 <= 64'h0;
            rtlzz_pipe_366_s5 <= 96'h0;
            rtlzz_pipe_370_s5 <= 96'h0;
            rtlzz_pipe_374_s5 <= 128'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_10_s7 <= 256'h0;
            rtlzz_pipe_174_s6 <= 130'h0;
            rtlzz_pipe_387_s4 <= 64'h0;
            rtlzz_pipe_391_s4 <= 96'h0;
            rtlzz_pipe_395_s4 <= 96'h0;
            rtlzz_pipe_399_s4 <= 128'h0;
            rtlzz_pipe_11_s5 <= 256'h0;
            rtlzz_pipe_11_s6 <= 256'h0;
            rtlzz_pipe_11_s7 <= 256'h0;
            rtlzz_pipe_175_s5 <= 130'h0;
            rtlzz_pipe_175_s6 <= 130'h0;
            rtlzz_pipe_465_s6 <= 64'h0;
            rtlzz_pipe_469_s6 <= 96'h0;
            rtlzz_pipe_473_s6 <= 96'h0;
            rtlzz_pipe_477_s6 <= 128'h0;
            rtlzz_pipe_48_s7 <= 256'h0;
            rtlzz_pipe_719_s3 <= 64'h0;
            rtlzz_pipe_719_s4 <= 64'h0;
            rtlzz_pipe_724_s3 <= 1'h0;
            rtlzz_pipe_724_s4 <= 1'h0;
            rtlzz_pipe_168_s5 <= 34'h0;
            rtlzz_pipe_20_s6 <= 34'h0;
            rtlzz_pipe_266_s5 <= 64'h0;
            rtlzz_pipe_268_s5 <= 34'h0;
            rtlzz_pipe_268_s6 <= 34'h0;
            rtlzz_pipe_298_s5 <= 33'h0;
            rtlzz_pipe_729_s5 <= 64'h0;
            rtlzz_pipe_734_s5 <= 1'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_269_s6 <= 34'h0;
            rtlzz_pipe_427_s6 <= 66'h0;
            rtlzz_pipe_430_s6 <= 67'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_173_s6 <= 130'h0;
            rtlzz_pipe_173_s7 <= 130'h0;
            rtlzz_pipe_739_s7 <= 64'h0;
            rtlzz_pipe_740_s7 <= 64'h0;
            rtlzz_pipe_745_s7 <= 4'h0;
            rtlzz_pipe_747_s7 <= 4'hf;
            rtlzz_pipe_753_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_753_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_759_s6 <= 4'hf;
            rtlzz_pipe_759_s7 <= 4'hf;
            rtlzz_pipe_765_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_771_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_777_s7 <= 2'h3;
            rtlzz_pipe_783_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_788_s7 <= 64'h0;
            rtlzz_pipe_794_s7 <= 2'h0;
            rtlzz_pipe_800_s1 <= 64'h0;
            rtlzz_pipe_800_s2 <= 64'h0;
            rtlzz_pipe_800_s3 <= 64'h0;
            rtlzz_pipe_800_s4 <= 64'h0;
            rtlzz_pipe_800_s5 <= 64'h0;
            rtlzz_pipe_800_s6 <= 64'h0;
            rtlzz_pipe_805_s1 <= 1'h0;
            rtlzz_pipe_805_s2 <= 1'h0;
            rtlzz_pipe_805_s3 <= 1'h0;
            rtlzz_pipe_805_s4 <= 1'h0;
            rtlzz_pipe_805_s5 <= 1'h0;
            rtlzz_pipe_805_s6 <= 1'h0;
            rtlzz_pipe_184_s7 <= 34'h0;
            rtlzz_pipe_274_s7 <= 64'h0;
            rtlzz_pipe_246_s7 <= 34'h0;
            rtlzz_pipe_313_s7 <= 33'h0;
            rtlzz_pipe_810_s2 <= 64'h0;
            rtlzz_pipe_810_s3 <= 64'h0;
            rtlzz_pipe_810_s4 <= 64'h0;
            rtlzz_pipe_810_s5 <= 64'h0;
            rtlzz_pipe_810_s6 <= 64'h0;
            rtlzz_pipe_810_s7 <= 64'h0;
            rtlzz_pipe_815_s2 <= 1'h0;
            rtlzz_pipe_815_s3 <= 1'h0;
            rtlzz_pipe_815_s4 <= 1'h0;
            rtlzz_pipe_815_s5 <= 1'h0;
            rtlzz_pipe_815_s6 <= 1'h0;
            rtlzz_pipe_815_s7 <= 1'h0;
            rtlzz_pipe_845_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_851_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_857_s7 <= 2'h3;
            rtlzz_pipe_879_s1 <= 64'h0;
            rtlzz_pipe_879_s2 <= 64'h0;
            rtlzz_pipe_884_s1 <= 64'h0;
            rtlzz_pipe_884_s2 <= 64'h0;
            rtlzz_pipe_889_s1 <= 1'h0;
            rtlzz_pipe_889_s2 <= 1'h0;
            rtlzz_pipe_198_s3 <= 34'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_286_s3 <= 66'h0;
            rtlzz_pipe_286_s4 <= 66'h0;
            rtlzz_pipe_322_s3 <= 33'h0;
            rtlzz_pipe_325_s4 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_331_s3 <= 64'h0;
            rtlzz_pipe_894_s2 <= 64'h0;
            rtlzz_pipe_894_s3 <= 64'h0;
            rtlzz_pipe_899_s2 <= 64'h0;
            rtlzz_pipe_899_s3 <= 64'h0;
            rtlzz_pipe_904_s2 <= 1'h0;
            rtlzz_pipe_904_s3 <= 1'h0;
            rtlzz_pipe_199_s4 <= 34'h0;
            rtlzz_pipe_281_s4 <= 64'h0;
            rtlzz_pipe_283_s4 <= 34'h0;
            rtlzz_pipe_287_s4 <= 66'h0;
            rtlzz_pipe_200_s4 <= 68'h0;
            rtlzz_pipe_203_s5 <= 130'h0;
            rtlzz_pipe_214_s4 <= 132'h0;
            rtlzz_pipe_214_s5 <= 132'h0;
            rtlzz_pipe_144_s4 <= 258'h0;
            rtlzz_pipe_144_s5 <= 258'h0;
            rtlzz_pipe_921_s5 <= 64'h0;
            rtlzz_pipe_922_s5 <= 64'h0;
            rtlzz_pipe_927_s5 <= 4'h0;
            rtlzz_pipe_928_s5 <= 4'h0;
            rtlzz_pipe_933_s3 <= 64'h0;
            rtlzz_pipe_933_s4 <= 64'h0;
            rtlzz_pipe_938_s3 <= 2'h0;
            rtlzz_pipe_938_s4 <= 2'h0;
            rtlzz_pipe_120_s5 <= 34'h0;
            rtlzz_pipe_288_s5 <= 66'h0;
            rtlzz_pipe_290_s5 <= 34'h0;
            rtlzz_pipe_334_s5 <= 33'h0;
            rtlzz_pipe_337_s6 <= 33'h0;
            rtlzz_pipe_340_s6 <= 34'h0;
            rtlzz_pipe_943_s4 <= 64'h0;
            rtlzz_pipe_948_s4 <= 2'h0;
            rtlzz_pipe_115_s5 <= 66'h0;
            rtlzz_pipe_122_s5 <= 34'h0;
            rtlzz_pipe_122_s6 <= 34'h0;
            rtlzz_pipe_289_s5 <= 66'h0;
            rtlzz_pipe_289_s6 <= 66'h0;
            rtlzz_pipe_291_s5 <= 34'h0;
            rtlzz_pipe_291_s6 <= 34'h0;
            rtlzz_pipe_955_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_961_s6 <= 4'hf;
            rtlzz_pipe_997_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_1003_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_1009_s6 <= 4'hf;
            rtlzz_pipe_1074_s1 <= 64'h0;
            rtlzz_pipe_1074_s2 <= 64'h0;
            rtlzz_pipe_1074_s3 <= 64'h0;
            rtlzz_pipe_1074_s4 <= 64'h0;
            rtlzz_pipe_1074_s5 <= 64'h0;
            rtlzz_pipe_1074_s6 <= 64'h0;
            rtlzz_pipe_1074_s7 <= 64'h0;
            rtlzz_pipe_1079_s1 <= 64'h0;
            rtlzz_pipe_1079_s2 <= 64'h0;
            rtlzz_pipe_1079_s3 <= 64'h0;
            rtlzz_pipe_1079_s4 <= 64'h0;
            rtlzz_pipe_1079_s5 <= 64'h0;
            rtlzz_pipe_1079_s6 <= 64'h0;
            rtlzz_pipe_1079_s7 <= 64'h0;
            rtlzz_pipe_1084_s1 <= 64'h0;
            rtlzz_pipe_1084_s2 <= 64'h0;
            rtlzz_pipe_1084_s3 <= 64'h0;
            rtlzz_pipe_1084_s4 <= 64'h0;
            rtlzz_pipe_1084_s5 <= 64'h0;
            rtlzz_pipe_1084_s6 <= 64'h0;
            rtlzz_pipe_1084_s7 <= 64'h0;
            rtlzz_pipe_1089_s1 <= 64'h0;
            rtlzz_pipe_1089_s2 <= 64'h0;
            rtlzz_pipe_1089_s3 <= 64'h0;
            rtlzz_pipe_1089_s4 <= 64'h0;
            rtlzz_pipe_1089_s5 <= 64'h0;
            rtlzz_pipe_1089_s6 <= 64'h0;
            rtlzz_pipe_1089_s7 <= 64'h0;
            rtlzz_pipe_1094_s1 <= 64'h0;
            rtlzz_pipe_1094_s2 <= 64'h0;
            rtlzz_pipe_1094_s3 <= 64'h0;
            rtlzz_pipe_1094_s4 <= 64'h0;
            rtlzz_pipe_1094_s5 <= 64'h0;
            rtlzz_pipe_1094_s6 <= 64'h0;
            rtlzz_pipe_1094_s7 <= 64'h0;
            rtlzz_pipe_1099_s1 <= 64'h0;
            rtlzz_pipe_1099_s2 <= 64'h0;
            rtlzz_pipe_1099_s3 <= 64'h0;
            rtlzz_pipe_1099_s4 <= 64'h0;
            rtlzz_pipe_1099_s5 <= 64'h0;
            rtlzz_pipe_1099_s6 <= 64'h0;
            rtlzz_pipe_1099_s7 <= 64'h0;
            rtlzz_pipe_1104_s1 <= 64'h0;
            rtlzz_pipe_1104_s2 <= 64'h0;
            rtlzz_pipe_1104_s3 <= 64'h0;
            rtlzz_pipe_1104_s4 <= 64'h0;
            rtlzz_pipe_1104_s5 <= 64'h0;
            rtlzz_pipe_1104_s6 <= 64'h0;
            rtlzz_pipe_1104_s7 <= 64'h0;
            rtlzz_pipe_1109_s1 <= 64'h0;
            rtlzz_pipe_1109_s2 <= 64'h0;
            rtlzz_pipe_1109_s3 <= 64'h0;
            rtlzz_pipe_1109_s4 <= 64'h0;
            rtlzz_pipe_1109_s5 <= 64'h0;
            rtlzz_pipe_1109_s6 <= 64'h0;
            rtlzz_pipe_1109_s7 <= 64'h0;
            rtlzz_pipe_1114_s1 <= 1'h0;
            rtlzz_pipe_1114_s2 <= 1'h0;
            rtlzz_pipe_1114_s3 <= 1'h0;
            rtlzz_pipe_1114_s4 <= 1'h0;
            rtlzz_pipe_1114_s5 <= 1'h0;
            rtlzz_pipe_1114_s6 <= 1'h0;
            rtlzz_pipe_1114_s7 <= 1'h0;
            rtlzz_pipe_1328_s6 <= 64'h0;
            rtlzz_pipe_1333_s6 <= 64'h0;
            rtlzz_pipe_1338_s6 <= 4'h0;
            rtlzz_pipe_1358_s4 <= 64'h0;
            rtlzz_pipe_1358_s5 <= 64'h0;
            rtlzz_pipe_1363_s4 <= 64'h0;
            rtlzz_pipe_1363_s5 <= 64'h0;
            rtlzz_pipe_1368_s4 <= 2'h0;
            rtlzz_pipe_1368_s5 <= 2'h0;
            rtlzz_pipe_979_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_985_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_991_s6 <= 4'hf;
            rtlzz_pipe_1223_s6 <= 64'h0;
            rtlzz_pipe_1226_s7 <= 64'h0;
            rtlzz_pipe_1228_s6 <= 64'h0;
            rtlzz_pipe_1231_s7 <= 64'h0;
            rtlzz_pipe_1232_s7 <= 1'h0;
            rtlzz_pipe_1233_s6 <= 64'h0;
            rtlzz_pipe_1233_s7 <= 64'h0;
            rtlzz_pipe_1234_s7 <= 64'h0;
            rtlzz_pipe_1238_s6 <= 64'h0;
            rtlzz_pipe_1238_s7 <= 64'h0;
            rtlzz_pipe_1239_s7 <= 64'h0;
            rtlzz_pipe_1243_s6 <= 2'h0;
            rtlzz_pipe_1243_s7 <= 2'h0;
            rtlzz_pipe_1244_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= __beopt_width_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_265_s2 <= rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_265_s3 <= rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_265_s4 <= rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_265_s5 <= rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_270_s2 <= rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_270_s3 <= rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_270_s4 <= rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_270_s5 <= rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_270_s6 <= rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_271_s3 <= rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_271_s4 <= rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_271_s5 <= rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_271_s6 <= rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_271_s7 <= rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_278_s1 <= __beopt_width_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_278_s2 <= rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= __beopt_width_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_279_s2 <= rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_279_s3 <= rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_292_s3 <= rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_292_s4 <= rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_293_s3 <= rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_293_s4 <= rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_310_s7 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_362_s5 <= mul_tree_343_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_366_s5 <= mul_tree_343_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_370_s5 <= mul_tree_343_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_374_s5 <= mul_tree_343_374; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_174_s6 <= __beopt_width_561; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_387_s4 <= mul_tree_344_387; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_391_s4 <= mul_tree_344_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_395_s4 <= mul_tree_344_395; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_399_s4 <= mul_tree_344_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_11_s6 <= rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_11_s7 <= rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_175_s5 <= __beopt_width_562; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_175_s6 <= rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_465_s6 <= mul_tree_348_465; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_469_s6 <= mul_tree_348_469; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_473_s6 <= mul_tree_348_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_477_s6 <= mul_tree_348_477; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_48_s7 <= s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_719_s3 <= limb_13_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_719_s4 <= rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_724_s3 <= limb_13_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_724_s4 <= rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_168_s5 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_20_s6 <= tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_268_s5 <= __beopt_width_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_268_s6 <= rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_298_s5 <= mul_precision_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_729_s5 <= limb_15_729; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_734_s5 <= limb_15_734; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_269_s6 <= __beopt_width_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_427_s6 <= mul_tree_345_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_430_s6 <= mul_tree_345_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_173_s6 <= __beopt_width_560; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_173_s7 <= rtlzz_pipe_173_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_739_s7 <= limb_29_739; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_740_s7 <= limb_29_740; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_745_s7 <= limb_29_745; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_747_s7 <= limb_29_747; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_753_s6 <= limb_31_753; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_753_s7 <= rtlzz_pipe_753_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_759_s6 <= limb_31_759; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_759_s7 <= rtlzz_pipe_759_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_765_s7 <= limb_38_765; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_771_s7 <= limb_38_771; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_777_s7 <= limb_38_777; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_783_s7 <= limb_40_783; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_788_s7 <= limb_40_788; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_794_s7 <= limb_40_794; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_800_s1 <= limb_51_800; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_800_s2 <= rtlzz_pipe_800_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_800_s3 <= rtlzz_pipe_800_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_800_s4 <= rtlzz_pipe_800_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_800_s5 <= rtlzz_pipe_800_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_800_s6 <= rtlzz_pipe_800_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_805_s1 <= limb_51_805; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_805_s2 <= rtlzz_pipe_805_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_805_s3 <= rtlzz_pipe_805_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_805_s4 <= rtlzz_pipe_805_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_805_s5 <= rtlzz_pipe_805_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_805_s6 <= rtlzz_pipe_805_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_184_s7 <= __beopt_width_579; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_274_s7 <= __beopt_width_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_246_s7 <= __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_313_s7 <= mul_precision_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_810_s2 <= limb_53_810; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_810_s3 <= rtlzz_pipe_810_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_810_s4 <= rtlzz_pipe_810_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_810_s5 <= rtlzz_pipe_810_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_810_s6 <= rtlzz_pipe_810_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_810_s7 <= rtlzz_pipe_810_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_815_s2 <= limb_53_815; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_815_s3 <= rtlzz_pipe_815_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_815_s4 <= rtlzz_pipe_815_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_815_s5 <= rtlzz_pipe_815_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_815_s6 <= rtlzz_pipe_815_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_815_s7 <= rtlzz_pipe_815_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_845_s7 <= limb_76_845; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_851_s7 <= limb_76_851; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_857_s7 <= limb_76_857; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_879_s1 <= limb_85_879; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_879_s2 <= rtlzz_pipe_879_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_884_s1 <= limb_85_884; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_884_s2 <= rtlzz_pipe_884_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_889_s1 <= limb_85_889; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_889_s2 <= rtlzz_pipe_889_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_198_s3 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_286_s3 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_286_s4 <= rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_322_s3 <= mul_precision_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_325_s4 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_331_s3 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_894_s2 <= limb_87_894; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_894_s3 <= rtlzz_pipe_894_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_899_s2 <= limb_87_899; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_899_s3 <= rtlzz_pipe_899_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_904_s2 <= limb_87_904; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_904_s3 <= rtlzz_pipe_904_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_199_s4 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_281_s4 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_283_s4 <= __beopt_width_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_287_s4 <= __beopt_width_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_200_s4 <= __beopt_width_609; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_203_s5 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_214_s4 <= __beopt_width_635; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_214_s5 <= rtlzz_pipe_214_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_144_s4 <= tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_144_s5 <= rtlzz_pipe_144_s4; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_921_s5 <= limb_105_921; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_922_s5 <= limb_105_922; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_927_s5 <= limb_105_927; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_928_s5 <= limb_105_928; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_933_s3 <= limb_113_933; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_933_s4 <= rtlzz_pipe_933_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_938_s3 <= limb_113_938; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_938_s4 <= rtlzz_pipe_938_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_120_s5 <= tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_288_s5 <= __beopt_width_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_290_s5 <= __beopt_width_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= mul_precision_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_337_s6 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= mul_precision_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_943_s4 <= limb_115_943; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_948_s4 <= limb_115_948; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_115_s5 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_122_s5 <= tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_122_s6 <= rtlzz_pipe_122_s5; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_289_s6 <= rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_291_s5 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_291_s6 <= rtlzz_pipe_291_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_955_s6 <= limb_129_955; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_961_s6 <= limb_129_961; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_997_s6 <= limb_140_997; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1003_s6 <= limb_140_1003; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1009_s6 <= limb_140_1009; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1074_s1 <= limb_157_1074; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1074_s2 <= rtlzz_pipe_1074_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1074_s3 <= rtlzz_pipe_1074_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1074_s4 <= rtlzz_pipe_1074_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1074_s5 <= rtlzz_pipe_1074_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1074_s6 <= rtlzz_pipe_1074_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1074_s7 <= rtlzz_pipe_1074_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1079_s1 <= limb_157_1079; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1079_s2 <= rtlzz_pipe_1079_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1079_s3 <= rtlzz_pipe_1079_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1079_s4 <= rtlzz_pipe_1079_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1079_s5 <= rtlzz_pipe_1079_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1079_s6 <= rtlzz_pipe_1079_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1079_s7 <= rtlzz_pipe_1079_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1084_s1 <= limb_157_1084; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1084_s2 <= rtlzz_pipe_1084_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1084_s3 <= rtlzz_pipe_1084_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1084_s4 <= rtlzz_pipe_1084_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1084_s5 <= rtlzz_pipe_1084_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1084_s6 <= rtlzz_pipe_1084_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1084_s7 <= rtlzz_pipe_1084_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1089_s1 <= limb_157_1089; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1089_s2 <= rtlzz_pipe_1089_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1089_s3 <= rtlzz_pipe_1089_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1089_s4 <= rtlzz_pipe_1089_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1089_s5 <= rtlzz_pipe_1089_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1089_s6 <= rtlzz_pipe_1089_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1089_s7 <= rtlzz_pipe_1089_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1094_s1 <= limb_157_1094; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1094_s2 <= rtlzz_pipe_1094_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1094_s3 <= rtlzz_pipe_1094_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1094_s4 <= rtlzz_pipe_1094_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1094_s5 <= rtlzz_pipe_1094_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1094_s6 <= rtlzz_pipe_1094_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1094_s7 <= rtlzz_pipe_1094_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1099_s1 <= limb_157_1099; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1099_s2 <= rtlzz_pipe_1099_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1099_s3 <= rtlzz_pipe_1099_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1099_s4 <= rtlzz_pipe_1099_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1099_s5 <= rtlzz_pipe_1099_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1099_s6 <= rtlzz_pipe_1099_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1099_s7 <= rtlzz_pipe_1099_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1104_s1 <= limb_157_1104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1104_s2 <= rtlzz_pipe_1104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1104_s3 <= rtlzz_pipe_1104_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1104_s4 <= rtlzz_pipe_1104_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1104_s5 <= rtlzz_pipe_1104_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1104_s6 <= rtlzz_pipe_1104_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1104_s7 <= rtlzz_pipe_1104_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1109_s1 <= limb_157_1109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1109_s2 <= rtlzz_pipe_1109_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1109_s3 <= rtlzz_pipe_1109_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1109_s4 <= rtlzz_pipe_1109_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1109_s5 <= rtlzz_pipe_1109_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1109_s6 <= rtlzz_pipe_1109_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1109_s7 <= rtlzz_pipe_1109_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1114_s1 <= limb_157_1114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1114_s2 <= rtlzz_pipe_1114_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1114_s3 <= rtlzz_pipe_1114_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1114_s4 <= rtlzz_pipe_1114_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1114_s5 <= rtlzz_pipe_1114_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1114_s6 <= rtlzz_pipe_1114_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1114_s7 <= rtlzz_pipe_1114_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1328_s6 <= limb_224_1328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1333_s6 <= limb_224_1333; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1338_s6 <= limb_224_1338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1358_s4 <= limb_226_1358; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1358_s5 <= rtlzz_pipe_1358_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1363_s4 <= limb_226_1363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1363_s5 <= rtlzz_pipe_1363_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1368_s4 <= limb_226_1368; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1368_s5 <= rtlzz_pipe_1368_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_979_s6 <= limb_138_979; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_985_s6 <= limb_138_985; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_991_s6 <= limb_138_991; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1223_s6 <= limb_219_1223; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1226_s7 <= limb_219_1226; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1228_s6 <= limb_219_1228; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1231_s7 <= limb_219_1231; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1232_s7 <= limb_219_1232; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1233_s6 <= limb_219_1233; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1233_s7 <= rtlzz_pipe_1233_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1234_s7 <= limb_219_1234; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1238_s6 <= limb_219_1238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1238_s7 <= rtlzz_pipe_1238_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1239_s7 <= limb_219_1239; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1243_s6 <= limb_219_1243; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1243_s7 <= rtlzz_pipe_1243_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1244_s7 <= limb_219_1244; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_383_reduce(input wire [63:0] i1521, input wire [95:0] i1522, input wire [95:0] i1523, input wire [127:0] i1524, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1521[63], i1521[62], i1521[61], i1521[60], i1521[59], i1521[58], i1521[57], i1521[56], i1521[55], i1521[54], i1521[53], i1521[52], i1521[51], i1521[50], i1521[49], i1521[48], i1521[47], i1521[46], i1521[45], i1521[44], i1521[43], i1521[42], i1521[41], i1521[40], i1521[39], i1521[38], i1521[37], i1521[36], i1521[35], i1521[34], i1521[33], i1521[32], i1521[31], i1521[30], i1521[29], i1521[28], i1521[27], i1521[26], i1521[25], i1521[24], i1521[23], i1521[22], i1521[21], i1521[20], i1521[19], i1521[18], i1521[17], i1521[16], i1521[15], i1521[14], i1521[13], i1521[12], i1521[11], i1521[10], i1521[9], i1521[8], i1521[7], i1521[6], i1521[5], i1521[4], i1521[3], i1521[2], i1521[1], i1521[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1522[95], i1522[94], i1522[93], i1522[92], i1522[91], i1522[90], i1522[89], i1522[88], i1522[87], i1522[86], i1522[85], i1522[84], i1522[83], i1522[82], i1522[81], i1522[80], i1522[79], i1522[78], i1522[77], i1522[76], i1522[75], i1522[74], i1522[73], i1522[72], i1522[71], i1522[70], i1522[69], i1522[68], i1522[67], i1522[66], i1522[65], i1522[64], i1522[63], i1522[62], i1522[61], i1522[60], i1522[59], i1522[58], i1522[57], i1522[56], i1522[55], i1522[54], i1522[53], i1522[52], i1522[51], i1522[50], i1522[49], i1522[48], i1522[47], i1522[46], i1522[45], i1522[44], i1522[43], i1522[42], i1522[41], i1522[40], i1522[39], i1522[38], i1522[37], i1522[36], i1522[35], i1522[34], i1522[33], i1522[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1523[95], i1523[94], i1523[93], i1523[92], i1523[91], i1523[90], i1523[89], i1523[88], i1523[87], i1523[86], i1523[85], i1523[84], i1523[83], i1523[82], i1523[81], i1523[80], i1523[79], i1523[78], i1523[77], i1523[76], i1523[75], i1523[74], i1523[73], i1523[72], i1523[71], i1523[70], i1523[69], i1523[68], i1523[67], i1523[66], i1523[65], i1523[64], i1523[63], i1523[62], i1523[61], i1523[60], i1523[59], i1523[58], i1523[57], i1523[56], i1523[55], i1523[54], i1523[53], i1523[52], i1523[51], i1523[50], i1523[49], i1523[48], i1523[47], i1523[46], i1523[45], i1523[44], i1523[43], i1523[42], i1523[41], i1523[40], i1523[39], i1523[38], i1523[37], i1523[36], i1523[35], i1523[34], i1523[33], i1523[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1524[127], i1524[126], i1524[125], i1524[124], i1524[123], i1524[122], i1524[121], i1524[120], i1524[119], i1524[118], i1524[117], i1524[116], i1524[115], i1524[114], i1524[113], i1524[112], i1524[111], i1524[110], i1524[109], i1524[108], i1524[107], i1524[106], i1524[105], i1524[104], i1524[103], i1524[102], i1524[101], i1524[100], i1524[99], i1524[98], i1524[97], i1524[96], i1524[95], i1524[94], i1524[93], i1524[92], i1524[91], i1524[90], i1524[89], i1524[88], i1524[87], i1524[86], i1524[85], i1524[84], i1524[83], i1524[82], i1524[81], i1524[80], i1524[79], i1524[78], i1524[77], i1524[76], i1524[75], i1524[74], i1524[73], i1524[72], i1524[71], i1524[70], i1524[69], i1524[68], i1524[67], i1524[66], i1524[65], i1524[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408_reduce(input wire [63:0] i1528, input wire [95:0] i1529, input wire [95:0] i1530, input wire [127:0] i1531, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1528[63], i1528[62], i1528[61], i1528[60], i1528[59], i1528[58], i1528[57], i1528[56], i1528[55], i1528[54], i1528[53], i1528[52], i1528[51], i1528[50], i1528[49], i1528[48], i1528[47], i1528[46], i1528[45], i1528[44], i1528[43], i1528[42], i1528[41], i1528[40], i1528[39], i1528[38], i1528[37], i1528[36], i1528[35], i1528[34], i1528[33], i1528[32], i1528[31], i1528[30], i1528[29], i1528[28], i1528[27], i1528[26], i1528[25], i1528[24], i1528[23], i1528[22], i1528[21], i1528[20], i1528[19], i1528[18], i1528[17], i1528[16], i1528[15], i1528[14], i1528[13], i1528[12], i1528[11], i1528[10], i1528[9], i1528[8], i1528[7], i1528[6], i1528[5], i1528[4], i1528[3], i1528[2], i1528[1], i1528[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1529[95], i1529[94], i1529[93], i1529[92], i1529[91], i1529[90], i1529[89], i1529[88], i1529[87], i1529[86], i1529[85], i1529[84], i1529[83], i1529[82], i1529[81], i1529[80], i1529[79], i1529[78], i1529[77], i1529[76], i1529[75], i1529[74], i1529[73], i1529[72], i1529[71], i1529[70], i1529[69], i1529[68], i1529[67], i1529[66], i1529[65], i1529[64], i1529[63], i1529[62], i1529[61], i1529[60], i1529[59], i1529[58], i1529[57], i1529[56], i1529[55], i1529[54], i1529[53], i1529[52], i1529[51], i1529[50], i1529[49], i1529[48], i1529[47], i1529[46], i1529[45], i1529[44], i1529[43], i1529[42], i1529[41], i1529[40], i1529[39], i1529[38], i1529[37], i1529[36], i1529[35], i1529[34], i1529[33], i1529[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1530[95], i1530[94], i1530[93], i1530[92], i1530[91], i1530[90], i1530[89], i1530[88], i1530[87], i1530[86], i1530[85], i1530[84], i1530[83], i1530[82], i1530[81], i1530[80], i1530[79], i1530[78], i1530[77], i1530[76], i1530[75], i1530[74], i1530[73], i1530[72], i1530[71], i1530[70], i1530[69], i1530[68], i1530[67], i1530[66], i1530[65], i1530[64], i1530[63], i1530[62], i1530[61], i1530[60], i1530[59], i1530[58], i1530[57], i1530[56], i1530[55], i1530[54], i1530[53], i1530[52], i1530[51], i1530[50], i1530[49], i1530[48], i1530[47], i1530[46], i1530[45], i1530[44], i1530[43], i1530[42], i1530[41], i1530[40], i1530[39], i1530[38], i1530[37], i1530[36], i1530[35], i1530[34], i1530[33], i1530[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1531[127], i1531[126], i1531[125], i1531[124], i1531[123], i1531[122], i1531[121], i1531[120], i1531[119], i1531[118], i1531[117], i1531[116], i1531[115], i1531[114], i1531[113], i1531[112], i1531[111], i1531[110], i1531[109], i1531[108], i1531[107], i1531[106], i1531[105], i1531[104], i1531[103], i1531[102], i1531[101], i1531[100], i1531[99], i1531[98], i1531[97], i1531[96], i1531[95], i1531[94], i1531[93], i1531[92], i1531[91], i1531[90], i1531[89], i1531[88], i1531[87], i1531[86], i1531[85], i1531[84], i1531[83], i1531[82], i1531[81], i1531[80], i1531[79], i1531[78], i1531[77], i1531[76], i1531[75], i1531[74], i1531[73], i1531[72], i1531[71], i1531[70], i1531[69], i1531[68], i1531[67], i1531[66], i1531[65], i1531[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461_reduce(input wire [63:0] i440, input wire [33:0] i443, input wire [33:0] i447, input wire [3:0] i451, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i440[63], i440[62], i440[61], i440[60], i440[59], i440[58], i440[57], i440[56], i440[55], i440[54], i440[53], i440[52], i440[51], i440[50], i440[49], i440[48], i440[47], i440[46], i440[45], i440[44], i440[43], i440[42], i440[41], i440[40], i440[39], i440[38], i440[37], i440[36], i440[35], i440[34], i440[33], i440[32], i440[31], i440[30], i440[29], i440[28], i440[27], i440[26], i440[25], i440[24], i440[23], i440[22], i440[21], i440[20], i440[19], i440[18], i440[17], i440[16], i440[15], i440[14], i440[13], i440[12], i440[11], i440[10], i440[9], i440[8], i440[7], i440[6], i440[5], i440[4], i440[3], i440[2], i440[1], i440[0]};
wire [67:0] t1 = {1'b0, 1'b0, i443[33], i443[32], i443[31], i443[30], i443[29], i443[28], i443[27], i443[26], i443[25], i443[24], i443[23], i443[22], i443[21], i443[20], i443[19], i443[18], i443[17], i443[16], i443[15], i443[14], i443[13], i443[12], i443[11], i443[10], i443[9], i443[8], i443[7], i443[6], i443[5], i443[4], i443[3], i443[2], i443[1], i443[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i447[33], i447[32], i447[31], i447[30], i447[29], i447[28], i447[27], i447[26], i447[25], i447[24], i447[23], i447[22], i447[21], i447[20], i447[19], i447[18], i447[17], i447[16], i447[15], i447[14], i447[13], i447[12], i447[11], i447[10], i447[9], i447[8], i447[7], i447[6], i447[5], i447[4], i447[3], i447[2], i447[1], i447[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i451[3], i451[2], i451[1], i451[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_486_reduce(input wire [63:0] i1537, input wire [95:0] i1538, input wire [95:0] i1539, input wire [127:0] i1540, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1537[63], i1537[62], i1537[61], i1537[60], i1537[59], i1537[58], i1537[57], i1537[56], i1537[55], i1537[54], i1537[53], i1537[52], i1537[51], i1537[50], i1537[49], i1537[48], i1537[47], i1537[46], i1537[45], i1537[44], i1537[43], i1537[42], i1537[41], i1537[40], i1537[39], i1537[38], i1537[37], i1537[36], i1537[35], i1537[34], i1537[33], i1537[32], i1537[31], i1537[30], i1537[29], i1537[28], i1537[27], i1537[26], i1537[25], i1537[24], i1537[23], i1537[22], i1537[21], i1537[20], i1537[19], i1537[18], i1537[17], i1537[16], i1537[15], i1537[14], i1537[13], i1537[12], i1537[11], i1537[10], i1537[9], i1537[8], i1537[7], i1537[6], i1537[5], i1537[4], i1537[3], i1537[2], i1537[1], i1537[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1538[95], i1538[94], i1538[93], i1538[92], i1538[91], i1538[90], i1538[89], i1538[88], i1538[87], i1538[86], i1538[85], i1538[84], i1538[83], i1538[82], i1538[81], i1538[80], i1538[79], i1538[78], i1538[77], i1538[76], i1538[75], i1538[74], i1538[73], i1538[72], i1538[71], i1538[70], i1538[69], i1538[68], i1538[67], i1538[66], i1538[65], i1538[64], i1538[63], i1538[62], i1538[61], i1538[60], i1538[59], i1538[58], i1538[57], i1538[56], i1538[55], i1538[54], i1538[53], i1538[52], i1538[51], i1538[50], i1538[49], i1538[48], i1538[47], i1538[46], i1538[45], i1538[44], i1538[43], i1538[42], i1538[41], i1538[40], i1538[39], i1538[38], i1538[37], i1538[36], i1538[35], i1538[34], i1538[33], i1538[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i1539[95], i1539[94], i1539[93], i1539[92], i1539[91], i1539[90], i1539[89], i1539[88], i1539[87], i1539[86], i1539[85], i1539[84], i1539[83], i1539[82], i1539[81], i1539[80], i1539[79], i1539[78], i1539[77], i1539[76], i1539[75], i1539[74], i1539[73], i1539[72], i1539[71], i1539[70], i1539[69], i1539[68], i1539[67], i1539[66], i1539[65], i1539[64], i1539[63], i1539[62], i1539[61], i1539[60], i1539[59], i1539[58], i1539[57], i1539[56], i1539[55], i1539[54], i1539[53], i1539[52], i1539[51], i1539[50], i1539[49], i1539[48], i1539[47], i1539[46], i1539[45], i1539[44], i1539[43], i1539[42], i1539[41], i1539[40], i1539[39], i1539[38], i1539[37], i1539[36], i1539[35], i1539[34], i1539[33], i1539[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i1540[127], i1540[126], i1540[125], i1540[124], i1540[123], i1540[122], i1540[121], i1540[120], i1540[119], i1540[118], i1540[117], i1540[116], i1540[115], i1540[114], i1540[113], i1540[112], i1540[111], i1540[110], i1540[109], i1540[108], i1540[107], i1540[106], i1540[105], i1540[104], i1540[103], i1540[102], i1540[101], i1540[100], i1540[99], i1540[98], i1540[97], i1540[96], i1540[95], i1540[94], i1540[93], i1540[92], i1540[91], i1540[90], i1540[89], i1540[88], i1540[87], i1540[86], i1540[85], i1540[84], i1540[83], i1540[82], i1540[81], i1540[80], i1540[79], i1540[78], i1540[77], i1540[76], i1540[75], i1540[74], i1540[73], i1540[72], i1540[71], i1540[70], i1540[69], i1540[68], i1540[67], i1540[66], i1540[65], i1540[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511_reduce(input wire [63:0] i490, input wire [63:0] i493, input wire [63:0] i497, input wire [63:0] i501, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i490[63], i490[62], i490[61], i490[60], i490[59], i490[58], i490[57], i490[56], i490[55], i490[54], i490[53], i490[52], i490[51], i490[50], i490[49], i490[48], i490[47], i490[46], i490[45], i490[44], i490[43], i490[42], i490[41], i490[40], i490[39], i490[38], i490[37], i490[36], i490[35], i490[34], i490[33], i490[32], i490[31], i490[30], i490[29], i490[28], i490[27], i490[26], i490[25], i490[24], i490[23], i490[22], i490[21], i490[20], i490[19], i490[18], i490[17], i490[16], i490[15], i490[14], i490[13], i490[12], i490[11], i490[10], i490[9], i490[8], i490[7], i490[6], i490[5], i490[4], i490[3], i490[2], i490[1], i490[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i493[63], i493[62], i493[61], i493[60], i493[59], i493[58], i493[57], i493[56], i493[55], i493[54], i493[53], i493[52], i493[51], i493[50], i493[49], i493[48], i493[47], i493[46], i493[45], i493[44], i493[43], i493[42], i493[41], i493[40], i493[39], i493[38], i493[37], i493[36], i493[35], i493[34], i493[33], i493[32], i493[31], i493[30], i493[29], i493[28], i493[27], i493[26], i493[25], i493[24], i493[23], i493[22], i493[21], i493[20], i493[19], i493[18], i493[17], i493[16], i493[15], i493[14], i493[13], i493[12], i493[11], i493[10], i493[9], i493[8], i493[7], i493[6], i493[5], i493[4], i493[3], i493[2], i493[1], i493[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i497[63], i497[62], i497[61], i497[60], i497[59], i497[58], i497[57], i497[56], i497[55], i497[54], i497[53], i497[52], i497[51], i497[50], i497[49], i497[48], i497[47], i497[46], i497[45], i497[44], i497[43], i497[42], i497[41], i497[40], i497[39], i497[38], i497[37], i497[36], i497[35], i497[34], i497[33], i497[32], i497[31], i497[30], i497[29], i497[28], i497[27], i497[26], i497[25], i497[24], i497[23], i497[22], i497[21], i497[20], i497[19], i497[18], i497[17], i497[16], i497[15], i497[14], i497[13], i497[12], i497[11], i497[10], i497[9], i497[8], i497[7], i497[6], i497[5], i497[4], i497[3], i497[2], i497[1], i497[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i501[63], i501[62], i501[61], i501[60], i501[59], i501[58], i501[57], i501[56], i501[55], i501[54], i501[53], i501[52], i501[51], i501[50], i501[49], i501[48], i501[47], i501[46], i501[45], i501[44], i501[43], i501[42], i501[41], i501[40], i501[39], i501[38], i501[37], i501[36], i501[35], i501[34], i501[33], i501[32], i501[31], i501[30], i501[29], i501[28], i501[27], i501[26], i501[25], i501[24], i501[23], i501[22], i501[21], i501[20], i501[19], i501[18], i501[17], i501[16], i501[15], i501[14], i501[13], i501[12], i501[11], i501[10], i501[9], i501[8], i501[7], i501[6], i501[5], i501[4], i501[3], i501[2], i501[1], i501[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_536_reduce(input wire [63:0] i515, input wire [32:0] i518, input wire [32:0] i522, input wire [1:0] i526, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i515[63], i515[62], i515[61], i515[60], i515[59], i515[58], i515[57], i515[56], i515[55], i515[54], i515[53], i515[52], i515[51], i515[50], i515[49], i515[48], i515[47], i515[46], i515[45], i515[44], i515[43], i515[42], i515[41], i515[40], i515[39], i515[38], i515[37], i515[36], i515[35], i515[34], i515[33], i515[32], i515[31], i515[30], i515[29], i515[28], i515[27], i515[26], i515[25], i515[24], i515[23], i515[22], i515[21], i515[20], i515[19], i515[18], i515[17], i515[16], i515[15], i515[14], i515[13], i515[12], i515[11], i515[10], i515[9], i515[8], i515[7], i515[6], i515[5], i515[4], i515[3], i515[2], i515[1], i515[0]};
wire [65:0] t1 = {1'b0, i518[32], i518[31], i518[30], i518[29], i518[28], i518[27], i518[26], i518[25], i518[24], i518[23], i518[22], i518[21], i518[20], i518[19], i518[18], i518[17], i518[16], i518[15], i518[14], i518[13], i518[12], i518[11], i518[10], i518[9], i518[8], i518[7], i518[6], i518[5], i518[4], i518[3], i518[2], i518[1], i518[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i526[1], i526[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_564_reduce(input wire [63:0] i543, input wire [33:0] i546, input wire [33:0] i550, input wire [3:0] i554, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i543[63], i543[62], i543[61], i543[60], i543[59], i543[58], i543[57], i543[56], i543[55], i543[54], i543[53], i543[52], i543[51], i543[50], i543[49], i543[48], i543[47], i543[46], i543[45], i543[44], i543[43], i543[42], i543[41], i543[40], i543[39], i543[38], i543[37], i543[36], i543[35], i543[34], i543[33], i543[32], i543[31], i543[30], i543[29], i543[28], i543[27], i543[26], i543[25], i543[24], i543[23], i543[22], i543[21], i543[20], i543[19], i543[18], i543[17], i543[16], i543[15], i543[14], i543[13], i543[12], i543[11], i543[10], i543[9], i543[8], i543[7], i543[6], i543[5], i543[4], i543[3], i543[2], i543[1], i543[0]};
wire [67:0] t1 = {1'b0, 1'b0, i546[33], i546[32], i546[31], i546[30], i546[29], i546[28], i546[27], i546[26], i546[25], i546[24], i546[23], i546[22], i546[21], i546[20], i546[19], i546[18], i546[17], i546[16], i546[15], i546[14], i546[13], i546[12], i546[11], i546[10], i546[9], i546[8], i546[7], i546[6], i546[5], i546[4], i546[3], i546[2], i546[1], i546[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i550[33], i550[32], i550[31], i550[30], i550[29], i550[28], i550[27], i550[26], i550[25], i550[24], i550[23], i550[22], i550[21], i550[20], i550[19], i550[18], i550[17], i550[16], i550[15], i550[14], i550[13], i550[12], i550[11], i550[10], i550[9], i550[8], i550[7], i550[6], i550[5], i550[4], i550[3], i550[2], i550[1], i550[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i554[3], i554[2], i554[1], i554[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589_reduce(input wire [63:0] i568, input wire [32:0] i571, input wire [32:0] i575, input wire [1:0] i579, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i568[63], i568[62], i568[61], i568[60], i568[59], i568[58], i568[57], i568[56], i568[55], i568[54], i568[53], i568[52], i568[51], i568[50], i568[49], i568[48], i568[47], i568[46], i568[45], i568[44], i568[43], i568[42], i568[41], i568[40], i568[39], i568[38], i568[37], i568[36], i568[35], i568[34], i568[33], i568[32], i568[31], i568[30], i568[29], i568[28], i568[27], i568[26], i568[25], i568[24], i568[23], i568[22], i568[21], i568[20], i568[19], i568[18], i568[17], i568[16], i568[15], i568[14], i568[13], i568[12], i568[11], i568[10], i568[9], i568[8], i568[7], i568[6], i568[5], i568[4], i568[3], i568[2], i568[1], i568[0]};
wire [65:0] t1 = {1'b0, i571[32], i571[31], i571[30], i571[29], i571[28], i571[27], i571[26], i571[25], i571[24], i571[23], i571[22], i571[21], i571[20], i571[19], i571[18], i571[17], i571[16], i571[15], i571[14], i571[13], i571[12], i571[11], i571[10], i571[9], i571[8], i571[7], i571[6], i571[5], i571[4], i571[3], i571[2], i571[1], i571[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i575[32], i575[31], i575[30], i575[29], i575[28], i575[27], i575[26], i575[25], i575[24], i575[23], i575[22], i575[21], i575[20], i575[19], i575[18], i575[17], i575[16], i575[15], i575[14], i575[13], i575[12], i575[11], i575[10], i575[9], i575[8], i575[7], i575[6], i575[5], i575[4], i575[3], i575[2], i575[1], i575[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i579[1], i579[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_617_reduce(input wire [63:0] i596, input wire [33:0] i599, input wire [33:0] i603, input wire [3:0] i607, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i596[63], i596[62], i596[61], i596[60], i596[59], i596[58], i596[57], i596[56], i596[55], i596[54], i596[53], i596[52], i596[51], i596[50], i596[49], i596[48], i596[47], i596[46], i596[45], i596[44], i596[43], i596[42], i596[41], i596[40], i596[39], i596[38], i596[37], i596[36], i596[35], i596[34], i596[33], i596[32], i596[31], i596[30], i596[29], i596[28], i596[27], i596[26], i596[25], i596[24], i596[23], i596[22], i596[21], i596[20], i596[19], i596[18], i596[17], i596[16], i596[15], i596[14], i596[13], i596[12], i596[11], i596[10], i596[9], i596[8], i596[7], i596[6], i596[5], i596[4], i596[3], i596[2], i596[1], i596[0]};
wire [67:0] t1 = {1'b0, 1'b0, i599[33], i599[32], i599[31], i599[30], i599[29], i599[28], i599[27], i599[26], i599[25], i599[24], i599[23], i599[22], i599[21], i599[20], i599[19], i599[18], i599[17], i599[16], i599[15], i599[14], i599[13], i599[12], i599[11], i599[10], i599[9], i599[8], i599[7], i599[6], i599[5], i599[4], i599[3], i599[2], i599[1], i599[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i603[33], i603[32], i603[31], i603[30], i603[29], i603[28], i603[27], i603[26], i603[25], i603[24], i603[23], i603[22], i603[21], i603[20], i603[19], i603[18], i603[17], i603[16], i603[15], i603[14], i603[13], i603[12], i603[11], i603[10], i603[9], i603[8], i603[7], i603[6], i603[5], i603[4], i603[3], i603[2], i603[1], i603[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i607[3], i607[2], i607[1], i607[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_642_reduce(input wire [63:0] i621, input wire [63:0] i624, input wire [63:0] i628, input wire [63:0] i632, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i621[63], i621[62], i621[61], i621[60], i621[59], i621[58], i621[57], i621[56], i621[55], i621[54], i621[53], i621[52], i621[51], i621[50], i621[49], i621[48], i621[47], i621[46], i621[45], i621[44], i621[43], i621[42], i621[41], i621[40], i621[39], i621[38], i621[37], i621[36], i621[35], i621[34], i621[33], i621[32], i621[31], i621[30], i621[29], i621[28], i621[27], i621[26], i621[25], i621[24], i621[23], i621[22], i621[21], i621[20], i621[19], i621[18], i621[17], i621[16], i621[15], i621[14], i621[13], i621[12], i621[11], i621[10], i621[9], i621[8], i621[7], i621[6], i621[5], i621[4], i621[3], i621[2], i621[1], i621[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i624[63], i624[62], i624[61], i624[60], i624[59], i624[58], i624[57], i624[56], i624[55], i624[54], i624[53], i624[52], i624[51], i624[50], i624[49], i624[48], i624[47], i624[46], i624[45], i624[44], i624[43], i624[42], i624[41], i624[40], i624[39], i624[38], i624[37], i624[36], i624[35], i624[34], i624[33], i624[32], i624[31], i624[30], i624[29], i624[28], i624[27], i624[26], i624[25], i624[24], i624[23], i624[22], i624[21], i624[20], i624[19], i624[18], i624[17], i624[16], i624[15], i624[14], i624[13], i624[12], i624[11], i624[10], i624[9], i624[8], i624[7], i624[6], i624[5], i624[4], i624[3], i624[2], i624[1], i624[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i628[63], i628[62], i628[61], i628[60], i628[59], i628[58], i628[57], i628[56], i628[55], i628[54], i628[53], i628[52], i628[51], i628[50], i628[49], i628[48], i628[47], i628[46], i628[45], i628[44], i628[43], i628[42], i628[41], i628[40], i628[39], i628[38], i628[37], i628[36], i628[35], i628[34], i628[33], i628[32], i628[31], i628[30], i628[29], i628[28], i628[27], i628[26], i628[25], i628[24], i628[23], i628[22], i628[21], i628[20], i628[19], i628[18], i628[17], i628[16], i628[15], i628[14], i628[13], i628[12], i628[11], i628[10], i628[9], i628[8], i628[7], i628[6], i628[5], i628[4], i628[3], i628[2], i628[1], i628[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i632[63], i632[62], i632[61], i632[60], i632[59], i632[58], i632[57], i632[56], i632[55], i632[54], i632[53], i632[52], i632[51], i632[50], i632[49], i632[48], i632[47], i632[46], i632[45], i632[44], i632[43], i632[42], i632[41], i632[40], i632[39], i632[38], i632[37], i632[36], i632[35], i632[34], i632[33], i632[32], i632[31], i632[30], i632[29], i632[28], i632[27], i632[26], i632[25], i632[24], i632[23], i632[22], i632[21], i632[20], i632[19], i632[18], i632[17], i632[16], i632[15], i632[14], i632[13], i632[12], i632[11], i632[10], i632[9], i632[8], i632[7], i632[6], i632[5], i632[4], i632[3], i632[2], i632[1], i632[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_667_reduce(input wire [63:0] i646, input wire [32:0] i649, input wire [32:0] i653, input wire [1:0] i657, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i646[63], i646[62], i646[61], i646[60], i646[59], i646[58], i646[57], i646[56], i646[55], i646[54], i646[53], i646[52], i646[51], i646[50], i646[49], i646[48], i646[47], i646[46], i646[45], i646[44], i646[43], i646[42], i646[41], i646[40], i646[39], i646[38], i646[37], i646[36], i646[35], i646[34], i646[33], i646[32], i646[31], i646[30], i646[29], i646[28], i646[27], i646[26], i646[25], i646[24], i646[23], i646[22], i646[21], i646[20], i646[19], i646[18], i646[17], i646[16], i646[15], i646[14], i646[13], i646[12], i646[11], i646[10], i646[9], i646[8], i646[7], i646[6], i646[5], i646[4], i646[3], i646[2], i646[1], i646[0]};
wire [65:0] t1 = {1'b0, i649[32], i649[31], i649[30], i649[29], i649[28], i649[27], i649[26], i649[25], i649[24], i649[23], i649[22], i649[21], i649[20], i649[19], i649[18], i649[17], i649[16], i649[15], i649[14], i649[13], i649[12], i649[11], i649[10], i649[9], i649[8], i649[7], i649[6], i649[5], i649[4], i649[3], i649[2], i649[1], i649[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i653[32], i653[31], i653[30], i653[29], i653[28], i653[27], i653[26], i653[25], i653[24], i653[23], i653[22], i653[21], i653[20], i653[19], i653[18], i653[17], i653[16], i653[15], i653[14], i653[13], i653[12], i653[11], i653[10], i653[9], i653[8], i653[7], i653[6], i653[5], i653[4], i653[3], i653[2], i653[1], i653[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i657[1], i657[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_692_reduce(input wire [63:0] i671, input wire [32:0] i674, input wire [32:0] i678, input wire [1:0] i682, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i671[63], i671[62], i671[61], i671[60], i671[59], i671[58], i671[57], i671[56], i671[55], i671[54], i671[53], i671[52], i671[51], i671[50], i671[49], i671[48], i671[47], i671[46], i671[45], i671[44], i671[43], i671[42], i671[41], i671[40], i671[39], i671[38], i671[37], i671[36], i671[35], i671[34], i671[33], i671[32], i671[31], i671[30], i671[29], i671[28], i671[27], i671[26], i671[25], i671[24], i671[23], i671[22], i671[21], i671[20], i671[19], i671[18], i671[17], i671[16], i671[15], i671[14], i671[13], i671[12], i671[11], i671[10], i671[9], i671[8], i671[7], i671[6], i671[5], i671[4], i671[3], i671[2], i671[1], i671[0]};
wire [65:0] t1 = {1'b0, i674[32], i674[31], i674[30], i674[29], i674[28], i674[27], i674[26], i674[25], i674[24], i674[23], i674[22], i674[21], i674[20], i674[19], i674[18], i674[17], i674[16], i674[15], i674[14], i674[13], i674[12], i674[11], i674[10], i674[9], i674[8], i674[7], i674[6], i674[5], i674[4], i674[3], i674[2], i674[1], i674[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i678[32], i678[31], i678[30], i678[29], i678[28], i678[27], i678[26], i678[25], i678[24], i678[23], i678[22], i678[21], i678[20], i678[19], i678[18], i678[17], i678[16], i678[15], i678[14], i678[13], i678[12], i678[11], i678[10], i678[9], i678[8], i678[7], i678[6], i678[5], i678[4], i678[3], i678[2], i678[1], i678[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i682[1], i682[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_717_reduce(input wire [63:0] i696, input wire [33:0] i699, input wire [33:0] i703, input wire [3:0] i707, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i696[63], i696[62], i696[61], i696[60], i696[59], i696[58], i696[57], i696[56], i696[55], i696[54], i696[53], i696[52], i696[51], i696[50], i696[49], i696[48], i696[47], i696[46], i696[45], i696[44], i696[43], i696[42], i696[41], i696[40], i696[39], i696[38], i696[37], i696[36], i696[35], i696[34], i696[33], i696[32], i696[31], i696[30], i696[29], i696[28], i696[27], i696[26], i696[25], i696[24], i696[23], i696[22], i696[21], i696[20], i696[19], i696[18], i696[17], i696[16], i696[15], i696[14], i696[13], i696[12], i696[11], i696[10], i696[9], i696[8], i696[7], i696[6], i696[5], i696[4], i696[3], i696[2], i696[1], i696[0]};
wire [67:0] t1 = {1'b0, 1'b0, i699[33], i699[32], i699[31], i699[30], i699[29], i699[28], i699[27], i699[26], i699[25], i699[24], i699[23], i699[22], i699[21], i699[20], i699[19], i699[18], i699[17], i699[16], i699[15], i699[14], i699[13], i699[12], i699[11], i699[10], i699[9], i699[8], i699[7], i699[6], i699[5], i699[4], i699[3], i699[2], i699[1], i699[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i703[33], i703[32], i703[31], i703[30], i703[29], i703[28], i703[27], i703[26], i703[25], i703[24], i703[23], i703[22], i703[21], i703[20], i703[19], i703[18], i703[17], i703[16], i703[15], i703[14], i703[13], i703[12], i703[11], i703[10], i703[9], i703[8], i703[7], i703[6], i703[5], i703[4], i703[3], i703[2], i703[1], i703[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i707[3], i707[2], i707[1], i707[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427Core(input wire [63:0] a,input wire [64:0] b,input wire cin,output wire [65:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [64:0] masked_b=((b&65'h1ffffffff00000000)|65'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_427();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430Core(input wire [64:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [64:0] masked_a=((a&65'h1ffffffff00000000)|65'h0);
wire [65:0] masked_b=((b&66'h30000000000000000)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433Core(input wire [65:0] a,input wire [66:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h3ffffffffffffffff)|66'h0);
wire [66:0] masked_b=((b&67'h7ffffffffffffffff)|67'h0);
wire [66:0] aa=67'(masked_b);
wire [66:0] bb=67'(masked_a);
wire [67:0] extended={1'b0,aa}+{1'b0,bb}+68'(1'b0);
wire [66:0] native_value=extended[66:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_721Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_721();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_726();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_731();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_736();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_742();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_748Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_748();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_754();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_760();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_766();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_772();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_778();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_784();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_790();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_796();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_801Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_801();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_806Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_806();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_811();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_816Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_816();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_822Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_822();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_828Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_828();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_834Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_834();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_840();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_846Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_846();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_852Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_852();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_858Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_858();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_864Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_864();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_870Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_870();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_876Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_876();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_881Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_881();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_886Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_886();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_891Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_891();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_896Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_896();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_901();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_906Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_906();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_912();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_918Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_918();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_924Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_924();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_930Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_930();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_935Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_935();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_940Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_940();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_945Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_945();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_950Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h1)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_950();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_956Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_956();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_962Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_962();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_968Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_968();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_974Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_974();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_980Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_980();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_986Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_986();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_992Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h3)|4'hc);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_992();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_998Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_998();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1004Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1004();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1010Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'h0)|4'hf);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1010();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1016Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1016();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1022Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1022();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1028();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1034Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1034();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1040Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1040();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1046Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1046();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1052Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1052();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1058();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1064();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1070Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h3);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1070();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1075Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1075();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1080Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1080();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1085Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1085();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1090();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1095Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1095();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1100Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1100();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1105Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1105();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1110Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1110();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1115Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h0)|1'h0);
wire [0:0] aa=1'(masked_a);
wire [0:0] bb=1'(masked_b);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1120Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1120();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1125Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1125();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1130Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1130();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1135Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1135();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1140Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1145Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1145();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1150();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1155Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1155();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1160Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1160();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1165Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1165();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1170Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1170();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1175Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1175();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1180Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1180();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1185Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1185();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1190Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1190();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1195Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1195();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1200Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1200();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1205Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1205();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1210Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h3)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1210();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1215Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'h0)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1215();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1220Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h0)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1225Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1225();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1230Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1230();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1235Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1235();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1240Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1240();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1245Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1245();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1250Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1250();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1255Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1255();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1260Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1260();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1265Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1265();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1270Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1270();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1275Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1275();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1280Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1280();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1285Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1285();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1290Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1290();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1295Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1295();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1300Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1300();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1305Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'h0)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_b);
wire [63:0] bb=64'(masked_a);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1305();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1310Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1310();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1315Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1315();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1320Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1320();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1325Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(cin);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1325();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1330Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1330();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1335Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h3)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1335();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1340Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'h0)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_b);
wire [3:0] bb=4'(masked_a);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1340();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1345Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1345();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1350Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1350();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1355Core(input wire [3:0] a,input wire [3:0] b,input wire cin,output wire [3:0] value);
wire [3:0] masked_a=((a&4'hf)|4'h0);
wire [3:0] masked_b=((b&4'hf)|4'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [4:0] extended={1'b0,aa}+{1'b0,bb}+5'(cin);
wire [3:0] native_value=extended[3:0];
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1355();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1360Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1360();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1365Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h3)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1365();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1370Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1370();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1375Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1375();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1380Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1380();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1385Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1385();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1390Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1390();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1395Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h3)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1395();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1400Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1400();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1405Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1410Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1410();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1415Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1420Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1420();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1425Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'h3)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_b);
wire [64:0] bb=65'(masked_a);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1425();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1430Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h0)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_b);
wire [1:0] bb=2'(masked_a);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1430();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1435Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1435();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1440Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1440();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1445Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [1:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [2:0] extended={1'b0,aa}+{1'b0,bb}+3'(cin);
wire [1:0] native_value=extended[1:0];
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_1445();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
