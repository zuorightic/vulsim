`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_360; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_361; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_362; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_363; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_364; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_365; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_366; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_367; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_368; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_369; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_373; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_374; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_375; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_376; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_377; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_378; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_379; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_382; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_383; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_384; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_385; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_386; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_387; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_388; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_389; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_390; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_391; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_392; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_393; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_394; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_398; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_399; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_400; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_401; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_402; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_403; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_404; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_405; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_406; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_407; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_408; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_409; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_410; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_411; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_345_412; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_413; // decl: <none>; prim: <none>
    logic mul_tree_345_414; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_415; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_416; // decl: <none>; prim: <none>
    logic mul_tree_345_417; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_418; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_419; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_420; // decl: <none>; prim: <none>
    logic mul_tree_345_421; // decl: <none>; prim: <none>
    logic mul_tree_345_422; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_345_423; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_424; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_425; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_426; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_427; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_428; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_429; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_430; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_431; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_432; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_433; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_434; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_435; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_436; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_346_437; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_438; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_439; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_347_440; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_441; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_442; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_443; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_444; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_446; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_447; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_448; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_449; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_450; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_347_451; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_452; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_453; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_454; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_455; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_456; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_457; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_458; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_459; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_460; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_461; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_462; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_463; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_464; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_465; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_466; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_467; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_468; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_469; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_471; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_472; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_476; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_477; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_478; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_479; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_480; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_481; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_482; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_483; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_484; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_485; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_486; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_487; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_488; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_489; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_490; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_491; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_492; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_493; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_494; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_496; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_497; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_501; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_502; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_503; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_504; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_505; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_506; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_507; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_508; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_509; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_510; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_511; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_512; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_513; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_514; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_350_515; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_516; // decl: <none>; prim: <none>
    logic mul_tree_350_517; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_518; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_519; // decl: <none>; prim: <none>
    logic mul_tree_350_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_521; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_522; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_523; // decl: <none>; prim: <none>
    logic mul_tree_350_524; // decl: <none>; prim: <none>
    logic mul_tree_350_525; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_350_526; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_527; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_528; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_529; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_530; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_531; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_532; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_533; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_534; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_535; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_536; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_537; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_538; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_539; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_351_540; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_541; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_542; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_352_543; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_544; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_545; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_546; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_547; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_548; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_549; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_550; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_551; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_552; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_553; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_352_554; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_555; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_556; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_557; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_558; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_559; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_560; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_561; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_562; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_563; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_564; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_565; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_566; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_567; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_353_568; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_569; // decl: <none>; prim: <none>
    logic mul_tree_353_570; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_571; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_572; // decl: <none>; prim: <none>
    logic mul_tree_353_573; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_574; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_575; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_576; // decl: <none>; prim: <none>
    logic mul_tree_353_577; // decl: <none>; prim: <none>
    logic mul_tree_353_578; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_353_579; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_580; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_581; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_582; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_583; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_584; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_585; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_586; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_587; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_588; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_589; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_590; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_591; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_592; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_354_593; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_594; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_595; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_355_596; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_597; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_598; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_599; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_600; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_601; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_602; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_603; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_604; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_605; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_606; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_355_607; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_608; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_609; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_610; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_611; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_612; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_613; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_614; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_615; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_616; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_617; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_618; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_619; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_620; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_621; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_622; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_623; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_624; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_625; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_626; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_627; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_628; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_629; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_630; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_631; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_632; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_633; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_634; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_635; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_636; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_637; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_638; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_639; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_640; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_641; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_642; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_643; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_644; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_645; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_357_646; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_647; // decl: <none>; prim: <none>
    logic mul_tree_357_648; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_649; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_650; // decl: <none>; prim: <none>
    logic mul_tree_357_651; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_652; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_653; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_654; // decl: <none>; prim: <none>
    logic mul_tree_357_655; // decl: <none>; prim: <none>
    logic mul_tree_357_656; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_357_657; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_658; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_659; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_660; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_661; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_662; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_663; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_664; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_665; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_666; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_667; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_668; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_669; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_670; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_358_671; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_672; // decl: <none>; prim: <none>
    logic mul_tree_358_673; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_674; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_675; // decl: <none>; prim: <none>
    logic mul_tree_358_676; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_677; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_678; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_679; // decl: <none>; prim: <none>
    logic mul_tree_358_680; // decl: <none>; prim: <none>
    logic mul_tree_358_681; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_358_682; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_683; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_684; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_685; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_686; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_687; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_688; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_689; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_690; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_691; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_692; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_693; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_694; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_695; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_359_696; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_697; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_698; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_699; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_700; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_701; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_702; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_703; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_704; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_705; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_706; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_359_707; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_708; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_709; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_710; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_711; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_712; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_713; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_714; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_715; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_716; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_717; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_718; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [512:0] rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s7; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_84_s1; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_234_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_164_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] rtlzz_pipe_165_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_238_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] rtlzz_pipe_239_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [65:0] rtlzz_pipe_180_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [128:0] rtlzz_pipe_248_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [33:0] rtlzz_pipe_198_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_94_s3; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_206_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_249_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [33:0] rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_114_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [63:0] rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] rtlzz_pipe_284_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_256_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_113_s4; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [33:0] rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_210_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_211_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_288_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_290_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_260_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] rtlzz_pipe_261_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] rtlzz_pipe_261_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_299_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_305_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_319_s7; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_323_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_377_s3; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_377_s4; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_377_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_377_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_380_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_380_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_380_s5; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_380_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_41_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [129:0] rtlzz_pipe_37_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [96:0] rtlzz_pipe_402_s4; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_405_s4; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_45_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [255:0] rtlzz_pipe_45_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [129:0] rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [67:0] rtlzz_pipe_28_s7; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_79_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [129:0] rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] rtlzz_pipe_75_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [96:0] rtlzz_pipe_505_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_508_s3; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_49_s4; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [255:0] rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [255:0] rtlzz_pipe_83_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [129:0] rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [255:0] rtlzz_pipe_220_s7; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [65:0] rtlzz_pipe_583_s4; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_586_s4; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_102_s5; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [129:0] rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_106_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_203_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_107_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [131:0] rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] rtlzz_pipe_139_s6; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [257:0] rtlzz_pipe_144_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] rtlzz_pipe_144_s6; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [131:0] rtlzz_pipe_118_s5; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] rtlzz_pipe_118_s6; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [67:0] rtlzz_pipe_128_s5; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] rtlzz_pipe_128_s6; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [131:0] rtlzz_pipe_135_s6; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [67:0] rtlzz_pipe_213_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_696_s6; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_700_s6; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_704_s6; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_708_s6; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_219_s7; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_13Core rtlzz_owner_13(.a(65'(rtlzz_pipe_12_s5)), .b(65'(rtlzz_pipe_234_s5)), .cin(1'b0), .value(s8_norm_add_18_v0));
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_15Core rtlzz_owner_15(.a(65'(tmp_workload_top_int_65__23_v0)), .b(65'(rtlzz_pipe_235_s4)), .cin(1'b0), .value(s8_norm_add_21_v0));
    assign tmp_workload_top_int_66__32_v0 = (rtlzz_pipe_164_s6 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (rtlzz_pipe_165_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_21Core rtlzz_owner_21(.a(34'(tmp_workload_top_int_34__42_v0)), .b(34'(rtlzz_pipe_238_s7)), .cin(1'b0), .value(s8_norm_add_36_v0));
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_23Core rtlzz_owner_23(.a(34'(tmp_workload_top_int_34__47_v0)), .b(34'(rtlzz_pipe_239_s6)), .cin(1'b0), .value(s8_norm_add_39_v0));
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_29Core rtlzz_owner_29(.a(68'(n20_v0)), .b(68'(rtlzz_pipe_28_s7)), .cin(1'b0), .value(s8_norm_sub_45_v0));
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_31Core rtlzz_owner_31(.a(68'(s8_norm_sub_45_v0)), .b(68'(tmp_workload_top_int_68__60_v0)), .cin(1'b0), .value(s8_norm_sub_47_v0));
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (__beopt_width_560 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (__beopt_width_561 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(130'(__beopt_width_317)), .b(130'(rtlzz_pipe_37_s7)), .cin(1'b0), .value(s8_norm_sub_56_v0));
    assign tmp_workload_top_int_130__76_v0 = (__beopt_width_562 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_40Core rtlzz_owner_40(.a(130'(s8_norm_sub_56_v0)), .b(130'(rtlzz_pipe_39_s7)), .cin(1'b0), .value(s8_norm_sub_58_v0));
    assign tmp_workload_top_int_256__79_v0 = (s8_norm_mul_10_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s5 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__85_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_51Core rtlzz_owner_51(.a(65'(tmp_workload_top_int_65__103_v0)), .b(65'(rtlzz_pipe_242_s6)), .cin(1'b0), .value(s8_norm_add_80_v0));
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_53Core rtlzz_owner_53(.a(65'(tmp_workload_top_int_65__108_v0)), .b(65'(rtlzz_pipe_243_s7)), .cin(1'b0), .value(s8_norm_add_83_v0));
    assign tmp_workload_top_int_66__117_v0 = (rtlzz_pipe_180_s7 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (__beopt_width_579 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_59Core rtlzz_owner_59(.a(34'(tmp_workload_top_int_34__127_v0)), .b(34'(__beopt_width_367)), .cin(1'b0), .value(s8_norm_add_98_v0));
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(34'(tmp_workload_top_int_34__132_v0)), .b(34'(__beopt_width_370)), .cin(1'b0), .value(s8_norm_add_101_v0));
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_67Core rtlzz_owner_67(.a(68'(n41_v0)), .b(68'(tmp_workload_top_int_68__142_v0)), .cin(1'b0), .value(s8_norm_sub_107_v0));
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_69Core rtlzz_owner_69(.a(68'(s8_norm_sub_107_v0)), .b(68'(tmp_workload_top_int_68__145_v0)), .cin(1'b0), .value(s8_norm_sub_109_v0));
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_76Core rtlzz_owner_76(.a(130'(__beopt_width_313)), .b(130'(rtlzz_pipe_75_s7)), .cin(1'b0), .value(s8_norm_sub_118_v0));
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_78Core rtlzz_owner_78(.a(130'(s8_norm_sub_118_v0)), .b(130'(rtlzz_pipe_77_s7)), .cin(1'b0), .value(s8_norm_sub_120_v0));
    assign tmp_workload_top_int_256__164_v0 = (s8_norm_mul_72_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (rtlzz_pipe_49_s4 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_85Core rtlzz_owner_85(.a(129'(rtlzz_pipe_84_s1)), .b(129'(rtlzz_pipe_248_s1)), .cin(1'b0), .value(s8_norm_add_130_v0));
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_87Core rtlzz_owner_87(.a(129'(tmp_workload_top_int_129__179_v0)), .b(129'(rtlzz_pipe_249_s1)), .cin(1'b0), .value(s8_norm_add_133_v0));
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (rtlzz_pipe_114_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s2 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_95Core rtlzz_owner_95(.a(34'(rtlzz_pipe_94_s3)), .b(34'(__beopt_width_388)), .cin(1'b0), .value(s8_norm_add_152_v0));
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_97Core rtlzz_owner_97(.a(34'(tmp_workload_top_int_34__207_v0)), .b(34'(rtlzz_pipe_253_s5)), .cin(1'b0), .value(s8_norm_add_155_v0));
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (__beopt_width_609 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_103Core rtlzz_owner_103(.a(68'(n60_v0)), .b(68'(rtlzz_pipe_102_s5)), .cin(1'b0), .value(s8_norm_sub_161_v0));
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_105Core rtlzz_owner_105(.a(68'(s8_norm_sub_161_v0)), .b(68'(tmp_workload_top_int_68__220_v0)), .cin(1'b0), .value(s8_norm_sub_163_v0));
    assign tmp_workload_top_int_130__223_v0 = (__beopt_width_611 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (rtlzz_pipe_107_s6 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s6 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (rtlzz_pipe_206_s3 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_113Core rtlzz_owner_113(.a(66'(tmp_workload_top_int_66__238_v0)), .b(66'(rtlzz_pipe_256_s3)), .cin(1'b0), .value(s8_norm_add_177_v0));
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_115Core rtlzz_owner_115(.a(66'(tmp_workload_top_int_66__243_v0)), .b(66'(__beopt_width_404)), .cin(1'b0), .value(s8_norm_add_180_v0));
    assign tmp_workload_top_int_66__252_v0 = (rtlzz_pipe_113_s4 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (rtlzz_pipe_210_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_121Core rtlzz_owner_121(.a(34'(tmp_workload_top_int_34__262_v0)), .b(34'(rtlzz_pipe_260_s5)), .cin(1'b0), .value(s8_norm_add_195_v0));
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_123Core rtlzz_owner_123(.a(34'(tmp_workload_top_int_34__267_v0)), .b(34'(rtlzz_pipe_261_s3)), .cin(1'b0), .value(s8_norm_add_198_v0));
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_129Core rtlzz_owner_129(.a(68'(n74_v0)), .b(68'(rtlzz_pipe_128_s6)), .cin(1'b0), .value(s8_norm_sub_204_v0));
    assign tmp_workload_top_int_68__280_v0 = (rtlzz_pipe_213_s6 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_131Core rtlzz_owner_131(.a(68'(s8_norm_sub_204_v0)), .b(68'(tmp_workload_top_int_68__280_v0)), .cin(1'b0), .value(s8_norm_sub_206_v0));
    assign tmp_workload_top_int_132__283_v0 = (rtlzz_pipe_118_s6 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (rtlzz_pipe_135_s6 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_138Core rtlzz_owner_138(.a(132'(__beopt_width_307)), .b(130'(tmp_workload_top_int_132__293_v0)), .cin(1'b0), .value(s8_norm_sub_215_v0));
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_140Core rtlzz_owner_140(.a(132'(s8_norm_sub_215_v0)), .b(132'(rtlzz_pipe_139_s6)), .cin(1'b0), .value(s8_norm_sub_217_v0));
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (rtlzz_pipe_144_s6 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_147Core rtlzz_owner_147(.a(258'(rtlzz_pipe_219_s7)), .b(256'(tmp_workload_top_int_258__309_v0)), .cin(1'b0), .value(s8_norm_sub_226_v0));
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_149Core rtlzz_owner_149(.a(258'(s8_norm_sub_226_v0)), .b(256'(tmp_workload_top_int_258__312_v0)), .cin(1'b0), .value(s8_norm_sub_228_v0));
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_157Core rtlzz_owner_157(.a(512'(tmp_workload_top_int_513__325_v0)), .b(512'(rtlzz_pipe_156_s7)), .cin(1'b0), .value(s8_norm_add_238_v0));
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_217_reduce rtlzz_reduce_217(.i152(s8_norm_shift_231_v0), .i154(s8_norm_shift_234_v0), .i223(__beopt_width_303), .y(__beopt_width_294));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_219_reduce rtlzz_reduce_219(.i143(s8_norm_shift_220_v0), .i145(s8_norm_shift_223_v0), .i227(__beopt_width_310), .y(__beopt_width_297));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_220Core rtlzz_owner_220(.a(256'(rtlzz_pipe_79_s6)), .b(256'(rtlzz_pipe_83_s6)), .cin(1'b0), .value(__beopt_width_299));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_221Core rtlzz_owner_221(.a(256'(rtlzz_pipe_220_s7)), .b(256'(s8_norm_shift_123_v0)), .cin(1'b0), .value(__beopt_width_301));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_223_reduce rtlzz_reduce_223(.i43(s8_norm_shift_61_v0), .i880(rtlzz_pipe_41_s7), .i886(rtlzz_pipe_45_s7), .y(__beopt_width_303));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_225_reduce rtlzz_reduce_225(.i134(s8_norm_shift_209_v0), .i136(s8_norm_shift_212_v0), .i917(rtlzz_pipe_118_s6), .y(__beopt_width_307));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_227_reduce rtlzz_reduce_227(.i108(s8_norm_shift_166_v0), .i110(s8_norm_shift_169_v0), .i909(rtlzz_pipe_106_s6), .y(__beopt_width_310));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_229_reduce rtlzz_reduce_229(.i72(s8_norm_shift_112_v0), .i74(s8_norm_shift_115_v0), .i536(mul_tree_350_536), .y(__beopt_width_313));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_231_reduce rtlzz_reduce_231(.i34(s8_norm_shift_50_v0), .i36(s8_norm_shift_53_v0), .i890(rtlzz_pipe_28_s7), .y(__beopt_width_317));
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (__beopt_width_325 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (__beopt_width_337 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (__beopt_width_340 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s1 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (rtlzz_pipe_272_s3 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s2 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (__beopt_width_362 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (__beopt_width_380 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (__beopt_width_386 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (__beopt_width_399 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (rtlzz_pipe_285_s4 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s2 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (__beopt_width_413 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (rtlzz_pipe_288_s4 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s5 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (rtlzz_pipe_290_s4 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (__beopt_width_427 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = mul_tree_343_384; // decl: <none>; prim: <none>
    assign arith_original_344 = mul_tree_344_409; // decl: <none>; prim: <none>
    assign arith_original_345 = mul_tree_345_434; // decl: <none>; prim: <none>
    assign arith_original_346 = mul_tree_346_437; // decl: <none>; prim: <none>
    assign arith_original_347 = mul_tree_347_462; // decl: <none>; prim: <none>
    assign arith_original_348 = mul_tree_348_487; // decl: <none>; prim: <none>
    assign arith_original_349 = mul_tree_349_512; // decl: <none>; prim: <none>
    assign arith_original_350 = mul_tree_350_537; // decl: <none>; prim: <none>
    assign arith_original_351 = mul_tree_351_540; // decl: <none>; prim: <none>
    assign arith_original_352 = mul_tree_352_565; // decl: <none>; prim: <none>
    assign arith_original_353 = mul_tree_353_590; // decl: <none>; prim: <none>
    assign arith_original_354 = mul_tree_354_593; // decl: <none>; prim: <none>
    assign arith_original_355 = mul_tree_355_618; // decl: <none>; prim: <none>
    assign arith_original_356 = mul_tree_356_643; // decl: <none>; prim: <none>
    assign arith_original_357 = mul_tree_357_668; // decl: <none>; prim: <none>
    assign arith_original_358 = mul_tree_358_693; // decl: <none>; prim: <none>
    assign arith_original_359 = mul_tree_359_718; // decl: <none>; prim: <none>
    assign mul_tree_343_360 = rtlzz_pipe_292_s2[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_361 = rtlzz_pipe_293_s2[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_362Core rtlzz_owner_362(.a(32'(mul_tree_343_360)), .b(32'(mul_tree_343_361)), .cin(1'b0), .value(mul_tree_343_362));
    assign mul_tree_343_363 = rtlzz_pipe_292_s2[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_364 = rtlzz_pipe_293_s2[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_365Core rtlzz_owner_365(.a(32'(mul_tree_343_363)), .b(32'(mul_tree_343_364)), .cin(1'b0), .value(mul_tree_343_365));
    assign mul_tree_343_366 = {mul_tree_343_365, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_367 = rtlzz_pipe_292_s2[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_368 = rtlzz_pipe_293_s2[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_369Core rtlzz_owner_369(.a(32'(mul_tree_343_367)), .b(32'(mul_tree_343_368)), .cin(1'b0), .value(mul_tree_343_369));
    assign mul_tree_343_370 = {mul_tree_343_369, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_371 = rtlzz_pipe_292_s2[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_372 = rtlzz_pipe_293_s2[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_373Core rtlzz_owner_373(.a(32'(mul_tree_343_371)), .b(32'(mul_tree_343_372)), .cin(1'b0), .value(mul_tree_343_373));
    assign mul_tree_343_374 = {mul_tree_343_373, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_375 = ({33'h0, mul_tree_343_362}); // decl: <none>; prim: <none>
    assign mul_tree_343_376 = ({1'h0, mul_tree_343_366}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_377Core rtlzz_owner_377(.a(64'(mul_tree_343_375)), .b(96'(mul_tree_343_376)), .cin(1'h0), .value(mul_tree_343_377));
    assign mul_tree_343_378 = ({33'h0, mul_tree_343_370}); // decl: <none>; prim: <none>
    assign mul_tree_343_379 = ({1'h0, mul_tree_343_374}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_380Core rtlzz_owner_380(.a(96'(mul_tree_343_378)), .b(128'(mul_tree_343_379)), .cin(1'h0), .value(mul_tree_343_380[127:0]));
    assign mul_tree_343_380[128:128] = '0;
    assign mul_tree_343_381 = ({33'h0, rtlzz_pipe_377_s6}); // decl: <none>; prim: <none>
    assign mul_tree_343_382 = ({1'h0, rtlzz_pipe_380_s6}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_383Core rtlzz_owner_383(.a(97'(mul_tree_343_381)), .b(129'(mul_tree_343_382)), .cin(1'h0), .value(mul_tree_343_383[127:0]));
    assign mul_tree_343_383[129:128] = '0;
    assign mul_tree_343_384 = mul_tree_343_383[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_385 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_386 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_387Core rtlzz_owner_387(.a(32'(mul_tree_344_385)), .b(32'(mul_tree_344_386)), .cin(1'b0), .value(mul_tree_344_387));
    assign mul_tree_344_388 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_389 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_390Core rtlzz_owner_390(.a(32'(mul_tree_344_388)), .b(32'(mul_tree_344_389)), .cin(1'b0), .value(mul_tree_344_390));
    assign mul_tree_344_391 = {mul_tree_344_390, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_392 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_393 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_394Core rtlzz_owner_394(.a(32'(mul_tree_344_392)), .b(32'(mul_tree_344_393)), .cin(1'b0), .value(mul_tree_344_394));
    assign mul_tree_344_395 = {mul_tree_344_394, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_396 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_397 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_398Core rtlzz_owner_398(.a(32'(mul_tree_344_396)), .b(32'(mul_tree_344_397)), .cin(1'b0), .value(mul_tree_344_398));
    assign mul_tree_344_399 = {mul_tree_344_398, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_400 = ({33'h0, mul_tree_344_387}); // decl: <none>; prim: <none>
    assign mul_tree_344_401 = ({1'h0, mul_tree_344_391}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_402Core rtlzz_owner_402(.a(64'(mul_tree_344_400)), .b(96'(mul_tree_344_401)), .cin(1'h0), .value(mul_tree_344_402));
    assign mul_tree_344_403 = ({33'h0, mul_tree_344_395}); // decl: <none>; prim: <none>
    assign mul_tree_344_404 = ({1'h0, mul_tree_344_399}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_405Core rtlzz_owner_405(.a(96'(mul_tree_344_403)), .b(128'(mul_tree_344_404)), .cin(1'h0), .value(mul_tree_344_405[127:0]));
    assign mul_tree_344_405[128:128] = '0;
    assign mul_tree_344_406 = ({33'h0, rtlzz_pipe_402_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_407 = ({1'h0, rtlzz_pipe_405_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_408Core rtlzz_owner_408(.a(97'(mul_tree_344_406)), .b(129'(mul_tree_344_407)), .cin(1'h0), .value(mul_tree_344_408[127:0]));
    assign mul_tree_344_408[129:128] = '0;
    assign mul_tree_344_409 = mul_tree_344_408[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_410 = mul_precision_298[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_411 = rtlzz_pipe_299_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_412Core rtlzz_owner_412(.a(32'(mul_tree_345_410)), .b(32'(mul_tree_345_411)), .cin(1'b0), .value(mul_tree_345_412));
    assign mul_tree_345_413 = mul_precision_298[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_414 = rtlzz_pipe_299_s6[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_415Core rtlzz_owner_415(.a(32'(mul_tree_345_413)), .b(1'(mul_tree_345_414)), .cin(1'b0), .value(mul_tree_345_415));
    assign mul_tree_345_416 = {mul_tree_345_415, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_417 = mul_precision_298[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_418 = rtlzz_pipe_299_s6[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_419Core rtlzz_owner_419(.a(1'(mul_tree_345_417)), .b(32'(mul_tree_345_418)), .cin(1'b0), .value(mul_tree_345_419));
    assign mul_tree_345_420 = {mul_tree_345_419, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_421 = mul_precision_298[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_422 = rtlzz_pipe_299_s6[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_423Core rtlzz_owner_423(.a(1'(mul_tree_345_421)), .b(1'(mul_tree_345_422)), .cin(1'b0), .value(mul_tree_345_423));
    assign mul_tree_345_424 = {mul_tree_345_423, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_425 = ({2'h0, mul_tree_345_412}); // decl: <none>; prim: <none>
    assign mul_tree_345_426 = ({1'h0, mul_tree_345_416}); // decl: <none>; prim: <none>
    assign mul_tree_345_428 = ({2'h0, mul_tree_345_420}); // decl: <none>; prim: <none>
    assign mul_tree_345_429 = ({1'h0, mul_tree_345_424}); // decl: <none>; prim: <none>
    assign mul_tree_345_431 = ({2'h0, mul_tree_345_427}); // decl: <none>; prim: <none>
    assign mul_tree_345_432 = ({1'h0, mul_tree_345_430}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_433_reduce rtlzz_reduce_433(.i412(mul_tree_345_412), .i415(mul_tree_345_415), .i419(mul_tree_345_419), .i423(mul_tree_345_423), .y(mul_tree_345_433));
    assign mul_tree_345_434 = mul_tree_345_433[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_435 = mul_precision_301[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_436 = rtlzz_pipe_302_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_437Core rtlzz_owner_437(.a(32'(mul_tree_346_435)), .b(32'(mul_tree_346_436)), .cin(1'b0), .value(mul_tree_346_437));
    assign mul_tree_347_438 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_439 = rtlzz_pipe_305_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_440Core rtlzz_owner_440(.a(32'(mul_tree_347_438)), .b(32'(mul_tree_347_439)), .cin(1'b0), .value(mul_tree_347_440));
    assign mul_tree_347_441 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_442 = rtlzz_pipe_305_s7[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_443Core rtlzz_owner_443(.a(32'(mul_tree_347_441)), .b(2'(mul_tree_347_442)), .cin(1'b0), .value(mul_tree_347_443));
    assign mul_tree_347_444 = {mul_tree_347_443, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_445 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_446 = rtlzz_pipe_305_s7[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_447Core rtlzz_owner_447(.a(2'(mul_tree_347_445)), .b(32'(mul_tree_347_446)), .cin(1'b0), .value(mul_tree_347_447));
    assign mul_tree_347_448 = {mul_tree_347_447, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_449 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_450 = rtlzz_pipe_305_s7[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_451Core rtlzz_owner_451(.a(2'(mul_tree_347_449)), .b(2'(mul_tree_347_450)), .cin(1'b0), .value(mul_tree_347_451));
    assign mul_tree_347_452 = {mul_tree_347_451, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_453 = ({3'h0, mul_tree_347_440}); // decl: <none>; prim: <none>
    assign mul_tree_347_454 = ({1'h0, mul_tree_347_444}); // decl: <none>; prim: <none>
    assign mul_tree_347_456 = ({3'h0, mul_tree_347_448}); // decl: <none>; prim: <none>
    assign mul_tree_347_457 = ({1'h0, mul_tree_347_452}); // decl: <none>; prim: <none>
    assign mul_tree_347_459 = ({3'h0, mul_tree_347_455}); // decl: <none>; prim: <none>
    assign mul_tree_347_460 = ({1'h0, mul_tree_347_458}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_461_reduce rtlzz_reduce_461(.i440(mul_tree_347_440), .i443(mul_tree_347_443), .i447(mul_tree_347_447), .i451(mul_tree_347_451), .y(mul_tree_347_461));
    assign mul_tree_347_462 = mul_tree_347_461[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_463 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_464 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_465Core rtlzz_owner_465(.a(32'(mul_tree_348_463)), .b(32'(mul_tree_348_464)), .cin(1'b0), .value(mul_tree_348_465));
    assign mul_tree_348_466 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_467 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_468Core rtlzz_owner_468(.a(32'(mul_tree_348_466)), .b(32'(mul_tree_348_467)), .cin(1'b0), .value(mul_tree_348_468));
    assign mul_tree_348_469 = {mul_tree_348_468, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_470 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_471 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_472Core rtlzz_owner_472(.a(32'(mul_tree_348_470)), .b(32'(mul_tree_348_471)), .cin(1'b0), .value(mul_tree_348_472));
    assign mul_tree_348_473 = {mul_tree_348_472, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_474 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_475 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_476Core rtlzz_owner_476(.a(32'(mul_tree_348_474)), .b(32'(mul_tree_348_475)), .cin(1'b0), .value(mul_tree_348_476));
    assign mul_tree_348_477 = {mul_tree_348_476, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_478 = ({33'h0, mul_tree_348_465}); // decl: <none>; prim: <none>
    assign mul_tree_348_479 = ({1'h0, mul_tree_348_469}); // decl: <none>; prim: <none>
    assign mul_tree_348_481 = ({33'h0, mul_tree_348_473}); // decl: <none>; prim: <none>
    assign mul_tree_348_482 = ({1'h0, mul_tree_348_477}); // decl: <none>; prim: <none>
    assign mul_tree_348_484 = ({33'h0, mul_tree_348_480}); // decl: <none>; prim: <none>
    assign mul_tree_348_485 = ({1'h0, mul_tree_348_483}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_486_reduce rtlzz_reduce_486(.i465(mul_tree_348_465), .i468(mul_tree_348_468), .i472(mul_tree_348_472), .i476(mul_tree_348_476), .y(mul_tree_348_486));
    assign mul_tree_348_487 = mul_tree_348_486[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_488 = rtlzz_pipe_310_s2[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_489 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_490Core rtlzz_owner_490(.a(32'(mul_tree_349_488)), .b(32'(mul_tree_349_489)), .cin(1'b0), .value(mul_tree_349_490));
    assign mul_tree_349_491 = rtlzz_pipe_310_s2[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_492 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_493Core rtlzz_owner_493(.a(32'(mul_tree_349_491)), .b(32'(mul_tree_349_492)), .cin(1'b0), .value(mul_tree_349_493));
    assign mul_tree_349_494 = {mul_tree_349_493, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_495 = rtlzz_pipe_310_s2[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_496 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_497Core rtlzz_owner_497(.a(32'(mul_tree_349_495)), .b(32'(mul_tree_349_496)), .cin(1'b0), .value(mul_tree_349_497));
    assign mul_tree_349_498 = {mul_tree_349_497, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_499 = rtlzz_pipe_310_s2[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_500 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_501Core rtlzz_owner_501(.a(32'(mul_tree_349_499)), .b(32'(mul_tree_349_500)), .cin(1'b0), .value(mul_tree_349_501));
    assign mul_tree_349_502 = {mul_tree_349_501, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_503 = ({33'h0, mul_tree_349_490}); // decl: <none>; prim: <none>
    assign mul_tree_349_504 = ({1'h0, mul_tree_349_494}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_505Core rtlzz_owner_505(.a(64'(mul_tree_349_503)), .b(96'(mul_tree_349_504)), .cin(1'h0), .value(mul_tree_349_505));
    assign mul_tree_349_506 = ({33'h0, mul_tree_349_498}); // decl: <none>; prim: <none>
    assign mul_tree_349_507 = ({1'h0, mul_tree_349_502}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_508Core rtlzz_owner_508(.a(96'(mul_tree_349_506)), .b(128'(mul_tree_349_507)), .cin(1'h0), .value(mul_tree_349_508[127:0]));
    assign mul_tree_349_508[128:128] = '0;
    assign mul_tree_349_509 = ({33'h0, rtlzz_pipe_505_s3}); // decl: <none>; prim: <none>
    assign mul_tree_349_510 = ({1'h0, rtlzz_pipe_508_s3}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_511Core rtlzz_owner_511(.a(97'(mul_tree_349_509)), .b(129'(mul_tree_349_510)), .cin(1'h0), .value(mul_tree_349_511[127:0]));
    assign mul_tree_349_511[129:128] = '0;
    assign mul_tree_349_512 = mul_tree_349_511[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_513 = mul_precision_313[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_514 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_515Core rtlzz_owner_515(.a(32'(mul_tree_350_513)), .b(32'(mul_tree_350_514)), .cin(1'b0), .value(mul_tree_350_515));
    assign mul_tree_350_516 = mul_precision_313[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_517 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_518Core rtlzz_owner_518(.a(32'(mul_tree_350_516)), .b(1'(mul_tree_350_517)), .cin(1'b0), .value(mul_tree_350_518));
    assign mul_tree_350_519 = {mul_tree_350_518, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_520 = mul_precision_313[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_521 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_522Core rtlzz_owner_522(.a(1'(mul_tree_350_520)), .b(32'(mul_tree_350_521)), .cin(1'b0), .value(mul_tree_350_522));
    assign mul_tree_350_523 = {mul_tree_350_522, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_524 = mul_precision_313[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_525 = mul_precision_314[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_526Core rtlzz_owner_526(.a(1'(mul_tree_350_524)), .b(1'(mul_tree_350_525)), .cin(1'b0), .value(mul_tree_350_526));
    assign mul_tree_350_527 = {mul_tree_350_526, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_528 = ({2'h0, mul_tree_350_515}); // decl: <none>; prim: <none>
    assign mul_tree_350_529 = ({1'h0, mul_tree_350_519}); // decl: <none>; prim: <none>
    assign mul_tree_350_531 = ({2'h0, mul_tree_350_523}); // decl: <none>; prim: <none>
    assign mul_tree_350_532 = ({1'h0, mul_tree_350_527}); // decl: <none>; prim: <none>
    assign mul_tree_350_534 = ({2'h0, mul_tree_350_530}); // decl: <none>; prim: <none>
    assign mul_tree_350_535 = ({1'h0, mul_tree_350_533}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_536_reduce rtlzz_reduce_536(.i515(mul_tree_350_515), .i518(mul_tree_350_518), .i522(mul_tree_350_522), .i526(mul_tree_350_526), .y(mul_tree_350_536));
    assign mul_tree_350_537 = mul_tree_350_536[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_538 = rtlzz_pipe_316_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_539 = mul_precision_317[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_540Core rtlzz_owner_540(.a(32'(mul_tree_351_538)), .b(32'(mul_tree_351_539)), .cin(1'b0), .value(mul_tree_351_540));
    assign mul_tree_352_541 = rtlzz_pipe_319_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_542 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_543Core rtlzz_owner_543(.a(32'(mul_tree_352_541)), .b(32'(mul_tree_352_542)), .cin(1'b0), .value(mul_tree_352_543));
    assign mul_tree_352_544 = rtlzz_pipe_319_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_545 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_546Core rtlzz_owner_546(.a(32'(mul_tree_352_544)), .b(2'(mul_tree_352_545)), .cin(1'b0), .value(mul_tree_352_546));
    assign mul_tree_352_547 = {mul_tree_352_546, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_548 = rtlzz_pipe_319_s7[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_549 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_550Core rtlzz_owner_550(.a(2'(mul_tree_352_548)), .b(32'(mul_tree_352_549)), .cin(1'b0), .value(mul_tree_352_550));
    assign mul_tree_352_551 = {mul_tree_352_550, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_552 = rtlzz_pipe_319_s7[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_553 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_554Core rtlzz_owner_554(.a(2'(mul_tree_352_552)), .b(2'(mul_tree_352_553)), .cin(1'b0), .value(mul_tree_352_554));
    assign mul_tree_352_555 = {mul_tree_352_554, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_556 = ({3'h0, mul_tree_352_543}); // decl: <none>; prim: <none>
    assign mul_tree_352_557 = ({1'h0, mul_tree_352_547}); // decl: <none>; prim: <none>
    assign mul_tree_352_559 = ({3'h0, mul_tree_352_551}); // decl: <none>; prim: <none>
    assign mul_tree_352_560 = ({1'h0, mul_tree_352_555}); // decl: <none>; prim: <none>
    assign mul_tree_352_562 = ({3'h0, mul_tree_352_558}); // decl: <none>; prim: <none>
    assign mul_tree_352_563 = ({1'h0, mul_tree_352_561}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_564_reduce rtlzz_reduce_564(.i543(mul_tree_352_543), .i546(mul_tree_352_546), .i550(mul_tree_352_550), .i554(mul_tree_352_554), .y(mul_tree_352_564));
    assign mul_tree_352_565 = mul_tree_352_564[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_566 = mul_precision_322[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_567 = rtlzz_pipe_323_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_568Core rtlzz_owner_568(.a(32'(mul_tree_353_566)), .b(32'(mul_tree_353_567)), .cin(1'b0), .value(mul_tree_353_568));
    assign mul_tree_353_569 = mul_precision_322[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_570 = rtlzz_pipe_323_s3[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_571Core rtlzz_owner_571(.a(32'(mul_tree_353_569)), .b(1'(mul_tree_353_570)), .cin(1'b0), .value(mul_tree_353_571));
    assign mul_tree_353_572 = {mul_tree_353_571, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_573 = mul_precision_322[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_574 = rtlzz_pipe_323_s3[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_575Core rtlzz_owner_575(.a(1'(mul_tree_353_573)), .b(32'(mul_tree_353_574)), .cin(1'b0), .value(mul_tree_353_575));
    assign mul_tree_353_576 = {mul_tree_353_575, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_577 = mul_precision_322[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_578 = rtlzz_pipe_323_s3[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_579Core rtlzz_owner_579(.a(1'(mul_tree_353_577)), .b(1'(mul_tree_353_578)), .cin(1'b0), .value(mul_tree_353_579));
    assign mul_tree_353_580 = {mul_tree_353_579, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_581 = ({2'h0, mul_tree_353_568}); // decl: <none>; prim: <none>
    assign mul_tree_353_582 = ({1'h0, mul_tree_353_572}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_583Core rtlzz_owner_583(.a(64'(mul_tree_353_581)), .b(65'(mul_tree_353_582)), .cin(1'h0), .value(mul_tree_353_583));
    assign mul_tree_353_584 = ({2'h0, mul_tree_353_576}); // decl: <none>; prim: <none>
    assign mul_tree_353_585 = ({1'h0, mul_tree_353_580}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_586Core rtlzz_owner_586(.a(65'(mul_tree_353_584)), .b(66'(mul_tree_353_585)), .cin(1'h0), .value(mul_tree_353_586[65:0]));
    assign mul_tree_353_586[66:66] = '0;
    assign mul_tree_353_587 = ({2'h0, rtlzz_pipe_583_s4}); // decl: <none>; prim: <none>
    assign mul_tree_353_588 = ({1'h0, rtlzz_pipe_586_s4}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_589Core rtlzz_owner_589(.a(66'(mul_tree_353_587)), .b(67'(mul_tree_353_588)), .cin(1'h0), .value(mul_tree_353_589[65:0]));
    assign mul_tree_353_589[67:66] = '0;
    assign mul_tree_353_590 = mul_tree_353_589[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_591 = rtlzz_pipe_325_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_592 = mul_precision_326[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_593Core rtlzz_owner_593(.a(32'(mul_tree_354_591)), .b(32'(mul_tree_354_592)), .cin(1'b0), .value(mul_tree_354_593));
    assign mul_tree_355_594 = rtlzz_pipe_328_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_595 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_596Core rtlzz_owner_596(.a(32'(mul_tree_355_594)), .b(32'(mul_tree_355_595)), .cin(1'b0), .value(mul_tree_355_596));
    assign mul_tree_355_597 = rtlzz_pipe_328_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_598 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_599Core rtlzz_owner_599(.a(32'(mul_tree_355_597)), .b(2'(mul_tree_355_598)), .cin(1'b0), .value(mul_tree_355_599));
    assign mul_tree_355_600 = {mul_tree_355_599, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_601 = rtlzz_pipe_328_s5[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_602 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_603Core rtlzz_owner_603(.a(2'(mul_tree_355_601)), .b(32'(mul_tree_355_602)), .cin(1'b0), .value(mul_tree_355_603));
    assign mul_tree_355_604 = {mul_tree_355_603, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_605 = rtlzz_pipe_328_s5[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_606 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_607Core rtlzz_owner_607(.a(2'(mul_tree_355_605)), .b(2'(mul_tree_355_606)), .cin(1'b0), .value(mul_tree_355_607));
    assign mul_tree_355_608 = {mul_tree_355_607, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_609 = ({3'h0, mul_tree_355_596}); // decl: <none>; prim: <none>
    assign mul_tree_355_610 = ({1'h0, mul_tree_355_600}); // decl: <none>; prim: <none>
    assign mul_tree_355_612 = ({3'h0, mul_tree_355_604}); // decl: <none>; prim: <none>
    assign mul_tree_355_613 = ({1'h0, mul_tree_355_608}); // decl: <none>; prim: <none>
    assign mul_tree_355_615 = ({3'h0, mul_tree_355_611}); // decl: <none>; prim: <none>
    assign mul_tree_355_616 = ({1'h0, mul_tree_355_614}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_617_reduce rtlzz_reduce_617(.i596(mul_tree_355_596), .i599(mul_tree_355_599), .i603(mul_tree_355_603), .i607(mul_tree_355_607), .y(mul_tree_355_617));
    assign mul_tree_355_618 = mul_tree_355_617[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_619 = rtlzz_pipe_331_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_620 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_621Core rtlzz_owner_621(.a(32'(mul_tree_356_619)), .b(32'(mul_tree_356_620)), .cin(1'b0), .value(mul_tree_356_621));
    assign mul_tree_356_622 = rtlzz_pipe_331_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_623 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_624Core rtlzz_owner_624(.a(32'(mul_tree_356_622)), .b(32'(mul_tree_356_623)), .cin(1'b0), .value(mul_tree_356_624));
    assign mul_tree_356_625 = {mul_tree_356_624, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_626 = rtlzz_pipe_331_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_627 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_628Core rtlzz_owner_628(.a(32'(mul_tree_356_626)), .b(32'(mul_tree_356_627)), .cin(1'b0), .value(mul_tree_356_628));
    assign mul_tree_356_629 = {mul_tree_356_628, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_630 = rtlzz_pipe_331_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_631 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_632Core rtlzz_owner_632(.a(32'(mul_tree_356_630)), .b(32'(mul_tree_356_631)), .cin(1'b0), .value(mul_tree_356_632));
    assign mul_tree_356_633 = {mul_tree_356_632, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_634 = ({33'h0, mul_tree_356_621}); // decl: <none>; prim: <none>
    assign mul_tree_356_635 = ({1'h0, mul_tree_356_625}); // decl: <none>; prim: <none>
    assign mul_tree_356_637 = ({33'h0, mul_tree_356_629}); // decl: <none>; prim: <none>
    assign mul_tree_356_638 = ({1'h0, mul_tree_356_633}); // decl: <none>; prim: <none>
    assign mul_tree_356_640 = ({33'h0, mul_tree_356_636}); // decl: <none>; prim: <none>
    assign mul_tree_356_641 = ({1'h0, mul_tree_356_639}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_642_reduce rtlzz_reduce_642(.i621(mul_tree_356_621), .i624(mul_tree_356_624), .i628(mul_tree_356_628), .i632(mul_tree_356_632), .y(mul_tree_356_642));
    assign mul_tree_356_643 = mul_tree_356_642[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_644 = mul_precision_334[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_645 = rtlzz_pipe_335_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_646Core rtlzz_owner_646(.a(32'(mul_tree_357_644)), .b(32'(mul_tree_357_645)), .cin(1'b0), .value(mul_tree_357_646));
    assign mul_tree_357_647 = mul_precision_334[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_648 = rtlzz_pipe_335_s4[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_649Core rtlzz_owner_649(.a(32'(mul_tree_357_647)), .b(1'(mul_tree_357_648)), .cin(1'b0), .value(mul_tree_357_649));
    assign mul_tree_357_650 = {mul_tree_357_649, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_651 = mul_precision_334[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_652 = rtlzz_pipe_335_s4[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_653Core rtlzz_owner_653(.a(1'(mul_tree_357_651)), .b(32'(mul_tree_357_652)), .cin(1'b0), .value(mul_tree_357_653));
    assign mul_tree_357_654 = {mul_tree_357_653, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_655 = mul_precision_334[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_656 = rtlzz_pipe_335_s4[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_657Core rtlzz_owner_657(.a(1'(mul_tree_357_655)), .b(1'(mul_tree_357_656)), .cin(1'b0), .value(mul_tree_357_657));
    assign mul_tree_357_658 = {mul_tree_357_657, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_659 = ({2'h0, mul_tree_357_646}); // decl: <none>; prim: <none>
    assign mul_tree_357_660 = ({1'h0, mul_tree_357_650}); // decl: <none>; prim: <none>
    assign mul_tree_357_662 = ({2'h0, mul_tree_357_654}); // decl: <none>; prim: <none>
    assign mul_tree_357_663 = ({1'h0, mul_tree_357_658}); // decl: <none>; prim: <none>
    assign mul_tree_357_665 = ({2'h0, mul_tree_357_661}); // decl: <none>; prim: <none>
    assign mul_tree_357_666 = ({1'h0, mul_tree_357_664}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_667_reduce rtlzz_reduce_667(.i646(mul_tree_357_646), .i649(mul_tree_357_649), .i653(mul_tree_357_653), .i657(mul_tree_357_657), .y(mul_tree_357_667));
    assign mul_tree_357_668 = mul_tree_357_667[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_669 = rtlzz_pipe_337_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_670 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_671Core rtlzz_owner_671(.a(32'(mul_tree_358_669)), .b(32'(mul_tree_358_670)), .cin(1'b0), .value(mul_tree_358_671));
    assign mul_tree_358_672 = rtlzz_pipe_337_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_673 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_674Core rtlzz_owner_674(.a(32'(mul_tree_358_672)), .b(1'(mul_tree_358_673)), .cin(1'b0), .value(mul_tree_358_674));
    assign mul_tree_358_675 = {mul_tree_358_674, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_676 = rtlzz_pipe_337_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_677 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_678Core rtlzz_owner_678(.a(1'(mul_tree_358_676)), .b(32'(mul_tree_358_677)), .cin(1'b0), .value(mul_tree_358_678));
    assign mul_tree_358_679 = {mul_tree_358_678, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_680 = rtlzz_pipe_337_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_681 = mul_precision_338[32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_682Core rtlzz_owner_682(.a(1'(mul_tree_358_680)), .b(1'(mul_tree_358_681)), .cin(1'b0), .value(mul_tree_358_682));
    assign mul_tree_358_683 = {mul_tree_358_682, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_684 = ({2'h0, mul_tree_358_671}); // decl: <none>; prim: <none>
    assign mul_tree_358_685 = ({1'h0, mul_tree_358_675}); // decl: <none>; prim: <none>
    assign mul_tree_358_687 = ({2'h0, mul_tree_358_679}); // decl: <none>; prim: <none>
    assign mul_tree_358_688 = ({1'h0, mul_tree_358_683}); // decl: <none>; prim: <none>
    assign mul_tree_358_690 = ({2'h0, mul_tree_358_686}); // decl: <none>; prim: <none>
    assign mul_tree_358_691 = ({1'h0, mul_tree_358_689}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_692_reduce rtlzz_reduce_692(.i671(mul_tree_358_671), .i674(mul_tree_358_674), .i678(mul_tree_358_678), .i682(mul_tree_358_682), .y(mul_tree_358_692));
    assign mul_tree_358_693 = mul_tree_358_692[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_694 = mul_precision_340[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_695 = rtlzz_pipe_341_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_696Core rtlzz_owner_696(.a(32'(mul_tree_359_694)), .b(32'(mul_tree_359_695)), .cin(1'b0), .value(mul_tree_359_696));
    assign mul_tree_359_697 = mul_precision_340[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_698 = rtlzz_pipe_341_s5[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_699Core rtlzz_owner_699(.a(32'(mul_tree_359_697)), .b(2'(mul_tree_359_698)), .cin(1'b0), .value(mul_tree_359_699));
    assign mul_tree_359_700 = {mul_tree_359_699, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_701 = mul_precision_340[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_702 = rtlzz_pipe_341_s5[31:0]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_703Core rtlzz_owner_703(.a(2'(mul_tree_359_701)), .b(32'(mul_tree_359_702)), .cin(1'b0), .value(mul_tree_359_703));
    assign mul_tree_359_704 = {mul_tree_359_703, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_705 = mul_precision_340[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_706 = rtlzz_pipe_341_s5[33:32]; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_707Core rtlzz_owner_707(.a(2'(mul_tree_359_705)), .b(2'(mul_tree_359_706)), .cin(1'b0), .value(mul_tree_359_707));
    assign mul_tree_359_708 = {mul_tree_359_707, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_709 = ({3'h0, rtlzz_pipe_696_s6}); // decl: <none>; prim: <none>
    assign mul_tree_359_710 = ({1'h0, rtlzz_pipe_700_s6}); // decl: <none>; prim: <none>
    assign mul_tree_359_712 = ({3'h0, rtlzz_pipe_704_s6}); // decl: <none>; prim: <none>
    assign mul_tree_359_713 = ({1'h0, rtlzz_pipe_708_s6}); // decl: <none>; prim: <none>
    assign mul_tree_359_715 = ({3'h0, mul_tree_359_711}); // decl: <none>; prim: <none>
    assign mul_tree_359_716 = ({1'h0, mul_tree_359_714}); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_717_reduce rtlzz_reduce_717(.i922(rtlzz_pipe_696_s6), .i923(rtlzz_pipe_700_s6), .i924(rtlzz_pipe_704_s6), .i925(rtlzz_pipe_708_s6), .y(mul_tree_359_717));
    assign mul_tree_359_718 = mul_tree_359_717[67:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_156_s1 <= 513'h0;
            rtlzz_pipe_156_s2 <= 513'h0;
            rtlzz_pipe_156_s3 <= 513'h0;
            rtlzz_pipe_156_s4 <= 513'h0;
            rtlzz_pipe_156_s5 <= 513'h0;
            rtlzz_pipe_156_s6 <= 513'h0;
            rtlzz_pipe_156_s7 <= 513'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_12_s3 <= 65'h0;
            rtlzz_pipe_12_s4 <= 65'h0;
            rtlzz_pipe_12_s5 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_84_s1 <= 129'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_234_s5 <= 65'h0;
            rtlzz_pipe_164_s6 <= 66'h0;
            rtlzz_pipe_168_s6 <= 34'h0;
            rtlzz_pipe_168_s7 <= 34'h0;
            rtlzz_pipe_235_s1 <= 65'h0;
            rtlzz_pipe_235_s2 <= 65'h0;
            rtlzz_pipe_235_s3 <= 65'h0;
            rtlzz_pipe_235_s4 <= 65'h0;
            rtlzz_pipe_165_s5 <= 66'h0;
            rtlzz_pipe_169_s5 <= 34'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_266_s6 <= 64'h0;
            rtlzz_pipe_266_s7 <= 64'h0;
            rtlzz_pipe_238_s6 <= 34'h0;
            rtlzz_pipe_238_s7 <= 34'h0;
            rtlzz_pipe_239_s5 <= 34'h0;
            rtlzz_pipe_239_s6 <= 34'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_272_s1 <= 65'h0;
            rtlzz_pipe_272_s2 <= 65'h0;
            rtlzz_pipe_272_s3 <= 65'h0;
            rtlzz_pipe_242_s4 <= 65'h0;
            rtlzz_pipe_242_s5 <= 65'h0;
            rtlzz_pipe_242_s6 <= 65'h0;
            rtlzz_pipe_180_s7 <= 66'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_273_s2 <= 65'h0;
            rtlzz_pipe_243_s3 <= 65'h0;
            rtlzz_pipe_243_s4 <= 65'h0;
            rtlzz_pipe_243_s5 <= 65'h0;
            rtlzz_pipe_243_s6 <= 65'h0;
            rtlzz_pipe_243_s7 <= 65'h0;
            rtlzz_pipe_248_s1 <= 129'h0;
            rtlzz_pipe_198_s2 <= 34'h0;
            rtlzz_pipe_94_s3 <= 34'h0;
            rtlzz_pipe_206_s2 <= 66'h0;
            rtlzz_pipe_206_s3 <= 66'h0;
            rtlzz_pipe_249_s1 <= 129'h0;
            rtlzz_pipe_199_s2 <= 34'h0;
            rtlzz_pipe_199_s3 <= 34'h0;
            rtlzz_pipe_199_s4 <= 34'h0;
            rtlzz_pipe_199_s5 <= 34'h0;
            rtlzz_pipe_114_s2 <= 66'h0;
            rtlzz_pipe_280_s2 <= 64'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_280_s4 <= 64'h0;
            rtlzz_pipe_281_s2 <= 64'h0;
            rtlzz_pipe_281_s3 <= 64'h0;
            rtlzz_pipe_281_s4 <= 64'h0;
            rtlzz_pipe_281_s5 <= 64'h0;
            rtlzz_pipe_282_s2 <= 34'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_253_s2 <= 34'h0;
            rtlzz_pipe_253_s3 <= 34'h0;
            rtlzz_pipe_253_s4 <= 34'h0;
            rtlzz_pipe_253_s5 <= 34'h0;
            rtlzz_pipe_284_s2 <= 128'h0;
            rtlzz_pipe_285_s2 <= 128'h0;
            rtlzz_pipe_285_s3 <= 128'h0;
            rtlzz_pipe_285_s4 <= 128'h0;
            rtlzz_pipe_286_s2 <= 66'h0;
            rtlzz_pipe_256_s3 <= 66'h0;
            rtlzz_pipe_113_s4 <= 66'h0;
            rtlzz_pipe_210_s4 <= 34'h0;
            rtlzz_pipe_210_s5 <= 34'h0;
            rtlzz_pipe_115_s2 <= 66'h0;
            rtlzz_pipe_211_s2 <= 34'h0;
            rtlzz_pipe_211_s3 <= 34'h0;
            rtlzz_pipe_288_s4 <= 66'h0;
            rtlzz_pipe_289_s2 <= 66'h0;
            rtlzz_pipe_289_s3 <= 66'h0;
            rtlzz_pipe_289_s4 <= 66'h0;
            rtlzz_pipe_289_s5 <= 66'h0;
            rtlzz_pipe_290_s4 <= 34'h0;
            rtlzz_pipe_260_s5 <= 34'h0;
            rtlzz_pipe_261_s2 <= 34'h0;
            rtlzz_pipe_261_s3 <= 34'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_299_s6 <= 33'h0;
            rtlzz_pipe_302_s5 <= 32'h0;
            rtlzz_pipe_302_s6 <= 32'h0;
            rtlzz_pipe_302_s7 <= 32'h0;
            rtlzz_pipe_305_s7 <= 34'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s2 <= 64'h0;
            rtlzz_pipe_316_s7 <= 32'h0;
            rtlzz_pipe_319_s7 <= 34'h0;
            rtlzz_pipe_323_s3 <= 33'h0;
            rtlzz_pipe_325_s5 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_328_s5 <= 34'h0;
            rtlzz_pipe_331_s3 <= 64'h0;
            rtlzz_pipe_331_s4 <= 64'h0;
            rtlzz_pipe_335_s3 <= 33'h0;
            rtlzz_pipe_335_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_341_s4 <= 34'h0;
            rtlzz_pipe_341_s5 <= 34'h0;
            rtlzz_pipe_377_s3 <= 97'h0;
            rtlzz_pipe_377_s4 <= 97'h0;
            rtlzz_pipe_377_s5 <= 97'h0;
            rtlzz_pipe_377_s6 <= 97'h0;
            rtlzz_pipe_380_s3 <= 129'h0;
            rtlzz_pipe_380_s4 <= 129'h0;
            rtlzz_pipe_380_s5 <= 129'h0;
            rtlzz_pipe_380_s6 <= 129'h0;
            rtlzz_pipe_41_s7 <= 256'h0;
            rtlzz_pipe_37_s7 <= 130'h0;
            rtlzz_pipe_402_s4 <= 97'h0;
            rtlzz_pipe_405_s4 <= 129'h0;
            rtlzz_pipe_11_s5 <= 256'h0;
            rtlzz_pipe_45_s6 <= 256'h0;
            rtlzz_pipe_45_s7 <= 256'h0;
            rtlzz_pipe_39_s5 <= 130'h0;
            rtlzz_pipe_39_s6 <= 130'h0;
            rtlzz_pipe_39_s7 <= 130'h0;
            rtlzz_pipe_28_s7 <= 68'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_79_s6 <= 256'h0;
            rtlzz_pipe_75_s6 <= 130'h0;
            rtlzz_pipe_75_s7 <= 130'h0;
            rtlzz_pipe_505_s3 <= 97'h0;
            rtlzz_pipe_508_s3 <= 129'h0;
            rtlzz_pipe_49_s4 <= 256'h0;
            rtlzz_pipe_83_s5 <= 256'h0;
            rtlzz_pipe_83_s6 <= 256'h0;
            rtlzz_pipe_77_s4 <= 130'h0;
            rtlzz_pipe_77_s5 <= 130'h0;
            rtlzz_pipe_77_s6 <= 130'h0;
            rtlzz_pipe_77_s7 <= 130'h0;
            rtlzz_pipe_220_s7 <= 256'h0;
            rtlzz_pipe_583_s4 <= 66'h0;
            rtlzz_pipe_586_s4 <= 67'h0;
            rtlzz_pipe_102_s5 <= 68'h0;
            rtlzz_pipe_106_s5 <= 130'h0;
            rtlzz_pipe_106_s6 <= 130'h0;
            rtlzz_pipe_203_s6 <= 130'h0;
            rtlzz_pipe_107_s6 <= 130'h0;
            rtlzz_pipe_139_s5 <= 132'h0;
            rtlzz_pipe_139_s6 <= 132'h0;
            rtlzz_pipe_144_s5 <= 258'h0;
            rtlzz_pipe_144_s6 <= 258'h0;
            rtlzz_pipe_118_s5 <= 132'h0;
            rtlzz_pipe_118_s6 <= 132'h0;
            rtlzz_pipe_128_s5 <= 68'h0;
            rtlzz_pipe_128_s6 <= 68'h0;
            rtlzz_pipe_135_s6 <= 132'h0;
            rtlzz_pipe_213_s6 <= 68'h0;
            rtlzz_pipe_696_s6 <= 64'h0;
            rtlzz_pipe_700_s6 <= 66'h0;
            rtlzz_pipe_704_s6 <= 66'h0;
            rtlzz_pipe_708_s6 <= 68'h0;
            rtlzz_pipe_219_s7 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_156_s2 <= rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_156_s3 <= rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_156_s4 <= rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_156_s5 <= rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_156_s6 <= rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_156_s7 <= rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_84_s1 <= tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_234_s5 <= __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_164_s6 <= __beopt_width_545; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_168_s6 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_168_s7 <= rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_235_s2 <= rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_235_s3 <= rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_235_s4 <= rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_165_s5 <= __beopt_width_546; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_169_s5 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_266_s6 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_266_s7 <= rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_238_s6 <= __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_238_s7 <= rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_239_s5 <= __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_239_s6 <= rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_272_s1 <= __beopt_width_353; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_272_s2 <= rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_272_s3 <= rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_242_s4 <= __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_242_s5 <= rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_242_s6 <= rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_180_s7 <= __beopt_width_573; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_273_s2 <= rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_243_s3 <= __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_243_s4 <= rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_243_s5 <= rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_243_s6 <= rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_243_s7 <= rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_248_s1 <= __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_198_s2 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_94_s3 <= tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_206_s2 <= __beopt_width_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_206_s3 <= rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_199_s2 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_199_s3 <= rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_199_s4 <= rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_199_s5 <= rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_280_s2 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_280_s4 <= rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_281_s2 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_281_s3 <= rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_281_s4 <= rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_281_s5 <= rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_282_s2 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_253_s2 <= __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_253_s3 <= rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_253_s4 <= rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_253_s5 <= rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_284_s2 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_285_s2 <= __beopt_width_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_285_s3 <= rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_285_s4 <= rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_286_s2 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_256_s3 <= __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_113_s4 <= s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_210_s4 <= __beopt_width_627; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_210_s5 <= rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_211_s2 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_211_s3 <= rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_288_s4 <= __beopt_width_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_289_s2 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_289_s3 <= rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_289_s4 <= rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_290_s4 <= __beopt_width_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_260_s5 <= __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_261_s2 <= __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_261_s3 <= rtlzz_pipe_261_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_299_s6 <= mul_precision_299; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_302_s5 <= mul_precision_302; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_302_s6 <= rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_302_s7 <= rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_305_s7 <= mul_precision_305; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_310_s2 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_316_s7 <= mul_precision_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_319_s7 <= mul_precision_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_323_s3 <= mul_precision_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_325_s5 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_328_s5 <= rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_331_s3 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_335_s3 <= mul_precision_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_341_s4 <= mul_precision_341; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_341_s5 <= rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_377_s3 <= mul_tree_343_377; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_377_s4 <= rtlzz_pipe_377_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_377_s5 <= rtlzz_pipe_377_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_377_s6 <= rtlzz_pipe_377_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_380_s3 <= mul_tree_343_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_380_s4 <= rtlzz_pipe_380_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_380_s5 <= rtlzz_pipe_380_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_380_s6 <= rtlzz_pipe_380_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_41_s7 <= tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_37_s7 <= tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_402_s4 <= mul_tree_344_402; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_405_s4 <= mul_tree_344_405; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= rtlzz_pipe_45_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_39_s5 <= tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_39_s6 <= rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_39_s7 <= rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_28_s7 <= tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_75_s7 <= rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_505_s3 <= mul_tree_349_505; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_508_s3 <= mul_tree_349_508; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_49_s4 <= s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_83_s5 <= s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_77_s4 <= tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_77_s5 <= rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_77_s6 <= rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_77_s7 <= rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_220_s7 <= __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_583_s4 <= mul_tree_353_583; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_586_s4 <= mul_tree_353_586; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_106_s6 <= rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_203_s6 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_139_s5 <= tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_139_s6 <= rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_144_s5 <= tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_144_s6 <= rtlzz_pipe_144_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_118_s5 <= s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_118_s6 <= rtlzz_pipe_118_s5; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_128_s5 <= tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_128_s6 <= rtlzz_pipe_128_s5; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_135_s6 <= tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_213_s6 <= __beopt_width_634; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_696_s6 <= mul_tree_359_696; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_700_s6 <= mul_tree_359_700; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_704_s6 <= mul_tree_359_704; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_708_s6 <= mul_tree_359_708; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_219_s7 <= __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_217_reduce(input wire [511:0] i152, input wire [511:0] i154, input wire [255:0] i223, output wire [511:0] y);
wire [511:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i223[255], i223[254], i223[253], i223[252], i223[251], i223[250], i223[249], i223[248], i223[247], i223[246], i223[245], i223[244], i223[243], i223[242], i223[241], i223[240], i223[239], i223[238], i223[237], i223[236], i223[235], i223[234], i223[233], i223[232], i223[231], i223[230], i223[229], i223[228], i223[227], i223[226], i223[225], i223[224], i223[223], i223[222], i223[221], i223[220], i223[219], i223[218], i223[217], i223[216], i223[215], i223[214], i223[213], i223[212], i223[211], i223[210], i223[209], i223[208], i223[207], i223[206], i223[205], i223[204], i223[203], i223[202], i223[201], i223[200], i223[199], i223[198], i223[197], i223[196], i223[195], i223[194], i223[193], i223[192], i223[191], i223[190], i223[189], i223[188], i223[187], i223[186], i223[185], i223[184], i223[183], i223[182], i223[181], i223[180], i223[179], i223[178], i223[177], i223[176], i223[175], i223[174], i223[173], i223[172], i223[171], i223[170], i223[169], i223[168], i223[167], i223[166], i223[165], i223[164], i223[163], i223[162], i223[161], i223[160], i223[159], i223[158], i223[157], i223[156], i223[155], i223[154], i223[153], i223[152], i223[151], i223[150], i223[149], i223[148], i223[147], i223[146], i223[145], i223[144], i223[143], i223[142], i223[141], i223[140], i223[139], i223[138], i223[137], i223[136], i223[135], i223[134], i223[133], i223[132], i223[131], i223[130], i223[129], i223[128], i223[127], i223[126], i223[125], i223[124], i223[123], i223[122], i223[121], i223[120], i223[119], i223[118], i223[117], i223[116], i223[115], i223[114], i223[113], i223[112], i223[111], i223[110], i223[109], i223[108], i223[107], i223[106], i223[105], i223[104], i223[103], i223[102], i223[101], i223[100], i223[99], i223[98], i223[97], i223[96], i223[95], i223[94], i223[93], i223[92], i223[91], i223[90], i223[89], i223[88], i223[87], i223[86], i223[85], i223[84], i223[83], i223[82], i223[81], i223[80], i223[79], i223[78], i223[77], i223[76], i223[75], i223[74], i223[73], i223[72], i223[71], i223[70], i223[69], i223[68], i223[67], i223[66], i223[65], i223[64], i223[63], i223[62], i223[61], i223[60], i223[59], i223[58], i223[57], i223[56], i223[55], i223[54], i223[53], i223[52], i223[51], i223[50], i223[49], i223[48], i223[47], i223[46], i223[45], i223[44], i223[43], i223[42], i223[41], i223[40], i223[39], i223[38], i223[37], i223[36], i223[35], i223[34], i223[33], i223[32], i223[31], i223[30], i223[29], i223[28], i223[27], i223[26], i223[25], i223[24], i223[23], i223[22], i223[21], i223[20], i223[19], i223[18], i223[17], i223[16], i223[15], i223[14], i223[13], i223[12], i223[11], i223[10], i223[9], i223[8], i223[7], i223[6], i223[5], i223[4], i223[3], i223[2], i223[1], i223[0]};
wire [511:0] t1 = {i154[511], i154[510], i154[509], i154[508], i154[507], i154[506], i154[505], i154[504], i154[503], i154[502], i154[501], i154[500], i154[499], i154[498], i154[497], i154[496], i154[495], i154[494], i154[493], i154[492], i154[491], i154[490], i154[489], i154[488], i154[487], i154[486], i154[485], i154[484], i154[483], i154[482], i154[481], i154[480], i154[479], i154[478], i154[477], i154[476], i154[475], i154[474], i154[473], i154[472], i154[471], i154[470], i154[469], i154[468], i154[467], i154[466], i154[465], i154[464], i154[463], i154[462], i154[461], i154[460], i154[459], i154[458], i154[457], i154[456], i154[455], i154[454], i154[453], i154[452], i154[451], i154[450], i154[449], i154[448], i154[447], i154[446], i154[445], i154[444], i154[443], i154[442], i154[441], i154[440], i154[439], i154[438], i154[437], i154[436], i154[435], i154[434], i154[433], i154[432], i154[431], i154[430], i154[429], i154[428], i154[427], i154[426], i154[425], i154[424], i154[423], i154[422], i154[421], i154[420], i154[419], i154[418], i154[417], i154[416], i154[415], i154[414], i154[413], i154[412], i154[411], i154[410], i154[409], i154[408], i154[407], i154[406], i154[405], i154[404], i154[403], i154[402], i154[401], i154[400], i154[399], i154[398], i154[397], i154[396], i154[395], i154[394], i154[393], i154[392], i154[391], i154[390], i154[389], i154[388], i154[387], i154[386], i154[385], i154[384], i154[383], i154[382], i154[381], i154[380], i154[379], i154[378], i154[377], i154[376], i154[375], i154[374], i154[373], i154[372], i154[371], i154[370], i154[369], i154[368], i154[367], i154[366], i154[365], i154[364], i154[363], i154[362], i154[361], i154[360], i154[359], i154[358], i154[357], i154[356], i154[355], i154[354], i154[353], i154[352], i154[351], i154[350], i154[349], i154[348], i154[347], i154[346], i154[345], i154[344], i154[343], i154[342], i154[341], i154[340], i154[339], i154[338], i154[337], i154[336], i154[335], i154[334], i154[333], i154[332], i154[331], i154[330], i154[329], i154[328], i154[327], i154[326], i154[325], i154[324], i154[323], i154[322], i154[321], i154[320], i154[319], i154[318], i154[317], i154[316], i154[315], i154[314], i154[313], i154[312], i154[311], i154[310], i154[309], i154[308], i154[307], i154[306], i154[305], i154[304], i154[303], i154[302], i154[301], i154[300], i154[299], i154[298], i154[297], i154[296], i154[295], i154[294], i154[293], i154[292], i154[291], i154[290], i154[289], i154[288], i154[287], i154[286], i154[285], i154[284], i154[283], i154[282], i154[281], i154[280], i154[279], i154[278], i154[277], i154[276], i154[275], i154[274], i154[273], i154[272], i154[271], i154[270], i154[269], i154[268], i154[267], i154[266], i154[265], i154[264], i154[263], i154[262], i154[261], i154[260], i154[259], i154[258], i154[257], i154[256], i154[255], i154[254], i154[253], i154[252], i154[251], i154[250], i154[249], i154[248], i154[247], i154[246], i154[245], i154[244], i154[243], i154[242], i154[241], i154[240], i154[239], i154[238], i154[237], i154[236], i154[235], i154[234], i154[233], i154[232], i154[231], i154[230], i154[229], i154[228], i154[227], i154[226], i154[225], i154[224], i154[223], i154[222], i154[221], i154[220], i154[219], i154[218], i154[217], i154[216], i154[215], i154[214], i154[213], i154[212], i154[211], i154[210], i154[209], i154[208], i154[207], i154[206], i154[205], i154[204], i154[203], i154[202], i154[201], i154[200], i154[199], i154[198], i154[197], i154[196], i154[195], i154[194], i154[193], i154[192], i154[191], i154[190], i154[189], i154[188], i154[187], i154[186], i154[185], i154[184], i154[183], i154[182], i154[181], i154[180], i154[179], i154[178], i154[177], i154[176], i154[175], i154[174], i154[173], i154[172], i154[171], i154[170], i154[169], i154[168], i154[167], i154[166], i154[165], i154[164], i154[163], i154[162], i154[161], i154[160], i154[159], i154[158], i154[157], i154[156], i154[155], i154[154], i154[153], i154[152], i154[151], i154[150], i154[149], i154[148], i154[147], i154[146], i154[145], i154[144], i154[143], i154[142], i154[141], i154[140], i154[139], i154[138], i154[137], i154[136], i154[135], i154[134], i154[133], i154[132], i154[131], i154[130], i154[129], i154[128], i154[127], i154[126], i154[125], i154[124], i154[123], i154[122], i154[121], i154[120], i154[119], i154[118], i154[117], i154[116], i154[115], i154[114], i154[113], i154[112], i154[111], i154[110], i154[109], i154[108], i154[107], i154[106], i154[105], i154[104], i154[103], i154[102], i154[101], i154[100], i154[99], i154[98], i154[97], i154[96], i154[95], i154[94], i154[93], i154[92], i154[91], i154[90], i154[89], i154[88], i154[87], i154[86], i154[85], i154[84], i154[83], i154[82], i154[81], i154[80], i154[79], i154[78], i154[77], i154[76], i154[75], i154[74], i154[73], i154[72], i154[71], i154[70], i154[69], i154[68], i154[67], i154[66], i154[65], i154[64], i154[63], i154[62], i154[61], i154[60], i154[59], i154[58], i154[57], i154[56], i154[55], i154[54], i154[53], i154[52], i154[51], i154[50], i154[49], i154[48], i154[47], i154[46], i154[45], i154[44], i154[43], i154[42], i154[41], i154[40], i154[39], i154[38], i154[37], i154[36], i154[35], i154[34], i154[33], i154[32], i154[31], i154[30], i154[29], i154[28], i154[27], i154[26], i154[25], i154[24], i154[23], i154[22], i154[21], i154[20], i154[19], i154[18], i154[17], i154[16], i154[15], i154[14], i154[13], i154[12], i154[11], i154[10], i154[9], i154[8], i154[7], i154[6], i154[5], i154[4], i154[3], i154[2], i154[1], i154[0]};
wire [511:0] t2 = {i152[511], i152[510], i152[509], i152[508], i152[507], i152[506], i152[505], i152[504], i152[503], i152[502], i152[501], i152[500], i152[499], i152[498], i152[497], i152[496], i152[495], i152[494], i152[493], i152[492], i152[491], i152[490], i152[489], i152[488], i152[487], i152[486], i152[485], i152[484], i152[483], i152[482], i152[481], i152[480], i152[479], i152[478], i152[477], i152[476], i152[475], i152[474], i152[473], i152[472], i152[471], i152[470], i152[469], i152[468], i152[467], i152[466], i152[465], i152[464], i152[463], i152[462], i152[461], i152[460], i152[459], i152[458], i152[457], i152[456], i152[455], i152[454], i152[453], i152[452], i152[451], i152[450], i152[449], i152[448], i152[447], i152[446], i152[445], i152[444], i152[443], i152[442], i152[441], i152[440], i152[439], i152[438], i152[437], i152[436], i152[435], i152[434], i152[433], i152[432], i152[431], i152[430], i152[429], i152[428], i152[427], i152[426], i152[425], i152[424], i152[423], i152[422], i152[421], i152[420], i152[419], i152[418], i152[417], i152[416], i152[415], i152[414], i152[413], i152[412], i152[411], i152[410], i152[409], i152[408], i152[407], i152[406], i152[405], i152[404], i152[403], i152[402], i152[401], i152[400], i152[399], i152[398], i152[397], i152[396], i152[395], i152[394], i152[393], i152[392], i152[391], i152[390], i152[389], i152[388], i152[387], i152[386], i152[385], i152[384], i152[383], i152[382], i152[381], i152[380], i152[379], i152[378], i152[377], i152[376], i152[375], i152[374], i152[373], i152[372], i152[371], i152[370], i152[369], i152[368], i152[367], i152[366], i152[365], i152[364], i152[363], i152[362], i152[361], i152[360], i152[359], i152[358], i152[357], i152[356], i152[355], i152[354], i152[353], i152[352], i152[351], i152[350], i152[349], i152[348], i152[347], i152[346], i152[345], i152[344], i152[343], i152[342], i152[341], i152[340], i152[339], i152[338], i152[337], i152[336], i152[335], i152[334], i152[333], i152[332], i152[331], i152[330], i152[329], i152[328], i152[327], i152[326], i152[325], i152[324], i152[323], i152[322], i152[321], i152[320], i152[319], i152[318], i152[317], i152[316], i152[315], i152[314], i152[313], i152[312], i152[311], i152[310], i152[309], i152[308], i152[307], i152[306], i152[305], i152[304], i152[303], i152[302], i152[301], i152[300], i152[299], i152[298], i152[297], i152[296], i152[295], i152[294], i152[293], i152[292], i152[291], i152[290], i152[289], i152[288], i152[287], i152[286], i152[285], i152[284], i152[283], i152[282], i152[281], i152[280], i152[279], i152[278], i152[277], i152[276], i152[275], i152[274], i152[273], i152[272], i152[271], i152[270], i152[269], i152[268], i152[267], i152[266], i152[265], i152[264], i152[263], i152[262], i152[261], i152[260], i152[259], i152[258], i152[257], i152[256], i152[255], i152[254], i152[253], i152[252], i152[251], i152[250], i152[249], i152[248], i152[247], i152[246], i152[245], i152[244], i152[243], i152[242], i152[241], i152[240], i152[239], i152[238], i152[237], i152[236], i152[235], i152[234], i152[233], i152[232], i152[231], i152[230], i152[229], i152[228], i152[227], i152[226], i152[225], i152[224], i152[223], i152[222], i152[221], i152[220], i152[219], i152[218], i152[217], i152[216], i152[215], i152[214], i152[213], i152[212], i152[211], i152[210], i152[209], i152[208], i152[207], i152[206], i152[205], i152[204], i152[203], i152[202], i152[201], i152[200], i152[199], i152[198], i152[197], i152[196], i152[195], i152[194], i152[193], i152[192], i152[191], i152[190], i152[189], i152[188], i152[187], i152[186], i152[185], i152[184], i152[183], i152[182], i152[181], i152[180], i152[179], i152[178], i152[177], i152[176], i152[175], i152[174], i152[173], i152[172], i152[171], i152[170], i152[169], i152[168], i152[167], i152[166], i152[165], i152[164], i152[163], i152[162], i152[161], i152[160], i152[159], i152[158], i152[157], i152[156], i152[155], i152[154], i152[153], i152[152], i152[151], i152[150], i152[149], i152[148], i152[147], i152[146], i152[145], i152[144], i152[143], i152[142], i152[141], i152[140], i152[139], i152[138], i152[137], i152[136], i152[135], i152[134], i152[133], i152[132], i152[131], i152[130], i152[129], i152[128], i152[127], i152[126], i152[125], i152[124], i152[123], i152[122], i152[121], i152[120], i152[119], i152[118], i152[117], i152[116], i152[115], i152[114], i152[113], i152[112], i152[111], i152[110], i152[109], i152[108], i152[107], i152[106], i152[105], i152[104], i152[103], i152[102], i152[101], i152[100], i152[99], i152[98], i152[97], i152[96], i152[95], i152[94], i152[93], i152[92], i152[91], i152[90], i152[89], i152[88], i152[87], i152[86], i152[85], i152[84], i152[83], i152[82], i152[81], i152[80], i152[79], i152[78], i152[77], i152[76], i152[75], i152[74], i152[73], i152[72], i152[71], i152[70], i152[69], i152[68], i152[67], i152[66], i152[65], i152[64], i152[63], i152[62], i152[61], i152[60], i152[59], i152[58], i152[57], i152[56], i152[55], i152[54], i152[53], i152[52], i152[51], i152[50], i152[49], i152[48], i152[47], i152[46], i152[45], i152[44], i152[43], i152[42], i152[41], i152[40], i152[39], i152[38], i152[37], i152[36], i152[35], i152[34], i152[33], i152[32], i152[31], i152[30], i152[29], i152[28], i152[27], i152[26], i152[25], i152[24], i152[23], i152[22], i152[21], i152[20], i152[19], i152[18], i152[17], i152[16], i152[15], i152[14], i152[13], i152[12], i152[11], i152[10], i152[9], i152[8], i152[7], i152[6], i152[5], i152[4], i152[3], i152[2], i152[1], i152[0]};
wire [511:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_219_reduce(input wire [257:0] i143, input wire [257:0] i145, input wire [129:0] i227, output wire [257:0] y);
wire [257:0] t0 = {i145[257], i145[256], i145[255], i145[254], i145[253], i145[252], i145[251], i145[250], i145[249], i145[248], i145[247], i145[246], i145[245], i145[244], i145[243], i145[242], i145[241], i145[240], i145[239], i145[238], i145[237], i145[236], i145[235], i145[234], i145[233], i145[232], i145[231], i145[230], i145[229], i145[228], i145[227], i145[226], i145[225], i145[224], i145[223], i145[222], i145[221], i145[220], i145[219], i145[218], i145[217], i145[216], i145[215], i145[214], i145[213], i145[212], i145[211], i145[210], i145[209], i145[208], i145[207], i145[206], i145[205], i145[204], i145[203], i145[202], i145[201], i145[200], i145[199], i145[198], i145[197], i145[196], i145[195], i145[194], i145[193], i145[192], i145[191], i145[190], i145[189], i145[188], i145[187], i145[186], i145[185], i145[184], i145[183], i145[182], i145[181], i145[180], i145[179], i145[178], i145[177], i145[176], i145[175], i145[174], i145[173], i145[172], i145[171], i145[170], i145[169], i145[168], i145[167], i145[166], i145[165], i145[164], i145[163], i145[162], i145[161], i145[160], i145[159], i145[158], i145[157], i145[156], i145[155], i145[154], i145[153], i145[152], i145[151], i145[150], i145[149], i145[148], i145[147], i145[146], i145[145], i145[144], i145[143], i145[142], i145[141], i145[140], i145[139], i145[138], i145[137], i145[136], i145[135], i145[134], i145[133], i145[132], i145[131], i145[130], i145[129], i145[128], i145[127], i145[126], i145[125], i145[124], i145[123], i145[122], i145[121], i145[120], i145[119], i145[118], i145[117], i145[116], i145[115], i145[114], i145[113], i145[112], i145[111], i145[110], i145[109], i145[108], i145[107], i145[106], i145[105], i145[104], i145[103], i145[102], i145[101], i145[100], i145[99], i145[98], i145[97], i145[96], i145[95], i145[94], i145[93], i145[92], i145[91], i145[90], i145[89], i145[88], i145[87], i145[86], i145[85], i145[84], i145[83], i145[82], i145[81], i145[80], i145[79], i145[78], i145[77], i145[76], i145[75], i145[74], i145[73], i145[72], i145[71], i145[70], i145[69], i145[68], i145[67], i145[66], i145[65], i145[64], i145[63], i145[62], i145[61], i145[60], i145[59], i145[58], i145[57], i145[56], i145[55], i145[54], i145[53], i145[52], i145[51], i145[50], i145[49], i145[48], i145[47], i145[46], i145[45], i145[44], i145[43], i145[42], i145[41], i145[40], i145[39], i145[38], i145[37], i145[36], i145[35], i145[34], i145[33], i145[32], i145[31], i145[30], i145[29], i145[28], i145[27], i145[26], i145[25], i145[24], i145[23], i145[22], i145[21], i145[20], i145[19], i145[18], i145[17], i145[16], i145[15], i145[14], i145[13], i145[12], i145[11], i145[10], i145[9], i145[8], i145[7], i145[6], i145[5], i145[4], i145[3], i145[2], i145[1], i145[0]};
wire [257:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i227[129], i227[128], i227[127], i227[126], i227[125], i227[124], i227[123], i227[122], i227[121], i227[120], i227[119], i227[118], i227[117], i227[116], i227[115], i227[114], i227[113], i227[112], i227[111], i227[110], i227[109], i227[108], i227[107], i227[106], i227[105], i227[104], i227[103], i227[102], i227[101], i227[100], i227[99], i227[98], i227[97], i227[96], i227[95], i227[94], i227[93], i227[92], i227[91], i227[90], i227[89], i227[88], i227[87], i227[86], i227[85], i227[84], i227[83], i227[82], i227[81], i227[80], i227[79], i227[78], i227[77], i227[76], i227[75], i227[74], i227[73], i227[72], i227[71], i227[70], i227[69], i227[68], i227[67], i227[66], i227[65], i227[64], i227[63], i227[62], i227[61], i227[60], i227[59], i227[58], i227[57], i227[56], i227[55], i227[54], i227[53], i227[52], i227[51], i227[50], i227[49], i227[48], i227[47], i227[46], i227[45], i227[44], i227[43], i227[42], i227[41], i227[40], i227[39], i227[38], i227[37], i227[36], i227[35], i227[34], i227[33], i227[32], i227[31], i227[30], i227[29], i227[28], i227[27], i227[26], i227[25], i227[24], i227[23], i227[22], i227[21], i227[20], i227[19], i227[18], i227[17], i227[16], i227[15], i227[14], i227[13], i227[12], i227[11], i227[10], i227[9], i227[8], i227[7], i227[6], i227[5], i227[4], i227[3], i227[2], i227[1], i227[0]};
wire [257:0] t2 = {i143[257], i143[256], i143[255], i143[254], i143[253], i143[252], i143[251], i143[250], i143[249], i143[248], i143[247], i143[246], i143[245], i143[244], i143[243], i143[242], i143[241], i143[240], i143[239], i143[238], i143[237], i143[236], i143[235], i143[234], i143[233], i143[232], i143[231], i143[230], i143[229], i143[228], i143[227], i143[226], i143[225], i143[224], i143[223], i143[222], i143[221], i143[220], i143[219], i143[218], i143[217], i143[216], i143[215], i143[214], i143[213], i143[212], i143[211], i143[210], i143[209], i143[208], i143[207], i143[206], i143[205], i143[204], i143[203], i143[202], i143[201], i143[200], i143[199], i143[198], i143[197], i143[196], i143[195], i143[194], i143[193], i143[192], i143[191], i143[190], i143[189], i143[188], i143[187], i143[186], i143[185], i143[184], i143[183], i143[182], i143[181], i143[180], i143[179], i143[178], i143[177], i143[176], i143[175], i143[174], i143[173], i143[172], i143[171], i143[170], i143[169], i143[168], i143[167], i143[166], i143[165], i143[164], i143[163], i143[162], i143[161], i143[160], i143[159], i143[158], i143[157], i143[156], i143[155], i143[154], i143[153], i143[152], i143[151], i143[150], i143[149], i143[148], i143[147], i143[146], i143[145], i143[144], i143[143], i143[142], i143[141], i143[140], i143[139], i143[138], i143[137], i143[136], i143[135], i143[134], i143[133], i143[132], i143[131], i143[130], i143[129], i143[128], i143[127], i143[126], i143[125], i143[124], i143[123], i143[122], i143[121], i143[120], i143[119], i143[118], i143[117], i143[116], i143[115], i143[114], i143[113], i143[112], i143[111], i143[110], i143[109], i143[108], i143[107], i143[106], i143[105], i143[104], i143[103], i143[102], i143[101], i143[100], i143[99], i143[98], i143[97], i143[96], i143[95], i143[94], i143[93], i143[92], i143[91], i143[90], i143[89], i143[88], i143[87], i143[86], i143[85], i143[84], i143[83], i143[82], i143[81], i143[80], i143[79], i143[78], i143[77], i143[76], i143[75], i143[74], i143[73], i143[72], i143[71], i143[70], i143[69], i143[68], i143[67], i143[66], i143[65], i143[64], i143[63], i143[62], i143[61], i143[60], i143[59], i143[58], i143[57], i143[56], i143[55], i143[54], i143[53], i143[52], i143[51], i143[50], i143[49], i143[48], i143[47], i143[46], i143[45], i143[44], i143[43], i143[42], i143[41], i143[40], i143[39], i143[38], i143[37], i143[36], i143[35], i143[34], i143[33], i143[32], i143[31], i143[30], i143[29], i143[28], i143[27], i143[26], i143[25], i143[24], i143[23], i143[22], i143[21], i143[20], i143[19], i143[18], i143[17], i143[16], i143[15], i143[14], i143[13], i143[12], i143[11], i143[10], i143[9], i143[8], i143[7], i143[6], i143[5], i143[4], i143[3], i143[2], i143[1], i143[0]};
wire [257:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_223_reduce(input wire [255:0] i43, input wire [255:0] i880, input wire [255:0] i886, output wire [255:0] y);
wire [255:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i880[127], i880[126], i880[125], i880[124], i880[123], i880[122], i880[121], i880[120], i880[119], i880[118], i880[117], i880[116], i880[115], i880[114], i880[113], i880[112], i880[111], i880[110], i880[109], i880[108], i880[107], i880[106], i880[105], i880[104], i880[103], i880[102], i880[101], i880[100], i880[99], i880[98], i880[97], i880[96], i880[95], i880[94], i880[93], i880[92], i880[91], i880[90], i880[89], i880[88], i880[87], i880[86], i880[85], i880[84], i880[83], i880[82], i880[81], i880[80], i880[79], i880[78], i880[77], i880[76], i880[75], i880[74], i880[73], i880[72], i880[71], i880[70], i880[69], i880[68], i880[67], i880[66], i880[65], i880[64], i880[63], i880[62], i880[61], i880[60], i880[59], i880[58], i880[57], i880[56], i880[55], i880[54], i880[53], i880[52], i880[51], i880[50], i880[49], i880[48], i880[47], i880[46], i880[45], i880[44], i880[43], i880[42], i880[41], i880[40], i880[39], i880[38], i880[37], i880[36], i880[35], i880[34], i880[33], i880[32], i880[31], i880[30], i880[29], i880[28], i880[27], i880[26], i880[25], i880[24], i880[23], i880[22], i880[21], i880[20], i880[19], i880[18], i880[17], i880[16], i880[15], i880[14], i880[13], i880[12], i880[11], i880[10], i880[9], i880[8], i880[7], i880[6], i880[5], i880[4], i880[3], i880[2], i880[1], i880[0]};
wire [255:0] t1 = {i886[255], i886[254], i886[253], i886[252], i886[251], i886[250], i886[249], i886[248], i886[247], i886[246], i886[245], i886[244], i886[243], i886[242], i886[241], i886[240], i886[239], i886[238], i886[237], i886[236], i886[235], i886[234], i886[233], i886[232], i886[231], i886[230], i886[229], i886[228], i886[227], i886[226], i886[225], i886[224], i886[223], i886[222], i886[221], i886[220], i886[219], i886[218], i886[217], i886[216], i886[215], i886[214], i886[213], i886[212], i886[211], i886[210], i886[209], i886[208], i886[207], i886[206], i886[205], i886[204], i886[203], i886[202], i886[201], i886[200], i886[199], i886[198], i886[197], i886[196], i886[195], i886[194], i886[193], i886[192], i886[191], i886[190], i886[189], i886[188], i886[187], i886[186], i886[185], i886[184], i886[183], i886[182], i886[181], i886[180], i886[179], i886[178], i886[177], i886[176], i886[175], i886[174], i886[173], i886[172], i886[171], i886[170], i886[169], i886[168], i886[167], i886[166], i886[165], i886[164], i886[163], i886[162], i886[161], i886[160], i886[159], i886[158], i886[157], i886[156], i886[155], i886[154], i886[153], i886[152], i886[151], i886[150], i886[149], i886[148], i886[147], i886[146], i886[145], i886[144], i886[143], i886[142], i886[141], i886[140], i886[139], i886[138], i886[137], i886[136], i886[135], i886[134], i886[133], i886[132], i886[131], i886[130], i886[129], i886[128], i886[127], i886[126], i886[125], i886[124], i886[123], i886[122], i886[121], i886[120], i886[119], i886[118], i886[117], i886[116], i886[115], i886[114], i886[113], i886[112], i886[111], i886[110], i886[109], i886[108], i886[107], i886[106], i886[105], i886[104], i886[103], i886[102], i886[101], i886[100], i886[99], i886[98], i886[97], i886[96], i886[95], i886[94], i886[93], i886[92], i886[91], i886[90], i886[89], i886[88], i886[87], i886[86], i886[85], i886[84], i886[83], i886[82], i886[81], i886[80], i886[79], i886[78], i886[77], i886[76], i886[75], i886[74], i886[73], i886[72], i886[71], i886[70], i886[69], i886[68], i886[67], i886[66], i886[65], i886[64], i886[63], i886[62], i886[61], i886[60], i886[59], i886[58], i886[57], i886[56], i886[55], i886[54], i886[53], i886[52], i886[51], i886[50], i886[49], i886[48], i886[47], i886[46], i886[45], i886[44], i886[43], i886[42], i886[41], i886[40], i886[39], i886[38], i886[37], i886[36], i886[35], i886[34], i886[33], i886[32], i886[31], i886[30], i886[29], i886[28], i886[27], i886[26], i886[25], i886[24], i886[23], i886[22], i886[21], i886[20], i886[19], i886[18], i886[17], i886[16], i886[15], i886[14], i886[13], i886[12], i886[11], i886[10], i886[9], i886[8], i886[7], i886[6], i886[5], i886[4], i886[3], i886[2], i886[1], i886[0]};
wire [255:0] t2 = {i43[255], i43[254], i43[253], i43[252], i43[251], i43[250], i43[249], i43[248], i43[247], i43[246], i43[245], i43[244], i43[243], i43[242], i43[241], i43[240], i43[239], i43[238], i43[237], i43[236], i43[235], i43[234], i43[233], i43[232], i43[231], i43[230], i43[229], i43[228], i43[227], i43[226], i43[225], i43[224], i43[223], i43[222], i43[221], i43[220], i43[219], i43[218], i43[217], i43[216], i43[215], i43[214], i43[213], i43[212], i43[211], i43[210], i43[209], i43[208], i43[207], i43[206], i43[205], i43[204], i43[203], i43[202], i43[201], i43[200], i43[199], i43[198], i43[197], i43[196], i43[195], i43[194], i43[193], i43[192], i43[191], i43[190], i43[189], i43[188], i43[187], i43[186], i43[185], i43[184], i43[183], i43[182], i43[181], i43[180], i43[179], i43[178], i43[177], i43[176], i43[175], i43[174], i43[173], i43[172], i43[171], i43[170], i43[169], i43[168], i43[167], i43[166], i43[165], i43[164], i43[163], i43[162], i43[161], i43[160], i43[159], i43[158], i43[157], i43[156], i43[155], i43[154], i43[153], i43[152], i43[151], i43[150], i43[149], i43[148], i43[147], i43[146], i43[145], i43[144], i43[143], i43[142], i43[141], i43[140], i43[139], i43[138], i43[137], i43[136], i43[135], i43[134], i43[133], i43[132], i43[131], i43[130], i43[129], i43[128], i43[127], i43[126], i43[125], i43[124], i43[123], i43[122], i43[121], i43[120], i43[119], i43[118], i43[117], i43[116], i43[115], i43[114], i43[113], i43[112], i43[111], i43[110], i43[109], i43[108], i43[107], i43[106], i43[105], i43[104], i43[103], i43[102], i43[101], i43[100], i43[99], i43[98], i43[97], i43[96], i43[95], i43[94], i43[93], i43[92], i43[91], i43[90], i43[89], i43[88], i43[87], i43[86], i43[85], i43[84], i43[83], i43[82], i43[81], i43[80], i43[79], i43[78], i43[77], i43[76], i43[75], i43[74], i43[73], i43[72], i43[71], i43[70], i43[69], i43[68], i43[67], i43[66], i43[65], i43[64], i43[63], i43[62], i43[61], i43[60], i43[59], i43[58], i43[57], i43[56], i43[55], i43[54], i43[53], i43[52], i43[51], i43[50], i43[49], i43[48], i43[47], i43[46], i43[45], i43[44], i43[43], i43[42], i43[41], i43[40], i43[39], i43[38], i43[37], i43[36], i43[35], i43[34], i43[33], i43[32], i43[31], i43[30], i43[29], i43[28], i43[27], i43[26], i43[25], i43[24], i43[23], i43[22], i43[21], i43[20], i43[19], i43[18], i43[17], i43[16], i43[15], i43[14], i43[13], i43[12], i43[11], i43[10], i43[9], i43[8], i43[7], i43[6], i43[5], i43[4], i43[3], i43[2], i43[1], i43[0]};
wire [255:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_225_reduce(input wire [131:0] i134, input wire [131:0] i136, input wire [131:0] i917, output wire [131:0] y);
wire [131:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i917[65], i917[64], i917[63], i917[62], i917[61], i917[60], i917[59], i917[58], i917[57], i917[56], i917[55], i917[54], i917[53], i917[52], i917[51], i917[50], i917[49], i917[48], i917[47], i917[46], i917[45], i917[44], i917[43], i917[42], i917[41], i917[40], i917[39], i917[38], i917[37], i917[36], i917[35], i917[34], i917[33], i917[32], i917[31], i917[30], i917[29], i917[28], i917[27], i917[26], i917[25], i917[24], i917[23], i917[22], i917[21], i917[20], i917[19], i917[18], i917[17], i917[16], i917[15], i917[14], i917[13], i917[12], i917[11], i917[10], i917[9], i917[8], i917[7], i917[6], i917[5], i917[4], i917[3], i917[2], i917[1], i917[0]};
wire [131:0] t1 = {i136[131], i136[130], i136[129], i136[128], i136[127], i136[126], i136[125], i136[124], i136[123], i136[122], i136[121], i136[120], i136[119], i136[118], i136[117], i136[116], i136[115], i136[114], i136[113], i136[112], i136[111], i136[110], i136[109], i136[108], i136[107], i136[106], i136[105], i136[104], i136[103], i136[102], i136[101], i136[100], i136[99], i136[98], i136[97], i136[96], i136[95], i136[94], i136[93], i136[92], i136[91], i136[90], i136[89], i136[88], i136[87], i136[86], i136[85], i136[84], i136[83], i136[82], i136[81], i136[80], i136[79], i136[78], i136[77], i136[76], i136[75], i136[74], i136[73], i136[72], i136[71], i136[70], i136[69], i136[68], i136[67], i136[66], i136[65], i136[64], i136[63], i136[62], i136[61], i136[60], i136[59], i136[58], i136[57], i136[56], i136[55], i136[54], i136[53], i136[52], i136[51], i136[50], i136[49], i136[48], i136[47], i136[46], i136[45], i136[44], i136[43], i136[42], i136[41], i136[40], i136[39], i136[38], i136[37], i136[36], i136[35], i136[34], i136[33], i136[32], i136[31], i136[30], i136[29], i136[28], i136[27], i136[26], i136[25], i136[24], i136[23], i136[22], i136[21], i136[20], i136[19], i136[18], i136[17], i136[16], i136[15], i136[14], i136[13], i136[12], i136[11], i136[10], i136[9], i136[8], i136[7], i136[6], i136[5], i136[4], i136[3], i136[2], i136[1], i136[0]};
wire [131:0] t2 = {i134[131], i134[130], i134[129], i134[128], i134[127], i134[126], i134[125], i134[124], i134[123], i134[122], i134[121], i134[120], i134[119], i134[118], i134[117], i134[116], i134[115], i134[114], i134[113], i134[112], i134[111], i134[110], i134[109], i134[108], i134[107], i134[106], i134[105], i134[104], i134[103], i134[102], i134[101], i134[100], i134[99], i134[98], i134[97], i134[96], i134[95], i134[94], i134[93], i134[92], i134[91], i134[90], i134[89], i134[88], i134[87], i134[86], i134[85], i134[84], i134[83], i134[82], i134[81], i134[80], i134[79], i134[78], i134[77], i134[76], i134[75], i134[74], i134[73], i134[72], i134[71], i134[70], i134[69], i134[68], i134[67], i134[66], i134[65], i134[64], i134[63], i134[62], i134[61], i134[60], i134[59], i134[58], i134[57], i134[56], i134[55], i134[54], i134[53], i134[52], i134[51], i134[50], i134[49], i134[48], i134[47], i134[46], i134[45], i134[44], i134[43], i134[42], i134[41], i134[40], i134[39], i134[38], i134[37], i134[36], i134[35], i134[34], i134[33], i134[32], i134[31], i134[30], i134[29], i134[28], i134[27], i134[26], i134[25], i134[24], i134[23], i134[22], i134[21], i134[20], i134[19], i134[18], i134[17], i134[16], i134[15], i134[14], i134[13], i134[12], i134[11], i134[10], i134[9], i134[8], i134[7], i134[6], i134[5], i134[4], i134[3], i134[2], i134[1], i134[0]};
wire [131:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_227_reduce(input wire [129:0] i108, input wire [129:0] i110, input wire [129:0] i909, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i909[65], i909[64], i909[63], i909[62], i909[61], i909[60], i909[59], i909[58], i909[57], i909[56], i909[55], i909[54], i909[53], i909[52], i909[51], i909[50], i909[49], i909[48], i909[47], i909[46], i909[45], i909[44], i909[43], i909[42], i909[41], i909[40], i909[39], i909[38], i909[37], i909[36], i909[35], i909[34], i909[33], i909[32], i909[31], i909[30], i909[29], i909[28], i909[27], i909[26], i909[25], i909[24], i909[23], i909[22], i909[21], i909[20], i909[19], i909[18], i909[17], i909[16], i909[15], i909[14], i909[13], i909[12], i909[11], i909[10], i909[9], i909[8], i909[7], i909[6], i909[5], i909[4], i909[3], i909[2], i909[1], i909[0]};
wire [129:0] t1 = {i110[129], i110[128], i110[127], i110[126], i110[125], i110[124], i110[123], i110[122], i110[121], i110[120], i110[119], i110[118], i110[117], i110[116], i110[115], i110[114], i110[113], i110[112], i110[111], i110[110], i110[109], i110[108], i110[107], i110[106], i110[105], i110[104], i110[103], i110[102], i110[101], i110[100], i110[99], i110[98], i110[97], i110[96], i110[95], i110[94], i110[93], i110[92], i110[91], i110[90], i110[89], i110[88], i110[87], i110[86], i110[85], i110[84], i110[83], i110[82], i110[81], i110[80], i110[79], i110[78], i110[77], i110[76], i110[75], i110[74], i110[73], i110[72], i110[71], i110[70], i110[69], i110[68], i110[67], i110[66], i110[65], i110[64], i110[63], i110[62], i110[61], i110[60], i110[59], i110[58], i110[57], i110[56], i110[55], i110[54], i110[53], i110[52], i110[51], i110[50], i110[49], i110[48], i110[47], i110[46], i110[45], i110[44], i110[43], i110[42], i110[41], i110[40], i110[39], i110[38], i110[37], i110[36], i110[35], i110[34], i110[33], i110[32], i110[31], i110[30], i110[29], i110[28], i110[27], i110[26], i110[25], i110[24], i110[23], i110[22], i110[21], i110[20], i110[19], i110[18], i110[17], i110[16], i110[15], i110[14], i110[13], i110[12], i110[11], i110[10], i110[9], i110[8], i110[7], i110[6], i110[5], i110[4], i110[3], i110[2], i110[1], i110[0]};
wire [129:0] t2 = {i108[129], i108[128], i108[127], i108[126], i108[125], i108[124], i108[123], i108[122], i108[121], i108[120], i108[119], i108[118], i108[117], i108[116], i108[115], i108[114], i108[113], i108[112], i108[111], i108[110], i108[109], i108[108], i108[107], i108[106], i108[105], i108[104], i108[103], i108[102], i108[101], i108[100], i108[99], i108[98], i108[97], i108[96], i108[95], i108[94], i108[93], i108[92], i108[91], i108[90], i108[89], i108[88], i108[87], i108[86], i108[85], i108[84], i108[83], i108[82], i108[81], i108[80], i108[79], i108[78], i108[77], i108[76], i108[75], i108[74], i108[73], i108[72], i108[71], i108[70], i108[69], i108[68], i108[67], i108[66], i108[65], i108[64], i108[63], i108[62], i108[61], i108[60], i108[59], i108[58], i108[57], i108[56], i108[55], i108[54], i108[53], i108[52], i108[51], i108[50], i108[49], i108[48], i108[47], i108[46], i108[45], i108[44], i108[43], i108[42], i108[41], i108[40], i108[39], i108[38], i108[37], i108[36], i108[35], i108[34], i108[33], i108[32], i108[31], i108[30], i108[29], i108[28], i108[27], i108[26], i108[25], i108[24], i108[23], i108[22], i108[21], i108[20], i108[19], i108[18], i108[17], i108[16], i108[15], i108[14], i108[13], i108[12], i108[11], i108[10], i108[9], i108[8], i108[7], i108[6], i108[5], i108[4], i108[3], i108[2], i108[1], i108[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_229_reduce(input wire [129:0] i72, input wire [129:0] i74, input wire [67:0] i536, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i536[65], i536[64], i536[63], i536[62], i536[61], i536[60], i536[59], i536[58], i536[57], i536[56], i536[55], i536[54], i536[53], i536[52], i536[51], i536[50], i536[49], i536[48], i536[47], i536[46], i536[45], i536[44], i536[43], i536[42], i536[41], i536[40], i536[39], i536[38], i536[37], i536[36], i536[35], i536[34], i536[33], i536[32], i536[31], i536[30], i536[29], i536[28], i536[27], i536[26], i536[25], i536[24], i536[23], i536[22], i536[21], i536[20], i536[19], i536[18], i536[17], i536[16], i536[15], i536[14], i536[13], i536[12], i536[11], i536[10], i536[9], i536[8], i536[7], i536[6], i536[5], i536[4], i536[3], i536[2], i536[1], i536[0]};
wire [129:0] t1 = {i74[129], i74[128], i74[127], i74[126], i74[125], i74[124], i74[123], i74[122], i74[121], i74[120], i74[119], i74[118], i74[117], i74[116], i74[115], i74[114], i74[113], i74[112], i74[111], i74[110], i74[109], i74[108], i74[107], i74[106], i74[105], i74[104], i74[103], i74[102], i74[101], i74[100], i74[99], i74[98], i74[97], i74[96], i74[95], i74[94], i74[93], i74[92], i74[91], i74[90], i74[89], i74[88], i74[87], i74[86], i74[85], i74[84], i74[83], i74[82], i74[81], i74[80], i74[79], i74[78], i74[77], i74[76], i74[75], i74[74], i74[73], i74[72], i74[71], i74[70], i74[69], i74[68], i74[67], i74[66], i74[65], i74[64], i74[63], i74[62], i74[61], i74[60], i74[59], i74[58], i74[57], i74[56], i74[55], i74[54], i74[53], i74[52], i74[51], i74[50], i74[49], i74[48], i74[47], i74[46], i74[45], i74[44], i74[43], i74[42], i74[41], i74[40], i74[39], i74[38], i74[37], i74[36], i74[35], i74[34], i74[33], i74[32], i74[31], i74[30], i74[29], i74[28], i74[27], i74[26], i74[25], i74[24], i74[23], i74[22], i74[21], i74[20], i74[19], i74[18], i74[17], i74[16], i74[15], i74[14], i74[13], i74[12], i74[11], i74[10], i74[9], i74[8], i74[7], i74[6], i74[5], i74[4], i74[3], i74[2], i74[1], i74[0]};
wire [129:0] t2 = {i72[129], i72[128], i72[127], i72[126], i72[125], i72[124], i72[123], i72[122], i72[121], i72[120], i72[119], i72[118], i72[117], i72[116], i72[115], i72[114], i72[113], i72[112], i72[111], i72[110], i72[109], i72[108], i72[107], i72[106], i72[105], i72[104], i72[103], i72[102], i72[101], i72[100], i72[99], i72[98], i72[97], i72[96], i72[95], i72[94], i72[93], i72[92], i72[91], i72[90], i72[89], i72[88], i72[87], i72[86], i72[85], i72[84], i72[83], i72[82], i72[81], i72[80], i72[79], i72[78], i72[77], i72[76], i72[75], i72[74], i72[73], i72[72], i72[71], i72[70], i72[69], i72[68], i72[67], i72[66], i72[65], i72[64], i72[63], i72[62], i72[61], i72[60], i72[59], i72[58], i72[57], i72[56], i72[55], i72[54], i72[53], i72[52], i72[51], i72[50], i72[49], i72[48], i72[47], i72[46], i72[45], i72[44], i72[43], i72[42], i72[41], i72[40], i72[39], i72[38], i72[37], i72[36], i72[35], i72[34], i72[33], i72[32], i72[31], i72[30], i72[29], i72[28], i72[27], i72[26], i72[25], i72[24], i72[23], i72[22], i72[21], i72[20], i72[19], i72[18], i72[17], i72[16], i72[15], i72[14], i72[13], i72[12], i72[11], i72[10], i72[9], i72[8], i72[7], i72[6], i72[5], i72[4], i72[3], i72[2], i72[1], i72[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_231_reduce(input wire [129:0] i34, input wire [129:0] i36, input wire [67:0] i890, output wire [129:0] y);
wire [129:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i890[65], i890[64], i890[63], i890[62], i890[61], i890[60], i890[59], i890[58], i890[57], i890[56], i890[55], i890[54], i890[53], i890[52], i890[51], i890[50], i890[49], i890[48], i890[47], i890[46], i890[45], i890[44], i890[43], i890[42], i890[41], i890[40], i890[39], i890[38], i890[37], i890[36], i890[35], i890[34], i890[33], i890[32], i890[31], i890[30], i890[29], i890[28], i890[27], i890[26], i890[25], i890[24], i890[23], i890[22], i890[21], i890[20], i890[19], i890[18], i890[17], i890[16], i890[15], i890[14], i890[13], i890[12], i890[11], i890[10], i890[9], i890[8], i890[7], i890[6], i890[5], i890[4], i890[3], i890[2], i890[1], i890[0]};
wire [129:0] t1 = {i36[129], i36[128], i36[127], i36[126], i36[125], i36[124], i36[123], i36[122], i36[121], i36[120], i36[119], i36[118], i36[117], i36[116], i36[115], i36[114], i36[113], i36[112], i36[111], i36[110], i36[109], i36[108], i36[107], i36[106], i36[105], i36[104], i36[103], i36[102], i36[101], i36[100], i36[99], i36[98], i36[97], i36[96], i36[95], i36[94], i36[93], i36[92], i36[91], i36[90], i36[89], i36[88], i36[87], i36[86], i36[85], i36[84], i36[83], i36[82], i36[81], i36[80], i36[79], i36[78], i36[77], i36[76], i36[75], i36[74], i36[73], i36[72], i36[71], i36[70], i36[69], i36[68], i36[67], i36[66], i36[65], i36[64], i36[63], i36[62], i36[61], i36[60], i36[59], i36[58], i36[57], i36[56], i36[55], i36[54], i36[53], i36[52], i36[51], i36[50], i36[49], i36[48], i36[47], i36[46], i36[45], i36[44], i36[43], i36[42], i36[41], i36[40], i36[39], i36[38], i36[37], i36[36], i36[35], i36[34], i36[33], i36[32], i36[31], i36[30], i36[29], i36[28], i36[27], i36[26], i36[25], i36[24], i36[23], i36[22], i36[21], i36[20], i36[19], i36[18], i36[17], i36[16], i36[15], i36[14], i36[13], i36[12], i36[11], i36[10], i36[9], i36[8], i36[7], i36[6], i36[5], i36[4], i36[3], i36[2], i36[1], i36[0]};
wire [129:0] t2 = {i34[129], i34[128], i34[127], i34[126], i34[125], i34[124], i34[123], i34[122], i34[121], i34[120], i34[119], i34[118], i34[117], i34[116], i34[115], i34[114], i34[113], i34[112], i34[111], i34[110], i34[109], i34[108], i34[107], i34[106], i34[105], i34[104], i34[103], i34[102], i34[101], i34[100], i34[99], i34[98], i34[97], i34[96], i34[95], i34[94], i34[93], i34[92], i34[91], i34[90], i34[89], i34[88], i34[87], i34[86], i34[85], i34[84], i34[83], i34[82], i34[81], i34[80], i34[79], i34[78], i34[77], i34[76], i34[75], i34[74], i34[73], i34[72], i34[71], i34[70], i34[69], i34[68], i34[67], i34[66], i34[65], i34[64], i34[63], i34[62], i34[61], i34[60], i34[59], i34[58], i34[57], i34[56], i34[55], i34[54], i34[53], i34[52], i34[51], i34[50], i34[49], i34[48], i34[47], i34[46], i34[45], i34[44], i34[43], i34[42], i34[41], i34[40], i34[39], i34[38], i34[37], i34[36], i34[35], i34[34], i34[33], i34[32], i34[31], i34[30], i34[29], i34[28], i34[27], i34[26], i34[25], i34[24], i34[23], i34[22], i34[21], i34[20], i34[19], i34[18], i34[17], i34[16], i34[15], i34[14], i34[13], i34[12], i34[11], i34[10], i34[9], i34[8], i34[7], i34[6], i34[5], i34[4], i34[3], i34[2], i34[1], i34[0]};
wire [129:0] sum = t0 + t1 + t2;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_433_reduce(input wire [63:0] i412, input wire [32:0] i415, input wire [32:0] i419, input wire [1:0] i423, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i412[63], i412[62], i412[61], i412[60], i412[59], i412[58], i412[57], i412[56], i412[55], i412[54], i412[53], i412[52], i412[51], i412[50], i412[49], i412[48], i412[47], i412[46], i412[45], i412[44], i412[43], i412[42], i412[41], i412[40], i412[39], i412[38], i412[37], i412[36], i412[35], i412[34], i412[33], i412[32], i412[31], i412[30], i412[29], i412[28], i412[27], i412[26], i412[25], i412[24], i412[23], i412[22], i412[21], i412[20], i412[19], i412[18], i412[17], i412[16], i412[15], i412[14], i412[13], i412[12], i412[11], i412[10], i412[9], i412[8], i412[7], i412[6], i412[5], i412[4], i412[3], i412[2], i412[1], i412[0]};
wire [65:0] t1 = {1'b0, i415[32], i415[31], i415[30], i415[29], i415[28], i415[27], i415[26], i415[25], i415[24], i415[23], i415[22], i415[21], i415[20], i415[19], i415[18], i415[17], i415[16], i415[15], i415[14], i415[13], i415[12], i415[11], i415[10], i415[9], i415[8], i415[7], i415[6], i415[5], i415[4], i415[3], i415[2], i415[1], i415[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i419[32], i419[31], i419[30], i419[29], i419[28], i419[27], i419[26], i419[25], i419[24], i419[23], i419[22], i419[21], i419[20], i419[19], i419[18], i419[17], i419[16], i419[15], i419[14], i419[13], i419[12], i419[11], i419[10], i419[9], i419[8], i419[7], i419[6], i419[5], i419[4], i419[3], i419[2], i419[1], i419[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i423[1], i423[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_461_reduce(input wire [63:0] i440, input wire [33:0] i443, input wire [33:0] i447, input wire [3:0] i451, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i440[63], i440[62], i440[61], i440[60], i440[59], i440[58], i440[57], i440[56], i440[55], i440[54], i440[53], i440[52], i440[51], i440[50], i440[49], i440[48], i440[47], i440[46], i440[45], i440[44], i440[43], i440[42], i440[41], i440[40], i440[39], i440[38], i440[37], i440[36], i440[35], i440[34], i440[33], i440[32], i440[31], i440[30], i440[29], i440[28], i440[27], i440[26], i440[25], i440[24], i440[23], i440[22], i440[21], i440[20], i440[19], i440[18], i440[17], i440[16], i440[15], i440[14], i440[13], i440[12], i440[11], i440[10], i440[9], i440[8], i440[7], i440[6], i440[5], i440[4], i440[3], i440[2], i440[1], i440[0]};
wire [67:0] t1 = {1'b0, 1'b0, i443[33], i443[32], i443[31], i443[30], i443[29], i443[28], i443[27], i443[26], i443[25], i443[24], i443[23], i443[22], i443[21], i443[20], i443[19], i443[18], i443[17], i443[16], i443[15], i443[14], i443[13], i443[12], i443[11], i443[10], i443[9], i443[8], i443[7], i443[6], i443[5], i443[4], i443[3], i443[2], i443[1], i443[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i447[33], i447[32], i447[31], i447[30], i447[29], i447[28], i447[27], i447[26], i447[25], i447[24], i447[23], i447[22], i447[21], i447[20], i447[19], i447[18], i447[17], i447[16], i447[15], i447[14], i447[13], i447[12], i447[11], i447[10], i447[9], i447[8], i447[7], i447[6], i447[5], i447[4], i447[3], i447[2], i447[1], i447[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i451[3], i451[2], i451[1], i451[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_486_reduce(input wire [63:0] i465, input wire [63:0] i468, input wire [63:0] i472, input wire [63:0] i476, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i465[63], i465[62], i465[61], i465[60], i465[59], i465[58], i465[57], i465[56], i465[55], i465[54], i465[53], i465[52], i465[51], i465[50], i465[49], i465[48], i465[47], i465[46], i465[45], i465[44], i465[43], i465[42], i465[41], i465[40], i465[39], i465[38], i465[37], i465[36], i465[35], i465[34], i465[33], i465[32], i465[31], i465[30], i465[29], i465[28], i465[27], i465[26], i465[25], i465[24], i465[23], i465[22], i465[21], i465[20], i465[19], i465[18], i465[17], i465[16], i465[15], i465[14], i465[13], i465[12], i465[11], i465[10], i465[9], i465[8], i465[7], i465[6], i465[5], i465[4], i465[3], i465[2], i465[1], i465[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i468[63], i468[62], i468[61], i468[60], i468[59], i468[58], i468[57], i468[56], i468[55], i468[54], i468[53], i468[52], i468[51], i468[50], i468[49], i468[48], i468[47], i468[46], i468[45], i468[44], i468[43], i468[42], i468[41], i468[40], i468[39], i468[38], i468[37], i468[36], i468[35], i468[34], i468[33], i468[32], i468[31], i468[30], i468[29], i468[28], i468[27], i468[26], i468[25], i468[24], i468[23], i468[22], i468[21], i468[20], i468[19], i468[18], i468[17], i468[16], i468[15], i468[14], i468[13], i468[12], i468[11], i468[10], i468[9], i468[8], i468[7], i468[6], i468[5], i468[4], i468[3], i468[2], i468[1], i468[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i472[63], i472[62], i472[61], i472[60], i472[59], i472[58], i472[57], i472[56], i472[55], i472[54], i472[53], i472[52], i472[51], i472[50], i472[49], i472[48], i472[47], i472[46], i472[45], i472[44], i472[43], i472[42], i472[41], i472[40], i472[39], i472[38], i472[37], i472[36], i472[35], i472[34], i472[33], i472[32], i472[31], i472[30], i472[29], i472[28], i472[27], i472[26], i472[25], i472[24], i472[23], i472[22], i472[21], i472[20], i472[19], i472[18], i472[17], i472[16], i472[15], i472[14], i472[13], i472[12], i472[11], i472[10], i472[9], i472[8], i472[7], i472[6], i472[5], i472[4], i472[3], i472[2], i472[1], i472[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i476[63], i476[62], i476[61], i476[60], i476[59], i476[58], i476[57], i476[56], i476[55], i476[54], i476[53], i476[52], i476[51], i476[50], i476[49], i476[48], i476[47], i476[46], i476[45], i476[44], i476[43], i476[42], i476[41], i476[40], i476[39], i476[38], i476[37], i476[36], i476[35], i476[34], i476[33], i476[32], i476[31], i476[30], i476[29], i476[28], i476[27], i476[26], i476[25], i476[24], i476[23], i476[22], i476[21], i476[20], i476[19], i476[18], i476[17], i476[16], i476[15], i476[14], i476[13], i476[12], i476[11], i476[10], i476[9], i476[8], i476[7], i476[6], i476[5], i476[4], i476[3], i476[2], i476[1], i476[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_536_reduce(input wire [63:0] i515, input wire [32:0] i518, input wire [32:0] i522, input wire [1:0] i526, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i515[63], i515[62], i515[61], i515[60], i515[59], i515[58], i515[57], i515[56], i515[55], i515[54], i515[53], i515[52], i515[51], i515[50], i515[49], i515[48], i515[47], i515[46], i515[45], i515[44], i515[43], i515[42], i515[41], i515[40], i515[39], i515[38], i515[37], i515[36], i515[35], i515[34], i515[33], i515[32], i515[31], i515[30], i515[29], i515[28], i515[27], i515[26], i515[25], i515[24], i515[23], i515[22], i515[21], i515[20], i515[19], i515[18], i515[17], i515[16], i515[15], i515[14], i515[13], i515[12], i515[11], i515[10], i515[9], i515[8], i515[7], i515[6], i515[5], i515[4], i515[3], i515[2], i515[1], i515[0]};
wire [65:0] t1 = {1'b0, i518[32], i518[31], i518[30], i518[29], i518[28], i518[27], i518[26], i518[25], i518[24], i518[23], i518[22], i518[21], i518[20], i518[19], i518[18], i518[17], i518[16], i518[15], i518[14], i518[13], i518[12], i518[11], i518[10], i518[9], i518[8], i518[7], i518[6], i518[5], i518[4], i518[3], i518[2], i518[1], i518[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i522[32], i522[31], i522[30], i522[29], i522[28], i522[27], i522[26], i522[25], i522[24], i522[23], i522[22], i522[21], i522[20], i522[19], i522[18], i522[17], i522[16], i522[15], i522[14], i522[13], i522[12], i522[11], i522[10], i522[9], i522[8], i522[7], i522[6], i522[5], i522[4], i522[3], i522[2], i522[1], i522[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i526[1], i526[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_564_reduce(input wire [63:0] i543, input wire [33:0] i546, input wire [33:0] i550, input wire [3:0] i554, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i543[63], i543[62], i543[61], i543[60], i543[59], i543[58], i543[57], i543[56], i543[55], i543[54], i543[53], i543[52], i543[51], i543[50], i543[49], i543[48], i543[47], i543[46], i543[45], i543[44], i543[43], i543[42], i543[41], i543[40], i543[39], i543[38], i543[37], i543[36], i543[35], i543[34], i543[33], i543[32], i543[31], i543[30], i543[29], i543[28], i543[27], i543[26], i543[25], i543[24], i543[23], i543[22], i543[21], i543[20], i543[19], i543[18], i543[17], i543[16], i543[15], i543[14], i543[13], i543[12], i543[11], i543[10], i543[9], i543[8], i543[7], i543[6], i543[5], i543[4], i543[3], i543[2], i543[1], i543[0]};
wire [67:0] t1 = {1'b0, 1'b0, i546[33], i546[32], i546[31], i546[30], i546[29], i546[28], i546[27], i546[26], i546[25], i546[24], i546[23], i546[22], i546[21], i546[20], i546[19], i546[18], i546[17], i546[16], i546[15], i546[14], i546[13], i546[12], i546[11], i546[10], i546[9], i546[8], i546[7], i546[6], i546[5], i546[4], i546[3], i546[2], i546[1], i546[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i550[33], i550[32], i550[31], i550[30], i550[29], i550[28], i550[27], i550[26], i550[25], i550[24], i550[23], i550[22], i550[21], i550[20], i550[19], i550[18], i550[17], i550[16], i550[15], i550[14], i550[13], i550[12], i550[11], i550[10], i550[9], i550[8], i550[7], i550[6], i550[5], i550[4], i550[3], i550[2], i550[1], i550[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i554[3], i554[2], i554[1], i554[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_617_reduce(input wire [63:0] i596, input wire [33:0] i599, input wire [33:0] i603, input wire [3:0] i607, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i596[63], i596[62], i596[61], i596[60], i596[59], i596[58], i596[57], i596[56], i596[55], i596[54], i596[53], i596[52], i596[51], i596[50], i596[49], i596[48], i596[47], i596[46], i596[45], i596[44], i596[43], i596[42], i596[41], i596[40], i596[39], i596[38], i596[37], i596[36], i596[35], i596[34], i596[33], i596[32], i596[31], i596[30], i596[29], i596[28], i596[27], i596[26], i596[25], i596[24], i596[23], i596[22], i596[21], i596[20], i596[19], i596[18], i596[17], i596[16], i596[15], i596[14], i596[13], i596[12], i596[11], i596[10], i596[9], i596[8], i596[7], i596[6], i596[5], i596[4], i596[3], i596[2], i596[1], i596[0]};
wire [67:0] t1 = {1'b0, 1'b0, i599[33], i599[32], i599[31], i599[30], i599[29], i599[28], i599[27], i599[26], i599[25], i599[24], i599[23], i599[22], i599[21], i599[20], i599[19], i599[18], i599[17], i599[16], i599[15], i599[14], i599[13], i599[12], i599[11], i599[10], i599[9], i599[8], i599[7], i599[6], i599[5], i599[4], i599[3], i599[2], i599[1], i599[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i603[33], i603[32], i603[31], i603[30], i603[29], i603[28], i603[27], i603[26], i603[25], i603[24], i603[23], i603[22], i603[21], i603[20], i603[19], i603[18], i603[17], i603[16], i603[15], i603[14], i603[13], i603[12], i603[11], i603[10], i603[9], i603[8], i603[7], i603[6], i603[5], i603[4], i603[3], i603[2], i603[1], i603[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i607[3], i607[2], i607[1], i607[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_642_reduce(input wire [63:0] i621, input wire [63:0] i624, input wire [63:0] i628, input wire [63:0] i632, output wire [129:0] y);
wire [127:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i621[63], i621[62], i621[61], i621[60], i621[59], i621[58], i621[57], i621[56], i621[55], i621[54], i621[53], i621[52], i621[51], i621[50], i621[49], i621[48], i621[47], i621[46], i621[45], i621[44], i621[43], i621[42], i621[41], i621[40], i621[39], i621[38], i621[37], i621[36], i621[35], i621[34], i621[33], i621[32], i621[31], i621[30], i621[29], i621[28], i621[27], i621[26], i621[25], i621[24], i621[23], i621[22], i621[21], i621[20], i621[19], i621[18], i621[17], i621[16], i621[15], i621[14], i621[13], i621[12], i621[11], i621[10], i621[9], i621[8], i621[7], i621[6], i621[5], i621[4], i621[3], i621[2], i621[1], i621[0]};
wire [127:0] t1 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i624[63], i624[62], i624[61], i624[60], i624[59], i624[58], i624[57], i624[56], i624[55], i624[54], i624[53], i624[52], i624[51], i624[50], i624[49], i624[48], i624[47], i624[46], i624[45], i624[44], i624[43], i624[42], i624[41], i624[40], i624[39], i624[38], i624[37], i624[36], i624[35], i624[34], i624[33], i624[32], i624[31], i624[30], i624[29], i624[28], i624[27], i624[26], i624[25], i624[24], i624[23], i624[22], i624[21], i624[20], i624[19], i624[18], i624[17], i624[16], i624[15], i624[14], i624[13], i624[12], i624[11], i624[10], i624[9], i624[8], i624[7], i624[6], i624[5], i624[4], i624[3], i624[2], i624[1], i624[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t2 = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, i628[63], i628[62], i628[61], i628[60], i628[59], i628[58], i628[57], i628[56], i628[55], i628[54], i628[53], i628[52], i628[51], i628[50], i628[49], i628[48], i628[47], i628[46], i628[45], i628[44], i628[43], i628[42], i628[41], i628[40], i628[39], i628[38], i628[37], i628[36], i628[35], i628[34], i628[33], i628[32], i628[31], i628[30], i628[29], i628[28], i628[27], i628[26], i628[25], i628[24], i628[23], i628[22], i628[21], i628[20], i628[19], i628[18], i628[17], i628[16], i628[15], i628[14], i628[13], i628[12], i628[11], i628[10], i628[9], i628[8], i628[7], i628[6], i628[5], i628[4], i628[3], i628[2], i628[1], i628[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] t3 = {i632[63], i632[62], i632[61], i632[60], i632[59], i632[58], i632[57], i632[56], i632[55], i632[54], i632[53], i632[52], i632[51], i632[50], i632[49], i632[48], i632[47], i632[46], i632[45], i632[44], i632[43], i632[42], i632[41], i632[40], i632[39], i632[38], i632[37], i632[36], i632[35], i632[34], i632[33], i632[32], i632[31], i632[30], i632[29], i632[28], i632[27], i632[26], i632[25], i632[24], i632[23], i632[22], i632[21], i632[20], i632[19], i632[18], i632[17], i632[16], i632[15], i632[14], i632[13], i632[12], i632[11], i632[10], i632[9], i632[8], i632[7], i632[6], i632[5], i632[4], i632[3], i632[2], i632[1], i632[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [127:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_667_reduce(input wire [63:0] i646, input wire [32:0] i649, input wire [32:0] i653, input wire [1:0] i657, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i646[63], i646[62], i646[61], i646[60], i646[59], i646[58], i646[57], i646[56], i646[55], i646[54], i646[53], i646[52], i646[51], i646[50], i646[49], i646[48], i646[47], i646[46], i646[45], i646[44], i646[43], i646[42], i646[41], i646[40], i646[39], i646[38], i646[37], i646[36], i646[35], i646[34], i646[33], i646[32], i646[31], i646[30], i646[29], i646[28], i646[27], i646[26], i646[25], i646[24], i646[23], i646[22], i646[21], i646[20], i646[19], i646[18], i646[17], i646[16], i646[15], i646[14], i646[13], i646[12], i646[11], i646[10], i646[9], i646[8], i646[7], i646[6], i646[5], i646[4], i646[3], i646[2], i646[1], i646[0]};
wire [65:0] t1 = {1'b0, i649[32], i649[31], i649[30], i649[29], i649[28], i649[27], i649[26], i649[25], i649[24], i649[23], i649[22], i649[21], i649[20], i649[19], i649[18], i649[17], i649[16], i649[15], i649[14], i649[13], i649[12], i649[11], i649[10], i649[9], i649[8], i649[7], i649[6], i649[5], i649[4], i649[3], i649[2], i649[1], i649[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i653[32], i653[31], i653[30], i653[29], i653[28], i653[27], i653[26], i653[25], i653[24], i653[23], i653[22], i653[21], i653[20], i653[19], i653[18], i653[17], i653[16], i653[15], i653[14], i653[13], i653[12], i653[11], i653[10], i653[9], i653[8], i653[7], i653[6], i653[5], i653[4], i653[3], i653[2], i653[1], i653[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i657[1], i657[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_692_reduce(input wire [63:0] i671, input wire [32:0] i674, input wire [32:0] i678, input wire [1:0] i682, output wire [67:0] y);
wire [65:0] t0 = {1'b0, 1'b0, i671[63], i671[62], i671[61], i671[60], i671[59], i671[58], i671[57], i671[56], i671[55], i671[54], i671[53], i671[52], i671[51], i671[50], i671[49], i671[48], i671[47], i671[46], i671[45], i671[44], i671[43], i671[42], i671[41], i671[40], i671[39], i671[38], i671[37], i671[36], i671[35], i671[34], i671[33], i671[32], i671[31], i671[30], i671[29], i671[28], i671[27], i671[26], i671[25], i671[24], i671[23], i671[22], i671[21], i671[20], i671[19], i671[18], i671[17], i671[16], i671[15], i671[14], i671[13], i671[12], i671[11], i671[10], i671[9], i671[8], i671[7], i671[6], i671[5], i671[4], i671[3], i671[2], i671[1], i671[0]};
wire [65:0] t1 = {1'b0, i674[32], i674[31], i674[30], i674[29], i674[28], i674[27], i674[26], i674[25], i674[24], i674[23], i674[22], i674[21], i674[20], i674[19], i674[18], i674[17], i674[16], i674[15], i674[14], i674[13], i674[12], i674[11], i674[10], i674[9], i674[8], i674[7], i674[6], i674[5], i674[4], i674[3], i674[2], i674[1], i674[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t2 = {1'b0, i678[32], i678[31], i678[30], i678[29], i678[28], i678[27], i678[26], i678[25], i678[24], i678[23], i678[22], i678[21], i678[20], i678[19], i678[18], i678[17], i678[16], i678[15], i678[14], i678[13], i678[12], i678[11], i678[10], i678[9], i678[8], i678[7], i678[6], i678[5], i678[4], i678[3], i678[2], i678[1], i678[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] t3 = {i682[1], i682[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [65:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule

(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_717_reduce(input wire [63:0] i922, input wire [65:0] i923, input wire [65:0] i924, input wire [67:0] i925, output wire [69:0] y);
wire [67:0] t0 = {1'b0, 1'b0, 1'b0, 1'b0, i922[63], i922[62], i922[61], i922[60], i922[59], i922[58], i922[57], i922[56], i922[55], i922[54], i922[53], i922[52], i922[51], i922[50], i922[49], i922[48], i922[47], i922[46], i922[45], i922[44], i922[43], i922[42], i922[41], i922[40], i922[39], i922[38], i922[37], i922[36], i922[35], i922[34], i922[33], i922[32], i922[31], i922[30], i922[29], i922[28], i922[27], i922[26], i922[25], i922[24], i922[23], i922[22], i922[21], i922[20], i922[19], i922[18], i922[17], i922[16], i922[15], i922[14], i922[13], i922[12], i922[11], i922[10], i922[9], i922[8], i922[7], i922[6], i922[5], i922[4], i922[3], i922[2], i922[1], i922[0]};
wire [67:0] t1 = {1'b0, 1'b0, i923[65], i923[64], i923[63], i923[62], i923[61], i923[60], i923[59], i923[58], i923[57], i923[56], i923[55], i923[54], i923[53], i923[52], i923[51], i923[50], i923[49], i923[48], i923[47], i923[46], i923[45], i923[44], i923[43], i923[42], i923[41], i923[40], i923[39], i923[38], i923[37], i923[36], i923[35], i923[34], i923[33], i923[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t2 = {1'b0, 1'b0, i924[65], i924[64], i924[63], i924[62], i924[61], i924[60], i924[59], i924[58], i924[57], i924[56], i924[55], i924[54], i924[53], i924[52], i924[51], i924[50], i924[49], i924[48], i924[47], i924[46], i924[45], i924[44], i924[43], i924[42], i924[41], i924[40], i924[39], i924[38], i924[37], i924[36], i924[35], i924[34], i924[33], i924[32], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] t3 = {i925[67], i925[66], i925[65], i925[64], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
wire [67:0] sum = t0 + t1 + t2 + t3;
assign y=sum;
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_13();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_15();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_21();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_23();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_29Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_29();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_31Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_31();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_40();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_51();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53Core(input wire [64:0] a,input wire [64:0] b,input wire cin,output wire [64:0] value);
wire [64:0] masked_a=((a&65'hffffffffffffffff)|65'h0);
wire [64:0] masked_b=((b&65'hffffffffffffffff)|65'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b0);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_53();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_59();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_67();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_69();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_76();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78Core(input wire [129:0] a,input wire [129:0] b,input wire cin,output wire [129:0] value);
wire [129:0] masked_a=((a&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] masked_b=((b&130'hffffffffffffffffffffffffffffffff)|130'h0);
wire [129:0] aa=130'(masked_a);
wire [129:0] bb=130'(masked_b);
wire [130:0] extended={1'b0,aa}-{1'b0,bb}-131'(1'b0);
wire [129:0] native_value=extended[129:0];
assign value=native_value[0+:130];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_78();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_85();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_87Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [128:0] value);
wire [128:0] masked_a=((a&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'hffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_87();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_95();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'hffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_97();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_103();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'hffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_105();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113Core(input wire [65:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h1ffffffffffffffff)|66'h0);
wire [65:0] masked_b=((b&66'hffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_113();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115Core(input wire [65:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h1ffffffffffffffff)|66'h0);
wire [65:0] masked_b=((b&66'hffffffffffffffff)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_115();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_121();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123Core(input wire [33:0] a,input wire [33:0] b,input wire cin,output wire [33:0] value);
wire [33:0] masked_a=((a&34'h1ffffffff)|34'h0);
wire [33:0] masked_b=((b&34'h1ffffffff)|34'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [34:0] extended={1'b0,aa}+{1'b0,bb}+35'(1'b0);
wire [33:0] native_value=extended[33:0];
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_123();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_129();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131Core(input wire [67:0] a,input wire [67:0] b,input wire cin,output wire [67:0] value);
wire [67:0] masked_a=((a&68'hfffffffffffffffff)|68'h0);
wire [67:0] masked_b=((b&68'h3ffffffffffffffff)|68'h0);
wire [67:0] aa=68'(masked_a);
wire [67:0] bb=68'(masked_b);
wire [68:0] extended={1'b0,aa}-{1'b0,bb}-69'(1'b0);
wire [67:0] native_value=extended[67:0];
assign value=native_value[0+:68];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_131();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138Core(input wire [131:0] a,input wire [129:0] b,input wire cin,output wire [131:0] value);
wire [131:0] masked_a=((a&132'hfffffffffffffffffffffffffffffffff)|132'h0);
wire [129:0] masked_b=((b&130'h3ffffffffffffffffffffffffffffffff)|130'h0);
wire [131:0] aa=132'(masked_a);
wire [131:0] bb=132'(masked_b);
wire [132:0] extended={1'b0,aa}-{1'b0,bb}-133'(1'b0);
wire [131:0] native_value=extended[131:0];
assign value=native_value[0+:132];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_138();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140Core(input wire [131:0] a,input wire [131:0] b,input wire cin,output wire [131:0] value);
wire [131:0] masked_a=((a&132'hfffffffffffffffffffffffffffffffff)|132'h0);
wire [131:0] masked_b=((b&132'hffffffffffffffffffffffffffffffff)|132'h0);
wire [131:0] aa=132'(masked_a);
wire [131:0] bb=132'(masked_b);
wire [132:0] extended={1'b0,aa}-{1'b0,bb}-133'(1'b0);
wire [131:0] native_value=extended[131:0];
assign value=native_value[0+:132];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_140();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147Core(input wire [257:0] a,input wire [255:0] b,input wire cin,output wire [257:0] value);
wire [257:0] masked_a=((a&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [257:0] aa=258'(masked_a);
wire [257:0] bb=258'(masked_b);
wire [258:0] extended={1'b0,aa}-{1'b0,bb}-259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:258];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_147();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149Core(input wire [257:0] a,input wire [255:0] b,input wire cin,output wire [257:0] value);
wire [257:0] masked_a=((a&258'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|258'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [257:0] aa=258'(masked_a);
wire [257:0] bb=258'(masked_b);
wire [258:0] extended={1'b0,aa}-{1'b0,bb}-259'(1'b0);
wire [257:0] native_value=extended[257:0];
assign value=native_value[0+:258];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_149();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_157Core(input wire [511:0] a,input wire [511:0] b,input wire cin,output wire [512:0] value);
wire [511:0] masked_a=((a&512'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|512'h0);
wire [511:0] masked_b=((b&512'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|512'h0);
wire [512:0] aa=513'(masked_a);
wire [512:0] bb=513'(masked_b);
wire [513:0] extended={1'b0,aa}+{1'b0,bb}+514'(1'b0);
wire [512:0] native_value=extended[512:0];
assign value=native_value[0+:513];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_157();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_b);
wire [255:0] bb=256'(masked_a);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_220();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_221Core(input wire [255:0] a,input wire [255:0] b,input wire cin,output wire [255:0] value);
wire [255:0] masked_a=((a&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] masked_b=((b&256'hffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff)|256'h0);
wire [255:0] aa=256'(masked_a);
wire [255:0] bb=256'(masked_b);
wire [256:0] extended={1'b0,aa}+{1'b0,bb}+257'(1'b0);
wire [255:0] native_value=extended[255:0];
assign value=native_value[0+:256];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_221();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_362();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_365();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_369();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_373();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_377Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_377();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_380();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_383Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_383();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_387();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_390();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_394();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_398();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_402();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_405();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_408();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_412();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_415();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_419();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_423();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_437();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_440();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_443();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_447();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_451();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_465();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_468();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_472();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_476();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_490();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_493();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_497();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_501();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505Core(input wire [63:0] a,input wire [95:0] b,input wire cin,output wire [96:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [95:0] masked_b=((b&96'hffffffffffffffff00000000)|96'h0);
wire [96:0] aa=97'(masked_b);
wire [96:0] bb=97'(masked_a);
wire [97:0] extended={1'b0,aa}+{1'b0,bb}+98'(1'b0);
wire [96:0] native_value=extended[96:0];
assign value=native_value[0+:97];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_505();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_508Core(input wire [95:0] a,input wire [127:0] b,input wire cin,output wire [127:0] value);
wire [95:0] masked_a=((a&96'hffffffffffffffff00000000)|96'h0);
wire [127:0] masked_b=((b&128'hffffffffffffffff0000000000000000)|128'h0);
wire [127:0] aa=128'(masked_b);
wire [127:0] bb=128'(masked_a);
wire [128:0] extended={1'b0,aa}+{1'b0,bb}+129'(1'b0);
wire [127:0] native_value=extended[127:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_508();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511Core(input wire [96:0] a,input wire [128:0] b,input wire cin,output wire [127:0] value);
wire [96:0] masked_a=((a&97'h1ffffffffffffffffffffffff)|97'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_b);
wire [128:0] bb=129'(masked_a);
wire [129:0] extended={1'b0,aa}+{1'b0,bb}+130'(1'b0);
wire [128:0] native_value=extended[128:0];
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_511();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_515();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_518();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_522();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_526();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_540();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_543();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_546();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_550();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_554();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_568();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_571();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_575();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_579();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583Core(input wire [63:0] a,input wire [64:0] b,input wire cin,output wire [65:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [64:0] masked_b=((b&65'h1ffffffff00000000)|65'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_583();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_586Core(input wire [64:0] a,input wire [65:0] b,input wire cin,output wire [65:0] value);
wire [64:0] masked_a=((a&65'h1ffffffff00000000)|65'h0);
wire [65:0] masked_b=((b&66'h30000000000000000)|66'h0);
wire [65:0] aa=66'(masked_a);
wire [65:0] bb=66'(masked_b);
wire [66:0] extended={1'b0,aa}+{1'b0,bb}+67'(1'b0);
wire [65:0] native_value=extended[65:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_586();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589Core(input wire [65:0] a,input wire [66:0] b,input wire cin,output wire [65:0] value);
wire [65:0] masked_a=((a&66'h3ffffffffffffffff)|66'h0);
wire [66:0] masked_b=((b&67'h7ffffffffffffffff)|67'h0);
wire [66:0] aa=67'(masked_b);
wire [66:0] bb=67'(masked_a);
wire [67:0] extended={1'b0,aa}+{1'b0,bb}+68'(1'b0);
wire [66:0] native_value=extended[66:0];
assign value=native_value[0+:66];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_589();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_593();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_596();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_599();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_603();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_607();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_621();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_624();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_628();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_632();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_646();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_649();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_653();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_657();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_671();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674Core(input wire [31:0] a,input wire [0:0] b,input wire cin,output wire [32:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_674();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678Core(input wire [0:0] a,input wire [31:0] b,input wire cin,output wire [32:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [32:0] aa=33'(masked_a);
wire [32:0] bb=33'(masked_b);
wire [32:0] native_value=aa*bb;
assign value=native_value[0+:33];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_678();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [1:0] value);
wire [0:0] masked_a=((a&1'h1)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [1:0] aa=2'(masked_a);
wire [1:0] bb=2'(masked_b);
wire [1:0] native_value=aa*bb;
assign value=native_value[0+:2];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_682();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696Core(input wire [31:0] a,input wire [31:0] b,input wire cin,output wire [63:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [63:0] native_value=aa*bb;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_696();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699Core(input wire [31:0] a,input wire [1:0] b,input wire cin,output wire [33:0] value);
wire [31:0] masked_a=((a&32'hffffffff)|32'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_699();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703Core(input wire [1:0] a,input wire [31:0] b,input wire cin,output wire [33:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [31:0] masked_b=((b&32'hffffffff)|32'h0);
wire [33:0] aa=34'(masked_a);
wire [33:0] bb=34'(masked_b);
wire [33:0] native_value=aa*bb;
assign value=native_value[0+:34];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_703();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707Core(input wire [1:0] a,input wire [1:0] b,input wire cin,output wire [3:0] value);
wire [1:0] masked_a=((a&2'h3)|2'h0);
wire [1:0] masked_b=((b&2'h3)|2'h0);
wire [3:0] aa=4'(masked_a);
wire [3:0] bb=4'(masked_b);
wire [3:0] native_value=aa*bb;
assign value=native_value[0+:4];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_707();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
