`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [63:0] limb_16_40; // decl: <none>; prim: <none>
    logic [63:0] limb_16_41; // decl: <none>; prim: <none>
    logic [63:0] limb_16_42; // decl: <none>; prim: <none>
    logic [64:0] limb_16_43; // decl: <none>; prim: <none>
    logic [63:0] limb_16_44; // decl: <none>; prim: <none>
    logic limb_16_45; // decl: <none>; prim: <none>
    logic [63:0] limb_16_46; // decl: <none>; prim: <none>
    logic [63:0] limb_16_47; // decl: <none>; prim: <none>
    logic [63:0] limb_16_48; // decl: <none>; prim: <none>
    logic [64:0] limb_16_49; // decl: <none>; prim: <none>
    logic [63:0] limb_16_50; // decl: <none>; prim: <none>
    logic limb_16_51; // decl: <none>; prim: <none>
    logic limb_16_52; // decl: <none>; prim: <none>
    logic limb_16_53; // decl: <none>; prim: <none>
    logic limb_16_54; // decl: <none>; prim: <none>
    logic [1:0] limb_16_55; // decl: <none>; prim: <none>
    logic limb_16_56; // decl: <none>; prim: <none>
    logic [128:0] limb_16_57; // decl: <none>; prim: <none>
    logic [63:0] limb_18_58; // decl: <none>; prim: <none>
    logic [63:0] limb_18_59; // decl: <none>; prim: <none>
    logic [63:0] limb_18_60; // decl: <none>; prim: <none>
    logic [64:0] limb_18_61; // decl: <none>; prim: <none>
    logic [63:0] limb_18_62; // decl: <none>; prim: <none>
    logic limb_18_63; // decl: <none>; prim: <none>
    logic [63:0] limb_18_64; // decl: <none>; prim: <none>
    logic [63:0] limb_18_65; // decl: <none>; prim: <none>
    logic [63:0] limb_18_66; // decl: <none>; prim: <none>
    logic [64:0] limb_18_67; // decl: <none>; prim: <none>
    logic [63:0] limb_18_68; // decl: <none>; prim: <none>
    logic limb_18_69; // decl: <none>; prim: <none>
    logic limb_18_70; // decl: <none>; prim: <none>
    logic limb_18_71; // decl: <none>; prim: <none>
    logic limb_18_72; // decl: <none>; prim: <none>
    logic [1:0] limb_18_73; // decl: <none>; prim: <none>
    logic limb_18_74; // decl: <none>; prim: <none>
    logic [128:0] limb_18_75; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_27_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_27_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_34_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_40_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_40_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_40_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_44_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_45_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_46_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_46_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_46_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_46_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_47_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_47_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_52_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_52_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_53_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_54_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_60_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_65_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_65_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_66_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_66_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_66_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_66_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_71_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_72_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_72_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_72_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_72_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_72_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s1 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s3 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    assign s8_norm_sub_14_v0 = limb_16_57; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_17Core rtlzz_owner_17(.a(129'(s8_norm_sub_14_v0)), .b(64'(rtlzz_pipe_12_s7)), .cin(1'b0), .value(s8_norm_cmp_16_v0));
    assign s8_norm_sub_18_v0 = limb_18_75; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_19Core rtlzz_owner_19(.a(129'(s8_norm_sub_18_v0)), .b(129'(s8_norm_sub_14_v0)), .cin(s8_norm_cmp_16_v0), .value(s8_norm_mux_19_v0[63:0]));
    assign s8_norm_mux_19_v0[128:64] = '0;
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (rtlzz_pipe_27_s4 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_37Core rtlzz_owner_37(.a(64'(mul_precision_28)), .b(64'(mul_precision_29)), .cin(1'b0), .value(arith_original_37));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_38Core rtlzz_owner_38(.a(128'(rtlzz_pipe_31_s2)), .b(65'(rtlzz_pipe_32_s2)), .cin(1'b0), .value(arith_original_38));
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_39Core rtlzz_owner_39(.a(65'(rtlzz_pipe_34_s5)), .b(64'(rtlzz_pipe_35_s5)), .cin(1'b0), .value(arith_original_39));
    assign limb_16_40 = tmp_workload_top_int_129__16_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_41 = n3_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_42 = (~limb_16_41); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_43Core rtlzz_owner_43(.a(64'(rtlzz_pipe_40_s6)), .b(64'(rtlzz_pipe_42_s6)), .cin(1'h1), .value(limb_16_43));
    assign limb_16_44 = limb_16_43[63:0]; // decl: <none>; prim: <none>
    assign limb_16_45 = limb_16_43[64]; // decl: <none>; prim: <none>
    assign limb_16_46 = tmp_workload_top_int_129__16_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_16_47 = n3_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_16_48 = (~rtlzz_pipe_47_s7); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_49Core rtlzz_owner_49(.a(64'(rtlzz_pipe_46_s7)), .b(64'(limb_16_48)), .cin(rtlzz_pipe_45_s7), .value(limb_16_49));
    assign limb_16_50 = limb_16_49[63:0]; // decl: <none>; prim: <none>
    assign limb_16_51 = limb_16_49[64]; // decl: <none>; prim: <none>
    assign limb_16_52 = tmp_workload_top_int_129__16_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_53 = n3_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_54 = (~rtlzz_pipe_53_s6); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_55Core rtlzz_owner_55(.a(1'(rtlzz_pipe_52_s7)), .b(1'(rtlzz_pipe_54_s7)), .cin(limb_16_51), .value(limb_16_55[0:0]));
    assign limb_16_55[1:1] = '0;
    assign limb_16_56 = limb_16_55[0]; // decl: <none>; prim: <none>
    assign limb_16_57 = {limb_16_56, limb_16_50, rtlzz_pipe_44_s7}; // decl: <none>; prim: <none>
    assign limb_18_58 = s8_norm_sub_14_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_18_59 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_18_60 = (~limb_18_59); // decl: <none>; prim: <none>
    (* keep_hierarchy=1 *) WorkloadCore__rtlzz_arith_61Core rtlzz_owner_61(.a(64'(limb_18_58)), .b(64'(rtlzz_pipe_60_s7)), .cin(1'h1), .value(limb_18_61[63:0]));
    assign limb_18_61[64:64] = '0;
    assign limb_18_62 = limb_18_61[63:0]; // decl: <none>; prim: <none>
    assign limb_18_63 = limb_18_61[64]; // decl: <none>; prim: <none>
    assign limb_18_64 = s8_norm_sub_14_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_18_65 = tmp_workload_top_int_129__13_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_18_66 = (~rtlzz_pipe_65_s3); // decl: <none>; prim: <none>
    assign limb_18_67 = 65'((({1'h0, limb_18_64}) + ({1'h0, rtlzz_pipe_66_s7}) + ({64'h0, limb_18_63}))); // decl: <none>; prim: <none>
    assign limb_18_68 = limb_18_67[63:0]; // decl: <none>; prim: <none>
    assign limb_18_69 = limb_18_67[64]; // decl: <none>; prim: <none>
    assign limb_18_70 = s8_norm_sub_14_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_71 = tmp_workload_top_int_129__13_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_72 = (~rtlzz_pipe_71_s2); // decl: <none>; prim: <none>
    assign limb_18_73 = 2'((({1'h0, limb_18_70}) + ({1'h0, rtlzz_pipe_72_s7}) + ({1'h0, limb_18_69}))); // decl: <none>; prim: <none>
    assign limb_18_74 = limb_18_73[0]; // decl: <none>; prim: <none>
    assign limb_18_75 = {limb_18_74, limb_18_68, limb_18_62}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_23_s1 <= 193'h0;
            rtlzz_pipe_25_s1 <= 129'h0;
            rtlzz_pipe_25_s2 <= 129'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_31_s2 <= 128'h0;
            rtlzz_pipe_27_s3 <= 129'h0;
            rtlzz_pipe_27_s4 <= 129'h0;
            rtlzz_pipe_34_s5 <= 65'h0;
            rtlzz_pipe_40_s4 <= 64'h0;
            rtlzz_pipe_40_s5 <= 64'h0;
            rtlzz_pipe_40_s6 <= 64'h0;
            rtlzz_pipe_42_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_44_s7 <= 64'h0;
            rtlzz_pipe_45_s7 <= 1'h1;
            rtlzz_pipe_46_s4 <= 64'h0;
            rtlzz_pipe_46_s5 <= 64'h0;
            rtlzz_pipe_46_s6 <= 64'h0;
            rtlzz_pipe_46_s7 <= 64'h0;
            rtlzz_pipe_47_s6 <= 64'h0;
            rtlzz_pipe_47_s7 <= 64'h0;
            rtlzz_pipe_52_s4 <= 1'h0;
            rtlzz_pipe_52_s5 <= 1'h0;
            rtlzz_pipe_52_s6 <= 1'h0;
            rtlzz_pipe_52_s7 <= 1'h0;
            rtlzz_pipe_53_s6 <= 1'h0;
            rtlzz_pipe_54_s7 <= 1'h1;
            rtlzz_pipe_60_s1 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s2 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s3 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s4 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s5 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_60_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_65_s1 <= 64'h0;
            rtlzz_pipe_65_s2 <= 64'h0;
            rtlzz_pipe_65_s3 <= 64'h0;
            rtlzz_pipe_66_s4 <= 64'hffffffffffffffff;
            rtlzz_pipe_66_s5 <= 64'hffffffffffffffff;
            rtlzz_pipe_66_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_66_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_71_s1 <= 1'h0;
            rtlzz_pipe_71_s2 <= 1'h0;
            rtlzz_pipe_72_s3 <= 1'h1;
            rtlzz_pipe_72_s4 <= 1'h1;
            rtlzz_pipe_72_s5 <= 1'h1;
            rtlzz_pipe_72_s6 <= 1'h1;
            rtlzz_pipe_72_s7 <= 1'h1;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_27_s3 <= __beopt_width_29; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_27_s4 <= rtlzz_pipe_27_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_34_s5 <= mul_precision_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_40_s4 <= limb_16_40; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_40_s5 <= rtlzz_pipe_40_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_40_s6 <= rtlzz_pipe_40_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_42_s6 <= limb_16_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_44_s7 <= limb_16_44; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= limb_16_45; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_46_s4 <= limb_16_46; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_46_s5 <= rtlzz_pipe_46_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_46_s6 <= rtlzz_pipe_46_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_46_s7 <= rtlzz_pipe_46_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_47_s6 <= limb_16_47; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_47_s7 <= rtlzz_pipe_47_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= limb_16_52; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_52_s7 <= rtlzz_pipe_52_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_53_s6 <= limb_16_53; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_54_s7 <= limb_16_54; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_60_s1 <= limb_18_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= rtlzz_pipe_60_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_60_s3 <= rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_60_s4 <= rtlzz_pipe_60_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_60_s5 <= rtlzz_pipe_60_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_60_s6 <= rtlzz_pipe_60_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_60_s7 <= rtlzz_pipe_60_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= limb_18_65; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_65_s2 <= rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_65_s3 <= rtlzz_pipe_65_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_66_s4 <= limb_18_66; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_66_s5 <= rtlzz_pipe_66_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_66_s6 <= rtlzz_pipe_66_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_66_s7 <= rtlzz_pipe_66_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= limb_18_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_71_s2 <= rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_72_s3 <= limb_18_72; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_72_s4 <= rtlzz_pipe_72_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_72_s5 <= rtlzz_pipe_72_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_72_s6 <= rtlzz_pipe_72_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_72_s7 <= rtlzz_pipe_72_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17Core(input wire [128:0] a,input wire [63:0] b,input wire cin,output wire [0:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=129'(aa<bb);
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_17();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19Core(input wire [128:0] a,input wire [128:0] b,input wire cin,output wire [63:0] value);
wire [128:0] masked_a=((a&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] masked_b=((b&129'h1ffffffffffffffffffffffffffffffff)|129'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=cin?bb:aa;
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_19();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_37Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [127:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [127:0] aa=128'(masked_a);
wire [127:0] bb=128'(masked_b);
wire [127:0] native_value=aa*bb;
assign value=native_value[0+:128];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_37();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38Core(input wire [127:0] a,input wire [64:0] b,input wire cin,output wire [192:0] value);
wire [127:0] masked_a=((a&128'hffffffffffffffffffffffffffffffff)|128'h0);
wire [64:0] masked_b=((b&65'h1ffffffffffffffff)|65'h0);
wire [192:0] aa=193'(masked_a);
wire [192:0] bb=193'(masked_b);
wire [192:0] native_value=aa*bb;
assign value=native_value[0+:193];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_38();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39Core(input wire [64:0] a,input wire [63:0] b,input wire cin,output wire [128:0] value);
wire [64:0] masked_a=((a&65'h1ffffffffffffffff)|65'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [128:0] aa=129'(masked_a);
wire [128:0] bb=129'(masked_b);
wire [128:0] native_value=aa*bb;
assign value=native_value[0+:129];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_39();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_43Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(1'b1);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_43();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [64:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [64:0] aa=65'(masked_a);
wire [64:0] bb=65'(masked_b);
wire [65:0] extended={1'b0,aa}+{1'b0,bb}+66'(cin);
wire [64:0] native_value=extended[64:0];
assign value=native_value[0+:65];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_49();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55Core(input wire [0:0] a,input wire [0:0] b,input wire cin,output wire [0:0] value);
wire [0:0] masked_a=((a&1'h0)|1'h0);
wire [0:0] masked_b=((b&1'h1)|1'h0);
wire [0:0] aa=1'(masked_b);
wire [0:0] bb=1'(masked_a);
wire [1:0] extended={1'b0,aa}+{1'b0,bb}+2'(cin);
wire [0:0] native_value=extended[0:0];
assign value=native_value[0+:1];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_55();endmodule
// unsigned-wide-family-hierarchy-v1
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61Core(input wire [63:0] a,input wire [63:0] b,input wire cin,output wire [63:0] value);
wire [63:0] masked_a=((a&64'hffffffffffffffff)|64'h0);
wire [63:0] masked_b=((b&64'hffffffffffffffff)|64'h0);
wire [63:0] aa=64'(masked_a);
wire [63:0] bb=64'(masked_b);
wire [64:0] extended={1'b0,aa}+{1'b0,bb}+65'(1'b1);
wire [63:0] native_value=extended[63:0];
assign value=native_value[0+:64];
endmodule
(* keep_hierarchy=1 *) module WorkloadCore__rtlzz_arith_61();endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
