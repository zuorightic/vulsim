`timescale 1ns/1ps

module constant_pipe(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12
    input logic [31:0] c, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14
    input logic [31:0] d, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16
    output logic [36:0] y, // decl: <none>; prim: <none>
    output logic [36:0] z, // decl: <none>; prim: <none>
    input logic iv, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    output logic ov, // decl: <none>; prim: <none>
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [36:0] arith_5_335; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:35-6:67
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38


    assign y = arith_5_335; // decl: <none>; prim: <none>
    assign z = arith_5_335; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign arith_5_335 = 37'h40000000; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:35-6:67
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        end
    end
endmodule
