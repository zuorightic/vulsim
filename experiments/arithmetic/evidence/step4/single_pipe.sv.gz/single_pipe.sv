`timescale 1ns/1ps

module single_pipe(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12
    input logic [31:0] c, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14
    input logic [31:0] d, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16
    output logic [36:0] y, // decl: <none>; prim: <none>
    output logic [36:0] z, // decl: <none>; prim: <none>
    input logic iv, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    output logic ov, // decl: <none>; prim: <none>
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [36:0] arith_5_335; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_460; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    logic arith_opt_461; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic [7:0] arith_opt_462; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [7:0] arith_opt_463; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    logic [22:0] arith_opt_464; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_465; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_466; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic arith_opt_467; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_468; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    logic arith_opt_469; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic arith_opt_470; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_471; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    logic [22:0] arith_opt_472; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_473; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_474; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_475; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_476; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic arith_opt_477; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    logic arith_opt_478; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic [23:0] arith_opt_479; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_480; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    logic arith_opt_481; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic [23:0] arith_opt_482; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_483; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    logic arith_opt_484; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_485; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [23:0] arith_opt_486; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_487; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_488; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_489; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [23:0] arith_opt_490; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_491; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_492; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_493; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [1:0] arith_opt_494; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_495; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_496; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_497; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_498; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [1:0] arith_opt_499; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_500; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_501; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_502; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_503; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [2:0] arith_opt_504; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_505; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_506; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_507; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_508; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [2:0] arith_opt_509; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_510; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_511; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_512; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_513; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [3:0] arith_opt_514; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_515; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_516; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_517; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_518; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [3:0] arith_opt_519; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_520; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_521; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_522; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_523; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [4:0] arith_opt_524; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_525; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_526; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_527; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_528; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [4:0] arith_opt_529; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_530; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_531; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_532; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_533; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [5:0] arith_opt_534; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_535; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_536; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_537; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_538; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [5:0] arith_opt_539; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_540; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_541; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_542; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_543; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [6:0] arith_opt_544; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_545; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_546; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_547; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_548; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [6:0] arith_opt_549; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_550; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_551; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_552; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_553; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_554; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_555; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_556; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_557; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_558; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_559; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_560; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_561; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_562; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_563; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_564; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_565; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_566; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_567; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_568; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_569; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_570; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_571; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_572; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_573; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_574; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_575; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_576; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_577; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_578; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_579; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_580; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_581; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_582; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_583; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_584; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_585; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_586; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_587; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_588; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_589; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_590; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_591; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_592; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_593; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_594; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_595; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_596; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_597; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_598; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_599; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_600; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_601; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_602; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_603; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_604; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_605; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_606; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_607; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_608; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_609; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_610; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_611; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_612; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_613; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_614; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_615; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_616; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_617; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_618; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_619; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_620; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_621; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_622; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_623; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_624; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_625; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_626; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_627; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_628; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_629; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_630; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_631; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_632; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_633; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_634; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_635; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_636; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_637; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_638; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_639; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_640; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_641; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_642; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_643; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_644; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_645; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_646; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_647; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_648; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_649; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_650; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_651; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_652; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_653; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_654; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_655; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_656; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_657; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_658; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_659; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_660; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_661; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_662; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_663; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_664; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_665; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_666; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_667; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_668; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_669; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_670; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_671; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_672; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_673; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_674; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_675; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_676; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_677; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_678; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_679; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_680; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_681; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_682; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_683; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_684; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_685; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_686; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_687; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_688; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_689; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_690; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_691; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_692; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_693; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_694; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_695; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_696; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_697; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_698; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_699; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_700; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_701; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_702; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_703; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_704; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_705; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_706; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_707; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_708; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_709; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_710; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_711; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic [7:0] arith_opt_712; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    logic [10:0] arith_opt_713; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    logic [11:0] arith_opt_714; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    logic [7:0] arith_opt_715; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    logic [10:0] arith_opt_716; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    logic [11:0] arith_opt_717; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    logic [11:0] arith_opt_718; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_719; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    logic [47:0] arith_opt_720; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_721; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic arith_opt_722; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_723; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    logic [30:0] arith_opt_724; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    logic arith_opt_725; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    logic [31:0] arith_opt_726; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic [11:0] arith_opt_727; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_728; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    logic [31:0] arith_opt_729; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic arith_opt_730; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    logic arith_opt_731; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    logic arith_opt_732; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    logic [31:0] arith_opt_733; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    logic arith_opt_734; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    logic arith_opt_735; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    logic arith_opt_736; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic arith_opt_737; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    logic arith_opt_738; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    logic arith_opt_739; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic [11:0] arith_opt_740; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_741; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_742; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    logic arith_opt_743; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    logic [31:0] arith_opt_744; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    logic [31:0] arith_opt_745; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    logic [31:0] arith_opt_746; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    logic arith_opt_747; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    logic [31:0] arith_opt_748; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    logic [31:0] arith_opt_749; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    logic [31:0] arith_opt_750; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [31:0] arith_opt_751; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    logic arith_opt_752; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    logic [1:0] arith_opt_753; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    logic [8:0] arith_opt_754; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    logic [31:0] arith_opt_755; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [1:0] arith_opt_756; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    logic [6:0] arith_opt_757; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    logic [31:0] arith_opt_758; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_759; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    logic arith_opt_760; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    logic [1:0] arith_opt_761; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    logic [1:0] arith_opt_762; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    logic arith_opt_763; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    logic [24:0] arith_opt_764; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_765; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    logic [8:0] arith_opt_766; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    logic arith_opt_767; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    logic [8:0] arith_opt_768; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    logic [31:0] arith_opt_769; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    logic [31:0] arith_opt_770; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_771; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_772; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    logic [31:0] arith_opt_773; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    logic [2:0] arith_opt_774; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    logic arith_opt_775; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    logic [2:0] arith_opt_776; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    logic [4:0] arith_opt_777; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    logic [4:0] arith_opt_778; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [4:0] arith_opt_779; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [31:0] arith_opt_780; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [36:0] arith_opt_781; // decl: <none>; prim: <none>
    logic arith_opt_782; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    logic arith_opt_783; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    logic arith_opt_784; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_785; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_786; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_787; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    logic arith_opt_788; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    logic arith_opt_789; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    logic arith_opt_790; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    logic [30:0] arith_opt_791; // decl: <none>; prim: <none>
    logic [30:0] arith_opt_792; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_793; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic [23:0] arith_opt_794; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic [9:0] arith_opt_795; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_796; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_797; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_798; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_799; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_800; // decl: <none>; prim: <none>
    logic [16:0] arith_opt_801; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_802; // decl: <none>; prim: <none>
    logic [6:0] arith_opt_803; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_804; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_805; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_806; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_807; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_808; // decl: <none>; prim: <none>
    logic arith_opt_809; // decl: <none>; prim: <none>
    logic arith_opt_810; // decl: <none>; prim: <none>
    logic arith_opt_811; // decl: <none>; prim: <none>
    logic arith_opt_812; // decl: <none>; prim: <none>
    logic arith_opt_813; // decl: <none>; prim: <none>
    logic arith_opt_814; // decl: <none>; prim: <none>
    logic arith_opt_815; // decl: <none>; prim: <none>
    logic arith_opt_816; // decl: <none>; prim: <none>
    logic arith_opt_817; // decl: <none>; prim: <none>
    logic arith_opt_818; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_819; // decl: <none>; prim: <none>
    logic arith_opt_820; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_821; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_822; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_823; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_824; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_825; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_826; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_827; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_828; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_829; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_830; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_831; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_832; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_833; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_834; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_835; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_836; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_837; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_838; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_839; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_840; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_841; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_842; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_843; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_844; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_845; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_846; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_847; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_848; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_849; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_850; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_851; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_852; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_853; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_854; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_855; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_856; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_857; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_858; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_859; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_860; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_861; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_862; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_863; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_864; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_865; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_866; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_867; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_868; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_869; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_870; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_871; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_872; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_873; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_874; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_875; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_876; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_877; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_878; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_879; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_880; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_881; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_882; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [31:0] arith_opt_883; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [31:0] arith_opt_884; // decl: <none>; prim: <none>
    logic arith_opt_885; // decl: <none>; prim: <none>
    logic arith_opt_886; // decl: <none>; prim: <none>
    logic arith_opt_887; // decl: <none>; prim: <none>
    logic arith_opt_888; // decl: <none>; prim: <none>
    logic arith_opt_889; // decl: <none>; prim: <none>
    logic arith_opt_890; // decl: <none>; prim: <none>
    logic arith_opt_891; // decl: <none>; prim: <none>
    logic arith_opt_892; // decl: <none>; prim: <none>
    logic arith_opt_893; // decl: <none>; prim: <none>
    logic arith_opt_894; // decl: <none>; prim: <none>
    logic arith_opt_895; // decl: <none>; prim: <none>
    logic arith_opt_896; // decl: <none>; prim: <none>
    logic arith_opt_897; // decl: <none>; prim: <none>
    logic arith_opt_898; // decl: <none>; prim: <none>
    logic arith_opt_899; // decl: <none>; prim: <none>
    logic arith_opt_900; // decl: <none>; prim: <none>
    logic arith_opt_901; // decl: <none>; prim: <none>
    logic arith_opt_902; // decl: <none>; prim: <none>
    logic arith_opt_903; // decl: <none>; prim: <none>
    logic arith_opt_904; // decl: <none>; prim: <none>
    logic arith_opt_905; // decl: <none>; prim: <none>
    logic arith_opt_906; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_8_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_8_s2; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_8_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38


    assign y = rtlzz_pipe_8_s3; // decl: <none>; prim: <none>
    assign z = rtlzz_pipe_8_s3; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign arith_5_335 = arith_opt_781; // decl: <none>; prim: <none>
    assign arith_opt_460 = (a ^ b); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    assign arith_opt_461 = arith_opt_460[31]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_462 = a[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_463 = b[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    assign arith_opt_464 = a[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_465 = b[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_466 = (arith_opt_462 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_467 = (arith_opt_464 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_468 = (arith_opt_466 & arith_opt_467); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    assign arith_opt_469 = (arith_opt_463 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_470 = (arith_opt_465 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_471 = (arith_opt_469 & arith_opt_470); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    assign arith_opt_472 = (arith_opt_464 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_473 = (arith_opt_472 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_474 = (arith_opt_465 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_475 = (arith_opt_474 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_476 = (arith_opt_791 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_477 = (arith_opt_792 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    assign arith_opt_478 = (arith_opt_462 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_479 = (arith_opt_793 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_480 = (arith_opt_478 ? arith_opt_479 : ({1'h0, arith_opt_464})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    assign arith_opt_481 = (arith_opt_463 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_482 = (arith_opt_794 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_483 = (arith_opt_481 ? arith_opt_482 : ({1'h0, arith_opt_465})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    assign arith_opt_484 = (arith_opt_480 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_485 = (arith_opt_480 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_486 = (arith_opt_484 ? arith_opt_485 : arith_opt_480); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_487 = (arith_opt_484 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_488 = (arith_opt_483 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_489 = (arith_opt_483 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_490 = (arith_opt_488 ? arith_opt_489 : arith_opt_483); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_491 = (arith_opt_488 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_492 = (arith_opt_486 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_493 = (arith_opt_486 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_494 = (arith_opt_487 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_495 = (arith_opt_492 ? arith_opt_493 : arith_opt_486); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_496 = (arith_opt_492 ? arith_opt_494 : ({1'h0, arith_opt_487})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_497 = (arith_opt_490 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_498 = (arith_opt_490 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_499 = (arith_opt_491 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_500 = (arith_opt_497 ? arith_opt_498 : arith_opt_490); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_501 = (arith_opt_497 ? arith_opt_499 : ({1'h0, arith_opt_491})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_502 = (arith_opt_495 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_503 = (arith_opt_495 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_504 = (arith_opt_496 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_505 = (arith_opt_502 ? arith_opt_503 : arith_opt_495); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_506 = (arith_opt_502 ? arith_opt_504 : ({1'h0, arith_opt_496})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_507 = (arith_opt_500 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_508 = (arith_opt_500 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_509 = (arith_opt_501 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_510 = (arith_opt_507 ? arith_opt_508 : arith_opt_500); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_511 = (arith_opt_507 ? arith_opt_509 : ({1'h0, arith_opt_501})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_512 = (arith_opt_505 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_513 = (arith_opt_505 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_514 = (arith_opt_506 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_515 = (arith_opt_512 ? arith_opt_513 : arith_opt_505); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_516 = (arith_opt_512 ? arith_opt_514 : ({1'h0, arith_opt_506})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_517 = (arith_opt_510 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_518 = (arith_opt_510 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_519 = (arith_opt_511 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_520 = (arith_opt_517 ? arith_opt_518 : arith_opt_510); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_521 = (arith_opt_517 ? arith_opt_519 : ({1'h0, arith_opt_511})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_522 = (arith_opt_515 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_523 = (arith_opt_515 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_524 = (arith_opt_516 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_525 = (arith_opt_522 ? arith_opt_523 : arith_opt_515); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_526 = (arith_opt_522 ? arith_opt_524 : ({1'h0, arith_opt_516})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_527 = (arith_opt_520 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_528 = (arith_opt_520 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_529 = (arith_opt_521 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_530 = (arith_opt_527 ? arith_opt_528 : arith_opt_520); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_531 = (arith_opt_527 ? arith_opt_529 : ({1'h0, arith_opt_521})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_532 = (arith_opt_525 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_533 = (arith_opt_525 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_534 = (arith_opt_526 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_535 = (arith_opt_532 ? arith_opt_533 : arith_opt_525); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_536 = (arith_opt_532 ? arith_opt_534 : ({1'h0, arith_opt_526})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_537 = (arith_opt_530 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_538 = (arith_opt_530 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_539 = (arith_opt_531 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_540 = (arith_opt_537 ? arith_opt_538 : arith_opt_530); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_541 = (arith_opt_537 ? arith_opt_539 : ({1'h0, arith_opt_531})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_542 = (arith_opt_535 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_543 = (arith_opt_535 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_544 = (arith_opt_536 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_545 = (arith_opt_542 ? arith_opt_543 : arith_opt_535); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_546 = (arith_opt_542 ? arith_opt_544 : ({1'h0, arith_opt_536})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_547 = (arith_opt_540 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_548 = (arith_opt_540 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_549 = (arith_opt_541 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_550 = (arith_opt_547 ? arith_opt_548 : arith_opt_540); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_551 = (arith_opt_547 ? arith_opt_549 : ({1'h0, arith_opt_541})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_552 = (arith_opt_545 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_553 = (arith_opt_545 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_554 = (arith_opt_546 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_555 = (arith_opt_552 ? arith_opt_553 : arith_opt_545); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_556 = (arith_opt_552 ? arith_opt_554 : ({1'h0, arith_opt_546})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_557 = (arith_opt_550 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_558 = (arith_opt_550 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_559 = (arith_opt_551 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_560 = (arith_opt_557 ? arith_opt_558 : arith_opt_550); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_561 = (arith_opt_557 ? arith_opt_559 : ({1'h0, arith_opt_551})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_562 = (arith_opt_555 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_563 = (arith_opt_555 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_564 = (arith_opt_556 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_565 = (arith_opt_562 ? arith_opt_563 : arith_opt_555); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_566 = (arith_opt_562 ? arith_opt_564 : arith_opt_556); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_567 = (arith_opt_560 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_568 = (arith_opt_560 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_569 = (arith_opt_561 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_570 = (arith_opt_567 ? arith_opt_568 : arith_opt_560); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_571 = (arith_opt_567 ? arith_opt_569 : arith_opt_561); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_572 = (arith_opt_565 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_573 = (arith_opt_565 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_574 = (arith_opt_566 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_575 = (arith_opt_572 ? arith_opt_573 : arith_opt_565); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_576 = (arith_opt_572 ? arith_opt_574 : arith_opt_566); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_577 = (arith_opt_570 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_578 = (arith_opt_570 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_579 = (arith_opt_571 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_580 = (arith_opt_577 ? arith_opt_578 : arith_opt_570); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_581 = (arith_opt_577 ? arith_opt_579 : arith_opt_571); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_582 = (arith_opt_575 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_583 = (arith_opt_575 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_584 = (arith_opt_576 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_585 = (arith_opt_582 ? arith_opt_583 : arith_opt_575); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_586 = (arith_opt_582 ? arith_opt_584 : arith_opt_576); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_587 = (arith_opt_580 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_588 = (arith_opt_580 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_589 = (arith_opt_581 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_590 = (arith_opt_587 ? arith_opt_588 : arith_opt_580); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_591 = (arith_opt_587 ? arith_opt_589 : arith_opt_581); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_592 = (arith_opt_585 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_593 = (arith_opt_585 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_594 = (arith_opt_586 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_595 = (arith_opt_592 ? arith_opt_593 : arith_opt_585); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_596 = (arith_opt_592 ? arith_opt_594 : arith_opt_586); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_597 = (arith_opt_590 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_598 = (arith_opt_590 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_599 = (arith_opt_591 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_600 = (arith_opt_597 ? arith_opt_598 : arith_opt_590); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_601 = (arith_opt_597 ? arith_opt_599 : arith_opt_591); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_602 = (arith_opt_595 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_603 = (arith_opt_595 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_604 = (arith_opt_596 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_605 = (arith_opt_602 ? arith_opt_603 : arith_opt_595); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_606 = (arith_opt_602 ? arith_opt_604 : arith_opt_596); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_607 = (arith_opt_600 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_608 = (arith_opt_600 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_609 = (arith_opt_601 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_610 = (arith_opt_607 ? arith_opt_608 : arith_opt_600); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_611 = (arith_opt_607 ? arith_opt_609 : arith_opt_601); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_612 = (arith_opt_605 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_613 = (arith_opt_605 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_614 = (arith_opt_606 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_615 = (arith_opt_612 ? arith_opt_613 : arith_opt_605); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_616 = (arith_opt_612 ? arith_opt_614 : arith_opt_606); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_617 = (arith_opt_610 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_618 = (arith_opt_610 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_619 = (arith_opt_611 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_620 = (arith_opt_617 ? arith_opt_618 : arith_opt_610); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_621 = (arith_opt_617 ? arith_opt_619 : arith_opt_611); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_622 = (arith_opt_615 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_623 = (arith_opt_615 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_624 = (arith_opt_616 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_625 = (arith_opt_622 ? arith_opt_623 : arith_opt_615); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_626 = (arith_opt_622 ? arith_opt_624 : arith_opt_616); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_627 = (arith_opt_620 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_628 = (arith_opt_620 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_629 = (arith_opt_621 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_630 = (arith_opt_627 ? arith_opt_628 : arith_opt_620); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_631 = (arith_opt_627 ? arith_opt_629 : arith_opt_621); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_632 = (arith_opt_625 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_633 = (arith_opt_625 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_634 = (arith_opt_626 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_635 = (arith_opt_632 ? arith_opt_633 : arith_opt_625); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_636 = (arith_opt_632 ? arith_opt_634 : arith_opt_626); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_637 = (arith_opt_630 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_638 = (arith_opt_630 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_639 = (arith_opt_631 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_640 = (arith_opt_637 ? arith_opt_638 : arith_opt_630); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_641 = (arith_opt_637 ? arith_opt_639 : arith_opt_631); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_642 = (arith_opt_635 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_643 = (arith_opt_635 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_644 = (arith_opt_636 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_645 = (arith_opt_642 ? arith_opt_643 : arith_opt_635); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_646 = (arith_opt_642 ? arith_opt_644 : arith_opt_636); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_647 = (arith_opt_640 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_648 = (arith_opt_640 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_649 = (arith_opt_641 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_650 = (arith_opt_647 ? arith_opt_648 : arith_opt_640); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_651 = (arith_opt_647 ? arith_opt_649 : arith_opt_641); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_652 = (arith_opt_645 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_653 = (arith_opt_645 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_654 = (arith_opt_646 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_655 = (arith_opt_652 ? arith_opt_653 : arith_opt_645); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_656 = (arith_opt_652 ? arith_opt_654 : arith_opt_646); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_657 = (arith_opt_650 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_658 = (arith_opt_650 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_659 = (arith_opt_651 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_660 = (arith_opt_657 ? arith_opt_658 : arith_opt_650); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_661 = (arith_opt_657 ? arith_opt_659 : arith_opt_651); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_662 = (arith_opt_655 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_663 = (arith_opt_655 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_664 = (arith_opt_656 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_665 = (arith_opt_662 ? arith_opt_663 : arith_opt_655); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_666 = (arith_opt_662 ? arith_opt_664 : arith_opt_656); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_667 = (arith_opt_660 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_668 = (arith_opt_660 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_669 = (arith_opt_661 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_670 = (arith_opt_667 ? arith_opt_668 : arith_opt_660); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_671 = (arith_opt_667 ? arith_opt_669 : arith_opt_661); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_672 = (arith_opt_665 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_673 = (arith_opt_665 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_674 = (arith_opt_666 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_675 = (arith_opt_672 ? arith_opt_673 : arith_opt_665); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_676 = (arith_opt_672 ? arith_opt_674 : arith_opt_666); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_677 = (arith_opt_670 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_678 = (arith_opt_670 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_679 = (arith_opt_671 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_680 = (arith_opt_677 ? arith_opt_678 : arith_opt_670); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_681 = (arith_opt_677 ? arith_opt_679 : arith_opt_671); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_682 = (arith_opt_675 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_683 = (arith_opt_675 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_684 = (arith_opt_676 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_685 = (arith_opt_682 ? arith_opt_683 : arith_opt_675); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_686 = (arith_opt_682 ? arith_opt_684 : arith_opt_676); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_687 = (arith_opt_680 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_688 = (arith_opt_680 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_689 = (arith_opt_681 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_690 = (arith_opt_687 ? arith_opt_688 : arith_opt_680); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_691 = (arith_opt_687 ? arith_opt_689 : arith_opt_681); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_692 = (arith_opt_685 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_693 = (arith_opt_685 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_694 = (arith_opt_686 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_695 = (arith_opt_692 ? arith_opt_693 : arith_opt_685); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_696 = (arith_opt_692 ? arith_opt_694 : arith_opt_686); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_697 = (arith_opt_690 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_698 = (arith_opt_690 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_699 = (arith_opt_691 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_700 = (arith_opt_697 ? arith_opt_698 : arith_opt_690); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_701 = (arith_opt_697 ? arith_opt_699 : arith_opt_691); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_702 = (arith_opt_695 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_703 = (arith_opt_695 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_704 = (arith_opt_696 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_705 = (arith_opt_702 ? arith_opt_703 : arith_opt_695); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_706 = (arith_opt_702 ? arith_opt_704 : arith_opt_696); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_707 = (arith_opt_700 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_708 = (arith_opt_700 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_709 = (arith_opt_701 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_710 = (arith_opt_707 ? arith_opt_708 : arith_opt_700); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_711 = (arith_opt_707 ? arith_opt_709 : arith_opt_701); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_712 = (arith_opt_478 ? arith_opt_462 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    assign arith_opt_713 = (arith_opt_795 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    assign arith_opt_714 = (arith_opt_713 - arith_opt_796); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    assign arith_opt_715 = (arith_opt_481 ? arith_opt_463 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    assign arith_opt_716 = (arith_opt_797 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    assign arith_opt_717 = (arith_opt_716 - arith_opt_798); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    assign arith_opt_718 = (arith_opt_714 + arith_opt_717); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_719 = (arith_opt_718 - 12'h27f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    assign arith_opt_720 = 48'(($unsigned(48'($unsigned(arith_opt_799))) * $unsigned(48'($unsigned(arith_opt_800))))); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_721 = arith_opt_720[47:17]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_722 = (arith_opt_801 != 17'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_723 = (arith_opt_721 | 31'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    assign arith_opt_724 = (arith_opt_722 ? arith_opt_723 : arith_opt_721); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    assign arith_opt_725 = (arith_opt_802 < 32'h40000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    assign arith_opt_726 = (arith_opt_802 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_727 = (arith_opt_719 - 12'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_728 = (arith_opt_725 ? arith_opt_727 : arith_opt_719); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    assign arith_opt_729 = (arith_opt_725 ? arith_opt_726 : ({1'h0, arith_opt_724})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_730 = (arith_opt_728 < 12'h200); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    assign arith_opt_731 = (arith_opt_728 < 12'h1ff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    assign arith_opt_732 = (!arith_opt_731); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    assign arith_opt_733 = (arith_opt_729 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    assign arith_opt_734 = (arith_opt_733 < 32'h80000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    assign arith_opt_735 = (arith_opt_728 > 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    assign arith_opt_736 = (!arith_opt_735); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_737 = (arith_opt_728 == 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    assign arith_opt_738 = (arith_opt_811 & arith_opt_737); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    assign arith_opt_739 = (!arith_opt_788); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_740 = (12'h200 - arith_opt_728); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_741 = (arith_opt_740 >= 12'h20); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_742 = (arith_opt_729 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    assign arith_opt_743 = (arith_opt_742 ? 1'(32'h1) : 1'(32'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    assign arith_opt_744 = (arith_opt_740 >= 12'd32 ? 32'h0 : (32'h1 << arith_opt_740)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    assign arith_opt_745 = (arith_opt_744 - 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    assign arith_opt_746 = (arith_opt_729 & arith_opt_745); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    assign arith_opt_747 = (arith_opt_746 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    assign arith_opt_748 = (arith_opt_740 >= 12'd32 ? 32'h0 : (arith_opt_729 >> arith_opt_740)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    assign arith_opt_749 = (arith_opt_748 | 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    assign arith_opt_750 = (arith_opt_787 ? arith_opt_749 : arith_opt_748); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_751 = (arith_opt_784 ? ({31'h0, arith_opt_743}) : arith_opt_750); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    assign arith_opt_752 = (arith_opt_803 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    assign arith_opt_753 = (arith_opt_816 ? 2'(5'h2) : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    assign arith_opt_754 = (arith_opt_730 ? 9'(12'h200) : arith_opt_728[8:0]); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    assign arith_opt_755 = (arith_opt_730 ? arith_opt_751 : arith_opt_729); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_756 = (arith_opt_730 ? arith_opt_753 : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    assign arith_opt_757 = arith_opt_755[6:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    assign arith_opt_758 = (arith_opt_755 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_759 = arith_opt_758[31:7]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    assign arith_opt_760 = (arith_opt_757 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    assign arith_opt_761 = (arith_opt_756 | 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    assign arith_opt_762 = (arith_opt_760 ? arith_opt_761 : arith_opt_756); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    assign arith_opt_763 = (arith_opt_757 == 7'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    assign arith_opt_764 = (arith_opt_759 & 25'h1fffffe); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_765 = (arith_opt_763 ? arith_opt_764 : arith_opt_759); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    assign arith_opt_766 = 9'((arith_opt_804 - 10'h200)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    assign arith_opt_767 = (arith_opt_765 == 25'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    assign arith_opt_768 = (arith_opt_767 ? 9'(32'h0) : arith_opt_766); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    assign arith_opt_769 = (arith_opt_883 << 5'h1f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    assign arith_opt_770 = (arith_opt_806 << 5'h17); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_771 = (arith_opt_770 + arith_opt_805); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_772 = (arith_opt_769 | arith_opt_771); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    assign arith_opt_773 = (arith_opt_769 | 32'h7f800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    assign arith_opt_774 = (arith_opt_739 ? 3'(5'h5) : ({1'h0, arith_opt_762})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    assign arith_opt_775 = (!arith_opt_466); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    assign arith_opt_776 = (arith_opt_818 ? 3'(5'h0) : arith_opt_774); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    assign arith_opt_777 = (arith_opt_819 ? 5'h10 : 5'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    assign arith_opt_778 = (arith_opt_813 ? ({2'h0, arith_opt_776}) : arith_opt_777); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
        unique case (1'b1)
            arith_opt_854: arith_opt_779 = 5'h10;
            arith_opt_860: arith_opt_779 = 5'h0;
            default: arith_opt_779 = arith_opt_778;
        endcase
    end
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
        unique case (1'b1)
            arith_opt_861: arith_opt_780 = 32'h7fc00000;
            arith_opt_863: arith_opt_780 = arith_opt_769;
            arith_opt_880: arith_opt_780 = arith_opt_772;
            arith_opt_882: arith_opt_780 = 32'h7fc00000;
            default: arith_opt_780 = arith_opt_773;
        endcase
    end
    assign arith_opt_781 = {arith_opt_779, arith_opt_780}; // decl: <none>; prim: <none>
    assign arith_opt_782 = (!arith_opt_468); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    assign arith_opt_783 = (!arith_opt_471); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    assign arith_opt_784 = (arith_opt_730 & arith_opt_741); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_785 = (!arith_opt_741); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_786 = (arith_opt_730 & arith_opt_785); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_787 = (arith_opt_747 & arith_opt_786); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    assign arith_opt_788 = (arith_opt_736 & arith_opt_812); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    assign arith_opt_789 = (arith_opt_782 & arith_opt_783); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    assign arith_opt_790 = (arith_opt_809 & arith_opt_810); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    assign arith_opt_791 = a[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_792 = b[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_793 = (arith_opt_807 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_794 = (arith_opt_808 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_795 = ({2'h0, arith_opt_712}); // decl: <none>; prim: <none>
    assign arith_opt_796 = ({3'h0, arith_opt_706}); // decl: <none>; prim: <none>
    assign arith_opt_797 = ({2'h0, arith_opt_715}); // decl: <none>; prim: <none>
    assign arith_opt_798 = ({3'h0, arith_opt_711}); // decl: <none>; prim: <none>
    assign arith_opt_799 = ({24'h0, arith_opt_705}); // decl: <none>; prim: <none>
    assign arith_opt_800 = ({24'h0, arith_opt_710}); // decl: <none>; prim: <none>
    assign arith_opt_801 = arith_opt_720[16:0]; // decl: <none>; prim: <none>
    assign arith_opt_802 = ({1'h0, arith_opt_724}); // decl: <none>; prim: <none>
    assign arith_opt_803 = arith_opt_751[6:0]; // decl: <none>; prim: <none>
    assign arith_opt_804 = ({1'h0, arith_opt_754}); // decl: <none>; prim: <none>
    assign arith_opt_805 = ({7'h0, arith_opt_765}); // decl: <none>; prim: <none>
    assign arith_opt_806 = ({23'h0, arith_opt_768}); // decl: <none>; prim: <none>
    assign arith_opt_807 = a[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_808 = b[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_809 = (!arith_opt_476); // decl: <none>; prim: <none>
    assign arith_opt_810 = (!arith_opt_477); // decl: <none>; prim: <none>
    assign arith_opt_811 = (!arith_opt_734); // decl: <none>; prim: <none>
    assign arith_opt_812 = (!arith_opt_738); // decl: <none>; prim: <none>
    assign arith_opt_813 = (arith_opt_775 & arith_opt_817); // decl: <none>; prim: <none>
    assign arith_opt_814 = (arith_opt_811 & arith_opt_732); // decl: <none>; prim: <none>
    assign arith_opt_815 = (!arith_opt_814); // decl: <none>; prim: <none>
    assign arith_opt_816 = (arith_opt_815 & arith_opt_752); // decl: <none>; prim: <none>
    assign arith_opt_817 = (!arith_opt_469); // decl: <none>; prim: <none>
    assign arith_opt_818 = arith_opt_864; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_819 = (arith_opt_864 & arith_opt_789); // decl: <none>; prim: <none>
    assign arith_opt_820 = a[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_821 = a[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_822 = (arith_opt_820 & arith_opt_821); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_823 = a[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_824 = a[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_825 = (arith_opt_823 & arith_opt_824); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_826 = (arith_opt_822 & arith_opt_825); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_827 = a[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_828 = a[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_829 = (arith_opt_827 & arith_opt_828); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_830 = a[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_831 = a[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_832 = (arith_opt_830 & arith_opt_831); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_833 = (arith_opt_829 & arith_opt_832); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_834 = (arith_opt_826 & arith_opt_833); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_835 = (arith_opt_834 & arith_opt_467); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_836 = (arith_opt_835 & arith_opt_473); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_837 = b[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_838 = b[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_839 = (arith_opt_837 & arith_opt_838); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_840 = b[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_841 = b[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_842 = (arith_opt_840 & arith_opt_841); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_843 = (arith_opt_839 & arith_opt_842); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_844 = b[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_845 = b[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_846 = (arith_opt_844 & arith_opt_845); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_847 = b[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_848 = b[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_849 = (arith_opt_847 & arith_opt_848); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_850 = (arith_opt_846 & arith_opt_849); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_851 = (arith_opt_843 & arith_opt_850); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_852 = (arith_opt_851 & arith_opt_470); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_853 = (arith_opt_852 & arith_opt_475); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_854 = (!arith_opt_906); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_855 = (!arith_opt_834); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_856 = (!arith_opt_835); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_857 = (!arith_opt_851); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_858 = (!arith_opt_852); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_859 = (arith_opt_856 & arith_opt_858); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_860 = (arith_opt_906 & arith_opt_861); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_861 = (!arith_opt_859); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_862 = (!arith_opt_881); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_863 = (arith_opt_864 & arith_opt_881); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_864 = (!arith_opt_790); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_865 = arith_opt_728[6]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_866 = arith_opt_728[7]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_867 = arith_opt_728[9]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_868 = arith_opt_728[1]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_869 = arith_opt_728[8]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_870 = arith_opt_728[2]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_871 = arith_opt_728[3]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_872 = arith_opt_728[4]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_873 = arith_opt_728[5]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_874 = arith_opt_728[10]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_875 = arith_opt_728[11]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_876 = arith_opt_728[0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_877 = (!arith_opt_902); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_878 = (arith_opt_736 & arith_opt_877); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_879 = (arith_opt_886 & arith_opt_903); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_880 = (arith_opt_788 & arith_opt_886); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_881 = (arith_opt_855 & arith_opt_857); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_882 = (arith_opt_859 & arith_opt_885); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_883 = (arith_opt_884 & 32'h1); // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_884 = ({31'h0, arith_opt_461}); // decl: <none>; prim: <none>
    assign arith_opt_885 = (arith_opt_864 & arith_opt_862); // decl: <none>; prim: <none>
    assign arith_opt_886 = (arith_opt_790 & arith_opt_881); // decl: <none>; prim: <none>
    assign arith_opt_887 = (arith_opt_865 & arith_opt_866); // decl: <none>; prim: <none>
    assign arith_opt_888 = (!arith_opt_868); // decl: <none>; prim: <none>
    assign arith_opt_889 = (!arith_opt_869); // decl: <none>; prim: <none>
    assign arith_opt_890 = (arith_opt_888 & arith_opt_889); // decl: <none>; prim: <none>
    assign arith_opt_891 = (arith_opt_867 & arith_opt_890); // decl: <none>; prim: <none>
    assign arith_opt_892 = (arith_opt_887 & arith_opt_891); // decl: <none>; prim: <none>
    assign arith_opt_893 = (arith_opt_870 & arith_opt_871); // decl: <none>; prim: <none>
    assign arith_opt_894 = (arith_opt_872 & arith_opt_873); // decl: <none>; prim: <none>
    assign arith_opt_895 = (arith_opt_893 & arith_opt_894); // decl: <none>; prim: <none>
    assign arith_opt_896 = (!arith_opt_874); // decl: <none>; prim: <none>
    assign arith_opt_897 = (!arith_opt_875); // decl: <none>; prim: <none>
    assign arith_opt_898 = (arith_opt_896 & arith_opt_897); // decl: <none>; prim: <none>
    assign arith_opt_899 = (arith_opt_811 & arith_opt_876); // decl: <none>; prim: <none>
    assign arith_opt_900 = (arith_opt_898 & arith_opt_899); // decl: <none>; prim: <none>
    assign arith_opt_901 = (arith_opt_895 & arith_opt_900); // decl: <none>; prim: <none>
    assign arith_opt_902 = (arith_opt_892 & arith_opt_901); // decl: <none>; prim: <none>
    assign arith_opt_903 = (!arith_opt_878); // decl: <none>; prim: <none>
    assign arith_opt_904 = (!arith_opt_836); // decl: <none>; prim: <none>
    assign arith_opt_905 = (!arith_opt_853); // decl: <none>; prim: <none>
    assign arith_opt_906 = (arith_opt_904 & arith_opt_905); // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_8_s1 <= 37'h107fc00000;
            rtlzz_pipe_8_s2 <= 37'h107fc00000;
            rtlzz_pipe_8_s3 <= 37'h107fc00000;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_8_s1 <= arith_5_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_8_s2 <= rtlzz_pipe_8_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_8_s3 <= rtlzz_pipe_8_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        end
    end
endmodule
