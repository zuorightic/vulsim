`timescale 1ns/1ps

module serial_pipe(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:12
    input logic [31:0] c, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14
    input logic [31:0] d, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:16
    output logic [36:0] y, // decl: <none>; prim: <none>
    output logic [36:0] z, // decl: <none>; prim: <none>
    input logic iv, // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    output logic ov, // decl: <none>; prim: <none>
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] tmp_serial_int_32__2_v0; // decl: <none>; prim: <none>
    logic [36:0] arith_5_335; // decl: <none>; prim: <none>
    logic [36:0] arith_7_335; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_913; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:12:43-12:53; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:12:43-12:53
    logic [31:0] arith_opt_914; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    logic arith_opt_915; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic [7:0] arith_opt_916; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [7:0] arith_opt_917; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    logic [22:0] arith_opt_918; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_919; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_920; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic arith_opt_921; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_922; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    logic arith_opt_923; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic arith_opt_924; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_925; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    logic [22:0] arith_opt_926; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_927; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_928; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_929; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_930; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic arith_opt_931; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    logic arith_opt_932; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic [23:0] arith_opt_933; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_934; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    logic arith_opt_935; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic [23:0] arith_opt_936; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_937; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    logic arith_opt_938; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_939; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [23:0] arith_opt_940; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_941; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_942; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_943; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [23:0] arith_opt_944; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_945; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_946; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_947; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [1:0] arith_opt_948; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_949; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_950; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_951; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_952; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [1:0] arith_opt_953; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_954; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_955; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_956; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_957; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [2:0] arith_opt_958; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_959; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_960; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_961; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_962; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [2:0] arith_opt_963; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_964; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_965; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_966; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_967; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [3:0] arith_opt_968; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_969; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_970; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_971; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_972; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [3:0] arith_opt_973; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_974; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_975; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_976; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_977; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [4:0] arith_opt_978; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_979; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_980; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_981; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_982; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [4:0] arith_opt_983; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_984; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_985; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_986; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_987; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [5:0] arith_opt_988; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_989; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_990; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_991; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_992; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [5:0] arith_opt_993; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_994; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_995; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_996; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_997; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [6:0] arith_opt_998; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_999; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_1000; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1001; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1002; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [6:0] arith_opt_1003; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1004; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_1005; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1006; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1007; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1008; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1009; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1010; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1011; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1012; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1013; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1014; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1015; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1016; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1017; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1018; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1019; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1020; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1021; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1022; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1023; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1024; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1025; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1026; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1027; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1028; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1029; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1030; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1031; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1032; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1033; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1034; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1035; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1036; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1037; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1038; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1039; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1040; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1041; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1042; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1043; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1044; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1045; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1046; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1047; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1048; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1049; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1050; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1051; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1052; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1053; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1054; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1055; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1056; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1057; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1058; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1059; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1060; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1061; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1062; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1063; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1064; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1065; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1066; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1067; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1068; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1069; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1070; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1071; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1072; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1073; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1074; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1075; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1076; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1077; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1078; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1079; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1080; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1081; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1082; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1083; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1084; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1085; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1086; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1087; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1088; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1089; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1090; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1091; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1092; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1093; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1094; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1095; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1096; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1097; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1098; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1099; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1100; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1101; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1102; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1103; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1104; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1105; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1106; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1107; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1108; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1109; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1110; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1111; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1112; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1113; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1114; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1115; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1116; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1117; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1118; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1119; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1120; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1121; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1122; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1123; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1124; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1125; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1126; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1127; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1128; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1129; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1130; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1131; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1132; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1133; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1134; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1135; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1136; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1137; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1138; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1139; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1140; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1141; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1142; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1143; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1144; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1145; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1146; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1147; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1148; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1149; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1150; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1151; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1152; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1153; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1154; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1155; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1156; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1157; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1158; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1159; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1160; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1161; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1162; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1163; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1164; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1165; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic [7:0] arith_opt_1166; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    logic [10:0] arith_opt_1167; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    logic [11:0] arith_opt_1168; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    logic [7:0] arith_opt_1169; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    logic [10:0] arith_opt_1170; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    logic [11:0] arith_opt_1171; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    logic [11:0] arith_opt_1172; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_1173; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    logic [47:0] arith_opt_1174; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_1175; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic arith_opt_1176; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_1177; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    logic [30:0] arith_opt_1178; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    logic arith_opt_1179; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    logic [31:0] arith_opt_1180; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic [11:0] arith_opt_1181; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_1182; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    logic [31:0] arith_opt_1183; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic arith_opt_1184; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    logic arith_opt_1185; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    logic arith_opt_1186; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    logic [31:0] arith_opt_1187; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    logic arith_opt_1188; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    logic arith_opt_1189; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    logic arith_opt_1190; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic arith_opt_1191; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    logic arith_opt_1192; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    logic arith_opt_1193; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic [11:0] arith_opt_1194; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_1195; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_1196; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    logic arith_opt_1197; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    logic [31:0] arith_opt_1198; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    logic [31:0] arith_opt_1199; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    logic [31:0] arith_opt_1200; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    logic arith_opt_1201; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    logic [31:0] arith_opt_1202; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    logic [31:0] arith_opt_1203; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    logic [31:0] arith_opt_1204; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [31:0] arith_opt_1205; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    logic arith_opt_1206; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    logic [1:0] arith_opt_1207; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    logic [8:0] arith_opt_1208; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    logic [31:0] arith_opt_1209; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [1:0] arith_opt_1210; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    logic [6:0] arith_opt_1211; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    logic [31:0] arith_opt_1212; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_1213; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    logic arith_opt_1214; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    logic [1:0] arith_opt_1215; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    logic [1:0] arith_opt_1216; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    logic arith_opt_1217; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    logic [24:0] arith_opt_1218; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_1219; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    logic [8:0] arith_opt_1220; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    logic arith_opt_1221; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    logic [8:0] arith_opt_1222; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    logic [31:0] arith_opt_1223; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    logic [31:0] arith_opt_1224; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_1225; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_1226; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    logic [31:0] arith_opt_1227; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    logic [2:0] arith_opt_1228; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    logic arith_opt_1229; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    logic [2:0] arith_opt_1230; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    logic [4:0] arith_opt_1231; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    logic [4:0] arith_opt_1232; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [4:0] arith_opt_1233; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [31:0] arith_opt_1234; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [36:0] arith_opt_1235; // decl: <none>; prim: <none>
    logic arith_opt_1236; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    logic arith_opt_1237; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    logic arith_opt_1238; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1239; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1240; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1241; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    logic arith_opt_1242; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    logic arith_opt_1243; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    logic arith_opt_1244; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    logic [30:0] arith_opt_1245; // decl: <none>; prim: <none>
    logic [30:0] arith_opt_1246; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1247; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic [23:0] arith_opt_1248; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic [9:0] arith_opt_1249; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_1250; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_1251; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_1252; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_1253; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_1254; // decl: <none>; prim: <none>
    logic [16:0] arith_opt_1255; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1256; // decl: <none>; prim: <none>
    logic [6:0] arith_opt_1257; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_1258; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1259; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1260; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1261; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1262; // decl: <none>; prim: <none>
    logic arith_opt_1263; // decl: <none>; prim: <none>
    logic arith_opt_1264; // decl: <none>; prim: <none>
    logic arith_opt_1265; // decl: <none>; prim: <none>
    logic arith_opt_1266; // decl: <none>; prim: <none>
    logic arith_opt_1267; // decl: <none>; prim: <none>
    logic arith_opt_1268; // decl: <none>; prim: <none>
    logic arith_opt_1269; // decl: <none>; prim: <none>
    logic arith_opt_1270; // decl: <none>; prim: <none>
    logic arith_opt_1271; // decl: <none>; prim: <none>
    logic arith_opt_1272; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1273; // decl: <none>; prim: <none>
    logic arith_opt_1274; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1275; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1276; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1277; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1278; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1279; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1280; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1281; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1282; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1283; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1284; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1285; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1286; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1287; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1288; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1289; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1290; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1291; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1292; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1293; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1294; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1295; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1296; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1297; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1298; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1299; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1300; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1301; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1302; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1303; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1304; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1305; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1306; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1307; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1308; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1309; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1310; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1311; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1312; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1313; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1314; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1315; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1316; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1317; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1318; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1319; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1320; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1321; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1322; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1323; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1324; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1325; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1326; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1327; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1328; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1329; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1330; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1331; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1332; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1333; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1334; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1335; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1336; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [31:0] arith_opt_1337; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [31:0] arith_opt_1338; // decl: <none>; prim: <none>
    logic arith_opt_1339; // decl: <none>; prim: <none>
    logic arith_opt_1340; // decl: <none>; prim: <none>
    logic arith_opt_1341; // decl: <none>; prim: <none>
    logic arith_opt_1342; // decl: <none>; prim: <none>
    logic arith_opt_1343; // decl: <none>; prim: <none>
    logic arith_opt_1344; // decl: <none>; prim: <none>
    logic arith_opt_1345; // decl: <none>; prim: <none>
    logic arith_opt_1346; // decl: <none>; prim: <none>
    logic arith_opt_1347; // decl: <none>; prim: <none>
    logic arith_opt_1348; // decl: <none>; prim: <none>
    logic arith_opt_1349; // decl: <none>; prim: <none>
    logic arith_opt_1350; // decl: <none>; prim: <none>
    logic arith_opt_1351; // decl: <none>; prim: <none>
    logic arith_opt_1352; // decl: <none>; prim: <none>
    logic arith_opt_1353; // decl: <none>; prim: <none>
    logic arith_opt_1354; // decl: <none>; prim: <none>
    logic arith_opt_1355; // decl: <none>; prim: <none>
    logic arith_opt_1356; // decl: <none>; prim: <none>
    logic arith_opt_1357; // decl: <none>; prim: <none>
    logic arith_opt_1358; // decl: <none>; prim: <none>
    logic arith_opt_1359; // decl: <none>; prim: <none>
    logic arith_opt_1360; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1361; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    logic arith_opt_1362; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic [7:0] arith_opt_1363; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [7:0] arith_opt_1364; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    logic [22:0] arith_opt_1365; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_1366; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_1367; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic arith_opt_1368; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_1369; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    logic arith_opt_1370; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic arith_opt_1371; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_1372; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    logic [22:0] arith_opt_1373; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic arith_opt_1374; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    logic [22:0] arith_opt_1375; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic arith_opt_1376; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    logic arith_opt_1377; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    logic arith_opt_1378; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    logic arith_opt_1379; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    logic [23:0] arith_opt_1380; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_1381; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    logic arith_opt_1382; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    logic [23:0] arith_opt_1383; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    logic [23:0] arith_opt_1384; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    logic arith_opt_1385; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1386; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [23:0] arith_opt_1387; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_1388; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1389; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1390; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [23:0] arith_opt_1391; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic arith_opt_1392; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1393; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1394; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [1:0] arith_opt_1395; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1396; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_1397; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1398; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1399; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [1:0] arith_opt_1400; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1401; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [1:0] arith_opt_1402; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1403; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1404; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [2:0] arith_opt_1405; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1406; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_1407; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1408; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1409; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [2:0] arith_opt_1410; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1411; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [2:0] arith_opt_1412; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1413; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1414; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [3:0] arith_opt_1415; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1416; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_1417; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1418; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1419; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [3:0] arith_opt_1420; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1421; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [3:0] arith_opt_1422; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1423; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1424; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [4:0] arith_opt_1425; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1426; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_1427; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1428; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1429; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [4:0] arith_opt_1430; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1431; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [4:0] arith_opt_1432; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1433; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1434; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [5:0] arith_opt_1435; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1436; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_1437; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1438; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1439; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [5:0] arith_opt_1440; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1441; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [5:0] arith_opt_1442; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1443; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1444; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [6:0] arith_opt_1445; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1446; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_1447; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1448; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1449; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [6:0] arith_opt_1450; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1451; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [6:0] arith_opt_1452; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1453; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1454; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1455; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    logic [23:0] arith_opt_1456; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1457; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    logic arith_opt_1458; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1459; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1460; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    logic [23:0] arith_opt_1461; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1462; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    logic arith_opt_1463; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1464; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1465; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1466; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1467; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1468; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1469; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1470; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1471; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1472; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1473; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1474; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1475; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1476; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1477; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1478; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1479; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1480; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1481; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1482; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1483; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1484; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1485; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1486; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1487; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1488; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1489; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1490; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1491; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1492; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1493; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1494; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1495; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1496; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1497; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1498; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1499; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1500; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1501; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1502; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1503; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1504; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1505; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1506; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1507; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1508; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1509; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1510; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1511; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1512; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1513; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1514; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1515; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1516; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1517; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1518; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1519; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1520; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1521; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1522; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1523; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1524; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1525; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1526; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1527; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1528; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1529; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1530; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1531; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1532; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1533; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1534; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1535; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1536; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1537; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1538; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1539; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1540; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1541; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1542; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1543; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1544; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1545; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1546; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1547; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1548; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1549; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1550; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1551; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1552; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1553; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1554; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1555; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1556; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1557; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1558; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1559; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1560; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1561; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1562; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1563; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1564; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1565; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1566; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1567; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1568; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1569; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1570; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1571; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1572; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1573; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1574; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1575; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1576; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1577; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1578; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1579; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1580; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1581; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1582; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1583; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1584; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1585; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1586; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1587; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1588; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1589; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1590; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1591; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1592; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1593; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1594; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1595; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1596; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1597; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1598; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1599; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1600; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1601; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1602; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1603; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    logic [23:0] arith_opt_1604; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    logic [7:0] arith_opt_1605; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    logic [23:0] arith_opt_1606; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1607; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic arith_opt_1608; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    logic [23:0] arith_opt_1609; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    logic [7:0] arith_opt_1610; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    logic [23:0] arith_opt_1611; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    logic [7:0] arith_opt_1612; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    logic [7:0] arith_opt_1613; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    logic [10:0] arith_opt_1614; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    logic [11:0] arith_opt_1615; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    logic [7:0] arith_opt_1616; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    logic [10:0] arith_opt_1617; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    logic [11:0] arith_opt_1618; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    logic [11:0] arith_opt_1619; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_1620; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    logic [47:0] arith_opt_1621; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_1622; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic arith_opt_1623; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    logic [30:0] arith_opt_1624; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    logic [30:0] arith_opt_1625; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    logic arith_opt_1626; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    logic [31:0] arith_opt_1627; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic [11:0] arith_opt_1628; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    logic [11:0] arith_opt_1629; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    logic [31:0] arith_opt_1630; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    logic arith_opt_1631; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    logic arith_opt_1632; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    logic arith_opt_1633; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    logic [31:0] arith_opt_1634; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    logic arith_opt_1635; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    logic arith_opt_1636; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    logic arith_opt_1637; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic arith_opt_1638; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    logic arith_opt_1639; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    logic arith_opt_1640; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    logic [11:0] arith_opt_1641; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_1642; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    logic arith_opt_1643; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    logic arith_opt_1644; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    logic [31:0] arith_opt_1645; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    logic [31:0] arith_opt_1646; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    logic [31:0] arith_opt_1647; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    logic arith_opt_1648; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    logic [31:0] arith_opt_1649; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    logic [31:0] arith_opt_1650; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    logic [31:0] arith_opt_1651; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [31:0] arith_opt_1652; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    logic arith_opt_1653; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    logic [1:0] arith_opt_1654; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    logic [8:0] arith_opt_1655; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    logic [31:0] arith_opt_1656; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    logic [1:0] arith_opt_1657; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    logic [6:0] arith_opt_1658; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    logic [31:0] arith_opt_1659; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_1660; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    logic arith_opt_1661; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    logic [1:0] arith_opt_1662; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    logic [1:0] arith_opt_1663; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    logic arith_opt_1664; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    logic [24:0] arith_opt_1665; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    logic [24:0] arith_opt_1666; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    logic [8:0] arith_opt_1667; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    logic arith_opt_1668; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    logic [8:0] arith_opt_1669; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    logic [31:0] arith_opt_1670; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    logic [31:0] arith_opt_1671; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_1672; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    logic [31:0] arith_opt_1673; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    logic [31:0] arith_opt_1674; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    logic [2:0] arith_opt_1675; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    logic arith_opt_1676; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    logic [2:0] arith_opt_1677; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    logic [4:0] arith_opt_1678; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    logic [4:0] arith_opt_1679; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [4:0] arith_opt_1680; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic [31:0] arith_opt_1681; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [36:0] arith_opt_1682; // decl: <none>; prim: <none>
    logic arith_opt_1683; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    logic arith_opt_1684; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    logic arith_opt_1685; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1686; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1687; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    logic arith_opt_1688; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    logic arith_opt_1689; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    logic arith_opt_1690; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    logic arith_opt_1691; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    logic [30:0] arith_opt_1692; // decl: <none>; prim: <none>
    logic [30:0] arith_opt_1693; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1694; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    logic [23:0] arith_opt_1695; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    logic [9:0] arith_opt_1696; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_1697; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_1698; // decl: <none>; prim: <none>
    logic [10:0] arith_opt_1699; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_1700; // decl: <none>; prim: <none>
    logic [47:0] arith_opt_1701; // decl: <none>; prim: <none>
    logic [16:0] arith_opt_1702; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1703; // decl: <none>; prim: <none>
    logic [6:0] arith_opt_1704; // decl: <none>; prim: <none>
    logic [9:0] arith_opt_1705; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1706; // decl: <none>; prim: <none>
    logic [31:0] arith_opt_1707; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1708; // decl: <none>; prim: <none>
    logic [23:0] arith_opt_1709; // decl: <none>; prim: <none>
    logic arith_opt_1710; // decl: <none>; prim: <none>
    logic arith_opt_1711; // decl: <none>; prim: <none>
    logic arith_opt_1712; // decl: <none>; prim: <none>
    logic arith_opt_1713; // decl: <none>; prim: <none>
    logic arith_opt_1714; // decl: <none>; prim: <none>
    logic arith_opt_1715; // decl: <none>; prim: <none>
    logic arith_opt_1716; // decl: <none>; prim: <none>
    logic arith_opt_1717; // decl: <none>; prim: <none>
    logic arith_opt_1718; // decl: <none>; prim: <none>
    logic arith_opt_1719; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1720; // decl: <none>; prim: <none>
    logic arith_opt_1721; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1722; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1723; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1724; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1725; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1726; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1727; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1728; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1729; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1730; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1731; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1732; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1733; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1734; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1735; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1736; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1737; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1738; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1739; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1740; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1741; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1742; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1743; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1744; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1745; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1746; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1747; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1748; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1749; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1750; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1751; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1752; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1753; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1754; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1755; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1756; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1757; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1758; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1759; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1760; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1761; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    logic arith_opt_1762; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1763; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1764; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1765; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1766; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1767; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1768; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1769; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1770; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1771; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1772; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1773; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1774; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1775; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1776; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1777; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1778; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1779; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1780; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1781; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1782; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic arith_opt_1783; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    logic [31:0] arith_opt_1784; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    logic [31:0] arith_opt_1785; // decl: <none>; prim: <none>
    logic arith_opt_1786; // decl: <none>; prim: <none>
    logic arith_opt_1787; // decl: <none>; prim: <none>
    logic arith_opt_1788; // decl: <none>; prim: <none>
    logic arith_opt_1789; // decl: <none>; prim: <none>
    logic arith_opt_1790; // decl: <none>; prim: <none>
    logic arith_opt_1791; // decl: <none>; prim: <none>
    logic arith_opt_1792; // decl: <none>; prim: <none>
    logic arith_opt_1793; // decl: <none>; prim: <none>
    logic arith_opt_1794; // decl: <none>; prim: <none>
    logic arith_opt_1795; // decl: <none>; prim: <none>
    logic arith_opt_1796; // decl: <none>; prim: <none>
    logic arith_opt_1797; // decl: <none>; prim: <none>
    logic arith_opt_1798; // decl: <none>; prim: <none>
    logic arith_opt_1799; // decl: <none>; prim: <none>
    logic arith_opt_1800; // decl: <none>; prim: <none>
    logic arith_opt_1801; // decl: <none>; prim: <none>
    logic arith_opt_1802; // decl: <none>; prim: <none>
    logic arith_opt_1803; // decl: <none>; prim: <none>
    logic arith_opt_1804; // decl: <none>; prim: <none>
    logic arith_opt_1805; // decl: <none>; prim: <none>
    logic arith_opt_1806; // decl: <none>; prim: <none>
    logic arith_opt_1807; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14
    logic [36:0] rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_9_s3; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_10_s2; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_10_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38


    assign tmp_serial_int_32__2_v0 = arith_opt_913; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_9_s3; // decl: <none>; prim: <none>
    assign z = rtlzz_pipe_10_s3; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign arith_5_335 = arith_opt_1235; // decl: <none>; prim: <none>
    assign arith_7_335 = arith_opt_1682; // decl: <none>; prim: <none>
    assign arith_opt_913 = rtlzz_pipe_9_s1[31:0]; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:12:43-12:53; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:12:43-12:53
    assign arith_opt_914 = (a ^ b); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    assign arith_opt_915 = arith_opt_914[31]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_916 = a[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_917 = b[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    assign arith_opt_918 = a[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_919 = b[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_920 = (arith_opt_916 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_921 = (arith_opt_918 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_922 = (arith_opt_920 & arith_opt_921); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    assign arith_opt_923 = (arith_opt_917 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_924 = (arith_opt_919 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_925 = (arith_opt_923 & arith_opt_924); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    assign arith_opt_926 = (arith_opt_918 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_927 = (arith_opt_926 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_928 = (arith_opt_919 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_929 = (arith_opt_928 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_930 = (arith_opt_1245 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_931 = (arith_opt_1246 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    assign arith_opt_932 = (arith_opt_916 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_933 = (arith_opt_1247 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_934 = (arith_opt_932 ? arith_opt_933 : ({1'h0, arith_opt_918})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    assign arith_opt_935 = (arith_opt_917 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_936 = (arith_opt_1248 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_937 = (arith_opt_935 ? arith_opt_936 : ({1'h0, arith_opt_919})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    assign arith_opt_938 = (arith_opt_934 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_939 = (arith_opt_934 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_940 = (arith_opt_938 ? arith_opt_939 : arith_opt_934); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_941 = (arith_opt_938 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_942 = (arith_opt_937 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_943 = (arith_opt_937 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_944 = (arith_opt_942 ? arith_opt_943 : arith_opt_937); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_945 = (arith_opt_942 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_946 = (arith_opt_940 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_947 = (arith_opt_940 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_948 = (arith_opt_941 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_949 = (arith_opt_946 ? arith_opt_947 : arith_opt_940); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_950 = (arith_opt_946 ? arith_opt_948 : ({1'h0, arith_opt_941})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_951 = (arith_opt_944 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_952 = (arith_opt_944 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_953 = (arith_opt_945 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_954 = (arith_opt_951 ? arith_opt_952 : arith_opt_944); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_955 = (arith_opt_951 ? arith_opt_953 : ({1'h0, arith_opt_945})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_956 = (arith_opt_949 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_957 = (arith_opt_949 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_958 = (arith_opt_950 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_959 = (arith_opt_956 ? arith_opt_957 : arith_opt_949); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_960 = (arith_opt_956 ? arith_opt_958 : ({1'h0, arith_opt_950})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_961 = (arith_opt_954 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_962 = (arith_opt_954 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_963 = (arith_opt_955 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_964 = (arith_opt_961 ? arith_opt_962 : arith_opt_954); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_965 = (arith_opt_961 ? arith_opt_963 : ({1'h0, arith_opt_955})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_966 = (arith_opt_959 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_967 = (arith_opt_959 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_968 = (arith_opt_960 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_969 = (arith_opt_966 ? arith_opt_967 : arith_opt_959); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_970 = (arith_opt_966 ? arith_opt_968 : ({1'h0, arith_opt_960})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_971 = (arith_opt_964 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_972 = (arith_opt_964 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_973 = (arith_opt_965 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_974 = (arith_opt_971 ? arith_opt_972 : arith_opt_964); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_975 = (arith_opt_971 ? arith_opt_973 : ({1'h0, arith_opt_965})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_976 = (arith_opt_969 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_977 = (arith_opt_969 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_978 = (arith_opt_970 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_979 = (arith_opt_976 ? arith_opt_977 : arith_opt_969); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_980 = (arith_opt_976 ? arith_opt_978 : ({1'h0, arith_opt_970})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_981 = (arith_opt_974 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_982 = (arith_opt_974 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_983 = (arith_opt_975 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_984 = (arith_opt_981 ? arith_opt_982 : arith_opt_974); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_985 = (arith_opt_981 ? arith_opt_983 : ({1'h0, arith_opt_975})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_986 = (arith_opt_979 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_987 = (arith_opt_979 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_988 = (arith_opt_980 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_989 = (arith_opt_986 ? arith_opt_987 : arith_opt_979); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_990 = (arith_opt_986 ? arith_opt_988 : ({1'h0, arith_opt_980})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_991 = (arith_opt_984 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_992 = (arith_opt_984 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_993 = (arith_opt_985 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_994 = (arith_opt_991 ? arith_opt_992 : arith_opt_984); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_995 = (arith_opt_991 ? arith_opt_993 : ({1'h0, arith_opt_985})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_996 = (arith_opt_989 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_997 = (arith_opt_989 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_998 = (arith_opt_990 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_999 = (arith_opt_996 ? arith_opt_997 : arith_opt_989); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1000 = (arith_opt_996 ? arith_opt_998 : ({1'h0, arith_opt_990})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1001 = (arith_opt_994 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1002 = (arith_opt_994 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1003 = (arith_opt_995 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1004 = (arith_opt_1001 ? arith_opt_1002 : arith_opt_994); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1005 = (arith_opt_1001 ? arith_opt_1003 : ({1'h0, arith_opt_995})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1006 = (arith_opt_999 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1007 = (arith_opt_999 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1008 = (arith_opt_1000 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1009 = (arith_opt_1006 ? arith_opt_1007 : arith_opt_999); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1010 = (arith_opt_1006 ? arith_opt_1008 : ({1'h0, arith_opt_1000})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1011 = (arith_opt_1004 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1012 = (arith_opt_1004 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1013 = (arith_opt_1005 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1014 = (arith_opt_1011 ? arith_opt_1012 : arith_opt_1004); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1015 = (arith_opt_1011 ? arith_opt_1013 : ({1'h0, arith_opt_1005})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1016 = (arith_opt_1009 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1017 = (arith_opt_1009 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1018 = (arith_opt_1010 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1019 = (arith_opt_1016 ? arith_opt_1017 : arith_opt_1009); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1020 = (arith_opt_1016 ? arith_opt_1018 : arith_opt_1010); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1021 = (arith_opt_1014 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1022 = (arith_opt_1014 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1023 = (arith_opt_1015 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1024 = (arith_opt_1021 ? arith_opt_1022 : arith_opt_1014); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1025 = (arith_opt_1021 ? arith_opt_1023 : arith_opt_1015); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1026 = (arith_opt_1019 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1027 = (arith_opt_1019 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1028 = (arith_opt_1020 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1029 = (arith_opt_1026 ? arith_opt_1027 : arith_opt_1019); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1030 = (arith_opt_1026 ? arith_opt_1028 : arith_opt_1020); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1031 = (arith_opt_1024 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1032 = (arith_opt_1024 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1033 = (arith_opt_1025 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1034 = (arith_opt_1031 ? arith_opt_1032 : arith_opt_1024); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1035 = (arith_opt_1031 ? arith_opt_1033 : arith_opt_1025); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1036 = (arith_opt_1029 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1037 = (arith_opt_1029 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1038 = (arith_opt_1030 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1039 = (arith_opt_1036 ? arith_opt_1037 : arith_opt_1029); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1040 = (arith_opt_1036 ? arith_opt_1038 : arith_opt_1030); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1041 = (arith_opt_1034 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1042 = (arith_opt_1034 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1043 = (arith_opt_1035 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1044 = (arith_opt_1041 ? arith_opt_1042 : arith_opt_1034); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1045 = (arith_opt_1041 ? arith_opt_1043 : arith_opt_1035); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1046 = (arith_opt_1039 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1047 = (arith_opt_1039 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1048 = (arith_opt_1040 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1049 = (arith_opt_1046 ? arith_opt_1047 : arith_opt_1039); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1050 = (arith_opt_1046 ? arith_opt_1048 : arith_opt_1040); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1051 = (arith_opt_1044 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1052 = (arith_opt_1044 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1053 = (arith_opt_1045 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1054 = (arith_opt_1051 ? arith_opt_1052 : arith_opt_1044); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1055 = (arith_opt_1051 ? arith_opt_1053 : arith_opt_1045); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1056 = (arith_opt_1049 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1057 = (arith_opt_1049 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1058 = (arith_opt_1050 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1059 = (arith_opt_1056 ? arith_opt_1057 : arith_opt_1049); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1060 = (arith_opt_1056 ? arith_opt_1058 : arith_opt_1050); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1061 = (arith_opt_1054 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1062 = (arith_opt_1054 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1063 = (arith_opt_1055 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1064 = (arith_opt_1061 ? arith_opt_1062 : arith_opt_1054); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1065 = (arith_opt_1061 ? arith_opt_1063 : arith_opt_1055); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1066 = (arith_opt_1059 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1067 = (arith_opt_1059 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1068 = (arith_opt_1060 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1069 = (arith_opt_1066 ? arith_opt_1067 : arith_opt_1059); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1070 = (arith_opt_1066 ? arith_opt_1068 : arith_opt_1060); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1071 = (arith_opt_1064 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1072 = (arith_opt_1064 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1073 = (arith_opt_1065 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1074 = (arith_opt_1071 ? arith_opt_1072 : arith_opt_1064); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1075 = (arith_opt_1071 ? arith_opt_1073 : arith_opt_1065); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1076 = (arith_opt_1069 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1077 = (arith_opt_1069 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1078 = (arith_opt_1070 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1079 = (arith_opt_1076 ? arith_opt_1077 : arith_opt_1069); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1080 = (arith_opt_1076 ? arith_opt_1078 : arith_opt_1070); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1081 = (arith_opt_1074 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1082 = (arith_opt_1074 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1083 = (arith_opt_1075 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1084 = (arith_opt_1081 ? arith_opt_1082 : arith_opt_1074); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1085 = (arith_opt_1081 ? arith_opt_1083 : arith_opt_1075); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1086 = (arith_opt_1079 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1087 = (arith_opt_1079 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1088 = (arith_opt_1080 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1089 = (arith_opt_1086 ? arith_opt_1087 : arith_opt_1079); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1090 = (arith_opt_1086 ? arith_opt_1088 : arith_opt_1080); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1091 = (arith_opt_1084 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1092 = (arith_opt_1084 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1093 = (arith_opt_1085 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1094 = (arith_opt_1091 ? arith_opt_1092 : arith_opt_1084); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1095 = (arith_opt_1091 ? arith_opt_1093 : arith_opt_1085); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1096 = (arith_opt_1089 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1097 = (arith_opt_1089 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1098 = (arith_opt_1090 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1099 = (arith_opt_1096 ? arith_opt_1097 : arith_opt_1089); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1100 = (arith_opt_1096 ? arith_opt_1098 : arith_opt_1090); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1101 = (arith_opt_1094 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1102 = (arith_opt_1094 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1103 = (arith_opt_1095 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1104 = (arith_opt_1101 ? arith_opt_1102 : arith_opt_1094); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1105 = (arith_opt_1101 ? arith_opt_1103 : arith_opt_1095); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1106 = (arith_opt_1099 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1107 = (arith_opt_1099 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1108 = (arith_opt_1100 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1109 = (arith_opt_1106 ? arith_opt_1107 : arith_opt_1099); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1110 = (arith_opt_1106 ? arith_opt_1108 : arith_opt_1100); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1111 = (arith_opt_1104 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1112 = (arith_opt_1104 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1113 = (arith_opt_1105 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1114 = (arith_opt_1111 ? arith_opt_1112 : arith_opt_1104); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1115 = (arith_opt_1111 ? arith_opt_1113 : arith_opt_1105); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1116 = (arith_opt_1109 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1117 = (arith_opt_1109 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1118 = (arith_opt_1110 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1119 = (arith_opt_1116 ? arith_opt_1117 : arith_opt_1109); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1120 = (arith_opt_1116 ? arith_opt_1118 : arith_opt_1110); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1121 = (arith_opt_1114 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1122 = (arith_opt_1114 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1123 = (arith_opt_1115 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1124 = (arith_opt_1121 ? arith_opt_1122 : arith_opt_1114); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1125 = (arith_opt_1121 ? arith_opt_1123 : arith_opt_1115); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1126 = (arith_opt_1119 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1127 = (arith_opt_1119 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1128 = (arith_opt_1120 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1129 = (arith_opt_1126 ? arith_opt_1127 : arith_opt_1119); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1130 = (arith_opt_1126 ? arith_opt_1128 : arith_opt_1120); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1131 = (arith_opt_1124 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1132 = (arith_opt_1124 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1133 = (arith_opt_1125 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1134 = (arith_opt_1131 ? arith_opt_1132 : arith_opt_1124); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1135 = (arith_opt_1131 ? arith_opt_1133 : arith_opt_1125); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1136 = (arith_opt_1129 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1137 = (arith_opt_1129 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1138 = (arith_opt_1130 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1139 = (arith_opt_1136 ? arith_opt_1137 : arith_opt_1129); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1140 = (arith_opt_1136 ? arith_opt_1138 : arith_opt_1130); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1141 = (arith_opt_1134 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1142 = (arith_opt_1134 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1143 = (arith_opt_1135 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1144 = (arith_opt_1141 ? arith_opt_1142 : arith_opt_1134); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1145 = (arith_opt_1141 ? arith_opt_1143 : arith_opt_1135); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1146 = (arith_opt_1139 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1147 = (arith_opt_1139 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1148 = (arith_opt_1140 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1149 = (arith_opt_1146 ? arith_opt_1147 : arith_opt_1139); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1150 = (arith_opt_1146 ? arith_opt_1148 : arith_opt_1140); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1151 = (arith_opt_1144 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1152 = (arith_opt_1144 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1153 = (arith_opt_1145 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1154 = (arith_opt_1151 ? arith_opt_1152 : arith_opt_1144); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1155 = (arith_opt_1151 ? arith_opt_1153 : arith_opt_1145); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1156 = (arith_opt_1149 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1157 = (arith_opt_1149 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1158 = (arith_opt_1150 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1159 = (arith_opt_1156 ? arith_opt_1157 : arith_opt_1149); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1160 = (arith_opt_1156 ? arith_opt_1158 : arith_opt_1150); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1161 = (arith_opt_1154 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1162 = (arith_opt_1154 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1163 = (arith_opt_1155 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1164 = (arith_opt_1161 ? arith_opt_1162 : arith_opt_1154); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1165 = (arith_opt_1161 ? arith_opt_1163 : arith_opt_1155); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1166 = (arith_opt_932 ? arith_opt_916 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    assign arith_opt_1167 = (arith_opt_1249 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    assign arith_opt_1168 = (arith_opt_1167 - arith_opt_1250); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    assign arith_opt_1169 = (arith_opt_935 ? arith_opt_917 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    assign arith_opt_1170 = (arith_opt_1251 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    assign arith_opt_1171 = (arith_opt_1170 - arith_opt_1252); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    assign arith_opt_1172 = (arith_opt_1168 + arith_opt_1171); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_1173 = (arith_opt_1172 - 12'h27f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    assign arith_opt_1174 = 48'(($unsigned(48'($unsigned(arith_opt_1253))) * $unsigned(48'($unsigned(arith_opt_1254))))); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1175 = arith_opt_1174[47:17]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1176 = (arith_opt_1255 != 17'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1177 = (arith_opt_1175 | 31'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    assign arith_opt_1178 = (arith_opt_1176 ? arith_opt_1177 : arith_opt_1175); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    assign arith_opt_1179 = (arith_opt_1256 < 32'h40000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    assign arith_opt_1180 = (arith_opt_1256 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_1181 = (arith_opt_1173 - 12'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_1182 = (arith_opt_1179 ? arith_opt_1181 : arith_opt_1173); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    assign arith_opt_1183 = (arith_opt_1179 ? arith_opt_1180 : ({1'h0, arith_opt_1178})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_1184 = (arith_opt_1182 < 12'h200); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    assign arith_opt_1185 = (arith_opt_1182 < 12'h1ff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    assign arith_opt_1186 = (!arith_opt_1185); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    assign arith_opt_1187 = (arith_opt_1183 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    assign arith_opt_1188 = (arith_opt_1187 < 32'h80000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    assign arith_opt_1189 = (arith_opt_1182 > 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    assign arith_opt_1190 = (!arith_opt_1189); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_1191 = (arith_opt_1182 == 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    assign arith_opt_1192 = (arith_opt_1265 & arith_opt_1191); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    assign arith_opt_1193 = (!arith_opt_1242); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_1194 = (12'h200 - arith_opt_1182); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_1195 = (arith_opt_1194 >= 12'h20); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_1196 = (arith_opt_1183 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    assign arith_opt_1197 = (arith_opt_1196 ? 1'(32'h1) : 1'(32'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    assign arith_opt_1198 = (arith_opt_1194 >= 12'd32 ? 32'h0 : (32'h1 << arith_opt_1194)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    assign arith_opt_1199 = (arith_opt_1198 - 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    assign arith_opt_1200 = (arith_opt_1183 & arith_opt_1199); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    assign arith_opt_1201 = (arith_opt_1200 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    assign arith_opt_1202 = (arith_opt_1194 >= 12'd32 ? 32'h0 : (arith_opt_1183 >> arith_opt_1194)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    assign arith_opt_1203 = (arith_opt_1202 | 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    assign arith_opt_1204 = (arith_opt_1241 ? arith_opt_1203 : arith_opt_1202); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_1205 = (arith_opt_1238 ? ({31'h0, arith_opt_1197}) : arith_opt_1204); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    assign arith_opt_1206 = (arith_opt_1257 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    assign arith_opt_1207 = (arith_opt_1270 ? 2'(5'h2) : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    assign arith_opt_1208 = (arith_opt_1184 ? 9'(12'h200) : arith_opt_1182[8:0]); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    assign arith_opt_1209 = (arith_opt_1184 ? arith_opt_1205 : arith_opt_1183); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_1210 = (arith_opt_1184 ? arith_opt_1207 : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    assign arith_opt_1211 = arith_opt_1209[6:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    assign arith_opt_1212 = (arith_opt_1209 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_1213 = arith_opt_1212[31:7]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    assign arith_opt_1214 = (arith_opt_1211 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    assign arith_opt_1215 = (arith_opt_1210 | 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    assign arith_opt_1216 = (arith_opt_1214 ? arith_opt_1215 : arith_opt_1210); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    assign arith_opt_1217 = (arith_opt_1211 == 7'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    assign arith_opt_1218 = (arith_opt_1213 & 25'h1fffffe); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_1219 = (arith_opt_1217 ? arith_opt_1218 : arith_opt_1213); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    assign arith_opt_1220 = 9'((arith_opt_1258 - 10'h200)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    assign arith_opt_1221 = (arith_opt_1219 == 25'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    assign arith_opt_1222 = (arith_opt_1221 ? 9'(32'h0) : arith_opt_1220); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    assign arith_opt_1223 = (arith_opt_1337 << 5'h1f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    assign arith_opt_1224 = (arith_opt_1260 << 5'h17); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_1225 = (arith_opt_1224 + arith_opt_1259); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_1226 = (arith_opt_1223 | arith_opt_1225); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    assign arith_opt_1227 = (arith_opt_1223 | 32'h7f800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    assign arith_opt_1228 = (arith_opt_1193 ? 3'(5'h5) : ({1'h0, arith_opt_1216})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    assign arith_opt_1229 = (!arith_opt_920); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    assign arith_opt_1230 = (arith_opt_1272 ? 3'(5'h0) : arith_opt_1228); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    assign arith_opt_1231 = (arith_opt_1273 ? 5'h10 : 5'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    assign arith_opt_1232 = (arith_opt_1267 ? ({2'h0, arith_opt_1230}) : arith_opt_1231); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
        unique case (1'b1)
            arith_opt_1308: arith_opt_1233 = 5'h10;
            arith_opt_1314: arith_opt_1233 = 5'h0;
            default: arith_opt_1233 = arith_opt_1232;
        endcase
    end
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
        unique case (1'b1)
            arith_opt_1315: arith_opt_1234 = 32'h7fc00000;
            arith_opt_1317: arith_opt_1234 = arith_opt_1223;
            arith_opt_1334: arith_opt_1234 = arith_opt_1226;
            arith_opt_1336: arith_opt_1234 = 32'h7fc00000;
            default: arith_opt_1234 = arith_opt_1227;
        endcase
    end
    assign arith_opt_1235 = {arith_opt_1233, arith_opt_1234}; // decl: <none>; prim: <none>
    assign arith_opt_1236 = (!arith_opt_922); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    assign arith_opt_1237 = (!arith_opt_925); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    assign arith_opt_1238 = (arith_opt_1184 & arith_opt_1195); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1239 = (!arith_opt_1195); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1240 = (arith_opt_1184 & arith_opt_1239); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1241 = (arith_opt_1201 & arith_opt_1240); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    assign arith_opt_1242 = (arith_opt_1190 & arith_opt_1266); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    assign arith_opt_1243 = (arith_opt_1236 & arith_opt_1237); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    assign arith_opt_1244 = (arith_opt_1263 & arith_opt_1264); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    assign arith_opt_1245 = a[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_1246 = b[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_1247 = (arith_opt_1261 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_1248 = (arith_opt_1262 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_1249 = ({2'h0, arith_opt_1166}); // decl: <none>; prim: <none>
    assign arith_opt_1250 = ({3'h0, arith_opt_1160}); // decl: <none>; prim: <none>
    assign arith_opt_1251 = ({2'h0, arith_opt_1169}); // decl: <none>; prim: <none>
    assign arith_opt_1252 = ({3'h0, arith_opt_1165}); // decl: <none>; prim: <none>
    assign arith_opt_1253 = ({24'h0, arith_opt_1159}); // decl: <none>; prim: <none>
    assign arith_opt_1254 = ({24'h0, arith_opt_1164}); // decl: <none>; prim: <none>
    assign arith_opt_1255 = arith_opt_1174[16:0]; // decl: <none>; prim: <none>
    assign arith_opt_1256 = ({1'h0, arith_opt_1178}); // decl: <none>; prim: <none>
    assign arith_opt_1257 = arith_opt_1205[6:0]; // decl: <none>; prim: <none>
    assign arith_opt_1258 = ({1'h0, arith_opt_1208}); // decl: <none>; prim: <none>
    assign arith_opt_1259 = ({7'h0, arith_opt_1219}); // decl: <none>; prim: <none>
    assign arith_opt_1260 = ({23'h0, arith_opt_1222}); // decl: <none>; prim: <none>
    assign arith_opt_1261 = a[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_1262 = b[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_1263 = (!arith_opt_930); // decl: <none>; prim: <none>
    assign arith_opt_1264 = (!arith_opt_931); // decl: <none>; prim: <none>
    assign arith_opt_1265 = (!arith_opt_1188); // decl: <none>; prim: <none>
    assign arith_opt_1266 = (!arith_opt_1192); // decl: <none>; prim: <none>
    assign arith_opt_1267 = (arith_opt_1229 & arith_opt_1271); // decl: <none>; prim: <none>
    assign arith_opt_1268 = (arith_opt_1265 & arith_opt_1186); // decl: <none>; prim: <none>
    assign arith_opt_1269 = (!arith_opt_1268); // decl: <none>; prim: <none>
    assign arith_opt_1270 = (arith_opt_1269 & arith_opt_1206); // decl: <none>; prim: <none>
    assign arith_opt_1271 = (!arith_opt_923); // decl: <none>; prim: <none>
    assign arith_opt_1272 = arith_opt_1318; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1273 = (arith_opt_1318 & arith_opt_1243); // decl: <none>; prim: <none>
    assign arith_opt_1274 = a[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1275 = a[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1276 = (arith_opt_1274 & arith_opt_1275); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1277 = a[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1278 = a[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1279 = (arith_opt_1277 & arith_opt_1278); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1280 = (arith_opt_1276 & arith_opt_1279); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1281 = a[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1282 = a[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1283 = (arith_opt_1281 & arith_opt_1282); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1284 = a[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1285 = a[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1286 = (arith_opt_1284 & arith_opt_1285); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1287 = (arith_opt_1283 & arith_opt_1286); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1288 = (arith_opt_1280 & arith_opt_1287); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1289 = (arith_opt_1288 & arith_opt_921); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1290 = (arith_opt_1289 & arith_opt_927); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1291 = b[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1292 = b[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1293 = (arith_opt_1291 & arith_opt_1292); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1294 = b[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1295 = b[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1296 = (arith_opt_1294 & arith_opt_1295); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1297 = (arith_opt_1293 & arith_opt_1296); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1298 = b[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1299 = b[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1300 = (arith_opt_1298 & arith_opt_1299); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1301 = b[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1302 = b[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1303 = (arith_opt_1301 & arith_opt_1302); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1304 = (arith_opt_1300 & arith_opt_1303); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1305 = (arith_opt_1297 & arith_opt_1304); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1306 = (arith_opt_1305 & arith_opt_924); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1307 = (arith_opt_1306 & arith_opt_929); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1308 = (!arith_opt_1360); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1309 = (!arith_opt_1288); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1310 = (!arith_opt_1289); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1311 = (!arith_opt_1305); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1312 = (!arith_opt_1306); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1313 = (arith_opt_1310 & arith_opt_1312); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1314 = (arith_opt_1360 & arith_opt_1315); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1315 = (!arith_opt_1313); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1316 = (!arith_opt_1335); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1317 = (arith_opt_1318 & arith_opt_1335); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1318 = (!arith_opt_1244); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1319 = arith_opt_1182[6]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1320 = arith_opt_1182[7]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1321 = arith_opt_1182[9]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1322 = arith_opt_1182[1]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1323 = arith_opt_1182[8]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1324 = arith_opt_1182[2]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1325 = arith_opt_1182[3]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1326 = arith_opt_1182[4]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1327 = arith_opt_1182[5]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1328 = arith_opt_1182[10]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1329 = arith_opt_1182[11]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1330 = arith_opt_1182[0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1331 = (!arith_opt_1356); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1332 = (arith_opt_1190 & arith_opt_1331); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1333 = (arith_opt_1340 & arith_opt_1357); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1334 = (arith_opt_1242 & arith_opt_1340); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1335 = (arith_opt_1309 & arith_opt_1311); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1336 = (arith_opt_1313 & arith_opt_1339); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1337 = (arith_opt_1338 & 32'h1); // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_1338 = ({31'h0, arith_opt_915}); // decl: <none>; prim: <none>
    assign arith_opt_1339 = (arith_opt_1318 & arith_opt_1316); // decl: <none>; prim: <none>
    assign arith_opt_1340 = (arith_opt_1244 & arith_opt_1335); // decl: <none>; prim: <none>
    assign arith_opt_1341 = (arith_opt_1319 & arith_opt_1320); // decl: <none>; prim: <none>
    assign arith_opt_1342 = (!arith_opt_1322); // decl: <none>; prim: <none>
    assign arith_opt_1343 = (!arith_opt_1323); // decl: <none>; prim: <none>
    assign arith_opt_1344 = (arith_opt_1342 & arith_opt_1343); // decl: <none>; prim: <none>
    assign arith_opt_1345 = (arith_opt_1321 & arith_opt_1344); // decl: <none>; prim: <none>
    assign arith_opt_1346 = (arith_opt_1341 & arith_opt_1345); // decl: <none>; prim: <none>
    assign arith_opt_1347 = (arith_opt_1324 & arith_opt_1325); // decl: <none>; prim: <none>
    assign arith_opt_1348 = (arith_opt_1326 & arith_opt_1327); // decl: <none>; prim: <none>
    assign arith_opt_1349 = (arith_opt_1347 & arith_opt_1348); // decl: <none>; prim: <none>
    assign arith_opt_1350 = (!arith_opt_1328); // decl: <none>; prim: <none>
    assign arith_opt_1351 = (!arith_opt_1329); // decl: <none>; prim: <none>
    assign arith_opt_1352 = (arith_opt_1350 & arith_opt_1351); // decl: <none>; prim: <none>
    assign arith_opt_1353 = (arith_opt_1265 & arith_opt_1330); // decl: <none>; prim: <none>
    assign arith_opt_1354 = (arith_opt_1352 & arith_opt_1353); // decl: <none>; prim: <none>
    assign arith_opt_1355 = (arith_opt_1349 & arith_opt_1354); // decl: <none>; prim: <none>
    assign arith_opt_1356 = (arith_opt_1346 & arith_opt_1355); // decl: <none>; prim: <none>
    assign arith_opt_1357 = (!arith_opt_1332); // decl: <none>; prim: <none>
    assign arith_opt_1358 = (!arith_opt_1290); // decl: <none>; prim: <none>
    assign arith_opt_1359 = (!arith_opt_1307); // decl: <none>; prim: <none>
    assign arith_opt_1360 = (arith_opt_1358 & arith_opt_1359); // decl: <none>; prim: <none>
    assign arith_opt_1361 = (tmp_serial_int_32__2_v0 ^ rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:27-44:32
    assign arith_opt_1362 = arith_opt_1361[31]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_1363 = tmp_serial_int_32__2_v0[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_1364 = rtlzz_pipe_2_s1[30:23]; // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:12
    assign arith_opt_1365 = tmp_serial_int_32__2_v0[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_1366 = rtlzz_pipe_2_s1[22:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_1367 = (arith_opt_1363 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:16-47:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_1368 = (arith_opt_1365 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:39-47:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_1369 = (arith_opt_1367 & arith_opt_1368); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:15-47:56
    assign arith_opt_1370 = (arith_opt_1364 == 8'hff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:16-48:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_1371 = (arith_opt_1366 != 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:39-48:55; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_1372 = (arith_opt_1370 & arith_opt_1371); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:15-48:56
    assign arith_opt_1373 = (arith_opt_1365 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:24-49:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_1374 = (arith_opt_1373 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:49:23-49:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:18-46:28
    assign arith_opt_1375 = (arith_opt_1366 & 23'h400000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:24-50:46; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_1376 = (arith_opt_1375 == 23'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:50:23-50:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:35-46:45
    assign arith_opt_1377 = (arith_opt_1692 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:51:16-51:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:63-6:64
    assign arith_opt_1378 = (arith_opt_1693 == 31'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:52:16-52:55; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:6:65-6:66
    assign arith_opt_1379 = (arith_opt_1363 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:9-54:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:24-45:31
    assign arith_opt_1380 = (arith_opt_1694 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_1381 = (arith_opt_1379 ? arith_opt_1380 : ({1'h0, arith_opt_1365})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:54:31-54:53
    assign arith_opt_1382 = (arith_opt_1364 != 8'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:9-55:24; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:46-45:53
    assign arith_opt_1383 = (arith_opt_1695 | 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:46:5-46:46
    assign arith_opt_1384 = (arith_opt_1382 ? arith_opt_1383 : ({1'h0, arith_opt_1366})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:55:31-55:53
    assign arith_opt_1385 = (arith_opt_1381 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1386 = (arith_opt_1381 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1387 = (arith_opt_1385 ? arith_opt_1386 : arith_opt_1381); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1388 = (arith_opt_1385 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1389 = (arith_opt_1384 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1390 = (arith_opt_1384 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1391 = (arith_opt_1389 ? arith_opt_1390 : arith_opt_1384); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1392 = (arith_opt_1389 ? 1'(8'h1) : 1'(8'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1393 = (arith_opt_1387 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1394 = (arith_opt_1387 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1395 = (arith_opt_1388 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1396 = (arith_opt_1393 ? arith_opt_1394 : arith_opt_1387); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1397 = (arith_opt_1393 ? arith_opt_1395 : ({1'h0, arith_opt_1388})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1398 = (arith_opt_1391 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1399 = (arith_opt_1391 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1400 = (arith_opt_1392 + 1'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1401 = (arith_opt_1398 ? arith_opt_1399 : arith_opt_1391); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1402 = (arith_opt_1398 ? arith_opt_1400 : ({1'h0, arith_opt_1392})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1403 = (arith_opt_1396 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1404 = (arith_opt_1396 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1405 = (arith_opt_1397 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1406 = (arith_opt_1403 ? arith_opt_1404 : arith_opt_1396); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1407 = (arith_opt_1403 ? arith_opt_1405 : ({1'h0, arith_opt_1397})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1408 = (arith_opt_1401 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1409 = (arith_opt_1401 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1410 = (arith_opt_1402 + 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1411 = (arith_opt_1408 ? arith_opt_1409 : arith_opt_1401); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1412 = (arith_opt_1408 ? arith_opt_1410 : ({1'h0, arith_opt_1402})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1413 = (arith_opt_1406 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1414 = (arith_opt_1406 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1415 = (arith_opt_1407 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1416 = (arith_opt_1413 ? arith_opt_1414 : arith_opt_1406); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1417 = (arith_opt_1413 ? arith_opt_1415 : ({1'h0, arith_opt_1407})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1418 = (arith_opt_1411 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1419 = (arith_opt_1411 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1420 = (arith_opt_1412 + 3'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1421 = (arith_opt_1418 ? arith_opt_1419 : arith_opt_1411); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1422 = (arith_opt_1418 ? arith_opt_1420 : ({1'h0, arith_opt_1412})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1423 = (arith_opt_1416 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1424 = (arith_opt_1416 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1425 = (arith_opt_1417 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1426 = (arith_opt_1423 ? arith_opt_1424 : arith_opt_1416); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1427 = (arith_opt_1423 ? arith_opt_1425 : ({1'h0, arith_opt_1417})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1428 = (arith_opt_1421 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1429 = (arith_opt_1421 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1430 = (arith_opt_1422 + 4'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1431 = (arith_opt_1428 ? arith_opt_1429 : arith_opt_1421); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1432 = (arith_opt_1428 ? arith_opt_1430 : ({1'h0, arith_opt_1422})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1433 = (arith_opt_1426 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1434 = (arith_opt_1426 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1435 = (arith_opt_1427 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1436 = (arith_opt_1433 ? arith_opt_1434 : arith_opt_1426); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1437 = (arith_opt_1433 ? arith_opt_1435 : ({1'h0, arith_opt_1427})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1438 = (arith_opt_1431 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1439 = (arith_opt_1431 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1440 = (arith_opt_1432 + 5'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1441 = (arith_opt_1438 ? arith_opt_1439 : arith_opt_1431); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1442 = (arith_opt_1438 ? arith_opt_1440 : ({1'h0, arith_opt_1432})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1443 = (arith_opt_1436 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1444 = (arith_opt_1436 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1445 = (arith_opt_1437 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1446 = (arith_opt_1443 ? arith_opt_1444 : arith_opt_1436); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1447 = (arith_opt_1443 ? arith_opt_1445 : ({1'h0, arith_opt_1437})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1448 = (arith_opt_1441 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1449 = (arith_opt_1441 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1450 = (arith_opt_1442 + 6'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1451 = (arith_opt_1448 ? arith_opt_1449 : arith_opt_1441); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1452 = (arith_opt_1448 ? arith_opt_1450 : ({1'h0, arith_opt_1442})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1453 = (arith_opt_1446 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1454 = (arith_opt_1446 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1455 = (arith_opt_1447 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:53-58:72
    assign arith_opt_1456 = (arith_opt_1453 ? arith_opt_1454 : arith_opt_1446); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1457 = (arith_opt_1453 ? arith_opt_1455 : ({1'h0, arith_opt_1447})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72
    assign arith_opt_1458 = (arith_opt_1451 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1459 = (arith_opt_1451 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1460 = (arith_opt_1452 + 7'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:53-59:72
    assign arith_opt_1461 = (arith_opt_1458 ? arith_opt_1459 : arith_opt_1451); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1462 = (arith_opt_1458 ? arith_opt_1460 : ({1'h0, arith_opt_1452})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72
    assign arith_opt_1463 = (arith_opt_1456 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1464 = (arith_opt_1456 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1465 = (arith_opt_1457 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1466 = (arith_opt_1463 ? arith_opt_1464 : arith_opt_1456); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1467 = (arith_opt_1463 ? arith_opt_1465 : arith_opt_1457); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1468 = (arith_opt_1461 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1469 = (arith_opt_1461 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1470 = (arith_opt_1462 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1471 = (arith_opt_1468 ? arith_opt_1469 : arith_opt_1461); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1472 = (arith_opt_1468 ? arith_opt_1470 : arith_opt_1462); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1473 = (arith_opt_1466 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1474 = (arith_opt_1466 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1475 = (arith_opt_1467 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1476 = (arith_opt_1473 ? arith_opt_1474 : arith_opt_1466); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1477 = (arith_opt_1473 ? arith_opt_1475 : arith_opt_1467); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1478 = (arith_opt_1471 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1479 = (arith_opt_1471 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1480 = (arith_opt_1472 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1481 = (arith_opt_1478 ? arith_opt_1479 : arith_opt_1471); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1482 = (arith_opt_1478 ? arith_opt_1480 : arith_opt_1472); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1483 = (arith_opt_1476 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1484 = (arith_opt_1476 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1485 = (arith_opt_1477 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1486 = (arith_opt_1483 ? arith_opt_1484 : arith_opt_1476); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1487 = (arith_opt_1483 ? arith_opt_1485 : arith_opt_1477); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1488 = (arith_opt_1481 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1489 = (arith_opt_1481 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1490 = (arith_opt_1482 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1491 = (arith_opt_1488 ? arith_opt_1489 : arith_opt_1481); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1492 = (arith_opt_1488 ? arith_opt_1490 : arith_opt_1482); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1493 = (arith_opt_1486 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1494 = (arith_opt_1486 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1495 = (arith_opt_1487 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1496 = (arith_opt_1493 ? arith_opt_1494 : arith_opt_1486); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1497 = (arith_opt_1493 ? arith_opt_1495 : arith_opt_1487); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1498 = (arith_opt_1491 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1499 = (arith_opt_1491 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1500 = (arith_opt_1492 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1501 = (arith_opt_1498 ? arith_opt_1499 : arith_opt_1491); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1502 = (arith_opt_1498 ? arith_opt_1500 : arith_opt_1492); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1503 = (arith_opt_1496 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1504 = (arith_opt_1496 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1505 = (arith_opt_1497 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1506 = (arith_opt_1503 ? arith_opt_1504 : arith_opt_1496); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1507 = (arith_opt_1503 ? arith_opt_1505 : arith_opt_1497); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1508 = (arith_opt_1501 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1509 = (arith_opt_1501 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1510 = (arith_opt_1502 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1511 = (arith_opt_1508 ? arith_opt_1509 : arith_opt_1501); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1512 = (arith_opt_1508 ? arith_opt_1510 : arith_opt_1502); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1513 = (arith_opt_1506 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1514 = (arith_opt_1506 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1515 = (arith_opt_1507 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1516 = (arith_opt_1513 ? arith_opt_1514 : arith_opt_1506); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1517 = (arith_opt_1513 ? arith_opt_1515 : arith_opt_1507); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1518 = (arith_opt_1511 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1519 = (arith_opt_1511 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1520 = (arith_opt_1512 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1521 = (arith_opt_1518 ? arith_opt_1519 : arith_opt_1511); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1522 = (arith_opt_1518 ? arith_opt_1520 : arith_opt_1512); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1523 = (arith_opt_1516 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1524 = (arith_opt_1516 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1525 = (arith_opt_1517 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1526 = (arith_opt_1523 ? arith_opt_1524 : arith_opt_1516); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1527 = (arith_opt_1523 ? arith_opt_1525 : arith_opt_1517); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1528 = (arith_opt_1521 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1529 = (arith_opt_1521 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1530 = (arith_opt_1522 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1531 = (arith_opt_1528 ? arith_opt_1529 : arith_opt_1521); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1532 = (arith_opt_1528 ? arith_opt_1530 : arith_opt_1522); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1533 = (arith_opt_1526 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1534 = (arith_opt_1526 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1535 = (arith_opt_1527 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1536 = (arith_opt_1533 ? arith_opt_1534 : arith_opt_1526); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1537 = (arith_opt_1533 ? arith_opt_1535 : arith_opt_1527); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1538 = (arith_opt_1531 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1539 = (arith_opt_1531 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1540 = (arith_opt_1532 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1541 = (arith_opt_1538 ? arith_opt_1539 : arith_opt_1531); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1542 = (arith_opt_1538 ? arith_opt_1540 : arith_opt_1532); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1543 = (arith_opt_1536 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1544 = (arith_opt_1536 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1545 = (arith_opt_1537 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1546 = (arith_opt_1543 ? arith_opt_1544 : arith_opt_1536); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1547 = (arith_opt_1543 ? arith_opt_1545 : arith_opt_1537); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1548 = (arith_opt_1541 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1549 = (arith_opt_1541 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1550 = (arith_opt_1542 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1551 = (arith_opt_1548 ? arith_opt_1549 : arith_opt_1541); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1552 = (arith_opt_1548 ? arith_opt_1550 : arith_opt_1542); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1553 = (arith_opt_1546 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1554 = (arith_opt_1546 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1555 = (arith_opt_1547 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1556 = (arith_opt_1553 ? arith_opt_1554 : arith_opt_1546); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1557 = (arith_opt_1553 ? arith_opt_1555 : arith_opt_1547); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1558 = (arith_opt_1551 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1559 = (arith_opt_1551 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1560 = (arith_opt_1552 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1561 = (arith_opt_1558 ? arith_opt_1559 : arith_opt_1551); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1562 = (arith_opt_1558 ? arith_opt_1560 : arith_opt_1552); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1563 = (arith_opt_1556 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1564 = (arith_opt_1556 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1565 = (arith_opt_1557 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1566 = (arith_opt_1563 ? arith_opt_1564 : arith_opt_1556); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1567 = (arith_opt_1563 ? arith_opt_1565 : arith_opt_1557); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1568 = (arith_opt_1561 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1569 = (arith_opt_1561 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1570 = (arith_opt_1562 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1571 = (arith_opt_1568 ? arith_opt_1569 : arith_opt_1561); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1572 = (arith_opt_1568 ? arith_opt_1570 : arith_opt_1562); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1573 = (arith_opt_1566 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1574 = (arith_opt_1566 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1575 = (arith_opt_1567 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1576 = (arith_opt_1573 ? arith_opt_1574 : arith_opt_1566); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1577 = (arith_opt_1573 ? arith_opt_1575 : arith_opt_1567); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1578 = (arith_opt_1571 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1579 = (arith_opt_1571 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1580 = (arith_opt_1572 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1581 = (arith_opt_1578 ? arith_opt_1579 : arith_opt_1571); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1582 = (arith_opt_1578 ? arith_opt_1580 : arith_opt_1572); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1583 = (arith_opt_1576 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1584 = (arith_opt_1576 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1585 = (arith_opt_1577 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1586 = (arith_opt_1583 ? arith_opt_1584 : arith_opt_1576); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1587 = (arith_opt_1583 ? arith_opt_1585 : arith_opt_1577); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1588 = (arith_opt_1581 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1589 = (arith_opt_1581 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1590 = (arith_opt_1582 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1591 = (arith_opt_1588 ? arith_opt_1589 : arith_opt_1581); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1592 = (arith_opt_1588 ? arith_opt_1590 : arith_opt_1582); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1593 = (arith_opt_1586 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1594 = (arith_opt_1586 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1595 = (arith_opt_1587 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1596 = (arith_opt_1593 ? arith_opt_1594 : arith_opt_1586); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1597 = (arith_opt_1593 ? arith_opt_1595 : arith_opt_1587); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1598 = (arith_opt_1591 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1599 = (arith_opt_1591 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1600 = (arith_opt_1592 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1601 = (arith_opt_1598 ? arith_opt_1599 : arith_opt_1591); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1602 = (arith_opt_1598 ? arith_opt_1600 : arith_opt_1592); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1603 = (arith_opt_1596 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:13-58:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:18-58:35
    assign arith_opt_1604 = (arith_opt_1596 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:44-58:51
    assign arith_opt_1605 = (arith_opt_1597 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:58-58:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:58:63-58:72
    assign arith_opt_1606 = (arith_opt_1603 ? arith_opt_1604 : arith_opt_1596); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1607 = (arith_opt_1603 ? arith_opt_1605 : arith_opt_1597); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1608 = (arith_opt_1601 < 24'h800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:13-59:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:18-59:35
    assign arith_opt_1609 = (arith_opt_1601 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:44-59:51
    assign arith_opt_1610 = (arith_opt_1602 + 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:58-59:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:59:63-59:72
    assign arith_opt_1611 = (arith_opt_1608 ? arith_opt_1609 : arith_opt_1601); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:53:5-53:48
    assign arith_opt_1612 = (arith_opt_1608 ? arith_opt_1610 : arith_opt_1602); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:56:5-56:27
    assign arith_opt_1613 = (arith_opt_1379 ? arith_opt_1363 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:17-45:32
    assign arith_opt_1614 = (arith_opt_1696 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:41
    assign arith_opt_1615 = (arith_opt_1614 - arith_opt_1697); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:26-62:58
    assign arith_opt_1616 = (arith_opt_1382 ? arith_opt_1364 : 8'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:45:39-45:54
    assign arith_opt_1617 = (arith_opt_1698 + 10'h200); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:41
    assign arith_opt_1618 = (arith_opt_1617 - arith_opt_1699); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:18-63:88; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:63:26-63:58
    assign arith_opt_1619 = (arith_opt_1615 + arith_opt_1618); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_1620 = (arith_opt_1619 - 12'h27f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:40; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:62:18-62:88
    assign arith_opt_1621 = 48'(($unsigned(48'($unsigned(arith_opt_1700))) * $unsigned(48'($unsigned(arith_opt_1701))))); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1622 = arith_opt_1621[47:17]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1623 = (arith_opt_1702 != 17'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:9-67:51; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:65:23-65:30
    assign arith_opt_1624 = (arith_opt_1622 | 31'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:27-66:40
    assign arith_opt_1625 = (arith_opt_1623 ? arith_opt_1624 : arith_opt_1622); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:67:59-67:75
    assign arith_opt_1626 = (arith_opt_1703 < 32'h40000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:9-68:34; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:15-68:34
    assign arith_opt_1627 = (arith_opt_1703 << 1'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_1628 = (arith_opt_1620 - 12'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:59-68:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:18-64:25
    assign arith_opt_1629 = (arith_opt_1626 ? arith_opt_1628 : arith_opt_1620); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:64:5-64:41
    assign arith_opt_1630 = (arith_opt_1626 ? arith_opt_1627 : ({1'h0, arith_opt_1625})); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:44-68:52
    assign arith_opt_1631 = (arith_opt_1629 < 12'h200); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:9-71:26; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:71:14-71:26
    assign arith_opt_1632 = (arith_opt_1629 < 12'h1ff); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:22-72:39; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:27-72:39
    assign arith_opt_1633 = (!arith_opt_1632); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:21-72:85
    assign arith_opt_1634 = (arith_opt_1630 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:62
    assign arith_opt_1635 = (arith_opt_1634 < 32'h80000000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:72:45-72:84
    assign arith_opt_1636 = (arith_opt_1629 > 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:21-85:38; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:26-85:38
    assign arith_opt_1637 = (!arith_opt_1636); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_1638 = (arith_opt_1629 == 12'h2fd); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:15-86:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:21-86:33
    assign arith_opt_1639 = (arith_opt_1712 & arith_opt_1638); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:86:14-86:80
    assign arith_opt_1640 = (!arith_opt_1689); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:85:20-86:81
    assign arith_opt_1641 = (12'h200 - arith_opt_1629); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_1642 = (arith_opt_1641 >= 12'h20); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:73:25-73:37
    assign arith_opt_1643 = (arith_opt_1630 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:36
    assign arith_opt_1644 = (arith_opt_1643 ? 1'(32'h1) : 1'(32'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:39-75:49
    assign arith_opt_1645 = (arith_opt_1641 >= 12'd32 ? 32'h0 : (32'h1 << arith_opt_1641)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:29-77:48
    assign arith_opt_1646 = (arith_opt_1645 - 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:77:28-77:62
    assign arith_opt_1647 = (arith_opt_1630 & arith_opt_1646); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:25-78:35
    assign arith_opt_1648 = (arith_opt_1647 != 32'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:24-78:50
    assign arith_opt_1649 = (arith_opt_1641 >= 12'd32 ? 32'h0 : (arith_opt_1630 >> arith_opt_1641)); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:79:19-79:31
    assign arith_opt_1650 = (arith_opt_1649 | 32'h1); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:80:28-80:44
    assign arith_opt_1651 = (arith_opt_1688 ? arith_opt_1650 : arith_opt_1649); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_1652 = (arith_opt_1685 ? ({31'h0, arith_opt_1644}) : arith_opt_1651); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:75:19-75:62
    assign arith_opt_1653 = (arith_opt_1704 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:22-83:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:46-83:56
    assign arith_opt_1654 = (arith_opt_1717 ? 2'(5'h2) : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:67-83:84
    assign arith_opt_1655 = (arith_opt_1631 ? 9'(12'h200) : arith_opt_1629[8:0]); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:68:54-68:74
    assign arith_opt_1656 = (arith_opt_1631 ? arith_opt_1652 : arith_opt_1630); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:66:5-66:42
    assign arith_opt_1657 = (arith_opt_1631 ? arith_opt_1654 : 2'(5'h0)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:83:13-83:57
    assign arith_opt_1658 = arith_opt_1656[6:0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:88:24-88:35
    assign arith_opt_1659 = (arith_opt_1656 + 32'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_1660 = arith_opt_1659[31:7]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:30-89:41
    assign arith_opt_1661 = (arith_opt_1658 != 7'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:9-90:31; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:22-90:31
    assign arith_opt_1662 = (arith_opt_1657 | 2'h1); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:20-69:29
    assign arith_opt_1663 = (arith_opt_1661 ? arith_opt_1662 : arith_opt_1657); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:90:41-90:58
    assign arith_opt_1664 = (arith_opt_1658 == 7'h40); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:9-91:32; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:22-91:32
    assign arith_opt_1665 = (arith_opt_1660 & 25'h1fffffe); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:89:24-89:41
    assign arith_opt_1666 = (arith_opt_1664 ? arith_opt_1665 : arith_opt_1660); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:44-91:73
    assign arith_opt_1667 = 9'((arith_opt_1705 - 10'h200)); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:82:9-82:26
    assign arith_opt_1668 = (arith_opt_1666 == 25'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:9-93:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:91:34-91:73
    assign arith_opt_1669 = (arith_opt_1668 ? 9'(32'h0) : arith_opt_1667); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:93:42-93:52
    assign arith_opt_1670 = (arith_opt_1784 << 5'h1f); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:23-94:42; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:44:19-44:40
    assign arith_opt_1671 = (arith_opt_1707 << 5'h17); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_1672 = (arith_opt_1671 + arith_opt_1706); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:47-94:72; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:48-94:61
    assign arith_opt_1673 = (arith_opt_1670 | arith_opt_1672); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:22-94:73
    assign arith_opt_1674 = (arith_opt_1670 | 32'h7f800000); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:30-95:73
    assign arith_opt_1675 = (arith_opt_1640 ? 3'(5'h5) : ({1'h0, arith_opt_1663})); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:95:83-95:92
    assign arith_opt_1676 = (!arith_opt_1367); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:97:14-97:56
    assign arith_opt_1677 = (arith_opt_1719 ? 3'(5'h0) : arith_opt_1675); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:100:66-100:75
    assign arith_opt_1678 = (arith_opt_1720 ? 5'h10 : 5'h0); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:63-98:73
    assign arith_opt_1679 = (arith_opt_1714 ? ({2'h0, arith_opt_1677}) : arith_opt_1678); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
        unique case (1'b1)
            arith_opt_1755: arith_opt_1680 = 5'h10;
            arith_opt_1761: arith_opt_1680 = 5'h0;
            default: arith_opt_1680 = arith_opt_1679;
        endcase
    end
    always_comb begin // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
        unique case (1'b1)
            arith_opt_1762: arith_opt_1681 = 32'h7fc00000;
            arith_opt_1764: arith_opt_1681 = arith_opt_1670;
            arith_opt_1781: arith_opt_1681 = arith_opt_1673;
            arith_opt_1783: arith_opt_1681 = 32'h7fc00000;
            default: arith_opt_1681 = arith_opt_1674;
        endcase
    end
    assign arith_opt_1682 = {arith_opt_1680, arith_opt_1681}; // decl: <none>; prim: <none>
    assign arith_opt_1683 = (!arith_opt_1369); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:47:5-47:57
    assign arith_opt_1684 = (!arith_opt_1372); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:48:5-48:57
    assign arith_opt_1685 = (arith_opt_1631 & arith_opt_1642); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1686 = (!arith_opt_1642); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1687 = (arith_opt_1631 & arith_opt_1686); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:74:13-74:33
    assign arith_opt_1688 = (arith_opt_1648 & arith_opt_1687); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:78:13-78:51
    assign arith_opt_1689 = (arith_opt_1637 & arith_opt_1713); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:70:5-70:27
    assign arith_opt_1690 = (arith_opt_1683 & arith_opt_1684); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:96:9-96:17
    assign arith_opt_1691 = (arith_opt_1710 & arith_opt_1711); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:98:13-98:21
    assign arith_opt_1692 = tmp_serial_int_32__2_v0[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_1693 = rtlzz_pipe_2_s1[30:0]; // decl: <none>; prim: <none>
    assign arith_opt_1694 = (arith_opt_1708 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:30-43:39
    assign arith_opt_1695 = (arith_opt_1709 & 24'h7fffff); // decl: <none>; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:43:41-43:50
    assign arith_opt_1696 = ({2'h0, arith_opt_1613}); // decl: <none>; prim: <none>
    assign arith_opt_1697 = ({3'h0, arith_opt_1607}); // decl: <none>; prim: <none>
    assign arith_opt_1698 = ({2'h0, arith_opt_1616}); // decl: <none>; prim: <none>
    assign arith_opt_1699 = ({3'h0, arith_opt_1612}); // decl: <none>; prim: <none>
    assign arith_opt_1700 = ({24'h0, arith_opt_1606}); // decl: <none>; prim: <none>
    assign arith_opt_1701 = ({24'h0, arith_opt_1611}); // decl: <none>; prim: <none>
    assign arith_opt_1702 = arith_opt_1621[16:0]; // decl: <none>; prim: <none>
    assign arith_opt_1703 = ({1'h0, arith_opt_1625}); // decl: <none>; prim: <none>
    assign arith_opt_1704 = arith_opt_1652[6:0]; // decl: <none>; prim: <none>
    assign arith_opt_1705 = ({1'h0, arith_opt_1655}); // decl: <none>; prim: <none>
    assign arith_opt_1706 = ({7'h0, arith_opt_1666}); // decl: <none>; prim: <none>
    assign arith_opt_1707 = ({23'h0, arith_opt_1669}); // decl: <none>; prim: <none>
    assign arith_opt_1708 = tmp_serial_int_32__2_v0[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_1709 = rtlzz_pipe_2_s1[23:0]; // decl: <none>; prim: <none>
    assign arith_opt_1710 = (!arith_opt_1377); // decl: <none>; prim: <none>
    assign arith_opt_1711 = (!arith_opt_1378); // decl: <none>; prim: <none>
    assign arith_opt_1712 = (!arith_opt_1635); // decl: <none>; prim: <none>
    assign arith_opt_1713 = (!arith_opt_1639); // decl: <none>; prim: <none>
    assign arith_opt_1714 = (arith_opt_1676 & arith_opt_1718); // decl: <none>; prim: <none>
    assign arith_opt_1715 = (arith_opt_1712 & arith_opt_1633); // decl: <none>; prim: <none>
    assign arith_opt_1716 = (!arith_opt_1715); // decl: <none>; prim: <none>
    assign arith_opt_1717 = (arith_opt_1716 & arith_opt_1653); // decl: <none>; prim: <none>
    assign arith_opt_1718 = (!arith_opt_1370); // decl: <none>; prim: <none>
    assign arith_opt_1719 = arith_opt_1765; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1720 = (arith_opt_1765 & arith_opt_1690); // decl: <none>; prim: <none>
    assign arith_opt_1721 = tmp_serial_int_32__2_v0[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1722 = tmp_serial_int_32__2_v0[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1723 = (arith_opt_1721 & arith_opt_1722); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1724 = tmp_serial_int_32__2_v0[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1725 = tmp_serial_int_32__2_v0[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1726 = (arith_opt_1724 & arith_opt_1725); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1727 = (arith_opt_1723 & arith_opt_1726); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1728 = tmp_serial_int_32__2_v0[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1729 = tmp_serial_int_32__2_v0[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1730 = (arith_opt_1728 & arith_opt_1729); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1731 = tmp_serial_int_32__2_v0[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1732 = tmp_serial_int_32__2_v0[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1733 = (arith_opt_1731 & arith_opt_1732); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1734 = (arith_opt_1730 & arith_opt_1733); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1735 = (arith_opt_1727 & arith_opt_1734); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1736 = (arith_opt_1735 & arith_opt_1368); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1737 = (arith_opt_1736 & arith_opt_1374); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1738 = rtlzz_pipe_2_s1[23]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1739 = rtlzz_pipe_2_s1[24]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1740 = (arith_opt_1738 & arith_opt_1739); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1741 = rtlzz_pipe_2_s1[25]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1742 = rtlzz_pipe_2_s1[26]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1743 = (arith_opt_1741 & arith_opt_1742); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1744 = (arith_opt_1740 & arith_opt_1743); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1745 = rtlzz_pipe_2_s1[27]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1746 = rtlzz_pipe_2_s1[28]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1747 = (arith_opt_1745 & arith_opt_1746); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1748 = rtlzz_pipe_2_s1[29]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1749 = rtlzz_pipe_2_s1[30]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1750 = (arith_opt_1748 & arith_opt_1749); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1751 = (arith_opt_1747 & arith_opt_1750); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1752 = (arith_opt_1744 & arith_opt_1751); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1753 = (arith_opt_1752 & arith_opt_1371); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1754 = (arith_opt_1753 & arith_opt_1376); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1755 = (!arith_opt_1807); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1756 = (!arith_opt_1735); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1757 = (!arith_opt_1736); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1758 = (!arith_opt_1752); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1759 = (!arith_opt_1753); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1760 = (arith_opt_1757 & arith_opt_1759); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1761 = (arith_opt_1807 & arith_opt_1762); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:69:5-69:30
    assign arith_opt_1762 = (!arith_opt_1760); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1763 = (!arith_opt_1782); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1764 = (arith_opt_1765 & arith_opt_1782); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1765 = (!arith_opt_1691); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1766 = arith_opt_1629[6]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1767 = arith_opt_1629[7]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1768 = arith_opt_1629[9]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1769 = arith_opt_1629[1]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1770 = arith_opt_1629[8]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1771 = arith_opt_1629[2]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1772 = arith_opt_1629[3]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1773 = arith_opt_1629[4]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1774 = arith_opt_1629[5]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1775 = arith_opt_1629[10]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1776 = arith_opt_1629[11]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1777 = arith_opt_1629[0]; // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1778 = (!arith_opt_1803); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1779 = (arith_opt_1637 & arith_opt_1778); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1780 = (arith_opt_1787 & arith_opt_1804); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1781 = (arith_opt_1689 & arith_opt_1787); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1782 = (arith_opt_1756 & arith_opt_1758); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1783 = (arith_opt_1760 & arith_opt_1786); // decl: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74; prim: /home/zyrv/vulsim/vullib/arithmetic.hpp:94:5-94:74
    assign arith_opt_1784 = (arith_opt_1785 & 32'h1); // decl: <none>; prim: /home/zyrv/vulsim/arithmetic_fp32_template.logic.cpp:2:1-2:10
    assign arith_opt_1785 = ({31'h0, arith_opt_1362}); // decl: <none>; prim: <none>
    assign arith_opt_1786 = (arith_opt_1765 & arith_opt_1763); // decl: <none>; prim: <none>
    assign arith_opt_1787 = (arith_opt_1691 & arith_opt_1782); // decl: <none>; prim: <none>
    assign arith_opt_1788 = (arith_opt_1766 & arith_opt_1767); // decl: <none>; prim: <none>
    assign arith_opt_1789 = (!arith_opt_1769); // decl: <none>; prim: <none>
    assign arith_opt_1790 = (!arith_opt_1770); // decl: <none>; prim: <none>
    assign arith_opt_1791 = (arith_opt_1789 & arith_opt_1790); // decl: <none>; prim: <none>
    assign arith_opt_1792 = (arith_opt_1768 & arith_opt_1791); // decl: <none>; prim: <none>
    assign arith_opt_1793 = (arith_opt_1788 & arith_opt_1792); // decl: <none>; prim: <none>
    assign arith_opt_1794 = (arith_opt_1771 & arith_opt_1772); // decl: <none>; prim: <none>
    assign arith_opt_1795 = (arith_opt_1773 & arith_opt_1774); // decl: <none>; prim: <none>
    assign arith_opt_1796 = (arith_opt_1794 & arith_opt_1795); // decl: <none>; prim: <none>
    assign arith_opt_1797 = (!arith_opt_1775); // decl: <none>; prim: <none>
    assign arith_opt_1798 = (!arith_opt_1776); // decl: <none>; prim: <none>
    assign arith_opt_1799 = (arith_opt_1797 & arith_opt_1798); // decl: <none>; prim: <none>
    assign arith_opt_1800 = (arith_opt_1712 & arith_opt_1777); // decl: <none>; prim: <none>
    assign arith_opt_1801 = (arith_opt_1799 & arith_opt_1800); // decl: <none>; prim: <none>
    assign arith_opt_1802 = (arith_opt_1796 & arith_opt_1801); // decl: <none>; prim: <none>
    assign arith_opt_1803 = (arith_opt_1793 & arith_opt_1802); // decl: <none>; prim: <none>
    assign arith_opt_1804 = (!arith_opt_1779); // decl: <none>; prim: <none>
    assign arith_opt_1805 = (!arith_opt_1737); // decl: <none>; prim: <none>
    assign arith_opt_1806 = (!arith_opt_1754); // decl: <none>; prim: <none>
    assign arith_opt_1807 = (arith_opt_1805 & arith_opt_1806); // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 32'h3f800000;
            rtlzz_pipe_9_s1 <= 37'h107fc00000;
            rtlzz_pipe_9_s2 <= 37'h107fc00000;
            rtlzz_pipe_9_s3 <= 37'h107fc00000;
            rtlzz_pipe_10_s2 <= 37'h7fc00000;
            rtlzz_pipe_10_s3 <= 37'h7fc00000;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:1-2:14
        end
        if (iv) begin
        rtlzz_pipe_9_s1 <= arith_5_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_9_s2 <= rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_9_s3 <= rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= arith_7_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_10_s3 <= rtlzz_pipe_10_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38; prim: /home/zyrv/vulsim/fp_region_test.logic.cpp:2:31-2:38
        end
    end
endmodule
