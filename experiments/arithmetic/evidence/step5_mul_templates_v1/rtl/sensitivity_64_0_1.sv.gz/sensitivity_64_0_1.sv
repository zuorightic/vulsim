`timescale 1ns/1ps

module sensitivity_64_0(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [128:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23
    output logic [128:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [127:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [127:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({64'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({64'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 64'(($unsigned(64'($unsigned(mul_tree_10_11))) * $unsigned(64'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 64'(($unsigned(64'($unsigned(mul_tree_10_14))) * $unsigned(64'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 64'(($unsigned(64'($unsigned(mul_tree_10_18))) * $unsigned(64'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 64'(($unsigned(64'($unsigned(mul_tree_10_22))) * $unsigned(64'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({33'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 97'((mul_tree_10_26 + mul_tree_10_27 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({33'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 129'((mul_tree_10_29 + mul_tree_10_30 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({33'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 130'((mul_tree_10_32 + mul_tree_10_33 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    end
endmodule
