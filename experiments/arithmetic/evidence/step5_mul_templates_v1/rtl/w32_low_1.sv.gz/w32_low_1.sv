`timescale 1ns/1ps

module w32_low_1(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [31:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [31:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    output logic [31:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [31:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [31:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [31:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [15:0] mul_tree_9_11; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_9_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_9_16; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_9_20; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_9_24; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_25; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_9_26; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_9_27; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_9_28; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_9_29; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_9_30; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_9_31; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_9_32; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_9_33; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_9_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_9_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [31:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    assign arith_original_9 = mul_tree_9_35; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_60; // decl: <none>; prim: <none>
    assign mul_tree_9_11 = a[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_12 = b[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_13 = 32'(($unsigned(32'($unsigned(mul_tree_9_11))) * $unsigned(32'($unsigned(mul_tree_9_12))))); // decl: <none>; prim: <none>
    assign mul_tree_9_14 = a[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_15 = b[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_9_16 = 32'(($unsigned(32'($unsigned(mul_tree_9_14))) * $unsigned(32'($unsigned(mul_tree_9_15))))); // decl: <none>; prim: <none>
    assign mul_tree_9_17 = {mul_tree_9_16, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_18 = a[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_9_19 = b[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_20 = 32'(($unsigned(32'($unsigned(mul_tree_9_18))) * $unsigned(32'($unsigned(mul_tree_9_19))))); // decl: <none>; prim: <none>
    assign mul_tree_9_21 = {mul_tree_9_20, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_22 = a[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_9_23 = b[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_9_24 = 32'(($unsigned(32'($unsigned(mul_tree_9_22))) * $unsigned(32'($unsigned(mul_tree_9_23))))); // decl: <none>; prim: <none>
    assign mul_tree_9_25 = {mul_tree_9_24, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_26 = ({17'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_28 = 49'((mul_tree_9_26 + mul_tree_9_27 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_29 = ({17'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_31 = 65'((mul_tree_9_29 + mul_tree_9_30 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_32 = ({17'h0, mul_tree_9_28}); // decl: <none>; prim: <none>
    assign mul_tree_9_33 = ({1'h0, mul_tree_9_31}); // decl: <none>; prim: <none>
    assign mul_tree_9_34 = 66'((mul_tree_9_32 + mul_tree_9_33 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_35 = mul_tree_9_34[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = a[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_37 = c[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = 32'(($unsigned(32'($unsigned(mul_tree_10_36))) * $unsigned(32'($unsigned(mul_tree_10_37))))); // decl: <none>; prim: <none>
    assign mul_tree_10_39 = a[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = c[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_41 = 32'(($unsigned(32'($unsigned(mul_tree_10_39))) * $unsigned(32'($unsigned(mul_tree_10_40))))); // decl: <none>; prim: <none>
    assign mul_tree_10_42 = {mul_tree_10_41, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = a[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = c[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_45 = 32'(($unsigned(32'($unsigned(mul_tree_10_43))) * $unsigned(32'($unsigned(mul_tree_10_44))))); // decl: <none>; prim: <none>
    assign mul_tree_10_46 = {mul_tree_10_45, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = a[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = c[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_49 = 32'(($unsigned(32'($unsigned(mul_tree_10_47))) * $unsigned(32'($unsigned(mul_tree_10_48))))); // decl: <none>; prim: <none>
    assign mul_tree_10_50 = {mul_tree_10_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = ({17'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_52 = ({1'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = 49'((mul_tree_10_51 + mul_tree_10_52 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_54 = ({17'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_55 = ({1'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 65'((mul_tree_10_54 + mul_tree_10_55 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = ({17'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_58 = ({1'h0, mul_tree_10_56}); // decl: <none>; prim: <none>
    assign mul_tree_10_59 = 66'((mul_tree_10_57 + mul_tree_10_58 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_60 = mul_tree_10_59[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 32'h23;
            rtlzz_pipe_17_s1 <= 48'h0;
            rtlzz_pipe_21_s1 <= 48'h0;
            rtlzz_pipe_25_s1 <= 64'h0;
            rtlzz_pipe_4_s2 <= 32'h23;
            rtlzz_pipe_38_s1 <= 32'h37;
            rtlzz_pipe_42_s1 <= 48'h0;
            rtlzz_pipe_46_s1 <= 48'h0;
            rtlzz_pipe_50_s1 <= 64'h0;
            rtlzz_pipe_5_s2 <= 32'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_9_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_9_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_9_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_9_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_10_38; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_10_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_10_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_10_50; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
