`timescale 1ns/1ps

module w13_full_1(
    input logic [12:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [12:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [12:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [25:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [25:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [25:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [25:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [12:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    logic [12:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [12:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [25:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [25:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [25:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [25:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [25:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [5:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic mul_tree_15_25; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic mul_tree_15_37; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic mul_tree_15_40; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic mul_tree_15_44; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic mul_tree_15_48; // decl: <none>; prim: <none>
    logic mul_tree_15_49; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_66; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_67; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_68; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_69; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_70; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_71; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_72; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_73; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_74; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_75; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_76; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_77; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_78; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_79; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_80; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_81; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_82; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_16_83; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_84; // decl: <none>; prim: <none>
    logic mul_tree_16_85; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_86; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_87; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_88; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_89; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_90; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_16_91; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_92; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_93; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_94; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_95; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_96; // decl: <none>; prim: <none>
    logic mul_tree_16_97; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_98; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_99; // decl: <none>; prim: <none>
    logic mul_tree_16_100; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_101; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_102; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_103; // decl: <none>; prim: <none>
    logic mul_tree_16_104; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_105; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_106; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_107; // decl: <none>; prim: <none>
    logic mul_tree_16_108; // decl: <none>; prim: <none>
    logic mul_tree_16_109; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_110; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_111; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_112; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_113; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_114; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_115; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_116; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_117; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_118; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_119; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_120; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_121; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_122; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_123; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_124; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_125; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_126; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_127; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_128; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_129; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_130; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_131; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_132; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_133; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_134; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_135; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_136; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [11:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_83_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_87_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_95_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_99_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({13'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({13'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({13'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_76; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_136; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 12'(($unsigned(12'($unsigned(mul_tree_15_17))) * $unsigned(12'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 12'(($unsigned(12'($unsigned(mul_tree_15_20))) * $unsigned(12'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 7'(($unsigned(7'($unsigned(mul_tree_15_24))) * $unsigned(7'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 12'(($unsigned(12'($unsigned(mul_tree_15_28))) * $unsigned(12'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = __beopt_width_15[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 12'(($unsigned(12'($unsigned(mul_tree_15_32))) * $unsigned(12'($unsigned(mul_tree_15_33))))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = {mul_tree_15_34, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_36 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_37 = __beopt_width_15[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 7'(($unsigned(7'($unsigned(mul_tree_15_36))) * $unsigned(7'($unsigned(mul_tree_15_37))))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = {mul_tree_15_38, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_40 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_15[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = 7'(($unsigned(7'($unsigned(mul_tree_15_40))) * $unsigned(7'($unsigned(mul_tree_15_41))))); // decl: <none>; prim: <none>
    assign mul_tree_15_43 = {mul_tree_15_42, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_15[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 7'(($unsigned(7'($unsigned(mul_tree_15_44))) * $unsigned(7'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_15[12]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 2'(($unsigned(2'($unsigned(mul_tree_15_48))) * $unsigned(2'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = ({7'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_53 = ({1'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 19'((mul_tree_15_52 + mul_tree_15_53 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_56 = ({2'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_57 = 20'((mul_tree_15_55 + mul_tree_15_56 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_58 = ({2'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = ({1'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_60 = 26'((mul_tree_15_58 + mul_tree_15_59 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_61 = ({7'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_62 = ({1'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = 26'((mul_tree_15_61 + mul_tree_15_62 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_64 = ({2'h0, mul_tree_15_54}); // decl: <none>; prim: <none>
    assign mul_tree_15_65 = ({1'h0, mul_tree_15_57}); // decl: <none>; prim: <none>
    assign mul_tree_15_66 = 21'((mul_tree_15_64 + mul_tree_15_65 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_67 = ({1'h0, mul_tree_15_60}); // decl: <none>; prim: <none>
    assign mul_tree_15_68 = ({1'h0, mul_tree_15_63}); // decl: <none>; prim: <none>
    assign mul_tree_15_69 = 27'((mul_tree_15_67 + mul_tree_15_68 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_70 = ({7'h0, mul_tree_15_66}); // decl: <none>; prim: <none>
    assign mul_tree_15_71 = ({1'h0, mul_tree_15_69}); // decl: <none>; prim: <none>
    assign mul_tree_15_72 = 28'((mul_tree_15_70 + mul_tree_15_71 + ({27'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_73 = ({1'h0, mul_tree_15_72}); // decl: <none>; prim: <none>
    assign mul_tree_15_74 = ({3'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_75 = 29'((mul_tree_15_73 + mul_tree_15_74 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_76 = mul_tree_15_75[25:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_77 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_78 = __beopt_width_18[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_79 = 12'(($unsigned(12'($unsigned(mul_tree_16_77))) * $unsigned(12'($unsigned(mul_tree_16_78))))); // decl: <none>; prim: <none>
    assign mul_tree_16_80 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_81 = __beopt_width_18[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_82 = 12'(($unsigned(12'($unsigned(mul_tree_16_80))) * $unsigned(12'($unsigned(mul_tree_16_81))))); // decl: <none>; prim: <none>
    assign mul_tree_16_83 = {mul_tree_16_82, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_84 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_85 = __beopt_width_18[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_86 = 7'(($unsigned(7'($unsigned(mul_tree_16_84))) * $unsigned(7'($unsigned(mul_tree_16_85))))); // decl: <none>; prim: <none>
    assign mul_tree_16_87 = {mul_tree_16_86, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_88 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_89 = __beopt_width_18[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_90 = 12'(($unsigned(12'($unsigned(mul_tree_16_88))) * $unsigned(12'($unsigned(mul_tree_16_89))))); // decl: <none>; prim: <none>
    assign mul_tree_16_91 = {mul_tree_16_90, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_92 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_93 = __beopt_width_18[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_94 = 12'(($unsigned(12'($unsigned(mul_tree_16_92))) * $unsigned(12'($unsigned(mul_tree_16_93))))); // decl: <none>; prim: <none>
    assign mul_tree_16_95 = {mul_tree_16_94, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_96 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_97 = __beopt_width_18[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_98 = 7'(($unsigned(7'($unsigned(mul_tree_16_96))) * $unsigned(7'($unsigned(mul_tree_16_97))))); // decl: <none>; prim: <none>
    assign mul_tree_16_99 = {mul_tree_16_98, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_100 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_101 = __beopt_width_18[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_102 = 7'(($unsigned(7'($unsigned(mul_tree_16_100))) * $unsigned(7'($unsigned(mul_tree_16_101))))); // decl: <none>; prim: <none>
    assign mul_tree_16_103 = {mul_tree_16_102, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_104 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_105 = __beopt_width_18[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_106 = 7'(($unsigned(7'($unsigned(mul_tree_16_104))) * $unsigned(7'($unsigned(mul_tree_16_105))))); // decl: <none>; prim: <none>
    assign mul_tree_16_107 = {mul_tree_16_106, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_108 = __beopt_width_14[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_109 = __beopt_width_18[12]; // decl: <none>; prim: <none>
    assign mul_tree_16_110 = 2'(($unsigned(2'($unsigned(mul_tree_16_108))) * $unsigned(2'($unsigned(mul_tree_16_109))))); // decl: <none>; prim: <none>
    assign mul_tree_16_111 = {mul_tree_16_110, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_112 = ({7'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_113 = ({1'h0, rtlzz_pipe_83_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_114 = 19'((mul_tree_16_112 + mul_tree_16_113 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_115 = ({1'h0, rtlzz_pipe_87_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_116 = ({2'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_117 = 20'((mul_tree_16_115 + mul_tree_16_116 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_118 = ({2'h0, rtlzz_pipe_95_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_119 = ({1'h0, rtlzz_pipe_99_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_120 = 26'((mul_tree_16_118 + mul_tree_16_119 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_121 = ({7'h0, rtlzz_pipe_103_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_122 = ({1'h0, rtlzz_pipe_107_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_123 = 26'((mul_tree_16_121 + mul_tree_16_122 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_124 = ({2'h0, mul_tree_16_114}); // decl: <none>; prim: <none>
    assign mul_tree_16_125 = ({1'h0, mul_tree_16_117}); // decl: <none>; prim: <none>
    assign mul_tree_16_126 = 21'((mul_tree_16_124 + mul_tree_16_125 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_127 = ({1'h0, mul_tree_16_120}); // decl: <none>; prim: <none>
    assign mul_tree_16_128 = ({1'h0, mul_tree_16_123}); // decl: <none>; prim: <none>
    assign mul_tree_16_129 = 27'((mul_tree_16_127 + mul_tree_16_128 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_130 = ({7'h0, mul_tree_16_126}); // decl: <none>; prim: <none>
    assign mul_tree_16_131 = ({1'h0, mul_tree_16_129}); // decl: <none>; prim: <none>
    assign mul_tree_16_132 = 28'((mul_tree_16_130 + mul_tree_16_131 + ({27'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_133 = ({1'h0, mul_tree_16_132}); // decl: <none>; prim: <none>
    assign mul_tree_16_134 = ({3'h0, rtlzz_pipe_111_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_135 = 29'((mul_tree_16_133 + mul_tree_16_134 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_136 = mul_tree_16_135[25:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_19_s1 <= 12'h23;
            rtlzz_pipe_23_s1 <= 18'h0;
            rtlzz_pipe_27_s1 <= 19'h0;
            rtlzz_pipe_31_s1 <= 18'h0;
            rtlzz_pipe_35_s1 <= 24'h0;
            rtlzz_pipe_39_s1 <= 25'h0;
            rtlzz_pipe_43_s1 <= 19'h0;
            rtlzz_pipe_47_s1 <= 25'h0;
            rtlzz_pipe_51_s1 <= 26'h0;
            rtlzz_pipe_4_s2 <= 26'h23;
            rtlzz_pipe_79_s1 <= 12'h37;
            rtlzz_pipe_83_s1 <= 18'h0;
            rtlzz_pipe_87_s1 <= 19'h0;
            rtlzz_pipe_91_s1 <= 18'h0;
            rtlzz_pipe_95_s1 <= 24'h0;
            rtlzz_pipe_99_s1 <= 25'h0;
            rtlzz_pipe_103_s1 <= 19'h0;
            rtlzz_pipe_107_s1 <= 25'h0;
            rtlzz_pipe_111_s1 <= 26'h0;
            rtlzz_pipe_5_s2 <= 26'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_15_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_15_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_15_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_15_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_15_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_15_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_15_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_15_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_15_51; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_16_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_83_s1 <= mul_tree_16_83; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_87_s1 <= mul_tree_16_87; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_16_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_95_s1 <= mul_tree_16_95; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_99_s1 <= mul_tree_16_99; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_tree_16_103; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_tree_16_107; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_tree_16_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
