`timescale 1ns/1ps

module sensitivity_128_1(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    input logic [256:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24
    output logic [256:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:56
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [256:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    logic [255:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [256:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [255:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [256:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    logic [256:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + c); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    assign y = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:56
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, s8_norm_mul_0_v0}); // decl: <none>; prim: <none>
    assign arith_original_11 = 256'(($unsigned(256'($unsigned(__beopt_width_11))) * $unsigned(256'($unsigned(__beopt_width_12))))); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    end
endmodule
