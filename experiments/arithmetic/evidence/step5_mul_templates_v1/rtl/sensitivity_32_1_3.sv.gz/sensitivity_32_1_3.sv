`timescale 1ns/1ps

module sensitivity_32_1(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [64:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    output logic [64:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [64:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [63:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [7:0] mul_tree_11_12; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_17; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_11_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_20; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_22; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_25; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_11_26; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_27; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_28; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_29; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_11_30; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_31; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_32; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_34; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_35; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_36; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_37; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_11_38; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_39; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_40; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_41; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_11_42; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_43; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_44; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_46; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_47; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_48; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_49; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_11_50; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_51; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_52; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_53; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_11_54; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_55; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_56; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_57; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_11_58; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_59; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_60; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_61; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_11_62; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_63; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_64; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_65; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_11_66; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_67; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_68; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_69; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_11_70; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_71; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_72; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_73; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_74; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_75; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_76; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_77; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_78; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_79; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_80; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_81; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_82; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_83; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_85; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_86; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_87; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_88; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_11_89; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_11_90; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_11_91; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_11_92; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_93; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_94; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_11_95; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_11_96; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_11_97; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_11_98; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_11_99; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_11_100; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_11_101; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_11_102; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_11_103; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_11_104; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_11_105; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_11_106; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_11_107; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_11_108; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_11_109; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_11_110; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_11_111; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_11_112; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_11_113; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_11_114; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_11_115; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_11_116; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_11_117; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_11_118; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_11_119; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_120; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    logic [64:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    logic [15:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [39:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [39:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [39:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [55:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [39:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_66_s1; // decl: <none>; prim: <none>
    logic [55:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s2); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    assign y = s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_11 = mul_tree_11_120; // decl: <none>; prim: <none>
    assign mul_tree_11_12 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_13 = __beopt_width_12[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_14 = 16'(($unsigned(16'($unsigned(mul_tree_11_12))) * $unsigned(16'($unsigned(mul_tree_11_13))))); // decl: <none>; prim: <none>
    assign mul_tree_11_15 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_16 = __beopt_width_12[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_17 = 16'(($unsigned(16'($unsigned(mul_tree_11_15))) * $unsigned(16'($unsigned(mul_tree_11_16))))); // decl: <none>; prim: <none>
    assign mul_tree_11_18 = {mul_tree_11_17, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_19 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_20 = __beopt_width_12[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_21 = 16'(($unsigned(16'($unsigned(mul_tree_11_19))) * $unsigned(16'($unsigned(mul_tree_11_20))))); // decl: <none>; prim: <none>
    assign mul_tree_11_22 = {mul_tree_11_21, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_23 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_24 = __beopt_width_12[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_25 = 16'(($unsigned(16'($unsigned(mul_tree_11_23))) * $unsigned(16'($unsigned(mul_tree_11_24))))); // decl: <none>; prim: <none>
    assign mul_tree_11_26 = {mul_tree_11_25, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_27 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_28 = __beopt_width_12[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_29 = 16'(($unsigned(16'($unsigned(mul_tree_11_27))) * $unsigned(16'($unsigned(mul_tree_11_28))))); // decl: <none>; prim: <none>
    assign mul_tree_11_30 = {mul_tree_11_29, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_31 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_32 = __beopt_width_12[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_33 = 16'(($unsigned(16'($unsigned(mul_tree_11_31))) * $unsigned(16'($unsigned(mul_tree_11_32))))); // decl: <none>; prim: <none>
    assign mul_tree_11_34 = {mul_tree_11_33, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_35 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_36 = __beopt_width_12[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_37 = 16'(($unsigned(16'($unsigned(mul_tree_11_35))) * $unsigned(16'($unsigned(mul_tree_11_36))))); // decl: <none>; prim: <none>
    assign mul_tree_11_38 = {mul_tree_11_37, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_39 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_40 = __beopt_width_12[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_41 = 16'(($unsigned(16'($unsigned(mul_tree_11_39))) * $unsigned(16'($unsigned(mul_tree_11_40))))); // decl: <none>; prim: <none>
    assign mul_tree_11_42 = {mul_tree_11_41, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_43 = __beopt_width_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_44 = __beopt_width_12[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_45 = 16'(($unsigned(16'($unsigned(mul_tree_11_43))) * $unsigned(16'($unsigned(mul_tree_11_44))))); // decl: <none>; prim: <none>
    assign mul_tree_11_46 = {mul_tree_11_45, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_47 = __beopt_width_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_48 = __beopt_width_12[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_49 = 16'(($unsigned(16'($unsigned(mul_tree_11_47))) * $unsigned(16'($unsigned(mul_tree_11_48))))); // decl: <none>; prim: <none>
    assign mul_tree_11_50 = {mul_tree_11_49, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_51 = __beopt_width_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_52 = __beopt_width_12[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_53 = 16'(($unsigned(16'($unsigned(mul_tree_11_51))) * $unsigned(16'($unsigned(mul_tree_11_52))))); // decl: <none>; prim: <none>
    assign mul_tree_11_54 = {mul_tree_11_53, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_55 = __beopt_width_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_56 = __beopt_width_12[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_57 = 16'(($unsigned(16'($unsigned(mul_tree_11_55))) * $unsigned(16'($unsigned(mul_tree_11_56))))); // decl: <none>; prim: <none>
    assign mul_tree_11_58 = {mul_tree_11_57, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_59 = __beopt_width_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_60 = __beopt_width_12[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_61 = 16'(($unsigned(16'($unsigned(mul_tree_11_59))) * $unsigned(16'($unsigned(mul_tree_11_60))))); // decl: <none>; prim: <none>
    assign mul_tree_11_62 = {mul_tree_11_61, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_63 = __beopt_width_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_64 = __beopt_width_12[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_65 = 16'(($unsigned(16'($unsigned(mul_tree_11_63))) * $unsigned(16'($unsigned(mul_tree_11_64))))); // decl: <none>; prim: <none>
    assign mul_tree_11_66 = {mul_tree_11_65, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_67 = __beopt_width_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_68 = __beopt_width_12[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_11_69 = 16'(($unsigned(16'($unsigned(mul_tree_11_67))) * $unsigned(16'($unsigned(mul_tree_11_68))))); // decl: <none>; prim: <none>
    assign mul_tree_11_70 = {mul_tree_11_69, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_71 = __beopt_width_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_72 = __beopt_width_12[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_11_73 = 16'(($unsigned(16'($unsigned(mul_tree_11_71))) * $unsigned(16'($unsigned(mul_tree_11_72))))); // decl: <none>; prim: <none>
    assign mul_tree_11_74 = {mul_tree_11_73, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_75 = ({9'h0, rtlzz_pipe_14_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_76 = ({1'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_77 = 25'((mul_tree_11_75 + mul_tree_11_76 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_78 = ({9'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_79 = ({1'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_80 = 41'((mul_tree_11_78 + mul_tree_11_79 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_81 = ({9'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_82 = ({1'h0, rtlzz_pipe_34_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_83 = 33'((mul_tree_11_81 + mul_tree_11_82 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_84 = ({9'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_85 = ({1'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_86 = 49'((mul_tree_11_84 + mul_tree_11_85 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_87 = ({9'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_88 = ({1'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_89 = 41'((mul_tree_11_87 + mul_tree_11_88 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_90 = ({9'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_91 = ({1'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_92 = 57'((mul_tree_11_90 + mul_tree_11_91 + ({56'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_93 = ({9'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_94 = ({1'h0, rtlzz_pipe_66_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_95 = 49'((mul_tree_11_93 + mul_tree_11_94 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_96 = ({9'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_97 = ({1'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_98 = 65'((mul_tree_11_96 + mul_tree_11_97 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_99 = ({17'h0, mul_tree_11_77}); // decl: <none>; prim: <none>
    assign mul_tree_11_100 = ({1'h0, mul_tree_11_80}); // decl: <none>; prim: <none>
    assign mul_tree_11_101 = 42'((mul_tree_11_99 + mul_tree_11_100 + ({41'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_102 = ({17'h0, mul_tree_11_83}); // decl: <none>; prim: <none>
    assign mul_tree_11_103 = ({1'h0, mul_tree_11_86}); // decl: <none>; prim: <none>
    assign mul_tree_11_104 = 50'((mul_tree_11_102 + mul_tree_11_103 + ({49'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_105 = ({17'h0, mul_tree_11_89}); // decl: <none>; prim: <none>
    assign mul_tree_11_106 = ({1'h0, mul_tree_11_92}); // decl: <none>; prim: <none>
    assign mul_tree_11_107 = 58'((mul_tree_11_105 + mul_tree_11_106 + ({57'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_108 = ({17'h0, mul_tree_11_95}); // decl: <none>; prim: <none>
    assign mul_tree_11_109 = ({1'h0, mul_tree_11_98}); // decl: <none>; prim: <none>
    assign mul_tree_11_110 = 66'((mul_tree_11_108 + mul_tree_11_109 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_111 = ({9'h0, mul_tree_11_101}); // decl: <none>; prim: <none>
    assign mul_tree_11_112 = ({1'h0, mul_tree_11_104}); // decl: <none>; prim: <none>
    assign mul_tree_11_113 = 51'((mul_tree_11_111 + mul_tree_11_112 + ({50'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_114 = ({9'h0, mul_tree_11_107}); // decl: <none>; prim: <none>
    assign mul_tree_11_115 = ({1'h0, mul_tree_11_110}); // decl: <none>; prim: <none>
    assign mul_tree_11_116 = 67'((mul_tree_11_114 + mul_tree_11_115 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_117 = ({17'h0, mul_tree_11_113}); // decl: <none>; prim: <none>
    assign mul_tree_11_118 = ({1'h0, mul_tree_11_116}); // decl: <none>; prim: <none>
    assign mul_tree_11_119 = 68'((mul_tree_11_117 + mul_tree_11_118 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_120 = mul_tree_11_119[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= mul_tree_11_14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_11_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_11_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_11_26; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_11_30; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_34_s1 <= mul_tree_11_34; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_11_38; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_11_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_11_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_11_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_11_54; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_11_58; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_11_62; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_66_s1 <= mul_tree_11_66; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_70_s1 <= mul_tree_11_70; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_74_s1 <= mul_tree_11_74; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    end
endmodule
