`timescale 1ns/1ps

module sensitivity_8_0(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [16:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    output logic [16:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [15:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [16:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [15:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [3:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({8'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 8'(($unsigned(8'($unsigned(mul_tree_10_11))) * $unsigned(8'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 8'(($unsigned(8'($unsigned(mul_tree_10_14))) * $unsigned(8'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 8'(($unsigned(8'($unsigned(mul_tree_10_18))) * $unsigned(8'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 8'(($unsigned(8'($unsigned(mul_tree_10_22))) * $unsigned(8'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({5'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 13'((mul_tree_10_26 + mul_tree_10_27 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({5'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 17'((mul_tree_10_29 + mul_tree_10_30 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({5'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 18'((mul_tree_10_32 + mul_tree_10_33 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    end
endmodule
