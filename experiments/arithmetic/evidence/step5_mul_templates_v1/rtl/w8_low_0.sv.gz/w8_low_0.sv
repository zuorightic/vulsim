`timescale 1ns/1ps

module w8_low_0(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [7:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25
    output logic [7:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:35; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:17-10:22
    output logic [7:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:23-10:28
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [7:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic [7:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic [7:0] rtlzz_pipe_4_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] rtlzz_pipe_5_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic [7:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:35; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:17-10:22
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:23-10:28
    assign arith_original_9 = 8'(($unsigned(8'($unsigned(a))) * $unsigned(8'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    assign arith_original_10 = 8'(($unsigned(8'($unsigned(a))) * $unsigned(8'($unsigned(c))))); // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_4_s1 <= 8'h23;
            rtlzz_pipe_4_s2 <= 8'h23;
            rtlzz_pipe_5_s1 <= 8'h37;
            rtlzz_pipe_5_s2 <= 8'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        end
    end
endmodule
