`timescale 1ns/1ps

module w17_full_2(
    input logic [16:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [16:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [16:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [33:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [33:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [33:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [16:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    logic [16:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [16:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [33:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [33:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [3:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic mul_tree_15_33; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic mul_tree_15_53; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_66; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_68; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_70; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_72; // decl: <none>; prim: <none>
    logic mul_tree_15_73; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_74; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_75; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_76; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_77; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_78; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_79; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_80; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_81; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_82; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_83; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_84; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_85; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_86; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_87; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_88; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_89; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_90; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_91; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_92; // decl: <none>; prim: <none>
    logic mul_tree_15_93; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_94; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_95; // decl: <none>; prim: <none>
    logic mul_tree_15_96; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_97; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_98; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_99; // decl: <none>; prim: <none>
    logic mul_tree_15_100; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_101; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_102; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_103; // decl: <none>; prim: <none>
    logic mul_tree_15_104; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_105; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_106; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_107; // decl: <none>; prim: <none>
    logic mul_tree_15_108; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_109; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_15_110; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_111; // decl: <none>; prim: <none>
    logic mul_tree_15_112; // decl: <none>; prim: <none>
    logic mul_tree_15_113; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_114; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_115; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_116; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_117; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_118; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_119; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_120; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_121; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_122; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_123; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_124; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_126; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_127; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_128; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_129; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_130; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_131; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_132; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_133; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_134; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_135; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_136; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_137; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_138; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_139; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_140; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_141; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_142; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_143; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_144; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_145; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_146; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_147; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_148; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_149; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_150; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_151; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_152; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_153; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_154; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_15_155; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_15_156; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_15_157; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_158; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_159; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_160; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_15_161; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_15_162; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_15_163; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_164; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_165; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_166; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_167; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_168; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_169; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_170; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_171; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_172; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_174; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_175; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_176; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_177; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_178; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_179; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_180; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_181; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_182; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_183; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_184; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_15_185; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_15_186; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_15_187; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_188; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_189; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_190; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_191; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_192; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_193; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_194; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_195; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_196; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_197; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_198; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_199; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_200; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_201; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_202; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_203; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_204; // decl: <none>; prim: <none>
    logic mul_tree_16_205; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_206; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_207; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_208; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_209; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_210; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_211; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_212; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_213; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_214; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_215; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_216; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_217; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_218; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_219; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_220; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_221; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_222; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_223; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_224; // decl: <none>; prim: <none>
    logic mul_tree_16_225; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_226; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_227; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_228; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_229; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_230; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_231; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_232; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_233; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_234; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_235; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_236; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_237; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_238; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_239; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_240; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_241; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_242; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_243; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_244; // decl: <none>; prim: <none>
    logic mul_tree_16_245; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_246; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_247; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_248; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_249; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_250; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_251; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_252; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_253; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_254; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_255; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_256; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_257; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_258; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_259; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_260; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_261; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_262; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_263; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_264; // decl: <none>; prim: <none>
    logic mul_tree_16_265; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_266; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_267; // decl: <none>; prim: <none>
    logic mul_tree_16_268; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_269; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_270; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_271; // decl: <none>; prim: <none>
    logic mul_tree_16_272; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_273; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_274; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_275; // decl: <none>; prim: <none>
    logic mul_tree_16_276; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_277; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_278; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_279; // decl: <none>; prim: <none>
    logic mul_tree_16_280; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_281; // decl: <none>; prim: <none>
    logic [4:0] mul_tree_16_282; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_283; // decl: <none>; prim: <none>
    logic mul_tree_16_284; // decl: <none>; prim: <none>
    logic mul_tree_16_285; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_286; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_287; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_288; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_289; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_290; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_291; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_292; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_293; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_294; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_295; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_296; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_297; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_298; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_299; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_300; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_301; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_302; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_303; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_304; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_305; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_306; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_307; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_308; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_309; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_310; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_311; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_312; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_313; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_314; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_315; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_316; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_317; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_318; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_319; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_320; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_321; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_322; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_323; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_324; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_325; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_326; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_16_327; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_16_328; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_16_329; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_330; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_331; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_332; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_16_333; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_16_334; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_16_335; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_336; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_337; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_338; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_339; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_340; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_341; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_342; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_343; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_344; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_345; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_346; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_347; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_348; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_349; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_350; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_351; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_352; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_353; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_16_354; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_16_355; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_16_356; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_16_357; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_16_358; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_16_359; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_360; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_115_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_130_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_133_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_136_s1; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_139_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_142_s1; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_145_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_151_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_181_s2; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_184_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_287_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_290_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_293_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_296_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_299_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_302_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_305_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_308_s1; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_311_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_314_s1; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_317_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_320_s1; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_323_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_353_s2; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_356_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({17'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({17'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({17'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_188; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_360; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 8'(($unsigned(8'($unsigned(mul_tree_15_17))) * $unsigned(8'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 8'(($unsigned(8'($unsigned(mul_tree_15_20))) * $unsigned(8'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 8'(($unsigned(8'($unsigned(mul_tree_15_24))) * $unsigned(8'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 8'(($unsigned(8'($unsigned(mul_tree_15_28))) * $unsigned(8'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = __beopt_width_15[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 5'(($unsigned(5'($unsigned(mul_tree_15_32))) * $unsigned(5'($unsigned(mul_tree_15_33))))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = {mul_tree_15_34, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_36 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_37 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 8'(($unsigned(8'($unsigned(mul_tree_15_36))) * $unsigned(8'($unsigned(mul_tree_15_37))))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = {mul_tree_15_38, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_40 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = 8'(($unsigned(8'($unsigned(mul_tree_15_40))) * $unsigned(8'($unsigned(mul_tree_15_41))))); // decl: <none>; prim: <none>
    assign mul_tree_15_43 = {mul_tree_15_42, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 8'(($unsigned(8'($unsigned(mul_tree_15_44))) * $unsigned(8'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 8'(($unsigned(8'($unsigned(mul_tree_15_48))) * $unsigned(8'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_15[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 5'(($unsigned(5'($unsigned(mul_tree_15_52))) * $unsigned(5'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_57 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 8'(($unsigned(8'($unsigned(mul_tree_15_56))) * $unsigned(8'($unsigned(mul_tree_15_57))))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = {mul_tree_15_58, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_60 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_61 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_62 = 8'(($unsigned(8'($unsigned(mul_tree_15_60))) * $unsigned(8'($unsigned(mul_tree_15_61))))); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = {mul_tree_15_62, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_64 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_65 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_66 = 8'(($unsigned(8'($unsigned(mul_tree_15_64))) * $unsigned(8'($unsigned(mul_tree_15_65))))); // decl: <none>; prim: <none>
    assign mul_tree_15_67 = {mul_tree_15_66, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_68 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_69 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_70 = 8'(($unsigned(8'($unsigned(mul_tree_15_68))) * $unsigned(8'($unsigned(mul_tree_15_69))))); // decl: <none>; prim: <none>
    assign mul_tree_15_71 = {mul_tree_15_70, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_72 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_73 = __beopt_width_15[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_74 = 5'(($unsigned(5'($unsigned(mul_tree_15_72))) * $unsigned(5'($unsigned(mul_tree_15_73))))); // decl: <none>; prim: <none>
    assign mul_tree_15_75 = {mul_tree_15_74, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_76 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_77 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_78 = 8'(($unsigned(8'($unsigned(mul_tree_15_76))) * $unsigned(8'($unsigned(mul_tree_15_77))))); // decl: <none>; prim: <none>
    assign mul_tree_15_79 = {mul_tree_15_78, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_80 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_81 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_82 = 8'(($unsigned(8'($unsigned(mul_tree_15_80))) * $unsigned(8'($unsigned(mul_tree_15_81))))); // decl: <none>; prim: <none>
    assign mul_tree_15_83 = {mul_tree_15_82, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_84 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_85 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_86 = 8'(($unsigned(8'($unsigned(mul_tree_15_84))) * $unsigned(8'($unsigned(mul_tree_15_85))))); // decl: <none>; prim: <none>
    assign mul_tree_15_87 = {mul_tree_15_86, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_88 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_89 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_90 = 8'(($unsigned(8'($unsigned(mul_tree_15_88))) * $unsigned(8'($unsigned(mul_tree_15_89))))); // decl: <none>; prim: <none>
    assign mul_tree_15_91 = {mul_tree_15_90, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_92 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_93 = __beopt_width_15[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_94 = 5'(($unsigned(5'($unsigned(mul_tree_15_92))) * $unsigned(5'($unsigned(mul_tree_15_93))))); // decl: <none>; prim: <none>
    assign mul_tree_15_95 = {mul_tree_15_94, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_96 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_97 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_98 = 5'(($unsigned(5'($unsigned(mul_tree_15_96))) * $unsigned(5'($unsigned(mul_tree_15_97))))); // decl: <none>; prim: <none>
    assign mul_tree_15_99 = {mul_tree_15_98, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_100 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_101 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_102 = 5'(($unsigned(5'($unsigned(mul_tree_15_100))) * $unsigned(5'($unsigned(mul_tree_15_101))))); // decl: <none>; prim: <none>
    assign mul_tree_15_103 = {mul_tree_15_102, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_104 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_105 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_106 = 5'(($unsigned(5'($unsigned(mul_tree_15_104))) * $unsigned(5'($unsigned(mul_tree_15_105))))); // decl: <none>; prim: <none>
    assign mul_tree_15_107 = {mul_tree_15_106, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_108 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_109 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_110 = 5'(($unsigned(5'($unsigned(mul_tree_15_108))) * $unsigned(5'($unsigned(mul_tree_15_109))))); // decl: <none>; prim: <none>
    assign mul_tree_15_111 = {mul_tree_15_110, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_112 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_113 = __beopt_width_15[16]; // decl: <none>; prim: <none>
    assign mul_tree_15_114 = 2'(($unsigned(2'($unsigned(mul_tree_15_112))) * $unsigned(2'($unsigned(mul_tree_15_113))))); // decl: <none>; prim: <none>
    assign mul_tree_15_115 = {mul_tree_15_114, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_116 = ({5'h0, mul_tree_15_19}); // decl: <none>; prim: <none>
    assign mul_tree_15_117 = ({1'h0, mul_tree_15_23}); // decl: <none>; prim: <none>
    assign mul_tree_15_118 = 13'((mul_tree_15_116 + mul_tree_15_117 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_119 = ({5'h0, mul_tree_15_27}); // decl: <none>; prim: <none>
    assign mul_tree_15_120 = ({1'h0, mul_tree_15_31}); // decl: <none>; prim: <none>
    assign mul_tree_15_121 = 21'((mul_tree_15_119 + mul_tree_15_120 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_122 = ({1'h0, mul_tree_15_35}); // decl: <none>; prim: <none>
    assign mul_tree_15_123 = ({10'h0, mul_tree_15_39}); // decl: <none>; prim: <none>
    assign mul_tree_15_124 = 22'((mul_tree_15_122 + mul_tree_15_123 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_125 = ({5'h0, mul_tree_15_43}); // decl: <none>; prim: <none>
    assign mul_tree_15_126 = ({1'h0, mul_tree_15_47}); // decl: <none>; prim: <none>
    assign mul_tree_15_127 = 21'((mul_tree_15_125 + mul_tree_15_126 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_128 = ({2'h0, mul_tree_15_51}); // decl: <none>; prim: <none>
    assign mul_tree_15_129 = ({1'h0, mul_tree_15_55}); // decl: <none>; prim: <none>
    assign mul_tree_15_130 = 26'((mul_tree_15_128 + mul_tree_15_129 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_131 = ({5'h0, mul_tree_15_59}); // decl: <none>; prim: <none>
    assign mul_tree_15_132 = ({1'h0, mul_tree_15_63}); // decl: <none>; prim: <none>
    assign mul_tree_15_133 = 21'((mul_tree_15_131 + mul_tree_15_132 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_134 = ({5'h0, mul_tree_15_67}); // decl: <none>; prim: <none>
    assign mul_tree_15_135 = ({1'h0, mul_tree_15_71}); // decl: <none>; prim: <none>
    assign mul_tree_15_136 = 29'((mul_tree_15_134 + mul_tree_15_135 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_137 = ({1'h0, mul_tree_15_75}); // decl: <none>; prim: <none>
    assign mul_tree_15_138 = ({10'h0, mul_tree_15_79}); // decl: <none>; prim: <none>
    assign mul_tree_15_139 = 30'((mul_tree_15_137 + mul_tree_15_138 + ({29'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_140 = ({5'h0, mul_tree_15_83}); // decl: <none>; prim: <none>
    assign mul_tree_15_141 = ({1'h0, mul_tree_15_87}); // decl: <none>; prim: <none>
    assign mul_tree_15_142 = 29'((mul_tree_15_140 + mul_tree_15_141 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_143 = ({2'h0, mul_tree_15_91}); // decl: <none>; prim: <none>
    assign mul_tree_15_144 = ({1'h0, mul_tree_15_95}); // decl: <none>; prim: <none>
    assign mul_tree_15_145 = 34'((mul_tree_15_143 + mul_tree_15_144 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_146 = ({5'h0, mul_tree_15_99}); // decl: <none>; prim: <none>
    assign mul_tree_15_147 = ({1'h0, mul_tree_15_103}); // decl: <none>; prim: <none>
    assign mul_tree_15_148 = 26'((mul_tree_15_146 + mul_tree_15_147 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_149 = ({5'h0, mul_tree_15_107}); // decl: <none>; prim: <none>
    assign mul_tree_15_150 = ({1'h0, mul_tree_15_111}); // decl: <none>; prim: <none>
    assign mul_tree_15_151 = 34'((mul_tree_15_149 + mul_tree_15_150 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_152 = ({9'h0, rtlzz_pipe_118_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_153 = ({1'h0, rtlzz_pipe_121_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_154 = 22'((mul_tree_15_152 + mul_tree_15_153 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_155 = ({1'h0, rtlzz_pipe_124_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_156 = ({2'h0, rtlzz_pipe_127_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_157 = 23'((mul_tree_15_155 + mul_tree_15_156 + ({22'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_158 = ({1'h0, rtlzz_pipe_130_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_159 = ({6'h0, rtlzz_pipe_133_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_160 = 27'((mul_tree_15_158 + mul_tree_15_159 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_161 = ({2'h0, rtlzz_pipe_136_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_162 = ({1'h0, rtlzz_pipe_139_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_163 = 31'((mul_tree_15_161 + mul_tree_15_162 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_164 = ({6'h0, rtlzz_pipe_142_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_165 = ({1'h0, rtlzz_pipe_145_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_166 = 35'((mul_tree_15_164 + mul_tree_15_165 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_167 = ({9'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_168 = ({1'h0, rtlzz_pipe_151_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_169 = 35'((mul_tree_15_167 + mul_tree_15_168 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_170 = ({2'h0, mul_tree_15_154}); // decl: <none>; prim: <none>
    assign mul_tree_15_171 = ({1'h0, mul_tree_15_157}); // decl: <none>; prim: <none>
    assign mul_tree_15_172 = 24'((mul_tree_15_170 + mul_tree_15_171 + ({23'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_173 = ({5'h0, mul_tree_15_160}); // decl: <none>; prim: <none>
    assign mul_tree_15_174 = ({1'h0, mul_tree_15_163}); // decl: <none>; prim: <none>
    assign mul_tree_15_175 = 32'((mul_tree_15_173 + mul_tree_15_174 + ({31'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_176 = ({1'h0, mul_tree_15_166}); // decl: <none>; prim: <none>
    assign mul_tree_15_177 = ({1'h0, mul_tree_15_169}); // decl: <none>; prim: <none>
    assign mul_tree_15_178 = 36'((mul_tree_15_176 + mul_tree_15_177 + ({35'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_179 = ({9'h0, mul_tree_15_172}); // decl: <none>; prim: <none>
    assign mul_tree_15_180 = ({1'h0, mul_tree_15_175}); // decl: <none>; prim: <none>
    assign mul_tree_15_181 = 33'((mul_tree_15_179 + mul_tree_15_180 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_182 = ({1'h0, mul_tree_15_178}); // decl: <none>; prim: <none>
    assign mul_tree_15_183 = ({3'h0, rtlzz_pipe_115_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_184 = 37'((mul_tree_15_182 + mul_tree_15_183 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_185 = ({5'h0, rtlzz_pipe_181_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_186 = ({1'h0, rtlzz_pipe_184_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_187 = 38'((mul_tree_15_185 + mul_tree_15_186 + ({37'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_188 = mul_tree_15_187[33:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_189 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_190 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_191 = 8'(($unsigned(8'($unsigned(mul_tree_16_189))) * $unsigned(8'($unsigned(mul_tree_16_190))))); // decl: <none>; prim: <none>
    assign mul_tree_16_192 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_193 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_194 = 8'(($unsigned(8'($unsigned(mul_tree_16_192))) * $unsigned(8'($unsigned(mul_tree_16_193))))); // decl: <none>; prim: <none>
    assign mul_tree_16_195 = {mul_tree_16_194, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_196 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_197 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_198 = 8'(($unsigned(8'($unsigned(mul_tree_16_196))) * $unsigned(8'($unsigned(mul_tree_16_197))))); // decl: <none>; prim: <none>
    assign mul_tree_16_199 = {mul_tree_16_198, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_200 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_201 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_202 = 8'(($unsigned(8'($unsigned(mul_tree_16_200))) * $unsigned(8'($unsigned(mul_tree_16_201))))); // decl: <none>; prim: <none>
    assign mul_tree_16_203 = {mul_tree_16_202, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_204 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_205 = __beopt_width_18[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_206 = 5'(($unsigned(5'($unsigned(mul_tree_16_204))) * $unsigned(5'($unsigned(mul_tree_16_205))))); // decl: <none>; prim: <none>
    assign mul_tree_16_207 = {mul_tree_16_206, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_208 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_209 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_210 = 8'(($unsigned(8'($unsigned(mul_tree_16_208))) * $unsigned(8'($unsigned(mul_tree_16_209))))); // decl: <none>; prim: <none>
    assign mul_tree_16_211 = {mul_tree_16_210, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_212 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_213 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_214 = 8'(($unsigned(8'($unsigned(mul_tree_16_212))) * $unsigned(8'($unsigned(mul_tree_16_213))))); // decl: <none>; prim: <none>
    assign mul_tree_16_215 = {mul_tree_16_214, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_216 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_217 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_218 = 8'(($unsigned(8'($unsigned(mul_tree_16_216))) * $unsigned(8'($unsigned(mul_tree_16_217))))); // decl: <none>; prim: <none>
    assign mul_tree_16_219 = {mul_tree_16_218, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_220 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_221 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_222 = 8'(($unsigned(8'($unsigned(mul_tree_16_220))) * $unsigned(8'($unsigned(mul_tree_16_221))))); // decl: <none>; prim: <none>
    assign mul_tree_16_223 = {mul_tree_16_222, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_224 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_225 = __beopt_width_18[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_226 = 5'(($unsigned(5'($unsigned(mul_tree_16_224))) * $unsigned(5'($unsigned(mul_tree_16_225))))); // decl: <none>; prim: <none>
    assign mul_tree_16_227 = {mul_tree_16_226, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_228 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_229 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_230 = 8'(($unsigned(8'($unsigned(mul_tree_16_228))) * $unsigned(8'($unsigned(mul_tree_16_229))))); // decl: <none>; prim: <none>
    assign mul_tree_16_231 = {mul_tree_16_230, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_232 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_233 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_234 = 8'(($unsigned(8'($unsigned(mul_tree_16_232))) * $unsigned(8'($unsigned(mul_tree_16_233))))); // decl: <none>; prim: <none>
    assign mul_tree_16_235 = {mul_tree_16_234, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_236 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_237 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_238 = 8'(($unsigned(8'($unsigned(mul_tree_16_236))) * $unsigned(8'($unsigned(mul_tree_16_237))))); // decl: <none>; prim: <none>
    assign mul_tree_16_239 = {mul_tree_16_238, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_240 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_241 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_242 = 8'(($unsigned(8'($unsigned(mul_tree_16_240))) * $unsigned(8'($unsigned(mul_tree_16_241))))); // decl: <none>; prim: <none>
    assign mul_tree_16_243 = {mul_tree_16_242, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_244 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_245 = __beopt_width_18[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_246 = 5'(($unsigned(5'($unsigned(mul_tree_16_244))) * $unsigned(5'($unsigned(mul_tree_16_245))))); // decl: <none>; prim: <none>
    assign mul_tree_16_247 = {mul_tree_16_246, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_248 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_249 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_250 = 8'(($unsigned(8'($unsigned(mul_tree_16_248))) * $unsigned(8'($unsigned(mul_tree_16_249))))); // decl: <none>; prim: <none>
    assign mul_tree_16_251 = {mul_tree_16_250, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_252 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_253 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_254 = 8'(($unsigned(8'($unsigned(mul_tree_16_252))) * $unsigned(8'($unsigned(mul_tree_16_253))))); // decl: <none>; prim: <none>
    assign mul_tree_16_255 = {mul_tree_16_254, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_256 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_257 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_258 = 8'(($unsigned(8'($unsigned(mul_tree_16_256))) * $unsigned(8'($unsigned(mul_tree_16_257))))); // decl: <none>; prim: <none>
    assign mul_tree_16_259 = {mul_tree_16_258, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_260 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_261 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_262 = 8'(($unsigned(8'($unsigned(mul_tree_16_260))) * $unsigned(8'($unsigned(mul_tree_16_261))))); // decl: <none>; prim: <none>
    assign mul_tree_16_263 = {mul_tree_16_262, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_264 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_265 = __beopt_width_18[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_266 = 5'(($unsigned(5'($unsigned(mul_tree_16_264))) * $unsigned(5'($unsigned(mul_tree_16_265))))); // decl: <none>; prim: <none>
    assign mul_tree_16_267 = {mul_tree_16_266, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_268 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_269 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_270 = 5'(($unsigned(5'($unsigned(mul_tree_16_268))) * $unsigned(5'($unsigned(mul_tree_16_269))))); // decl: <none>; prim: <none>
    assign mul_tree_16_271 = {mul_tree_16_270, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_272 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_273 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_274 = 5'(($unsigned(5'($unsigned(mul_tree_16_272))) * $unsigned(5'($unsigned(mul_tree_16_273))))); // decl: <none>; prim: <none>
    assign mul_tree_16_275 = {mul_tree_16_274, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_276 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_277 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_278 = 5'(($unsigned(5'($unsigned(mul_tree_16_276))) * $unsigned(5'($unsigned(mul_tree_16_277))))); // decl: <none>; prim: <none>
    assign mul_tree_16_279 = {mul_tree_16_278, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_280 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_281 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_282 = 5'(($unsigned(5'($unsigned(mul_tree_16_280))) * $unsigned(5'($unsigned(mul_tree_16_281))))); // decl: <none>; prim: <none>
    assign mul_tree_16_283 = {mul_tree_16_282, 28'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_284 = __beopt_width_14[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_285 = __beopt_width_18[16]; // decl: <none>; prim: <none>
    assign mul_tree_16_286 = 2'(($unsigned(2'($unsigned(mul_tree_16_284))) * $unsigned(2'($unsigned(mul_tree_16_285))))); // decl: <none>; prim: <none>
    assign mul_tree_16_287 = {mul_tree_16_286, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_288 = ({5'h0, mul_tree_16_191}); // decl: <none>; prim: <none>
    assign mul_tree_16_289 = ({1'h0, mul_tree_16_195}); // decl: <none>; prim: <none>
    assign mul_tree_16_290 = 13'((mul_tree_16_288 + mul_tree_16_289 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_291 = ({5'h0, mul_tree_16_199}); // decl: <none>; prim: <none>
    assign mul_tree_16_292 = ({1'h0, mul_tree_16_203}); // decl: <none>; prim: <none>
    assign mul_tree_16_293 = 21'((mul_tree_16_291 + mul_tree_16_292 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_294 = ({1'h0, mul_tree_16_207}); // decl: <none>; prim: <none>
    assign mul_tree_16_295 = ({10'h0, mul_tree_16_211}); // decl: <none>; prim: <none>
    assign mul_tree_16_296 = 22'((mul_tree_16_294 + mul_tree_16_295 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_297 = ({5'h0, mul_tree_16_215}); // decl: <none>; prim: <none>
    assign mul_tree_16_298 = ({1'h0, mul_tree_16_219}); // decl: <none>; prim: <none>
    assign mul_tree_16_299 = 21'((mul_tree_16_297 + mul_tree_16_298 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_300 = ({2'h0, mul_tree_16_223}); // decl: <none>; prim: <none>
    assign mul_tree_16_301 = ({1'h0, mul_tree_16_227}); // decl: <none>; prim: <none>
    assign mul_tree_16_302 = 26'((mul_tree_16_300 + mul_tree_16_301 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_303 = ({5'h0, mul_tree_16_231}); // decl: <none>; prim: <none>
    assign mul_tree_16_304 = ({1'h0, mul_tree_16_235}); // decl: <none>; prim: <none>
    assign mul_tree_16_305 = 21'((mul_tree_16_303 + mul_tree_16_304 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_306 = ({5'h0, mul_tree_16_239}); // decl: <none>; prim: <none>
    assign mul_tree_16_307 = ({1'h0, mul_tree_16_243}); // decl: <none>; prim: <none>
    assign mul_tree_16_308 = 29'((mul_tree_16_306 + mul_tree_16_307 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_309 = ({1'h0, mul_tree_16_247}); // decl: <none>; prim: <none>
    assign mul_tree_16_310 = ({10'h0, mul_tree_16_251}); // decl: <none>; prim: <none>
    assign mul_tree_16_311 = 30'((mul_tree_16_309 + mul_tree_16_310 + ({29'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_312 = ({5'h0, mul_tree_16_255}); // decl: <none>; prim: <none>
    assign mul_tree_16_313 = ({1'h0, mul_tree_16_259}); // decl: <none>; prim: <none>
    assign mul_tree_16_314 = 29'((mul_tree_16_312 + mul_tree_16_313 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_315 = ({2'h0, mul_tree_16_263}); // decl: <none>; prim: <none>
    assign mul_tree_16_316 = ({1'h0, mul_tree_16_267}); // decl: <none>; prim: <none>
    assign mul_tree_16_317 = 34'((mul_tree_16_315 + mul_tree_16_316 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_318 = ({5'h0, mul_tree_16_271}); // decl: <none>; prim: <none>
    assign mul_tree_16_319 = ({1'h0, mul_tree_16_275}); // decl: <none>; prim: <none>
    assign mul_tree_16_320 = 26'((mul_tree_16_318 + mul_tree_16_319 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_321 = ({5'h0, mul_tree_16_279}); // decl: <none>; prim: <none>
    assign mul_tree_16_322 = ({1'h0, mul_tree_16_283}); // decl: <none>; prim: <none>
    assign mul_tree_16_323 = 34'((mul_tree_16_321 + mul_tree_16_322 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_324 = ({9'h0, rtlzz_pipe_290_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_325 = ({1'h0, rtlzz_pipe_293_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_326 = 22'((mul_tree_16_324 + mul_tree_16_325 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_327 = ({1'h0, rtlzz_pipe_296_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_328 = ({2'h0, rtlzz_pipe_299_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_329 = 23'((mul_tree_16_327 + mul_tree_16_328 + ({22'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_330 = ({1'h0, rtlzz_pipe_302_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_331 = ({6'h0, rtlzz_pipe_305_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_332 = 27'((mul_tree_16_330 + mul_tree_16_331 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_333 = ({2'h0, rtlzz_pipe_308_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_334 = ({1'h0, rtlzz_pipe_311_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_335 = 31'((mul_tree_16_333 + mul_tree_16_334 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_336 = ({6'h0, rtlzz_pipe_314_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_337 = ({1'h0, rtlzz_pipe_317_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_338 = 35'((mul_tree_16_336 + mul_tree_16_337 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_339 = ({9'h0, rtlzz_pipe_320_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_340 = ({1'h0, rtlzz_pipe_323_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_341 = 35'((mul_tree_16_339 + mul_tree_16_340 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_342 = ({2'h0, mul_tree_16_326}); // decl: <none>; prim: <none>
    assign mul_tree_16_343 = ({1'h0, mul_tree_16_329}); // decl: <none>; prim: <none>
    assign mul_tree_16_344 = 24'((mul_tree_16_342 + mul_tree_16_343 + ({23'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_345 = ({5'h0, mul_tree_16_332}); // decl: <none>; prim: <none>
    assign mul_tree_16_346 = ({1'h0, mul_tree_16_335}); // decl: <none>; prim: <none>
    assign mul_tree_16_347 = 32'((mul_tree_16_345 + mul_tree_16_346 + ({31'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_348 = ({1'h0, mul_tree_16_338}); // decl: <none>; prim: <none>
    assign mul_tree_16_349 = ({1'h0, mul_tree_16_341}); // decl: <none>; prim: <none>
    assign mul_tree_16_350 = 36'((mul_tree_16_348 + mul_tree_16_349 + ({35'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_351 = ({9'h0, mul_tree_16_344}); // decl: <none>; prim: <none>
    assign mul_tree_16_352 = ({1'h0, mul_tree_16_347}); // decl: <none>; prim: <none>
    assign mul_tree_16_353 = 33'((mul_tree_16_351 + mul_tree_16_352 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_354 = ({1'h0, mul_tree_16_350}); // decl: <none>; prim: <none>
    assign mul_tree_16_355 = ({3'h0, rtlzz_pipe_287_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_356 = 37'((mul_tree_16_354 + mul_tree_16_355 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_357 = ({5'h0, rtlzz_pipe_353_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_358 = ({1'h0, rtlzz_pipe_356_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_359 = 38'((mul_tree_16_357 + mul_tree_16_358 + ({37'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_360 = mul_tree_16_359[33:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_115_s1 <= 34'h0;
            rtlzz_pipe_118_s1 <= 13'h23;
            rtlzz_pipe_121_s1 <= 21'h0;
            rtlzz_pipe_124_s1 <= 22'h0;
            rtlzz_pipe_127_s1 <= 21'h0;
            rtlzz_pipe_130_s1 <= 26'h0;
            rtlzz_pipe_133_s1 <= 21'h0;
            rtlzz_pipe_136_s1 <= 29'h0;
            rtlzz_pipe_139_s1 <= 30'h0;
            rtlzz_pipe_142_s1 <= 29'h0;
            rtlzz_pipe_145_s1 <= 34'h0;
            rtlzz_pipe_148_s1 <= 26'h0;
            rtlzz_pipe_151_s1 <= 34'h0;
            rtlzz_pipe_181_s2 <= 33'h23;
            rtlzz_pipe_184_s2 <= 37'h0;
            rtlzz_pipe_287_s1 <= 34'h0;
            rtlzz_pipe_290_s1 <= 13'h37;
            rtlzz_pipe_293_s1 <= 21'h0;
            rtlzz_pipe_296_s1 <= 22'h0;
            rtlzz_pipe_299_s1 <= 21'h0;
            rtlzz_pipe_302_s1 <= 26'h0;
            rtlzz_pipe_305_s1 <= 21'h0;
            rtlzz_pipe_308_s1 <= 29'h0;
            rtlzz_pipe_311_s1 <= 30'h0;
            rtlzz_pipe_314_s1 <= 29'h0;
            rtlzz_pipe_317_s1 <= 34'h0;
            rtlzz_pipe_320_s1 <= 26'h0;
            rtlzz_pipe_323_s1 <= 34'h0;
            rtlzz_pipe_353_s2 <= 33'h37;
            rtlzz_pipe_356_s2 <= 37'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_115_s1 <= mul_tree_15_115; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_tree_15_118; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_tree_15_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_tree_15_124; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_127_s1 <= mul_tree_15_127; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_130_s1 <= mul_tree_15_130; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_133_s1 <= mul_tree_15_133; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_136_s1 <= mul_tree_15_136; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_139_s1 <= mul_tree_15_139; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_142_s1 <= mul_tree_15_142; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_145_s1 <= mul_tree_15_145; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_15_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_151_s1 <= mul_tree_15_151; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_181_s2 <= mul_tree_15_181; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_184_s2 <= mul_tree_15_184; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_287_s1 <= mul_tree_16_287; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_290_s1 <= mul_tree_16_290; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_293_s1 <= mul_tree_16_293; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_296_s1 <= mul_tree_16_296; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_299_s1 <= mul_tree_16_299; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_302_s1 <= mul_tree_16_302; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_305_s1 <= mul_tree_16_305; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_308_s1 <= mul_tree_16_308; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_311_s1 <= mul_tree_16_311; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_314_s1 <= mul_tree_16_314; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_317_s1 <= mul_tree_16_317; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_320_s1 <= mul_tree_16_320; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_323_s1 <= mul_tree_16_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_353_s2 <= mul_tree_16_353; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_356_s2 <= mul_tree_16_356; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
