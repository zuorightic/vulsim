`timescale 1ns/1ps

module K16(
    input logic [15:0] a, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    input logic [15:0] c, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    output logic [31:0] x, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:24; prim: /home/zyrv/vulsim/K16.logic.cpp:9:12-9:17
    output logic [31:0] y, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:26; prim: /home/zyrv/vulsim/K16.logic.cpp:9:18-9:23
    output logic [31:0] z, // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:28; prim: /home/zyrv/vulsim/K16.logic.cpp:9:24-9:29
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:14-9:17; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    logic [31:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:20-9:23; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [31:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:26-9:29; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [15:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:10
    logic [15:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    logic [15:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [31:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [31:0] arith_original_15; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:14-9:17; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    logic [31:0] arith_original_16; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:20-9:23; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [31:0] arith_original_17; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:26-9:29; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [7:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_43; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_44; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_46; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_48; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_50; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_52; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_54; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_57; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_58; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_59; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_60; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_61; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_62; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_63; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_64; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_65; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_67; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_68; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_70; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_71; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_72; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_73; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_17_74; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_75; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_76; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_77; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_17_78; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_79; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_17_80; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_17_81; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_82; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_17_83; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_17_84; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_17_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_17_86; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_17_87; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_17_88; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_17_89; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_17_90; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_17_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_92; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_20_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:14-9:17; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    logic [15:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:20-9:23; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    logic [15:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:26-9:29; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign x = rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:24; prim: /home/zyrv/vulsim/K16.logic.cpp:9:12-9:17
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:26; prim: /home/zyrv/vulsim/K16.logic.cpp:9:18-9:23
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/K16.logic.cpp:2:15-2:28; prim: /home/zyrv/vulsim/K16.logic.cpp:9:24-9:29
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({16'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({16'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({16'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_42; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_67; // decl: <none>; prim: <none>
    assign arith_original_17 = mul_tree_17_92; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_14[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = __beopt_width_15[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_20 = 16'(($unsigned(16'($unsigned(mul_tree_15_18))) * $unsigned(16'($unsigned(mul_tree_15_19))))); // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_14[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = __beopt_width_15[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_23 = 16'(($unsigned(16'($unsigned(mul_tree_15_21))) * $unsigned(16'($unsigned(mul_tree_15_22))))); // decl: <none>; prim: <none>
    assign mul_tree_15_24 = {mul_tree_15_23, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_14[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = __beopt_width_15[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_27 = 16'(($unsigned(16'($unsigned(mul_tree_15_25))) * $unsigned(16'($unsigned(mul_tree_15_26))))); // decl: <none>; prim: <none>
    assign mul_tree_15_28 = {mul_tree_15_27, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_14[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = __beopt_width_15[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_31 = 16'(($unsigned(16'($unsigned(mul_tree_15_29))) * $unsigned(16'($unsigned(mul_tree_15_30))))); // decl: <none>; prim: <none>
    assign mul_tree_15_32 = {mul_tree_15_31, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = ({9'h0, rtlzz_pipe_20_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_34 = ({1'h0, rtlzz_pipe_24_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = 25'((mul_tree_15_33 + mul_tree_15_34 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_36 = ({9'h0, rtlzz_pipe_28_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_37 = ({1'h0, rtlzz_pipe_32_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 33'((mul_tree_15_36 + mul_tree_15_37 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = ({9'h0, mul_tree_15_35}); // decl: <none>; prim: <none>
    assign mul_tree_15_40 = ({1'h0, mul_tree_15_38}); // decl: <none>; prim: <none>
    assign mul_tree_15_41 = 34'((mul_tree_15_39 + mul_tree_15_40 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_42 = mul_tree_15_41[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_43 = __beopt_width_14[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_44 = __beopt_width_18[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_45 = 16'(($unsigned(16'($unsigned(mul_tree_16_43))) * $unsigned(16'($unsigned(mul_tree_16_44))))); // decl: <none>; prim: <none>
    assign mul_tree_16_46 = __beopt_width_14[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_47 = __beopt_width_18[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_48 = 16'(($unsigned(16'($unsigned(mul_tree_16_46))) * $unsigned(16'($unsigned(mul_tree_16_47))))); // decl: <none>; prim: <none>
    assign mul_tree_16_49 = {mul_tree_16_48, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_50 = __beopt_width_14[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_51 = __beopt_width_18[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_52 = 16'(($unsigned(16'($unsigned(mul_tree_16_50))) * $unsigned(16'($unsigned(mul_tree_16_51))))); // decl: <none>; prim: <none>
    assign mul_tree_16_53 = {mul_tree_16_52, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_54 = __beopt_width_14[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_55 = __beopt_width_18[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_56 = 16'(($unsigned(16'($unsigned(mul_tree_16_54))) * $unsigned(16'($unsigned(mul_tree_16_55))))); // decl: <none>; prim: <none>
    assign mul_tree_16_57 = {mul_tree_16_56, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_58 = ({9'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_59 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_60 = 25'((mul_tree_16_58 + mul_tree_16_59 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_61 = ({9'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_62 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_63 = 33'((mul_tree_16_61 + mul_tree_16_62 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_64 = ({9'h0, mul_tree_16_60}); // decl: <none>; prim: <none>
    assign mul_tree_16_65 = ({1'h0, mul_tree_16_63}); // decl: <none>; prim: <none>
    assign mul_tree_16_66 = 34'((mul_tree_16_64 + mul_tree_16_65 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_67 = mul_tree_16_66[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_68 = __beopt_width_15[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_69 = __beopt_width_18[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_70 = 16'(($unsigned(16'($unsigned(mul_tree_17_68))) * $unsigned(16'($unsigned(mul_tree_17_69))))); // decl: <none>; prim: <none>
    assign mul_tree_17_71 = __beopt_width_15[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_72 = __beopt_width_18[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_17_73 = 16'(($unsigned(16'($unsigned(mul_tree_17_71))) * $unsigned(16'($unsigned(mul_tree_17_72))))); // decl: <none>; prim: <none>
    assign mul_tree_17_74 = {mul_tree_17_73, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_75 = __beopt_width_15[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_17_76 = __beopt_width_18[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_77 = 16'(($unsigned(16'($unsigned(mul_tree_17_75))) * $unsigned(16'($unsigned(mul_tree_17_76))))); // decl: <none>; prim: <none>
    assign mul_tree_17_78 = {mul_tree_17_77, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_79 = __beopt_width_15[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_17_80 = __beopt_width_18[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_17_81 = 16'(($unsigned(16'($unsigned(mul_tree_17_79))) * $unsigned(16'($unsigned(mul_tree_17_80))))); // decl: <none>; prim: <none>
    assign mul_tree_17_82 = {mul_tree_17_81, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_83 = ({9'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_84 = ({1'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_85 = 25'((mul_tree_17_83 + mul_tree_17_84 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_86 = ({9'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_87 = ({1'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_88 = 33'((mul_tree_17_86 + mul_tree_17_87 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_89 = ({9'h0, mul_tree_17_85}); // decl: <none>; prim: <none>
    assign mul_tree_17_90 = ({1'h0, mul_tree_17_88}); // decl: <none>; prim: <none>
    assign mul_tree_17_91 = 34'((mul_tree_17_89 + mul_tree_17_90 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_92 = mul_tree_17_91[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        rtlzz_pipe_20_s1 <= mul_tree_15_20; // decl: <none>; prim: <none>
        rtlzz_pipe_24_s1 <= mul_tree_15_24; // decl: <none>; prim: <none>
        rtlzz_pipe_28_s1 <= mul_tree_15_28; // decl: <none>; prim: <none>
        rtlzz_pipe_32_s1 <= mul_tree_15_32; // decl: <none>; prim: <none>
        rtlzz_pipe_3_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:14-9:17; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:12
        rtlzz_pipe_45_s1 <= mul_tree_16_45; // decl: <none>; prim: <none>
        rtlzz_pipe_49_s1 <= mul_tree_16_49; // decl: <none>; prim: <none>
        rtlzz_pipe_53_s1 <= mul_tree_16_53; // decl: <none>; prim: <none>
        rtlzz_pipe_57_s1 <= mul_tree_16_57; // decl: <none>; prim: <none>
        rtlzz_pipe_4_s2 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:20-9:23; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
        rtlzz_pipe_70_s1 <= mul_tree_17_70; // decl: <none>; prim: <none>
        rtlzz_pipe_74_s1 <= mul_tree_17_74; // decl: <none>; prim: <none>
        rtlzz_pipe_78_s1 <= mul_tree_17_78; // decl: <none>; prim: <none>
        rtlzz_pipe_82_s1 <= mul_tree_17_82; // decl: <none>; prim: <none>
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/K16.logic.cpp:9:26-9:29; prim: /home/zyrv/vulsim/K16.logic.cpp:2:1-2:14
    end
endmodule
