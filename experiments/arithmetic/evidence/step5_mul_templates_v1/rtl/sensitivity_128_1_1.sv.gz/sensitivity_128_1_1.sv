`timescale 1ns/1ps

module sensitivity_128_1(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    input logic [256:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24
    output logic [256:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:56
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [256:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    logic [255:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [256:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [255:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [63:0] mul_tree_11_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_13; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_14; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_16; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_17; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_11_18; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_21; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_11_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_24; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_25; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_11_26; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_11_27; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_11_28; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_11_29; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_11_30; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_11_31; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_11_32; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_11_33; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_11_34; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_11_35; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_11_36; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24
    logic [192:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    assign y = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:56
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, s8_norm_mul_0_v0}); // decl: <none>; prim: <none>
    assign arith_original_11 = mul_tree_11_36; // decl: <none>; prim: <none>
    assign mul_tree_11_12 = __beopt_width_11[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_13 = __beopt_width_12[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_14 = 128'(($unsigned(128'($unsigned(mul_tree_11_12))) * $unsigned(128'($unsigned(mul_tree_11_13))))); // decl: <none>; prim: <none>
    assign mul_tree_11_15 = __beopt_width_11[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_16 = __beopt_width_12[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_11_17 = 128'(($unsigned(128'($unsigned(mul_tree_11_15))) * $unsigned(128'($unsigned(mul_tree_11_16))))); // decl: <none>; prim: <none>
    assign mul_tree_11_18 = {mul_tree_11_17, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_19 = __beopt_width_11[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_11_20 = __beopt_width_12[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_21 = 128'(($unsigned(128'($unsigned(mul_tree_11_19))) * $unsigned(128'($unsigned(mul_tree_11_20))))); // decl: <none>; prim: <none>
    assign mul_tree_11_22 = {mul_tree_11_21, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_23 = __beopt_width_11[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_11_24 = __beopt_width_12[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_11_25 = 128'(($unsigned(128'($unsigned(mul_tree_11_23))) * $unsigned(128'($unsigned(mul_tree_11_24))))); // decl: <none>; prim: <none>
    assign mul_tree_11_26 = {mul_tree_11_25, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_27 = ({65'h0, mul_tree_11_14}); // decl: <none>; prim: <none>
    assign mul_tree_11_28 = ({1'h0, mul_tree_11_18}); // decl: <none>; prim: <none>
    assign mul_tree_11_29 = 193'((mul_tree_11_27 + mul_tree_11_28 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_30 = ({65'h0, mul_tree_11_22}); // decl: <none>; prim: <none>
    assign mul_tree_11_31 = ({1'h0, mul_tree_11_26}); // decl: <none>; prim: <none>
    assign mul_tree_11_32 = 257'((mul_tree_11_30 + mul_tree_11_31 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_33 = ({65'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_34 = ({1'h0, rtlzz_pipe_32_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_35 = 258'((mul_tree_11_33 + mul_tree_11_34 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_36 = mul_tree_11_35[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_11_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_tree_11_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:43-9:56; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    end
endmodule
