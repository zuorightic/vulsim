`timescale 1ns/1ps

module w8_low_1(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [7:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25
    output logic [7:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:35; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:17-10:22
    output logic [7:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:23-10:28
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [7:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic [7:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic [3:0] mul_tree_9_11; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_12; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_9_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_14; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_9_16; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_17; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_9_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_21; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_9_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_9_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_9_25; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_9_26; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_9_27; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_9_28; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_9_29; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_9_30; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_9_31; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_9_32; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_9_33; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_9_34; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_9_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
    logic [7:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:35; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:17-10:22
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:23-10:28
    assign arith_original_9 = mul_tree_9_35; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_60; // decl: <none>; prim: <none>
    assign mul_tree_9_11 = a[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_12 = b[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_13 = 8'(($unsigned(8'($unsigned(mul_tree_9_11))) * $unsigned(8'($unsigned(mul_tree_9_12))))); // decl: <none>; prim: <none>
    assign mul_tree_9_14 = a[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_15 = b[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_9_16 = 8'(($unsigned(8'($unsigned(mul_tree_9_14))) * $unsigned(8'($unsigned(mul_tree_9_15))))); // decl: <none>; prim: <none>
    assign mul_tree_9_17 = {mul_tree_9_16, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_18 = a[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_9_19 = b[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_20 = 8'(($unsigned(8'($unsigned(mul_tree_9_18))) * $unsigned(8'($unsigned(mul_tree_9_19))))); // decl: <none>; prim: <none>
    assign mul_tree_9_21 = {mul_tree_9_20, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_22 = a[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_9_23 = b[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_9_24 = 8'(($unsigned(8'($unsigned(mul_tree_9_22))) * $unsigned(8'($unsigned(mul_tree_9_23))))); // decl: <none>; prim: <none>
    assign mul_tree_9_25 = {mul_tree_9_24, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_26 = ({5'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_28 = 13'((mul_tree_9_26 + mul_tree_9_27 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_29 = ({5'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_31 = 17'((mul_tree_9_29 + mul_tree_9_30 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_32 = ({5'h0, mul_tree_9_28}); // decl: <none>; prim: <none>
    assign mul_tree_9_33 = ({1'h0, mul_tree_9_31}); // decl: <none>; prim: <none>
    assign mul_tree_9_34 = 18'((mul_tree_9_32 + mul_tree_9_33 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_35 = mul_tree_9_34[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = a[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_37 = c[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = 8'(($unsigned(8'($unsigned(mul_tree_10_36))) * $unsigned(8'($unsigned(mul_tree_10_37))))); // decl: <none>; prim: <none>
    assign mul_tree_10_39 = a[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = c[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_41 = 8'(($unsigned(8'($unsigned(mul_tree_10_39))) * $unsigned(8'($unsigned(mul_tree_10_40))))); // decl: <none>; prim: <none>
    assign mul_tree_10_42 = {mul_tree_10_41, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = a[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = c[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_45 = 8'(($unsigned(8'($unsigned(mul_tree_10_43))) * $unsigned(8'($unsigned(mul_tree_10_44))))); // decl: <none>; prim: <none>
    assign mul_tree_10_46 = {mul_tree_10_45, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = a[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = c[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_49 = 8'(($unsigned(8'($unsigned(mul_tree_10_47))) * $unsigned(8'($unsigned(mul_tree_10_48))))); // decl: <none>; prim: <none>
    assign mul_tree_10_50 = {mul_tree_10_49, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = ({5'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_52 = ({1'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = 13'((mul_tree_10_51 + mul_tree_10_52 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_54 = ({5'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_55 = ({1'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 17'((mul_tree_10_54 + mul_tree_10_55 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = ({5'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_58 = ({1'h0, mul_tree_10_56}); // decl: <none>; prim: <none>
    assign mul_tree_10_59 = 18'((mul_tree_10_57 + mul_tree_10_58 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_60 = mul_tree_10_59[7:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 8'h23;
            rtlzz_pipe_17_s1 <= 12'h0;
            rtlzz_pipe_21_s1 <= 12'h0;
            rtlzz_pipe_25_s1 <= 16'h0;
            rtlzz_pipe_4_s2 <= 8'h23;
            rtlzz_pipe_38_s1 <= 8'h37;
            rtlzz_pipe_42_s1 <= 12'h0;
            rtlzz_pipe_46_s1 <= 12'h0;
            rtlzz_pipe_50_s1 <= 16'h0;
            rtlzz_pipe_5_s2 <= 8'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_9_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_9_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_9_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_9_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:22
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_10_38; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_10_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_10_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_10_50; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:28
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        end
    end
endmodule
