`timescale 1ns/1ps

module sensitivity_8_1(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [16:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    output logic [16:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:38-9:52
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [16:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [16:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [15:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [16:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    logic [15:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [16:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    assign y = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:38-9:52
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({8'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, rtlzz_pipe_4_s1}); // decl: <none>; prim: <none>
    assign arith_original_11 = 16'(($unsigned(16'($unsigned(__beopt_width_11))) * $unsigned(16'($unsigned(__beopt_width_12))))); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    end
endmodule
