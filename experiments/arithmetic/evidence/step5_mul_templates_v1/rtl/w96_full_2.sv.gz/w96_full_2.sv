`timescale 1ns/1ps

module w96_full_2(
    input logic [95:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [95:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [95:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [191:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:38; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [191:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:40; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [191:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [191:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [95:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    logic [95:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [95:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [191:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [191:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [191:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [191:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [191:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [23:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_66; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_15_67; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_68; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_69; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_70; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_15_71; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_72; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_73; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_74; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_15_75; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_76; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_77; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_78; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_79; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_80; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_81; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_82; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_83; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_84; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_85; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_86; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_87; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_88; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_89; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_90; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_91; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_92; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_93; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_15_94; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_15_95; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_15_96; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_15_97; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_98; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_99; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_15_100; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_101; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_102; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_103; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_15_104; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_15_105; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_15_106; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_15_107; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_15_108; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_15_109; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_15_110; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_15_111; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_15_112; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_113; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_114; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_115; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_15_116; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_15_117; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_15_118; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_119; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_120; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_121; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_15_122; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_15_123; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_15_124; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_126; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_127; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_128; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_129; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_130; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_131; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_16_132; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_133; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_134; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_135; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_16_136; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_137; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_138; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_139; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_16_140; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_141; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_142; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_143; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_16_144; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_145; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_146; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_147; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_16_148; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_149; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_150; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_151; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_16_152; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_153; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_154; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_155; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_16_156; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_157; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_158; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_159; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_16_160; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_161; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_162; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_163; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_16_164; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_165; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_166; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_167; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_16_168; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_169; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_170; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_171; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_16_172; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_173; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_174; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_175; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_16_176; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_177; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_178; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_179; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_16_180; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_181; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_182; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_183; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_16_184; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_185; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_186; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_16_187; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_16_188; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_16_189; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_16_190; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_16_191; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_192; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_193; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_194; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_16_195; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_16_196; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_16_197; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_198; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_199; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_200; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_201; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_202; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_16_203; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_16_204; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_16_205; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_16_206; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_207; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_208; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_16_209; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_210; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_211; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_212; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_16_213; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_16_214; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_16_215; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_16_216; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_16_217; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_16_218; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_16_219; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_16_220; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_16_221; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_16_222; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_16_223; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_16_224; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_16_225; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_16_226; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_16_227; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_16_228; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_16_229; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_16_230; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_16_231; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_16_232; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_16_233; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_16_234; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [47:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_132_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_136_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_140_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_144_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_156_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_160_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_164_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_168_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_172_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_176_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_180_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_184_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_188_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:38; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:40; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({96'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({96'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({96'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_125; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_234; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 48'(($unsigned(48'($unsigned(mul_tree_15_17))) * $unsigned(48'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 48'(($unsigned(48'($unsigned(mul_tree_15_20))) * $unsigned(48'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 48'(($unsigned(48'($unsigned(mul_tree_15_24))) * $unsigned(48'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 48'(($unsigned(48'($unsigned(mul_tree_15_28))) * $unsigned(48'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = __beopt_width_15[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 48'(($unsigned(48'($unsigned(mul_tree_15_32))) * $unsigned(48'($unsigned(mul_tree_15_33))))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = {mul_tree_15_34, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_36 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_37 = __beopt_width_15[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 48'(($unsigned(48'($unsigned(mul_tree_15_36))) * $unsigned(48'($unsigned(mul_tree_15_37))))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = {mul_tree_15_38, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_40 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_15[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = 48'(($unsigned(48'($unsigned(mul_tree_15_40))) * $unsigned(48'($unsigned(mul_tree_15_41))))); // decl: <none>; prim: <none>
    assign mul_tree_15_43 = {mul_tree_15_42, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_15[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 48'(($unsigned(48'($unsigned(mul_tree_15_44))) * $unsigned(48'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_15[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 48'(($unsigned(48'($unsigned(mul_tree_15_48))) * $unsigned(48'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_15[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 48'(($unsigned(48'($unsigned(mul_tree_15_52))) * $unsigned(48'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_57 = __beopt_width_15[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 48'(($unsigned(48'($unsigned(mul_tree_15_56))) * $unsigned(48'($unsigned(mul_tree_15_57))))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = {mul_tree_15_58, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_60 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_61 = __beopt_width_15[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_62 = 48'(($unsigned(48'($unsigned(mul_tree_15_60))) * $unsigned(48'($unsigned(mul_tree_15_61))))); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = {mul_tree_15_62, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_64 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_65 = __beopt_width_15[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_66 = 48'(($unsigned(48'($unsigned(mul_tree_15_64))) * $unsigned(48'($unsigned(mul_tree_15_65))))); // decl: <none>; prim: <none>
    assign mul_tree_15_67 = {mul_tree_15_66, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_68 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_69 = __beopt_width_15[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_70 = 48'(($unsigned(48'($unsigned(mul_tree_15_68))) * $unsigned(48'($unsigned(mul_tree_15_69))))); // decl: <none>; prim: <none>
    assign mul_tree_15_71 = {mul_tree_15_70, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_72 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_73 = __beopt_width_15[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_74 = 48'(($unsigned(48'($unsigned(mul_tree_15_72))) * $unsigned(48'($unsigned(mul_tree_15_73))))); // decl: <none>; prim: <none>
    assign mul_tree_15_75 = {mul_tree_15_74, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_76 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_77 = __beopt_width_15[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_15_78 = 48'(($unsigned(48'($unsigned(mul_tree_15_76))) * $unsigned(48'($unsigned(mul_tree_15_77))))); // decl: <none>; prim: <none>
    assign mul_tree_15_79 = {mul_tree_15_78, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_80 = ({25'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_81 = ({1'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_82 = 73'((mul_tree_15_80 + mul_tree_15_81 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_83 = ({25'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_84 = ({1'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_85 = 121'((mul_tree_15_83 + mul_tree_15_84 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_86 = ({25'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_87 = ({1'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_88 = 97'((mul_tree_15_86 + mul_tree_15_87 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_89 = ({25'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_90 = ({1'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_91 = 145'((mul_tree_15_89 + mul_tree_15_90 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_92 = ({25'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_93 = ({1'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_94 = 121'((mul_tree_15_92 + mul_tree_15_93 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_95 = ({25'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_96 = ({1'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_97 = 169'((mul_tree_15_95 + mul_tree_15_96 + ({168'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_98 = ({25'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_99 = ({1'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_100 = 145'((mul_tree_15_98 + mul_tree_15_99 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_101 = ({25'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_102 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_103 = 193'((mul_tree_15_101 + mul_tree_15_102 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_104 = ({49'h0, mul_tree_15_82}); // decl: <none>; prim: <none>
    assign mul_tree_15_105 = ({1'h0, mul_tree_15_85}); // decl: <none>; prim: <none>
    assign mul_tree_15_106 = 122'((mul_tree_15_104 + mul_tree_15_105 + ({121'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_107 = ({49'h0, mul_tree_15_88}); // decl: <none>; prim: <none>
    assign mul_tree_15_108 = ({1'h0, mul_tree_15_91}); // decl: <none>; prim: <none>
    assign mul_tree_15_109 = 146'((mul_tree_15_107 + mul_tree_15_108 + ({145'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_110 = ({49'h0, mul_tree_15_94}); // decl: <none>; prim: <none>
    assign mul_tree_15_111 = ({1'h0, mul_tree_15_97}); // decl: <none>; prim: <none>
    assign mul_tree_15_112 = 170'((mul_tree_15_110 + mul_tree_15_111 + ({169'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_113 = ({49'h0, mul_tree_15_100}); // decl: <none>; prim: <none>
    assign mul_tree_15_114 = ({1'h0, mul_tree_15_103}); // decl: <none>; prim: <none>
    assign mul_tree_15_115 = 194'((mul_tree_15_113 + mul_tree_15_114 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_116 = ({25'h0, mul_tree_15_106}); // decl: <none>; prim: <none>
    assign mul_tree_15_117 = ({1'h0, mul_tree_15_109}); // decl: <none>; prim: <none>
    assign mul_tree_15_118 = 147'((mul_tree_15_116 + mul_tree_15_117 + ({146'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_119 = ({25'h0, mul_tree_15_112}); // decl: <none>; prim: <none>
    assign mul_tree_15_120 = ({1'h0, mul_tree_15_115}); // decl: <none>; prim: <none>
    assign mul_tree_15_121 = 195'((mul_tree_15_119 + mul_tree_15_120 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_122 = ({49'h0, mul_tree_15_118}); // decl: <none>; prim: <none>
    assign mul_tree_15_123 = ({1'h0, mul_tree_15_121}); // decl: <none>; prim: <none>
    assign mul_tree_15_124 = 196'((mul_tree_15_122 + mul_tree_15_123 + ({195'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_125 = mul_tree_15_124[191:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_126 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_127 = __beopt_width_18[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_128 = 48'(($unsigned(48'($unsigned(mul_tree_16_126))) * $unsigned(48'($unsigned(mul_tree_16_127))))); // decl: <none>; prim: <none>
    assign mul_tree_16_129 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_130 = __beopt_width_18[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_131 = 48'(($unsigned(48'($unsigned(mul_tree_16_129))) * $unsigned(48'($unsigned(mul_tree_16_130))))); // decl: <none>; prim: <none>
    assign mul_tree_16_132 = {mul_tree_16_131, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_133 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_134 = __beopt_width_18[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_135 = 48'(($unsigned(48'($unsigned(mul_tree_16_133))) * $unsigned(48'($unsigned(mul_tree_16_134))))); // decl: <none>; prim: <none>
    assign mul_tree_16_136 = {mul_tree_16_135, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_137 = __beopt_width_14[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_138 = __beopt_width_18[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_139 = 48'(($unsigned(48'($unsigned(mul_tree_16_137))) * $unsigned(48'($unsigned(mul_tree_16_138))))); // decl: <none>; prim: <none>
    assign mul_tree_16_140 = {mul_tree_16_139, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_141 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_142 = __beopt_width_18[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_143 = 48'(($unsigned(48'($unsigned(mul_tree_16_141))) * $unsigned(48'($unsigned(mul_tree_16_142))))); // decl: <none>; prim: <none>
    assign mul_tree_16_144 = {mul_tree_16_143, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_145 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_146 = __beopt_width_18[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_147 = 48'(($unsigned(48'($unsigned(mul_tree_16_145))) * $unsigned(48'($unsigned(mul_tree_16_146))))); // decl: <none>; prim: <none>
    assign mul_tree_16_148 = {mul_tree_16_147, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_149 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_150 = __beopt_width_18[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_151 = 48'(($unsigned(48'($unsigned(mul_tree_16_149))) * $unsigned(48'($unsigned(mul_tree_16_150))))); // decl: <none>; prim: <none>
    assign mul_tree_16_152 = {mul_tree_16_151, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_153 = __beopt_width_14[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_154 = __beopt_width_18[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_155 = 48'(($unsigned(48'($unsigned(mul_tree_16_153))) * $unsigned(48'($unsigned(mul_tree_16_154))))); // decl: <none>; prim: <none>
    assign mul_tree_16_156 = {mul_tree_16_155, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_157 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_158 = __beopt_width_18[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_159 = 48'(($unsigned(48'($unsigned(mul_tree_16_157))) * $unsigned(48'($unsigned(mul_tree_16_158))))); // decl: <none>; prim: <none>
    assign mul_tree_16_160 = {mul_tree_16_159, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_161 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_162 = __beopt_width_18[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_163 = 48'(($unsigned(48'($unsigned(mul_tree_16_161))) * $unsigned(48'($unsigned(mul_tree_16_162))))); // decl: <none>; prim: <none>
    assign mul_tree_16_164 = {mul_tree_16_163, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_165 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_166 = __beopt_width_18[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_167 = 48'(($unsigned(48'($unsigned(mul_tree_16_165))) * $unsigned(48'($unsigned(mul_tree_16_166))))); // decl: <none>; prim: <none>
    assign mul_tree_16_168 = {mul_tree_16_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_169 = __beopt_width_14[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_170 = __beopt_width_18[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_171 = 48'(($unsigned(48'($unsigned(mul_tree_16_169))) * $unsigned(48'($unsigned(mul_tree_16_170))))); // decl: <none>; prim: <none>
    assign mul_tree_16_172 = {mul_tree_16_171, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_173 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_174 = __beopt_width_18[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_175 = 48'(($unsigned(48'($unsigned(mul_tree_16_173))) * $unsigned(48'($unsigned(mul_tree_16_174))))); // decl: <none>; prim: <none>
    assign mul_tree_16_176 = {mul_tree_16_175, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_177 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_178 = __beopt_width_18[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_16_179 = 48'(($unsigned(48'($unsigned(mul_tree_16_177))) * $unsigned(48'($unsigned(mul_tree_16_178))))); // decl: <none>; prim: <none>
    assign mul_tree_16_180 = {mul_tree_16_179, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_181 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_182 = __beopt_width_18[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_16_183 = 48'(($unsigned(48'($unsigned(mul_tree_16_181))) * $unsigned(48'($unsigned(mul_tree_16_182))))); // decl: <none>; prim: <none>
    assign mul_tree_16_184 = {mul_tree_16_183, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_185 = __beopt_width_14[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_186 = __beopt_width_18[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_16_187 = 48'(($unsigned(48'($unsigned(mul_tree_16_185))) * $unsigned(48'($unsigned(mul_tree_16_186))))); // decl: <none>; prim: <none>
    assign mul_tree_16_188 = {mul_tree_16_187, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_189 = ({25'h0, rtlzz_pipe_128_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_190 = ({1'h0, rtlzz_pipe_132_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_191 = 73'((mul_tree_16_189 + mul_tree_16_190 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_192 = ({25'h0, rtlzz_pipe_136_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_193 = ({1'h0, rtlzz_pipe_140_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_194 = 121'((mul_tree_16_192 + mul_tree_16_193 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_195 = ({25'h0, rtlzz_pipe_144_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_196 = ({1'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_197 = 97'((mul_tree_16_195 + mul_tree_16_196 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_198 = ({25'h0, rtlzz_pipe_152_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_199 = ({1'h0, rtlzz_pipe_156_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_200 = 145'((mul_tree_16_198 + mul_tree_16_199 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_201 = ({25'h0, rtlzz_pipe_160_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_202 = ({1'h0, rtlzz_pipe_164_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_203 = 121'((mul_tree_16_201 + mul_tree_16_202 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_204 = ({25'h0, rtlzz_pipe_168_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_205 = ({1'h0, rtlzz_pipe_172_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_206 = 169'((mul_tree_16_204 + mul_tree_16_205 + ({168'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_207 = ({25'h0, rtlzz_pipe_176_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_208 = ({1'h0, rtlzz_pipe_180_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_209 = 145'((mul_tree_16_207 + mul_tree_16_208 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_210 = ({25'h0, rtlzz_pipe_184_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_211 = ({1'h0, rtlzz_pipe_188_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_212 = 193'((mul_tree_16_210 + mul_tree_16_211 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_213 = ({49'h0, mul_tree_16_191}); // decl: <none>; prim: <none>
    assign mul_tree_16_214 = ({1'h0, mul_tree_16_194}); // decl: <none>; prim: <none>
    assign mul_tree_16_215 = 122'((mul_tree_16_213 + mul_tree_16_214 + ({121'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_216 = ({49'h0, mul_tree_16_197}); // decl: <none>; prim: <none>
    assign mul_tree_16_217 = ({1'h0, mul_tree_16_200}); // decl: <none>; prim: <none>
    assign mul_tree_16_218 = 146'((mul_tree_16_216 + mul_tree_16_217 + ({145'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_219 = ({49'h0, mul_tree_16_203}); // decl: <none>; prim: <none>
    assign mul_tree_16_220 = ({1'h0, mul_tree_16_206}); // decl: <none>; prim: <none>
    assign mul_tree_16_221 = 170'((mul_tree_16_219 + mul_tree_16_220 + ({169'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_222 = ({49'h0, mul_tree_16_209}); // decl: <none>; prim: <none>
    assign mul_tree_16_223 = ({1'h0, mul_tree_16_212}); // decl: <none>; prim: <none>
    assign mul_tree_16_224 = 194'((mul_tree_16_222 + mul_tree_16_223 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_225 = ({25'h0, mul_tree_16_215}); // decl: <none>; prim: <none>
    assign mul_tree_16_226 = ({1'h0, mul_tree_16_218}); // decl: <none>; prim: <none>
    assign mul_tree_16_227 = 147'((mul_tree_16_225 + mul_tree_16_226 + ({146'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_228 = ({25'h0, mul_tree_16_221}); // decl: <none>; prim: <none>
    assign mul_tree_16_229 = ({1'h0, mul_tree_16_224}); // decl: <none>; prim: <none>
    assign mul_tree_16_230 = 195'((mul_tree_16_228 + mul_tree_16_229 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_231 = ({49'h0, mul_tree_16_227}); // decl: <none>; prim: <none>
    assign mul_tree_16_232 = ({1'h0, mul_tree_16_230}); // decl: <none>; prim: <none>
    assign mul_tree_16_233 = 196'((mul_tree_16_231 + mul_tree_16_232 + ({195'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_234 = mul_tree_16_233[191:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_19_s1 <= 48'h23;
            rtlzz_pipe_23_s1 <= 72'h0;
            rtlzz_pipe_27_s1 <= 96'h0;
            rtlzz_pipe_31_s1 <= 120'h0;
            rtlzz_pipe_35_s1 <= 72'h0;
            rtlzz_pipe_39_s1 <= 96'h0;
            rtlzz_pipe_43_s1 <= 120'h0;
            rtlzz_pipe_47_s1 <= 144'h0;
            rtlzz_pipe_51_s1 <= 96'h0;
            rtlzz_pipe_55_s1 <= 120'h0;
            rtlzz_pipe_59_s1 <= 144'h0;
            rtlzz_pipe_63_s1 <= 168'h0;
            rtlzz_pipe_67_s1 <= 120'h0;
            rtlzz_pipe_71_s1 <= 144'h0;
            rtlzz_pipe_75_s1 <= 168'h0;
            rtlzz_pipe_79_s1 <= 192'h0;
            rtlzz_pipe_4_s2 <= 192'h23;
            rtlzz_pipe_128_s1 <= 48'h37;
            rtlzz_pipe_132_s1 <= 72'h0;
            rtlzz_pipe_136_s1 <= 96'h0;
            rtlzz_pipe_140_s1 <= 120'h0;
            rtlzz_pipe_144_s1 <= 72'h0;
            rtlzz_pipe_148_s1 <= 96'h0;
            rtlzz_pipe_152_s1 <= 120'h0;
            rtlzz_pipe_156_s1 <= 144'h0;
            rtlzz_pipe_160_s1 <= 96'h0;
            rtlzz_pipe_164_s1 <= 120'h0;
            rtlzz_pipe_168_s1 <= 144'h0;
            rtlzz_pipe_172_s1 <= 168'h0;
            rtlzz_pipe_176_s1 <= 120'h0;
            rtlzz_pipe_180_s1 <= 144'h0;
            rtlzz_pipe_184_s1 <= 168'h0;
            rtlzz_pipe_188_s1 <= 192'h0;
            rtlzz_pipe_5_s2 <= 192'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_15_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_15_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_15_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_15_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_15_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_15_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_15_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_15_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_15_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_15_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_15_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_15_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_15_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_15_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_15_75; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_15_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_tree_16_128; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_132_s1 <= mul_tree_16_132; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_136_s1 <= mul_tree_16_136; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_140_s1 <= mul_tree_16_140; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_144_s1 <= mul_tree_16_144; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_16_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= mul_tree_16_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= mul_tree_16_156; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_160_s1 <= mul_tree_16_160; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_164_s1 <= mul_tree_16_164; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_168_s1 <= mul_tree_16_168; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_172_s1 <= mul_tree_16_172; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_176_s1 <= mul_tree_16_176; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_180_s1 <= mul_tree_16_180; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_184_s1 <= mul_tree_16_184; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_188_s1 <= mul_tree_16_188; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
