`timescale 1ns/1ps

module w128_low_0(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic [127:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27
    output logic [127:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [127:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic [127:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic [127:0] rtlzz_pipe_4_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] rtlzz_pipe_5_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic [127:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign arith_original_9 = 128'(($unsigned(128'($unsigned(a))) * $unsigned(128'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    assign arith_original_10 = 128'(($unsigned(128'($unsigned(a))) * $unsigned(128'($unsigned(c))))); // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_4_s1 <= 128'h23;
            rtlzz_pipe_4_s2 <= 128'h23;
            rtlzz_pipe_5_s1 <= 128'h37;
            rtlzz_pipe_5_s2 <= 128'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        end
    end
endmodule
