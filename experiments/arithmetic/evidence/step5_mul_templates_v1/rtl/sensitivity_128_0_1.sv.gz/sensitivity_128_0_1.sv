`timescale 1ns/1ps

module sensitivity_128_0(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    input logic [256:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:24
    output logic [256:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:37
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [255:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [256:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic [63:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:14-2:26; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 128'(($unsigned(128'($unsigned(mul_tree_10_11))) * $unsigned(128'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 128'(($unsigned(128'($unsigned(mul_tree_10_14))) * $unsigned(128'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 128'(($unsigned(128'($unsigned(mul_tree_10_18))) * $unsigned(128'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 128'(($unsigned(128'($unsigned(mul_tree_10_22))) * $unsigned(128'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({65'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 193'((mul_tree_10_26 + mul_tree_10_27 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({65'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 257'((mul_tree_10_29 + mul_tree_10_30 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({65'h0, rtlzz_pipe_28_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 258'((mul_tree_10_32 + mul_tree_10_33 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_28_s1 <= mul_tree_10_28; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_10_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:37-9:40; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:13
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:27-2:34
    end
endmodule
