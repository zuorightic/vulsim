`timescale 1ns/1ps

module sensitivity_64_0(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [128:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23
    output logic [128:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [127:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [127:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [127:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [127:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({64'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({64'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = 128'(($unsigned(128'($unsigned(__beopt_width_10))) * $unsigned(128'($unsigned(__beopt_width_11))))); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    end
endmodule
