`timescale 1ns/1ps

module sensitivity_32_1(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [64:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    output logic [64:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [64:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [63:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [64:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [64:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    assign y = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, rtlzz_pipe_4_s1}); // decl: <none>; prim: <none>
    assign arith_original_11 = 64'(($unsigned(64'($unsigned(__beopt_width_11))) * $unsigned(64'($unsigned(__beopt_width_12))))); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    end
endmodule
