`timescale 1ns/1ps

module w96_low_1(
    input logic [95:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [95:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [95:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [95:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    output logic [95:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [95:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [95:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [95:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [95:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [47:0] mul_tree_9_11; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_12; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_9_13; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_14; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_15; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_9_16; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_9_17; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_19; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_9_20; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_9_21; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_22; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_9_23; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_9_24; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_9_25; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_9_26; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_9_27; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_9_28; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_29; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_30; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_31; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_9_32; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_9_33; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_9_34; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_9_35; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [144:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [144:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_56_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    assign arith_original_9 = mul_tree_9_35; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_60; // decl: <none>; prim: <none>
    assign mul_tree_9_11 = a[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_12 = b[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_13 = 96'(($unsigned(96'($unsigned(mul_tree_9_11))) * $unsigned(96'($unsigned(mul_tree_9_12))))); // decl: <none>; prim: <none>
    assign mul_tree_9_14 = a[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_15 = b[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_9_16 = 96'(($unsigned(96'($unsigned(mul_tree_9_14))) * $unsigned(96'($unsigned(mul_tree_9_15))))); // decl: <none>; prim: <none>
    assign mul_tree_9_17 = {mul_tree_9_16, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_18 = a[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_9_19 = b[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_20 = 96'(($unsigned(96'($unsigned(mul_tree_9_18))) * $unsigned(96'($unsigned(mul_tree_9_19))))); // decl: <none>; prim: <none>
    assign mul_tree_9_21 = {mul_tree_9_20, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_22 = a[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_9_23 = b[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_9_24 = 96'(($unsigned(96'($unsigned(mul_tree_9_22))) * $unsigned(96'($unsigned(mul_tree_9_23))))); // decl: <none>; prim: <none>
    assign mul_tree_9_25 = {mul_tree_9_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_26 = ({49'h0, mul_tree_9_13}); // decl: <none>; prim: <none>
    assign mul_tree_9_27 = ({1'h0, mul_tree_9_17}); // decl: <none>; prim: <none>
    assign mul_tree_9_28 = 145'((mul_tree_9_26 + mul_tree_9_27 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_29 = ({49'h0, mul_tree_9_21}); // decl: <none>; prim: <none>
    assign mul_tree_9_30 = ({1'h0, mul_tree_9_25}); // decl: <none>; prim: <none>
    assign mul_tree_9_31 = 193'((mul_tree_9_29 + mul_tree_9_30 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_32 = ({49'h0, rtlzz_pipe_28_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_33 = ({1'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_34 = 194'((mul_tree_9_32 + mul_tree_9_33 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_35 = mul_tree_9_34[95:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = a[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_37 = c[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = 96'(($unsigned(96'($unsigned(mul_tree_10_36))) * $unsigned(96'($unsigned(mul_tree_10_37))))); // decl: <none>; prim: <none>
    assign mul_tree_10_39 = a[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = c[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_41 = 96'(($unsigned(96'($unsigned(mul_tree_10_39))) * $unsigned(96'($unsigned(mul_tree_10_40))))); // decl: <none>; prim: <none>
    assign mul_tree_10_42 = {mul_tree_10_41, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = a[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = c[47:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_45 = 96'(($unsigned(96'($unsigned(mul_tree_10_43))) * $unsigned(96'($unsigned(mul_tree_10_44))))); // decl: <none>; prim: <none>
    assign mul_tree_10_46 = {mul_tree_10_45, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = a[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = c[95:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_49 = 96'(($unsigned(96'($unsigned(mul_tree_10_47))) * $unsigned(96'($unsigned(mul_tree_10_48))))); // decl: <none>; prim: <none>
    assign mul_tree_10_50 = {mul_tree_10_49, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = ({49'h0, mul_tree_10_38}); // decl: <none>; prim: <none>
    assign mul_tree_10_52 = ({1'h0, mul_tree_10_42}); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = 145'((mul_tree_10_51 + mul_tree_10_52 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_54 = ({49'h0, mul_tree_10_46}); // decl: <none>; prim: <none>
    assign mul_tree_10_55 = ({1'h0, mul_tree_10_50}); // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 193'((mul_tree_10_54 + mul_tree_10_55 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = ({49'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_58 = ({1'h0, rtlzz_pipe_56_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_59 = 194'((mul_tree_10_57 + mul_tree_10_58 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_60 = mul_tree_10_59[95:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_28_s1 <= 145'h23;
            rtlzz_pipe_31_s1 <= 193'h0;
            rtlzz_pipe_4_s2 <= 96'h23;
            rtlzz_pipe_53_s1 <= 145'h37;
            rtlzz_pipe_56_s1 <= 193'h0;
            rtlzz_pipe_5_s2 <= 96'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_28_s1 <= mul_tree_9_28; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_9_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_56_s1 <= mul_tree_10_56; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
