`timescale 1ns/1ps

module sensitivity_16_0(
    input logic [15:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [32:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    output logic [32:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [31:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [31:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [7:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({16'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({16'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 16'(($unsigned(16'($unsigned(mul_tree_10_11))) * $unsigned(16'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 16'(($unsigned(16'($unsigned(mul_tree_10_14))) * $unsigned(16'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 16'(($unsigned(16'($unsigned(mul_tree_10_18))) * $unsigned(16'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 16'(($unsigned(16'($unsigned(mul_tree_10_22))) * $unsigned(16'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({9'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 25'((mul_tree_10_26 + mul_tree_10_27 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({9'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 33'((mul_tree_10_29 + mul_tree_10_30 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({9'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 34'((mul_tree_10_32 + mul_tree_10_33 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    end
endmodule
