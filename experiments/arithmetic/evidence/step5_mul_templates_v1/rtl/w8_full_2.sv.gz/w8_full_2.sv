`timescale 1ns/1ps

module w8_full_2(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [7:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:25
    output logic [15:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:36; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    output logic [15:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:38; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    logic [15:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [7:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9
    logic [7:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    logic [7:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [15:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [15:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    logic [15:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [1:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_66; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_15_67; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_68; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_69; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_70; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_71; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_72; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_73; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_74; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_15_75; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_76; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_15_77; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_79; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_80; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_81; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_15_82; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_83; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_84; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_85; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_15_86; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_15_87; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_15_88; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_89; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_90; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_91; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_92; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_93; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_15_94; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_95; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_96; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_97; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_98; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_99; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_100; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_101; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_102; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_103; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_104; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_105; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_106; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_15_107; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_15_108; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_15_109; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_110; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_111; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_112; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_113; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_114; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_115; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_116; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_117; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_15_118; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_119; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_120; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_121; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_122; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_123; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_124; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_126; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_127; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_128; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_129; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_130; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_131; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_132; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_133; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_134; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_135; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_136; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_137; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_138; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_139; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_16_140; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_141; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_142; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_143; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_16_144; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_145; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_146; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_147; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_148; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_149; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_150; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_151; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_16_152; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_153; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_154; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_155; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_156; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_157; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_158; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_159; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_160; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_161; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_162; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_163; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_16_164; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_165; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_166; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_167; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_168; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_169; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_170; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_171; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_16_172; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_173; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_174; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_175; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_16_176; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_177; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_178; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_179; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_180; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_181; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_182; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_183; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_16_184; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_185; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_16_186; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_187; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_188; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_189; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_190; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_16_191; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_192; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_193; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_194; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_16_195; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_16_196; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_16_197; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_198; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_199; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_200; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_201; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_202; // decl: <none>; prim: <none>
    logic [10:0] mul_tree_16_203; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_204; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_205; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_206; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_207; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_208; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_209; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_210; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_211; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_212; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_213; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_214; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_215; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_16_216; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_16_217; // decl: <none>; prim: <none>
    logic [13:0] mul_tree_16_218; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_219; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_220; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_221; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_16_222; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_16_223; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_16_224; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_225; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_226; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_16_227; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_228; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_229; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_16_230; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_231; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_232; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_233; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_234; // decl: <none>; prim: <none>
    logic [6:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [10:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [10:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [14:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [14:0] rtlzz_pipe_118_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
    logic [6:0] rtlzz_pipe_191_s1; // decl: <none>; prim: <none>
    logic [10:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_197_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_200_s1; // decl: <none>; prim: <none>
    logic [10:0] rtlzz_pipe_203_s1; // decl: <none>; prim: <none>
    logic [14:0] rtlzz_pipe_206_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_209_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_212_s1; // decl: <none>; prim: <none>
    logic [14:0] rtlzz_pipe_227_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_230_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:36; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    assign z = s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:27-2:38; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:9
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    assign __beopt_width_14 = ({8'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({8'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({8'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_125; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_234; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 4'(($unsigned(4'($unsigned(mul_tree_15_17))) * $unsigned(4'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 4'(($unsigned(4'($unsigned(mul_tree_15_20))) * $unsigned(4'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 2'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 4'(($unsigned(4'($unsigned(mul_tree_15_24))) * $unsigned(4'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 4'(($unsigned(4'($unsigned(mul_tree_15_28))) * $unsigned(4'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = __beopt_width_15[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 4'(($unsigned(4'($unsigned(mul_tree_15_32))) * $unsigned(4'($unsigned(mul_tree_15_33))))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = {mul_tree_15_34, 2'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_36 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_37 = __beopt_width_15[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 4'(($unsigned(4'($unsigned(mul_tree_15_36))) * $unsigned(4'($unsigned(mul_tree_15_37))))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = {mul_tree_15_38, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_40 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_15[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = 4'(($unsigned(4'($unsigned(mul_tree_15_40))) * $unsigned(4'($unsigned(mul_tree_15_41))))); // decl: <none>; prim: <none>
    assign mul_tree_15_43 = {mul_tree_15_42, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_15[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 4'(($unsigned(4'($unsigned(mul_tree_15_44))) * $unsigned(4'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_15[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 4'(($unsigned(4'($unsigned(mul_tree_15_48))) * $unsigned(4'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_15[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 4'(($unsigned(4'($unsigned(mul_tree_15_52))) * $unsigned(4'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_57 = __beopt_width_15[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 4'(($unsigned(4'($unsigned(mul_tree_15_56))) * $unsigned(4'($unsigned(mul_tree_15_57))))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = {mul_tree_15_58, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_60 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_61 = __beopt_width_15[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_62 = 4'(($unsigned(4'($unsigned(mul_tree_15_60))) * $unsigned(4'($unsigned(mul_tree_15_61))))); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = {mul_tree_15_62, 10'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_64 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_65 = __beopt_width_15[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_66 = 4'(($unsigned(4'($unsigned(mul_tree_15_64))) * $unsigned(4'($unsigned(mul_tree_15_65))))); // decl: <none>; prim: <none>
    assign mul_tree_15_67 = {mul_tree_15_66, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_68 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_69 = __beopt_width_15[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_15_70 = 4'(($unsigned(4'($unsigned(mul_tree_15_68))) * $unsigned(4'($unsigned(mul_tree_15_69))))); // decl: <none>; prim: <none>
    assign mul_tree_15_71 = {mul_tree_15_70, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_72 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_73 = __beopt_width_15[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_74 = 4'(($unsigned(4'($unsigned(mul_tree_15_72))) * $unsigned(4'($unsigned(mul_tree_15_73))))); // decl: <none>; prim: <none>
    assign mul_tree_15_75 = {mul_tree_15_74, 10'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_76 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_77 = __beopt_width_15[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_78 = 4'(($unsigned(4'($unsigned(mul_tree_15_76))) * $unsigned(4'($unsigned(mul_tree_15_77))))); // decl: <none>; prim: <none>
    assign mul_tree_15_79 = {mul_tree_15_78, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_80 = ({3'h0, mul_tree_15_19}); // decl: <none>; prim: <none>
    assign mul_tree_15_81 = ({1'h0, mul_tree_15_23}); // decl: <none>; prim: <none>
    assign mul_tree_15_82 = 7'((mul_tree_15_80 + mul_tree_15_81 + ({6'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_83 = ({3'h0, mul_tree_15_27}); // decl: <none>; prim: <none>
    assign mul_tree_15_84 = ({1'h0, mul_tree_15_31}); // decl: <none>; prim: <none>
    assign mul_tree_15_85 = 11'((mul_tree_15_83 + mul_tree_15_84 + ({10'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_86 = ({3'h0, mul_tree_15_35}); // decl: <none>; prim: <none>
    assign mul_tree_15_87 = ({1'h0, mul_tree_15_39}); // decl: <none>; prim: <none>
    assign mul_tree_15_88 = 9'((mul_tree_15_86 + mul_tree_15_87 + ({8'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_89 = ({3'h0, mul_tree_15_43}); // decl: <none>; prim: <none>
    assign mul_tree_15_90 = ({1'h0, mul_tree_15_47}); // decl: <none>; prim: <none>
    assign mul_tree_15_91 = 13'((mul_tree_15_89 + mul_tree_15_90 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_92 = ({3'h0, mul_tree_15_51}); // decl: <none>; prim: <none>
    assign mul_tree_15_93 = ({1'h0, mul_tree_15_55}); // decl: <none>; prim: <none>
    assign mul_tree_15_94 = 11'((mul_tree_15_92 + mul_tree_15_93 + ({10'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_95 = ({3'h0, mul_tree_15_59}); // decl: <none>; prim: <none>
    assign mul_tree_15_96 = ({1'h0, mul_tree_15_63}); // decl: <none>; prim: <none>
    assign mul_tree_15_97 = 15'((mul_tree_15_95 + mul_tree_15_96 + ({14'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_98 = ({3'h0, mul_tree_15_67}); // decl: <none>; prim: <none>
    assign mul_tree_15_99 = ({1'h0, mul_tree_15_71}); // decl: <none>; prim: <none>
    assign mul_tree_15_100 = 13'((mul_tree_15_98 + mul_tree_15_99 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_101 = ({3'h0, mul_tree_15_75}); // decl: <none>; prim: <none>
    assign mul_tree_15_102 = ({1'h0, mul_tree_15_79}); // decl: <none>; prim: <none>
    assign mul_tree_15_103 = 17'((mul_tree_15_101 + mul_tree_15_102 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_104 = ({5'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_105 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_106 = 12'((mul_tree_15_104 + mul_tree_15_105 + ({11'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_107 = ({5'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_108 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_109 = 14'((mul_tree_15_107 + mul_tree_15_108 + ({13'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_110 = ({5'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_111 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_112 = 16'((mul_tree_15_110 + mul_tree_15_111 + ({15'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_113 = ({5'h0, rtlzz_pipe_100_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_114 = ({1'h0, rtlzz_pipe_103_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_115 = 18'((mul_tree_15_113 + mul_tree_15_114 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_116 = ({3'h0, mul_tree_15_106}); // decl: <none>; prim: <none>
    assign mul_tree_15_117 = ({1'h0, mul_tree_15_109}); // decl: <none>; prim: <none>
    assign mul_tree_15_118 = 15'((mul_tree_15_116 + mul_tree_15_117 + ({14'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_119 = ({3'h0, mul_tree_15_112}); // decl: <none>; prim: <none>
    assign mul_tree_15_120 = ({1'h0, mul_tree_15_115}); // decl: <none>; prim: <none>
    assign mul_tree_15_121 = 19'((mul_tree_15_119 + mul_tree_15_120 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_122 = ({5'h0, rtlzz_pipe_118_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_123 = ({1'h0, rtlzz_pipe_121_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_124 = 20'((mul_tree_15_122 + mul_tree_15_123 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_125 = mul_tree_15_124[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_126 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_127 = __beopt_width_18[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_128 = 4'(($unsigned(4'($unsigned(mul_tree_16_126))) * $unsigned(4'($unsigned(mul_tree_16_127))))); // decl: <none>; prim: <none>
    assign mul_tree_16_129 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_130 = __beopt_width_18[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_131 = 4'(($unsigned(4'($unsigned(mul_tree_16_129))) * $unsigned(4'($unsigned(mul_tree_16_130))))); // decl: <none>; prim: <none>
    assign mul_tree_16_132 = {mul_tree_16_131, 2'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_133 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_134 = __beopt_width_18[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_135 = 4'(($unsigned(4'($unsigned(mul_tree_16_133))) * $unsigned(4'($unsigned(mul_tree_16_134))))); // decl: <none>; prim: <none>
    assign mul_tree_16_136 = {mul_tree_16_135, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_137 = __beopt_width_14[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_138 = __beopt_width_18[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_139 = 4'(($unsigned(4'($unsigned(mul_tree_16_137))) * $unsigned(4'($unsigned(mul_tree_16_138))))); // decl: <none>; prim: <none>
    assign mul_tree_16_140 = {mul_tree_16_139, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_141 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_142 = __beopt_width_18[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_143 = 4'(($unsigned(4'($unsigned(mul_tree_16_141))) * $unsigned(4'($unsigned(mul_tree_16_142))))); // decl: <none>; prim: <none>
    assign mul_tree_16_144 = {mul_tree_16_143, 2'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_145 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_146 = __beopt_width_18[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_147 = 4'(($unsigned(4'($unsigned(mul_tree_16_145))) * $unsigned(4'($unsigned(mul_tree_16_146))))); // decl: <none>; prim: <none>
    assign mul_tree_16_148 = {mul_tree_16_147, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_149 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_150 = __beopt_width_18[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_151 = 4'(($unsigned(4'($unsigned(mul_tree_16_149))) * $unsigned(4'($unsigned(mul_tree_16_150))))); // decl: <none>; prim: <none>
    assign mul_tree_16_152 = {mul_tree_16_151, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_153 = __beopt_width_14[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_154 = __beopt_width_18[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_155 = 4'(($unsigned(4'($unsigned(mul_tree_16_153))) * $unsigned(4'($unsigned(mul_tree_16_154))))); // decl: <none>; prim: <none>
    assign mul_tree_16_156 = {mul_tree_16_155, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_157 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_158 = __beopt_width_18[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_159 = 4'(($unsigned(4'($unsigned(mul_tree_16_157))) * $unsigned(4'($unsigned(mul_tree_16_158))))); // decl: <none>; prim: <none>
    assign mul_tree_16_160 = {mul_tree_16_159, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_161 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_162 = __beopt_width_18[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_163 = 4'(($unsigned(4'($unsigned(mul_tree_16_161))) * $unsigned(4'($unsigned(mul_tree_16_162))))); // decl: <none>; prim: <none>
    assign mul_tree_16_164 = {mul_tree_16_163, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_165 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_166 = __beopt_width_18[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_167 = 4'(($unsigned(4'($unsigned(mul_tree_16_165))) * $unsigned(4'($unsigned(mul_tree_16_166))))); // decl: <none>; prim: <none>
    assign mul_tree_16_168 = {mul_tree_16_167, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_169 = __beopt_width_14[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_170 = __beopt_width_18[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_171 = 4'(($unsigned(4'($unsigned(mul_tree_16_169))) * $unsigned(4'($unsigned(mul_tree_16_170))))); // decl: <none>; prim: <none>
    assign mul_tree_16_172 = {mul_tree_16_171, 10'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_173 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_174 = __beopt_width_18[1:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_175 = 4'(($unsigned(4'($unsigned(mul_tree_16_173))) * $unsigned(4'($unsigned(mul_tree_16_174))))); // decl: <none>; prim: <none>
    assign mul_tree_16_176 = {mul_tree_16_175, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_177 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_178 = __beopt_width_18[3:2]; // decl: <none>; prim: <none>
    assign mul_tree_16_179 = 4'(($unsigned(4'($unsigned(mul_tree_16_177))) * $unsigned(4'($unsigned(mul_tree_16_178))))); // decl: <none>; prim: <none>
    assign mul_tree_16_180 = {mul_tree_16_179, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_181 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_182 = __beopt_width_18[5:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_183 = 4'(($unsigned(4'($unsigned(mul_tree_16_181))) * $unsigned(4'($unsigned(mul_tree_16_182))))); // decl: <none>; prim: <none>
    assign mul_tree_16_184 = {mul_tree_16_183, 10'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_185 = __beopt_width_14[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_186 = __beopt_width_18[7:6]; // decl: <none>; prim: <none>
    assign mul_tree_16_187 = 4'(($unsigned(4'($unsigned(mul_tree_16_185))) * $unsigned(4'($unsigned(mul_tree_16_186))))); // decl: <none>; prim: <none>
    assign mul_tree_16_188 = {mul_tree_16_187, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_189 = ({3'h0, mul_tree_16_128}); // decl: <none>; prim: <none>
    assign mul_tree_16_190 = ({1'h0, mul_tree_16_132}); // decl: <none>; prim: <none>
    assign mul_tree_16_191 = 7'((mul_tree_16_189 + mul_tree_16_190 + ({6'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_192 = ({3'h0, mul_tree_16_136}); // decl: <none>; prim: <none>
    assign mul_tree_16_193 = ({1'h0, mul_tree_16_140}); // decl: <none>; prim: <none>
    assign mul_tree_16_194 = 11'((mul_tree_16_192 + mul_tree_16_193 + ({10'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_195 = ({3'h0, mul_tree_16_144}); // decl: <none>; prim: <none>
    assign mul_tree_16_196 = ({1'h0, mul_tree_16_148}); // decl: <none>; prim: <none>
    assign mul_tree_16_197 = 9'((mul_tree_16_195 + mul_tree_16_196 + ({8'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_198 = ({3'h0, mul_tree_16_152}); // decl: <none>; prim: <none>
    assign mul_tree_16_199 = ({1'h0, mul_tree_16_156}); // decl: <none>; prim: <none>
    assign mul_tree_16_200 = 13'((mul_tree_16_198 + mul_tree_16_199 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_201 = ({3'h0, mul_tree_16_160}); // decl: <none>; prim: <none>
    assign mul_tree_16_202 = ({1'h0, mul_tree_16_164}); // decl: <none>; prim: <none>
    assign mul_tree_16_203 = 11'((mul_tree_16_201 + mul_tree_16_202 + ({10'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_204 = ({3'h0, mul_tree_16_168}); // decl: <none>; prim: <none>
    assign mul_tree_16_205 = ({1'h0, mul_tree_16_172}); // decl: <none>; prim: <none>
    assign mul_tree_16_206 = 15'((mul_tree_16_204 + mul_tree_16_205 + ({14'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_207 = ({3'h0, mul_tree_16_176}); // decl: <none>; prim: <none>
    assign mul_tree_16_208 = ({1'h0, mul_tree_16_180}); // decl: <none>; prim: <none>
    assign mul_tree_16_209 = 13'((mul_tree_16_207 + mul_tree_16_208 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_210 = ({3'h0, mul_tree_16_184}); // decl: <none>; prim: <none>
    assign mul_tree_16_211 = ({1'h0, mul_tree_16_188}); // decl: <none>; prim: <none>
    assign mul_tree_16_212 = 17'((mul_tree_16_210 + mul_tree_16_211 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_213 = ({5'h0, rtlzz_pipe_191_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_214 = ({1'h0, rtlzz_pipe_194_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_215 = 12'((mul_tree_16_213 + mul_tree_16_214 + ({11'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_216 = ({5'h0, rtlzz_pipe_197_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_217 = ({1'h0, rtlzz_pipe_200_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_218 = 14'((mul_tree_16_216 + mul_tree_16_217 + ({13'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_219 = ({5'h0, rtlzz_pipe_203_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_220 = ({1'h0, rtlzz_pipe_206_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_221 = 16'((mul_tree_16_219 + mul_tree_16_220 + ({15'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_222 = ({5'h0, rtlzz_pipe_209_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_223 = ({1'h0, rtlzz_pipe_212_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_224 = 18'((mul_tree_16_222 + mul_tree_16_223 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_225 = ({3'h0, mul_tree_16_215}); // decl: <none>; prim: <none>
    assign mul_tree_16_226 = ({1'h0, mul_tree_16_218}); // decl: <none>; prim: <none>
    assign mul_tree_16_227 = 15'((mul_tree_16_225 + mul_tree_16_226 + ({14'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_228 = ({3'h0, mul_tree_16_221}); // decl: <none>; prim: <none>
    assign mul_tree_16_229 = ({1'h0, mul_tree_16_224}); // decl: <none>; prim: <none>
    assign mul_tree_16_230 = 19'((mul_tree_16_228 + mul_tree_16_229 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_231 = ({5'h0, rtlzz_pipe_227_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_232 = ({1'h0, rtlzz_pipe_230_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_233 = 20'((mul_tree_16_231 + mul_tree_16_232 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_234 = mul_tree_16_233[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_82_s1 <= 7'h7;
            rtlzz_pipe_85_s1 <= 11'h0;
            rtlzz_pipe_88_s1 <= 9'h1c;
            rtlzz_pipe_91_s1 <= 13'h0;
            rtlzz_pipe_94_s1 <= 11'h0;
            rtlzz_pipe_97_s1 <= 15'h0;
            rtlzz_pipe_100_s1 <= 13'h0;
            rtlzz_pipe_103_s1 <= 17'h0;
            rtlzz_pipe_118_s2 <= 15'h23;
            rtlzz_pipe_121_s2 <= 19'h0;
            rtlzz_pipe_191_s1 <= 7'hb;
            rtlzz_pipe_194_s1 <= 11'h0;
            rtlzz_pipe_197_s1 <= 9'h2c;
            rtlzz_pipe_200_s1 <= 13'h0;
            rtlzz_pipe_203_s1 <= 11'h0;
            rtlzz_pipe_206_s1 <= 15'h0;
            rtlzz_pipe_209_s1 <= 13'h0;
            rtlzz_pipe_212_s1 <= 17'h0;
            rtlzz_pipe_227_s2 <= 15'h37;
            rtlzz_pipe_230_s2 <= 19'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_15_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_15_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_15_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_15_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_15_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_15_97; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_tree_15_100; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_tree_15_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_118_s2 <= mul_tree_15_118; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_121_s2 <= mul_tree_15_121; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_191_s1 <= mul_tree_16_191; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= mul_tree_16_194; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_197_s1 <= mul_tree_16_197; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_200_s1 <= mul_tree_16_200; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_203_s1 <= mul_tree_16_203; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_206_s1 <= mul_tree_16_206; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_209_s1 <= mul_tree_16_209; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_212_s1 <= mul_tree_16_212; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_227_s2 <= mul_tree_16_227; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_230_s2 <= mul_tree_16_230; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:15-2:22
        end
    end
endmodule
