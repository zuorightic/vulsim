`timescale 1ns/1ps

module sensitivity_8_0(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [16:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    output logic [16:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [15:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [16:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [15:0] arith_original_10; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [15:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [15:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = __beopt_width_12; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({8'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_10 = 16'(($unsigned(16'($unsigned(__beopt_width_10))) * $unsigned(16'($unsigned(__beopt_width_11))))); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    end
endmodule
