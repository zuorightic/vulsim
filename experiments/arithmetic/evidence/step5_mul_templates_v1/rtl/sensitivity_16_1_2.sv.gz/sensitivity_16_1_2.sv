`timescale 1ns/1ps

module sensitivity_16_1(
    input logic [15:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [32:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    output logic [32:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:35
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [32:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    logic [31:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [31:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [3:0] mul_tree_11_12; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_14; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_16; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_11_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_25; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_11_26; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_28; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_29; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_11_30; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_32; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_34; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_36; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_37; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_11_38; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_40; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_41; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_11_42; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_44; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_46; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_48; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_49; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_11_50; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_52; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_53; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_11_54; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_56; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_57; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_11_58; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_60; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_61; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_11_62; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_64; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_65; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_11_66; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_68; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_69; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_11_70; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_72; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_74; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_75; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_76; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_77; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_78; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_79; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_80; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_81; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_82; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_83; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_84; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_85; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_86; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_87; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_88; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_11_89; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_11_90; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_11_91; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_11_92; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_93; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_94; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_11_95; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_96; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_11_98; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_11_99; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_11_100; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_11_101; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_11_102; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_11_103; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_11_104; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_11_105; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_11_106; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_11_107; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_11_108; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_11_109; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_11_110; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_11_111; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_11_112; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_11_113; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_11_114; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_11_115; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_11_116; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_11_117; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_11_118; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_11_119; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_120; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    logic [32:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
    logic [12:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_80_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_83_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_86_s1; // decl: <none>; prim: <none>
    logic [20:0] rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic [28:0] rtlzz_pipe_92_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_95_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_98_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s2); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:41-9:53; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38
    assign y = s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:24; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:39-9:53
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({16'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({16'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_11 = mul_tree_11_120; // decl: <none>; prim: <none>
    assign mul_tree_11_12 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_13 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_14 = 8'(($unsigned(8'($unsigned(mul_tree_11_12))) * $unsigned(8'($unsigned(mul_tree_11_13))))); // decl: <none>; prim: <none>
    assign mul_tree_11_15 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_16 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_17 = 8'(($unsigned(8'($unsigned(mul_tree_11_15))) * $unsigned(8'($unsigned(mul_tree_11_16))))); // decl: <none>; prim: <none>
    assign mul_tree_11_18 = {mul_tree_11_17, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_19 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_20 = __beopt_width_12[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_21 = 8'(($unsigned(8'($unsigned(mul_tree_11_19))) * $unsigned(8'($unsigned(mul_tree_11_20))))); // decl: <none>; prim: <none>
    assign mul_tree_11_22 = {mul_tree_11_21, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_23 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_24 = __beopt_width_12[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_25 = 8'(($unsigned(8'($unsigned(mul_tree_11_23))) * $unsigned(8'($unsigned(mul_tree_11_24))))); // decl: <none>; prim: <none>
    assign mul_tree_11_26 = {mul_tree_11_25, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_27 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_28 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_29 = 8'(($unsigned(8'($unsigned(mul_tree_11_27))) * $unsigned(8'($unsigned(mul_tree_11_28))))); // decl: <none>; prim: <none>
    assign mul_tree_11_30 = {mul_tree_11_29, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_31 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_32 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_33 = 8'(($unsigned(8'($unsigned(mul_tree_11_31))) * $unsigned(8'($unsigned(mul_tree_11_32))))); // decl: <none>; prim: <none>
    assign mul_tree_11_34 = {mul_tree_11_33, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_35 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_36 = __beopt_width_12[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_37 = 8'(($unsigned(8'($unsigned(mul_tree_11_35))) * $unsigned(8'($unsigned(mul_tree_11_36))))); // decl: <none>; prim: <none>
    assign mul_tree_11_38 = {mul_tree_11_37, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_39 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_40 = __beopt_width_12[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_41 = 8'(($unsigned(8'($unsigned(mul_tree_11_39))) * $unsigned(8'($unsigned(mul_tree_11_40))))); // decl: <none>; prim: <none>
    assign mul_tree_11_42 = {mul_tree_11_41, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_43 = __beopt_width_11[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_44 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_45 = 8'(($unsigned(8'($unsigned(mul_tree_11_43))) * $unsigned(8'($unsigned(mul_tree_11_44))))); // decl: <none>; prim: <none>
    assign mul_tree_11_46 = {mul_tree_11_45, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_47 = __beopt_width_11[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_48 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_49 = 8'(($unsigned(8'($unsigned(mul_tree_11_47))) * $unsigned(8'($unsigned(mul_tree_11_48))))); // decl: <none>; prim: <none>
    assign mul_tree_11_50 = {mul_tree_11_49, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_51 = __beopt_width_11[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_52 = __beopt_width_12[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_53 = 8'(($unsigned(8'($unsigned(mul_tree_11_51))) * $unsigned(8'($unsigned(mul_tree_11_52))))); // decl: <none>; prim: <none>
    assign mul_tree_11_54 = {mul_tree_11_53, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_55 = __beopt_width_11[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_56 = __beopt_width_12[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_57 = 8'(($unsigned(8'($unsigned(mul_tree_11_55))) * $unsigned(8'($unsigned(mul_tree_11_56))))); // decl: <none>; prim: <none>
    assign mul_tree_11_58 = {mul_tree_11_57, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_59 = __beopt_width_11[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_60 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_61 = 8'(($unsigned(8'($unsigned(mul_tree_11_59))) * $unsigned(8'($unsigned(mul_tree_11_60))))); // decl: <none>; prim: <none>
    assign mul_tree_11_62 = {mul_tree_11_61, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_63 = __beopt_width_11[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_64 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_65 = 8'(($unsigned(8'($unsigned(mul_tree_11_63))) * $unsigned(8'($unsigned(mul_tree_11_64))))); // decl: <none>; prim: <none>
    assign mul_tree_11_66 = {mul_tree_11_65, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_67 = __beopt_width_11[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_68 = __beopt_width_12[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_11_69 = 8'(($unsigned(8'($unsigned(mul_tree_11_67))) * $unsigned(8'($unsigned(mul_tree_11_68))))); // decl: <none>; prim: <none>
    assign mul_tree_11_70 = {mul_tree_11_69, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_71 = __beopt_width_11[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_72 = __beopt_width_12[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_11_73 = 8'(($unsigned(8'($unsigned(mul_tree_11_71))) * $unsigned(8'($unsigned(mul_tree_11_72))))); // decl: <none>; prim: <none>
    assign mul_tree_11_74 = {mul_tree_11_73, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_75 = ({5'h0, mul_tree_11_14}); // decl: <none>; prim: <none>
    assign mul_tree_11_76 = ({1'h0, mul_tree_11_18}); // decl: <none>; prim: <none>
    assign mul_tree_11_77 = 13'((mul_tree_11_75 + mul_tree_11_76 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_78 = ({5'h0, mul_tree_11_22}); // decl: <none>; prim: <none>
    assign mul_tree_11_79 = ({1'h0, mul_tree_11_26}); // decl: <none>; prim: <none>
    assign mul_tree_11_80 = 21'((mul_tree_11_78 + mul_tree_11_79 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_81 = ({5'h0, mul_tree_11_30}); // decl: <none>; prim: <none>
    assign mul_tree_11_82 = ({1'h0, mul_tree_11_34}); // decl: <none>; prim: <none>
    assign mul_tree_11_83 = 17'((mul_tree_11_81 + mul_tree_11_82 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_84 = ({5'h0, mul_tree_11_38}); // decl: <none>; prim: <none>
    assign mul_tree_11_85 = ({1'h0, mul_tree_11_42}); // decl: <none>; prim: <none>
    assign mul_tree_11_86 = 25'((mul_tree_11_84 + mul_tree_11_85 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_87 = ({5'h0, mul_tree_11_46}); // decl: <none>; prim: <none>
    assign mul_tree_11_88 = ({1'h0, mul_tree_11_50}); // decl: <none>; prim: <none>
    assign mul_tree_11_89 = 21'((mul_tree_11_87 + mul_tree_11_88 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_90 = ({5'h0, mul_tree_11_54}); // decl: <none>; prim: <none>
    assign mul_tree_11_91 = ({1'h0, mul_tree_11_58}); // decl: <none>; prim: <none>
    assign mul_tree_11_92 = 29'((mul_tree_11_90 + mul_tree_11_91 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_93 = ({5'h0, mul_tree_11_62}); // decl: <none>; prim: <none>
    assign mul_tree_11_94 = ({1'h0, mul_tree_11_66}); // decl: <none>; prim: <none>
    assign mul_tree_11_95 = 25'((mul_tree_11_93 + mul_tree_11_94 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_96 = ({5'h0, mul_tree_11_70}); // decl: <none>; prim: <none>
    assign mul_tree_11_97 = ({1'h0, mul_tree_11_74}); // decl: <none>; prim: <none>
    assign mul_tree_11_98 = 33'((mul_tree_11_96 + mul_tree_11_97 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_99 = ({9'h0, rtlzz_pipe_77_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_100 = ({1'h0, rtlzz_pipe_80_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_101 = 22'((mul_tree_11_99 + mul_tree_11_100 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_102 = ({9'h0, rtlzz_pipe_83_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_103 = ({1'h0, rtlzz_pipe_86_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_104 = 26'((mul_tree_11_102 + mul_tree_11_103 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_105 = ({9'h0, rtlzz_pipe_89_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_106 = ({1'h0, rtlzz_pipe_92_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_107 = 30'((mul_tree_11_105 + mul_tree_11_106 + ({29'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_108 = ({9'h0, rtlzz_pipe_95_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_109 = ({1'h0, rtlzz_pipe_98_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_110 = 34'((mul_tree_11_108 + mul_tree_11_109 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_111 = ({5'h0, mul_tree_11_101}); // decl: <none>; prim: <none>
    assign mul_tree_11_112 = ({1'h0, mul_tree_11_104}); // decl: <none>; prim: <none>
    assign mul_tree_11_113 = 27'((mul_tree_11_111 + mul_tree_11_112 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_114 = ({5'h0, mul_tree_11_107}); // decl: <none>; prim: <none>
    assign mul_tree_11_115 = ({1'h0, mul_tree_11_110}); // decl: <none>; prim: <none>
    assign mul_tree_11_116 = 35'((mul_tree_11_114 + mul_tree_11_115 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_117 = ({9'h0, mul_tree_11_113}); // decl: <none>; prim: <none>
    assign mul_tree_11_118 = ({1'h0, mul_tree_11_116}); // decl: <none>; prim: <none>
    assign mul_tree_11_119 = 36'((mul_tree_11_117 + mul_tree_11_118 + ({35'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_120 = mul_tree_11_119[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:22
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= mul_tree_11_77; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_80_s1 <= mul_tree_11_80; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_83_s1 <= mul_tree_11_83; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_86_s1 <= mul_tree_11_86; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= mul_tree_11_89; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_92_s1 <= mul_tree_11_92; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_95_s1 <= mul_tree_11_95; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_98_s1 <= mul_tree_11_98; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:35-9:38; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:25-2:32
    end
endmodule
