`timescale 1ns/1ps

module sensitivity_64_1(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    input logic [128:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23
    output logic [128:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:55
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:36
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [128:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:42-9:55; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    logic [127:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [127:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:12
    logic [31:0] mul_tree_11_12; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_13; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_15; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_16; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_17; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_11_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_21; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_11_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_11_24; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_11_25; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_26; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_11_27; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_11_28; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_11_29; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_11_30; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_11_31; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_11_32; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_11_33; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_11_34; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_11_35; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_11_36; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23
    logic [63:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:42-9:55; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:42-9:55; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
    assign y = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:25; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:55
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({64'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({64'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, s8_norm_mul_0_v0}); // decl: <none>; prim: <none>
    assign arith_original_11 = mul_tree_11_36; // decl: <none>; prim: <none>
    assign mul_tree_11_12 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_13 = __beopt_width_12[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_14 = 64'(($unsigned(64'($unsigned(mul_tree_11_12))) * $unsigned(64'($unsigned(mul_tree_11_13))))); // decl: <none>; prim: <none>
    assign mul_tree_11_15 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_16 = __beopt_width_12[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_11_17 = 64'(($unsigned(64'($unsigned(mul_tree_11_15))) * $unsigned(64'($unsigned(mul_tree_11_16))))); // decl: <none>; prim: <none>
    assign mul_tree_11_18 = {mul_tree_11_17, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_19 = __beopt_width_11[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_11_20 = __beopt_width_12[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_21 = 64'(($unsigned(64'($unsigned(mul_tree_11_19))) * $unsigned(64'($unsigned(mul_tree_11_20))))); // decl: <none>; prim: <none>
    assign mul_tree_11_22 = {mul_tree_11_21, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_23 = __beopt_width_11[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_11_24 = __beopt_width_12[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_11_25 = 64'(($unsigned(64'($unsigned(mul_tree_11_23))) * $unsigned(64'($unsigned(mul_tree_11_24))))); // decl: <none>; prim: <none>
    assign mul_tree_11_26 = {mul_tree_11_25, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_27 = ({33'h0, rtlzz_pipe_14_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_28 = ({1'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_29 = 97'((mul_tree_11_27 + mul_tree_11_28 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_30 = ({33'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_31 = ({1'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_32 = 129'((mul_tree_11_30 + mul_tree_11_31 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_33 = ({33'h0, mul_tree_11_29}); // decl: <none>; prim: <none>
    assign mul_tree_11_34 = ({1'h0, mul_tree_11_32}); // decl: <none>; prim: <none>
    assign mul_tree_11_35 = 130'((mul_tree_11_33 + mul_tree_11_34 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_36 = mul_tree_11_35[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:13-2:23
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= mul_tree_11_14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_11_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_11_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_11_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:42-9:55; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:36-9:39
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:26-2:33
    end
endmodule
