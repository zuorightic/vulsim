`timescale 1ns/1ps

module w128_full_1(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic [127:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27
    output logic [255:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:25
    output logic [255:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:31
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:22-10:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [255:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:28-10:31; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    logic [127:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    logic [127:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [127:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    logic [255:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [255:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:22-10:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [255:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:28-10:31; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    logic [63:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_42; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_43; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_16_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_45; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_46; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_16_47; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_16_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_49; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_50; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_16_51; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_16_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_53; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_16_54; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_16_55; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_16_56; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_57; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_58; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_16_59; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_16_60; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_16_61; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_16_62; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_16_63; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_16_64; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_16_65; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_16_66; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:22-10:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    logic [192:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:28-10:31; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:25
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:31
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    assign __beopt_width_14 = ({128'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({128'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({128'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_41; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_66; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 128'(($unsigned(128'($unsigned(mul_tree_15_17))) * $unsigned(128'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 128'(($unsigned(128'($unsigned(mul_tree_15_20))) * $unsigned(128'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 128'(($unsigned(128'($unsigned(mul_tree_15_24))) * $unsigned(128'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 128'(($unsigned(128'($unsigned(mul_tree_15_28))) * $unsigned(128'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = ({65'h0, mul_tree_15_19}); // decl: <none>; prim: <none>
    assign mul_tree_15_33 = ({1'h0, mul_tree_15_23}); // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 193'((mul_tree_15_32 + mul_tree_15_33 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = ({65'h0, mul_tree_15_27}); // decl: <none>; prim: <none>
    assign mul_tree_15_36 = ({1'h0, mul_tree_15_31}); // decl: <none>; prim: <none>
    assign mul_tree_15_37 = 257'((mul_tree_15_35 + mul_tree_15_36 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_38 = ({65'h0, rtlzz_pipe_34_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = ({1'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_40 = 258'((mul_tree_15_38 + mul_tree_15_39 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_41 = mul_tree_15_40[255:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_42 = __beopt_width_14[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_43 = __beopt_width_18[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_44 = 128'(($unsigned(128'($unsigned(mul_tree_16_42))) * $unsigned(128'($unsigned(mul_tree_16_43))))); // decl: <none>; prim: <none>
    assign mul_tree_16_45 = __beopt_width_14[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_46 = __beopt_width_18[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_16_47 = 128'(($unsigned(128'($unsigned(mul_tree_16_45))) * $unsigned(128'($unsigned(mul_tree_16_46))))); // decl: <none>; prim: <none>
    assign mul_tree_16_48 = {mul_tree_16_47, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_49 = __beopt_width_14[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_16_50 = __beopt_width_18[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_51 = 128'(($unsigned(128'($unsigned(mul_tree_16_49))) * $unsigned(128'($unsigned(mul_tree_16_50))))); // decl: <none>; prim: <none>
    assign mul_tree_16_52 = {mul_tree_16_51, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_53 = __beopt_width_14[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_16_54 = __beopt_width_18[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_16_55 = 128'(($unsigned(128'($unsigned(mul_tree_16_53))) * $unsigned(128'($unsigned(mul_tree_16_54))))); // decl: <none>; prim: <none>
    assign mul_tree_16_56 = {mul_tree_16_55, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_57 = ({65'h0, mul_tree_16_44}); // decl: <none>; prim: <none>
    assign mul_tree_16_58 = ({1'h0, mul_tree_16_48}); // decl: <none>; prim: <none>
    assign mul_tree_16_59 = 193'((mul_tree_16_57 + mul_tree_16_58 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_60 = ({65'h0, mul_tree_16_52}); // decl: <none>; prim: <none>
    assign mul_tree_16_61 = ({1'h0, mul_tree_16_56}); // decl: <none>; prim: <none>
    assign mul_tree_16_62 = 257'((mul_tree_16_60 + mul_tree_16_61 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_63 = ({65'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_64 = ({1'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_65 = 258'((mul_tree_16_63 + mul_tree_16_64 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_66 = mul_tree_16_65[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_34_s1 <= 193'h23;
            rtlzz_pipe_37_s1 <= 257'h0;
            rtlzz_pipe_4_s2 <= 256'h23;
            rtlzz_pipe_59_s1 <= 193'h37;
            rtlzz_pipe_62_s1 <= 257'h0;
            rtlzz_pipe_5_s2 <= 256'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_34_s1 <= mul_tree_15_34; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_15_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:22-10:25; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_16_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_16_62; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:28-10:31; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        end
    end
endmodule
