`timescale 1ns/1ps

module w128_low_1(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:13
    input logic [127:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:15
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:27
    output logic [127:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [127:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic [127:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [127:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic [63:0] mul_tree_9_11; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_12; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_9_13; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_14; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_15; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_9_16; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_9_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_18; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_19; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_9_20; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_9_21; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_9_23; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_9_24; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_9_25; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_26; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_27; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_9_28; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_9_29; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_9_30; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_9_31; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_9_32; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_9_33; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_9_34; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_9_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
    logic [192:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_56_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:29-2:41; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign arith_original_9 = mul_tree_9_35; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_60; // decl: <none>; prim: <none>
    assign mul_tree_9_11 = a[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_12 = b[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_13 = 128'(($unsigned(128'($unsigned(mul_tree_9_11))) * $unsigned(128'($unsigned(mul_tree_9_12))))); // decl: <none>; prim: <none>
    assign mul_tree_9_14 = a[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_15 = b[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_9_16 = 128'(($unsigned(128'($unsigned(mul_tree_9_14))) * $unsigned(128'($unsigned(mul_tree_9_15))))); // decl: <none>; prim: <none>
    assign mul_tree_9_17 = {mul_tree_9_16, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_18 = a[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_9_19 = b[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_20 = 128'(($unsigned(128'($unsigned(mul_tree_9_18))) * $unsigned(128'($unsigned(mul_tree_9_19))))); // decl: <none>; prim: <none>
    assign mul_tree_9_21 = {mul_tree_9_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_22 = a[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_9_23 = b[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_9_24 = 128'(($unsigned(128'($unsigned(mul_tree_9_22))) * $unsigned(128'($unsigned(mul_tree_9_23))))); // decl: <none>; prim: <none>
    assign mul_tree_9_25 = {mul_tree_9_24, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_26 = ({65'h0, mul_tree_9_13}); // decl: <none>; prim: <none>
    assign mul_tree_9_27 = ({1'h0, mul_tree_9_17}); // decl: <none>; prim: <none>
    assign mul_tree_9_28 = 193'((mul_tree_9_26 + mul_tree_9_27 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_29 = ({65'h0, mul_tree_9_21}); // decl: <none>; prim: <none>
    assign mul_tree_9_30 = ({1'h0, mul_tree_9_25}); // decl: <none>; prim: <none>
    assign mul_tree_9_31 = 257'((mul_tree_9_29 + mul_tree_9_30 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_32 = ({65'h0, rtlzz_pipe_28_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_33 = ({1'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_34 = 258'((mul_tree_9_32 + mul_tree_9_33 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_35 = mul_tree_9_34[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = a[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_37 = c[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = 128'(($unsigned(128'($unsigned(mul_tree_10_36))) * $unsigned(128'($unsigned(mul_tree_10_37))))); // decl: <none>; prim: <none>
    assign mul_tree_10_39 = a[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = c[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_41 = 128'(($unsigned(128'($unsigned(mul_tree_10_39))) * $unsigned(128'($unsigned(mul_tree_10_40))))); // decl: <none>; prim: <none>
    assign mul_tree_10_42 = {mul_tree_10_41, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = a[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = c[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_45 = 128'(($unsigned(128'($unsigned(mul_tree_10_43))) * $unsigned(128'($unsigned(mul_tree_10_44))))); // decl: <none>; prim: <none>
    assign mul_tree_10_46 = {mul_tree_10_45, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = a[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = c[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_49 = 128'(($unsigned(128'($unsigned(mul_tree_10_47))) * $unsigned(128'($unsigned(mul_tree_10_48))))); // decl: <none>; prim: <none>
    assign mul_tree_10_50 = {mul_tree_10_49, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = ({65'h0, mul_tree_10_38}); // decl: <none>; prim: <none>
    assign mul_tree_10_52 = ({1'h0, mul_tree_10_42}); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = 193'((mul_tree_10_51 + mul_tree_10_52 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_54 = ({65'h0, mul_tree_10_46}); // decl: <none>; prim: <none>
    assign mul_tree_10_55 = ({1'h0, mul_tree_10_50}); // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 257'((mul_tree_10_54 + mul_tree_10_55 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = ({65'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_58 = ({1'h0, rtlzz_pipe_56_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_59 = 258'((mul_tree_10_57 + mul_tree_10_58 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_60 = mul_tree_10_59[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_28_s1 <= 193'h23;
            rtlzz_pipe_31_s1 <= 257'h0;
            rtlzz_pipe_4_s2 <= 128'h23;
            rtlzz_pipe_53_s1 <= 193'h37;
            rtlzz_pipe_56_s1 <= 257'h0;
            rtlzz_pipe_5_s2 <= 128'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_28_s1 <= mul_tree_9_28; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_9_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_56_s1 <= mul_tree_10_56; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:17-2:24
        end
    end
endmodule
