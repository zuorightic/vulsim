`timescale 1ns/1ps

module w17_full_0(
    input logic [16:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [16:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [16:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [33:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [33:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [33:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [16:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    logic [16:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [16:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [33:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [33:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [33:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [33:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [33:0] rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({17'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({17'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({17'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = 34'(($unsigned(34'($unsigned(__beopt_width_14))) * $unsigned(34'($unsigned(__beopt_width_15))))); // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign arith_original_16 = 34'(($unsigned(34'($unsigned(__beopt_width_14))) * $unsigned(34'($unsigned(__beopt_width_18))))); // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_4_s1 <= 34'h23;
            rtlzz_pipe_4_s2 <= 34'h23;
            rtlzz_pipe_5_s1 <= 34'h37;
            rtlzz_pipe_5_s2 <= 34'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
