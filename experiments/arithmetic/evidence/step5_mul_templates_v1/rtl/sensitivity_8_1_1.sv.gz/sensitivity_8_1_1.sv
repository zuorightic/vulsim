`timescale 1ns/1ps

module sensitivity_8_1(
    input logic [7:0] a, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    input logic [16:0] c, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    output logic [16:0] y, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:38-9:52
    input logic iv, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    output logic ov, // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:34
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [16:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [16:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [15:0] arith_original_11; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic [3:0] mul_tree_11_12; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_14; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_16; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_11_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_11_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_11_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_11_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_26; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_27; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_28; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_11_29; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_30; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_31; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_11_32; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_11_33; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_11_34; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_11_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_11_36; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    logic [16:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
    logic [7:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31


    assign s8_norm_mul_0_v0 = arith_original_11; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (__beopt_width_13 + rtlzz_pipe_2_s2); // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:40-9:52; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37
    assign y = s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:23; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:9:38-9:52
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_12 = ({8'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({1'h0, rtlzz_pipe_4_s2}); // decl: <none>; prim: <none>
    assign arith_original_11 = mul_tree_11_36; // decl: <none>; prim: <none>
    assign mul_tree_11_12 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_13 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_14 = 8'(($unsigned(8'($unsigned(mul_tree_11_12))) * $unsigned(8'($unsigned(mul_tree_11_13))))); // decl: <none>; prim: <none>
    assign mul_tree_11_15 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_16 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_17 = 8'(($unsigned(8'($unsigned(mul_tree_11_15))) * $unsigned(8'($unsigned(mul_tree_11_16))))); // decl: <none>; prim: <none>
    assign mul_tree_11_18 = {mul_tree_11_17, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_19 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_20 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_11_21 = 8'(($unsigned(8'($unsigned(mul_tree_11_19))) * $unsigned(8'($unsigned(mul_tree_11_20))))); // decl: <none>; prim: <none>
    assign mul_tree_11_22 = {mul_tree_11_21, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_23 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_24 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_11_25 = 8'(($unsigned(8'($unsigned(mul_tree_11_23))) * $unsigned(8'($unsigned(mul_tree_11_24))))); // decl: <none>; prim: <none>
    assign mul_tree_11_26 = {mul_tree_11_25, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_11_27 = ({5'h0, rtlzz_pipe_14_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_28 = ({1'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_29 = 13'((mul_tree_11_27 + mul_tree_11_28 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_30 = ({5'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_31 = ({1'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_11_32 = 17'((mul_tree_11_30 + mul_tree_11_31 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_33 = ({5'h0, mul_tree_11_29}); // decl: <none>; prim: <none>
    assign mul_tree_11_34 = ({1'h0, mul_tree_11_32}); // decl: <none>; prim: <none>
    assign mul_tree_11_35 = 18'((mul_tree_11_33 + mul_tree_11_34 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_11_36 = mul_tree_11_35[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:12-2:21
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= mul_tree_11_14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_11_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_11_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_11_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:9:34-9:37; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:1-2:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31; prim: /home/zyrv/vulsim/sensitivity.logic.cpp:2:24-2:31
    end
endmodule
