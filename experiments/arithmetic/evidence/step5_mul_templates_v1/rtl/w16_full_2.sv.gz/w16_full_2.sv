`timescale 1ns/1ps

module w16_full_2(
    input logic [15:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [15:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [31:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    output logic [31:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [31:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [15:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    logic [15:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [15:0] __beopt_width_17; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [31:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [31:0] arith_original_15; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:21-10:24; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    logic [31:0] arith_original_16; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:10:27-10:30; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    logic [3:0] mul_tree_15_17; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_22; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_28; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_30; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_31; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_32; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_33; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_34; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_35; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_36; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_39; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_66; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_15_67; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_68; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_70; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_71; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_72; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_73; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_74; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_15_75; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_76; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_77; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_78; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_79; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_80; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_81; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_82; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_83; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_84; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_85; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_86; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_87; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_88; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_89; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_90; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_91; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_92; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_93; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_15_94; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_95; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_96; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_15_97; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_98; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_99; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_100; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_101; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_102; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_15_103; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_104; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_105; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_15_106; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_107; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_108; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_109; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_110; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_111; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_15_112; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_113; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_114; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_15_115; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_116; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_117; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_15_118; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_119; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_120; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_15_121; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_122; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_123; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_124; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_126; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_127; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_128; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_129; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_130; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_131; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_132; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_133; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_134; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_135; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_136; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_137; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_138; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_139; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_140; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_141; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_142; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_143; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_16_144; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_145; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_146; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_147; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_148; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_149; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_150; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_151; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_152; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_153; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_154; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_155; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_156; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_157; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_158; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_159; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_16_160; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_161; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_162; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_163; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_164; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_165; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_166; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_167; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_168; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_169; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_170; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_171; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_172; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_173; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_174; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_175; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_16_176; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_177; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_178; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_179; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_16_180; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_181; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_182; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_183; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_16_184; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_185; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_16_186; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_16_187; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_188; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_189; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_190; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_16_191; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_192; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_193; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_194; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_195; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_196; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_16_197; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_198; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_199; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_200; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_201; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_202; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_16_203; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_204; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_205; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_16_206; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_207; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_208; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_16_209; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_210; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_211; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_16_212; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_213; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_214; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_16_215; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_216; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_217; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_16_218; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_219; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_220; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_16_221; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_222; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_223; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_16_224; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_225; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_226; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_16_227; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_228; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_229; // decl: <none>; prim: <none>
    logic [34:0] mul_tree_16_230; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_231; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_232; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_16_233; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_16_234; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [27:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [27:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_109_s2; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_115_s2; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_132_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_136_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_140_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_144_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_148_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_152_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_156_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_160_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_164_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_168_s1; // decl: <none>; prim: <none>
    logic [27:0] rtlzz_pipe_172_s1; // decl: <none>; prim: <none>
    logic [19:0] rtlzz_pipe_176_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_180_s1; // decl: <none>; prim: <none>
    logic [27:0] rtlzz_pipe_184_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_188_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_215_s2; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_218_s2; // decl: <none>; prim: <none>
    logic [29:0] rtlzz_pipe_221_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_224_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:19-10:24
    assign z = s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:25-10:30
    assign __beopt_width_12 = a; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    assign __beopt_width_13 = b; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    assign __beopt_width_17 = c; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    assign __beopt_width_14 = ({16'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({16'h0, __beopt_width_13}); // decl: <none>; prim: <none>
    assign __beopt_width_18 = ({16'h0, __beopt_width_17}); // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_125; // decl: <none>; prim: <none>
    assign arith_original_16 = mul_tree_16_234; // decl: <none>; prim: <none>
    assign mul_tree_15_17 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_18 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_19 = 8'(($unsigned(8'($unsigned(mul_tree_15_17))) * $unsigned(8'($unsigned(mul_tree_15_18))))); // decl: <none>; prim: <none>
    assign mul_tree_15_20 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_21 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_22 = 8'(($unsigned(8'($unsigned(mul_tree_15_20))) * $unsigned(8'($unsigned(mul_tree_15_21))))); // decl: <none>; prim: <none>
    assign mul_tree_15_23 = {mul_tree_15_22, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_24 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_25 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_26 = 8'(($unsigned(8'($unsigned(mul_tree_15_24))) * $unsigned(8'($unsigned(mul_tree_15_25))))); // decl: <none>; prim: <none>
    assign mul_tree_15_27 = {mul_tree_15_26, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_28 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_29 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_30 = 8'(($unsigned(8'($unsigned(mul_tree_15_28))) * $unsigned(8'($unsigned(mul_tree_15_29))))); // decl: <none>; prim: <none>
    assign mul_tree_15_31 = {mul_tree_15_30, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_32 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_33 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_34 = 8'(($unsigned(8'($unsigned(mul_tree_15_32))) * $unsigned(8'($unsigned(mul_tree_15_33))))); // decl: <none>; prim: <none>
    assign mul_tree_15_35 = {mul_tree_15_34, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_36 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_37 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_38 = 8'(($unsigned(8'($unsigned(mul_tree_15_36))) * $unsigned(8'($unsigned(mul_tree_15_37))))); // decl: <none>; prim: <none>
    assign mul_tree_15_39 = {mul_tree_15_38, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_40 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = 8'(($unsigned(8'($unsigned(mul_tree_15_40))) * $unsigned(8'($unsigned(mul_tree_15_41))))); // decl: <none>; prim: <none>
    assign mul_tree_15_43 = {mul_tree_15_42, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 8'(($unsigned(8'($unsigned(mul_tree_15_44))) * $unsigned(8'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 8'(($unsigned(8'($unsigned(mul_tree_15_48))) * $unsigned(8'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 8'(($unsigned(8'($unsigned(mul_tree_15_52))) * $unsigned(8'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_57 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 8'(($unsigned(8'($unsigned(mul_tree_15_56))) * $unsigned(8'($unsigned(mul_tree_15_57))))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = {mul_tree_15_58, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_60 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_61 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_62 = 8'(($unsigned(8'($unsigned(mul_tree_15_60))) * $unsigned(8'($unsigned(mul_tree_15_61))))); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = {mul_tree_15_62, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_64 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_65 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_66 = 8'(($unsigned(8'($unsigned(mul_tree_15_64))) * $unsigned(8'($unsigned(mul_tree_15_65))))); // decl: <none>; prim: <none>
    assign mul_tree_15_67 = {mul_tree_15_66, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_68 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_69 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_70 = 8'(($unsigned(8'($unsigned(mul_tree_15_68))) * $unsigned(8'($unsigned(mul_tree_15_69))))); // decl: <none>; prim: <none>
    assign mul_tree_15_71 = {mul_tree_15_70, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_72 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_73 = __beopt_width_15[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_15_74 = 8'(($unsigned(8'($unsigned(mul_tree_15_72))) * $unsigned(8'($unsigned(mul_tree_15_73))))); // decl: <none>; prim: <none>
    assign mul_tree_15_75 = {mul_tree_15_74, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_76 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_77 = __beopt_width_15[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_78 = 8'(($unsigned(8'($unsigned(mul_tree_15_76))) * $unsigned(8'($unsigned(mul_tree_15_77))))); // decl: <none>; prim: <none>
    assign mul_tree_15_79 = {mul_tree_15_78, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_80 = ({5'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_81 = ({1'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_82 = 13'((mul_tree_15_80 + mul_tree_15_81 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_83 = ({5'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_84 = ({1'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_85 = 21'((mul_tree_15_83 + mul_tree_15_84 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_86 = ({5'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_87 = ({1'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_88 = 17'((mul_tree_15_86 + mul_tree_15_87 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_89 = ({5'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_90 = ({1'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_91 = 25'((mul_tree_15_89 + mul_tree_15_90 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_92 = ({5'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_93 = ({1'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_94 = 21'((mul_tree_15_92 + mul_tree_15_93 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_95 = ({5'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_96 = ({1'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_97 = 29'((mul_tree_15_95 + mul_tree_15_96 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_98 = ({5'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_99 = ({1'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_100 = 25'((mul_tree_15_98 + mul_tree_15_99 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_101 = ({5'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_102 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_103 = 33'((mul_tree_15_101 + mul_tree_15_102 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_104 = ({9'h0, mul_tree_15_82}); // decl: <none>; prim: <none>
    assign mul_tree_15_105 = ({1'h0, mul_tree_15_85}); // decl: <none>; prim: <none>
    assign mul_tree_15_106 = 22'((mul_tree_15_104 + mul_tree_15_105 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_107 = ({9'h0, mul_tree_15_88}); // decl: <none>; prim: <none>
    assign mul_tree_15_108 = ({1'h0, mul_tree_15_91}); // decl: <none>; prim: <none>
    assign mul_tree_15_109 = 26'((mul_tree_15_107 + mul_tree_15_108 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_110 = ({9'h0, mul_tree_15_94}); // decl: <none>; prim: <none>
    assign mul_tree_15_111 = ({1'h0, mul_tree_15_97}); // decl: <none>; prim: <none>
    assign mul_tree_15_112 = 30'((mul_tree_15_110 + mul_tree_15_111 + ({29'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_113 = ({9'h0, mul_tree_15_100}); // decl: <none>; prim: <none>
    assign mul_tree_15_114 = ({1'h0, mul_tree_15_103}); // decl: <none>; prim: <none>
    assign mul_tree_15_115 = 34'((mul_tree_15_113 + mul_tree_15_114 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_116 = ({5'h0, rtlzz_pipe_106_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_117 = ({1'h0, rtlzz_pipe_109_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_118 = 27'((mul_tree_15_116 + mul_tree_15_117 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_119 = ({5'h0, rtlzz_pipe_112_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_120 = ({1'h0, rtlzz_pipe_115_s2}); // decl: <none>; prim: <none>
    assign mul_tree_15_121 = 35'((mul_tree_15_119 + mul_tree_15_120 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_122 = ({9'h0, mul_tree_15_118}); // decl: <none>; prim: <none>
    assign mul_tree_15_123 = ({1'h0, mul_tree_15_121}); // decl: <none>; prim: <none>
    assign mul_tree_15_124 = 36'((mul_tree_15_122 + mul_tree_15_123 + ({35'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_125 = mul_tree_15_124[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_126 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_127 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_128 = 8'(($unsigned(8'($unsigned(mul_tree_16_126))) * $unsigned(8'($unsigned(mul_tree_16_127))))); // decl: <none>; prim: <none>
    assign mul_tree_16_129 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_130 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_131 = 8'(($unsigned(8'($unsigned(mul_tree_16_129))) * $unsigned(8'($unsigned(mul_tree_16_130))))); // decl: <none>; prim: <none>
    assign mul_tree_16_132 = {mul_tree_16_131, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_133 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_134 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_135 = 8'(($unsigned(8'($unsigned(mul_tree_16_133))) * $unsigned(8'($unsigned(mul_tree_16_134))))); // decl: <none>; prim: <none>
    assign mul_tree_16_136 = {mul_tree_16_135, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_137 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_138 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_139 = 8'(($unsigned(8'($unsigned(mul_tree_16_137))) * $unsigned(8'($unsigned(mul_tree_16_138))))); // decl: <none>; prim: <none>
    assign mul_tree_16_140 = {mul_tree_16_139, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_141 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_142 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_143 = 8'(($unsigned(8'($unsigned(mul_tree_16_141))) * $unsigned(8'($unsigned(mul_tree_16_142))))); // decl: <none>; prim: <none>
    assign mul_tree_16_144 = {mul_tree_16_143, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_145 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_146 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_147 = 8'(($unsigned(8'($unsigned(mul_tree_16_145))) * $unsigned(8'($unsigned(mul_tree_16_146))))); // decl: <none>; prim: <none>
    assign mul_tree_16_148 = {mul_tree_16_147, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_149 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_150 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_151 = 8'(($unsigned(8'($unsigned(mul_tree_16_149))) * $unsigned(8'($unsigned(mul_tree_16_150))))); // decl: <none>; prim: <none>
    assign mul_tree_16_152 = {mul_tree_16_151, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_153 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_154 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_155 = 8'(($unsigned(8'($unsigned(mul_tree_16_153))) * $unsigned(8'($unsigned(mul_tree_16_154))))); // decl: <none>; prim: <none>
    assign mul_tree_16_156 = {mul_tree_16_155, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_157 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_158 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_159 = 8'(($unsigned(8'($unsigned(mul_tree_16_157))) * $unsigned(8'($unsigned(mul_tree_16_158))))); // decl: <none>; prim: <none>
    assign mul_tree_16_160 = {mul_tree_16_159, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_161 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_162 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_163 = 8'(($unsigned(8'($unsigned(mul_tree_16_161))) * $unsigned(8'($unsigned(mul_tree_16_162))))); // decl: <none>; prim: <none>
    assign mul_tree_16_164 = {mul_tree_16_163, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_165 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_166 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_167 = 8'(($unsigned(8'($unsigned(mul_tree_16_165))) * $unsigned(8'($unsigned(mul_tree_16_166))))); // decl: <none>; prim: <none>
    assign mul_tree_16_168 = {mul_tree_16_167, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_169 = __beopt_width_14[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_170 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_171 = 8'(($unsigned(8'($unsigned(mul_tree_16_169))) * $unsigned(8'($unsigned(mul_tree_16_170))))); // decl: <none>; prim: <none>
    assign mul_tree_16_172 = {mul_tree_16_171, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_173 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_174 = __beopt_width_18[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_16_175 = 8'(($unsigned(8'($unsigned(mul_tree_16_173))) * $unsigned(8'($unsigned(mul_tree_16_174))))); // decl: <none>; prim: <none>
    assign mul_tree_16_176 = {mul_tree_16_175, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_177 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_178 = __beopt_width_18[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_16_179 = 8'(($unsigned(8'($unsigned(mul_tree_16_177))) * $unsigned(8'($unsigned(mul_tree_16_178))))); // decl: <none>; prim: <none>
    assign mul_tree_16_180 = {mul_tree_16_179, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_181 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_182 = __beopt_width_18[11:8]; // decl: <none>; prim: <none>
    assign mul_tree_16_183 = 8'(($unsigned(8'($unsigned(mul_tree_16_181))) * $unsigned(8'($unsigned(mul_tree_16_182))))); // decl: <none>; prim: <none>
    assign mul_tree_16_184 = {mul_tree_16_183, 20'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_185 = __beopt_width_14[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_186 = __beopt_width_18[15:12]; // decl: <none>; prim: <none>
    assign mul_tree_16_187 = 8'(($unsigned(8'($unsigned(mul_tree_16_185))) * $unsigned(8'($unsigned(mul_tree_16_186))))); // decl: <none>; prim: <none>
    assign mul_tree_16_188 = {mul_tree_16_187, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_16_189 = ({5'h0, rtlzz_pipe_128_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_190 = ({1'h0, rtlzz_pipe_132_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_191 = 13'((mul_tree_16_189 + mul_tree_16_190 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_192 = ({5'h0, rtlzz_pipe_136_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_193 = ({1'h0, rtlzz_pipe_140_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_194 = 21'((mul_tree_16_192 + mul_tree_16_193 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_195 = ({5'h0, rtlzz_pipe_144_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_196 = ({1'h0, rtlzz_pipe_148_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_197 = 17'((mul_tree_16_195 + mul_tree_16_196 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_198 = ({5'h0, rtlzz_pipe_152_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_199 = ({1'h0, rtlzz_pipe_156_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_200 = 25'((mul_tree_16_198 + mul_tree_16_199 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_201 = ({5'h0, rtlzz_pipe_160_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_202 = ({1'h0, rtlzz_pipe_164_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_203 = 21'((mul_tree_16_201 + mul_tree_16_202 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_204 = ({5'h0, rtlzz_pipe_168_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_205 = ({1'h0, rtlzz_pipe_172_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_206 = 29'((mul_tree_16_204 + mul_tree_16_205 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_207 = ({5'h0, rtlzz_pipe_176_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_208 = ({1'h0, rtlzz_pipe_180_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_209 = 25'((mul_tree_16_207 + mul_tree_16_208 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_210 = ({5'h0, rtlzz_pipe_184_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_211 = ({1'h0, rtlzz_pipe_188_s1}); // decl: <none>; prim: <none>
    assign mul_tree_16_212 = 33'((mul_tree_16_210 + mul_tree_16_211 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_213 = ({9'h0, mul_tree_16_191}); // decl: <none>; prim: <none>
    assign mul_tree_16_214 = ({1'h0, mul_tree_16_194}); // decl: <none>; prim: <none>
    assign mul_tree_16_215 = 22'((mul_tree_16_213 + mul_tree_16_214 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_216 = ({9'h0, mul_tree_16_197}); // decl: <none>; prim: <none>
    assign mul_tree_16_217 = ({1'h0, mul_tree_16_200}); // decl: <none>; prim: <none>
    assign mul_tree_16_218 = 26'((mul_tree_16_216 + mul_tree_16_217 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_219 = ({9'h0, mul_tree_16_203}); // decl: <none>; prim: <none>
    assign mul_tree_16_220 = ({1'h0, mul_tree_16_206}); // decl: <none>; prim: <none>
    assign mul_tree_16_221 = 30'((mul_tree_16_219 + mul_tree_16_220 + ({29'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_222 = ({9'h0, mul_tree_16_209}); // decl: <none>; prim: <none>
    assign mul_tree_16_223 = ({1'h0, mul_tree_16_212}); // decl: <none>; prim: <none>
    assign mul_tree_16_224 = 34'((mul_tree_16_222 + mul_tree_16_223 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_225 = ({5'h0, rtlzz_pipe_215_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_226 = ({1'h0, rtlzz_pipe_218_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_227 = 27'((mul_tree_16_225 + mul_tree_16_226 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_228 = ({5'h0, rtlzz_pipe_221_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_229 = ({1'h0, rtlzz_pipe_224_s2}); // decl: <none>; prim: <none>
    assign mul_tree_16_230 = 35'((mul_tree_16_228 + mul_tree_16_229 + ({34'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_231 = ({9'h0, mul_tree_16_227}); // decl: <none>; prim: <none>
    assign mul_tree_16_232 = ({1'h0, mul_tree_16_230}); // decl: <none>; prim: <none>
    assign mul_tree_16_233 = 36'((mul_tree_16_231 + mul_tree_16_232 + ({35'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_16_234 = mul_tree_16_233[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_19_s1 <= 8'h23;
            rtlzz_pipe_23_s1 <= 12'h0;
            rtlzz_pipe_27_s1 <= 16'h0;
            rtlzz_pipe_31_s1 <= 20'h0;
            rtlzz_pipe_35_s1 <= 12'h0;
            rtlzz_pipe_39_s1 <= 16'h0;
            rtlzz_pipe_43_s1 <= 20'h0;
            rtlzz_pipe_47_s1 <= 24'h0;
            rtlzz_pipe_51_s1 <= 16'h0;
            rtlzz_pipe_55_s1 <= 20'h0;
            rtlzz_pipe_59_s1 <= 24'h0;
            rtlzz_pipe_63_s1 <= 28'h0;
            rtlzz_pipe_67_s1 <= 20'h0;
            rtlzz_pipe_71_s1 <= 24'h0;
            rtlzz_pipe_75_s1 <= 28'h0;
            rtlzz_pipe_79_s1 <= 32'h0;
            rtlzz_pipe_106_s2 <= 22'h23;
            rtlzz_pipe_109_s2 <= 26'h0;
            rtlzz_pipe_112_s2 <= 30'h0;
            rtlzz_pipe_115_s2 <= 34'h0;
            rtlzz_pipe_128_s1 <= 8'h37;
            rtlzz_pipe_132_s1 <= 12'h0;
            rtlzz_pipe_136_s1 <= 16'h0;
            rtlzz_pipe_140_s1 <= 20'h0;
            rtlzz_pipe_144_s1 <= 12'h0;
            rtlzz_pipe_148_s1 <= 16'h0;
            rtlzz_pipe_152_s1 <= 20'h0;
            rtlzz_pipe_156_s1 <= 24'h0;
            rtlzz_pipe_160_s1 <= 16'h0;
            rtlzz_pipe_164_s1 <= 20'h0;
            rtlzz_pipe_168_s1 <= 24'h0;
            rtlzz_pipe_172_s1 <= 28'h0;
            rtlzz_pipe_176_s1 <= 20'h0;
            rtlzz_pipe_180_s1 <= 24'h0;
            rtlzz_pipe_184_s1 <= 28'h0;
            rtlzz_pipe_188_s1 <= 32'h0;
            rtlzz_pipe_215_s2 <= 22'h37;
            rtlzz_pipe_218_s2 <= 26'h0;
            rtlzz_pipe_221_s2 <= 30'h0;
            rtlzz_pipe_224_s2 <= 34'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_15_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_15_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_15_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_15_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_15_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_15_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_15_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_15_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_15_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_15_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_15_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_15_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_15_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_15_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_15_75; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_15_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= mul_tree_15_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_109_s2 <= mul_tree_15_109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= mul_tree_15_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= mul_tree_15_115; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_tree_16_128; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_132_s1 <= mul_tree_16_132; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_136_s1 <= mul_tree_16_136; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_140_s1 <= mul_tree_16_140; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_144_s1 <= mul_tree_16_144; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_148_s1 <= mul_tree_16_148; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_152_s1 <= mul_tree_16_152; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= mul_tree_16_156; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_160_s1 <= mul_tree_16_160; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_164_s1 <= mul_tree_16_164; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_168_s1 <= mul_tree_16_168; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_172_s1 <= mul_tree_16_172; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_176_s1 <= mul_tree_16_176; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_180_s1 <= mul_tree_16_180; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_184_s1 <= mul_tree_16_184; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_188_s1 <= mul_tree_16_188; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_215_s2 <= mul_tree_16_215; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_218_s2 <= mul_tree_16_218; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_221_s2 <= mul_tree_16_221; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_224_s2 <= mul_tree_16_224; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
