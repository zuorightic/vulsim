`timescale 1ns/1ps

module w13_low_1(
    input logic [12:0] a, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:10
    input logic [12:0] b, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:12
    input logic [12:0] c, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:1-2:14
    input logic iv, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    output logic ov, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:26
    output logic [12:0] y, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    output logic [12:0] z, // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [12:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [12:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [12:0] arith_original_9; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [12:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic [5:0] mul_tree_9_11; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_12; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_13; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_14; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_15; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_16; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_9_17; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_18; // decl: <none>; prim: <none>
    logic mul_tree_9_19; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_9_20; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_9_21; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_22; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_23; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_24; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_9_25; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_26; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_27; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_9_28; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_9_29; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_30; // decl: <none>; prim: <none>
    logic mul_tree_9_31; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_9_32; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_9_33; // decl: <none>; prim: <none>
    logic mul_tree_9_34; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_35; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_9_36; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_9_37; // decl: <none>; prim: <none>
    logic mul_tree_9_38; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_9_39; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_9_40; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_9_41; // decl: <none>; prim: <none>
    logic mul_tree_9_42; // decl: <none>; prim: <none>
    logic mul_tree_9_43; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_9_44; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_45; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_9_46; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_9_47; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_9_48; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_9_49; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_9_50; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_9_51; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_52; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_53; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_54; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_55; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_56; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_9_57; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_9_58; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_9_59; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_9_60; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_9_61; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_9_62; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_9_63; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_9_64; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_9_65; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_9_66; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_9_67; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_9_68; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_9_69; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_9_70; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic mul_tree_10_79; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic mul_tree_10_91; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic mul_tree_10_94; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic mul_tree_10_98; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [6:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic mul_tree_10_102; // decl: <none>; prim: <none>
    logic mul_tree_10_103; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_120; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_121; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_122; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_123; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_124; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_125; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_126; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_10_127; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_10_128; // decl: <none>; prim: <none>
    logic [28:0] mul_tree_10_129; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_130; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
    logic [11:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_77_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_81_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_93_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [25:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_5_s2; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23


    assign s8_norm_mul_0_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:37; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:18-10:23
    assign z = rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:28-2:39; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:24-10:29
    assign arith_original_9 = mul_tree_9_70; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_130; // decl: <none>; prim: <none>
    assign mul_tree_9_11 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_12 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_13 = 12'(($unsigned(12'($unsigned(mul_tree_9_11))) * $unsigned(12'($unsigned(mul_tree_9_12))))); // decl: <none>; prim: <none>
    assign mul_tree_9_14 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_15 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_16 = 12'(($unsigned(12'($unsigned(mul_tree_9_14))) * $unsigned(12'($unsigned(mul_tree_9_15))))); // decl: <none>; prim: <none>
    assign mul_tree_9_17 = {mul_tree_9_16, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_18 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_19 = b[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_20 = 7'(($unsigned(7'($unsigned(mul_tree_9_18))) * $unsigned(7'($unsigned(mul_tree_9_19))))); // decl: <none>; prim: <none>
    assign mul_tree_9_21 = {mul_tree_9_20, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_22 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_23 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_24 = 12'(($unsigned(12'($unsigned(mul_tree_9_22))) * $unsigned(12'($unsigned(mul_tree_9_23))))); // decl: <none>; prim: <none>
    assign mul_tree_9_25 = {mul_tree_9_24, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_26 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_27 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_28 = 12'(($unsigned(12'($unsigned(mul_tree_9_26))) * $unsigned(12'($unsigned(mul_tree_9_27))))); // decl: <none>; prim: <none>
    assign mul_tree_9_29 = {mul_tree_9_28, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_30 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_31 = b[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_32 = 7'(($unsigned(7'($unsigned(mul_tree_9_30))) * $unsigned(7'($unsigned(mul_tree_9_31))))); // decl: <none>; prim: <none>
    assign mul_tree_9_33 = {mul_tree_9_32, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_34 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_35 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_9_36 = 7'(($unsigned(7'($unsigned(mul_tree_9_34))) * $unsigned(7'($unsigned(mul_tree_9_35))))); // decl: <none>; prim: <none>
    assign mul_tree_9_37 = {mul_tree_9_36, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_38 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_39 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_9_40 = 7'(($unsigned(7'($unsigned(mul_tree_9_38))) * $unsigned(7'($unsigned(mul_tree_9_39))))); // decl: <none>; prim: <none>
    assign mul_tree_9_41 = {mul_tree_9_40, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_42 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_43 = b[12]; // decl: <none>; prim: <none>
    assign mul_tree_9_44 = 2'(($unsigned(2'($unsigned(mul_tree_9_42))) * $unsigned(2'($unsigned(mul_tree_9_43))))); // decl: <none>; prim: <none>
    assign mul_tree_9_45 = {mul_tree_9_44, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_9_46 = ({7'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_47 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_48 = 19'((mul_tree_9_46 + mul_tree_9_47 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_49 = ({1'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_50 = ({2'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_51 = 20'((mul_tree_9_49 + mul_tree_9_50 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_52 = ({2'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_53 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_54 = 26'((mul_tree_9_52 + mul_tree_9_53 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_55 = ({7'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_56 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_57 = 26'((mul_tree_9_55 + mul_tree_9_56 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_58 = ({2'h0, mul_tree_9_48}); // decl: <none>; prim: <none>
    assign mul_tree_9_59 = ({1'h0, mul_tree_9_51}); // decl: <none>; prim: <none>
    assign mul_tree_9_60 = 21'((mul_tree_9_58 + mul_tree_9_59 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_61 = ({1'h0, mul_tree_9_54}); // decl: <none>; prim: <none>
    assign mul_tree_9_62 = ({1'h0, mul_tree_9_57}); // decl: <none>; prim: <none>
    assign mul_tree_9_63 = 27'((mul_tree_9_61 + mul_tree_9_62 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_64 = ({7'h0, mul_tree_9_60}); // decl: <none>; prim: <none>
    assign mul_tree_9_65 = ({1'h0, mul_tree_9_63}); // decl: <none>; prim: <none>
    assign mul_tree_9_66 = 28'((mul_tree_9_64 + mul_tree_9_65 + ({27'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_67 = ({1'h0, mul_tree_9_66}); // decl: <none>; prim: <none>
    assign mul_tree_9_68 = ({3'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_9_69 = 29'((mul_tree_9_67 + mul_tree_9_68 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_9_70 = mul_tree_9_69[12:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = c[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_73 = 12'(($unsigned(12'($unsigned(mul_tree_10_71))) * $unsigned(12'($unsigned(mul_tree_10_72))))); // decl: <none>; prim: <none>
    assign mul_tree_10_74 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_75 = c[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 12'(($unsigned(12'($unsigned(mul_tree_10_74))) * $unsigned(12'($unsigned(mul_tree_10_75))))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = {mul_tree_10_76, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_78 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_79 = c[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_80 = 7'(($unsigned(7'($unsigned(mul_tree_10_78))) * $unsigned(7'($unsigned(mul_tree_10_79))))); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = {mul_tree_10_80, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_82 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_83 = c[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_84 = 12'(($unsigned(12'($unsigned(mul_tree_10_82))) * $unsigned(12'($unsigned(mul_tree_10_83))))); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = {mul_tree_10_84, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_86 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_87 = c[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 12'(($unsigned(12'($unsigned(mul_tree_10_86))) * $unsigned(12'($unsigned(mul_tree_10_87))))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = {mul_tree_10_88, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_90 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_91 = c[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_92 = 7'(($unsigned(7'($unsigned(mul_tree_10_90))) * $unsigned(7'($unsigned(mul_tree_10_91))))); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = {mul_tree_10_92, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_94 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_95 = c[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_96 = 7'(($unsigned(7'($unsigned(mul_tree_10_94))) * $unsigned(7'($unsigned(mul_tree_10_95))))); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = {mul_tree_10_96, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_98 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_99 = c[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 7'(($unsigned(7'($unsigned(mul_tree_10_98))) * $unsigned(7'($unsigned(mul_tree_10_99))))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = {mul_tree_10_100, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_102 = a[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_103 = c[12]; // decl: <none>; prim: <none>
    assign mul_tree_10_104 = 2'(($unsigned(2'($unsigned(mul_tree_10_102))) * $unsigned(2'($unsigned(mul_tree_10_103))))); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = {mul_tree_10_104, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_106 = ({7'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({1'h0, rtlzz_pipe_77_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = 19'((mul_tree_10_106 + mul_tree_10_107 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = ({1'h0, rtlzz_pipe_81_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({2'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = 20'((mul_tree_10_109 + mul_tree_10_110 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = ({2'h0, rtlzz_pipe_89_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({1'h0, rtlzz_pipe_93_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = 26'((mul_tree_10_112 + mul_tree_10_113 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = ({7'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({1'h0, rtlzz_pipe_101_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = 26'((mul_tree_10_115 + mul_tree_10_116 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = ({2'h0, mul_tree_10_108}); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = ({1'h0, mul_tree_10_111}); // decl: <none>; prim: <none>
    assign mul_tree_10_120 = 21'((mul_tree_10_118 + mul_tree_10_119 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_121 = ({1'h0, mul_tree_10_114}); // decl: <none>; prim: <none>
    assign mul_tree_10_122 = ({1'h0, mul_tree_10_117}); // decl: <none>; prim: <none>
    assign mul_tree_10_123 = 27'((mul_tree_10_121 + mul_tree_10_122 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_124 = ({7'h0, mul_tree_10_120}); // decl: <none>; prim: <none>
    assign mul_tree_10_125 = ({1'h0, mul_tree_10_123}); // decl: <none>; prim: <none>
    assign mul_tree_10_126 = 28'((mul_tree_10_124 + mul_tree_10_125 + ({27'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_127 = ({1'h0, mul_tree_10_126}); // decl: <none>; prim: <none>
    assign mul_tree_10_128 = ({3'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_129 = 29'((mul_tree_10_127 + mul_tree_10_128 + ({28'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_130 = mul_tree_10_129[12:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 12'h23;
            rtlzz_pipe_17_s1 <= 18'h0;
            rtlzz_pipe_21_s1 <= 19'h0;
            rtlzz_pipe_25_s1 <= 18'h0;
            rtlzz_pipe_29_s1 <= 24'h0;
            rtlzz_pipe_33_s1 <= 25'h0;
            rtlzz_pipe_37_s1 <= 19'h0;
            rtlzz_pipe_41_s1 <= 25'h0;
            rtlzz_pipe_45_s1 <= 26'h0;
            rtlzz_pipe_4_s2 <= 13'h23;
            rtlzz_pipe_73_s1 <= 12'h37;
            rtlzz_pipe_77_s1 <= 18'h0;
            rtlzz_pipe_81_s1 <= 19'h0;
            rtlzz_pipe_85_s1 <= 18'h0;
            rtlzz_pipe_89_s1 <= 24'h0;
            rtlzz_pipe_93_s1 <= 25'h0;
            rtlzz_pipe_97_s1 <= 19'h0;
            rtlzz_pipe_101_s1 <= 25'h0;
            rtlzz_pipe_105_s1 <= 26'h0;
            rtlzz_pipe_5_s2 <= 13'h37;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_9_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_9_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_9_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_9_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_9_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_9_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_9_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_9_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_9_45; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:20-10:23
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_77_s1 <= mul_tree_10_77; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_81_s1 <= mul_tree_10_81; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= mul_tree_10_89; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_93_s1 <= mul_tree_10_93; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_tree_10_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_10_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/mul-template.logic.cpp:10:26-10:29
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23; prim: /home/zyrv/vulsim/mul-template.logic.cpp:2:16-2:23
        end
    end
endmodule
