`timescale 1ns/1ps
module MulTemplates(input logic clk,rstn,iv,input logic [127:0] a,b,c,output logic [255:0] ys[0:87],zs[0:87],output logic vs[0:87]);
wire [15:0] y0,z0;wire v0;
w8_full_0 u0(.clk(clk),.rstn(rstn),.iv(iv),.ov(v0),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y0),.z(z0));
always_ff @(posedge clk) begin
if(!rstn)begin vs[0]<=0;ys[0]<=256'd35;zs[0]<=256'd55;end
else begin vs[0]<=v0;if(v0)begin ys[0]<=256'(y0);zs[0]<=256'(z0);end end
end
wire [15:0] y1,z1;wire v1;
w8_full_1 u1(.clk(clk),.rstn(rstn),.iv(iv),.ov(v1),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y1),.z(z1));
always_ff @(posedge clk) begin
if(!rstn)begin vs[1]<=0;ys[1]<=256'd35;zs[1]<=256'd55;end
else begin vs[1]<=v1;if(v1)begin ys[1]<=256'(y1);zs[1]<=256'(z1);end end
end
wire [15:0] y2,z2;wire v2;
w8_full_2 u2(.clk(clk),.rstn(rstn),.iv(iv),.ov(v2),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y2),.z(z2));
always_ff @(posedge clk) begin
if(!rstn)begin vs[2]<=0;ys[2]<=256'd35;zs[2]<=256'd55;end
else begin vs[2]<=v2;if(v2)begin ys[2]<=256'(y2);zs[2]<=256'(z2);end end
end
wire [15:0] y3,z3;wire v3;
w8_full_3 u3(.clk(clk),.rstn(rstn),.iv(iv),.ov(v3),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y3),.z(z3));
always_ff @(posedge clk) begin
if(!rstn)begin vs[3]<=0;ys[3]<=256'd35;zs[3]<=256'd55;end
else begin vs[3]<=v3;if(v3)begin ys[3]<=256'(y3);zs[3]<=256'(z3);end end
end
wire [7:0] y4,z4;wire v4;
w8_low_0 u4(.clk(clk),.rstn(rstn),.iv(iv),.ov(v4),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y4),.z(z4));
always_ff @(posedge clk) begin
if(!rstn)begin vs[4]<=0;ys[4]<=256'd35;zs[4]<=256'd55;end
else begin vs[4]<=v4;if(v4)begin ys[4]<=256'(y4);zs[4]<=256'(z4);end end
end
wire [7:0] y5,z5;wire v5;
w8_low_1 u5(.clk(clk),.rstn(rstn),.iv(iv),.ov(v5),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y5),.z(z5));
always_ff @(posedge clk) begin
if(!rstn)begin vs[5]<=0;ys[5]<=256'd35;zs[5]<=256'd55;end
else begin vs[5]<=v5;if(v5)begin ys[5]<=256'(y5);zs[5]<=256'(z5);end end
end
wire [7:0] y6,z6;wire v6;
w8_low_2 u6(.clk(clk),.rstn(rstn),.iv(iv),.ov(v6),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y6),.z(z6));
always_ff @(posedge clk) begin
if(!rstn)begin vs[6]<=0;ys[6]<=256'd35;zs[6]<=256'd55;end
else begin vs[6]<=v6;if(v6)begin ys[6]<=256'(y6);zs[6]<=256'(z6);end end
end
wire [7:0] y7,z7;wire v7;
w8_low_3 u7(.clk(clk),.rstn(rstn),.iv(iv),.ov(v7),.a(a[7:0]),.b(b[7:0]),.c(c[7:0]),.y(y7),.z(z7));
always_ff @(posedge clk) begin
if(!rstn)begin vs[7]<=0;ys[7]<=256'd35;zs[7]<=256'd55;end
else begin vs[7]<=v7;if(v7)begin ys[7]<=256'(y7);zs[7]<=256'(z7);end end
end
wire [31:0] y8,z8;wire v8;
w16_full_0 u8(.clk(clk),.rstn(rstn),.iv(iv),.ov(v8),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y8),.z(z8));
always_ff @(posedge clk) begin
if(!rstn)begin vs[8]<=0;ys[8]<=256'd35;zs[8]<=256'd55;end
else begin vs[8]<=v8;if(v8)begin ys[8]<=256'(y8);zs[8]<=256'(z8);end end
end
wire [31:0] y9,z9;wire v9;
w16_full_1 u9(.clk(clk),.rstn(rstn),.iv(iv),.ov(v9),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y9),.z(z9));
always_ff @(posedge clk) begin
if(!rstn)begin vs[9]<=0;ys[9]<=256'd35;zs[9]<=256'd55;end
else begin vs[9]<=v9;if(v9)begin ys[9]<=256'(y9);zs[9]<=256'(z9);end end
end
wire [31:0] y10,z10;wire v10;
w16_full_2 u10(.clk(clk),.rstn(rstn),.iv(iv),.ov(v10),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y10),.z(z10));
always_ff @(posedge clk) begin
if(!rstn)begin vs[10]<=0;ys[10]<=256'd35;zs[10]<=256'd55;end
else begin vs[10]<=v10;if(v10)begin ys[10]<=256'(y10);zs[10]<=256'(z10);end end
end
wire [31:0] y11,z11;wire v11;
w16_full_3 u11(.clk(clk),.rstn(rstn),.iv(iv),.ov(v11),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y11),.z(z11));
always_ff @(posedge clk) begin
if(!rstn)begin vs[11]<=0;ys[11]<=256'd35;zs[11]<=256'd55;end
else begin vs[11]<=v11;if(v11)begin ys[11]<=256'(y11);zs[11]<=256'(z11);end end
end
wire [15:0] y12,z12;wire v12;
w16_low_0 u12(.clk(clk),.rstn(rstn),.iv(iv),.ov(v12),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y12),.z(z12));
always_ff @(posedge clk) begin
if(!rstn)begin vs[12]<=0;ys[12]<=256'd35;zs[12]<=256'd55;end
else begin vs[12]<=v12;if(v12)begin ys[12]<=256'(y12);zs[12]<=256'(z12);end end
end
wire [15:0] y13,z13;wire v13;
w16_low_1 u13(.clk(clk),.rstn(rstn),.iv(iv),.ov(v13),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y13),.z(z13));
always_ff @(posedge clk) begin
if(!rstn)begin vs[13]<=0;ys[13]<=256'd35;zs[13]<=256'd55;end
else begin vs[13]<=v13;if(v13)begin ys[13]<=256'(y13);zs[13]<=256'(z13);end end
end
wire [15:0] y14,z14;wire v14;
w16_low_2 u14(.clk(clk),.rstn(rstn),.iv(iv),.ov(v14),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y14),.z(z14));
always_ff @(posedge clk) begin
if(!rstn)begin vs[14]<=0;ys[14]<=256'd35;zs[14]<=256'd55;end
else begin vs[14]<=v14;if(v14)begin ys[14]<=256'(y14);zs[14]<=256'(z14);end end
end
wire [15:0] y15,z15;wire v15;
w16_low_3 u15(.clk(clk),.rstn(rstn),.iv(iv),.ov(v15),.a(a[15:0]),.b(b[15:0]),.c(c[15:0]),.y(y15),.z(z15));
always_ff @(posedge clk) begin
if(!rstn)begin vs[15]<=0;ys[15]<=256'd35;zs[15]<=256'd55;end
else begin vs[15]<=v15;if(v15)begin ys[15]<=256'(y15);zs[15]<=256'(z15);end end
end
wire [63:0] y16,z16;wire v16;
w32_full_0 u16(.clk(clk),.rstn(rstn),.iv(iv),.ov(v16),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y16),.z(z16));
always_ff @(posedge clk) begin
if(!rstn)begin vs[16]<=0;ys[16]<=256'd35;zs[16]<=256'd55;end
else begin vs[16]<=v16;if(v16)begin ys[16]<=256'(y16);zs[16]<=256'(z16);end end
end
wire [63:0] y17,z17;wire v17;
w32_full_1 u17(.clk(clk),.rstn(rstn),.iv(iv),.ov(v17),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y17),.z(z17));
always_ff @(posedge clk) begin
if(!rstn)begin vs[17]<=0;ys[17]<=256'd35;zs[17]<=256'd55;end
else begin vs[17]<=v17;if(v17)begin ys[17]<=256'(y17);zs[17]<=256'(z17);end end
end
wire [63:0] y18,z18;wire v18;
w32_full_2 u18(.clk(clk),.rstn(rstn),.iv(iv),.ov(v18),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y18),.z(z18));
always_ff @(posedge clk) begin
if(!rstn)begin vs[18]<=0;ys[18]<=256'd35;zs[18]<=256'd55;end
else begin vs[18]<=v18;if(v18)begin ys[18]<=256'(y18);zs[18]<=256'(z18);end end
end
wire [63:0] y19,z19;wire v19;
w32_full_3 u19(.clk(clk),.rstn(rstn),.iv(iv),.ov(v19),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y19),.z(z19));
always_ff @(posedge clk) begin
if(!rstn)begin vs[19]<=0;ys[19]<=256'd35;zs[19]<=256'd55;end
else begin vs[19]<=v19;if(v19)begin ys[19]<=256'(y19);zs[19]<=256'(z19);end end
end
wire [31:0] y20,z20;wire v20;
w32_low_0 u20(.clk(clk),.rstn(rstn),.iv(iv),.ov(v20),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y20),.z(z20));
always_ff @(posedge clk) begin
if(!rstn)begin vs[20]<=0;ys[20]<=256'd35;zs[20]<=256'd55;end
else begin vs[20]<=v20;if(v20)begin ys[20]<=256'(y20);zs[20]<=256'(z20);end end
end
wire [31:0] y21,z21;wire v21;
w32_low_1 u21(.clk(clk),.rstn(rstn),.iv(iv),.ov(v21),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y21),.z(z21));
always_ff @(posedge clk) begin
if(!rstn)begin vs[21]<=0;ys[21]<=256'd35;zs[21]<=256'd55;end
else begin vs[21]<=v21;if(v21)begin ys[21]<=256'(y21);zs[21]<=256'(z21);end end
end
wire [31:0] y22,z22;wire v22;
w32_low_2 u22(.clk(clk),.rstn(rstn),.iv(iv),.ov(v22),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y22),.z(z22));
always_ff @(posedge clk) begin
if(!rstn)begin vs[22]<=0;ys[22]<=256'd35;zs[22]<=256'd55;end
else begin vs[22]<=v22;if(v22)begin ys[22]<=256'(y22);zs[22]<=256'(z22);end end
end
wire [31:0] y23,z23;wire v23;
w32_low_3 u23(.clk(clk),.rstn(rstn),.iv(iv),.ov(v23),.a(a[31:0]),.b(b[31:0]),.c(c[31:0]),.y(y23),.z(z23));
always_ff @(posedge clk) begin
if(!rstn)begin vs[23]<=0;ys[23]<=256'd35;zs[23]<=256'd55;end
else begin vs[23]<=v23;if(v23)begin ys[23]<=256'(y23);zs[23]<=256'(z23);end end
end
wire [127:0] y24,z24;wire v24;
w64_full_0 u24(.clk(clk),.rstn(rstn),.iv(iv),.ov(v24),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y24),.z(z24));
always_ff @(posedge clk) begin
if(!rstn)begin vs[24]<=0;ys[24]<=256'd35;zs[24]<=256'd55;end
else begin vs[24]<=v24;if(v24)begin ys[24]<=256'(y24);zs[24]<=256'(z24);end end
end
wire [127:0] y25,z25;wire v25;
w64_full_1 u25(.clk(clk),.rstn(rstn),.iv(iv),.ov(v25),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y25),.z(z25));
always_ff @(posedge clk) begin
if(!rstn)begin vs[25]<=0;ys[25]<=256'd35;zs[25]<=256'd55;end
else begin vs[25]<=v25;if(v25)begin ys[25]<=256'(y25);zs[25]<=256'(z25);end end
end
wire [127:0] y26,z26;wire v26;
w64_full_2 u26(.clk(clk),.rstn(rstn),.iv(iv),.ov(v26),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y26),.z(z26));
always_ff @(posedge clk) begin
if(!rstn)begin vs[26]<=0;ys[26]<=256'd35;zs[26]<=256'd55;end
else begin vs[26]<=v26;if(v26)begin ys[26]<=256'(y26);zs[26]<=256'(z26);end end
end
wire [127:0] y27,z27;wire v27;
w64_full_3 u27(.clk(clk),.rstn(rstn),.iv(iv),.ov(v27),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y27),.z(z27));
always_ff @(posedge clk) begin
if(!rstn)begin vs[27]<=0;ys[27]<=256'd35;zs[27]<=256'd55;end
else begin vs[27]<=v27;if(v27)begin ys[27]<=256'(y27);zs[27]<=256'(z27);end end
end
wire [63:0] y28,z28;wire v28;
w64_low_0 u28(.clk(clk),.rstn(rstn),.iv(iv),.ov(v28),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y28),.z(z28));
always_ff @(posedge clk) begin
if(!rstn)begin vs[28]<=0;ys[28]<=256'd35;zs[28]<=256'd55;end
else begin vs[28]<=v28;if(v28)begin ys[28]<=256'(y28);zs[28]<=256'(z28);end end
end
wire [63:0] y29,z29;wire v29;
w64_low_1 u29(.clk(clk),.rstn(rstn),.iv(iv),.ov(v29),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y29),.z(z29));
always_ff @(posedge clk) begin
if(!rstn)begin vs[29]<=0;ys[29]<=256'd35;zs[29]<=256'd55;end
else begin vs[29]<=v29;if(v29)begin ys[29]<=256'(y29);zs[29]<=256'(z29);end end
end
wire [63:0] y30,z30;wire v30;
w64_low_2 u30(.clk(clk),.rstn(rstn),.iv(iv),.ov(v30),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y30),.z(z30));
always_ff @(posedge clk) begin
if(!rstn)begin vs[30]<=0;ys[30]<=256'd35;zs[30]<=256'd55;end
else begin vs[30]<=v30;if(v30)begin ys[30]<=256'(y30);zs[30]<=256'(z30);end end
end
wire [63:0] y31,z31;wire v31;
w64_low_3 u31(.clk(clk),.rstn(rstn),.iv(iv),.ov(v31),.a(a[63:0]),.b(b[63:0]),.c(c[63:0]),.y(y31),.z(z31));
always_ff @(posedge clk) begin
if(!rstn)begin vs[31]<=0;ys[31]<=256'd35;zs[31]<=256'd55;end
else begin vs[31]<=v31;if(v31)begin ys[31]<=256'(y31);zs[31]<=256'(z31);end end
end
wire [255:0] y32,z32;wire v32;
w128_full_0 u32(.clk(clk),.rstn(rstn),.iv(iv),.ov(v32),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y32),.z(z32));
always_ff @(posedge clk) begin
if(!rstn)begin vs[32]<=0;ys[32]<=256'd35;zs[32]<=256'd55;end
else begin vs[32]<=v32;if(v32)begin ys[32]<=256'(y32);zs[32]<=256'(z32);end end
end
wire [255:0] y33,z33;wire v33;
w128_full_1 u33(.clk(clk),.rstn(rstn),.iv(iv),.ov(v33),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y33),.z(z33));
always_ff @(posedge clk) begin
if(!rstn)begin vs[33]<=0;ys[33]<=256'd35;zs[33]<=256'd55;end
else begin vs[33]<=v33;if(v33)begin ys[33]<=256'(y33);zs[33]<=256'(z33);end end
end
wire [255:0] y34,z34;wire v34;
w128_full_2 u34(.clk(clk),.rstn(rstn),.iv(iv),.ov(v34),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y34),.z(z34));
always_ff @(posedge clk) begin
if(!rstn)begin vs[34]<=0;ys[34]<=256'd35;zs[34]<=256'd55;end
else begin vs[34]<=v34;if(v34)begin ys[34]<=256'(y34);zs[34]<=256'(z34);end end
end
wire [255:0] y35,z35;wire v35;
w128_full_3 u35(.clk(clk),.rstn(rstn),.iv(iv),.ov(v35),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y35),.z(z35));
always_ff @(posedge clk) begin
if(!rstn)begin vs[35]<=0;ys[35]<=256'd35;zs[35]<=256'd55;end
else begin vs[35]<=v35;if(v35)begin ys[35]<=256'(y35);zs[35]<=256'(z35);end end
end
wire [127:0] y36,z36;wire v36;
w128_low_0 u36(.clk(clk),.rstn(rstn),.iv(iv),.ov(v36),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y36),.z(z36));
always_ff @(posedge clk) begin
if(!rstn)begin vs[36]<=0;ys[36]<=256'd35;zs[36]<=256'd55;end
else begin vs[36]<=v36;if(v36)begin ys[36]<=256'(y36);zs[36]<=256'(z36);end end
end
wire [127:0] y37,z37;wire v37;
w128_low_1 u37(.clk(clk),.rstn(rstn),.iv(iv),.ov(v37),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y37),.z(z37));
always_ff @(posedge clk) begin
if(!rstn)begin vs[37]<=0;ys[37]<=256'd35;zs[37]<=256'd55;end
else begin vs[37]<=v37;if(v37)begin ys[37]<=256'(y37);zs[37]<=256'(z37);end end
end
wire [127:0] y38,z38;wire v38;
w128_low_2 u38(.clk(clk),.rstn(rstn),.iv(iv),.ov(v38),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y38),.z(z38));
always_ff @(posedge clk) begin
if(!rstn)begin vs[38]<=0;ys[38]<=256'd35;zs[38]<=256'd55;end
else begin vs[38]<=v38;if(v38)begin ys[38]<=256'(y38);zs[38]<=256'(z38);end end
end
wire [127:0] y39,z39;wire v39;
w128_low_3 u39(.clk(clk),.rstn(rstn),.iv(iv),.ov(v39),.a(a[127:0]),.b(b[127:0]),.c(c[127:0]),.y(y39),.z(z39));
always_ff @(posedge clk) begin
if(!rstn)begin vs[39]<=0;ys[39]<=256'd35;zs[39]<=256'd55;end
else begin vs[39]<=v39;if(v39)begin ys[39]<=256'(y39);zs[39]<=256'(z39);end end
end
wire [23:0] y40,z40;wire v40;
w12_full_0 u40(.clk(clk),.rstn(rstn),.iv(iv),.ov(v40),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y40),.z(z40));
always_ff @(posedge clk) begin
if(!rstn)begin vs[40]<=0;ys[40]<=256'd35;zs[40]<=256'd55;end
else begin vs[40]<=v40;if(v40)begin ys[40]<=256'(y40);zs[40]<=256'(z40);end end
end
wire [23:0] y41,z41;wire v41;
w12_full_1 u41(.clk(clk),.rstn(rstn),.iv(iv),.ov(v41),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y41),.z(z41));
always_ff @(posedge clk) begin
if(!rstn)begin vs[41]<=0;ys[41]<=256'd35;zs[41]<=256'd55;end
else begin vs[41]<=v41;if(v41)begin ys[41]<=256'(y41);zs[41]<=256'(z41);end end
end
wire [23:0] y42,z42;wire v42;
w12_full_2 u42(.clk(clk),.rstn(rstn),.iv(iv),.ov(v42),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y42),.z(z42));
always_ff @(posedge clk) begin
if(!rstn)begin vs[42]<=0;ys[42]<=256'd35;zs[42]<=256'd55;end
else begin vs[42]<=v42;if(v42)begin ys[42]<=256'(y42);zs[42]<=256'(z42);end end
end
wire [23:0] y43,z43;wire v43;
w12_full_3 u43(.clk(clk),.rstn(rstn),.iv(iv),.ov(v43),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y43),.z(z43));
always_ff @(posedge clk) begin
if(!rstn)begin vs[43]<=0;ys[43]<=256'd35;zs[43]<=256'd55;end
else begin vs[43]<=v43;if(v43)begin ys[43]<=256'(y43);zs[43]<=256'(z43);end end
end
wire [11:0] y44,z44;wire v44;
w12_low_0 u44(.clk(clk),.rstn(rstn),.iv(iv),.ov(v44),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y44),.z(z44));
always_ff @(posedge clk) begin
if(!rstn)begin vs[44]<=0;ys[44]<=256'd35;zs[44]<=256'd55;end
else begin vs[44]<=v44;if(v44)begin ys[44]<=256'(y44);zs[44]<=256'(z44);end end
end
wire [11:0] y45,z45;wire v45;
w12_low_1 u45(.clk(clk),.rstn(rstn),.iv(iv),.ov(v45),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y45),.z(z45));
always_ff @(posedge clk) begin
if(!rstn)begin vs[45]<=0;ys[45]<=256'd35;zs[45]<=256'd55;end
else begin vs[45]<=v45;if(v45)begin ys[45]<=256'(y45);zs[45]<=256'(z45);end end
end
wire [11:0] y46,z46;wire v46;
w12_low_2 u46(.clk(clk),.rstn(rstn),.iv(iv),.ov(v46),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y46),.z(z46));
always_ff @(posedge clk) begin
if(!rstn)begin vs[46]<=0;ys[46]<=256'd35;zs[46]<=256'd55;end
else begin vs[46]<=v46;if(v46)begin ys[46]<=256'(y46);zs[46]<=256'(z46);end end
end
wire [11:0] y47,z47;wire v47;
w12_low_3 u47(.clk(clk),.rstn(rstn),.iv(iv),.ov(v47),.a(a[11:0]),.b(b[11:0]),.c(c[11:0]),.y(y47),.z(z47));
always_ff @(posedge clk) begin
if(!rstn)begin vs[47]<=0;ys[47]<=256'd35;zs[47]<=256'd55;end
else begin vs[47]<=v47;if(v47)begin ys[47]<=256'(y47);zs[47]<=256'(z47);end end
end
wire [47:0] y48,z48;wire v48;
w24_full_0 u48(.clk(clk),.rstn(rstn),.iv(iv),.ov(v48),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y48),.z(z48));
always_ff @(posedge clk) begin
if(!rstn)begin vs[48]<=0;ys[48]<=256'd35;zs[48]<=256'd55;end
else begin vs[48]<=v48;if(v48)begin ys[48]<=256'(y48);zs[48]<=256'(z48);end end
end
wire [47:0] y49,z49;wire v49;
w24_full_1 u49(.clk(clk),.rstn(rstn),.iv(iv),.ov(v49),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y49),.z(z49));
always_ff @(posedge clk) begin
if(!rstn)begin vs[49]<=0;ys[49]<=256'd35;zs[49]<=256'd55;end
else begin vs[49]<=v49;if(v49)begin ys[49]<=256'(y49);zs[49]<=256'(z49);end end
end
wire [47:0] y50,z50;wire v50;
w24_full_2 u50(.clk(clk),.rstn(rstn),.iv(iv),.ov(v50),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y50),.z(z50));
always_ff @(posedge clk) begin
if(!rstn)begin vs[50]<=0;ys[50]<=256'd35;zs[50]<=256'd55;end
else begin vs[50]<=v50;if(v50)begin ys[50]<=256'(y50);zs[50]<=256'(z50);end end
end
wire [47:0] y51,z51;wire v51;
w24_full_3 u51(.clk(clk),.rstn(rstn),.iv(iv),.ov(v51),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y51),.z(z51));
always_ff @(posedge clk) begin
if(!rstn)begin vs[51]<=0;ys[51]<=256'd35;zs[51]<=256'd55;end
else begin vs[51]<=v51;if(v51)begin ys[51]<=256'(y51);zs[51]<=256'(z51);end end
end
wire [23:0] y52,z52;wire v52;
w24_low_0 u52(.clk(clk),.rstn(rstn),.iv(iv),.ov(v52),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y52),.z(z52));
always_ff @(posedge clk) begin
if(!rstn)begin vs[52]<=0;ys[52]<=256'd35;zs[52]<=256'd55;end
else begin vs[52]<=v52;if(v52)begin ys[52]<=256'(y52);zs[52]<=256'(z52);end end
end
wire [23:0] y53,z53;wire v53;
w24_low_1 u53(.clk(clk),.rstn(rstn),.iv(iv),.ov(v53),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y53),.z(z53));
always_ff @(posedge clk) begin
if(!rstn)begin vs[53]<=0;ys[53]<=256'd35;zs[53]<=256'd55;end
else begin vs[53]<=v53;if(v53)begin ys[53]<=256'(y53);zs[53]<=256'(z53);end end
end
wire [23:0] y54,z54;wire v54;
w24_low_2 u54(.clk(clk),.rstn(rstn),.iv(iv),.ov(v54),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y54),.z(z54));
always_ff @(posedge clk) begin
if(!rstn)begin vs[54]<=0;ys[54]<=256'd35;zs[54]<=256'd55;end
else begin vs[54]<=v54;if(v54)begin ys[54]<=256'(y54);zs[54]<=256'(z54);end end
end
wire [23:0] y55,z55;wire v55;
w24_low_3 u55(.clk(clk),.rstn(rstn),.iv(iv),.ov(v55),.a(a[23:0]),.b(b[23:0]),.c(c[23:0]),.y(y55),.z(z55));
always_ff @(posedge clk) begin
if(!rstn)begin vs[55]<=0;ys[55]<=256'd35;zs[55]<=256'd55;end
else begin vs[55]<=v55;if(v55)begin ys[55]<=256'(y55);zs[55]<=256'(z55);end end
end
wire [95:0] y56,z56;wire v56;
w48_full_0 u56(.clk(clk),.rstn(rstn),.iv(iv),.ov(v56),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y56),.z(z56));
always_ff @(posedge clk) begin
if(!rstn)begin vs[56]<=0;ys[56]<=256'd35;zs[56]<=256'd55;end
else begin vs[56]<=v56;if(v56)begin ys[56]<=256'(y56);zs[56]<=256'(z56);end end
end
wire [95:0] y57,z57;wire v57;
w48_full_1 u57(.clk(clk),.rstn(rstn),.iv(iv),.ov(v57),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y57),.z(z57));
always_ff @(posedge clk) begin
if(!rstn)begin vs[57]<=0;ys[57]<=256'd35;zs[57]<=256'd55;end
else begin vs[57]<=v57;if(v57)begin ys[57]<=256'(y57);zs[57]<=256'(z57);end end
end
wire [95:0] y58,z58;wire v58;
w48_full_2 u58(.clk(clk),.rstn(rstn),.iv(iv),.ov(v58),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y58),.z(z58));
always_ff @(posedge clk) begin
if(!rstn)begin vs[58]<=0;ys[58]<=256'd35;zs[58]<=256'd55;end
else begin vs[58]<=v58;if(v58)begin ys[58]<=256'(y58);zs[58]<=256'(z58);end end
end
wire [95:0] y59,z59;wire v59;
w48_full_3 u59(.clk(clk),.rstn(rstn),.iv(iv),.ov(v59),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y59),.z(z59));
always_ff @(posedge clk) begin
if(!rstn)begin vs[59]<=0;ys[59]<=256'd35;zs[59]<=256'd55;end
else begin vs[59]<=v59;if(v59)begin ys[59]<=256'(y59);zs[59]<=256'(z59);end end
end
wire [47:0] y60,z60;wire v60;
w48_low_0 u60(.clk(clk),.rstn(rstn),.iv(iv),.ov(v60),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y60),.z(z60));
always_ff @(posedge clk) begin
if(!rstn)begin vs[60]<=0;ys[60]<=256'd35;zs[60]<=256'd55;end
else begin vs[60]<=v60;if(v60)begin ys[60]<=256'(y60);zs[60]<=256'(z60);end end
end
wire [47:0] y61,z61;wire v61;
w48_low_1 u61(.clk(clk),.rstn(rstn),.iv(iv),.ov(v61),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y61),.z(z61));
always_ff @(posedge clk) begin
if(!rstn)begin vs[61]<=0;ys[61]<=256'd35;zs[61]<=256'd55;end
else begin vs[61]<=v61;if(v61)begin ys[61]<=256'(y61);zs[61]<=256'(z61);end end
end
wire [47:0] y62,z62;wire v62;
w48_low_2 u62(.clk(clk),.rstn(rstn),.iv(iv),.ov(v62),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y62),.z(z62));
always_ff @(posedge clk) begin
if(!rstn)begin vs[62]<=0;ys[62]<=256'd35;zs[62]<=256'd55;end
else begin vs[62]<=v62;if(v62)begin ys[62]<=256'(y62);zs[62]<=256'(z62);end end
end
wire [47:0] y63,z63;wire v63;
w48_low_3 u63(.clk(clk),.rstn(rstn),.iv(iv),.ov(v63),.a(a[47:0]),.b(b[47:0]),.c(c[47:0]),.y(y63),.z(z63));
always_ff @(posedge clk) begin
if(!rstn)begin vs[63]<=0;ys[63]<=256'd35;zs[63]<=256'd55;end
else begin vs[63]<=v63;if(v63)begin ys[63]<=256'(y63);zs[63]<=256'(z63);end end
end
wire [191:0] y64,z64;wire v64;
w96_full_0 u64(.clk(clk),.rstn(rstn),.iv(iv),.ov(v64),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y64),.z(z64));
always_ff @(posedge clk) begin
if(!rstn)begin vs[64]<=0;ys[64]<=256'd35;zs[64]<=256'd55;end
else begin vs[64]<=v64;if(v64)begin ys[64]<=256'(y64);zs[64]<=256'(z64);end end
end
wire [191:0] y65,z65;wire v65;
w96_full_1 u65(.clk(clk),.rstn(rstn),.iv(iv),.ov(v65),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y65),.z(z65));
always_ff @(posedge clk) begin
if(!rstn)begin vs[65]<=0;ys[65]<=256'd35;zs[65]<=256'd55;end
else begin vs[65]<=v65;if(v65)begin ys[65]<=256'(y65);zs[65]<=256'(z65);end end
end
wire [191:0] y66,z66;wire v66;
w96_full_2 u66(.clk(clk),.rstn(rstn),.iv(iv),.ov(v66),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y66),.z(z66));
always_ff @(posedge clk) begin
if(!rstn)begin vs[66]<=0;ys[66]<=256'd35;zs[66]<=256'd55;end
else begin vs[66]<=v66;if(v66)begin ys[66]<=256'(y66);zs[66]<=256'(z66);end end
end
wire [191:0] y67,z67;wire v67;
w96_full_3 u67(.clk(clk),.rstn(rstn),.iv(iv),.ov(v67),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y67),.z(z67));
always_ff @(posedge clk) begin
if(!rstn)begin vs[67]<=0;ys[67]<=256'd35;zs[67]<=256'd55;end
else begin vs[67]<=v67;if(v67)begin ys[67]<=256'(y67);zs[67]<=256'(z67);end end
end
wire [95:0] y68,z68;wire v68;
w96_low_0 u68(.clk(clk),.rstn(rstn),.iv(iv),.ov(v68),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y68),.z(z68));
always_ff @(posedge clk) begin
if(!rstn)begin vs[68]<=0;ys[68]<=256'd35;zs[68]<=256'd55;end
else begin vs[68]<=v68;if(v68)begin ys[68]<=256'(y68);zs[68]<=256'(z68);end end
end
wire [95:0] y69,z69;wire v69;
w96_low_1 u69(.clk(clk),.rstn(rstn),.iv(iv),.ov(v69),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y69),.z(z69));
always_ff @(posedge clk) begin
if(!rstn)begin vs[69]<=0;ys[69]<=256'd35;zs[69]<=256'd55;end
else begin vs[69]<=v69;if(v69)begin ys[69]<=256'(y69);zs[69]<=256'(z69);end end
end
wire [95:0] y70,z70;wire v70;
w96_low_2 u70(.clk(clk),.rstn(rstn),.iv(iv),.ov(v70),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y70),.z(z70));
always_ff @(posedge clk) begin
if(!rstn)begin vs[70]<=0;ys[70]<=256'd35;zs[70]<=256'd55;end
else begin vs[70]<=v70;if(v70)begin ys[70]<=256'(y70);zs[70]<=256'(z70);end end
end
wire [95:0] y71,z71;wire v71;
w96_low_3 u71(.clk(clk),.rstn(rstn),.iv(iv),.ov(v71),.a(a[95:0]),.b(b[95:0]),.c(c[95:0]),.y(y71),.z(z71));
always_ff @(posedge clk) begin
if(!rstn)begin vs[71]<=0;ys[71]<=256'd35;zs[71]<=256'd55;end
else begin vs[71]<=v71;if(v71)begin ys[71]<=256'(y71);zs[71]<=256'(z71);end end
end
wire [25:0] y72,z72;wire v72;
w13_full_0 u72(.clk(clk),.rstn(rstn),.iv(iv),.ov(v72),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y72),.z(z72));
always_ff @(posedge clk) begin
if(!rstn)begin vs[72]<=0;ys[72]<=256'd35;zs[72]<=256'd55;end
else begin vs[72]<=v72;if(v72)begin ys[72]<=256'(y72);zs[72]<=256'(z72);end end
end
wire [25:0] y73,z73;wire v73;
w13_full_1 u73(.clk(clk),.rstn(rstn),.iv(iv),.ov(v73),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y73),.z(z73));
always_ff @(posedge clk) begin
if(!rstn)begin vs[73]<=0;ys[73]<=256'd35;zs[73]<=256'd55;end
else begin vs[73]<=v73;if(v73)begin ys[73]<=256'(y73);zs[73]<=256'(z73);end end
end
wire [25:0] y74,z74;wire v74;
w13_full_2 u74(.clk(clk),.rstn(rstn),.iv(iv),.ov(v74),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y74),.z(z74));
always_ff @(posedge clk) begin
if(!rstn)begin vs[74]<=0;ys[74]<=256'd35;zs[74]<=256'd55;end
else begin vs[74]<=v74;if(v74)begin ys[74]<=256'(y74);zs[74]<=256'(z74);end end
end
wire [25:0] y75,z75;wire v75;
w13_full_3 u75(.clk(clk),.rstn(rstn),.iv(iv),.ov(v75),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y75),.z(z75));
always_ff @(posedge clk) begin
if(!rstn)begin vs[75]<=0;ys[75]<=256'd35;zs[75]<=256'd55;end
else begin vs[75]<=v75;if(v75)begin ys[75]<=256'(y75);zs[75]<=256'(z75);end end
end
wire [12:0] y76,z76;wire v76;
w13_low_0 u76(.clk(clk),.rstn(rstn),.iv(iv),.ov(v76),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y76),.z(z76));
always_ff @(posedge clk) begin
if(!rstn)begin vs[76]<=0;ys[76]<=256'd35;zs[76]<=256'd55;end
else begin vs[76]<=v76;if(v76)begin ys[76]<=256'(y76);zs[76]<=256'(z76);end end
end
wire [12:0] y77,z77;wire v77;
w13_low_1 u77(.clk(clk),.rstn(rstn),.iv(iv),.ov(v77),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y77),.z(z77));
always_ff @(posedge clk) begin
if(!rstn)begin vs[77]<=0;ys[77]<=256'd35;zs[77]<=256'd55;end
else begin vs[77]<=v77;if(v77)begin ys[77]<=256'(y77);zs[77]<=256'(z77);end end
end
wire [12:0] y78,z78;wire v78;
w13_low_2 u78(.clk(clk),.rstn(rstn),.iv(iv),.ov(v78),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y78),.z(z78));
always_ff @(posedge clk) begin
if(!rstn)begin vs[78]<=0;ys[78]<=256'd35;zs[78]<=256'd55;end
else begin vs[78]<=v78;if(v78)begin ys[78]<=256'(y78);zs[78]<=256'(z78);end end
end
wire [12:0] y79,z79;wire v79;
w13_low_3 u79(.clk(clk),.rstn(rstn),.iv(iv),.ov(v79),.a(a[12:0]),.b(b[12:0]),.c(c[12:0]),.y(y79),.z(z79));
always_ff @(posedge clk) begin
if(!rstn)begin vs[79]<=0;ys[79]<=256'd35;zs[79]<=256'd55;end
else begin vs[79]<=v79;if(v79)begin ys[79]<=256'(y79);zs[79]<=256'(z79);end end
end
wire [33:0] y80,z80;wire v80;
w17_full_0 u80(.clk(clk),.rstn(rstn),.iv(iv),.ov(v80),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y80),.z(z80));
always_ff @(posedge clk) begin
if(!rstn)begin vs[80]<=0;ys[80]<=256'd35;zs[80]<=256'd55;end
else begin vs[80]<=v80;if(v80)begin ys[80]<=256'(y80);zs[80]<=256'(z80);end end
end
wire [33:0] y81,z81;wire v81;
w17_full_1 u81(.clk(clk),.rstn(rstn),.iv(iv),.ov(v81),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y81),.z(z81));
always_ff @(posedge clk) begin
if(!rstn)begin vs[81]<=0;ys[81]<=256'd35;zs[81]<=256'd55;end
else begin vs[81]<=v81;if(v81)begin ys[81]<=256'(y81);zs[81]<=256'(z81);end end
end
wire [33:0] y82,z82;wire v82;
w17_full_2 u82(.clk(clk),.rstn(rstn),.iv(iv),.ov(v82),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y82),.z(z82));
always_ff @(posedge clk) begin
if(!rstn)begin vs[82]<=0;ys[82]<=256'd35;zs[82]<=256'd55;end
else begin vs[82]<=v82;if(v82)begin ys[82]<=256'(y82);zs[82]<=256'(z82);end end
end
wire [33:0] y83,z83;wire v83;
w17_full_3 u83(.clk(clk),.rstn(rstn),.iv(iv),.ov(v83),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y83),.z(z83));
always_ff @(posedge clk) begin
if(!rstn)begin vs[83]<=0;ys[83]<=256'd35;zs[83]<=256'd55;end
else begin vs[83]<=v83;if(v83)begin ys[83]<=256'(y83);zs[83]<=256'(z83);end end
end
wire [16:0] y84,z84;wire v84;
w17_low_0 u84(.clk(clk),.rstn(rstn),.iv(iv),.ov(v84),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y84),.z(z84));
always_ff @(posedge clk) begin
if(!rstn)begin vs[84]<=0;ys[84]<=256'd35;zs[84]<=256'd55;end
else begin vs[84]<=v84;if(v84)begin ys[84]<=256'(y84);zs[84]<=256'(z84);end end
end
wire [16:0] y85,z85;wire v85;
w17_low_1 u85(.clk(clk),.rstn(rstn),.iv(iv),.ov(v85),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y85),.z(z85));
always_ff @(posedge clk) begin
if(!rstn)begin vs[85]<=0;ys[85]<=256'd35;zs[85]<=256'd55;end
else begin vs[85]<=v85;if(v85)begin ys[85]<=256'(y85);zs[85]<=256'(z85);end end
end
wire [16:0] y86,z86;wire v86;
w17_low_2 u86(.clk(clk),.rstn(rstn),.iv(iv),.ov(v86),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y86),.z(z86));
always_ff @(posedge clk) begin
if(!rstn)begin vs[86]<=0;ys[86]<=256'd35;zs[86]<=256'd55;end
else begin vs[86]<=v86;if(v86)begin ys[86]<=256'(y86);zs[86]<=256'(z86);end end
end
wire [16:0] y87,z87;wire v87;
w17_low_3 u87(.clk(clk),.rstn(rstn),.iv(iv),.ov(v87),.a(a[16:0]),.b(b[16:0]),.c(c[16:0]),.y(y87),.z(z87));
always_ff @(posedge clk) begin
if(!rstn)begin vs[87]<=0;ys[87]<=256'd35;zs[87]<=256'd55;end
else begin vs[87]<=v87;if(v87)begin ys[87]<=256'(y87);zs[87]<=256'(z87);end end
end
endmodule
