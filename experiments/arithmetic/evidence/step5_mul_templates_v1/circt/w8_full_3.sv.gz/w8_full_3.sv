module w8_full_3(	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:1
  input  [7:0]  a,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:25
                b,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:37
                c,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:49
  input         iv,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:61
                rstn,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:74
                clk,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:89
  output        ov,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:104
  output [15:0] y,	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:117
                z	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:1:130
);

  reg         rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:156:21
  wire        _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9
  wire [7:0]  _GEN_0 = {4'h0, a[3:0]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:7:9, :9:9
  wire [7:0]  _GEN_1 = {4'h0, b[3:0]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:12:10, :14:10
  reg  [7:0]  rtlzz_pipe_19_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:17:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:17:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :17:23
      rtlzz_pipe_19_s1 <= 8'h23;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:16:10, :17:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :17:23
      rtlzz_pipe_19_s1 <= iv ? _GEN_0 * _GEN_1 : rtlzz_pipe_19_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:9:9, :14:10, :15:10, :17:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_2 = {4'h0, b[7:4]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:21:10, :23:10
  reg  [11:0] rtlzz_pipe_23_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:28:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:28:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :28:23
      rtlzz_pipe_23_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:28:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :28:23
      rtlzz_pipe_23_s1 <= iv ? {_GEN_0 * _GEN_2, 4'h0} : rtlzz_pipe_23_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:9:9, :23:10, :24:10, :26:10, :28:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_3 = {4'h0, a[7:4]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:29:10, :31:10
  reg  [11:0] rtlzz_pipe_27_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:39:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:39:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :39:23
      rtlzz_pipe_27_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:39:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :39:23
      rtlzz_pipe_27_s1 <= iv ? {_GEN_3 * _GEN_1, 4'h0} : rtlzz_pipe_27_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:14:10, :31:10, :35:10, :37:10, :39:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:50:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:50:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :50:23
      rtlzz_pipe_31_s1 <= 16'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:50:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :50:23
      rtlzz_pipe_31_s1 <= iv ? {_GEN_3 * _GEN_2, 8'h0} : rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:23:10, :31:10, :46:10, :48:10, :50:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:80:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:80:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :80:22
      rtlzz_pipe_4_s2 <= 16'h23;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:79:10, :80:22
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :80:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? {3'h0, {5'h0, rtlzz_pipe_19_s1} + {1'h0, rtlzz_pipe_23_s1}}
            + {4'h0, rtlzz_pipe_27_s1} + rtlzz_pipe_31_s1
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:17:23, :28:23, :39:23, :50:23, :52:10, :54:10, :58:10, :61:10, :63:10, :69:10, :76:10, :80:22, :156:21
  end // always_ff @(posedge)
  wire [7:0]  _GEN_4 = {4'h0, c[3:0]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:86:10, :88:10
  reg  [7:0]  rtlzz_pipe_44_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:91:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:91:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :91:23
      rtlzz_pipe_44_s1 <= 8'h37;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:90:10, :91:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :91:23
      rtlzz_pipe_44_s1 <= iv ? _GEN_0 * _GEN_4 : rtlzz_pipe_44_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:9:9, :88:10, :89:10, :91:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_5 = {4'h0, c[7:4]};	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:95:10, :97:10
  reg  [11:0] rtlzz_pipe_48_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:102:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:102:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :102:23
      rtlzz_pipe_48_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:102:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :102:23
      rtlzz_pipe_48_s1 <= iv ? {_GEN_0 * _GEN_5, 4'h0} : rtlzz_pipe_48_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:9:9, :97:10, :98:10, :100:10, :102:23
  end // always_ff @(posedge)
  reg  [11:0] rtlzz_pipe_52_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:113:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:113:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :113:23
      rtlzz_pipe_52_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:113:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :113:23
      rtlzz_pipe_52_s1 <= iv ? {_GEN_3 * _GEN_4, 4'h0} : rtlzz_pipe_52_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:31:10, :88:10, :109:11, :111:11, :113:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_56_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:124:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:124:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :124:23
      rtlzz_pipe_56_s1 <= 16'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:124:23
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :124:23
      rtlzz_pipe_56_s1 <= iv ? {_GEN_3 * _GEN_5, 8'h0} : rtlzz_pipe_56_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:31:10, :97:10, :120:11, :122:11, :124:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:154:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:154:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :154:22
      rtlzz_pipe_5_s2 <= 16'h37;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:153:11, :154:22
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :154:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? {3'h0, {5'h0, rtlzz_pipe_44_s1} + {1'h0, rtlzz_pipe_48_s1}}
            + {4'h0, rtlzz_pipe_52_s1} + rtlzz_pipe_56_s1
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:91:23, :102:23, :113:23, :124:23, :126:11, :128:11, :132:11, :135:11, :137:11, :143:11, :150:11, :154:22, :156:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:156:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :156:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:156:21
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :156:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:156:21
  end // always_ff @(posedge)
  reg         rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:158:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:158:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :158:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:158:21
    else	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:4:9, :158:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:156:21, :158:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:158:21, :159:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:80:22, :159:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002828223706963/input.mlir:154:22, :159:3
endmodule
