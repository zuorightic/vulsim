module w8_full_2(	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:1
  input  [7:0]  a,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:25
                b,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:37
                c,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:49
  input         iv,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:61
                rstn,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:74
                clk,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:89
  output        ov,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:104
  output [15:0] y,	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:117
                z	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:1:130
);

  reg         rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:588:21
  wire        _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9
  wire [3:0]  _GEN_0 = {2'h0, a[1:0]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:9:9, :337:11
  wire [3:0]  _GEN_1 = {2'h0, b[1:0]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:14:10, :184:11
  wire [3:0]  _GEN_2 = {2'h0, b[3:2]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:23:10, :195:11
  reg  [6:0]  rtlzz_pipe_82_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:35:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:35:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :35:23
      rtlzz_pipe_82_s1 <= 7'h7;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:34:10, :35:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :35:23
      rtlzz_pipe_82_s1 <=
        iv ? {1'h0, {2'h0, _GEN_0 * _GEN_1} + {_GEN_0 * _GEN_2, 2'h0}} : rtlzz_pipe_82_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:9:9, :14:10, :15:10, :23:10, :24:10, :32:10, :35:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_3 = {2'h0, b[5:4]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:41:10, :213:11
  wire [3:0]  _GEN_4 = {2'h0, b[7:6]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:52:10, :224:11
  reg  [10:0] rtlzz_pipe_85_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:64:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:64:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :64:23
      rtlzz_pipe_85_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:64:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :64:23
      rtlzz_pipe_85_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_3, 4'h0} + {_GEN_0 * _GEN_4, 6'h0}}
          : rtlzz_pipe_85_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:9:9, :41:10, :42:10, :52:10, :53:10, :61:10, :64:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_5 = {2'h0, a[3:2]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:67:10, :395:11
  reg  [8:0]  rtlzz_pipe_88_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:93:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:93:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :93:23
      rtlzz_pipe_88_s1 <= 9'h1C;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:92:10, :93:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :93:23
      rtlzz_pipe_88_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_1, 2'h0} + {_GEN_5 * _GEN_2, 4'h0}}
          : rtlzz_pipe_88_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:14:10, :23:10, :67:10, :71:10, :82:10, :90:10, :93:23
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_91_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:122:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:122:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :122:23
      rtlzz_pipe_91_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:122:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :122:23
      rtlzz_pipe_91_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_3, 6'h0} + {_GEN_5 * _GEN_4, 8'h0}}
          : rtlzz_pipe_91_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:41:10, :52:10, :67:10, :100:10, :111:11, :119:11, :122:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_6 = {2'h0, a[5:4]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:125:11, :453:11
  reg  [10:0] rtlzz_pipe_94_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:151:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:151:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :151:23
      rtlzz_pipe_94_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:151:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :151:23
      rtlzz_pipe_94_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_1, 4'h0} + {_GEN_6 * _GEN_2, 6'h0}}
          : rtlzz_pipe_94_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:14:10, :23:10, :125:11, :129:11, :140:11, :148:11, :151:23
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_97_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:180:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:180:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :180:23
      rtlzz_pipe_97_s1 <= 15'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:180:23
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :180:23
      rtlzz_pipe_97_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_3, 8'h0} + {_GEN_6 * _GEN_4, 10'h0}}
          : rtlzz_pipe_97_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:41:10, :52:10, :125:11, :158:11, :169:11, :177:11, :180:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_7 = {2'h0, a[7:6]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:183:11, :511:11
  reg  [12:0] rtlzz_pipe_100_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:209:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:209:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :209:24
      rtlzz_pipe_100_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:209:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :209:24
      rtlzz_pipe_100_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_1, 6'h0} + {_GEN_7 * _GEN_2, 8'h0}}
          : rtlzz_pipe_100_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:14:10, :23:10, :183:11, :187:11, :198:11, :206:11, :209:24
  end // always_ff @(posedge)
  reg  [16:0] rtlzz_pipe_103_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:238:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:238:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :238:24
      rtlzz_pipe_103_s1 <= 17'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:238:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :238:24
      rtlzz_pipe_103_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_3, 10'h0} + {_GEN_7 * _GEN_4, 12'h0}}
          : rtlzz_pipe_103_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:41:10, :52:10, :183:11, :216:11, :227:11, :235:11, :238:24
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_118_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:267:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:267:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :267:24
      rtlzz_pipe_118_s2 <= 15'h23;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:266:11, :267:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :267:24
      rtlzz_pipe_118_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_82_s1} + {1'h0, rtlzz_pipe_85_s1}}
               + {5'h0, rtlzz_pipe_88_s1} + {1'h0, rtlzz_pipe_91_s1}}
          : rtlzz_pipe_118_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:35:23, :64:23, :93:23, :122:23, :240:11, :242:11, :246:11, :251:11, :253:11, :257:11, :264:11, :267:24, :588:21
  end // always_ff @(posedge)
  reg  [18:0] rtlzz_pipe_121_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:296:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:296:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :296:24
      rtlzz_pipe_121_s2 <= 19'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:296:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :296:24
      rtlzz_pipe_121_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_94_s1} + {1'h0, rtlzz_pipe_97_s1}}
               + {5'h0, rtlzz_pipe_100_s1} + {1'h0, rtlzz_pipe_103_s1}}
          : rtlzz_pipe_121_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:151:23, :180:23, :209:24, :238:24, :269:11, :271:11, :275:11, :280:11, :282:11, :286:11, :293:11, :296:24, :588:21
  end // always_ff @(posedge)
  wire [3:0]  _GEN_8 = {2'h0, c[1:0]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:304:11, :474:11
  wire [3:0]  _GEN_9 = {2'h0, c[3:2]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:313:11, :485:11
  reg  [6:0]  rtlzz_pipe_191_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:325:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:325:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :325:24
      rtlzz_pipe_191_s1 <= 7'hB;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:324:11, :325:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :325:24
      rtlzz_pipe_191_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_8} + {_GEN_0 * _GEN_9, 2'h0}}
          : rtlzz_pipe_191_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:9:9, :304:11, :305:11, :313:11, :314:11, :322:11, :325:24
  end // always_ff @(posedge)
  wire [3:0]  _GEN_10 = {2'h0, c[5:4]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:331:11, :503:11
  wire [3:0]  _GEN_11 = {2'h0, c[7:6]};	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:342:11, :514:11
  reg  [10:0] rtlzz_pipe_194_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:354:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:354:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :354:24
      rtlzz_pipe_194_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:354:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :354:24
      rtlzz_pipe_194_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_10, 4'h0} + {_GEN_0 * _GEN_11, 6'h0}}
          : rtlzz_pipe_194_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:9:9, :331:11, :332:11, :342:11, :343:11, :351:11, :354:24
  end // always_ff @(posedge)
  reg  [8:0]  rtlzz_pipe_197_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:383:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:383:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :383:24
      rtlzz_pipe_197_s1 <= 9'h2C;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:382:11, :383:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :383:24
      rtlzz_pipe_197_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_8, 2'h0} + {_GEN_5 * _GEN_9, 4'h0}}
          : rtlzz_pipe_197_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:67:10, :304:11, :313:11, :361:11, :372:11, :380:11, :383:24
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_200_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:412:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:412:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :412:24
      rtlzz_pipe_200_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:412:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :412:24
      rtlzz_pipe_200_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_10, 6'h0} + {_GEN_5 * _GEN_11, 8'h0}}
          : rtlzz_pipe_200_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:67:10, :331:11, :342:11, :390:11, :401:11, :409:11, :412:24
  end // always_ff @(posedge)
  reg  [10:0] rtlzz_pipe_203_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:441:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:441:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :441:24
      rtlzz_pipe_203_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:441:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :441:24
      rtlzz_pipe_203_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_8, 4'h0} + {_GEN_6 * _GEN_9, 6'h0}}
          : rtlzz_pipe_203_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:125:11, :304:11, :313:11, :419:11, :430:11, :438:11, :441:24
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_206_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:470:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:470:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :470:24
      rtlzz_pipe_206_s1 <= 15'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:470:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :470:24
      rtlzz_pipe_206_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_10, 8'h0} + {_GEN_6 * _GEN_11, 10'h0}}
          : rtlzz_pipe_206_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:125:11, :331:11, :342:11, :448:11, :459:11, :467:11, :470:24
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_209_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:499:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:499:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :499:24
      rtlzz_pipe_209_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:499:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :499:24
      rtlzz_pipe_209_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_8, 6'h0} + {_GEN_7 * _GEN_9, 8'h0}}
          : rtlzz_pipe_209_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:183:11, :304:11, :313:11, :477:11, :488:11, :496:11, :499:24
  end // always_ff @(posedge)
  reg  [16:0] rtlzz_pipe_212_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:528:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:528:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :528:24
      rtlzz_pipe_212_s1 <= 17'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:528:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :528:24
      rtlzz_pipe_212_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_10, 10'h0} + {_GEN_7 * _GEN_11, 12'h0}}
          : rtlzz_pipe_212_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:183:11, :331:11, :342:11, :506:11, :517:11, :525:11, :528:24
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_227_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:557:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:557:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :557:24
      rtlzz_pipe_227_s2 <= 15'h37;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:556:11, :557:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :557:24
      rtlzz_pipe_227_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_191_s1} + {1'h0, rtlzz_pipe_194_s1}}
               + {5'h0, rtlzz_pipe_197_s1} + {1'h0, rtlzz_pipe_200_s1}}
          : rtlzz_pipe_227_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:325:24, :354:24, :383:24, :412:24, :530:11, :532:11, :536:11, :541:11, :543:11, :547:11, :554:11, :557:24, :588:21
  end // always_ff @(posedge)
  reg  [18:0] rtlzz_pipe_230_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:586:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:586:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :586:24
      rtlzz_pipe_230_s2 <= 19'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:586:24
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :586:24
      rtlzz_pipe_230_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_203_s1} + {1'h0, rtlzz_pipe_206_s1}}
               + {5'h0, rtlzz_pipe_209_s1} + {1'h0, rtlzz_pipe_212_s1}}
          : rtlzz_pipe_230_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:441:24, :470:24, :499:24, :528:24, :559:11, :561:11, :565:11, :570:11, :572:11, :576:11, :583:11, :586:24, :588:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:588:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :588:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:588:21
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :588:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:588:21
  end // always_ff @(posedge)
  reg         rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:590:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:590:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :590:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:590:21
    else	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:4:9, :590:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:588:21, :590:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:590:21, :611:3
  assign y = {1'h0, rtlzz_pipe_118_s2} + rtlzz_pipe_121_s2[15:0];	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:267:24, :296:24, :592:11, :594:11, :598:11, :611:3
  assign z = {1'h0, rtlzz_pipe_227_s2} + rtlzz_pipe_230_s2[15:0];	// /tmp/rtlzz-circt-7-2002827815913707/input.mlir:557:24, :586:24, :602:11, :604:11, :608:11, :611:3
endmodule
