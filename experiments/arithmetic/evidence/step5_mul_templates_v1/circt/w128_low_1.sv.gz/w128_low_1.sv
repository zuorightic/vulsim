module w128_low_1(	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:1
  input  [127:0] a,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:26
                 b,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:40
                 c,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:54
  input          iv,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:68
                 rstn,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:81
                 clk,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:96
  output         ov,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:111
  output [127:0] y,	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:124
                 z	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:1:138
);

  reg          rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:142:21
  wire         _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9
  wire [127:0] _GEN_0 = {64'h0, a[63:0]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:5:9, :7:9
  wire [127:0] _GEN_1 = {64'h0, b[63:0]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:8:9, :10:9
  wire [127:0] _GEN_2 = {64'h0, b[127:64]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:17:10, :19:10
  reg  [192:0] rtlzz_pipe_28_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:31:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:31:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :31:23
      rtlzz_pipe_28_s1 <= 193'h23;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:30:10, :31:23
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :31:23
      rtlzz_pipe_28_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_0 * _GEN_1} + {_GEN_0 * _GEN_2, 64'h0}}
          : rtlzz_pipe_28_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:7:9, :10:9, :11:9, :19:10, :20:10, :28:10, :31:23
  end // always_ff @(posedge)
  wire [127:0] _GEN_3 = {64'h0, a[127:64]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:32:10, :34:10
  reg  [256:0] rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:60:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:60:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :60:23
      rtlzz_pipe_31_s1 <= 257'h0;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:60:23
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :60:23
      rtlzz_pipe_31_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_3 * _GEN_1, 64'h0} + {_GEN_3 * _GEN_2, 128'h0}}
          : rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:10:9, :19:10, :34:10, :38:10, :49:10, :57:10, :60:23
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:72:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:72:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :72:22
      rtlzz_pipe_4_s2 <= 128'h23;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:71:10, :72:22
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :72:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? rtlzz_pipe_28_s1[127:0] + rtlzz_pipe_31_s1[127:0]
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:31:23, :60:23, :62:10, :64:10, :68:10, :72:22, :142:21
  end // always_ff @(posedge)
  wire [127:0] _GEN_4 = {64'h0, c[63:0]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:76:10, :78:10
  wire [127:0] _GEN_5 = {64'h0, c[127:64]};	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:85:10, :87:10
  reg  [192:0] rtlzz_pipe_53_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:99:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:99:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :99:23
      rtlzz_pipe_53_s1 <= 193'h37;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:98:10, :99:23
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :99:23
      rtlzz_pipe_53_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_0 * _GEN_4} + {_GEN_0 * _GEN_5, 64'h0}}
          : rtlzz_pipe_53_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:7:9, :78:10, :79:10, :87:10, :88:10, :96:10, :99:23
  end // always_ff @(posedge)
  reg  [256:0] rtlzz_pipe_56_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:128:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:128:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :128:23
      rtlzz_pipe_56_s1 <= 257'h0;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:128:23
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :128:23
      rtlzz_pipe_56_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_3 * _GEN_4, 64'h0} + {_GEN_3 * _GEN_5, 128'h0}}
          : rtlzz_pipe_56_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:34:10, :78:10, :87:10, :106:11, :117:11, :125:11, :128:23
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:140:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:140:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :140:22
      rtlzz_pipe_5_s2 <= 128'h37;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:139:11, :140:22
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :140:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? rtlzz_pipe_53_s1[127:0] + rtlzz_pipe_56_s1[127:0]
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:99:23, :128:23, :130:11, :132:11, :136:11, :140:22, :142:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:142:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :142:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:142:21
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :142:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:142:21
  end // always_ff @(posedge)
  reg          rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:144:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:144:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :144:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:144:21
    else	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:4:9, :144:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:142:21, :144:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:144:21, :145:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:72:22, :145:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830881924321/input.mlir:140:22, :145:3
endmodule
