module w8_low_3(	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:1
  input  [7:0] a,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:24
               b,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:36
               c,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:48
  input        iv,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:60
               rstn,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:73
               clk,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:88
  output       ov,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:103
  output [7:0] y,	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:116
               z	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:1:128
);

  reg         rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:150:21
  wire        _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9
  wire [7:0]  _GEN_0 = {4'h0, a[3:0]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:5:9, :7:9
  wire [7:0]  _GEN_1 = {4'h0, b[3:0]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:8:9, :10:9
  reg  [7:0]  rtlzz_pipe_13_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:13:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:13:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :13:23
      rtlzz_pipe_13_s1 <= 8'h23;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:13:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :13:23
      rtlzz_pipe_13_s1 <= iv ? _GEN_0 * _GEN_1 : rtlzz_pipe_13_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:7:9, :10:9, :11:9, :13:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_2 = {4'h0, b[7:4]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:17:10, :19:10
  reg  [11:0] rtlzz_pipe_17_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:24:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:24:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :24:23
      rtlzz_pipe_17_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:24:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :24:23
      rtlzz_pipe_17_s1 <= iv ? {_GEN_0 * _GEN_2, 4'h0} : rtlzz_pipe_17_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:7:9, :19:10, :20:10, :22:10, :24:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_3 = {4'h0, a[7:4]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:25:10, :27:10
  reg  [11:0] rtlzz_pipe_21_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:35:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:35:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :35:23
      rtlzz_pipe_21_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:35:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :35:23
      rtlzz_pipe_21_s1 <= iv ? {_GEN_3 * _GEN_1, 4'h0} : rtlzz_pipe_21_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:10:9, :27:10, :31:10, :33:10, :35:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_25_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:46:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:46:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :46:23
      rtlzz_pipe_25_s1 <= 16'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:46:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :46:23
      rtlzz_pipe_25_s1 <= iv ? {_GEN_3 * _GEN_2, 8'h0} : rtlzz_pipe_25_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:19:10, :27:10, :42:10, :44:10, :46:23
  end // always_ff @(posedge)
  reg  [7:0]  rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:76:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:76:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :76:22
      rtlzz_pipe_4_s2 <= 8'h23;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:76:22
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :76:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? rtlzz_pipe_13_s1 + rtlzz_pipe_17_s1[7:0] + rtlzz_pipe_21_s1[7:0]
            + rtlzz_pipe_25_s1[7:0]
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:13:23, :24:23, :35:23, :46:23, :50:10, :54:10, :59:10, :61:10, :65:10, :72:10, :76:22, :150:21
  end // always_ff @(posedge)
  wire [7:0]  _GEN_4 = {4'h0, c[3:0]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:80:10, :82:10
  reg  [7:0]  rtlzz_pipe_38_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:85:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:85:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :85:23
      rtlzz_pipe_38_s1 <= 8'h37;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:85:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :85:23
      rtlzz_pipe_38_s1 <= iv ? _GEN_0 * _GEN_4 : rtlzz_pipe_38_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:7:9, :82:10, :83:10, :85:23
  end // always_ff @(posedge)
  wire [7:0]  _GEN_5 = {4'h0, c[7:4]};	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:89:10, :91:10
  reg  [11:0] rtlzz_pipe_42_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:96:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:96:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :96:23
      rtlzz_pipe_42_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:96:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :96:23
      rtlzz_pipe_42_s1 <= iv ? {_GEN_0 * _GEN_5, 4'h0} : rtlzz_pipe_42_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:7:9, :91:10, :92:10, :94:10, :96:23
  end // always_ff @(posedge)
  reg  [11:0] rtlzz_pipe_46_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:107:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:107:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :107:23
      rtlzz_pipe_46_s1 <= 12'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:107:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :107:23
      rtlzz_pipe_46_s1 <= iv ? {_GEN_3 * _GEN_4, 4'h0} : rtlzz_pipe_46_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:27:10, :82:10, :103:10, :105:10, :107:23
  end // always_ff @(posedge)
  reg  [15:0] rtlzz_pipe_50_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:118:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:118:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :118:23
      rtlzz_pipe_50_s1 <= 16'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:118:23
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :118:23
      rtlzz_pipe_50_s1 <= iv ? {_GEN_3 * _GEN_5, 8'h0} : rtlzz_pipe_50_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:27:10, :91:10, :114:11, :116:11, :118:23
  end // always_ff @(posedge)
  reg  [7:0]  rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:148:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:148:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :148:22
      rtlzz_pipe_5_s2 <= 8'h37;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:148:22
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :148:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? rtlzz_pipe_38_s1 + rtlzz_pipe_42_s1[7:0] + rtlzz_pipe_46_s1[7:0]
            + rtlzz_pipe_50_s1[7:0]
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:85:23, :96:23, :107:23, :118:23, :122:11, :126:11, :131:11, :133:11, :137:11, :144:11, :148:22, :150:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:150:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :150:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:150:21
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :150:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:150:21
  end // always_ff @(posedge)
  reg         rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:152:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:152:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :152:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:152:21
    else	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:4:9, :152:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:150:21, :152:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:152:21, :153:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:76:22, :153:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829350226441/input.mlir:148:22, :153:3
endmodule
