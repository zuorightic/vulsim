module w128_full_3(	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:1
  input  [127:0] a,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:27
                 b,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:41
                 c,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:55
  input          iv,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:69
                 rstn,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:82
                 clk,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:97
  output         ov,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:112
  output [255:0] y,	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:125
                 z	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:1:139
);

  reg          rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:636:21
  wire         _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9
  wire [63:0]  _GEN_0 = {32'h0, a[31:0]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :354:11
  wire [63:0]  _GEN_1 = {32'h0, b[31:0]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:14:10, :142:11
  reg  [63:0]  rtlzz_pipe_19_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:17:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:17:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :17:23
      rtlzz_pipe_19_s1 <= 64'h23;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:16:10, :17:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :17:23
      rtlzz_pipe_19_s1 <= iv ? _GEN_0 * _GEN_1 : rtlzz_pipe_19_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :14:10, :15:10, :17:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_2 = {32'h0, b[63:32]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:23:10, :153:11
  reg  [95:0]  rtlzz_pipe_23_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:28:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:28:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :28:23
      rtlzz_pipe_23_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:28:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :28:23
      rtlzz_pipe_23_s1 <= iv ? {_GEN_0 * _GEN_2, 32'h0} : rtlzz_pipe_23_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :23:10, :24:10, :26:10, :28:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_3 = {32'h0, b[95:64]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:34:10, :164:11
  reg  [127:0] rtlzz_pipe_27_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:39:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:39:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :39:23
      rtlzz_pipe_27_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:39:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :39:23
      rtlzz_pipe_27_s1 <= iv ? {_GEN_0 * _GEN_3, 64'h0} : rtlzz_pipe_27_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :34:10, :35:10, :37:10, :39:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_4 = {32'h0, b[127:96]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:45:10, :175:11
  reg  [159:0] rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:50:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:50:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :50:23
      rtlzz_pipe_31_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:50:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :50:23
      rtlzz_pipe_31_s1 <= iv ? {_GEN_0 * _GEN_4, 96'h0} : rtlzz_pipe_31_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :45:10, :46:10, :48:10, :50:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_5 = {32'h0, a[63:32]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:53:10, :398:11
  reg  [95:0]  rtlzz_pipe_35_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:61:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:61:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :61:23
      rtlzz_pipe_35_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:61:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :61:23
      rtlzz_pipe_35_s1 <= iv ? {_GEN_5 * _GEN_1, 32'h0} : rtlzz_pipe_35_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:14:10, :53:10, :57:10, :59:10, :61:23
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_39_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:72:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:72:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :72:23
      rtlzz_pipe_39_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:72:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :72:23
      rtlzz_pipe_39_s1 <= iv ? {_GEN_5 * _GEN_2, 64'h0} : rtlzz_pipe_39_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:23:10, :53:10, :68:10, :70:10, :72:23
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_43_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:83:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:83:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :83:23
      rtlzz_pipe_43_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:83:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :83:23
      rtlzz_pipe_43_s1 <= iv ? {_GEN_5 * _GEN_3, 96'h0} : rtlzz_pipe_43_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:34:10, :53:10, :79:10, :81:10, :83:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_47_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:94:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:94:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :94:23
      rtlzz_pipe_47_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:94:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :94:23
      rtlzz_pipe_47_s1 <= iv ? {_GEN_5 * _GEN_4, 128'h0} : rtlzz_pipe_47_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:45:10, :53:10, :90:10, :92:10, :94:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_6 = {32'h0, a[95:64]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:97:10, :442:11
  reg  [127:0] rtlzz_pipe_51_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:105:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:105:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :105:23
      rtlzz_pipe_51_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:105:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :105:23
      rtlzz_pipe_51_s1 <= iv ? {_GEN_6 * _GEN_1, 64'h0} : rtlzz_pipe_51_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:14:10, :97:10, :101:10, :103:10, :105:23
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_55_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:116:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:116:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :116:23
      rtlzz_pipe_55_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:116:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :116:23
      rtlzz_pipe_55_s1 <= iv ? {_GEN_6 * _GEN_2, 96'h0} : rtlzz_pipe_55_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:23:10, :97:10, :112:11, :114:11, :116:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_59_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:127:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:127:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :127:23
      rtlzz_pipe_59_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:127:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :127:23
      rtlzz_pipe_59_s1 <= iv ? {_GEN_6 * _GEN_3, 128'h0} : rtlzz_pipe_59_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:34:10, :97:10, :123:11, :125:11, :127:23
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_63_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:138:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:138:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :138:23
      rtlzz_pipe_63_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:138:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :138:23
      rtlzz_pipe_63_s1 <= iv ? {_GEN_6 * _GEN_4, 160'h0} : rtlzz_pipe_63_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:45:10, :97:10, :134:11, :136:11, :138:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_7 = {32'h0, a[127:96]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:141:11, :486:11
  reg  [159:0] rtlzz_pipe_67_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:149:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:149:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :149:23
      rtlzz_pipe_67_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:149:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :149:23
      rtlzz_pipe_67_s1 <= iv ? {_GEN_7 * _GEN_1, 96'h0} : rtlzz_pipe_67_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:14:10, :141:11, :145:11, :147:11, :149:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_71_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:160:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:160:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :160:23
      rtlzz_pipe_71_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:160:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :160:23
      rtlzz_pipe_71_s1 <= iv ? {_GEN_7 * _GEN_2, 128'h0} : rtlzz_pipe_71_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:23:10, :141:11, :156:11, :158:11, :160:23
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_75_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:171:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:171:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :171:23
      rtlzz_pipe_75_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:171:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :171:23
      rtlzz_pipe_75_s1 <= iv ? {_GEN_7 * _GEN_3, 160'h0} : rtlzz_pipe_75_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:34:10, :141:11, :167:11, :169:11, :171:23
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_79_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:182:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:182:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :182:23
      rtlzz_pipe_79_s1 <= 256'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:182:23
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :182:23
      rtlzz_pipe_79_s1 <= iv ? {_GEN_7 * _GEN_4, 192'h0} : rtlzz_pipe_79_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:45:10, :141:11, :178:11, :180:11, :182:23
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:320:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:320:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :320:22
      rtlzz_pipe_4_s2 <= 256'h23;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:319:11, :320:22
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :320:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? {63'h0,
             {32'h0,
              {64'h0, {33'h0, rtlzz_pipe_19_s1} + {1'h0, rtlzz_pipe_23_s1}}
                + {33'h0, rtlzz_pipe_27_s1} + {1'h0, rtlzz_pipe_31_s1}}
               + {64'h0, {33'h0, rtlzz_pipe_35_s1} + {1'h0, rtlzz_pipe_39_s1}}
               + {33'h0, rtlzz_pipe_43_s1} + {1'h0, rtlzz_pipe_47_s1}}
            + {31'h0,
               {64'h0, {33'h0, rtlzz_pipe_51_s1} + {1'h0, rtlzz_pipe_55_s1}}
                 + {33'h0, rtlzz_pipe_59_s1} + {1'h0, rtlzz_pipe_63_s1}}
            + {63'h0, {33'h0, rtlzz_pipe_67_s1} + {1'h0, rtlzz_pipe_71_s1}}
            + {32'h0, rtlzz_pipe_75_s1} + rtlzz_pipe_79_s1
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:17:23, :28:23, :39:23, :50:23, :61:23, :72:23, :83:23, :94:23, :105:23, :116:23, :127:23, :138:23, :149:23, :160:23, :171:23, :182:23, :184:11, :186:11, :190:11, :195:11, :197:11, :201:11, :208:11, :213:11, :215:11, :219:11, :224:11, :226:11, :230:11, :237:11, :244:11, :247:11, :249:11, :251:11, :255:11, :260:11, :262:11, :266:11, :273:11, :276:11, :278:11, :280:11, :284:11, :287:11, :289:11, :295:11, :302:11, :309:11, :316:11, :320:22, :636:21
  end // always_ff @(posedge)
  wire [63:0]  _GEN_8 = {32'h0, c[31:0]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:328:11, :456:11
  reg  [63:0]  rtlzz_pipe_128_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:331:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:331:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :331:24
      rtlzz_pipe_128_s1 <= 64'h37;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:330:11, :331:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :331:24
      rtlzz_pipe_128_s1 <= iv ? _GEN_0 * _GEN_8 : rtlzz_pipe_128_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :328:11, :329:11, :331:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_9 = {32'h0, c[63:32]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:337:11, :467:11
  reg  [95:0]  rtlzz_pipe_132_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:342:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:342:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :342:24
      rtlzz_pipe_132_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:342:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :342:24
      rtlzz_pipe_132_s1 <= iv ? {_GEN_0 * _GEN_9, 32'h0} : rtlzz_pipe_132_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :337:11, :338:11, :340:11, :342:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_10 = {32'h0, c[95:64]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:348:11, :478:11
  reg  [127:0] rtlzz_pipe_136_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:353:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:353:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :353:24
      rtlzz_pipe_136_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:353:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :353:24
      rtlzz_pipe_136_s1 <= iv ? {_GEN_0 * _GEN_10, 64'h0} : rtlzz_pipe_136_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :348:11, :349:11, :351:11, :353:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_11 = {32'h0, c[127:96]};	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:359:11, :489:11
  reg  [159:0] rtlzz_pipe_140_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:364:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:364:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :364:24
      rtlzz_pipe_140_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:364:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :364:24
      rtlzz_pipe_140_s1 <= iv ? {_GEN_0 * _GEN_11, 96'h0} : rtlzz_pipe_140_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:9:9, :359:11, :360:11, :362:11, :364:24
  end // always_ff @(posedge)
  reg  [95:0]  rtlzz_pipe_144_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:375:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:375:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :375:24
      rtlzz_pipe_144_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:375:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :375:24
      rtlzz_pipe_144_s1 <= iv ? {_GEN_5 * _GEN_8, 32'h0} : rtlzz_pipe_144_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:53:10, :328:11, :371:11, :373:11, :375:24
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_148_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:386:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:386:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :386:24
      rtlzz_pipe_148_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:386:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :386:24
      rtlzz_pipe_148_s1 <= iv ? {_GEN_5 * _GEN_9, 64'h0} : rtlzz_pipe_148_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:53:10, :337:11, :382:11, :384:11, :386:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_152_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:397:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:397:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :397:24
      rtlzz_pipe_152_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:397:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :397:24
      rtlzz_pipe_152_s1 <= iv ? {_GEN_5 * _GEN_10, 96'h0} : rtlzz_pipe_152_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:53:10, :348:11, :393:11, :395:11, :397:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_156_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:408:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:408:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :408:24
      rtlzz_pipe_156_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:408:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :408:24
      rtlzz_pipe_156_s1 <= iv ? {_GEN_5 * _GEN_11, 128'h0} : rtlzz_pipe_156_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:53:10, :359:11, :404:11, :406:11, :408:24
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_160_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:419:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:419:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :419:24
      rtlzz_pipe_160_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:419:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :419:24
      rtlzz_pipe_160_s1 <= iv ? {_GEN_6 * _GEN_8, 64'h0} : rtlzz_pipe_160_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:97:10, :328:11, :415:11, :417:11, :419:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_164_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:430:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:430:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :430:24
      rtlzz_pipe_164_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:430:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :430:24
      rtlzz_pipe_164_s1 <= iv ? {_GEN_6 * _GEN_9, 96'h0} : rtlzz_pipe_164_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:97:10, :337:11, :426:11, :428:11, :430:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_168_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:441:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:441:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :441:24
      rtlzz_pipe_168_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:441:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :441:24
      rtlzz_pipe_168_s1 <= iv ? {_GEN_6 * _GEN_10, 128'h0} : rtlzz_pipe_168_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:97:10, :348:11, :437:11, :439:11, :441:24
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_172_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:452:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:452:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :452:24
      rtlzz_pipe_172_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:452:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :452:24
      rtlzz_pipe_172_s1 <= iv ? {_GEN_6 * _GEN_11, 160'h0} : rtlzz_pipe_172_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:97:10, :359:11, :448:11, :450:11, :452:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_176_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:463:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:463:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :463:24
      rtlzz_pipe_176_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:463:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :463:24
      rtlzz_pipe_176_s1 <= iv ? {_GEN_7 * _GEN_8, 96'h0} : rtlzz_pipe_176_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:141:11, :328:11, :459:11, :461:11, :463:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_180_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:474:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:474:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :474:24
      rtlzz_pipe_180_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:474:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :474:24
      rtlzz_pipe_180_s1 <= iv ? {_GEN_7 * _GEN_9, 128'h0} : rtlzz_pipe_180_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:141:11, :337:11, :470:11, :472:11, :474:24
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_184_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:485:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:485:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :485:24
      rtlzz_pipe_184_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:485:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :485:24
      rtlzz_pipe_184_s1 <= iv ? {_GEN_7 * _GEN_10, 160'h0} : rtlzz_pipe_184_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:141:11, :348:11, :481:11, :483:11, :485:24
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_188_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:496:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:496:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :496:24
      rtlzz_pipe_188_s1 <= 256'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:496:24
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :496:24
      rtlzz_pipe_188_s1 <= iv ? {_GEN_7 * _GEN_11, 192'h0} : rtlzz_pipe_188_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:141:11, :359:11, :492:11, :494:11, :496:24
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:634:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:634:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :634:22
      rtlzz_pipe_5_s2 <= 256'h37;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:633:11, :634:22
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :634:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? {63'h0,
             {32'h0,
              {64'h0, {33'h0, rtlzz_pipe_128_s1} + {1'h0, rtlzz_pipe_132_s1}}
                + {33'h0, rtlzz_pipe_136_s1} + {1'h0, rtlzz_pipe_140_s1}}
               + {64'h0, {33'h0, rtlzz_pipe_144_s1} + {1'h0, rtlzz_pipe_148_s1}}
               + {33'h0, rtlzz_pipe_152_s1} + {1'h0, rtlzz_pipe_156_s1}}
            + {31'h0,
               {64'h0, {33'h0, rtlzz_pipe_160_s1} + {1'h0, rtlzz_pipe_164_s1}}
                 + {33'h0, rtlzz_pipe_168_s1} + {1'h0, rtlzz_pipe_172_s1}}
            + {63'h0, {33'h0, rtlzz_pipe_176_s1} + {1'h0, rtlzz_pipe_180_s1}}
            + {32'h0, rtlzz_pipe_184_s1} + rtlzz_pipe_188_s1
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:331:24, :342:24, :353:24, :364:24, :375:24, :386:24, :397:24, :408:24, :419:24, :430:24, :441:24, :452:24, :463:24, :474:24, :485:24, :496:24, :498:11, :500:11, :504:11, :509:11, :511:11, :515:11, :522:11, :527:11, :529:11, :533:11, :538:11, :540:11, :544:11, :551:11, :558:11, :561:11, :563:11, :565:11, :569:11, :574:11, :576:11, :580:11, :587:11, :590:11, :592:11, :594:11, :598:11, :601:11, :603:11, :609:11, :616:11, :623:11, :630:11, :634:22, :636:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:636:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :636:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:636:21
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :636:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:636:21
  end // always_ff @(posedge)
  reg          rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:638:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:638:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :638:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:638:21
    else	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:4:9, :638:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:636:21, :638:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:638:21, :639:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:320:22, :639:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002830496032600/input.mlir:634:22, :639:3
endmodule
