module w8_low_2(	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:1
  input  [7:0] a,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:24
               b,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:36
               c,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:48
  input        iv,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:60
               rstn,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:73
               clk,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:88
  output       ov,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:103
  output [7:0] y,	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:116
               z	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:1:128
);

  reg         rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:582:21
  wire        _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9
  wire [3:0]  _GEN_0 = {2'h0, a[1:0]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:5:9, :7:9
  wire [3:0]  _GEN_1 = {2'h0, b[1:0]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:8:9, :10:9
  wire [3:0]  _GEN_2 = {2'h0, b[3:2]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:17:10, :19:10
  reg  [6:0]  rtlzz_pipe_76_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:31:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:31:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :31:23
      rtlzz_pipe_76_s1 <= 7'h7;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:30:10, :31:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :31:23
      rtlzz_pipe_76_s1 <=
        iv ? {1'h0, {2'h0, _GEN_0 * _GEN_1} + {_GEN_0 * _GEN_2, 2'h0}} : rtlzz_pipe_76_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:7:9, :10:9, :11:9, :19:10, :20:10, :28:10, :31:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_3 = {2'h0, b[5:4]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:35:10, :37:10
  wire [3:0]  _GEN_4 = {2'h0, b[7:6]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:46:10, :48:10
  reg  [10:0] rtlzz_pipe_79_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:60:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:60:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :60:23
      rtlzz_pipe_79_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:60:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :60:23
      rtlzz_pipe_79_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_3, 4'h0} + {_GEN_0 * _GEN_4, 6'h0}}
          : rtlzz_pipe_79_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:7:9, :37:10, :38:10, :48:10, :49:10, :57:10, :60:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_5 = {2'h0, a[3:2]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:61:10, :63:10
  reg  [8:0]  rtlzz_pipe_82_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:89:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:89:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :89:23
      rtlzz_pipe_82_s1 <= 9'h1C;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:88:10, :89:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :89:23
      rtlzz_pipe_82_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_1, 2'h0} + {_GEN_5 * _GEN_2, 4'h0}}
          : rtlzz_pipe_82_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:10:9, :19:10, :63:10, :67:10, :78:10, :86:10, :89:23
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_85_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:118:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:118:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :118:23
      rtlzz_pipe_85_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:118:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :118:23
      rtlzz_pipe_85_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_3, 6'h0} + {_GEN_5 * _GEN_4, 8'h0}}
          : rtlzz_pipe_85_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:37:10, :48:10, :63:10, :96:10, :107:11, :115:11, :118:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_6 = {2'h0, a[5:4]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:119:11, :121:11
  reg  [10:0] rtlzz_pipe_88_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:147:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:147:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :147:23
      rtlzz_pipe_88_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:147:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :147:23
      rtlzz_pipe_88_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_1, 4'h0} + {_GEN_6 * _GEN_2, 6'h0}}
          : rtlzz_pipe_88_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:10:9, :19:10, :121:11, :125:11, :136:11, :144:11, :147:23
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_91_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:176:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:176:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :176:23
      rtlzz_pipe_91_s1 <= 15'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:176:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :176:23
      rtlzz_pipe_91_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_3, 8'h0} + {_GEN_6 * _GEN_4, 10'h0}}
          : rtlzz_pipe_91_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:37:10, :48:10, :121:11, :154:11, :165:11, :173:11, :176:23
  end // always_ff @(posedge)
  wire [3:0]  _GEN_7 = {2'h0, a[7:6]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:177:11, :179:11
  reg  [12:0] rtlzz_pipe_94_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:205:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:205:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :205:23
      rtlzz_pipe_94_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:205:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :205:23
      rtlzz_pipe_94_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_1, 6'h0} + {_GEN_7 * _GEN_2, 8'h0}}
          : rtlzz_pipe_94_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:10:9, :19:10, :179:11, :183:11, :194:11, :202:11, :205:23
  end // always_ff @(posedge)
  reg  [16:0] rtlzz_pipe_97_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:234:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:234:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :234:23
      rtlzz_pipe_97_s1 <= 17'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:234:23
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :234:23
      rtlzz_pipe_97_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_3, 10'h0} + {_GEN_7 * _GEN_4, 12'h0}}
          : rtlzz_pipe_97_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:37:10, :48:10, :179:11, :212:11, :223:11, :231:11, :234:23
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_112_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:263:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:263:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :263:24
      rtlzz_pipe_112_s2 <= 15'h23;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:262:11, :263:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :263:24
      rtlzz_pipe_112_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_76_s1} + {1'h0, rtlzz_pipe_79_s1}}
               + {5'h0, rtlzz_pipe_82_s1} + {1'h0, rtlzz_pipe_85_s1}}
          : rtlzz_pipe_112_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:31:23, :60:23, :89:23, :118:23, :236:11, :238:11, :242:11, :247:11, :249:11, :253:11, :260:11, :263:24, :582:21
  end // always_ff @(posedge)
  reg  [18:0] rtlzz_pipe_115_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:292:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:292:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :292:24
      rtlzz_pipe_115_s2 <= 19'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:292:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :292:24
      rtlzz_pipe_115_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_88_s1} + {1'h0, rtlzz_pipe_91_s1}}
               + {5'h0, rtlzz_pipe_94_s1} + {1'h0, rtlzz_pipe_97_s1}}
          : rtlzz_pipe_115_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:147:23, :176:23, :205:23, :234:23, :265:11, :267:11, :271:11, :276:11, :278:11, :282:11, :289:11, :292:24, :582:21
  end // always_ff @(posedge)
  wire [3:0]  _GEN_8 = {2'h0, c[1:0]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:296:11, :298:11
  wire [3:0]  _GEN_9 = {2'h0, c[3:2]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:305:11, :307:11
  reg  [6:0]  rtlzz_pipe_185_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:319:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:319:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :319:24
      rtlzz_pipe_185_s1 <= 7'hB;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:318:11, :319:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :319:24
      rtlzz_pipe_185_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_8} + {_GEN_0 * _GEN_9, 2'h0}}
          : rtlzz_pipe_185_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:7:9, :298:11, :299:11, :307:11, :308:11, :316:11, :319:24
  end // always_ff @(posedge)
  wire [3:0]  _GEN_10 = {2'h0, c[5:4]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:323:11, :325:11
  wire [3:0]  _GEN_11 = {2'h0, c[7:6]};	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:334:11, :336:11
  reg  [10:0] rtlzz_pipe_188_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:348:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:348:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :348:24
      rtlzz_pipe_188_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:348:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :348:24
      rtlzz_pipe_188_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_0 * _GEN_10, 4'h0} + {_GEN_0 * _GEN_11, 6'h0}}
          : rtlzz_pipe_188_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:7:9, :325:11, :326:11, :336:11, :337:11, :345:11, :348:24
  end // always_ff @(posedge)
  reg  [8:0]  rtlzz_pipe_191_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:377:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:377:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :377:24
      rtlzz_pipe_191_s1 <= 9'h2C;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:376:11, :377:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :377:24
      rtlzz_pipe_191_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_8, 2'h0} + {_GEN_5 * _GEN_9, 4'h0}}
          : rtlzz_pipe_191_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:63:10, :298:11, :307:11, :355:11, :366:11, :374:11, :377:24
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_194_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:406:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:406:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :406:24
      rtlzz_pipe_194_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:406:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :406:24
      rtlzz_pipe_194_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_5 * _GEN_10, 6'h0} + {_GEN_5 * _GEN_11, 8'h0}}
          : rtlzz_pipe_194_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:63:10, :325:11, :336:11, :384:11, :395:11, :403:11, :406:24
  end // always_ff @(posedge)
  reg  [10:0] rtlzz_pipe_197_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:435:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:435:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :435:24
      rtlzz_pipe_197_s1 <= 11'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:435:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :435:24
      rtlzz_pipe_197_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_8, 4'h0} + {_GEN_6 * _GEN_9, 6'h0}}
          : rtlzz_pipe_197_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:121:11, :298:11, :307:11, :413:11, :424:11, :432:11, :435:24
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_200_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:464:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:464:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :464:24
      rtlzz_pipe_200_s1 <= 15'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:464:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :464:24
      rtlzz_pipe_200_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_6 * _GEN_10, 8'h0} + {_GEN_6 * _GEN_11, 10'h0}}
          : rtlzz_pipe_200_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:121:11, :325:11, :336:11, :442:11, :453:11, :461:11, :464:24
  end // always_ff @(posedge)
  reg  [12:0] rtlzz_pipe_203_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:493:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:493:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :493:24
      rtlzz_pipe_203_s1 <= 13'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:493:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :493:24
      rtlzz_pipe_203_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_8, 6'h0} + {_GEN_7 * _GEN_9, 8'h0}}
          : rtlzz_pipe_203_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:179:11, :298:11, :307:11, :471:11, :482:11, :490:11, :493:24
  end // always_ff @(posedge)
  reg  [16:0] rtlzz_pipe_206_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:522:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:522:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :522:24
      rtlzz_pipe_206_s1 <= 17'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:522:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :522:24
      rtlzz_pipe_206_s1 <=
        iv
          ? {1'h0, {2'h0, _GEN_7 * _GEN_10, 10'h0} + {_GEN_7 * _GEN_11, 12'h0}}
          : rtlzz_pipe_206_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:179:11, :325:11, :336:11, :500:11, :511:11, :519:11, :522:24
  end // always_ff @(posedge)
  reg  [14:0] rtlzz_pipe_221_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:551:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:551:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :551:24
      rtlzz_pipe_221_s2 <= 15'h37;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:550:11, :551:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :551:24
      rtlzz_pipe_221_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_185_s1} + {1'h0, rtlzz_pipe_188_s1}}
               + {5'h0, rtlzz_pipe_191_s1} + {1'h0, rtlzz_pipe_194_s1}}
          : rtlzz_pipe_221_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:319:24, :348:24, :377:24, :406:24, :524:11, :526:11, :530:11, :535:11, :537:11, :541:11, :548:11, :551:24, :582:21
  end // always_ff @(posedge)
  reg  [18:0] rtlzz_pipe_224_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:580:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:580:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :580:24
      rtlzz_pipe_224_s2 <= 19'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:580:24
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :580:24
      rtlzz_pipe_224_s2 <=
        rtlzz_valid_s1
          ? {1'h0,
             {2'h0, {5'h0, rtlzz_pipe_197_s1} + {1'h0, rtlzz_pipe_200_s1}}
               + {5'h0, rtlzz_pipe_203_s1} + {1'h0, rtlzz_pipe_206_s1}}
          : rtlzz_pipe_224_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:435:24, :464:24, :493:24, :522:24, :553:11, :555:11, :559:11, :564:11, :566:11, :570:11, :577:11, :580:24, :582:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:582:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :582:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:582:21
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :582:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:582:21
  end // always_ff @(posedge)
  reg         rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:584:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:584:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :584:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:584:21
    else	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:4:9, :584:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:582:21, :584:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:584:21, :605:3
  assign y = rtlzz_pipe_112_s2[7:0] + rtlzz_pipe_115_s2[7:0];	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:263:24, :292:24, :586:11, :588:11, :592:11, :605:3
  assign z = rtlzz_pipe_221_s2[7:0] + rtlzz_pipe_224_s2[7:0];	// /tmp/rtlzz-circt-7-2002828950595892/input.mlir:551:24, :580:24, :596:11, :598:11, :602:11, :605:3
endmodule
