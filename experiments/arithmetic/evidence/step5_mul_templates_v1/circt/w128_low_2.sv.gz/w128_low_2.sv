module w128_low_2(	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:1
  input  [127:0] a,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:26
                 b,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:40
                 c,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:54
  input          iv,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:68
                 rstn,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:81
                 clk,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:96
  output         ov,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:111
  output [127:0] y,	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:124
                 z	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:1:138
);

  reg          rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:630:21
  wire         _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9
  wire [63:0]  _GEN_0 = {32'h0, a[31:0]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:5:9, :7:9
  wire [63:0]  _GEN_1 = {32'h0, b[31:0]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:8:9, :10:9
  reg  [63:0]  rtlzz_pipe_13_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:13:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:13:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :13:23
      rtlzz_pipe_13_s1 <= 64'h23;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:12:10, :13:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :13:23
      rtlzz_pipe_13_s1 <= iv ? _GEN_0 * _GEN_1 : rtlzz_pipe_13_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :10:9, :11:9, :13:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_2 = {32'h0, b[63:32]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:17:10, :19:10
  reg  [95:0]  rtlzz_pipe_17_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:24:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:24:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :24:23
      rtlzz_pipe_17_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:24:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :24:23
      rtlzz_pipe_17_s1 <= iv ? {_GEN_0 * _GEN_2, 32'h0} : rtlzz_pipe_17_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :19:10, :20:10, :22:10, :24:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_3 = {32'h0, b[95:64]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:28:10, :30:10
  reg  [127:0] rtlzz_pipe_21_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:35:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:35:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :35:23
      rtlzz_pipe_21_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:35:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :35:23
      rtlzz_pipe_21_s1 <= iv ? {_GEN_0 * _GEN_3, 64'h0} : rtlzz_pipe_21_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :30:10, :31:10, :33:10, :35:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_4 = {32'h0, b[127:96]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:39:10, :41:10
  reg  [159:0] rtlzz_pipe_25_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:46:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:46:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :46:23
      rtlzz_pipe_25_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:46:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :46:23
      rtlzz_pipe_25_s1 <= iv ? {_GEN_0 * _GEN_4, 96'h0} : rtlzz_pipe_25_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :41:10, :42:10, :44:10, :46:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_5 = {32'h0, a[63:32]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:47:10, :49:10
  reg  [95:0]  rtlzz_pipe_29_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:57:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:57:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :57:23
      rtlzz_pipe_29_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:57:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :57:23
      rtlzz_pipe_29_s1 <= iv ? {_GEN_5 * _GEN_1, 32'h0} : rtlzz_pipe_29_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:10:9, :49:10, :53:10, :55:10, :57:23
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_33_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:68:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:68:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :68:23
      rtlzz_pipe_33_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:68:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :68:23
      rtlzz_pipe_33_s1 <= iv ? {_GEN_5 * _GEN_2, 64'h0} : rtlzz_pipe_33_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:19:10, :49:10, :64:10, :66:10, :68:23
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_37_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:79:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:79:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :79:23
      rtlzz_pipe_37_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:79:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :79:23
      rtlzz_pipe_37_s1 <= iv ? {_GEN_5 * _GEN_3, 96'h0} : rtlzz_pipe_37_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:30:10, :49:10, :75:10, :77:10, :79:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_41_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:90:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:90:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :90:23
      rtlzz_pipe_41_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:90:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :90:23
      rtlzz_pipe_41_s1 <= iv ? {_GEN_5 * _GEN_4, 128'h0} : rtlzz_pipe_41_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:41:10, :49:10, :86:10, :88:10, :90:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_6 = {32'h0, a[95:64]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:91:10, :93:10
  reg  [127:0] rtlzz_pipe_45_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:101:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:101:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :101:23
      rtlzz_pipe_45_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:101:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :101:23
      rtlzz_pipe_45_s1 <= iv ? {_GEN_6 * _GEN_1, 64'h0} : rtlzz_pipe_45_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:10:9, :93:10, :97:10, :99:10, :101:23
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_49_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:112:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:112:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :112:23
      rtlzz_pipe_49_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:112:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :112:23
      rtlzz_pipe_49_s1 <= iv ? {_GEN_6 * _GEN_2, 96'h0} : rtlzz_pipe_49_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:19:10, :93:10, :108:10, :110:10, :112:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_53_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:123:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:123:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :123:23
      rtlzz_pipe_53_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:123:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :123:23
      rtlzz_pipe_53_s1 <= iv ? {_GEN_6 * _GEN_3, 128'h0} : rtlzz_pipe_53_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:30:10, :93:10, :119:11, :121:11, :123:23
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_57_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:134:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:134:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :134:23
      rtlzz_pipe_57_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:134:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :134:23
      rtlzz_pipe_57_s1 <= iv ? {_GEN_6 * _GEN_4, 160'h0} : rtlzz_pipe_57_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:41:10, :93:10, :130:11, :132:11, :134:23
  end // always_ff @(posedge)
  wire [63:0]  _GEN_7 = {32'h0, a[127:96]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:135:11, :137:11
  reg  [159:0] rtlzz_pipe_61_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:145:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:145:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :145:23
      rtlzz_pipe_61_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:145:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :145:23
      rtlzz_pipe_61_s1 <= iv ? {_GEN_7 * _GEN_1, 96'h0} : rtlzz_pipe_61_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:10:9, :137:11, :141:11, :143:11, :145:23
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_65_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:156:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:156:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :156:23
      rtlzz_pipe_65_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:156:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :156:23
      rtlzz_pipe_65_s1 <= iv ? {_GEN_7 * _GEN_2, 128'h0} : rtlzz_pipe_65_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:19:10, :137:11, :152:11, :154:11, :156:23
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_69_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:167:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:167:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :167:23
      rtlzz_pipe_69_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:167:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :167:23
      rtlzz_pipe_69_s1 <= iv ? {_GEN_7 * _GEN_3, 160'h0} : rtlzz_pipe_69_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:30:10, :137:11, :163:11, :165:11, :167:23
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_73_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:178:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:178:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :178:23
      rtlzz_pipe_73_s1 <= 256'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:178:23
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :178:23
      rtlzz_pipe_73_s1 <= iv ? {_GEN_7 * _GEN_4, 192'h0} : rtlzz_pipe_73_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:41:10, :137:11, :174:11, :176:11, :178:23
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:316:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:316:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :316:22
      rtlzz_pipe_4_s2 <= 128'h23;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:315:11, :316:22
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :316:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? {31'h0, {33'h0, rtlzz_pipe_13_s1} + {1'h0, rtlzz_pipe_17_s1}}
            + rtlzz_pipe_21_s1 + rtlzz_pipe_25_s1[127:0] + {32'h0, rtlzz_pipe_29_s1}
            + rtlzz_pipe_33_s1 + rtlzz_pipe_37_s1[127:0] + rtlzz_pipe_41_s1[127:0]
            + rtlzz_pipe_45_s1 + rtlzz_pipe_49_s1[127:0] + rtlzz_pipe_53_s1[127:0]
            + rtlzz_pipe_57_s1[127:0] + rtlzz_pipe_61_s1[127:0] + rtlzz_pipe_65_s1[127:0]
            + rtlzz_pipe_69_s1[127:0] + rtlzz_pipe_73_s1[127:0]
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:13:23, :24:23, :35:23, :46:23, :57:23, :68:23, :79:23, :90:23, :101:23, :112:23, :123:23, :134:23, :145:23, :156:23, :167:23, :178:23, :180:11, :182:11, :186:11, :189:11, :193:11, :197:11, :204:11, :209:11, :215:11, :220:11, :222:11, :226:11, :233:11, :240:11, :247:11, :251:11, :256:11, :258:11, :262:11, :269:11, :274:11, :276:11, :280:11, :285:11, :287:11, :291:11, :298:11, :305:11, :312:11, :316:22, :630:21
  end // always_ff @(posedge)
  wire [63:0]  _GEN_8 = {32'h0, c[31:0]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:320:11, :322:11
  reg  [63:0]  rtlzz_pipe_122_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:325:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:325:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :325:24
      rtlzz_pipe_122_s1 <= 64'h37;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:324:11, :325:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :325:24
      rtlzz_pipe_122_s1 <= iv ? _GEN_0 * _GEN_8 : rtlzz_pipe_122_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :322:11, :323:11, :325:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_9 = {32'h0, c[63:32]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:329:11, :331:11
  reg  [95:0]  rtlzz_pipe_126_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:336:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:336:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :336:24
      rtlzz_pipe_126_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:336:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :336:24
      rtlzz_pipe_126_s1 <= iv ? {_GEN_0 * _GEN_9, 32'h0} : rtlzz_pipe_126_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :331:11, :332:11, :334:11, :336:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_10 = {32'h0, c[95:64]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:340:11, :342:11
  reg  [127:0] rtlzz_pipe_130_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:347:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:347:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :347:24
      rtlzz_pipe_130_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:347:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :347:24
      rtlzz_pipe_130_s1 <= iv ? {_GEN_0 * _GEN_10, 64'h0} : rtlzz_pipe_130_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :342:11, :343:11, :345:11, :347:24
  end // always_ff @(posedge)
  wire [63:0]  _GEN_11 = {32'h0, c[127:96]};	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:351:11, :353:11
  reg  [159:0] rtlzz_pipe_134_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:358:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:358:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :358:24
      rtlzz_pipe_134_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:358:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :358:24
      rtlzz_pipe_134_s1 <= iv ? {_GEN_0 * _GEN_11, 96'h0} : rtlzz_pipe_134_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:7:9, :353:11, :354:11, :356:11, :358:24
  end // always_ff @(posedge)
  reg  [95:0]  rtlzz_pipe_138_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:369:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:369:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :369:24
      rtlzz_pipe_138_s1 <= 96'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:369:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :369:24
      rtlzz_pipe_138_s1 <= iv ? {_GEN_5 * _GEN_8, 32'h0} : rtlzz_pipe_138_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:49:10, :322:11, :365:11, :367:11, :369:24
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_142_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:380:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:380:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :380:24
      rtlzz_pipe_142_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:380:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :380:24
      rtlzz_pipe_142_s1 <= iv ? {_GEN_5 * _GEN_9, 64'h0} : rtlzz_pipe_142_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:49:10, :331:11, :376:11, :378:11, :380:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_146_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:391:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:391:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :391:24
      rtlzz_pipe_146_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:391:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :391:24
      rtlzz_pipe_146_s1 <= iv ? {_GEN_5 * _GEN_10, 96'h0} : rtlzz_pipe_146_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:49:10, :342:11, :387:11, :389:11, :391:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_150_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:402:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:402:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :402:24
      rtlzz_pipe_150_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:402:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :402:24
      rtlzz_pipe_150_s1 <= iv ? {_GEN_5 * _GEN_11, 128'h0} : rtlzz_pipe_150_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:49:10, :353:11, :398:11, :400:11, :402:24
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_154_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:413:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:413:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :413:24
      rtlzz_pipe_154_s1 <= 128'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:413:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :413:24
      rtlzz_pipe_154_s1 <= iv ? {_GEN_6 * _GEN_8, 64'h0} : rtlzz_pipe_154_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:93:10, :322:11, :409:11, :411:11, :413:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_158_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:424:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:424:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :424:24
      rtlzz_pipe_158_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:424:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :424:24
      rtlzz_pipe_158_s1 <= iv ? {_GEN_6 * _GEN_9, 96'h0} : rtlzz_pipe_158_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:93:10, :331:11, :420:11, :422:11, :424:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_162_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:435:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:435:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :435:24
      rtlzz_pipe_162_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:435:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :435:24
      rtlzz_pipe_162_s1 <= iv ? {_GEN_6 * _GEN_10, 128'h0} : rtlzz_pipe_162_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:93:10, :342:11, :431:11, :433:11, :435:24
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_166_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:446:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:446:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :446:24
      rtlzz_pipe_166_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:446:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :446:24
      rtlzz_pipe_166_s1 <= iv ? {_GEN_6 * _GEN_11, 160'h0} : rtlzz_pipe_166_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:93:10, :353:11, :442:11, :444:11, :446:24
  end // always_ff @(posedge)
  reg  [159:0] rtlzz_pipe_170_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:457:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:457:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :457:24
      rtlzz_pipe_170_s1 <= 160'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:457:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :457:24
      rtlzz_pipe_170_s1 <= iv ? {_GEN_7 * _GEN_8, 96'h0} : rtlzz_pipe_170_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:137:11, :322:11, :453:11, :455:11, :457:24
  end // always_ff @(posedge)
  reg  [191:0] rtlzz_pipe_174_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:468:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:468:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :468:24
      rtlzz_pipe_174_s1 <= 192'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:468:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :468:24
      rtlzz_pipe_174_s1 <= iv ? {_GEN_7 * _GEN_9, 128'h0} : rtlzz_pipe_174_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:137:11, :331:11, :464:11, :466:11, :468:24
  end // always_ff @(posedge)
  reg  [223:0] rtlzz_pipe_178_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:479:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:479:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :479:24
      rtlzz_pipe_178_s1 <= 224'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:479:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :479:24
      rtlzz_pipe_178_s1 <= iv ? {_GEN_7 * _GEN_10, 160'h0} : rtlzz_pipe_178_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:137:11, :342:11, :475:11, :477:11, :479:24
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_182_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:490:24
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:490:24
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :490:24
      rtlzz_pipe_182_s1 <= 256'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:490:24
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :490:24
      rtlzz_pipe_182_s1 <= iv ? {_GEN_7 * _GEN_11, 192'h0} : rtlzz_pipe_182_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:137:11, :353:11, :486:11, :488:11, :490:24
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:628:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:628:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :628:22
      rtlzz_pipe_5_s2 <= 128'h37;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:627:11, :628:22
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :628:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? {31'h0, {33'h0, rtlzz_pipe_122_s1} + {1'h0, rtlzz_pipe_126_s1}}
            + rtlzz_pipe_130_s1 + rtlzz_pipe_134_s1[127:0] + {32'h0, rtlzz_pipe_138_s1}
            + rtlzz_pipe_142_s1 + rtlzz_pipe_146_s1[127:0] + rtlzz_pipe_150_s1[127:0]
            + rtlzz_pipe_154_s1 + rtlzz_pipe_158_s1[127:0] + rtlzz_pipe_162_s1[127:0]
            + rtlzz_pipe_166_s1[127:0] + rtlzz_pipe_170_s1[127:0]
            + rtlzz_pipe_174_s1[127:0] + rtlzz_pipe_178_s1[127:0]
            + rtlzz_pipe_182_s1[127:0]
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:325:24, :336:24, :347:24, :358:24, :369:24, :380:24, :391:24, :402:24, :413:24, :424:24, :435:24, :446:24, :457:24, :468:24, :479:24, :490:24, :492:11, :494:11, :498:11, :501:11, :505:11, :509:11, :516:11, :521:11, :527:11, :532:11, :534:11, :538:11, :545:11, :552:11, :559:11, :563:11, :568:11, :570:11, :574:11, :581:11, :586:11, :588:11, :592:11, :597:11, :599:11, :603:11, :610:11, :617:11, :624:11, :628:22, :630:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:630:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :630:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:630:21
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :630:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:630:21
  end // always_ff @(posedge)
  reg          rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:632:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:632:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :632:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:632:21
    else	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:4:9, :632:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:630:21, :632:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:632:21, :633:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:316:22, :633:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002831225287760/input.mlir:628:22, :633:3
endmodule
