module w128_full_1(	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:1
  input  [127:0] a,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:27
                 b,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:41
                 c,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:55
  input          iv,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:69
                 rstn,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:82
                 clk,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:97
  output         ov,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:112
  output [255:0] y,	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:125
                 z	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:1:139
);

  reg          rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:148:21
  wire         _GEN = ~rstn;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9
  wire [127:0] _GEN_0 = {64'h0, a[63:0]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:7:9, :9:9
  wire [127:0] _GEN_1 = {64'h0, b[63:0]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:12:10, :14:10
  wire [127:0] _GEN_2 = {64'h0, b[127:64]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:21:10, :23:10
  reg  [192:0] rtlzz_pipe_34_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:35:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:35:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :35:23
      rtlzz_pipe_34_s1 <= 193'h23;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:34:10, :35:23
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :35:23
      rtlzz_pipe_34_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_0 * _GEN_1} + {_GEN_0 * _GEN_2, 64'h0}}
          : rtlzz_pipe_34_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:9:9, :14:10, :15:10, :23:10, :24:10, :32:10, :35:23
  end // always_ff @(posedge)
  wire [127:0] _GEN_3 = {64'h0, a[127:64]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:36:10, :38:10
  reg  [256:0] rtlzz_pipe_37_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:64:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:64:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :64:23
      rtlzz_pipe_37_s1 <= 257'h0;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:64:23
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :64:23
      rtlzz_pipe_37_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_3 * _GEN_1, 64'h0} + {_GEN_3 * _GEN_2, 128'h0}}
          : rtlzz_pipe_37_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:14:10, :23:10, :38:10, :42:10, :53:10, :61:10, :64:23
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:76:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:76:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :76:22
      rtlzz_pipe_4_s2 <= 256'h23;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:75:10, :76:22
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :76:22
      rtlzz_pipe_4_s2 <=
        rtlzz_valid_s1
          ? {63'h0, rtlzz_pipe_34_s1} + rtlzz_pipe_37_s1[255:0]
          : rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:35:23, :64:23, :66:10, :68:10, :72:10, :76:22, :148:21
  end // always_ff @(posedge)
  wire [127:0] _GEN_4 = {64'h0, c[63:0]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:82:10, :84:10
  wire [127:0] _GEN_5 = {64'h0, c[127:64]};	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:91:10, :93:10
  reg  [192:0] rtlzz_pipe_59_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:105:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:105:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :105:23
      rtlzz_pipe_59_s1 <= 193'h37;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:104:10, :105:23
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :105:23
      rtlzz_pipe_59_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_0 * _GEN_4} + {_GEN_0 * _GEN_5, 64'h0}}
          : rtlzz_pipe_59_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:9:9, :84:10, :85:10, :93:10, :94:10, :102:10, :105:23
  end // always_ff @(posedge)
  reg  [256:0] rtlzz_pipe_62_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:134:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:134:23
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :134:23
      rtlzz_pipe_62_s1 <= 257'h0;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:134:23
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :134:23
      rtlzz_pipe_62_s1 <=
        iv
          ? {1'h0, {64'h0, _GEN_3 * _GEN_4, 64'h0} + {_GEN_3 * _GEN_5, 128'h0}}
          : rtlzz_pipe_62_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:38:10, :84:10, :93:10, :112:11, :123:11, :131:11, :134:23
  end // always_ff @(posedge)
  reg  [255:0] rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:146:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:146:22
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :146:22
      rtlzz_pipe_5_s2 <= 256'h37;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:145:11, :146:22
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :146:22
      rtlzz_pipe_5_s2 <=
        rtlzz_valid_s1
          ? {63'h0, rtlzz_pipe_59_s1} + rtlzz_pipe_62_s1[255:0]
          : rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:105:23, :134:23, :136:11, :138:11, :142:11, :146:22, :148:21
  end // always_ff @(posedge)
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:148:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :148:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:148:21
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :148:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:148:21
  end // always_ff @(posedge)
  reg          rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:150:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:150:21
    if (_GEN)	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :150:21
      rtlzz_valid_s2 <= 1'h0;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:150:21
    else	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:4:9, :150:21
      rtlzz_valid_s2 <= rtlzz_valid_s1;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:148:21, :150:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:150:21, :151:3
  assign y = rtlzz_pipe_4_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:76:22, :151:3
  assign z = rtlzz_pipe_5_s2;	// /tmp/rtlzz-circt-7-2002829726691560/input.mlir:146:22, :151:3
endmodule
