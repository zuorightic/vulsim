#include "VMulMAC.h"
#include "verilated.h"
#include <fstream>
#include <iomanip>
#include <iostream>
int main(int argc,char** argv){if(argc!=2)return 2;Verilated::commandArgs(argc,argv);VMulMAC top;std::ifstream in(argv[1]);unsigned a[4],b[4],c[9],iv;
auto read=[&](unsigned* words,int n){for(int i=0;i<n;++i)if(!(in>>std::hex>>words[i]))return false;return true;};
while(read(a,4)&&read(b,4)&&read(c,9)&&(in>>std::hex>>iv)){top.clk=0;top.iv=iv;for(int i=0;i<4;++i){top.a[i]=a[i];top.b[i]=b[i];}for(int i=0;i<9;++i)top.c[i]=c[i];top.eval();top.clk=1;top.eval();for(int i=0;i<20;++i){if(i)std::cout<<' ';std::cout<<std::hex<<unsigned(top.vs[i])<<' ';for(int j=8;j>=0;--j)std::cout<<std::setw(8)<<std::setfill('0')<<top.ys[i][j];}std::cout<<'\n';}}
