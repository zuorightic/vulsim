`timescale 1ns/1ps
module MulMAC(input logic clk,iv,input logic [127:0] a,b,input logic [256:0] c,output logic [256:0] ys[0:19],output logic vs[0:19]);
wire [16:0] y0;wire v0;sensitivity_8_1_0 u0(.clk(clk),.iv(iv),.ov(v0),.a(a[7:0]),.b(b[7:0]),.c(c[16:0]),.y(y0));
always_ff @(posedge clk)begin vs[0]<=v0;if(v0)ys[0]<=257'(y0);end
wire [16:0] y1;wire v1;sensitivity_8_1_1 u1(.clk(clk),.iv(iv),.ov(v1),.a(a[7:0]),.b(b[7:0]),.c(c[16:0]),.y(y1));
always_ff @(posedge clk)begin vs[1]<=v1;if(v1)ys[1]<=257'(y1);end
wire [16:0] y2;wire v2;sensitivity_8_1_2 u2(.clk(clk),.iv(iv),.ov(v2),.a(a[7:0]),.b(b[7:0]),.c(c[16:0]),.y(y2));
always_ff @(posedge clk)begin vs[2]<=v2;if(v2)ys[2]<=257'(y2);end
wire [16:0] y3;wire v3;sensitivity_8_1_3 u3(.clk(clk),.iv(iv),.ov(v3),.a(a[7:0]),.b(b[7:0]),.c(c[16:0]),.y(y3));
always_ff @(posedge clk)begin vs[3]<=v3;if(v3)ys[3]<=257'(y3);end
wire [32:0] y4;wire v4;sensitivity_16_1_0 u4(.clk(clk),.iv(iv),.ov(v4),.a(a[15:0]),.b(b[15:0]),.c(c[32:0]),.y(y4));
always_ff @(posedge clk)begin vs[4]<=v4;if(v4)ys[4]<=257'(y4);end
wire [32:0] y5;wire v5;sensitivity_16_1_1 u5(.clk(clk),.iv(iv),.ov(v5),.a(a[15:0]),.b(b[15:0]),.c(c[32:0]),.y(y5));
always_ff @(posedge clk)begin vs[5]<=v5;if(v5)ys[5]<=257'(y5);end
wire [32:0] y6;wire v6;sensitivity_16_1_2 u6(.clk(clk),.iv(iv),.ov(v6),.a(a[15:0]),.b(b[15:0]),.c(c[32:0]),.y(y6));
always_ff @(posedge clk)begin vs[6]<=v6;if(v6)ys[6]<=257'(y6);end
wire [32:0] y7;wire v7;sensitivity_16_1_3 u7(.clk(clk),.iv(iv),.ov(v7),.a(a[15:0]),.b(b[15:0]),.c(c[32:0]),.y(y7));
always_ff @(posedge clk)begin vs[7]<=v7;if(v7)ys[7]<=257'(y7);end
wire [64:0] y8;wire v8;sensitivity_32_1_0 u8(.clk(clk),.iv(iv),.ov(v8),.a(a[31:0]),.b(b[31:0]),.c(c[64:0]),.y(y8));
always_ff @(posedge clk)begin vs[8]<=v8;if(v8)ys[8]<=257'(y8);end
wire [64:0] y9;wire v9;sensitivity_32_1_1 u9(.clk(clk),.iv(iv),.ov(v9),.a(a[31:0]),.b(b[31:0]),.c(c[64:0]),.y(y9));
always_ff @(posedge clk)begin vs[9]<=v9;if(v9)ys[9]<=257'(y9);end
wire [64:0] y10;wire v10;sensitivity_32_1_2 u10(.clk(clk),.iv(iv),.ov(v10),.a(a[31:0]),.b(b[31:0]),.c(c[64:0]),.y(y10));
always_ff @(posedge clk)begin vs[10]<=v10;if(v10)ys[10]<=257'(y10);end
wire [64:0] y11;wire v11;sensitivity_32_1_3 u11(.clk(clk),.iv(iv),.ov(v11),.a(a[31:0]),.b(b[31:0]),.c(c[64:0]),.y(y11));
always_ff @(posedge clk)begin vs[11]<=v11;if(v11)ys[11]<=257'(y11);end
wire [128:0] y12;wire v12;sensitivity_64_1_0 u12(.clk(clk),.iv(iv),.ov(v12),.a(a[63:0]),.b(b[63:0]),.c(c[128:0]),.y(y12));
always_ff @(posedge clk)begin vs[12]<=v12;if(v12)ys[12]<=257'(y12);end
wire [128:0] y13;wire v13;sensitivity_64_1_1 u13(.clk(clk),.iv(iv),.ov(v13),.a(a[63:0]),.b(b[63:0]),.c(c[128:0]),.y(y13));
always_ff @(posedge clk)begin vs[13]<=v13;if(v13)ys[13]<=257'(y13);end
wire [128:0] y14;wire v14;sensitivity_64_1_2 u14(.clk(clk),.iv(iv),.ov(v14),.a(a[63:0]),.b(b[63:0]),.c(c[128:0]),.y(y14));
always_ff @(posedge clk)begin vs[14]<=v14;if(v14)ys[14]<=257'(y14);end
wire [128:0] y15;wire v15;sensitivity_64_1_3 u15(.clk(clk),.iv(iv),.ov(v15),.a(a[63:0]),.b(b[63:0]),.c(c[128:0]),.y(y15));
always_ff @(posedge clk)begin vs[15]<=v15;if(v15)ys[15]<=257'(y15);end
wire [256:0] y16;wire v16;sensitivity_128_1_0 u16(.clk(clk),.iv(iv),.ov(v16),.a(a[127:0]),.b(b[127:0]),.c(c[256:0]),.y(y16));
always_ff @(posedge clk)begin vs[16]<=v16;if(v16)ys[16]<=257'(y16);end
wire [256:0] y17;wire v17;sensitivity_128_1_1 u17(.clk(clk),.iv(iv),.ov(v17),.a(a[127:0]),.b(b[127:0]),.c(c[256:0]),.y(y17));
always_ff @(posedge clk)begin vs[17]<=v17;if(v17)ys[17]<=257'(y17);end
wire [256:0] y18;wire v18;sensitivity_128_1_2 u18(.clk(clk),.iv(iv),.ov(v18),.a(a[127:0]),.b(b[127:0]),.c(c[256:0]),.y(y18));
always_ff @(posedge clk)begin vs[18]<=v18;if(v18)ys[18]<=257'(y18);end
wire [256:0] y19;wire v19;sensitivity_128_1_3 u19(.clk(clk),.iv(iv),.ov(v19),.a(a[127:0]),.b(b[127:0]),.c(c[256:0]),.y(y19));
always_ff @(posedge clk)begin vs[19]<=v19;if(v19)ys[19]<=257'(y19);end
endmodule
