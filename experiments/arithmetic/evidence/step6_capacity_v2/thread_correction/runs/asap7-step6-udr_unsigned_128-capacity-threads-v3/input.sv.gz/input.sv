`timescale 1ns/1ps

module UDR_128_C(
    input logic iv, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:9:1-9:11
    output logic [127:0] q, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:25:5-25:18
    output logic [127:0] r, // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:26:5-26:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:29-18:43
    logic [127:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
    logic [127:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49
    logic [127:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49
    logic [127:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:23:27-23:73; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
    logic [127:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:24:27-24:62; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:24:27-24:62
    logic [127:0] arith_original_12; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49
    logic [127:0] arith_original_13; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49
    logic [127:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:29-18:43
    logic [127:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:29-18:43
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
    assign s8_norm_udivmod_6_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (rtlzz_pipe_3_s1 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:23:27-23:73; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
    assign s8_norm_mux_9_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:24:27-24:62; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:24:27-24:62
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:25:5-25:18
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:26:5-26:18
    assign arith_original_12 = (rtlzz_pipe_1_s1 / rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:21:31-21:49
    assign arith_original_13 = (rtlzz_pipe_1_s1 % rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:22:31-22:49
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 128'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:7:1-7:11
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:29-18:43
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:18:5-18:44
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_128_C.logic.cpp:4:1-4:8
        end
    end
endmodule

module Step6UDR128(input logic clk,rstn,iv,input logic [127:0] a,input logic [127:0] d,output logic ov,output logic [127:0] q,output logic [127:0] r);
wire valid;
wire [127:0] raw_q;
wire [127:0] raw_r;
UDR_128_C core(.clk(clk),.rstn(rstn),.iv(iv),.ov(valid),.a(a),.d(d),.q(raw_q),.r(raw_r));
always_ff @(posedge clk)begin if(!rstn)begin ov<=0;q<=128'd340282366920938463463374607431768211455;r<=128'd170141183460469231768580791863303209013;end else begin ov<=valid;if(valid)begin q<=raw_q;r<=raw_r;end end end
endmodule
