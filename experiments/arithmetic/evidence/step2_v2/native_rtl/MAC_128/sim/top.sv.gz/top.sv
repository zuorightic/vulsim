`timescale 1ns/1ps

module Case_sim_top(
  input clk,
  input rstn,
  input calculate__vld__,
  input [511:0] calculate_value__,
  output [255:0] calculate_result__
);



    logic calculate__vld; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22
    logic [511:0] calculate_value; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    logic [255:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:49:22-49:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:49:22-49:39
    logic [255:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:40:27-40:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:52:22-52:27
    logic [255:0] s8_norm_add_7_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:41:23-41:62; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:41:23-41:62
    logic [255:0] calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:53:5-53:32
    logic s10_guard_not_0_v48; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22
    logic [255:0] calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28
    logic [127:0] __beopt_width_14; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    logic [127:0] __beopt_width_15; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    logic [127:0] __beopt_width_12; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    logic [127:0] __beopt_width_13; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    logic [255:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_19; // decl: <none>; prim: <none>


    assign calculate__vld = calculate__vld__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22
    assign calculate_value = calculate_value__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    assign calculate_result__ = calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28

    assign s8_norm_hw_3_v0 = calculate_value[511:256]; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:49:22-49:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:49:22-49:39
    assign s8_norm_mul_6_v0 = 256'(($unsigned(256'($unsigned(__beopt_width_18))) * $unsigned(256'($unsigned(__beopt_width_19))))); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:40:27-40:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:52:22-52:27
    assign s8_norm_add_7_v0 = (s8_norm_mul_6_v0 + s8_norm_hw_3_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:41:23-41:62; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:41:23-41:62
    assign calculate_result___v3 = (s10_guard_not_0_v48 ? 256'h0 : s8_norm_add_7_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:53:5-53:32
    assign s10_guard_not_0_v48 = (!calculate__vld); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:30:1-30:22
    assign calculate_result = calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:34:1-34:28
    assign __beopt_width_14 = calculate_value[127:0]; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    assign __beopt_width_15 = calculate_value[255:128]; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    assign __beopt_width_12 = __beopt_width_14; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    assign __beopt_width_13 = __beopt_width_15; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MAC_128/sim/top.logic.cpp:32:1-32:27
    assign __beopt_width_18 = ({128'h0, __beopt_width_12}); // decl: <none>; prim: <none>
    assign __beopt_width_19 = ({128'h0, __beopt_width_13}); // decl: <none>; prim: <none>
endmodule

