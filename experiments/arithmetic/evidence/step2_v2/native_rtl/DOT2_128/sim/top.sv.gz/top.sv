`timescale 1ns/1ps

module Case_sim_top(
  input clk,
  input rstn,
  input calculate__vld__,
  input [511:0] calculate_value__,
  output [256:0] calculate_result__
);



    logic calculate__vld; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22
    logic [511:0] calculate_value; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27
    logic [255:0] s8_norm_mul_7_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:41:27-41:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:57:22-57:27
    logic [255:0] s8_norm_mul_8_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:42:28-42:45; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:57:22-57:27
    logic [256:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:45:23-45:62; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:43:5-43:45
    logic [256:0] calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:58:5-58:32
    logic s10_guard_not_0_v65; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22
    logic [256:0] calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28
    logic [255:0] __beopt_width_69; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:51:22-51:39
    logic [255:0] __beopt_width_70; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:52:22-52:39
    logic [255:0] __beopt_width_71; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:53:22-53:39
    logic [255:0] __beopt_width_18; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_19; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_20; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_21; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_24; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27
    logic [255:0] __beopt_width_22; // decl: <none>; prim: <none>


    assign calculate__vld = calculate__vld__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22
    assign calculate_value = calculate_value__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27
    assign calculate_result__ = calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28

    assign s8_norm_mul_7_v0 = 256'(($unsigned(256'($unsigned(__beopt_width_69))) * $unsigned(256'($unsigned(__beopt_width_70))))); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:41:27-41:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:57:22-57:27
    assign s8_norm_mul_8_v0 = 256'(($unsigned(256'($unsigned(__beopt_width_71))) * $unsigned(256'($unsigned(__beopt_width_24))))); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:42:28-42:45; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:57:22-57:27
    assign s8_norm_add_11_v0 = (s8_norm_mul_7_v0 + s8_norm_mul_8_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:45:23-45:62; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:43:5-43:45
    assign calculate_result___v3 = (s10_guard_not_0_v65 ? 257'h0 : s8_norm_add_11_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:58:5-58:32
    assign s10_guard_not_0_v65 = (!calculate__vld); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:31:1-31:22
    assign calculate_result = calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:35:1-35:28
    assign __beopt_width_69 = (__beopt_width_18 & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:51:22-51:39
    assign __beopt_width_70 = (__beopt_width_19 & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:52:22-52:39
    assign __beopt_width_71 = (__beopt_width_20 & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:53:22-53:39
    assign __beopt_width_18 = calculate_value[255:0]; // decl: <none>; prim: <none>
    assign __beopt_width_19 = calculate_value[383:128]; // decl: <none>; prim: <none>
    assign __beopt_width_20 = calculate_value[511:256]; // decl: <none>; prim: <none>
    assign __beopt_width_21 = calculate_value[511:384]; // decl: <none>; prim: <none>
    assign __beopt_width_24 = (__beopt_width_22 & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/DOT2_128/sim/top.logic.cpp:33:1-33:27
    assign __beopt_width_22 = ({128'h0, __beopt_width_21}); // decl: <none>; prim: <none>
endmodule

