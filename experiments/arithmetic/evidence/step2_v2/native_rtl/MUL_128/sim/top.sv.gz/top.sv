`timescale 1ns/1ps

module Case_sim_top(
  input clk,
  input rstn,
  input calculate__vld__,
  input [255:0] calculate_value__,
  output [255:0] calculate_result__
);



    logic calculate__vld; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22
    logic [255:0] calculate_value; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27
    logic [255:0] s8_norm_mul_5_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:39:27-39:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:49:22-49:27
    logic [255:0] calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:50:5-50:32
    logic s10_guard_not_0_v33; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22
    logic [255:0] calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28
    logic [255:0] __beopt_width_37; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:45:22-45:39
    logic [127:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_14; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27
    logic [255:0] __beopt_width_12; // decl: <none>; prim: <none>


    assign calculate__vld = calculate__vld__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22
    assign calculate_value = calculate_value__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27
    assign calculate_result__ = calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28

    assign s8_norm_mul_5_v0 = 256'(($unsigned(256'($unsigned(__beopt_width_37))) * $unsigned(256'($unsigned(__beopt_width_14))))); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:39:27-39:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:49:22-49:27
    assign calculate_result___v3 = (s10_guard_not_0_v33 ? 256'h0 : s8_norm_mul_5_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:50:5-50:32
    assign s10_guard_not_0_v33 = (!calculate__vld); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:29:1-29:22
    assign calculate_result = calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:33:1-33:28
    assign __beopt_width_37 = (calculate_value & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:45:22-45:39
    assign __beopt_width_10 = calculate_value[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_14 = (__beopt_width_12 & 256'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/MUL_128/sim/top.logic.cpp:31:1-31:27
    assign __beopt_width_12 = ({128'h0, __beopt_width_10}); // decl: <none>; prim: <none>
endmodule

