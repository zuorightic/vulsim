`timescale 1ns/1ps

module Case_sim_top(
  input clk,
  input rstn,
  input calculate__vld__,
  input [384:0] calculate_value__,
  output [127:0] calculate_result__
);



    logic calculate__vld; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22
    logic [384:0] calculate_value; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:33:1-33:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:33:1-33:27
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:50:22-50:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:50:22-50:39
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:51:22-51:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:51:22-51:39
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:52:22-52:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:52:22-52:39
    logic s8_norm_hw_4_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:53:27-53:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:53:27-53:44
    logic [127:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:42:28-42:59; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:56:22-56:27
    logic [127:0] s8_norm_mul_11_v0; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:56:22-56:27
    logic [127:0] s8_norm_add_13_v0; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:44:23-44:65; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:44:23-44:65
    logic [127:0] calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:57:5-57:32
    logic s10_guard_not_0_v62; // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22
    logic [127:0] calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28


    assign calculate__vld = calculate__vld__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22
    assign calculate_value = calculate_value__; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:33:1-33:27; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:33:1-33:27
    assign calculate_result__ = calculate_result; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28

    assign s8_norm_hw_1_v0 = calculate_value[127:0]; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:50:22-50:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:50:22-50:39
    assign s8_norm_hw_2_v0 = calculate_value[255:128]; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:51:22-51:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:51:22-51:39
    assign s8_norm_hw_3_v0 = calculate_value[383:256]; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:52:22-52:39; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:52:22-52:39
    assign s8_norm_hw_4_v0 = calculate_value[384]; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:53:27-53:44; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:53:27-53:44
    assign s8_norm_mux_10_v0 = (s8_norm_hw_4_v0 ? s8_norm_hw_3_v0 : 128'h0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:42:28-42:59; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:56:22-56:27
    assign s8_norm_mul_11_v0 = 128'(($unsigned(128'($unsigned(s8_norm_hw_1_v0))) * $unsigned(128'($unsigned(s8_norm_hw_2_v0))))); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:56:22-56:27
    assign s8_norm_add_13_v0 = (s8_norm_mul_11_v0 + s8_norm_mux_10_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:44:23-44:65; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:44:23-44:65
    assign calculate_result___v3 = (s10_guard_not_0_v62 ? 128'h0 : s8_norm_add_13_v0); // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:57:5-57:32
    assign s10_guard_not_0_v62 = (!calculate__vld); // decl: <none>; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:31:1-31:22
    assign calculate_result = calculate_result___v3; // decl: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28; prim: /home/zyrv/vulsim/build/step2-revision-20261030/full-v2/native/H_M_128/sim/top.logic.cpp:35:1-35:28
endmodule

