`timescale 1ns/1ps

module WorkloadCore(
    input logic [511:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [511:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [511:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [511:0] s8_norm_sub_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:35; prim: /home/zyrv/vulsim/workload.cpp:13:10-13:35
    logic [62:0] limb_3_6; // decl: <none>; prim: <none>
    logic [62:0] limb_3_7; // decl: <none>; prim: <none>
    logic [62:0] limb_3_8; // decl: <none>; prim: <none>
    logic [63:0] limb_3_9; // decl: <none>; prim: <none>
    logic [62:0] limb_3_10; // decl: <none>; prim: <none>
    logic limb_3_11; // decl: <none>; prim: <none>
    logic [62:0] limb_3_12; // decl: <none>; prim: <none>
    logic [62:0] limb_3_13; // decl: <none>; prim: <none>
    logic [62:0] limb_3_14; // decl: <none>; prim: <none>
    logic [63:0] limb_3_15; // decl: <none>; prim: <none>
    logic [62:0] limb_3_16; // decl: <none>; prim: <none>
    logic limb_3_17; // decl: <none>; prim: <none>
    logic [62:0] limb_3_18; // decl: <none>; prim: <none>
    logic [62:0] limb_3_19; // decl: <none>; prim: <none>
    logic [62:0] limb_3_20; // decl: <none>; prim: <none>
    logic [63:0] limb_3_21; // decl: <none>; prim: <none>
    logic [62:0] limb_3_22; // decl: <none>; prim: <none>
    logic limb_3_23; // decl: <none>; prim: <none>
    logic [62:0] limb_3_24; // decl: <none>; prim: <none>
    logic [62:0] limb_3_25; // decl: <none>; prim: <none>
    logic [62:0] limb_3_26; // decl: <none>; prim: <none>
    logic [63:0] limb_3_27; // decl: <none>; prim: <none>
    logic [62:0] limb_3_28; // decl: <none>; prim: <none>
    logic limb_3_29; // decl: <none>; prim: <none>
    logic [62:0] limb_3_30; // decl: <none>; prim: <none>
    logic [62:0] limb_3_31; // decl: <none>; prim: <none>
    logic [62:0] limb_3_32; // decl: <none>; prim: <none>
    logic [63:0] limb_3_33; // decl: <none>; prim: <none>
    logic [62:0] limb_3_34; // decl: <none>; prim: <none>
    logic limb_3_35; // decl: <none>; prim: <none>
    logic [62:0] limb_3_36; // decl: <none>; prim: <none>
    logic [62:0] limb_3_37; // decl: <none>; prim: <none>
    logic [62:0] limb_3_38; // decl: <none>; prim: <none>
    logic [63:0] limb_3_39; // decl: <none>; prim: <none>
    logic [62:0] limb_3_40; // decl: <none>; prim: <none>
    logic limb_3_41; // decl: <none>; prim: <none>
    logic [62:0] limb_3_42; // decl: <none>; prim: <none>
    logic [62:0] limb_3_43; // decl: <none>; prim: <none>
    logic [62:0] limb_3_44; // decl: <none>; prim: <none>
    logic [63:0] limb_3_45; // decl: <none>; prim: <none>
    logic [62:0] limb_3_46; // decl: <none>; prim: <none>
    logic limb_3_47; // decl: <none>; prim: <none>
    logic [62:0] limb_3_48; // decl: <none>; prim: <none>
    logic [62:0] limb_3_49; // decl: <none>; prim: <none>
    logic [62:0] limb_3_50; // decl: <none>; prim: <none>
    logic [63:0] limb_3_51; // decl: <none>; prim: <none>
    logic [62:0] limb_3_52; // decl: <none>; prim: <none>
    logic limb_3_53; // decl: <none>; prim: <none>
    logic [7:0] limb_3_54; // decl: <none>; prim: <none>
    logic [7:0] limb_3_55; // decl: <none>; prim: <none>
    logic [7:0] limb_3_56; // decl: <none>; prim: <none>
    logic [8:0] limb_3_57; // decl: <none>; prim: <none>
    logic [7:0] limb_3_58; // decl: <none>; prim: <none>
    logic [511:0] limb_3_59; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_6_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_8_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_10_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_10_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_11_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_12_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_13_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_16_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_17_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_18_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_19_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_26_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_30_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_36_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_38_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_44_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_48_s3; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_49_s2; // decl: <none>; prim: <none>
    logic [62:0] rtlzz_pipe_50_s3; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_54_s3; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_56_s2; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_56_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_sub_0_v0 = limb_3_59; // decl: <none>; prim: <none>
    assign y = s8_norm_sub_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign limb_3_6 = a[62:0]; // decl: <none>; prim: <none>
    assign limb_3_7 = b[62:0]; // decl: <none>; prim: <none>
    assign limb_3_8 = (~limb_3_7); // decl: <none>; prim: <none>
    assign limb_3_9 = 64'((({1'h0, rtlzz_pipe_6_s1}) + ({1'h0, rtlzz_pipe_8_s1}) + ({63'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_3_10 = limb_3_9[62:0]; // decl: <none>; prim: <none>
    assign limb_3_11 = limb_3_9[63]; // decl: <none>; prim: <none>
    assign limb_3_12 = a[125:63]; // decl: <none>; prim: <none>
    assign limb_3_13 = b[125:63]; // decl: <none>; prim: <none>
    assign limb_3_14 = (~rtlzz_pipe_13_s2); // decl: <none>; prim: <none>
    assign limb_3_15 = 64'((({1'h0, rtlzz_pipe_12_s2}) + ({1'h0, limb_3_14}) + ({63'h0, rtlzz_pipe_11_s2}))); // decl: <none>; prim: <none>
    assign limb_3_16 = limb_3_15[62:0]; // decl: <none>; prim: <none>
    assign limb_3_17 = limb_3_15[63]; // decl: <none>; prim: <none>
    assign limb_3_18 = a[188:126]; // decl: <none>; prim: <none>
    assign limb_3_19 = b[188:126]; // decl: <none>; prim: <none>
    assign limb_3_20 = (~rtlzz_pipe_19_s3); // decl: <none>; prim: <none>
    assign limb_3_21 = 64'((({1'h0, rtlzz_pipe_18_s3}) + ({1'h0, limb_3_20}) + ({63'h0, rtlzz_pipe_17_s3}))); // decl: <none>; prim: <none>
    assign limb_3_22 = limb_3_21[62:0]; // decl: <none>; prim: <none>
    assign limb_3_23 = limb_3_21[63]; // decl: <none>; prim: <none>
    assign limb_3_24 = a[251:189]; // decl: <none>; prim: <none>
    assign limb_3_25 = b[251:189]; // decl: <none>; prim: <none>
    assign limb_3_26 = (~limb_3_25); // decl: <none>; prim: <none>
    assign limb_3_27 = 64'((({1'h0, rtlzz_pipe_24_s3}) + ({1'h0, rtlzz_pipe_26_s3}) + ({63'h0, limb_3_23}))); // decl: <none>; prim: <none>
    assign limb_3_28 = limb_3_27[62:0]; // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_27[63]; // decl: <none>; prim: <none>
    assign limb_3_30 = a[314:252]; // decl: <none>; prim: <none>
    assign limb_3_31 = b[314:252]; // decl: <none>; prim: <none>
    assign limb_3_32 = (~rtlzz_pipe_31_s1); // decl: <none>; prim: <none>
    assign limb_3_33 = 64'((({1'h0, rtlzz_pipe_30_s3}) + ({1'h0, rtlzz_pipe_32_s3}) + ({63'h0, limb_3_29}))); // decl: <none>; prim: <none>
    assign limb_3_34 = limb_3_33[62:0]; // decl: <none>; prim: <none>
    assign limb_3_35 = limb_3_33[63]; // decl: <none>; prim: <none>
    assign limb_3_36 = a[377:315]; // decl: <none>; prim: <none>
    assign limb_3_37 = b[377:315]; // decl: <none>; prim: <none>
    assign limb_3_38 = (~rtlzz_pipe_37_s1); // decl: <none>; prim: <none>
    assign limb_3_39 = 64'((({1'h0, rtlzz_pipe_36_s3}) + ({1'h0, rtlzz_pipe_38_s3}) + ({63'h0, limb_3_35}))); // decl: <none>; prim: <none>
    assign limb_3_40 = limb_3_39[62:0]; // decl: <none>; prim: <none>
    assign limb_3_41 = limb_3_39[63]; // decl: <none>; prim: <none>
    assign limb_3_42 = a[440:378]; // decl: <none>; prim: <none>
    assign limb_3_43 = b[440:378]; // decl: <none>; prim: <none>
    assign limb_3_44 = (~limb_3_43); // decl: <none>; prim: <none>
    assign limb_3_45 = 64'((({1'h0, rtlzz_pipe_42_s3}) + ({1'h0, rtlzz_pipe_44_s3}) + ({63'h0, limb_3_41}))); // decl: <none>; prim: <none>
    assign limb_3_46 = limb_3_45[62:0]; // decl: <none>; prim: <none>
    assign limb_3_47 = limb_3_45[63]; // decl: <none>; prim: <none>
    assign limb_3_48 = a[503:441]; // decl: <none>; prim: <none>
    assign limb_3_49 = b[503:441]; // decl: <none>; prim: <none>
    assign limb_3_50 = (~rtlzz_pipe_49_s2); // decl: <none>; prim: <none>
    assign limb_3_51 = 64'((({1'h0, rtlzz_pipe_48_s3}) + ({1'h0, rtlzz_pipe_50_s3}) + ({63'h0, limb_3_47}))); // decl: <none>; prim: <none>
    assign limb_3_52 = limb_3_51[62:0]; // decl: <none>; prim: <none>
    assign limb_3_53 = limb_3_51[63]; // decl: <none>; prim: <none>
    assign limb_3_54 = a[511:504]; // decl: <none>; prim: <none>
    assign limb_3_55 = b[511:504]; // decl: <none>; prim: <none>
    assign limb_3_56 = (~rtlzz_pipe_55_s1); // decl: <none>; prim: <none>
    assign limb_3_57 = 9'((({1'h0, rtlzz_pipe_54_s3}) + ({1'h0, rtlzz_pipe_56_s3}) + ({8'h0, limb_3_53}))); // decl: <none>; prim: <none>
    assign limb_3_58 = limb_3_57[7:0]; // decl: <none>; prim: <none>
    assign limb_3_59 = {limb_3_58, limb_3_52, limb_3_46, limb_3_40, limb_3_34, limb_3_28, limb_3_22, rtlzz_pipe_16_s3, rtlzz_pipe_10_s3}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_6_s1 <= 63'h0;
            rtlzz_pipe_8_s1 <= 63'h7fffffffffffffff;
            rtlzz_pipe_10_s2 <= 63'h0;
            rtlzz_pipe_10_s3 <= 63'h0;
            rtlzz_pipe_11_s2 <= 1'h1;
            rtlzz_pipe_12_s1 <= 63'h0;
            rtlzz_pipe_12_s2 <= 63'h0;
            rtlzz_pipe_13_s1 <= 63'h0;
            rtlzz_pipe_13_s2 <= 63'h0;
            rtlzz_pipe_16_s3 <= 63'h0;
            rtlzz_pipe_17_s3 <= 1'h1;
            rtlzz_pipe_18_s1 <= 63'h0;
            rtlzz_pipe_18_s2 <= 63'h0;
            rtlzz_pipe_18_s3 <= 63'h0;
            rtlzz_pipe_19_s1 <= 63'h0;
            rtlzz_pipe_19_s2 <= 63'h0;
            rtlzz_pipe_19_s3 <= 63'h0;
            rtlzz_pipe_24_s1 <= 63'h0;
            rtlzz_pipe_24_s2 <= 63'h0;
            rtlzz_pipe_24_s3 <= 63'h0;
            rtlzz_pipe_26_s1 <= 63'h7fffffffffffffff;
            rtlzz_pipe_26_s2 <= 63'h7fffffffffffffff;
            rtlzz_pipe_26_s3 <= 63'h7fffffffffffffff;
            rtlzz_pipe_30_s1 <= 63'h0;
            rtlzz_pipe_30_s2 <= 63'h0;
            rtlzz_pipe_30_s3 <= 63'h0;
            rtlzz_pipe_31_s1 <= 63'h0;
            rtlzz_pipe_32_s2 <= 63'h7fffffffffffffff;
            rtlzz_pipe_32_s3 <= 63'h7fffffffffffffff;
            rtlzz_pipe_36_s1 <= 63'h0;
            rtlzz_pipe_36_s2 <= 63'h0;
            rtlzz_pipe_36_s3 <= 63'h0;
            rtlzz_pipe_37_s1 <= 63'h0;
            rtlzz_pipe_38_s2 <= 63'h7fffffffffffffff;
            rtlzz_pipe_38_s3 <= 63'h7fffffffffffffff;
            rtlzz_pipe_42_s1 <= 63'h0;
            rtlzz_pipe_42_s2 <= 63'h0;
            rtlzz_pipe_42_s3 <= 63'h0;
            rtlzz_pipe_44_s1 <= 63'h7fffffffffffffff;
            rtlzz_pipe_44_s2 <= 63'h7fffffffffffffff;
            rtlzz_pipe_44_s3 <= 63'h7fffffffffffffff;
            rtlzz_pipe_48_s1 <= 63'h0;
            rtlzz_pipe_48_s2 <= 63'h0;
            rtlzz_pipe_48_s3 <= 63'h0;
            rtlzz_pipe_49_s1 <= 63'h0;
            rtlzz_pipe_49_s2 <= 63'h0;
            rtlzz_pipe_50_s3 <= 63'h7fffffffffffffff;
            rtlzz_pipe_54_s1 <= 8'h0;
            rtlzz_pipe_54_s2 <= 8'h0;
            rtlzz_pipe_54_s3 <= 8'h0;
            rtlzz_pipe_55_s1 <= 8'h0;
            rtlzz_pipe_56_s2 <= 8'hff;
            rtlzz_pipe_56_s3 <= 8'hff;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_6_s1 <= limb_3_6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_8_s1 <= limb_3_8; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= limb_3_10; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_10_s3 <= rtlzz_pipe_10_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= limb_3_11; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_12_s1 <= limb_3_12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_13_s1 <= limb_3_13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_13_s2 <= rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_16_s3 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_17_s3 <= limb_3_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= limb_3_18; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_18_s2 <= rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_18_s3 <= rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_19_s3 <= rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_24_s1 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_3_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_26_s3 <= rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= limb_3_30; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_30_s3 <= rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= limb_3_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= limb_3_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_36_s1 <= limb_3_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_36_s3 <= rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_3_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= limb_3_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_3_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_44_s1 <= limb_3_44; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_44_s2 <= rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_48_s1 <= limb_3_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= limb_3_49; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_49_s2 <= rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_50_s3 <= limb_3_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= limb_3_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_54_s2 <= rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_54_s3 <= rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= limb_3_55; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_56_s2 <= limb_3_56; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_56_s3 <= rtlzz_pipe_56_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [511:0] a_data,input wire a_wen,input wire [511:0] b_data,input wire b_wen,output reg [511:0] y);
reg liv;wire cov;
reg [511:0] l_a;
reg [511:0] l_b;
wire [511:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;l_b<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
