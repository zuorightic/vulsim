`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] x1, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] x2, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] x3, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] x4, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] x5, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] x6, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] x7, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    output logic [63:0] y0, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    output logic [63:0] y1, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    output logic [63:0] y2, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    output logic [63:0] y3, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    output logic [63:0] y4, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    output logic [63:0] y5, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    output logic [63:0] y6, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    output logic [63:0] y7, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:8; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [64:0] tmp_workload_top_int_65__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] tmp_workload_top_int_65__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    logic [64:0] s8_norm_add_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_sub_20_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:18-44:62; prim: /home/zyrv/vulsim/workload.cpp:44:18-44:62
    logic [64:0] tmp_workload_top_int_65__41_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] tmp_workload_top_int_65__43_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    logic [64:0] s8_norm_add_34_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic s8_norm_cmp_38_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_sub_40_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] s8_norm_mux_41_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:19-50:66; prim: /home/zyrv/vulsim/workload.cpp:50:19-50:66
    logic [64:0] tmp_workload_top_int_65__74_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] tmp_workload_top_int_65__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] s8_norm_add_54_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic s8_norm_cmp_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_sub_60_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] s8_norm_mux_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    logic [64:0] tmp_workload_top_int_65__107_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] tmp_workload_top_int_65__109_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] s8_norm_mux_71_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
    logic [64:0] s8_norm_add_74_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic s8_norm_cmp_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] s8_norm_mux_81_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:19-62:66; prim: /home/zyrv/vulsim/workload.cpp:62:19-62:66
    logic [64:0] tmp_workload_top_int_65__140_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] tmp_workload_top_int_65__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    logic [64:0] s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic s8_norm_cmp_88_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_sub_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] s8_norm_mux_91_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
    logic [64:0] s8_norm_add_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic s8_norm_cmp_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] s8_norm_mux_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
    logic [127:0] tmp_workload_top_int_128__175_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    logic [255:0] s8_norm_mul_106_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:49; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:31
    logic [192:0] tmp_workload_top_int_193__180_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    logic [385:0] s8_norm_mul_110_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n34_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    logic [257:0] s8_norm_mul_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:20-75:48; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:22
    logic [128:0] n36_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    logic [128:0] tmp_workload_top_int_129__191_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:39
    logic s8_norm_cmp_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:21-77:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_sub_122_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:50-77:68; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    logic [128:0] s8_norm_mux_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:69; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:69
    logic [64:0] tmp_workload_top_int_65__204_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] tmp_workload_top_int_65__206_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    logic [64:0] s8_norm_add_127_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:45; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:45
    logic s8_norm_cmp_129_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:20-80:37; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_sub_131_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:48-80:65; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    logic [64:0] s8_norm_mux_132_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:66; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:66
    logic [64:0] s8_norm_add_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] s8_norm_sub_137_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:59; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:59
    logic s8_norm_cmp_139_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:20-82:37; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_sub_141_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:48-82:65; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    logic [64:0] s8_norm_mux_142_v0; // decl: /home/zyrv/vulsim/workload.cpp:82:19-82:66; prim: /home/zyrv/vulsim/workload.cpp:82:19-82:66
    logic [64:0] tmp_workload_top_int_65__237_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] tmp_workload_top_int_65__239_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    logic [64:0] s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_sub_151_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] s8_norm_mux_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
    logic [64:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic s8_norm_cmp_159_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] s8_norm_mux_162_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:66; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:66
    logic [127:0] tmp_workload_top_int_128__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    logic [255:0] s8_norm_mul_167_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:49; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:31
    logic [192:0] tmp_workload_top_int_193__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [385:0] s8_norm_mul_171_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n54_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    logic [257:0] s8_norm_mul_176_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:48; prim: /home/zyrv/vulsim/workload.cpp:94:19-94:22
    logic [128:0] n56_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    logic [128:0] tmp_workload_top_int_129__288_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_179_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:39
    logic s8_norm_cmp_181_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:21-97:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_sub_183_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:50-97:68; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [128:0] s8_norm_mux_184_v0; // decl: /home/zyrv/vulsim/workload.cpp:97:20-97:69; prim: /home/zyrv/vulsim/workload.cpp:97:20-97:69
    logic [64:0] tmp_workload_top_int_65__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] tmp_workload_top_int_65__303_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    logic [64:0] s8_norm_add_188_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:46; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:46
    logic s8_norm_cmp_190_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:20-100:37; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_sub_192_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:48-100:65; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    logic [64:0] s8_norm_mux_193_v0; // decl: /home/zyrv/vulsim/workload.cpp:100:19-100:66; prim: /home/zyrv/vulsim/workload.cpp:100:19-100:66
    logic [64:0] s8_norm_add_196_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] s8_norm_sub_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
    logic s8_norm_cmp_200_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_sub_202_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:48-102:65; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    logic [64:0] s8_norm_mux_203_v0; // decl: /home/zyrv/vulsim/workload.cpp:102:19-102:66; prim: /home/zyrv/vulsim/workload.cpp:102:19-102:66
    logic [64:0] tmp_workload_top_int_65__334_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    logic [64:0] tmp_workload_top_int_65__336_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    logic [64:0] s8_norm_add_208_v0; // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    logic s8_norm_cmp_210_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_sub_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:48-106:65; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    logic [64:0] s8_norm_mux_213_v0; // decl: /home/zyrv/vulsim/workload.cpp:106:19-106:66; prim: /home/zyrv/vulsim/workload.cpp:106:19-106:66
    logic [64:0] s8_norm_add_216_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:45; prim: /home/zyrv/vulsim/workload.cpp:69:19-69:31
    logic [64:0] s8_norm_sub_218_v0; // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
    logic s8_norm_cmp_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:20-108:37; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_sub_222_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:48-108:65; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    logic [64:0] s8_norm_mux_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:108:19-108:66; prim: /home/zyrv/vulsim/workload.cpp:108:19-108:66
    logic [63:0] tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    logic [63:0] tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    logic [127:0] tmp_workload_top_int_128__369_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    logic [255:0] s8_norm_mul_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:49; prim: /home/zyrv/vulsim/workload.cpp:103:19-103:31
    logic [192:0] tmp_workload_top_int_193__374_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    logic [385:0] s8_norm_mul_232_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    logic [257:0] s8_norm_mul_237_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:20-115:48; prim: /home/zyrv/vulsim/workload.cpp:114:19-114:22
    logic [128:0] n76_v0; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    logic [128:0] tmp_workload_top_int_129__385_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_240_v0; // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:39
    logic s8_norm_cmp_242_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:21-117:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_sub_244_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:50-117:68; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    logic [128:0] s8_norm_mux_245_v0; // decl: /home/zyrv/vulsim/workload.cpp:117:20-117:69; prim: /home/zyrv/vulsim/workload.cpp:117:20-117:69
    logic [64:0] tmp_workload_top_int_65__398_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    logic [64:0] tmp_workload_top_int_65__400_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    logic [64:0] s8_norm_add_249_v0; // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:46; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:46
    logic s8_norm_cmp_251_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:20-120:37; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_sub_253_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:48-120:65; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    logic [64:0] s8_norm_mux_254_v0; // decl: /home/zyrv/vulsim/workload.cpp:120:19-120:66; prim: /home/zyrv/vulsim/workload.cpp:120:19-120:66
    logic [64:0] s8_norm_add_257_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:45; prim: /home/zyrv/vulsim/workload.cpp:83:19-83:31
    logic [64:0] s8_norm_sub_259_v0; // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:60; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:60
    logic s8_norm_cmp_261_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:20-122:37; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_sub_263_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:48-122:65; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    logic [64:0] s8_norm_mux_264_v0; // decl: /home/zyrv/vulsim/workload.cpp:122:19-122:66; prim: /home/zyrv/vulsim/workload.cpp:122:19-122:66
    logic [63:0] tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    logic [63:0] tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    logic [127:0] tmp_workload_top_int_128__433_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    logic [255:0] s8_norm_mul_269_v0; // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:49; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:31
    logic [192:0] tmp_workload_top_int_193__438_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    logic [385:0] s8_norm_mul_273_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n88_v0; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    logic [257:0] s8_norm_mul_278_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:20-129:48; prim: /home/zyrv/vulsim/workload.cpp:128:19-128:22
    logic [128:0] n90_v0; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    logic [128:0] tmp_workload_top_int_129__449_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_281_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
    logic s8_norm_cmp_283_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:21-131:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_sub_285_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:50-131:68; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    logic [128:0] s8_norm_mux_286_v0; // decl: /home/zyrv/vulsim/workload.cpp:131:20-131:69; prim: /home/zyrv/vulsim/workload.cpp:131:20-131:69
    logic [64:0] tmp_workload_top_int_65__462_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    logic [64:0] tmp_workload_top_int_65__464_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    logic [64:0] s8_norm_add_290_v0; // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:46; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:46
    logic s8_norm_cmp_292_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:20-134:37; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_sub_294_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:48-134:65; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    logic [64:0] s8_norm_mux_295_v0; // decl: /home/zyrv/vulsim/workload.cpp:134:19-134:66; prim: /home/zyrv/vulsim/workload.cpp:134:19-134:66
    logic [64:0] s8_norm_add_298_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:45; prim: /home/zyrv/vulsim/workload.cpp:70:19-70:31
    logic [64:0] s8_norm_sub_300_v0; // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
    logic s8_norm_cmp_302_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_sub_304_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:48-136:65; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    logic [64:0] s8_norm_mux_305_v0; // decl: /home/zyrv/vulsim/workload.cpp:136:19-136:66; prim: /home/zyrv/vulsim/workload.cpp:136:19-136:66
    logic [63:0] tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    logic [63:0] tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    logic [127:0] tmp_workload_top_int_128__497_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    logic [255:0] s8_norm_mul_310_v0; // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:51; prim: /home/zyrv/vulsim/workload.cpp:104:19-104:31
    logic [192:0] tmp_workload_top_int_193__502_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    logic [385:0] s8_norm_mul_314_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:50; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    logic [192:0] n102_v0; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    logic [257:0] s8_norm_mul_319_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:21-143:50; prim: /home/zyrv/vulsim/workload.cpp:142:20-142:24
    logic [128:0] n104_v0; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    logic [128:0] tmp_workload_top_int_129__513_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_322_v0; // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:42; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:42
    logic s8_norm_cmp_324_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:22-145:41; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_sub_326_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:53-145:72; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    logic [128:0] s8_norm_mux_327_v0; // decl: /home/zyrv/vulsim/workload.cpp:145:21-145:73; prim: /home/zyrv/vulsim/workload.cpp:145:21-145:73
    logic [64:0] tmp_workload_top_int_65__526_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    logic [64:0] tmp_workload_top_int_65__528_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    logic [64:0] s8_norm_add_331_v0; // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:48; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:48
    logic s8_norm_cmp_333_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:21-148:39; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_sub_335_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:51-148:69; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    logic [64:0] s8_norm_mux_336_v0; // decl: /home/zyrv/vulsim/workload.cpp:148:20-148:70; prim: /home/zyrv/vulsim/workload.cpp:148:20-148:70
    logic [64:0] s8_norm_add_339_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:46; prim: /home/zyrv/vulsim/workload.cpp:84:19-84:31
    logic [64:0] s8_norm_sub_341_v0; // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:62; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:62
    logic s8_norm_cmp_343_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:21-150:39; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_sub_345_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:51-150:69; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    logic [64:0] s8_norm_mux_346_v0; // decl: /home/zyrv/vulsim/workload.cpp:150:20-150:70; prim: /home/zyrv/vulsim/workload.cpp:150:20-150:70
    logic [63:0] tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    logic [63:0] tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    logic [127:0] __beopt_width_858; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_859; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_860; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_862; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_863; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_865; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_866; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_867; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_869; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_870; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_872; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_873; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_874; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_876; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_877; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_879; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_880; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_881; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_883; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_884; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_886; // decl: <none>; prim: <none>
    logic [192:0] __beopt_width_887; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_888; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_890; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_891; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_255; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    logic [128:0] __beopt_width_259; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    logic [128:0] __beopt_width_263; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    logic [128:0] __beopt_width_268; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    logic [128:0] __beopt_width_272; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    logic [128:0] __beopt_width_256; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_260; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_264; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_267; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_253; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_254; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_255; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_256; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_257; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_258; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_259; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_260; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_261; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_262; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_263; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_264; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_265; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_266; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_267; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_268; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_269; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_270; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_271; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_272; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_273; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_274; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_275; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_276; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_277; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_278; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_279; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_280; // decl: <none>; prim: <none>
    logic [48:0] mul_precision_281; // decl: <none>; prim: <none>
    logic [112:0] mul_precision_282; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_283; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_284; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_285; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_286; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_287; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_288; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_289; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_290; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_291; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [112:0] arith_original_298; // decl: <none>; prim: <none>
    logic [192:0] arith_original_299; // decl: <none>; prim: <none>
    logic [128:0] arith_original_300; // decl: <none>; prim: <none>
    logic [112:0] arith_original_301; // decl: <none>; prim: <none>
    logic [192:0] arith_original_302; // decl: <none>; prim: <none>
    logic [128:0] arith_original_303; // decl: <none>; prim: <none>
    logic [127:0] arith_original_304; // decl: <none>; prim: <none>
    logic [192:0] arith_original_305; // decl: <none>; prim: <none>
    logic [128:0] arith_original_306; // decl: <none>; prim: <none>
    logic [112:0] arith_original_307; // decl: <none>; prim: <none>
    logic [192:0] arith_original_308; // decl: <none>; prim: <none>
    logic [128:0] arith_original_309; // decl: <none>; prim: <none>
    logic [127:0] arith_original_310; // decl: <none>; prim: <none>
    logic [192:0] arith_original_311; // decl: <none>; prim: <none>
    logic [128:0] arith_original_312; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_9_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_9_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_9_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_9_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_10_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    logic [64:0] rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic [64:0] rtlzz_pipe_11_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    logic rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_13_s3; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    logic [64:0] rtlzz_pipe_15_s5; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] rtlzz_pipe_16_s6; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic [64:0] rtlzz_pipe_16_s7; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic [64:0] rtlzz_pipe_16_s8; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    logic rtlzz_pipe_17_s7; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic rtlzz_pipe_17_s8; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] rtlzz_pipe_18_s8; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    logic [64:0] rtlzz_pipe_20_s1; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s7; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s8; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s9; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s12; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_20_s13; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_21_s1; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s7; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s8; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s9; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s12; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s13; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_21_s14; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    logic [64:0] rtlzz_pipe_22_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic [64:0] rtlzz_pipe_22_s12; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    logic rtlzz_pipe_23_s11; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic rtlzz_pipe_23_s12; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_24_s12; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    logic [64:0] rtlzz_pipe_26_s14; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] rtlzz_pipe_27_s15; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    logic rtlzz_pipe_28_s15; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    logic [64:0] rtlzz_pipe_31_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_31_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_31_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_31_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_32_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] rtlzz_pipe_32_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] rtlzz_pipe_32_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] rtlzz_pipe_32_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] rtlzz_pipe_32_s5; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    logic [64:0] rtlzz_pipe_33_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic [64:0] rtlzz_pipe_33_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    logic rtlzz_pipe_34_s2; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic rtlzz_pipe_34_s3; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_35_s3; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    logic [64:0] rtlzz_pipe_36_s4; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] rtlzz_pipe_36_s5; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    logic [64:0] rtlzz_pipe_37_s5; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    logic [64:0] rtlzz_pipe_38_s6; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic [64:0] rtlzz_pipe_38_s7; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic [64:0] rtlzz_pipe_38_s8; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    logic rtlzz_pipe_39_s7; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic rtlzz_pipe_39_s8; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] rtlzz_pipe_40_s8; // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    logic [64:0] rtlzz_pipe_41_s9; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    logic [64:0] rtlzz_pipe_41_s10; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    logic [64:0] rtlzz_pipe_42_s1; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s9; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_42_s12; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_43_s1; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s9; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_43_s12; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    logic [64:0] rtlzz_pipe_44_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s12; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic [64:0] rtlzz_pipe_44_s13; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    logic rtlzz_pipe_45_s11; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s12; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic rtlzz_pipe_45_s13; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_46_s12; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_46_s13; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    logic [64:0] rtlzz_pipe_49_s13; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [64:0] rtlzz_pipe_49_s14; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic [64:0] rtlzz_pipe_49_s15; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    logic rtlzz_pipe_50_s14; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic rtlzz_pipe_50_s15; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] rtlzz_pipe_51_s15; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    logic [64:0] rtlzz_pipe_53_s4; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s5; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s6; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s7; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s8; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s9; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s10; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s11; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s12; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_53_s13; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    logic [64:0] rtlzz_pipe_54_s13; // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    logic [64:0] rtlzz_pipe_55_s14; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic [64:0] rtlzz_pipe_55_s15; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    logic rtlzz_pipe_56_s14; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic rtlzz_pipe_56_s15; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] rtlzz_pipe_57_s15; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    logic [64:0] rtlzz_pipe_59_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s8; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s9; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s10; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s11; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_59_s12; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    logic [64:0] rtlzz_pipe_60_s13; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [64:0] rtlzz_pipe_60_s14; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic [64:0] rtlzz_pipe_60_s15; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    logic rtlzz_pipe_61_s15; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] rtlzz_pipe_62_s13; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] rtlzz_pipe_62_s14; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] rtlzz_pipe_62_s15; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    logic [64:0] rtlzz_pipe_76_s9; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s10; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s11; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s12; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s13; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s14; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_76_s15; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    logic [64:0] rtlzz_pipe_82_s10; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_82_s11; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_82_s12; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_82_s13; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_82_s14; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_82_s15; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    logic [64:0] rtlzz_pipe_87_s6; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s7; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s8; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s9; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s10; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s11; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s12; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s13; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_87_s14; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    logic [64:0] rtlzz_pipe_88_s14; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    logic [64:0] rtlzz_pipe_89_s15; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic rtlzz_pipe_90_s15; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    logic [64:0] rtlzz_pipe_93_s7; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s8; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s9; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s10; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s11; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s12; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_93_s13; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    logic [64:0] rtlzz_pipe_94_s14; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    logic rtlzz_pipe_95_s14; // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    logic [64:0] rtlzz_pipe_110_s11; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] rtlzz_pipe_110_s12; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] rtlzz_pipe_110_s13; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] rtlzz_pipe_110_s14; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] rtlzz_pipe_110_s15; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    logic [64:0] rtlzz_pipe_116_s12; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] rtlzz_pipe_116_s13; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] rtlzz_pipe_116_s14; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [64:0] rtlzz_pipe_116_s15; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    logic [128:0] rtlzz_pipe_167_s15; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    logic rtlzz_valid_s15; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8


    assign tmp_workload_top_int_65__8_v0 = ({1'h0, x0}); // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    assign tmp_workload_top_int_65__10_v0 = ({1'h0, x4}); // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
    assign s8_norm_add_6_v0 = (tmp_workload_top_int_65__8_v0 + tmp_workload_top_int_65__10_v0); // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
    assign s8_norm_cmp_8_v0 = (rtlzz_pipe_11_s1 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    assign s8_norm_sub_10_v0 = (rtlzz_pipe_11_s2 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
    assign s8_norm_mux_11_v0 = (rtlzz_pipe_12_s3 ? rtlzz_pipe_11_s3 : rtlzz_pipe_13_s3); // decl: /home/zyrv/vulsim/workload.cpp:42:18-42:62; prim: /home/zyrv/vulsim/workload.cpp:42:18-42:62
    assign s8_norm_add_14_v0 = (rtlzz_pipe_9_s4 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    assign s8_norm_sub_16_v0 = (rtlzz_pipe_15_s5 - rtlzz_pipe_10_s5); // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
    assign s8_norm_cmp_18_v0 = (rtlzz_pipe_16_s6 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    assign s8_norm_sub_20_v0 = (rtlzz_pipe_16_s7 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
    assign s8_norm_mux_21_v0 = (rtlzz_pipe_17_s8 ? rtlzz_pipe_16_s8 : rtlzz_pipe_18_s8); // decl: /home/zyrv/vulsim/workload.cpp:44:18-44:62; prim: /home/zyrv/vulsim/workload.cpp:44:18-44:62
    assign tmp_workload_top_int_65__41_v0 = ({1'h0, x2}); // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    assign tmp_workload_top_int_65__43_v0 = ({1'h0, x6}); // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
    assign s8_norm_add_26_v0 = (rtlzz_pipe_20_s9 + rtlzz_pipe_21_s9); // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
    assign s8_norm_cmp_28_v0 = (rtlzz_pipe_22_s10 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    assign s8_norm_sub_30_v0 = (rtlzz_pipe_22_s11 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
    assign s8_norm_mux_31_v0 = (rtlzz_pipe_23_s12 ? rtlzz_pipe_22_s12 : rtlzz_pipe_24_s12); // decl: /home/zyrv/vulsim/workload.cpp:48:18-48:62; prim: /home/zyrv/vulsim/workload.cpp:48:18-48:62
    assign s8_norm_add_34_v0 = (rtlzz_pipe_20_s13 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    assign s8_norm_sub_36_v0 = (rtlzz_pipe_26_s14 - rtlzz_pipe_21_s14); // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
    assign s8_norm_cmp_38_v0 = (s8_norm_sub_36_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    assign s8_norm_sub_40_v0 = (rtlzz_pipe_27_s15 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:50:48-50:65; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
    assign s8_norm_mux_41_v0 = (rtlzz_pipe_28_s15 ? rtlzz_pipe_27_s15 : s8_norm_sub_40_v0); // decl: /home/zyrv/vulsim/workload.cpp:50:19-50:66; prim: /home/zyrv/vulsim/workload.cpp:50:19-50:66
    assign tmp_workload_top_int_65__74_v0 = ({1'h0, x1}); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    assign tmp_workload_top_int_65__76_v0 = ({1'h0, x5}); // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
    assign s8_norm_add_46_v0 = (tmp_workload_top_int_65__74_v0 + tmp_workload_top_int_65__76_v0); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
    assign s8_norm_cmp_48_v0 = (rtlzz_pipe_33_s1 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    assign s8_norm_sub_50_v0 = (rtlzz_pipe_33_s2 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
    assign s8_norm_mux_51_v0 = (rtlzz_pipe_34_s3 ? rtlzz_pipe_33_s3 : rtlzz_pipe_35_s3); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
    assign s8_norm_add_54_v0 = (rtlzz_pipe_31_s4 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    assign s8_norm_sub_56_v0 = (rtlzz_pipe_37_s5 - rtlzz_pipe_32_s5); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
    assign s8_norm_cmp_58_v0 = (rtlzz_pipe_38_s6 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    assign s8_norm_sub_60_v0 = (rtlzz_pipe_38_s7 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
    assign s8_norm_mux_61_v0 = (rtlzz_pipe_39_s8 ? rtlzz_pipe_38_s8 : rtlzz_pipe_40_s8); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
    assign tmp_workload_top_int_65__107_v0 = ({1'h0, x3}); // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    assign tmp_workload_top_int_65__109_v0 = ({1'h0, x7}); // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
    assign s8_norm_add_66_v0 = (rtlzz_pipe_42_s9 + rtlzz_pipe_43_s9); // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
    assign s8_norm_cmp_68_v0 = (rtlzz_pipe_44_s10 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    assign s8_norm_sub_70_v0 = (rtlzz_pipe_44_s11 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
    assign s8_norm_mux_71_v0 = (rtlzz_pipe_45_s13 ? rtlzz_pipe_44_s13 : rtlzz_pipe_46_s13); // decl: /home/zyrv/vulsim/workload.cpp:60:19-60:66; prim: /home/zyrv/vulsim/workload.cpp:60:19-60:66
    assign s8_norm_add_74_v0 = (rtlzz_pipe_42_s12 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
    assign s8_norm_sub_76_v0 = (s8_norm_add_74_v0 - rtlzz_pipe_43_s12); // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
    assign s8_norm_cmp_78_v0 = (rtlzz_pipe_49_s13 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    assign s8_norm_sub_80_v0 = (rtlzz_pipe_49_s14 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
    assign s8_norm_mux_81_v0 = (rtlzz_pipe_50_s15 ? rtlzz_pipe_49_s15 : rtlzz_pipe_51_s15); // decl: /home/zyrv/vulsim/workload.cpp:62:19-62:66; prim: /home/zyrv/vulsim/workload.cpp:62:19-62:66
    assign tmp_workload_top_int_65__140_v0 = (s8_norm_mux_11_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
    assign tmp_workload_top_int_65__142_v0 = (s8_norm_mux_31_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
    assign s8_norm_add_86_v0 = (rtlzz_pipe_53_s13 + rtlzz_pipe_54_s13); // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
    assign s8_norm_cmp_88_v0 = (s8_norm_add_86_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    assign s8_norm_sub_90_v0 = (rtlzz_pipe_55_s14 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
    assign s8_norm_mux_91_v0 = (rtlzz_pipe_56_s15 ? rtlzz_pipe_55_s15 : rtlzz_pipe_57_s15); // decl: /home/zyrv/vulsim/workload.cpp:66:19-66:66; prim: /home/zyrv/vulsim/workload.cpp:66:19-66:66
    assign s8_norm_add_94_v0 = (rtlzz_pipe_53_s4 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
    assign s8_norm_sub_96_v0 = (rtlzz_pipe_59_s12 - tmp_workload_top_int_65__142_v0); // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
    assign s8_norm_cmp_98_v0 = (rtlzz_pipe_60_s14 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    assign s8_norm_sub_100_v0 = (s8_norm_sub_96_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
    assign s8_norm_mux_101_v0 = (rtlzz_pipe_61_s15 ? rtlzz_pipe_60_s15 : rtlzz_pipe_62_s15); // decl: /home/zyrv/vulsim/workload.cpp:68:19-68:66; prim: /home/zyrv/vulsim/workload.cpp:68:19-68:66
    assign tmp_workload_top_int_128__175_v0 = (__beopt_width_858 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:33; prim: /home/zyrv/vulsim/workload.cpp:50:5-50:67
    assign s8_norm_mul_106_v0 = ({143'h0, mul_precision_255}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__180_v0 = (__beopt_width_859 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:33; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:33
    assign s8_norm_mul_110_v0 = ({193'h0, mul_precision_258}); // decl: <none>; prim: <none>
    assign n34_v0 = s8_norm_mul_110_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:73:5-73:49; prim: /home/zyrv/vulsim/workload.cpp:73:20-73:48
    assign s8_norm_mul_115_v0 = ({129'h0, mul_precision_261}); // decl: <none>; prim: <none>
    assign n36_v0 = s8_norm_mul_115_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:49; prim: /home/zyrv/vulsim/workload.cpp:75:20-75:48
    assign tmp_workload_top_int_129__191_v0 = (__beopt_width_862 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:33; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    assign s8_norm_sub_118_v0 = (tmp_workload_top_int_129__191_v0 - n36_v0); // decl: /home/zyrv/vulsim/workload.cpp:76:20-76:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:39
    assign s8_norm_cmp_120_v0 = (s8_norm_sub_118_v0 < 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:77:21-77:39; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    assign s8_norm_sub_122_v0 = (s8_norm_sub_118_v0 - 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:77:50-77:68; prim: /home/zyrv/vulsim/workload.cpp:76:20-76:33
    assign s8_norm_mux_123_v0 = (s8_norm_cmp_120_v0 ? s8_norm_sub_118_v0 : s8_norm_sub_122_v0); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:69; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:69
    assign tmp_workload_top_int_65__204_v0 = (s8_norm_mux_21_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
    assign tmp_workload_top_int_65__206_v0 = (__beopt_width_863 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:33-79:45; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:70
    assign s8_norm_add_127_v0 = (rtlzz_pipe_76_s15 + tmp_workload_top_int_65__206_v0); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:45; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:45
    assign s8_norm_cmp_129_v0 = (s8_norm_add_127_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:80:20-80:37; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    assign s8_norm_sub_131_v0 = (s8_norm_add_127_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:80:48-80:65; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:30
    assign s8_norm_mux_132_v0 = (s8_norm_cmp_129_v0 ? s8_norm_add_127_v0 : s8_norm_sub_131_v0); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:66; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:66
    assign s8_norm_add_135_v0 = (rtlzz_pipe_76_s9 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
    assign s8_norm_sub_137_v0 = (rtlzz_pipe_82_s15 - tmp_workload_top_int_65__206_v0); // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:59; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:59
    assign s8_norm_cmp_139_v0 = (s8_norm_sub_137_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:82:20-82:37; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    assign s8_norm_sub_141_v0 = (s8_norm_sub_137_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:82:48-82:65; prim: /home/zyrv/vulsim/workload.cpp:81:19-81:44
    assign s8_norm_mux_142_v0 = (s8_norm_cmp_139_v0 ? s8_norm_sub_137_v0 : s8_norm_sub_141_v0); // decl: /home/zyrv/vulsim/workload.cpp:82:19-82:66; prim: /home/zyrv/vulsim/workload.cpp:82:19-82:66
    assign tmp_workload_top_int_65__237_v0 = (rtlzz_pipe_36_s5 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
    assign tmp_workload_top_int_65__239_v0 = (s8_norm_mux_71_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
    assign s8_norm_add_147_v0 = (rtlzz_pipe_87_s14 + rtlzz_pipe_88_s14); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    assign s8_norm_cmp_149_v0 = (s8_norm_add_147_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    assign s8_norm_sub_151_v0 = (rtlzz_pipe_89_s15 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:86:48-86:65; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
    assign s8_norm_mux_152_v0 = (rtlzz_pipe_90_s15 ? rtlzz_pipe_89_s15 : s8_norm_sub_151_v0); // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:66; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:66
    assign s8_norm_add_155_v0 = (rtlzz_pipe_87_s6 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
    assign s8_norm_sub_157_v0 = (rtlzz_pipe_93_s13 - tmp_workload_top_int_65__239_v0); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
    assign s8_norm_cmp_159_v0 = (s8_norm_sub_157_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    assign s8_norm_sub_161_v0 = (rtlzz_pipe_94_s14 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:88:48-88:65; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
    assign s8_norm_mux_162_v0 = (rtlzz_pipe_95_s14 ? rtlzz_pipe_94_s14 : s8_norm_sub_161_v0); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:66; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:66
    assign tmp_workload_top_int_128__272_v0 = (__beopt_width_865 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:33; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:67
    assign s8_norm_mul_167_v0 = ({143'h0, mul_precision_264}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__277_v0 = (__beopt_width_866 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign s8_norm_mul_171_v0 = ({193'h0, mul_precision_267}); // decl: <none>; prim: <none>
    assign n54_v0 = s8_norm_mul_171_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:93:5-93:49; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:48
    assign s8_norm_mul_176_v0 = ({129'h0, mul_precision_270}); // decl: <none>; prim: <none>
    assign n56_v0 = s8_norm_mul_176_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:95:5-95:49; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:48
    assign tmp_workload_top_int_129__288_v0 = (__beopt_width_869 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign s8_norm_sub_179_v0 = (tmp_workload_top_int_129__288_v0 - n56_v0); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:39
    assign s8_norm_cmp_181_v0 = (s8_norm_sub_179_v0 < 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:97:21-97:39; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign s8_norm_sub_183_v0 = (s8_norm_sub_179_v0 - 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:97:50-97:68; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign s8_norm_mux_184_v0 = (s8_norm_cmp_181_v0 ? s8_norm_sub_179_v0 : s8_norm_sub_183_v0); // decl: /home/zyrv/vulsim/workload.cpp:97:20-97:69; prim: /home/zyrv/vulsim/workload.cpp:97:20-97:69
    assign tmp_workload_top_int_65__301_v0 = (rtlzz_pipe_41_s10 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
    assign tmp_workload_top_int_65__303_v0 = (__beopt_width_870 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:99:34-99:46; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:70
    assign s8_norm_add_188_v0 = (rtlzz_pipe_110_s15 + tmp_workload_top_int_65__303_v0); // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:46; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:46
    assign s8_norm_cmp_190_v0 = (s8_norm_add_188_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:100:20-100:37; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    assign s8_norm_sub_192_v0 = (s8_norm_add_188_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:100:48-100:65; prim: /home/zyrv/vulsim/workload.cpp:99:19-99:31
    assign s8_norm_mux_193_v0 = (s8_norm_cmp_190_v0 ? s8_norm_add_188_v0 : s8_norm_sub_192_v0); // decl: /home/zyrv/vulsim/workload.cpp:100:19-100:66; prim: /home/zyrv/vulsim/workload.cpp:100:19-100:66
    assign s8_norm_add_196_v0 = (rtlzz_pipe_110_s11 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
    assign s8_norm_sub_198_v0 = (rtlzz_pipe_116_s15 - tmp_workload_top_int_65__303_v0); // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:60; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:60
    assign s8_norm_cmp_200_v0 = (s8_norm_sub_198_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:102:20-102:37; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    assign s8_norm_sub_202_v0 = (s8_norm_sub_198_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:102:48-102:65; prim: /home/zyrv/vulsim/workload.cpp:101:19-101:45
    assign s8_norm_mux_203_v0 = (s8_norm_cmp_200_v0 ? s8_norm_sub_198_v0 : s8_norm_sub_202_v0); // decl: /home/zyrv/vulsim/workload.cpp:102:19-102:66; prim: /home/zyrv/vulsim/workload.cpp:102:19-102:66
    assign tmp_workload_top_int_65__334_v0 = (s8_norm_mux_91_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:31; prim: /home/zyrv/vulsim/workload.cpp:66:5-66:67
    assign tmp_workload_top_int_65__336_v0 = (s8_norm_mux_152_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:105:34-105:46; prim: /home/zyrv/vulsim/workload.cpp:86:5-86:67
    assign s8_norm_add_208_v0 = (tmp_workload_top_int_65__334_v0 + tmp_workload_top_int_65__336_v0); // decl: /home/zyrv/vulsim/workload.cpp:105:19-105:46; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:46
    assign s8_norm_cmp_210_v0 = (s8_norm_add_208_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:106:20-106:37; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    assign s8_norm_sub_212_v0 = (s8_norm_add_208_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:106:48-106:65; prim: /home/zyrv/vulsim/workload.cpp:105:19-105:31
    assign s8_norm_mux_213_v0 = (s8_norm_cmp_210_v0 ? s8_norm_add_208_v0 : s8_norm_sub_212_v0); // decl: /home/zyrv/vulsim/workload.cpp:106:19-106:66; prim: /home/zyrv/vulsim/workload.cpp:106:19-106:66
    assign s8_norm_add_216_v0 = (tmp_workload_top_int_65__334_v0 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:45; prim: /home/zyrv/vulsim/workload.cpp:69:19-69:31
    assign s8_norm_sub_218_v0 = (s8_norm_add_216_v0 - tmp_workload_top_int_65__336_v0); // decl: /home/zyrv/vulsim/workload.cpp:107:19-107:60; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:60
    assign s8_norm_cmp_220_v0 = (s8_norm_sub_218_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:108:20-108:37; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    assign s8_norm_sub_222_v0 = (s8_norm_sub_218_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:108:48-108:65; prim: /home/zyrv/vulsim/workload.cpp:107:19-107:45
    assign s8_norm_mux_223_v0 = (s8_norm_cmp_220_v0 ? s8_norm_sub_218_v0 : s8_norm_sub_222_v0); // decl: /home/zyrv/vulsim/workload.cpp:108:19-108:66; prim: /home/zyrv/vulsim/workload.cpp:108:19-108:66
    assign tmp_workload_top_int_64__363_v0 = s8_norm_mux_213_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:109:19-109:31; prim: /home/zyrv/vulsim/workload.cpp:109:19-109:31
    assign tmp_workload_top_int_64__365_v0 = s8_norm_mux_223_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:110:19-110:31; prim: /home/zyrv/vulsim/workload.cpp:110:19-110:31
    assign tmp_workload_top_int_128__369_v0 = (__beopt_width_872 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:33; prim: /home/zyrv/vulsim/workload.cpp:100:5-100:67
    assign s8_norm_mul_228_v0 = ({128'h0, mul_precision_273}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__374_v0 = (__beopt_width_873 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:33; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:33
    assign s8_norm_mul_232_v0 = ({193'h0, mul_precision_276}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_232_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:113:5-113:49; prim: /home/zyrv/vulsim/workload.cpp:113:20-113:48
    assign s8_norm_mul_237_v0 = ({129'h0, mul_precision_279}); // decl: <none>; prim: <none>
    assign n76_v0 = s8_norm_mul_237_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:115:5-115:49; prim: /home/zyrv/vulsim/workload.cpp:115:20-115:48
    assign tmp_workload_top_int_129__385_v0 = (__beopt_width_876 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:33; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    assign s8_norm_sub_240_v0 = (tmp_workload_top_int_129__385_v0 - n76_v0); // decl: /home/zyrv/vulsim/workload.cpp:116:20-116:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:39
    assign s8_norm_cmp_242_v0 = (s8_norm_sub_240_v0 < 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:117:21-117:39; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    assign s8_norm_sub_244_v0 = (s8_norm_sub_240_v0 - 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:117:50-117:68; prim: /home/zyrv/vulsim/workload.cpp:116:20-116:33
    assign s8_norm_mux_245_v0 = (s8_norm_cmp_242_v0 ? s8_norm_sub_240_v0 : s8_norm_sub_244_v0); // decl: /home/zyrv/vulsim/workload.cpp:117:20-117:69; prim: /home/zyrv/vulsim/workload.cpp:117:20-117:69
    assign tmp_workload_top_int_65__398_v0 = (s8_norm_mux_132_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:67
    assign tmp_workload_top_int_65__400_v0 = (__beopt_width_877 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:119:34-119:46; prim: /home/zyrv/vulsim/workload.cpp:117:5-117:70
    assign s8_norm_add_249_v0 = (tmp_workload_top_int_65__398_v0 + tmp_workload_top_int_65__400_v0); // decl: /home/zyrv/vulsim/workload.cpp:119:19-119:46; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:46
    assign s8_norm_cmp_251_v0 = (s8_norm_add_249_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:120:20-120:37; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    assign s8_norm_sub_253_v0 = (s8_norm_add_249_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:120:48-120:65; prim: /home/zyrv/vulsim/workload.cpp:119:19-119:31
    assign s8_norm_mux_254_v0 = (s8_norm_cmp_251_v0 ? s8_norm_add_249_v0 : s8_norm_sub_253_v0); // decl: /home/zyrv/vulsim/workload.cpp:120:19-120:66; prim: /home/zyrv/vulsim/workload.cpp:120:19-120:66
    assign s8_norm_add_257_v0 = (tmp_workload_top_int_65__398_v0 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:45; prim: /home/zyrv/vulsim/workload.cpp:83:19-83:31
    assign s8_norm_sub_259_v0 = (s8_norm_add_257_v0 - tmp_workload_top_int_65__400_v0); // decl: /home/zyrv/vulsim/workload.cpp:121:19-121:60; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:60
    assign s8_norm_cmp_261_v0 = (s8_norm_sub_259_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:122:20-122:37; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    assign s8_norm_sub_263_v0 = (s8_norm_sub_259_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:122:48-122:65; prim: /home/zyrv/vulsim/workload.cpp:121:19-121:45
    assign s8_norm_mux_264_v0 = (s8_norm_cmp_261_v0 ? s8_norm_sub_259_v0 : s8_norm_sub_263_v0); // decl: /home/zyrv/vulsim/workload.cpp:122:19-122:66; prim: /home/zyrv/vulsim/workload.cpp:122:19-122:66
    assign tmp_workload_top_int_64__427_v0 = s8_norm_mux_254_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:123:19-123:31; prim: /home/zyrv/vulsim/workload.cpp:123:19-123:31
    assign tmp_workload_top_int_64__429_v0 = s8_norm_mux_264_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:124:19-124:31; prim: /home/zyrv/vulsim/workload.cpp:124:19-124:31
    assign tmp_workload_top_int_128__433_v0 = (__beopt_width_879 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:33; prim: /home/zyrv/vulsim/workload.cpp:88:5-88:67
    assign s8_norm_mul_269_v0 = ({143'h0, mul_precision_282}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__438_v0 = (__beopt_width_880 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:33; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:33
    assign s8_norm_mul_273_v0 = ({193'h0, mul_precision_285}); // decl: <none>; prim: <none>
    assign n88_v0 = s8_norm_mul_273_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:127:5-127:49; prim: /home/zyrv/vulsim/workload.cpp:127:20-127:48
    assign s8_norm_mul_278_v0 = ({129'h0, mul_precision_288}); // decl: <none>; prim: <none>
    assign n90_v0 = s8_norm_mul_278_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:129:5-129:49; prim: /home/zyrv/vulsim/workload.cpp:129:20-129:48
    assign tmp_workload_top_int_129__449_v0 = (__beopt_width_883 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:33; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    assign s8_norm_sub_281_v0 = (tmp_workload_top_int_129__449_v0 - n90_v0); // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
    assign s8_norm_cmp_283_v0 = (rtlzz_pipe_167_s15 < 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:131:21-131:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    assign s8_norm_sub_285_v0 = (rtlzz_pipe_167_s15 - 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:131:50-131:68; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:33
    assign s8_norm_mux_286_v0 = (s8_norm_cmp_283_v0 ? rtlzz_pipe_167_s15 : s8_norm_sub_285_v0); // decl: /home/zyrv/vulsim/workload.cpp:131:20-131:69; prim: /home/zyrv/vulsim/workload.cpp:131:20-131:69
    assign tmp_workload_top_int_65__462_v0 = (s8_norm_mux_101_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:31; prim: /home/zyrv/vulsim/workload.cpp:68:5-68:67
    assign tmp_workload_top_int_65__464_v0 = (__beopt_width_884 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:133:34-133:46; prim: /home/zyrv/vulsim/workload.cpp:131:5-131:70
    assign s8_norm_add_290_v0 = (tmp_workload_top_int_65__462_v0 + tmp_workload_top_int_65__464_v0); // decl: /home/zyrv/vulsim/workload.cpp:133:19-133:46; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:46
    assign s8_norm_cmp_292_v0 = (s8_norm_add_290_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:134:20-134:37; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    assign s8_norm_sub_294_v0 = (s8_norm_add_290_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:134:48-134:65; prim: /home/zyrv/vulsim/workload.cpp:133:19-133:31
    assign s8_norm_mux_295_v0 = (s8_norm_cmp_292_v0 ? s8_norm_add_290_v0 : s8_norm_sub_294_v0); // decl: /home/zyrv/vulsim/workload.cpp:134:19-134:66; prim: /home/zyrv/vulsim/workload.cpp:134:19-134:66
    assign s8_norm_add_298_v0 = (tmp_workload_top_int_65__462_v0 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:45; prim: /home/zyrv/vulsim/workload.cpp:70:19-70:31
    assign s8_norm_sub_300_v0 = (s8_norm_add_298_v0 - tmp_workload_top_int_65__464_v0); // decl: /home/zyrv/vulsim/workload.cpp:135:19-135:60; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:60
    assign s8_norm_cmp_302_v0 = (s8_norm_sub_300_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:136:20-136:37; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    assign s8_norm_sub_304_v0 = (s8_norm_sub_300_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:136:48-136:65; prim: /home/zyrv/vulsim/workload.cpp:135:19-135:45
    assign s8_norm_mux_305_v0 = (s8_norm_cmp_302_v0 ? s8_norm_sub_300_v0 : s8_norm_sub_304_v0); // decl: /home/zyrv/vulsim/workload.cpp:136:19-136:66; prim: /home/zyrv/vulsim/workload.cpp:136:19-136:66
    assign tmp_workload_top_int_64__491_v0 = s8_norm_mux_295_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:137:19-137:31; prim: /home/zyrv/vulsim/workload.cpp:137:19-137:31
    assign tmp_workload_top_int_64__493_v0 = s8_norm_mux_305_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:138:19-138:31; prim: /home/zyrv/vulsim/workload.cpp:138:19-138:31
    assign tmp_workload_top_int_128__497_v0 = (__beopt_width_886 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:34; prim: /home/zyrv/vulsim/workload.cpp:102:5-102:67
    assign s8_norm_mul_310_v0 = ({128'h0, mul_precision_291}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__502_v0 = (__beopt_width_887 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:35; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:35
    assign s8_norm_mul_314_v0 = ({193'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign n102_v0 = s8_norm_mul_314_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:141:5-141:51; prim: /home/zyrv/vulsim/workload.cpp:141:21-141:50
    assign s8_norm_mul_319_v0 = ({129'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign n104_v0 = s8_norm_mul_319_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:143:5-143:51; prim: /home/zyrv/vulsim/workload.cpp:143:21-143:50
    assign tmp_workload_top_int_129__513_v0 = (__beopt_width_890 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:35; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    assign s8_norm_sub_322_v0 = (tmp_workload_top_int_129__513_v0 - n104_v0); // decl: /home/zyrv/vulsim/workload.cpp:144:21-144:42; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:42
    assign s8_norm_cmp_324_v0 = (s8_norm_sub_322_v0 < 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:145:22-145:41; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    assign s8_norm_sub_326_v0 = (s8_norm_sub_322_v0 - 129'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:145:53-145:72; prim: /home/zyrv/vulsim/workload.cpp:144:21-144:35
    assign s8_norm_mux_327_v0 = (s8_norm_cmp_324_v0 ? s8_norm_sub_322_v0 : s8_norm_sub_326_v0); // decl: /home/zyrv/vulsim/workload.cpp:145:21-145:73; prim: /home/zyrv/vulsim/workload.cpp:145:21-145:73
    assign tmp_workload_top_int_65__526_v0 = (s8_norm_mux_142_v0 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:32; prim: /home/zyrv/vulsim/workload.cpp:82:5-82:67
    assign tmp_workload_top_int_65__528_v0 = (__beopt_width_891 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:147:35-147:48; prim: /home/zyrv/vulsim/workload.cpp:145:5-145:74
    assign s8_norm_add_331_v0 = (tmp_workload_top_int_65__526_v0 + tmp_workload_top_int_65__528_v0); // decl: /home/zyrv/vulsim/workload.cpp:147:20-147:48; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:48
    assign s8_norm_cmp_333_v0 = (s8_norm_add_331_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:148:21-148:39; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    assign s8_norm_sub_335_v0 = (s8_norm_add_331_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:148:51-148:69; prim: /home/zyrv/vulsim/workload.cpp:147:20-147:32
    assign s8_norm_mux_336_v0 = (s8_norm_cmp_333_v0 ? s8_norm_add_331_v0 : s8_norm_sub_335_v0); // decl: /home/zyrv/vulsim/workload.cpp:148:20-148:70; prim: /home/zyrv/vulsim/workload.cpp:148:20-148:70
    assign s8_norm_add_339_v0 = (tmp_workload_top_int_65__526_v0 + 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:46; prim: /home/zyrv/vulsim/workload.cpp:84:19-84:31
    assign s8_norm_sub_341_v0 = (s8_norm_add_339_v0 - tmp_workload_top_int_65__528_v0); // decl: /home/zyrv/vulsim/workload.cpp:149:20-149:62; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:62
    assign s8_norm_cmp_343_v0 = (s8_norm_sub_341_v0 < 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:150:21-150:39; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    assign s8_norm_sub_345_v0 = (s8_norm_sub_341_v0 - 65'hffffffff00000001); // decl: /home/zyrv/vulsim/workload.cpp:150:51-150:69; prim: /home/zyrv/vulsim/workload.cpp:149:20-149:46
    assign s8_norm_mux_346_v0 = (s8_norm_cmp_343_v0 ? s8_norm_sub_341_v0 : s8_norm_sub_345_v0); // decl: /home/zyrv/vulsim/workload.cpp:150:20-150:70; prim: /home/zyrv/vulsim/workload.cpp:150:20-150:70
    assign tmp_workload_top_int_64__555_v0 = s8_norm_mux_336_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:151:20-151:33; prim: /home/zyrv/vulsim/workload.cpp:151:20-151:33
    assign tmp_workload_top_int_64__557_v0 = s8_norm_mux_346_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:152:20-152:33; prim: /home/zyrv/vulsim/workload.cpp:152:20-152:33
    assign y0 = tmp_workload_top_int_64__363_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:153:5-153:13
    assign y1 = tmp_workload_top_int_64__427_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:154:5-154:13
    assign y2 = tmp_workload_top_int_64__491_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:155:5-155:13
    assign y3 = tmp_workload_top_int_64__555_v0; // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:156:5-156:14
    assign y4 = tmp_workload_top_int_64__365_v0; // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:157:5-157:13
    assign y5 = tmp_workload_top_int_64__429_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:158:5-158:13
    assign y6 = tmp_workload_top_int_64__493_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:159:5-159:13
    assign y7 = tmp_workload_top_int_64__557_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:160:5-160:14
    assign ov = rtlzz_valid_s15; // decl: <none>; prim: <none>
    assign __beopt_width_858 = ({63'h0, s8_norm_mux_41_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_859 = s8_norm_mul_106_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_860 = n34_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_862 = s8_norm_mul_106_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_863 = s8_norm_mux_123_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_865 = ({63'h0, s8_norm_mux_81_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_866 = s8_norm_mul_167_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_867 = n54_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_869 = s8_norm_mul_167_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_870 = s8_norm_mux_184_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_872 = ({63'h0, s8_norm_mux_193_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_873 = s8_norm_mul_228_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_874 = n74_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_876 = s8_norm_mul_228_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_877 = s8_norm_mux_245_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_879 = ({63'h0, s8_norm_mux_162_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_880 = s8_norm_mul_269_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_881 = n88_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_883 = s8_norm_mul_269_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_884 = s8_norm_mux_286_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_886 = ({63'h0, s8_norm_mux_203_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_887 = s8_norm_mul_310_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_888 = n102_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_890 = s8_norm_mul_310_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_891 = s8_norm_mux_327_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_255 = (__beopt_width_256 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:36-73:48
    assign __beopt_width_259 = (__beopt_width_260 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:36-93:48
    assign __beopt_width_263 = (__beopt_width_264 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:113:36-113:48
    assign __beopt_width_268 = (__beopt_width_267 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:127:36-127:48
    assign __beopt_width_272 = (__beopt_width_271 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:141:38-141:50
    assign __beopt_width_256 = ({64'h0, __beopt_width_860}); // decl: <none>; prim: <none>
    assign __beopt_width_260 = ({64'h0, __beopt_width_867}); // decl: <none>; prim: <none>
    assign __beopt_width_264 = ({64'h0, __beopt_width_874}); // decl: <none>; prim: <none>
    assign __beopt_width_267 = ({64'h0, __beopt_width_881}); // decl: <none>; prim: <none>
    assign __beopt_width_271 = ({64'h0, __beopt_width_888}); // decl: <none>; prim: <none>
    assign mul_precision_253 = tmp_workload_top_int_128__175_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_254 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_255 = arith_original_298; // decl: <none>; prim: <none>
    assign mul_precision_256 = tmp_workload_top_int_193__180_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_257 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_258 = arith_original_299; // decl: <none>; prim: <none>
    assign mul_precision_259 = __beopt_width_255[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_260 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_261 = arith_original_300; // decl: <none>; prim: <none>
    assign mul_precision_262 = tmp_workload_top_int_128__272_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_263 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_264 = arith_original_301; // decl: <none>; prim: <none>
    assign mul_precision_265 = tmp_workload_top_int_193__277_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_266 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_267 = arith_original_302; // decl: <none>; prim: <none>
    assign mul_precision_268 = __beopt_width_259[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_269 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_270 = arith_original_303; // decl: <none>; prim: <none>
    assign mul_precision_271 = tmp_workload_top_int_128__369_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_272 = 64'((128'hfffffffeff000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_273 = arith_original_304; // decl: <none>; prim: <none>
    assign mul_precision_274 = tmp_workload_top_int_193__374_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_275 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_276 = arith_original_305; // decl: <none>; prim: <none>
    assign mul_precision_277 = __beopt_width_263[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_278 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_279 = arith_original_306; // decl: <none>; prim: <none>
    assign mul_precision_280 = tmp_workload_top_int_128__433_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_281 = 49'((128'h1000000000000) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_282 = arith_original_307; // decl: <none>; prim: <none>
    assign mul_precision_283 = tmp_workload_top_int_193__438_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_284 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_285 = arith_original_308; // decl: <none>; prim: <none>
    assign mul_precision_286 = __beopt_width_268[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_287 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_288 = arith_original_309; // decl: <none>; prim: <none>
    assign mul_precision_289 = tmp_workload_top_int_128__497_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_290 = 64'((128'hfffffeff00000101) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_291 = arith_original_310; // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_193__502_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = 65'((193'h100000000ffffffff) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_311; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_272[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = 64'((129'hffffffff00000001) >> 0); // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_312; // decl: <none>; prim: <none>
    assign arith_original_298 = 113'(($unsigned(113'($unsigned(mul_precision_253))) * $unsigned(113'($unsigned(mul_precision_254))))); // decl: /home/zyrv/vulsim/workload.cpp:72:20-72:49; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:31
    assign arith_original_299 = 193'(($unsigned(193'($unsigned(mul_precision_256))) * $unsigned(193'($unsigned(mul_precision_257))))); // decl: /home/zyrv/vulsim/workload.cpp:73:20-73:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    assign arith_original_300 = 129'(($unsigned(129'($unsigned(mul_precision_259))) * $unsigned(129'($unsigned(mul_precision_260))))); // decl: /home/zyrv/vulsim/workload.cpp:75:20-75:48; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:22
    assign arith_original_301 = 113'(($unsigned(113'($unsigned(mul_precision_262))) * $unsigned(113'($unsigned(mul_precision_263))))); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:49; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:31
    assign arith_original_302 = 193'(($unsigned(193'($unsigned(mul_precision_265))) * $unsigned(193'($unsigned(mul_precision_266))))); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    assign arith_original_303 = 129'(($unsigned(129'($unsigned(mul_precision_268))) * $unsigned(129'($unsigned(mul_precision_269))))); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:48; prim: /home/zyrv/vulsim/workload.cpp:94:19-94:22
    assign arith_original_304 = 128'(($unsigned(128'($unsigned(mul_precision_271))) * $unsigned(128'($unsigned(mul_precision_272))))); // decl: /home/zyrv/vulsim/workload.cpp:112:20-112:49; prim: /home/zyrv/vulsim/workload.cpp:103:19-103:31
    assign arith_original_305 = 193'(($unsigned(193'($unsigned(mul_precision_274))) * $unsigned(193'($unsigned(mul_precision_275))))); // decl: /home/zyrv/vulsim/workload.cpp:113:20-113:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    assign arith_original_306 = 129'(($unsigned(129'($unsigned(mul_precision_277))) * $unsigned(129'($unsigned(mul_precision_278))))); // decl: /home/zyrv/vulsim/workload.cpp:115:20-115:48; prim: /home/zyrv/vulsim/workload.cpp:114:19-114:22
    assign arith_original_307 = 113'(($unsigned(113'($unsigned(mul_precision_280))) * $unsigned(113'($unsigned(mul_precision_281))))); // decl: /home/zyrv/vulsim/workload.cpp:126:20-126:49; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:31
    assign arith_original_308 = 193'(($unsigned(193'($unsigned(mul_precision_283))) * $unsigned(193'($unsigned(mul_precision_284))))); // decl: /home/zyrv/vulsim/workload.cpp:127:20-127:48; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    assign arith_original_309 = 129'(($unsigned(129'($unsigned(mul_precision_286))) * $unsigned(129'($unsigned(mul_precision_287))))); // decl: /home/zyrv/vulsim/workload.cpp:129:20-129:48; prim: /home/zyrv/vulsim/workload.cpp:128:19-128:22
    assign arith_original_310 = 128'(($unsigned(128'($unsigned(mul_precision_289))) * $unsigned(128'($unsigned(mul_precision_290))))); // decl: /home/zyrv/vulsim/workload.cpp:140:21-140:51; prim: /home/zyrv/vulsim/workload.cpp:104:19-104:31
    assign arith_original_311 = 193'(($unsigned(193'($unsigned(mul_precision_292))) * $unsigned(193'($unsigned(mul_precision_293))))); // decl: /home/zyrv/vulsim/workload.cpp:141:21-141:50; prim: /home/zyrv/vulsim/workload.cpp:40:5-40:67
    assign arith_original_312 = 129'(($unsigned(129'($unsigned(mul_precision_295))) * $unsigned(129'($unsigned(mul_precision_296))))); // decl: /home/zyrv/vulsim/workload.cpp:143:21-143:50; prim: /home/zyrv/vulsim/workload.cpp:142:20-142:24
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_9_s1 <= 65'h0;
            rtlzz_pipe_9_s2 <= 65'h0;
            rtlzz_pipe_9_s3 <= 65'h0;
            rtlzz_pipe_9_s4 <= 65'h0;
            rtlzz_pipe_10_s1 <= 65'h0;
            rtlzz_pipe_10_s2 <= 65'h0;
            rtlzz_pipe_10_s3 <= 65'h0;
            rtlzz_pipe_10_s4 <= 65'h0;
            rtlzz_pipe_10_s5 <= 65'h0;
            rtlzz_pipe_11_s1 <= 65'h0;
            rtlzz_pipe_11_s2 <= 65'h0;
            rtlzz_pipe_11_s3 <= 65'h0;
            rtlzz_pipe_12_s2 <= 1'h1;
            rtlzz_pipe_12_s3 <= 1'h1;
            rtlzz_pipe_13_s3 <= 65'h100000000ffffffff;
            rtlzz_pipe_15_s5 <= 65'hffffffff00000001;
            rtlzz_pipe_16_s6 <= 65'hffffffff00000001;
            rtlzz_pipe_16_s7 <= 65'hffffffff00000001;
            rtlzz_pipe_16_s8 <= 65'hffffffff00000001;
            rtlzz_pipe_17_s7 <= 1'h0;
            rtlzz_pipe_17_s8 <= 1'h0;
            rtlzz_pipe_18_s8 <= 65'h0;
            rtlzz_pipe_20_s1 <= 65'h0;
            rtlzz_pipe_20_s2 <= 65'h0;
            rtlzz_pipe_20_s3 <= 65'h0;
            rtlzz_pipe_20_s4 <= 65'h0;
            rtlzz_pipe_20_s5 <= 65'h0;
            rtlzz_pipe_20_s6 <= 65'h0;
            rtlzz_pipe_20_s7 <= 65'h0;
            rtlzz_pipe_20_s8 <= 65'h0;
            rtlzz_pipe_20_s9 <= 65'h0;
            rtlzz_pipe_20_s10 <= 65'h0;
            rtlzz_pipe_20_s11 <= 65'h0;
            rtlzz_pipe_20_s12 <= 65'h0;
            rtlzz_pipe_20_s13 <= 65'h0;
            rtlzz_pipe_21_s1 <= 65'h0;
            rtlzz_pipe_21_s2 <= 65'h0;
            rtlzz_pipe_21_s3 <= 65'h0;
            rtlzz_pipe_21_s4 <= 65'h0;
            rtlzz_pipe_21_s5 <= 65'h0;
            rtlzz_pipe_21_s6 <= 65'h0;
            rtlzz_pipe_21_s7 <= 65'h0;
            rtlzz_pipe_21_s8 <= 65'h0;
            rtlzz_pipe_21_s9 <= 65'h0;
            rtlzz_pipe_21_s10 <= 65'h0;
            rtlzz_pipe_21_s11 <= 65'h0;
            rtlzz_pipe_21_s12 <= 65'h0;
            rtlzz_pipe_21_s13 <= 65'h0;
            rtlzz_pipe_21_s14 <= 65'h0;
            rtlzz_pipe_22_s10 <= 65'h0;
            rtlzz_pipe_22_s11 <= 65'h0;
            rtlzz_pipe_22_s12 <= 65'h0;
            rtlzz_pipe_23_s11 <= 1'h1;
            rtlzz_pipe_23_s12 <= 1'h1;
            rtlzz_pipe_24_s12 <= 65'h100000000ffffffff;
            rtlzz_pipe_26_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_27_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_28_s15 <= 1'h0;
            rtlzz_pipe_31_s1 <= 65'h0;
            rtlzz_pipe_31_s2 <= 65'h0;
            rtlzz_pipe_31_s3 <= 65'h0;
            rtlzz_pipe_31_s4 <= 65'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_33_s1 <= 65'h0;
            rtlzz_pipe_33_s2 <= 65'h0;
            rtlzz_pipe_33_s3 <= 65'h0;
            rtlzz_pipe_34_s2 <= 1'h1;
            rtlzz_pipe_34_s3 <= 1'h1;
            rtlzz_pipe_35_s3 <= 65'h100000000ffffffff;
            rtlzz_pipe_36_s4 <= 65'h0;
            rtlzz_pipe_36_s5 <= 65'h0;
            rtlzz_pipe_37_s5 <= 65'hffffffff00000001;
            rtlzz_pipe_38_s6 <= 65'hffffffff00000001;
            rtlzz_pipe_38_s7 <= 65'hffffffff00000001;
            rtlzz_pipe_38_s8 <= 65'hffffffff00000001;
            rtlzz_pipe_39_s7 <= 1'h0;
            rtlzz_pipe_39_s8 <= 1'h0;
            rtlzz_pipe_40_s8 <= 65'h0;
            rtlzz_pipe_41_s9 <= 65'h0;
            rtlzz_pipe_41_s10 <= 65'h0;
            rtlzz_pipe_42_s1 <= 65'h0;
            rtlzz_pipe_42_s2 <= 65'h0;
            rtlzz_pipe_42_s3 <= 65'h0;
            rtlzz_pipe_42_s4 <= 65'h0;
            rtlzz_pipe_42_s5 <= 65'h0;
            rtlzz_pipe_42_s6 <= 65'h0;
            rtlzz_pipe_42_s7 <= 65'h0;
            rtlzz_pipe_42_s8 <= 65'h0;
            rtlzz_pipe_42_s9 <= 65'h0;
            rtlzz_pipe_42_s10 <= 65'h0;
            rtlzz_pipe_42_s11 <= 65'h0;
            rtlzz_pipe_42_s12 <= 65'h0;
            rtlzz_pipe_43_s1 <= 65'h0;
            rtlzz_pipe_43_s2 <= 65'h0;
            rtlzz_pipe_43_s3 <= 65'h0;
            rtlzz_pipe_43_s4 <= 65'h0;
            rtlzz_pipe_43_s5 <= 65'h0;
            rtlzz_pipe_43_s6 <= 65'h0;
            rtlzz_pipe_43_s7 <= 65'h0;
            rtlzz_pipe_43_s8 <= 65'h0;
            rtlzz_pipe_43_s9 <= 65'h0;
            rtlzz_pipe_43_s10 <= 65'h0;
            rtlzz_pipe_43_s11 <= 65'h0;
            rtlzz_pipe_43_s12 <= 65'h0;
            rtlzz_pipe_44_s10 <= 65'h0;
            rtlzz_pipe_44_s11 <= 65'h0;
            rtlzz_pipe_44_s12 <= 65'h0;
            rtlzz_pipe_44_s13 <= 65'h0;
            rtlzz_pipe_45_s11 <= 1'h1;
            rtlzz_pipe_45_s12 <= 1'h1;
            rtlzz_pipe_45_s13 <= 1'h1;
            rtlzz_pipe_46_s12 <= 65'h100000000ffffffff;
            rtlzz_pipe_46_s13 <= 65'h100000000ffffffff;
            rtlzz_pipe_49_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_49_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_49_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_50_s14 <= 1'h0;
            rtlzz_pipe_50_s15 <= 1'h0;
            rtlzz_pipe_51_s15 <= 65'h0;
            rtlzz_pipe_53_s4 <= 65'h0;
            rtlzz_pipe_53_s5 <= 65'h0;
            rtlzz_pipe_53_s6 <= 65'h0;
            rtlzz_pipe_53_s7 <= 65'h0;
            rtlzz_pipe_53_s8 <= 65'h0;
            rtlzz_pipe_53_s9 <= 65'h0;
            rtlzz_pipe_53_s10 <= 65'h0;
            rtlzz_pipe_53_s11 <= 65'h0;
            rtlzz_pipe_53_s12 <= 65'h0;
            rtlzz_pipe_53_s13 <= 65'h0;
            rtlzz_pipe_54_s13 <= 65'h0;
            rtlzz_pipe_55_s14 <= 65'h0;
            rtlzz_pipe_55_s15 <= 65'h0;
            rtlzz_pipe_56_s14 <= 1'h1;
            rtlzz_pipe_56_s15 <= 1'h1;
            rtlzz_pipe_57_s15 <= 65'h100000000ffffffff;
            rtlzz_pipe_59_s5 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s6 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s7 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s8 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s9 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s10 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_59_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_60_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_61_s15 <= 1'h0;
            rtlzz_pipe_62_s13 <= 65'h0;
            rtlzz_pipe_62_s14 <= 65'h0;
            rtlzz_pipe_62_s15 <= 65'h0;
            rtlzz_pipe_76_s9 <= 65'h0;
            rtlzz_pipe_76_s10 <= 65'h0;
            rtlzz_pipe_76_s11 <= 65'h0;
            rtlzz_pipe_76_s12 <= 65'h0;
            rtlzz_pipe_76_s13 <= 65'h0;
            rtlzz_pipe_76_s14 <= 65'h0;
            rtlzz_pipe_76_s15 <= 65'h0;
            rtlzz_pipe_82_s10 <= 65'hffffffff00000001;
            rtlzz_pipe_82_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_82_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_82_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_82_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_82_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_87_s6 <= 65'h0;
            rtlzz_pipe_87_s7 <= 65'h0;
            rtlzz_pipe_87_s8 <= 65'h0;
            rtlzz_pipe_87_s9 <= 65'h0;
            rtlzz_pipe_87_s10 <= 65'h0;
            rtlzz_pipe_87_s11 <= 65'h0;
            rtlzz_pipe_87_s12 <= 65'h0;
            rtlzz_pipe_87_s13 <= 65'h0;
            rtlzz_pipe_87_s14 <= 65'h0;
            rtlzz_pipe_88_s14 <= 65'h0;
            rtlzz_pipe_89_s15 <= 65'h0;
            rtlzz_pipe_90_s15 <= 1'h1;
            rtlzz_pipe_93_s7 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s8 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s9 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s10 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s11 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_93_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_94_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_95_s14 <= 1'h0;
            rtlzz_pipe_110_s11 <= 65'h0;
            rtlzz_pipe_110_s12 <= 65'h0;
            rtlzz_pipe_110_s13 <= 65'h0;
            rtlzz_pipe_110_s14 <= 65'h0;
            rtlzz_pipe_110_s15 <= 65'h0;
            rtlzz_pipe_116_s12 <= 65'hffffffff00000001;
            rtlzz_pipe_116_s13 <= 65'hffffffff00000001;
            rtlzz_pipe_116_s14 <= 65'hffffffff00000001;
            rtlzz_pipe_116_s15 <= 65'hffffffff00000001;
            rtlzz_pipe_167_s15 <= 129'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
            rtlzz_valid_s8 <= 1'h0;
            rtlzz_valid_s9 <= 1'h0;
            rtlzz_valid_s10 <= 1'h0;
            rtlzz_valid_s11 <= 1'h0;
            rtlzz_valid_s12 <= 1'h0;
            rtlzz_valid_s13 <= 1'h0;
            rtlzz_valid_s14 <= 1'h0;
            rtlzz_valid_s15 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_9_s1 <= tmp_workload_top_int_65__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_9_s2 <= rtlzz_pipe_9_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_9_s3 <= rtlzz_pipe_9_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_9_s4 <= rtlzz_pipe_9_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:29; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (iv) begin
        rtlzz_pipe_10_s1 <= tmp_workload_top_int_65__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= rtlzz_pipe_10_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_10_s3 <= rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_10_s4 <= rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_10_s5 <= rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:41:32-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:32-41:43
        end
        if (iv) begin
        rtlzz_pipe_11_s1 <= s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_11_s3 <= rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/workload.cpp:41:18-41:43; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:43
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:42:19-42:35; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_13_s3 <= s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:42:45-42:61; prim: /home/zyrv/vulsim/workload.cpp:41:18-41:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_15_s5 <= s8_norm_add_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:43; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_16_s6 <= s8_norm_sub_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_16_s7 <= rtlzz_pipe_16_s6; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_16_s8 <= rtlzz_pipe_16_s7; // decl: /home/zyrv/vulsim/workload.cpp:43:18-43:57; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:57
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_17_s7 <= s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_17_s8 <= rtlzz_pipe_17_s7; // decl: /home/zyrv/vulsim/workload.cpp:44:19-44:35; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_18_s8 <= s8_norm_sub_20_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:45-44:61; prim: /home/zyrv/vulsim/workload.cpp:43:18-43:43
        end
        if (iv) begin
        rtlzz_pipe_20_s1 <= tmp_workload_top_int_65__41_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_20_s2 <= rtlzz_pipe_20_s1; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_20_s3 <= rtlzz_pipe_20_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_20_s4 <= rtlzz_pipe_20_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_20_s5 <= rtlzz_pipe_20_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_20_s6 <= rtlzz_pipe_20_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_20_s7 <= rtlzz_pipe_20_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_20_s8 <= rtlzz_pipe_20_s7; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_20_s9 <= rtlzz_pipe_20_s8; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_20_s10 <= rtlzz_pipe_20_s9; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_20_s11 <= rtlzz_pipe_20_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_20_s12 <= rtlzz_pipe_20_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_20_s13 <= rtlzz_pipe_20_s12; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:29; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= tmp_workload_top_int_65__43_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_21_s2 <= rtlzz_pipe_21_s1; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_21_s3 <= rtlzz_pipe_21_s2; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_21_s4 <= rtlzz_pipe_21_s3; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_21_s5 <= rtlzz_pipe_21_s4; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_21_s6 <= rtlzz_pipe_21_s5; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_21_s7 <= rtlzz_pipe_21_s6; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_21_s8 <= rtlzz_pipe_21_s7; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_21_s9 <= rtlzz_pipe_21_s8; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_21_s10 <= rtlzz_pipe_21_s9; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_21_s11 <= rtlzz_pipe_21_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_21_s12 <= rtlzz_pipe_21_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_21_s13 <= rtlzz_pipe_21_s12; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_21_s14 <= rtlzz_pipe_21_s13; // decl: /home/zyrv/vulsim/workload.cpp:47:32-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:32-47:43
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_22_s10 <= s8_norm_add_26_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_22_s11 <= rtlzz_pipe_22_s10; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_22_s12 <= rtlzz_pipe_22_s11; // decl: /home/zyrv/vulsim/workload.cpp:47:18-47:43; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:43
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_23_s11 <= s8_norm_cmp_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_23_s12 <= rtlzz_pipe_23_s11; // decl: /home/zyrv/vulsim/workload.cpp:48:19-48:35; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_24_s12 <= s8_norm_sub_30_v0; // decl: /home/zyrv/vulsim/workload.cpp:48:45-48:61; prim: /home/zyrv/vulsim/workload.cpp:47:18-47:29
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_26_s14 <= s8_norm_add_34_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_27_s15 <= s8_norm_sub_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:49:19-49:58; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:58
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_28_s15 <= s8_norm_cmp_38_v0; // decl: /home/zyrv/vulsim/workload.cpp:50:20-50:37; prim: /home/zyrv/vulsim/workload.cpp:49:19-49:44
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= tmp_workload_top_int_65__74_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= rtlzz_pipe_31_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_31_s3 <= rtlzz_pipe_31_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= rtlzz_pipe_31_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:30; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= tmp_workload_top_int_65__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: /home/zyrv/vulsim/workload.cpp:53:33-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:33-53:44
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= s8_norm_add_46_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:44; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_34_s2 <= s8_norm_cmp_48_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= rtlzz_pipe_34_s2; // decl: /home/zyrv/vulsim/workload.cpp:54:20-54:37; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= s8_norm_sub_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:48-54:65; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_36_s4 <= s8_norm_mux_51_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= rtlzz_pipe_36_s4; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:66; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:66
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_37_s5 <= s8_norm_add_54_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:44; prim: /home/zyrv/vulsim/workload.cpp:39:5-39:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_38_s6 <= s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_38_s7 <= rtlzz_pipe_38_s6; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_38_s8 <= rtlzz_pipe_38_s7; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:58; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_39_s7 <= s8_norm_cmp_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_39_s8 <= rtlzz_pipe_39_s7; // decl: /home/zyrv/vulsim/workload.cpp:56:20-56:37; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_40_s8 <= s8_norm_sub_60_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:48-56:65; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:44
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_41_s9 <= s8_norm_mux_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_41_s10 <= rtlzz_pipe_41_s9; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:66; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:66
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= tmp_workload_top_int_65__107_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= rtlzz_pipe_42_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_42_s4 <= rtlzz_pipe_42_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_42_s5 <= rtlzz_pipe_42_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_42_s6 <= rtlzz_pipe_42_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_42_s7 <= rtlzz_pipe_42_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_42_s8 <= rtlzz_pipe_42_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_42_s9 <= rtlzz_pipe_42_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_42_s10 <= rtlzz_pipe_42_s9; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_42_s11 <= rtlzz_pipe_42_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_42_s12 <= rtlzz_pipe_42_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:30; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= tmp_workload_top_int_65__109_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= rtlzz_pipe_43_s1; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_43_s3 <= rtlzz_pipe_43_s2; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_43_s4 <= rtlzz_pipe_43_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_43_s5 <= rtlzz_pipe_43_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_43_s6 <= rtlzz_pipe_43_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_43_s7 <= rtlzz_pipe_43_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_43_s8 <= rtlzz_pipe_43_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_43_s9 <= rtlzz_pipe_43_s8; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_43_s10 <= rtlzz_pipe_43_s9; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_43_s11 <= rtlzz_pipe_43_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_43_s12 <= rtlzz_pipe_43_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:33-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:33-59:44
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_44_s10 <= s8_norm_add_66_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_44_s11 <= rtlzz_pipe_44_s10; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_44_s12 <= rtlzz_pipe_44_s11; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_44_s13 <= rtlzz_pipe_44_s12; // decl: /home/zyrv/vulsim/workload.cpp:59:19-59:44; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:44
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_45_s11 <= s8_norm_cmp_68_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_45_s12 <= rtlzz_pipe_45_s11; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_45_s13 <= rtlzz_pipe_45_s12; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:37; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_46_s12 <= s8_norm_sub_70_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_46_s13 <= rtlzz_pipe_46_s12; // decl: /home/zyrv/vulsim/workload.cpp:60:48-60:65; prim: /home/zyrv/vulsim/workload.cpp:59:19-59:30
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_49_s13 <= s8_norm_sub_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_49_s14 <= rtlzz_pipe_49_s13; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_49_s15 <= rtlzz_pipe_49_s14; // decl: /home/zyrv/vulsim/workload.cpp:61:19-61:58; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:58
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_50_s14 <= s8_norm_cmp_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_50_s15 <= rtlzz_pipe_50_s14; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:37; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_51_s15 <= s8_norm_sub_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:48-62:65; prim: /home/zyrv/vulsim/workload.cpp:61:19-61:44
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_53_s4 <= tmp_workload_top_int_65__140_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_53_s5 <= rtlzz_pipe_53_s4; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_53_s6 <= rtlzz_pipe_53_s5; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_53_s7 <= rtlzz_pipe_53_s6; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_53_s8 <= rtlzz_pipe_53_s7; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_53_s9 <= rtlzz_pipe_53_s8; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_53_s10 <= rtlzz_pipe_53_s9; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_53_s11 <= rtlzz_pipe_53_s10; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_53_s12 <= rtlzz_pipe_53_s11; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_53_s13 <= rtlzz_pipe_53_s12; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:30; prim: /home/zyrv/vulsim/workload.cpp:42:5-42:63
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_54_s13 <= tmp_workload_top_int_65__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:33-65:45; prim: /home/zyrv/vulsim/workload.cpp:48:5-48:63
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_55_s14 <= s8_norm_add_86_v0; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_55_s15 <= rtlzz_pipe_55_s14; // decl: /home/zyrv/vulsim/workload.cpp:65:19-65:45; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:45
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_56_s14 <= s8_norm_cmp_88_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_56_s15 <= rtlzz_pipe_56_s14; // decl: /home/zyrv/vulsim/workload.cpp:66:20-66:37; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_57_s15 <= s8_norm_sub_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:66:48-66:65; prim: /home/zyrv/vulsim/workload.cpp:65:19-65:30
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_59_s5 <= s8_norm_add_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_59_s6 <= rtlzz_pipe_59_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_59_s7 <= rtlzz_pipe_59_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_59_s8 <= rtlzz_pipe_59_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_59_s9 <= rtlzz_pipe_59_s8; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_59_s10 <= rtlzz_pipe_59_s9; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_59_s11 <= rtlzz_pipe_59_s10; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_59_s12 <= rtlzz_pipe_59_s11; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:44; prim: /home/zyrv/vulsim/workload.cpp:45:18-45:29
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_60_s13 <= s8_norm_sub_96_v0; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_60_s14 <= rtlzz_pipe_60_s13; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_60_s15 <= rtlzz_pipe_60_s14; // decl: /home/zyrv/vulsim/workload.cpp:67:19-67:59; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:59
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_61_s15 <= s8_norm_cmp_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:20-68:37; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_62_s13 <= s8_norm_sub_100_v0; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_62_s14 <= rtlzz_pipe_62_s13; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_62_s15 <= rtlzz_pipe_62_s14; // decl: /home/zyrv/vulsim/workload.cpp:68:48-68:65; prim: /home/zyrv/vulsim/workload.cpp:67:19-67:44
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_76_s9 <= tmp_workload_top_int_65__204_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_76_s10 <= rtlzz_pipe_76_s9; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_76_s11 <= rtlzz_pipe_76_s10; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_76_s12 <= rtlzz_pipe_76_s11; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_76_s13 <= rtlzz_pipe_76_s12; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_76_s14 <= rtlzz_pipe_76_s13; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_76_s15 <= rtlzz_pipe_76_s14; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:30; prim: /home/zyrv/vulsim/workload.cpp:44:5-44:63
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_82_s10 <= s8_norm_add_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_82_s11 <= rtlzz_pipe_82_s10; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_82_s12 <= rtlzz_pipe_82_s11; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_82_s13 <= rtlzz_pipe_82_s12; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_82_s14 <= rtlzz_pipe_82_s13; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_82_s15 <= rtlzz_pipe_82_s14; // decl: /home/zyrv/vulsim/workload.cpp:81:19-81:44; prim: /home/zyrv/vulsim/workload.cpp:46:18-46:29
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= tmp_workload_top_int_65__237_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_87_s7 <= rtlzz_pipe_87_s6; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_87_s8 <= rtlzz_pipe_87_s7; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_87_s9 <= rtlzz_pipe_87_s8; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_87_s10 <= rtlzz_pipe_87_s9; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_87_s11 <= rtlzz_pipe_87_s10; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_87_s12 <= rtlzz_pipe_87_s11; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_87_s13 <= rtlzz_pipe_87_s12; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_87_s14 <= rtlzz_pipe_87_s13; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:54:5-54:67
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_88_s14 <= tmp_workload_top_int_65__239_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:60:5-60:67
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_89_s15 <= s8_norm_add_147_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_90_s15 <= s8_norm_cmp_149_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:20-86:37; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:31
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_93_s7 <= s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s7) begin
        rtlzz_pipe_93_s8 <= rtlzz_pipe_93_s7; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s8) begin
        rtlzz_pipe_93_s9 <= rtlzz_pipe_93_s8; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s9) begin
        rtlzz_pipe_93_s10 <= rtlzz_pipe_93_s9; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_93_s11 <= rtlzz_pipe_93_s10; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_93_s12 <= rtlzz_pipe_93_s11; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_93_s13 <= rtlzz_pipe_93_s12; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:45; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_94_s14 <= s8_norm_sub_157_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:60; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:60
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_95_s14 <= s8_norm_cmp_159_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:20-88:37; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:45
        end
        if (rtlzz_valid_s10) begin
        rtlzz_pipe_110_s11 <= tmp_workload_top_int_65__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_110_s12 <= rtlzz_pipe_110_s11; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_110_s13 <= rtlzz_pipe_110_s12; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_110_s14 <= rtlzz_pipe_110_s13; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_110_s15 <= rtlzz_pipe_110_s14; // decl: /home/zyrv/vulsim/workload.cpp:99:19-99:31; prim: /home/zyrv/vulsim/workload.cpp:56:5-56:67
        end
        if (rtlzz_valid_s11) begin
        rtlzz_pipe_116_s12 <= s8_norm_add_196_v0; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
        end
        if (rtlzz_valid_s12) begin
        rtlzz_pipe_116_s13 <= rtlzz_pipe_116_s12; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
        end
        if (rtlzz_valid_s13) begin
        rtlzz_pipe_116_s14 <= rtlzz_pipe_116_s13; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_116_s15 <= rtlzz_pipe_116_s14; // decl: /home/zyrv/vulsim/workload.cpp:101:19-101:45; prim: /home/zyrv/vulsim/workload.cpp:58:19-58:31
        end
        if (rtlzz_valid_s14) begin
        rtlzz_pipe_167_s15 <= s8_norm_sub_281_v0; // decl: /home/zyrv/vulsim/workload.cpp:130:20-130:39; prim: /home/zyrv/vulsim/workload.cpp:130:20-130:39
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s8 <= rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s9 <= rtlzz_valid_s8; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s10 <= rtlzz_valid_s9; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s11 <= rtlzz_valid_s10; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s12 <= rtlzz_valid_s11; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s13 <= rtlzz_valid_s12; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s14 <= rtlzz_valid_s13; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        rtlzz_valid_s15 <= rtlzz_valid_s14; // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x0_data,input wire x0_wen,input wire [63:0] x1_data,input wire x1_wen,input wire [63:0] x2_data,input wire x2_wen,input wire [63:0] x3_data,input wire x3_wen,input wire [63:0] x4_data,input wire x4_wen,input wire [63:0] x5_data,input wire x5_wen,input wire [63:0] x6_data,input wire x6_wen,input wire [63:0] x7_data,input wire x7_wen,output reg [63:0] y0,output reg [63:0] y1,output reg [63:0] y2,output reg [63:0] y3,output reg [63:0] y4,output reg [63:0] y5,output reg [63:0] y6,output reg [63:0] y7);
reg liv;wire cov;
reg [63:0] l_x0;
reg [63:0] l_x1;
reg [63:0] l_x2;
reg [63:0] l_x3;
reg [63:0] l_x4;
reg [63:0] l_x5;
reg [63:0] l_x6;
reg [63:0] l_x7;
wire [63:0] c_y0;
wire [63:0] c_y1;
wire [63:0] c_y2;
wire [63:0] c_y3;
wire [63:0] c_y4;
wire [63:0] c_y5;
wire [63:0] c_y6;
wire [63:0] c_y7;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x0(l_x0),.x1(l_x1),.x2(l_x2),.x3(l_x3),.x4(l_x4),.x5(l_x5),.x6(l_x6),.x7(l_x7),.y0(c_y0),.y1(c_y1),.y2(c_y2),.y3(c_y3),.y4(c_y4),.y5(c_y5),.y6(c_y6),.y7(c_y7));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x0<=64'h0;l_x1<=64'h0;l_x2<=64'h0;l_x3<=64'h0;l_x4<=64'h0;l_x5<=64'h0;l_x6<=64'h0;l_x7<=64'h0;y0<=64'h0;y1<=64'h0;y2<=64'h0;y3<=64'h0;y4<=64'h0;y5<=64'h0;y6<=64'h0;y7<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x0_wen)l_x0<=x0_data;if(x1_wen)l_x1<=x1_data;if(x2_wen)l_x2<=x2_data;if(x3_wen)l_x3<=x3_data;if(x4_wen)l_x4<=x4_data;if(x5_wen)l_x5<=x5_data;if(x6_wen)l_x6<=x6_data;if(x7_wen)l_x7<=x7_data;y0<=c_y0;y1<=c_y1;y2<=c_y2;y3<=c_y3;y4<=c_y4;y5<=c_y5;y6<=c_y6;y7<=c_y7;end
endmodule
