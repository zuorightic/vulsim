#include <fixint.hpp>
#pragma input_port a
Int<127> a;
#pragma input_port b
Int<65> b;
#pragma input_port iv
bool iv;
#pragma output_port y
Int<131> y;
#pragma output_port ov
bool ov;
void workload_top() {
    y = (Int<131>(a) - Int<131>(b));
}
