`timescale 1ns/1ps

module WorkloadCore(
    input logic [126:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [64:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [130:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [130:0] s8_norm_sub_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:35; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [126:0] __beopt_width_7; // decl: <none>; prim: <none>
    logic [130:0] limb_3_7; // decl: <none>; prim: <none>
    logic [130:0] limb_3_8; // decl: <none>; prim: <none>
    logic [18:0] limb_3_9; // decl: <none>; prim: <none>
    logic [18:0] limb_3_10; // decl: <none>; prim: <none>
    logic [18:0] limb_3_11; // decl: <none>; prim: <none>
    logic [19:0] limb_3_12; // decl: <none>; prim: <none>
    logic [18:0] limb_3_13; // decl: <none>; prim: <none>
    logic limb_3_14; // decl: <none>; prim: <none>
    logic [18:0] limb_3_15; // decl: <none>; prim: <none>
    logic [18:0] limb_3_16; // decl: <none>; prim: <none>
    logic [18:0] limb_3_17; // decl: <none>; prim: <none>
    logic [19:0] limb_3_18; // decl: <none>; prim: <none>
    logic [18:0] limb_3_19; // decl: <none>; prim: <none>
    logic limb_3_20; // decl: <none>; prim: <none>
    logic [18:0] limb_3_21; // decl: <none>; prim: <none>
    logic [18:0] limb_3_22; // decl: <none>; prim: <none>
    logic [18:0] limb_3_23; // decl: <none>; prim: <none>
    logic [19:0] limb_3_24; // decl: <none>; prim: <none>
    logic [18:0] limb_3_25; // decl: <none>; prim: <none>
    logic limb_3_26; // decl: <none>; prim: <none>
    logic [18:0] limb_3_27; // decl: <none>; prim: <none>
    logic [18:0] limb_3_28; // decl: <none>; prim: <none>
    logic [18:0] limb_3_29; // decl: <none>; prim: <none>
    logic [19:0] limb_3_30; // decl: <none>; prim: <none>
    logic [18:0] limb_3_31; // decl: <none>; prim: <none>
    logic limb_3_32; // decl: <none>; prim: <none>
    logic [18:0] limb_3_33; // decl: <none>; prim: <none>
    logic [18:0] limb_3_34; // decl: <none>; prim: <none>
    logic [18:0] limb_3_35; // decl: <none>; prim: <none>
    logic [19:0] limb_3_36; // decl: <none>; prim: <none>
    logic [18:0] limb_3_37; // decl: <none>; prim: <none>
    logic limb_3_38; // decl: <none>; prim: <none>
    logic [18:0] limb_3_39; // decl: <none>; prim: <none>
    logic [18:0] limb_3_40; // decl: <none>; prim: <none>
    logic [18:0] limb_3_41; // decl: <none>; prim: <none>
    logic [19:0] limb_3_42; // decl: <none>; prim: <none>
    logic [18:0] limb_3_43; // decl: <none>; prim: <none>
    logic limb_3_44; // decl: <none>; prim: <none>
    logic [16:0] limb_3_45; // decl: <none>; prim: <none>
    logic [16:0] limb_3_46; // decl: <none>; prim: <none>
    logic [16:0] limb_3_47; // decl: <none>; prim: <none>
    logic [17:0] limb_3_48; // decl: <none>; prim: <none>
    logic [16:0] limb_3_49; // decl: <none>; prim: <none>
    logic [130:0] limb_3_50; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_13_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_16_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_20_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_21_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_22_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_29_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_33_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_39_s2; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_40_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_45_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_sub_2_v0 = limb_3_50; // decl: <none>; prim: <none>
    assign y = s8_norm_sub_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_7 = ({62'h0, b}); // decl: <none>; prim: <none>
    assign limb_3_7 = ({4'h0, a}); // decl: <none>; prim: <none>
    assign limb_3_8 = ({4'h0, __beopt_width_7}); // decl: <none>; prim: <none>
    assign limb_3_9 = limb_3_7[18:0]; // decl: <none>; prim: <none>
    assign limb_3_10 = limb_3_8[18:0]; // decl: <none>; prim: <none>
    assign limb_3_11 = (~limb_3_10); // decl: <none>; prim: <none>
    assign limb_3_12 = 20'((({1'h0, limb_3_9}) + ({1'h0, limb_3_11}) + ({19'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_3_13 = limb_3_12[18:0]; // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_12[19]; // decl: <none>; prim: <none>
    assign limb_3_15 = limb_3_7[37:19]; // decl: <none>; prim: <none>
    assign limb_3_16 = limb_3_8[37:19]; // decl: <none>; prim: <none>
    assign limb_3_17 = (~rtlzz_pipe_16_s1); // decl: <none>; prim: <none>
    assign limb_3_18 = 20'((({1'h0, rtlzz_pipe_15_s1}) + ({1'h0, limb_3_17}) + ({19'h0, rtlzz_pipe_14_s1}))); // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_18[18:0]; // decl: <none>; prim: <none>
    assign limb_3_20 = limb_3_18[19]; // decl: <none>; prim: <none>
    assign limb_3_21 = limb_3_7[56:38]; // decl: <none>; prim: <none>
    assign limb_3_22 = limb_3_8[56:38]; // decl: <none>; prim: <none>
    assign limb_3_23 = (~rtlzz_pipe_22_s2); // decl: <none>; prim: <none>
    assign limb_3_24 = 20'((({1'h0, rtlzz_pipe_21_s2}) + ({1'h0, limb_3_23}) + ({19'h0, rtlzz_pipe_20_s2}))); // decl: <none>; prim: <none>
    assign limb_3_25 = limb_3_24[18:0]; // decl: <none>; prim: <none>
    assign limb_3_26 = limb_3_24[19]; // decl: <none>; prim: <none>
    assign limb_3_27 = limb_3_7[75:57]; // decl: <none>; prim: <none>
    assign limb_3_28 = limb_3_8[75:57]; // decl: <none>; prim: <none>
    assign limb_3_29 = (~limb_3_28); // decl: <none>; prim: <none>
    assign limb_3_30 = 20'((({1'h0, rtlzz_pipe_27_s2}) + ({1'h0, rtlzz_pipe_29_s2}) + ({19'h0, limb_3_26}))); // decl: <none>; prim: <none>
    assign limb_3_31 = limb_3_30[18:0]; // decl: <none>; prim: <none>
    assign limb_3_32 = limb_3_30[19]; // decl: <none>; prim: <none>
    assign limb_3_33 = limb_3_7[94:76]; // decl: <none>; prim: <none>
    assign limb_3_34 = limb_3_8[94:76]; // decl: <none>; prim: <none>
    assign limb_3_35 = (~limb_3_34); // decl: <none>; prim: <none>
    assign limb_3_36 = 20'((({1'h0, rtlzz_pipe_33_s2}) + ({1'h0, rtlzz_pipe_35_s2}) + ({19'h0, limb_3_32}))); // decl: <none>; prim: <none>
    assign limb_3_37 = limb_3_36[18:0]; // decl: <none>; prim: <none>
    assign limb_3_38 = limb_3_36[19]; // decl: <none>; prim: <none>
    assign limb_3_39 = limb_3_7[113:95]; // decl: <none>; prim: <none>
    assign limb_3_40 = limb_3_8[113:95]; // decl: <none>; prim: <none>
    assign limb_3_41 = (~rtlzz_pipe_40_s1); // decl: <none>; prim: <none>
    assign limb_3_42 = 20'((({1'h0, rtlzz_pipe_39_s2}) + ({1'h0, rtlzz_pipe_41_s2}) + ({19'h0, limb_3_38}))); // decl: <none>; prim: <none>
    assign limb_3_43 = limb_3_42[18:0]; // decl: <none>; prim: <none>
    assign limb_3_44 = limb_3_42[19]; // decl: <none>; prim: <none>
    assign limb_3_45 = limb_3_7[130:114]; // decl: <none>; prim: <none>
    assign limb_3_46 = limb_3_8[130:114]; // decl: <none>; prim: <none>
    assign limb_3_47 = (~rtlzz_pipe_46_s1); // decl: <none>; prim: <none>
    assign limb_3_48 = 18'((({1'h0, rtlzz_pipe_45_s2}) + ({1'h0, rtlzz_pipe_47_s2}) + ({17'h0, limb_3_44}))); // decl: <none>; prim: <none>
    assign limb_3_49 = limb_3_48[16:0]; // decl: <none>; prim: <none>
    assign limb_3_50 = {limb_3_49, limb_3_43, limb_3_37, limb_3_31, limb_3_25, rtlzz_pipe_19_s2, rtlzz_pipe_13_s2}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 19'h0;
            rtlzz_pipe_13_s2 <= 19'h0;
            rtlzz_pipe_14_s1 <= 1'h1;
            rtlzz_pipe_15_s1 <= 19'h0;
            rtlzz_pipe_16_s1 <= 19'h0;
            rtlzz_pipe_19_s2 <= 19'h0;
            rtlzz_pipe_20_s2 <= 1'h1;
            rtlzz_pipe_21_s1 <= 19'h0;
            rtlzz_pipe_21_s2 <= 19'h0;
            rtlzz_pipe_22_s1 <= 19'h0;
            rtlzz_pipe_22_s2 <= 19'h0;
            rtlzz_pipe_27_s1 <= 19'h0;
            rtlzz_pipe_27_s2 <= 19'h0;
            rtlzz_pipe_29_s1 <= 19'h7ffff;
            rtlzz_pipe_29_s2 <= 19'h7ffff;
            rtlzz_pipe_33_s1 <= 19'h0;
            rtlzz_pipe_33_s2 <= 19'h0;
            rtlzz_pipe_35_s1 <= 19'h7ffff;
            rtlzz_pipe_35_s2 <= 19'h7ffff;
            rtlzz_pipe_39_s1 <= 19'h0;
            rtlzz_pipe_39_s2 <= 19'h0;
            rtlzz_pipe_40_s1 <= 19'h0;
            rtlzz_pipe_41_s2 <= 19'h7ffff;
            rtlzz_pipe_45_s1 <= 17'h0;
            rtlzz_pipe_45_s2 <= 17'h0;
            rtlzz_pipe_46_s1 <= 17'h0;
            rtlzz_pipe_47_s2 <= 17'h1ffff;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= limb_3_13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_13_s2 <= rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= limb_3_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_16_s1 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_20_s2 <= limb_3_20; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_21_s2 <= rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_3_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_22_s2 <= rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_3_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_27_s2 <= rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= limb_3_29; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_29_s2 <= rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= limb_3_33; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= limb_3_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= limb_3_39; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_39_s2 <= rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_40_s1 <= limb_3_40; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= limb_3_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= limb_3_45; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_45_s2 <= rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= limb_3_46; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= limb_3_47; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [126:0] a_data,input wire a_wen,input wire [64:0] b_data,input wire b_wen,output reg [130:0] y);
reg liv;wire cov;
reg [126:0] l_a;
reg [64:0] l_b;
wire [130:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=127'h00000000000000000;l_b<=65'h00000000000000000;y<=131'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
