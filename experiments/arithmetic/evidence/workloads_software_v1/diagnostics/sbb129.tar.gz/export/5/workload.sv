`timescale 1ns/1ps

module WorkloadCore(
    input logic [126:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [64:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic cin, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [128:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:52
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [128:0] s8_norm_sub_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:10-15:35; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] s8_norm_sub_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:9-15:52; prim: /home/zyrv/vulsim/workload.cpp:15:24-15:35
    logic [126:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [128:0] limb_4_10; // decl: <none>; prim: <none>
    logic [128:0] limb_4_11; // decl: <none>; prim: <none>
    logic [16:0] limb_4_12; // decl: <none>; prim: <none>
    logic [16:0] limb_4_13; // decl: <none>; prim: <none>
    logic [16:0] limb_4_14; // decl: <none>; prim: <none>
    logic [17:0] limb_4_15; // decl: <none>; prim: <none>
    logic [16:0] limb_4_16; // decl: <none>; prim: <none>
    logic limb_4_17; // decl: <none>; prim: <none>
    logic [16:0] limb_4_18; // decl: <none>; prim: <none>
    logic [16:0] limb_4_19; // decl: <none>; prim: <none>
    logic [16:0] limb_4_20; // decl: <none>; prim: <none>
    logic [17:0] limb_4_21; // decl: <none>; prim: <none>
    logic [16:0] limb_4_22; // decl: <none>; prim: <none>
    logic limb_4_23; // decl: <none>; prim: <none>
    logic [16:0] limb_4_24; // decl: <none>; prim: <none>
    logic [16:0] limb_4_25; // decl: <none>; prim: <none>
    logic [16:0] limb_4_26; // decl: <none>; prim: <none>
    logic [17:0] limb_4_27; // decl: <none>; prim: <none>
    logic [16:0] limb_4_28; // decl: <none>; prim: <none>
    logic limb_4_29; // decl: <none>; prim: <none>
    logic [16:0] limb_4_30; // decl: <none>; prim: <none>
    logic [16:0] limb_4_31; // decl: <none>; prim: <none>
    logic [16:0] limb_4_32; // decl: <none>; prim: <none>
    logic [17:0] limb_4_33; // decl: <none>; prim: <none>
    logic [16:0] limb_4_34; // decl: <none>; prim: <none>
    logic limb_4_35; // decl: <none>; prim: <none>
    logic [16:0] limb_4_36; // decl: <none>; prim: <none>
    logic [16:0] limb_4_37; // decl: <none>; prim: <none>
    logic [16:0] limb_4_38; // decl: <none>; prim: <none>
    logic [17:0] limb_4_39; // decl: <none>; prim: <none>
    logic [16:0] limb_4_40; // decl: <none>; prim: <none>
    logic limb_4_41; // decl: <none>; prim: <none>
    logic [16:0] limb_4_42; // decl: <none>; prim: <none>
    logic [16:0] limb_4_43; // decl: <none>; prim: <none>
    logic [16:0] limb_4_44; // decl: <none>; prim: <none>
    logic [17:0] limb_4_45; // decl: <none>; prim: <none>
    logic [16:0] limb_4_46; // decl: <none>; prim: <none>
    logic limb_4_47; // decl: <none>; prim: <none>
    logic [16:0] limb_4_48; // decl: <none>; prim: <none>
    logic [16:0] limb_4_49; // decl: <none>; prim: <none>
    logic [16:0] limb_4_50; // decl: <none>; prim: <none>
    logic [17:0] limb_4_51; // decl: <none>; prim: <none>
    logic [16:0] limb_4_52; // decl: <none>; prim: <none>
    logic limb_4_53; // decl: <none>; prim: <none>
    logic [9:0] limb_4_54; // decl: <none>; prim: <none>
    logic [9:0] limb_4_55; // decl: <none>; prim: <none>
    logic [9:0] limb_4_56; // decl: <none>; prim: <none>
    logic [10:0] limb_4_57; // decl: <none>; prim: <none>
    logic [9:0] limb_4_58; // decl: <none>; prim: <none>
    logic [128:0] limb_4_59; // decl: <none>; prim: <none>
    logic [16:0] limb_5_60; // decl: <none>; prim: <none>
    logic [16:0] limb_5_61; // decl: <none>; prim: <none>
    logic [16:0] limb_5_62; // decl: <none>; prim: <none>
    logic [17:0] limb_5_63; // decl: <none>; prim: <none>
    logic [16:0] limb_5_64; // decl: <none>; prim: <none>
    logic limb_5_65; // decl: <none>; prim: <none>
    logic [16:0] limb_5_66; // decl: <none>; prim: <none>
    logic [16:0] limb_5_67; // decl: <none>; prim: <none>
    logic [16:0] limb_5_68; // decl: <none>; prim: <none>
    logic [17:0] limb_5_69; // decl: <none>; prim: <none>
    logic [16:0] limb_5_70; // decl: <none>; prim: <none>
    logic limb_5_71; // decl: <none>; prim: <none>
    logic [16:0] limb_5_72; // decl: <none>; prim: <none>
    logic [16:0] limb_5_73; // decl: <none>; prim: <none>
    logic [16:0] limb_5_74; // decl: <none>; prim: <none>
    logic [17:0] limb_5_75; // decl: <none>; prim: <none>
    logic [16:0] limb_5_76; // decl: <none>; prim: <none>
    logic limb_5_77; // decl: <none>; prim: <none>
    logic [16:0] limb_5_78; // decl: <none>; prim: <none>
    logic [16:0] limb_5_79; // decl: <none>; prim: <none>
    logic [16:0] limb_5_80; // decl: <none>; prim: <none>
    logic [17:0] limb_5_81; // decl: <none>; prim: <none>
    logic [16:0] limb_5_82; // decl: <none>; prim: <none>
    logic limb_5_83; // decl: <none>; prim: <none>
    logic [16:0] limb_5_84; // decl: <none>; prim: <none>
    logic [16:0] limb_5_85; // decl: <none>; prim: <none>
    logic [16:0] limb_5_86; // decl: <none>; prim: <none>
    logic [17:0] limb_5_87; // decl: <none>; prim: <none>
    logic [16:0] limb_5_88; // decl: <none>; prim: <none>
    logic limb_5_89; // decl: <none>; prim: <none>
    logic [16:0] limb_5_90; // decl: <none>; prim: <none>
    logic [16:0] limb_5_91; // decl: <none>; prim: <none>
    logic [16:0] limb_5_92; // decl: <none>; prim: <none>
    logic [17:0] limb_5_93; // decl: <none>; prim: <none>
    logic [16:0] limb_5_94; // decl: <none>; prim: <none>
    logic limb_5_95; // decl: <none>; prim: <none>
    logic [16:0] limb_5_96; // decl: <none>; prim: <none>
    logic [16:0] limb_5_97; // decl: <none>; prim: <none>
    logic [16:0] limb_5_98; // decl: <none>; prim: <none>
    logic [17:0] limb_5_99; // decl: <none>; prim: <none>
    logic [16:0] limb_5_100; // decl: <none>; prim: <none>
    logic limb_5_101; // decl: <none>; prim: <none>
    logic [9:0] limb_5_102; // decl: <none>; prim: <none>
    logic [9:0] limb_5_103; // decl: <none>; prim: <none>
    logic [9:0] limb_5_104; // decl: <none>; prim: <none>
    logic [10:0] limb_5_105; // decl: <none>; prim: <none>
    logic [9:0] limb_5_106; // decl: <none>; prim: <none>
    logic [128:0] limb_5_107; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_16_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_17_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_22_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_38_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_44_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_48_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_50_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_50_s3; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_54_s3; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_55_s2; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_56_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_62_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_62_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_68_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_68_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_73_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_74_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_80_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_80_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_80_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_86_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_86_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_91_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_92_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_98_s3; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_sub_2_v0 = limb_4_59; // decl: <none>; prim: <none>
    assign s8_norm_sub_4_v0 = limb_5_107; // decl: <none>; prim: <none>
    assign y = s8_norm_sub_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:52
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({62'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({128'h0, cin}); // decl: <none>; prim: <none>
    assign limb_4_10 = ({2'h0, a}); // decl: <none>; prim: <none>
    assign limb_4_11 = ({2'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign limb_4_12 = limb_4_10[16:0]; // decl: <none>; prim: <none>
    assign limb_4_13 = limb_4_11[16:0]; // decl: <none>; prim: <none>
    assign limb_4_14 = (~limb_4_13); // decl: <none>; prim: <none>
    assign limb_4_15 = 18'((({1'h0, rtlzz_pipe_12_s1}) + ({1'h0, rtlzz_pipe_14_s1}) + ({17'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_4_16 = limb_4_15[16:0]; // decl: <none>; prim: <none>
    assign limb_4_17 = limb_4_15[17]; // decl: <none>; prim: <none>
    assign limb_4_18 = limb_4_10[33:17]; // decl: <none>; prim: <none>
    assign limb_4_19 = limb_4_11[33:17]; // decl: <none>; prim: <none>
    assign limb_4_20 = (~rtlzz_pipe_19_s2); // decl: <none>; prim: <none>
    assign limb_4_21 = 18'((({1'h0, rtlzz_pipe_18_s2}) + ({1'h0, limb_4_20}) + ({17'h0, rtlzz_pipe_17_s2}))); // decl: <none>; prim: <none>
    assign limb_4_22 = limb_4_21[16:0]; // decl: <none>; prim: <none>
    assign limb_4_23 = limb_4_21[17]; // decl: <none>; prim: <none>
    assign limb_4_24 = limb_4_10[50:34]; // decl: <none>; prim: <none>
    assign limb_4_25 = limb_4_11[50:34]; // decl: <none>; prim: <none>
    assign limb_4_26 = (~rtlzz_pipe_25_s3); // decl: <none>; prim: <none>
    assign limb_4_27 = 18'((({1'h0, rtlzz_pipe_24_s3}) + ({1'h0, limb_4_26}) + ({17'h0, rtlzz_pipe_23_s3}))); // decl: <none>; prim: <none>
    assign limb_4_28 = limb_4_27[16:0]; // decl: <none>; prim: <none>
    assign limb_4_29 = limb_4_27[17]; // decl: <none>; prim: <none>
    assign limb_4_30 = limb_4_10[67:51]; // decl: <none>; prim: <none>
    assign limb_4_31 = limb_4_11[67:51]; // decl: <none>; prim: <none>
    assign limb_4_32 = (~limb_4_31); // decl: <none>; prim: <none>
    assign limb_4_33 = 18'((({1'h0, rtlzz_pipe_30_s3}) + ({1'h0, rtlzz_pipe_32_s3}) + ({17'h0, limb_4_29}))); // decl: <none>; prim: <none>
    assign limb_4_34 = limb_4_33[16:0]; // decl: <none>; prim: <none>
    assign limb_4_35 = limb_4_33[17]; // decl: <none>; prim: <none>
    assign limb_4_36 = limb_4_10[84:68]; // decl: <none>; prim: <none>
    assign limb_4_37 = limb_4_11[84:68]; // decl: <none>; prim: <none>
    assign limb_4_38 = (~rtlzz_pipe_37_s1); // decl: <none>; prim: <none>
    assign limb_4_39 = 18'((({1'h0, rtlzz_pipe_36_s3}) + ({1'h0, rtlzz_pipe_38_s3}) + ({17'h0, limb_4_35}))); // decl: <none>; prim: <none>
    assign limb_4_40 = limb_4_39[16:0]; // decl: <none>; prim: <none>
    assign limb_4_41 = limb_4_39[17]; // decl: <none>; prim: <none>
    assign limb_4_42 = limb_4_10[101:85]; // decl: <none>; prim: <none>
    assign limb_4_43 = limb_4_11[101:85]; // decl: <none>; prim: <none>
    assign limb_4_44 = (~limb_4_43); // decl: <none>; prim: <none>
    assign limb_4_45 = 18'((({1'h0, rtlzz_pipe_42_s3}) + ({1'h0, rtlzz_pipe_44_s3}) + ({17'h0, limb_4_41}))); // decl: <none>; prim: <none>
    assign limb_4_46 = limb_4_45[16:0]; // decl: <none>; prim: <none>
    assign limb_4_47 = limb_4_45[17]; // decl: <none>; prim: <none>
    assign limb_4_48 = limb_4_10[118:102]; // decl: <none>; prim: <none>
    assign limb_4_49 = limb_4_11[118:102]; // decl: <none>; prim: <none>
    assign limb_4_50 = (~rtlzz_pipe_49_s1); // decl: <none>; prim: <none>
    assign limb_4_51 = 18'((({1'h0, rtlzz_pipe_48_s3}) + ({1'h0, rtlzz_pipe_50_s3}) + ({17'h0, limb_4_47}))); // decl: <none>; prim: <none>
    assign limb_4_52 = limb_4_51[16:0]; // decl: <none>; prim: <none>
    assign limb_4_53 = limb_4_51[17]; // decl: <none>; prim: <none>
    assign limb_4_54 = limb_4_10[128:119]; // decl: <none>; prim: <none>
    assign limb_4_55 = limb_4_11[128:119]; // decl: <none>; prim: <none>
    assign limb_4_56 = (~rtlzz_pipe_55_s2); // decl: <none>; prim: <none>
    assign limb_4_57 = 11'((({1'h0, rtlzz_pipe_54_s3}) + ({1'h0, rtlzz_pipe_56_s3}) + ({10'h0, limb_4_53}))); // decl: <none>; prim: <none>
    assign limb_4_58 = limb_4_57[9:0]; // decl: <none>; prim: <none>
    assign limb_4_59 = {limb_4_58, limb_4_52, limb_4_46, limb_4_40, limb_4_34, limb_4_28, rtlzz_pipe_22_s3, rtlzz_pipe_16_s3}; // decl: <none>; prim: <none>
    assign limb_5_60 = s8_norm_sub_2_v0[16:0]; // decl: <none>; prim: <none>
    assign limb_5_61 = __beopt_width_11[16:0]; // decl: <none>; prim: <none>
    assign limb_5_62 = (~limb_5_61); // decl: <none>; prim: <none>
    assign limb_5_63 = 18'((({1'h0, limb_5_60}) + ({1'h0, rtlzz_pipe_62_s3}) + ({17'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_5_64 = limb_5_63[16:0]; // decl: <none>; prim: <none>
    assign limb_5_65 = limb_5_63[17]; // decl: <none>; prim: <none>
    assign limb_5_66 = s8_norm_sub_2_v0[33:17]; // decl: <none>; prim: <none>
    assign limb_5_67 = __beopt_width_11[33:17]; // decl: <none>; prim: <none>
    assign limb_5_68 = (~rtlzz_pipe_67_s1); // decl: <none>; prim: <none>
    assign limb_5_69 = 18'((({1'h0, limb_5_66}) + ({1'h0, rtlzz_pipe_68_s3}) + ({17'h0, limb_5_65}))); // decl: <none>; prim: <none>
    assign limb_5_70 = limb_5_69[16:0]; // decl: <none>; prim: <none>
    assign limb_5_71 = limb_5_69[17]; // decl: <none>; prim: <none>
    assign limb_5_72 = s8_norm_sub_2_v0[50:34]; // decl: <none>; prim: <none>
    assign limb_5_73 = __beopt_width_11[50:34]; // decl: <none>; prim: <none>
    assign limb_5_74 = (~rtlzz_pipe_73_s2); // decl: <none>; prim: <none>
    assign limb_5_75 = 18'((({1'h0, limb_5_72}) + ({1'h0, rtlzz_pipe_74_s3}) + ({17'h0, limb_5_71}))); // decl: <none>; prim: <none>
    assign limb_5_76 = limb_5_75[16:0]; // decl: <none>; prim: <none>
    assign limb_5_77 = limb_5_75[17]; // decl: <none>; prim: <none>
    assign limb_5_78 = s8_norm_sub_2_v0[67:51]; // decl: <none>; prim: <none>
    assign limb_5_79 = __beopt_width_11[67:51]; // decl: <none>; prim: <none>
    assign limb_5_80 = (~limb_5_79); // decl: <none>; prim: <none>
    assign limb_5_81 = 18'((({1'h0, limb_5_78}) + ({1'h0, rtlzz_pipe_80_s3}) + ({17'h0, limb_5_77}))); // decl: <none>; prim: <none>
    assign limb_5_82 = limb_5_81[16:0]; // decl: <none>; prim: <none>
    assign limb_5_83 = limb_5_81[17]; // decl: <none>; prim: <none>
    assign limb_5_84 = s8_norm_sub_2_v0[84:68]; // decl: <none>; prim: <none>
    assign limb_5_85 = __beopt_width_11[84:68]; // decl: <none>; prim: <none>
    assign limb_5_86 = (~rtlzz_pipe_85_s1); // decl: <none>; prim: <none>
    assign limb_5_87 = 18'((({1'h0, limb_5_84}) + ({1'h0, rtlzz_pipe_86_s3}) + ({17'h0, limb_5_83}))); // decl: <none>; prim: <none>
    assign limb_5_88 = limb_5_87[16:0]; // decl: <none>; prim: <none>
    assign limb_5_89 = limb_5_87[17]; // decl: <none>; prim: <none>
    assign limb_5_90 = s8_norm_sub_2_v0[101:85]; // decl: <none>; prim: <none>
    assign limb_5_91 = __beopt_width_11[101:85]; // decl: <none>; prim: <none>
    assign limb_5_92 = (~rtlzz_pipe_91_s2); // decl: <none>; prim: <none>
    assign limb_5_93 = 18'((({1'h0, limb_5_90}) + ({1'h0, rtlzz_pipe_92_s3}) + ({17'h0, limb_5_89}))); // decl: <none>; prim: <none>
    assign limb_5_94 = limb_5_93[16:0]; // decl: <none>; prim: <none>
    assign limb_5_95 = limb_5_93[17]; // decl: <none>; prim: <none>
    assign limb_5_96 = s8_norm_sub_2_v0[118:102]; // decl: <none>; prim: <none>
    assign limb_5_97 = __beopt_width_11[118:102]; // decl: <none>; prim: <none>
    assign limb_5_98 = (~rtlzz_pipe_97_s2); // decl: <none>; prim: <none>
    assign limb_5_99 = 18'((({1'h0, limb_5_96}) + ({1'h0, rtlzz_pipe_98_s3}) + ({17'h0, limb_5_95}))); // decl: <none>; prim: <none>
    assign limb_5_100 = limb_5_99[16:0]; // decl: <none>; prim: <none>
    assign limb_5_101 = limb_5_99[17]; // decl: <none>; prim: <none>
    assign limb_5_102 = s8_norm_sub_2_v0[128:119]; // decl: <none>; prim: <none>
    assign limb_5_103 = __beopt_width_11[128:119]; // decl: <none>; prim: <none>
    assign limb_5_104 = (~rtlzz_pipe_103_s1); // decl: <none>; prim: <none>
    assign limb_5_105 = 11'((({1'h0, limb_5_102}) + ({1'h0, rtlzz_pipe_104_s3}) + ({10'h0, limb_5_101}))); // decl: <none>; prim: <none>
    assign limb_5_106 = limb_5_105[9:0]; // decl: <none>; prim: <none>
    assign limb_5_107 = {limb_5_106, limb_5_100, limb_5_94, limb_5_88, limb_5_82, limb_5_76, limb_5_70, limb_5_64}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 17'h0;
            rtlzz_pipe_14_s1 <= 17'h1ffff;
            rtlzz_pipe_16_s2 <= 17'h0;
            rtlzz_pipe_16_s3 <= 17'h0;
            rtlzz_pipe_17_s2 <= 1'h1;
            rtlzz_pipe_18_s1 <= 17'h0;
            rtlzz_pipe_18_s2 <= 17'h0;
            rtlzz_pipe_19_s1 <= 17'h0;
            rtlzz_pipe_19_s2 <= 17'h0;
            rtlzz_pipe_22_s3 <= 17'h0;
            rtlzz_pipe_23_s3 <= 1'h1;
            rtlzz_pipe_24_s1 <= 17'h0;
            rtlzz_pipe_24_s2 <= 17'h0;
            rtlzz_pipe_24_s3 <= 17'h0;
            rtlzz_pipe_25_s1 <= 17'h0;
            rtlzz_pipe_25_s2 <= 17'h0;
            rtlzz_pipe_25_s3 <= 17'h0;
            rtlzz_pipe_30_s1 <= 17'h0;
            rtlzz_pipe_30_s2 <= 17'h0;
            rtlzz_pipe_30_s3 <= 17'h0;
            rtlzz_pipe_32_s1 <= 17'h1ffff;
            rtlzz_pipe_32_s2 <= 17'h1ffff;
            rtlzz_pipe_32_s3 <= 17'h1ffff;
            rtlzz_pipe_36_s1 <= 17'h0;
            rtlzz_pipe_36_s2 <= 17'h0;
            rtlzz_pipe_36_s3 <= 17'h0;
            rtlzz_pipe_37_s1 <= 17'h0;
            rtlzz_pipe_38_s2 <= 17'h1ffff;
            rtlzz_pipe_38_s3 <= 17'h1ffff;
            rtlzz_pipe_42_s1 <= 17'h0;
            rtlzz_pipe_42_s2 <= 17'h0;
            rtlzz_pipe_42_s3 <= 17'h0;
            rtlzz_pipe_44_s1 <= 17'h1ffff;
            rtlzz_pipe_44_s2 <= 17'h1ffff;
            rtlzz_pipe_44_s3 <= 17'h1ffff;
            rtlzz_pipe_48_s1 <= 17'h0;
            rtlzz_pipe_48_s2 <= 17'h0;
            rtlzz_pipe_48_s3 <= 17'h0;
            rtlzz_pipe_49_s1 <= 17'h0;
            rtlzz_pipe_50_s2 <= 17'h1ffff;
            rtlzz_pipe_50_s3 <= 17'h1ffff;
            rtlzz_pipe_54_s1 <= 10'h0;
            rtlzz_pipe_54_s2 <= 10'h0;
            rtlzz_pipe_54_s3 <= 10'h0;
            rtlzz_pipe_55_s1 <= 10'h0;
            rtlzz_pipe_55_s2 <= 10'h0;
            rtlzz_pipe_56_s3 <= 10'h3ff;
            rtlzz_pipe_62_s1 <= 17'h1ffff;
            rtlzz_pipe_62_s2 <= 17'h1ffff;
            rtlzz_pipe_62_s3 <= 17'h1ffff;
            rtlzz_pipe_67_s1 <= 17'h0;
            rtlzz_pipe_68_s2 <= 17'h1ffff;
            rtlzz_pipe_68_s3 <= 17'h1ffff;
            rtlzz_pipe_73_s1 <= 17'h0;
            rtlzz_pipe_73_s2 <= 17'h0;
            rtlzz_pipe_74_s3 <= 17'h1ffff;
            rtlzz_pipe_80_s1 <= 17'h1ffff;
            rtlzz_pipe_80_s2 <= 17'h1ffff;
            rtlzz_pipe_80_s3 <= 17'h1ffff;
            rtlzz_pipe_85_s1 <= 17'h0;
            rtlzz_pipe_86_s2 <= 17'h1ffff;
            rtlzz_pipe_86_s3 <= 17'h1ffff;
            rtlzz_pipe_91_s1 <= 17'h0;
            rtlzz_pipe_91_s2 <= 17'h0;
            rtlzz_pipe_92_s3 <= 17'h1ffff;
            rtlzz_pipe_97_s1 <= 17'h0;
            rtlzz_pipe_97_s2 <= 17'h0;
            rtlzz_pipe_98_s3 <= 17'h1ffff;
            rtlzz_pipe_103_s1 <= 10'h0;
            rtlzz_pipe_104_s2 <= 10'h3ff;
            rtlzz_pipe_104_s3 <= 10'h3ff;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= limb_4_12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_4_14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_16_s2 <= limb_4_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_16_s3 <= rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_17_s2 <= limb_4_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= limb_4_18; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_18_s2 <= rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= limb_4_19; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_22_s3 <= limb_4_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= limb_4_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_24_s1 <= limb_4_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= limb_4_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= limb_4_30; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_30_s3 <= rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= limb_4_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_36_s1 <= limb_4_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_36_s3 <= rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_4_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= limb_4_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_4_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_44_s1 <= limb_4_44; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_44_s2 <= rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_48_s1 <= limb_4_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= limb_4_49; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_50_s2 <= limb_4_50; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_50_s3 <= rtlzz_pipe_50_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= limb_4_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_54_s2 <= rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_54_s3 <= rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= limb_4_55; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_55_s2 <= rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_56_s3 <= limb_4_56; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= limb_5_62; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_62_s2 <= rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_62_s3 <= rtlzz_pipe_62_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= limb_5_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_68_s2 <= limb_5_68; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_68_s3 <= rtlzz_pipe_68_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= limb_5_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_73_s2 <= rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_74_s3 <= limb_5_74; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_80_s1 <= limb_5_80; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_80_s2 <= rtlzz_pipe_80_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_80_s3 <= rtlzz_pipe_80_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= limb_5_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_86_s2 <= limb_5_86; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_86_s3 <= rtlzz_pipe_86_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= limb_5_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_91_s2 <= rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_92_s3 <= limb_5_92; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= limb_5_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_98_s3 <= limb_5_98; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= limb_5_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= limb_5_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_104_s3 <= rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [126:0] a_data,input wire a_wen,input wire [64:0] b_data,input wire b_wen,input wire [0:0] cin_data,input wire cin_wen,output reg [128:0] y);
reg liv;wire cov;
reg [126:0] l_a;
reg [64:0] l_b;
reg [0:0] l_cin;
wire [128:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.cin(l_cin),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=127'h00000000000000000;l_b<=65'h00000000000000000;l_cin<=1'h0;y<=129'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(cin_wen)l_cin<=cin_data;y<=c_y;end
endmodule
