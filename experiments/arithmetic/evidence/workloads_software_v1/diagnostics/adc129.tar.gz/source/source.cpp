#include <fixint.hpp>
#pragma input_port a
Int<127> a;
#pragma input_port b
Int<65> b;
#pragma input_port cin
Int<1> cin;
#pragma input_port iv
bool iv;
#pragma output_port y
Int<129> y;
#pragma output_port ov
bool ov;
void workload_top() {
    y = (Int<129>(a) + Int<129>(b)) + Int<129>(cin);
}
