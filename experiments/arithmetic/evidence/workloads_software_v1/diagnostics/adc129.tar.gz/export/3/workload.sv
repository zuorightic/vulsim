`timescale 1ns/1ps

module WorkloadCore(
    input logic [126:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [64:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic cin, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [128:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:52
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_add_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:9-15:52; prim: /home/zyrv/vulsim/workload.cpp:15:24-15:35
    logic [126:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [127:0] limb_4_10; // decl: <none>; prim: <none>
    logic [127:0] limb_4_11; // decl: <none>; prim: <none>
    logic [16:0] limb_4_12; // decl: <none>; prim: <none>
    logic [16:0] limb_4_13; // decl: <none>; prim: <none>
    logic [17:0] limb_4_14; // decl: <none>; prim: <none>
    logic [16:0] limb_4_15; // decl: <none>; prim: <none>
    logic limb_4_16; // decl: <none>; prim: <none>
    logic [16:0] limb_4_17; // decl: <none>; prim: <none>
    logic [16:0] limb_4_18; // decl: <none>; prim: <none>
    logic [17:0] limb_4_19; // decl: <none>; prim: <none>
    logic [16:0] limb_4_20; // decl: <none>; prim: <none>
    logic limb_4_21; // decl: <none>; prim: <none>
    logic [16:0] limb_4_22; // decl: <none>; prim: <none>
    logic [16:0] limb_4_23; // decl: <none>; prim: <none>
    logic [17:0] limb_4_24; // decl: <none>; prim: <none>
    logic [16:0] limb_4_25; // decl: <none>; prim: <none>
    logic limb_4_26; // decl: <none>; prim: <none>
    logic [16:0] limb_4_27; // decl: <none>; prim: <none>
    logic [16:0] limb_4_28; // decl: <none>; prim: <none>
    logic [17:0] limb_4_29; // decl: <none>; prim: <none>
    logic [16:0] limb_4_30; // decl: <none>; prim: <none>
    logic limb_4_31; // decl: <none>; prim: <none>
    logic [16:0] limb_4_32; // decl: <none>; prim: <none>
    logic [16:0] limb_4_33; // decl: <none>; prim: <none>
    logic [17:0] limb_4_34; // decl: <none>; prim: <none>
    logic [16:0] limb_4_35; // decl: <none>; prim: <none>
    logic limb_4_36; // decl: <none>; prim: <none>
    logic [16:0] limb_4_37; // decl: <none>; prim: <none>
    logic [16:0] limb_4_38; // decl: <none>; prim: <none>
    logic [17:0] limb_4_39; // decl: <none>; prim: <none>
    logic [16:0] limb_4_40; // decl: <none>; prim: <none>
    logic limb_4_41; // decl: <none>; prim: <none>
    logic [16:0] limb_4_42; // decl: <none>; prim: <none>
    logic [16:0] limb_4_43; // decl: <none>; prim: <none>
    logic [17:0] limb_4_44; // decl: <none>; prim: <none>
    logic [16:0] limb_4_45; // decl: <none>; prim: <none>
    logic limb_4_46; // decl: <none>; prim: <none>
    logic [8:0] limb_4_47; // decl: <none>; prim: <none>
    logic [8:0] limb_4_48; // decl: <none>; prim: <none>
    logic [9:0] limb_4_49; // decl: <none>; prim: <none>
    logic [8:0] limb_4_50; // decl: <none>; prim: <none>
    logic [127:0] limb_4_51; // decl: <none>; prim: <none>
    logic [128:0] limb_5_52; // decl: <none>; prim: <none>
    logic [128:0] limb_5_53; // decl: <none>; prim: <none>
    logic [16:0] limb_5_54; // decl: <none>; prim: <none>
    logic [16:0] limb_5_55; // decl: <none>; prim: <none>
    logic [17:0] limb_5_56; // decl: <none>; prim: <none>
    logic [16:0] limb_5_57; // decl: <none>; prim: <none>
    logic limb_5_58; // decl: <none>; prim: <none>
    logic [16:0] limb_5_59; // decl: <none>; prim: <none>
    logic [16:0] limb_5_60; // decl: <none>; prim: <none>
    logic [17:0] limb_5_61; // decl: <none>; prim: <none>
    logic [16:0] limb_5_62; // decl: <none>; prim: <none>
    logic limb_5_63; // decl: <none>; prim: <none>
    logic [16:0] limb_5_64; // decl: <none>; prim: <none>
    logic [16:0] limb_5_65; // decl: <none>; prim: <none>
    logic [17:0] limb_5_66; // decl: <none>; prim: <none>
    logic [16:0] limb_5_67; // decl: <none>; prim: <none>
    logic limb_5_68; // decl: <none>; prim: <none>
    logic [16:0] limb_5_69; // decl: <none>; prim: <none>
    logic [16:0] limb_5_70; // decl: <none>; prim: <none>
    logic [17:0] limb_5_71; // decl: <none>; prim: <none>
    logic [16:0] limb_5_72; // decl: <none>; prim: <none>
    logic limb_5_73; // decl: <none>; prim: <none>
    logic [16:0] limb_5_74; // decl: <none>; prim: <none>
    logic [16:0] limb_5_75; // decl: <none>; prim: <none>
    logic [17:0] limb_5_76; // decl: <none>; prim: <none>
    logic [16:0] limb_5_77; // decl: <none>; prim: <none>
    logic limb_5_78; // decl: <none>; prim: <none>
    logic [16:0] limb_5_79; // decl: <none>; prim: <none>
    logic [16:0] limb_5_80; // decl: <none>; prim: <none>
    logic [17:0] limb_5_81; // decl: <none>; prim: <none>
    logic [16:0] limb_5_82; // decl: <none>; prim: <none>
    logic limb_5_83; // decl: <none>; prim: <none>
    logic [16:0] limb_5_84; // decl: <none>; prim: <none>
    logic [16:0] limb_5_85; // decl: <none>; prim: <none>
    logic [17:0] limb_5_86; // decl: <none>; prim: <none>
    logic [16:0] limb_5_87; // decl: <none>; prim: <none>
    logic limb_5_88; // decl: <none>; prim: <none>
    logic [9:0] limb_5_89; // decl: <none>; prim: <none>
    logic [9:0] limb_5_90; // decl: <none>; prim: <none>
    logic [10:0] limb_5_91; // decl: <none>; prim: <none>
    logic [9:0] limb_5_92; // decl: <none>; prim: <none>
    logic [128:0] limb_5_93; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_15_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_20_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_20_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_43_s2; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_55_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_60_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_65_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_70_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_75_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_80_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_80_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_85_s2; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_90_s1; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_90_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_add_2_v0 = limb_4_51; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = limb_5_93; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:52
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({62'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({127'h0, cin}); // decl: <none>; prim: <none>
    assign limb_4_10 = ({1'h0, a}); // decl: <none>; prim: <none>
    assign limb_4_11 = ({1'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign limb_4_12 = limb_4_10[16:0]; // decl: <none>; prim: <none>
    assign limb_4_13 = limb_4_11[16:0]; // decl: <none>; prim: <none>
    assign limb_4_14 = 18'((({1'h0, limb_4_12}) + ({1'h0, limb_4_13}) + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_4_15 = limb_4_14[16:0]; // decl: <none>; prim: <none>
    assign limb_4_16 = limb_4_14[17]; // decl: <none>; prim: <none>
    assign limb_4_17 = limb_4_10[33:17]; // decl: <none>; prim: <none>
    assign limb_4_18 = limb_4_11[33:17]; // decl: <none>; prim: <none>
    assign limb_4_19 = 18'((({1'h0, limb_4_17}) + ({1'h0, limb_4_18}) + ({17'h0, limb_4_16}))); // decl: <none>; prim: <none>
    assign limb_4_20 = limb_4_19[16:0]; // decl: <none>; prim: <none>
    assign limb_4_21 = limb_4_19[17]; // decl: <none>; prim: <none>
    assign limb_4_22 = limb_4_10[50:34]; // decl: <none>; prim: <none>
    assign limb_4_23 = limb_4_11[50:34]; // decl: <none>; prim: <none>
    assign limb_4_24 = 18'((({1'h0, rtlzz_pipe_22_s1}) + ({1'h0, rtlzz_pipe_23_s1}) + ({17'h0, rtlzz_pipe_21_s1}))); // decl: <none>; prim: <none>
    assign limb_4_25 = limb_4_24[16:0]; // decl: <none>; prim: <none>
    assign limb_4_26 = limb_4_24[17]; // decl: <none>; prim: <none>
    assign limb_4_27 = limb_4_10[67:51]; // decl: <none>; prim: <none>
    assign limb_4_28 = limb_4_11[67:51]; // decl: <none>; prim: <none>
    assign limb_4_29 = 18'((({1'h0, rtlzz_pipe_27_s1}) + ({1'h0, rtlzz_pipe_28_s1}) + ({17'h0, limb_4_26}))); // decl: <none>; prim: <none>
    assign limb_4_30 = limb_4_29[16:0]; // decl: <none>; prim: <none>
    assign limb_4_31 = limb_4_29[17]; // decl: <none>; prim: <none>
    assign limb_4_32 = limb_4_10[84:68]; // decl: <none>; prim: <none>
    assign limb_4_33 = limb_4_11[84:68]; // decl: <none>; prim: <none>
    assign limb_4_34 = 18'((({1'h0, rtlzz_pipe_32_s1}) + ({1'h0, rtlzz_pipe_33_s1}) + ({17'h0, limb_4_31}))); // decl: <none>; prim: <none>
    assign limb_4_35 = limb_4_34[16:0]; // decl: <none>; prim: <none>
    assign limb_4_36 = limb_4_34[17]; // decl: <none>; prim: <none>
    assign limb_4_37 = limb_4_10[101:85]; // decl: <none>; prim: <none>
    assign limb_4_38 = limb_4_11[101:85]; // decl: <none>; prim: <none>
    assign limb_4_39 = 18'((({1'h0, rtlzz_pipe_37_s2}) + ({1'h0, rtlzz_pipe_38_s2}) + ({17'h0, rtlzz_pipe_36_s2}))); // decl: <none>; prim: <none>
    assign limb_4_40 = limb_4_39[16:0]; // decl: <none>; prim: <none>
    assign limb_4_41 = limb_4_39[17]; // decl: <none>; prim: <none>
    assign limb_4_42 = limb_4_10[118:102]; // decl: <none>; prim: <none>
    assign limb_4_43 = limb_4_11[118:102]; // decl: <none>; prim: <none>
    assign limb_4_44 = 18'((({1'h0, rtlzz_pipe_42_s2}) + ({1'h0, rtlzz_pipe_43_s2}) + ({17'h0, limb_4_41}))); // decl: <none>; prim: <none>
    assign limb_4_45 = limb_4_44[16:0]; // decl: <none>; prim: <none>
    assign limb_4_46 = limb_4_44[17]; // decl: <none>; prim: <none>
    assign limb_4_47 = limb_4_10[127:119]; // decl: <none>; prim: <none>
    assign limb_4_48 = limb_4_11[127:119]; // decl: <none>; prim: <none>
    assign limb_4_49 = 10'((({1'h0, rtlzz_pipe_47_s2}) + ({1'h0, rtlzz_pipe_48_s2}) + ({9'h0, limb_4_46}))); // decl: <none>; prim: <none>
    assign limb_4_50 = limb_4_49[8:0]; // decl: <none>; prim: <none>
    assign limb_4_51 = {limb_4_50, limb_4_45, limb_4_40, rtlzz_pipe_35_s2, rtlzz_pipe_30_s2, rtlzz_pipe_25_s2, rtlzz_pipe_20_s2, rtlzz_pipe_15_s2}; // decl: <none>; prim: <none>
    assign limb_5_52 = ({1'h0, s8_norm_add_2_v0}); // decl: <none>; prim: <none>
    assign limb_5_53 = ({1'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign limb_5_54 = limb_5_52[16:0]; // decl: <none>; prim: <none>
    assign limb_5_55 = limb_5_53[16:0]; // decl: <none>; prim: <none>
    assign limb_5_56 = 18'((({1'h0, limb_5_54}) + ({1'h0, rtlzz_pipe_55_s2}) + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_5_57 = limb_5_56[16:0]; // decl: <none>; prim: <none>
    assign limb_5_58 = limb_5_56[17]; // decl: <none>; prim: <none>
    assign limb_5_59 = limb_5_52[33:17]; // decl: <none>; prim: <none>
    assign limb_5_60 = limb_5_53[33:17]; // decl: <none>; prim: <none>
    assign limb_5_61 = 18'((({1'h0, limb_5_59}) + ({1'h0, rtlzz_pipe_60_s2}) + ({17'h0, limb_5_58}))); // decl: <none>; prim: <none>
    assign limb_5_62 = limb_5_61[16:0]; // decl: <none>; prim: <none>
    assign limb_5_63 = limb_5_61[17]; // decl: <none>; prim: <none>
    assign limb_5_64 = limb_5_52[50:34]; // decl: <none>; prim: <none>
    assign limb_5_65 = limb_5_53[50:34]; // decl: <none>; prim: <none>
    assign limb_5_66 = 18'((({1'h0, limb_5_64}) + ({1'h0, rtlzz_pipe_65_s2}) + ({17'h0, limb_5_63}))); // decl: <none>; prim: <none>
    assign limb_5_67 = limb_5_66[16:0]; // decl: <none>; prim: <none>
    assign limb_5_68 = limb_5_66[17]; // decl: <none>; prim: <none>
    assign limb_5_69 = limb_5_52[67:51]; // decl: <none>; prim: <none>
    assign limb_5_70 = limb_5_53[67:51]; // decl: <none>; prim: <none>
    assign limb_5_71 = 18'((({1'h0, limb_5_69}) + ({1'h0, rtlzz_pipe_70_s2}) + ({17'h0, limb_5_68}))); // decl: <none>; prim: <none>
    assign limb_5_72 = limb_5_71[16:0]; // decl: <none>; prim: <none>
    assign limb_5_73 = limb_5_71[17]; // decl: <none>; prim: <none>
    assign limb_5_74 = limb_5_52[84:68]; // decl: <none>; prim: <none>
    assign limb_5_75 = limb_5_53[84:68]; // decl: <none>; prim: <none>
    assign limb_5_76 = 18'((({1'h0, limb_5_74}) + ({1'h0, rtlzz_pipe_75_s2}) + ({17'h0, limb_5_73}))); // decl: <none>; prim: <none>
    assign limb_5_77 = limb_5_76[16:0]; // decl: <none>; prim: <none>
    assign limb_5_78 = limb_5_76[17]; // decl: <none>; prim: <none>
    assign limb_5_79 = limb_5_52[101:85]; // decl: <none>; prim: <none>
    assign limb_5_80 = limb_5_53[101:85]; // decl: <none>; prim: <none>
    assign limb_5_81 = 18'((({1'h0, limb_5_79}) + ({1'h0, rtlzz_pipe_80_s2}) + ({17'h0, limb_5_78}))); // decl: <none>; prim: <none>
    assign limb_5_82 = limb_5_81[16:0]; // decl: <none>; prim: <none>
    assign limb_5_83 = limb_5_81[17]; // decl: <none>; prim: <none>
    assign limb_5_84 = limb_5_52[118:102]; // decl: <none>; prim: <none>
    assign limb_5_85 = limb_5_53[118:102]; // decl: <none>; prim: <none>
    assign limb_5_86 = 18'((({1'h0, limb_5_84}) + ({1'h0, rtlzz_pipe_85_s2}) + ({17'h0, limb_5_83}))); // decl: <none>; prim: <none>
    assign limb_5_87 = limb_5_86[16:0]; // decl: <none>; prim: <none>
    assign limb_5_88 = limb_5_86[17]; // decl: <none>; prim: <none>
    assign limb_5_89 = limb_5_52[128:119]; // decl: <none>; prim: <none>
    assign limb_5_90 = limb_5_53[128:119]; // decl: <none>; prim: <none>
    assign limb_5_91 = 11'((({1'h0, limb_5_89}) + ({1'h0, rtlzz_pipe_90_s2}) + ({10'h0, limb_5_88}))); // decl: <none>; prim: <none>
    assign limb_5_92 = limb_5_91[9:0]; // decl: <none>; prim: <none>
    assign limb_5_93 = {limb_5_92, limb_5_87, limb_5_82, limb_5_77, limb_5_72, limb_5_67, limb_5_62, limb_5_57}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_15_s1 <= 17'h0;
            rtlzz_pipe_15_s2 <= 17'h0;
            rtlzz_pipe_20_s1 <= 17'h0;
            rtlzz_pipe_20_s2 <= 17'h0;
            rtlzz_pipe_21_s1 <= 1'h0;
            rtlzz_pipe_22_s1 <= 17'h0;
            rtlzz_pipe_23_s1 <= 17'h0;
            rtlzz_pipe_25_s2 <= 17'h0;
            rtlzz_pipe_27_s1 <= 17'h0;
            rtlzz_pipe_28_s1 <= 17'h0;
            rtlzz_pipe_30_s2 <= 17'h0;
            rtlzz_pipe_32_s1 <= 17'h0;
            rtlzz_pipe_33_s1 <= 17'h0;
            rtlzz_pipe_35_s2 <= 17'h0;
            rtlzz_pipe_36_s2 <= 1'h0;
            rtlzz_pipe_37_s1 <= 17'h0;
            rtlzz_pipe_37_s2 <= 17'h0;
            rtlzz_pipe_38_s1 <= 17'h0;
            rtlzz_pipe_38_s2 <= 17'h0;
            rtlzz_pipe_42_s1 <= 17'h0;
            rtlzz_pipe_42_s2 <= 17'h0;
            rtlzz_pipe_43_s1 <= 17'h0;
            rtlzz_pipe_43_s2 <= 17'h0;
            rtlzz_pipe_47_s1 <= 9'h0;
            rtlzz_pipe_47_s2 <= 9'h0;
            rtlzz_pipe_48_s1 <= 9'h0;
            rtlzz_pipe_48_s2 <= 9'h0;
            rtlzz_pipe_55_s1 <= 17'h0;
            rtlzz_pipe_55_s2 <= 17'h0;
            rtlzz_pipe_60_s1 <= 17'h0;
            rtlzz_pipe_60_s2 <= 17'h0;
            rtlzz_pipe_65_s1 <= 17'h0;
            rtlzz_pipe_65_s2 <= 17'h0;
            rtlzz_pipe_70_s1 <= 17'h0;
            rtlzz_pipe_70_s2 <= 17'h0;
            rtlzz_pipe_75_s1 <= 17'h0;
            rtlzz_pipe_75_s2 <= 17'h0;
            rtlzz_pipe_80_s1 <= 17'h0;
            rtlzz_pipe_80_s2 <= 17'h0;
            rtlzz_pipe_85_s1 <= 17'h0;
            rtlzz_pipe_85_s2 <= 17'h0;
            rtlzz_pipe_90_s1 <= 10'h0;
            rtlzz_pipe_90_s2 <= 10'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_15_s1 <= limb_4_15; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_15_s2 <= rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_20_s1 <= limb_4_20; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_20_s2 <= rtlzz_pipe_20_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_4_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_4_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= limb_4_23; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= limb_4_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_4_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_28_s1 <= limb_4_28; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= limb_4_30; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= limb_4_32; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= limb_4_33; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= limb_4_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= limb_4_36; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_4_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= limb_4_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_4_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= limb_4_43; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= limb_4_47; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_48_s1 <= limb_4_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= limb_5_55; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_55_s2 <= rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_60_s1 <= limb_5_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= rtlzz_pipe_60_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= limb_5_65; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_65_s2 <= rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_70_s1 <= limb_5_70; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_70_s2 <= rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= limb_5_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_75_s2 <= rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_80_s1 <= limb_5_80; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_80_s2 <= rtlzz_pipe_80_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= limb_5_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_85_s2 <= rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_90_s1 <= limb_5_90; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_90_s2 <= rtlzz_pipe_90_s1; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [126:0] a_data,input wire a_wen,input wire [64:0] b_data,input wire b_wen,input wire [0:0] cin_data,input wire cin_wen,output reg [128:0] y);
reg liv;wire cov;
reg [126:0] l_a;
reg [64:0] l_b;
reg [0:0] l_cin;
wire [128:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.cin(l_cin),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=127'h00000000000000000;l_b<=65'h00000000000000000;l_cin<=1'h0;y<=129'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(cin_wen)l_cin<=cin_data;y<=c_y;end
endmodule
