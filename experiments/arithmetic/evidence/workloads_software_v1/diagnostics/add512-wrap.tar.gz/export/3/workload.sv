`timescale 1ns/1ps

module WorkloadCore(
    input logic [511:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [511:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [511:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [511:0] s8_norm_add_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:35; prim: /home/zyrv/vulsim/workload.cpp:13:10-13:35
    logic [63:0] limb_3_6; // decl: <none>; prim: <none>
    logic [63:0] limb_3_7; // decl: <none>; prim: <none>
    logic [64:0] limb_3_8; // decl: <none>; prim: <none>
    logic [63:0] limb_3_9; // decl: <none>; prim: <none>
    logic limb_3_10; // decl: <none>; prim: <none>
    logic [63:0] limb_3_11; // decl: <none>; prim: <none>
    logic [63:0] limb_3_12; // decl: <none>; prim: <none>
    logic [64:0] limb_3_13; // decl: <none>; prim: <none>
    logic [63:0] limb_3_14; // decl: <none>; prim: <none>
    logic limb_3_15; // decl: <none>; prim: <none>
    logic [63:0] limb_3_16; // decl: <none>; prim: <none>
    logic [63:0] limb_3_17; // decl: <none>; prim: <none>
    logic [64:0] limb_3_18; // decl: <none>; prim: <none>
    logic [63:0] limb_3_19; // decl: <none>; prim: <none>
    logic limb_3_20; // decl: <none>; prim: <none>
    logic [63:0] limb_3_21; // decl: <none>; prim: <none>
    logic [63:0] limb_3_22; // decl: <none>; prim: <none>
    logic [64:0] limb_3_23; // decl: <none>; prim: <none>
    logic [63:0] limb_3_24; // decl: <none>; prim: <none>
    logic limb_3_25; // decl: <none>; prim: <none>
    logic [63:0] limb_3_26; // decl: <none>; prim: <none>
    logic [63:0] limb_3_27; // decl: <none>; prim: <none>
    logic [64:0] limb_3_28; // decl: <none>; prim: <none>
    logic [63:0] limb_3_29; // decl: <none>; prim: <none>
    logic limb_3_30; // decl: <none>; prim: <none>
    logic [63:0] limb_3_31; // decl: <none>; prim: <none>
    logic [63:0] limb_3_32; // decl: <none>; prim: <none>
    logic [64:0] limb_3_33; // decl: <none>; prim: <none>
    logic [63:0] limb_3_34; // decl: <none>; prim: <none>
    logic limb_3_35; // decl: <none>; prim: <none>
    logic [63:0] limb_3_36; // decl: <none>; prim: <none>
    logic [63:0] limb_3_37; // decl: <none>; prim: <none>
    logic [64:0] limb_3_38; // decl: <none>; prim: <none>
    logic [63:0] limb_3_39; // decl: <none>; prim: <none>
    logic limb_3_40; // decl: <none>; prim: <none>
    logic [63:0] limb_3_41; // decl: <none>; prim: <none>
    logic [63:0] limb_3_42; // decl: <none>; prim: <none>
    logic [64:0] limb_3_43; // decl: <none>; prim: <none>
    logic [63:0] limb_3_44; // decl: <none>; prim: <none>
    logic [511:0] limb_3_45; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_14_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_16_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_add_0_v0 = limb_3_45; // decl: <none>; prim: <none>
    assign y = s8_norm_add_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign limb_3_6 = a[63:0]; // decl: <none>; prim: <none>
    assign limb_3_7 = b[63:0]; // decl: <none>; prim: <none>
    assign limb_3_8 = 65'((({1'h0, limb_3_6}) + ({1'h0, limb_3_7}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_3_9 = limb_3_8[63:0]; // decl: <none>; prim: <none>
    assign limb_3_10 = limb_3_8[64]; // decl: <none>; prim: <none>
    assign limb_3_11 = a[127:64]; // decl: <none>; prim: <none>
    assign limb_3_12 = b[127:64]; // decl: <none>; prim: <none>
    assign limb_3_13 = 65'((({1'h0, limb_3_11}) + ({1'h0, limb_3_12}) + ({64'h0, limb_3_10}))); // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_13[63:0]; // decl: <none>; prim: <none>
    assign limb_3_15 = limb_3_13[64]; // decl: <none>; prim: <none>
    assign limb_3_16 = a[191:128]; // decl: <none>; prim: <none>
    assign limb_3_17 = b[191:128]; // decl: <none>; prim: <none>
    assign limb_3_18 = 65'((({1'h0, rtlzz_pipe_16_s1}) + ({1'h0, rtlzz_pipe_17_s1}) + ({64'h0, rtlzz_pipe_15_s1}))); // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_18[63:0]; // decl: <none>; prim: <none>
    assign limb_3_20 = limb_3_18[64]; // decl: <none>; prim: <none>
    assign limb_3_21 = a[255:192]; // decl: <none>; prim: <none>
    assign limb_3_22 = b[255:192]; // decl: <none>; prim: <none>
    assign limb_3_23 = 65'((({1'h0, rtlzz_pipe_21_s1}) + ({1'h0, rtlzz_pipe_22_s1}) + ({64'h0, limb_3_20}))); // decl: <none>; prim: <none>
    assign limb_3_24 = limb_3_23[63:0]; // decl: <none>; prim: <none>
    assign limb_3_25 = limb_3_23[64]; // decl: <none>; prim: <none>
    assign limb_3_26 = a[319:256]; // decl: <none>; prim: <none>
    assign limb_3_27 = b[319:256]; // decl: <none>; prim: <none>
    assign limb_3_28 = 65'((({1'h0, rtlzz_pipe_26_s2}) + ({1'h0, rtlzz_pipe_27_s2}) + ({64'h0, rtlzz_pipe_25_s2}))); // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_28[63:0]; // decl: <none>; prim: <none>
    assign limb_3_30 = limb_3_28[64]; // decl: <none>; prim: <none>
    assign limb_3_31 = a[383:320]; // decl: <none>; prim: <none>
    assign limb_3_32 = b[383:320]; // decl: <none>; prim: <none>
    assign limb_3_33 = 65'((({1'h0, rtlzz_pipe_31_s2}) + ({1'h0, rtlzz_pipe_32_s2}) + ({64'h0, limb_3_30}))); // decl: <none>; prim: <none>
    assign limb_3_34 = limb_3_33[63:0]; // decl: <none>; prim: <none>
    assign limb_3_35 = limb_3_33[64]; // decl: <none>; prim: <none>
    assign limb_3_36 = a[447:384]; // decl: <none>; prim: <none>
    assign limb_3_37 = b[447:384]; // decl: <none>; prim: <none>
    assign limb_3_38 = 65'((({1'h0, rtlzz_pipe_36_s2}) + ({1'h0, rtlzz_pipe_37_s2}) + ({64'h0, limb_3_35}))); // decl: <none>; prim: <none>
    assign limb_3_39 = limb_3_38[63:0]; // decl: <none>; prim: <none>
    assign limb_3_40 = limb_3_38[64]; // decl: <none>; prim: <none>
    assign limb_3_41 = a[511:448]; // decl: <none>; prim: <none>
    assign limb_3_42 = b[511:448]; // decl: <none>; prim: <none>
    assign limb_3_43 = 65'((({1'h0, rtlzz_pipe_41_s2}) + ({1'h0, rtlzz_pipe_42_s2}) + ({64'h0, limb_3_40}))); // decl: <none>; prim: <none>
    assign limb_3_44 = limb_3_43[63:0]; // decl: <none>; prim: <none>
    assign limb_3_45 = {limb_3_44, limb_3_39, limb_3_34, limb_3_29, rtlzz_pipe_24_s2, rtlzz_pipe_19_s2, rtlzz_pipe_14_s2, rtlzz_pipe_9_s2}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_9_s1 <= 64'h0;
            rtlzz_pipe_9_s2 <= 64'h0;
            rtlzz_pipe_14_s1 <= 64'h0;
            rtlzz_pipe_14_s2 <= 64'h0;
            rtlzz_pipe_15_s1 <= 1'h0;
            rtlzz_pipe_16_s1 <= 64'h0;
            rtlzz_pipe_17_s1 <= 64'h0;
            rtlzz_pipe_19_s2 <= 64'h0;
            rtlzz_pipe_21_s1 <= 64'h0;
            rtlzz_pipe_22_s1 <= 64'h0;
            rtlzz_pipe_24_s2 <= 64'h0;
            rtlzz_pipe_25_s2 <= 1'h0;
            rtlzz_pipe_26_s1 <= 64'h0;
            rtlzz_pipe_26_s2 <= 64'h0;
            rtlzz_pipe_27_s1 <= 64'h0;
            rtlzz_pipe_27_s2 <= 64'h0;
            rtlzz_pipe_31_s1 <= 64'h0;
            rtlzz_pipe_31_s2 <= 64'h0;
            rtlzz_pipe_32_s1 <= 64'h0;
            rtlzz_pipe_32_s2 <= 64'h0;
            rtlzz_pipe_36_s1 <= 64'h0;
            rtlzz_pipe_36_s2 <= 64'h0;
            rtlzz_pipe_37_s1 <= 64'h0;
            rtlzz_pipe_37_s2 <= 64'h0;
            rtlzz_pipe_41_s1 <= 64'h0;
            rtlzz_pipe_41_s2 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_42_s2 <= 64'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_9_s1 <= limb_3_9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_9_s2 <= rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_14_s2 <= rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= limb_3_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_16_s1 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= limb_3_17; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_3_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= limb_3_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_3_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_3_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_27_s2 <= rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= limb_3_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= limb_3_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_36_s1 <= limb_3_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_3_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= limb_3_41; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_3_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [511:0] a_data,input wire a_wen,input wire [511:0] b_data,input wire b_wen,output reg [511:0] y);
reg liv;wire cov;
reg [511:0] l_a;
reg [511:0] l_b;
wire [511:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;l_b<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
