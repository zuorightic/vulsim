`timescale 1ns/1ps

module WorkloadCore(
    input logic [64:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [64:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [64:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:10; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:34
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [64:0] s8_norm_add_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:33; prim: /home/zyrv/vulsim/workload.cpp:13:10-13:33
    logic [12:0] limb_3_6; // decl: <none>; prim: <none>
    logic [12:0] limb_3_7; // decl: <none>; prim: <none>
    logic [13:0] limb_3_8; // decl: <none>; prim: <none>
    logic [12:0] limb_3_9; // decl: <none>; prim: <none>
    logic limb_3_10; // decl: <none>; prim: <none>
    logic [12:0] limb_3_11; // decl: <none>; prim: <none>
    logic [12:0] limb_3_12; // decl: <none>; prim: <none>
    logic [13:0] limb_3_13; // decl: <none>; prim: <none>
    logic [12:0] limb_3_14; // decl: <none>; prim: <none>
    logic limb_3_15; // decl: <none>; prim: <none>
    logic [12:0] limb_3_16; // decl: <none>; prim: <none>
    logic [12:0] limb_3_17; // decl: <none>; prim: <none>
    logic [13:0] limb_3_18; // decl: <none>; prim: <none>
    logic [12:0] limb_3_19; // decl: <none>; prim: <none>
    logic limb_3_20; // decl: <none>; prim: <none>
    logic [12:0] limb_3_21; // decl: <none>; prim: <none>
    logic [12:0] limb_3_22; // decl: <none>; prim: <none>
    logic [13:0] limb_3_23; // decl: <none>; prim: <none>
    logic [12:0] limb_3_24; // decl: <none>; prim: <none>
    logic limb_3_25; // decl: <none>; prim: <none>
    logic [12:0] limb_3_26; // decl: <none>; prim: <none>
    logic [12:0] limb_3_27; // decl: <none>; prim: <none>
    logic [13:0] limb_3_28; // decl: <none>; prim: <none>
    logic [12:0] limb_3_29; // decl: <none>; prim: <none>
    logic [64:0] limb_3_30; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_9_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_10_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_11_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_14_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_14_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_15_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_16_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_17_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_19_s3; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_21_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_22_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_26_s3; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_27_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_add_0_v0 = limb_3_30; // decl: <none>; prim: <none>
    assign y = s8_norm_add_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:10; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:34
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign limb_3_6 = a[12:0]; // decl: <none>; prim: <none>
    assign limb_3_7 = b[12:0]; // decl: <none>; prim: <none>
    assign limb_3_8 = 14'((({1'h0, limb_3_6}) + ({1'h0, limb_3_7}) + ({13'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_3_9 = limb_3_8[12:0]; // decl: <none>; prim: <none>
    assign limb_3_10 = limb_3_8[13]; // decl: <none>; prim: <none>
    assign limb_3_11 = a[25:13]; // decl: <none>; prim: <none>
    assign limb_3_12 = b[25:13]; // decl: <none>; prim: <none>
    assign limb_3_13 = 14'((({1'h0, rtlzz_pipe_11_s1}) + ({1'h0, rtlzz_pipe_12_s1}) + ({13'h0, rtlzz_pipe_10_s1}))); // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_13[12:0]; // decl: <none>; prim: <none>
    assign limb_3_15 = limb_3_13[13]; // decl: <none>; prim: <none>
    assign limb_3_16 = a[38:26]; // decl: <none>; prim: <none>
    assign limb_3_17 = b[38:26]; // decl: <none>; prim: <none>
    assign limb_3_18 = 14'((({1'h0, rtlzz_pipe_16_s2}) + ({1'h0, rtlzz_pipe_17_s2}) + ({13'h0, rtlzz_pipe_15_s2}))); // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_18[12:0]; // decl: <none>; prim: <none>
    assign limb_3_20 = limb_3_18[13]; // decl: <none>; prim: <none>
    assign limb_3_21 = a[51:39]; // decl: <none>; prim: <none>
    assign limb_3_22 = b[51:39]; // decl: <none>; prim: <none>
    assign limb_3_23 = 14'((({1'h0, rtlzz_pipe_21_s2}) + ({1'h0, rtlzz_pipe_22_s2}) + ({13'h0, limb_3_20}))); // decl: <none>; prim: <none>
    assign limb_3_24 = limb_3_23[12:0]; // decl: <none>; prim: <none>
    assign limb_3_25 = limb_3_23[13]; // decl: <none>; prim: <none>
    assign limb_3_26 = a[64:52]; // decl: <none>; prim: <none>
    assign limb_3_27 = b[64:52]; // decl: <none>; prim: <none>
    assign limb_3_28 = 14'((({1'h0, rtlzz_pipe_26_s3}) + ({1'h0, rtlzz_pipe_27_s3}) + ({13'h0, rtlzz_pipe_25_s3}))); // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_28[12:0]; // decl: <none>; prim: <none>
    assign limb_3_30 = {limb_3_29, rtlzz_pipe_24_s3, rtlzz_pipe_19_s3, rtlzz_pipe_14_s3, rtlzz_pipe_9_s3}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_9_s1 <= 13'h0;
            rtlzz_pipe_9_s2 <= 13'h0;
            rtlzz_pipe_9_s3 <= 13'h0;
            rtlzz_pipe_10_s1 <= 1'h0;
            rtlzz_pipe_11_s1 <= 13'h0;
            rtlzz_pipe_12_s1 <= 13'h0;
            rtlzz_pipe_14_s2 <= 13'h0;
            rtlzz_pipe_14_s3 <= 13'h0;
            rtlzz_pipe_15_s2 <= 1'h0;
            rtlzz_pipe_16_s1 <= 13'h0;
            rtlzz_pipe_16_s2 <= 13'h0;
            rtlzz_pipe_17_s1 <= 13'h0;
            rtlzz_pipe_17_s2 <= 13'h0;
            rtlzz_pipe_19_s3 <= 13'h0;
            rtlzz_pipe_21_s1 <= 13'h0;
            rtlzz_pipe_21_s2 <= 13'h0;
            rtlzz_pipe_22_s1 <= 13'h0;
            rtlzz_pipe_22_s2 <= 13'h0;
            rtlzz_pipe_24_s3 <= 13'h0;
            rtlzz_pipe_25_s3 <= 1'h0;
            rtlzz_pipe_26_s1 <= 13'h0;
            rtlzz_pipe_26_s2 <= 13'h0;
            rtlzz_pipe_26_s3 <= 13'h0;
            rtlzz_pipe_27_s1 <= 13'h0;
            rtlzz_pipe_27_s2 <= 13'h0;
            rtlzz_pipe_27_s3 <= 13'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_9_s1 <= limb_3_9; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_9_s2 <= rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_9_s3 <= rtlzz_pipe_9_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_10_s1 <= limb_3_10; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_11_s1 <= limb_3_11; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_12_s1 <= limb_3_12; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_14_s2 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_14_s3 <= rtlzz_pipe_14_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_15_s2 <= limb_3_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_16_s1 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_16_s2 <= rtlzz_pipe_16_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= limb_3_17; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_17_s2 <= rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_19_s3 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_21_s2 <= rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_3_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_22_s2 <= rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= limb_3_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_3_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_26_s3 <= rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_3_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_27_s2 <= rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_27_s3 <= rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [64:0] a_data,input wire a_wen,input wire [64:0] b_data,input wire b_wen,output reg [64:0] y);
reg liv;wire cov;
reg [64:0] l_a;
reg [64:0] l_b;
wire [64:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=65'h00000000000000000;l_b<=65'h00000000000000000;y<=65'h00000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
