#include <fixint.hpp>
#pragma input_port a
Int<65> a;
#pragma input_port b
Int<65> b;
#pragma input_port iv
bool iv;
#pragma output_port y
Int<65> y;
#pragma output_port ov
bool ov;
void workload_top() {
    y = (Int<65>(a) + Int<65>(b));
}
