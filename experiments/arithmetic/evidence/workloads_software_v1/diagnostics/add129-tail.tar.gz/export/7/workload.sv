`timescale 1ns/1ps

module WorkloadCore(
    input logic [126:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [64:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [128:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:10-13:21
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_add_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [126:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] limb_3_8; // decl: <none>; prim: <none>
    logic [127:0] limb_3_9; // decl: <none>; prim: <none>
    logic [16:0] limb_3_10; // decl: <none>; prim: <none>
    logic [16:0] limb_3_11; // decl: <none>; prim: <none>
    logic [17:0] limb_3_12; // decl: <none>; prim: <none>
    logic [16:0] limb_3_13; // decl: <none>; prim: <none>
    logic limb_3_14; // decl: <none>; prim: <none>
    logic [16:0] limb_3_15; // decl: <none>; prim: <none>
    logic [16:0] limb_3_16; // decl: <none>; prim: <none>
    logic [17:0] limb_3_17; // decl: <none>; prim: <none>
    logic [16:0] limb_3_18; // decl: <none>; prim: <none>
    logic limb_3_19; // decl: <none>; prim: <none>
    logic [16:0] limb_3_20; // decl: <none>; prim: <none>
    logic [16:0] limb_3_21; // decl: <none>; prim: <none>
    logic [17:0] limb_3_22; // decl: <none>; prim: <none>
    logic [16:0] limb_3_23; // decl: <none>; prim: <none>
    logic limb_3_24; // decl: <none>; prim: <none>
    logic [16:0] limb_3_25; // decl: <none>; prim: <none>
    logic [16:0] limb_3_26; // decl: <none>; prim: <none>
    logic [17:0] limb_3_27; // decl: <none>; prim: <none>
    logic [16:0] limb_3_28; // decl: <none>; prim: <none>
    logic limb_3_29; // decl: <none>; prim: <none>
    logic [16:0] limb_3_30; // decl: <none>; prim: <none>
    logic [16:0] limb_3_31; // decl: <none>; prim: <none>
    logic [17:0] limb_3_32; // decl: <none>; prim: <none>
    logic [16:0] limb_3_33; // decl: <none>; prim: <none>
    logic limb_3_34; // decl: <none>; prim: <none>
    logic [16:0] limb_3_35; // decl: <none>; prim: <none>
    logic [16:0] limb_3_36; // decl: <none>; prim: <none>
    logic [17:0] limb_3_37; // decl: <none>; prim: <none>
    logic [16:0] limb_3_38; // decl: <none>; prim: <none>
    logic limb_3_39; // decl: <none>; prim: <none>
    logic [16:0] limb_3_40; // decl: <none>; prim: <none>
    logic [16:0] limb_3_41; // decl: <none>; prim: <none>
    logic [17:0] limb_3_42; // decl: <none>; prim: <none>
    logic [16:0] limb_3_43; // decl: <none>; prim: <none>
    logic limb_3_44; // decl: <none>; prim: <none>
    logic [8:0] limb_3_45; // decl: <none>; prim: <none>
    logic [8:0] limb_3_46; // decl: <none>; prim: <none>
    logic [9:0] limb_3_47; // decl: <none>; prim: <none>
    logic [8:0] limb_3_48; // decl: <none>; prim: <none>
    logic [127:0] limb_3_49; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_13_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_13_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_16_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_18_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_19_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_20_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_20_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_21_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_24_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_26_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_30_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_31_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_40_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_40_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_40_s3; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_41_s3; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_45_s2; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_45_s3; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_46_s2; // decl: <none>; prim: <none>
    logic [8:0] rtlzz_pipe_46_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_add_2_v0 = limb_3_49; // decl: <none>; prim: <none>
    assign y = __beopt_width_9; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:10-13:21
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({62'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({1'h0, s8_norm_add_2_v0}); // decl: <none>; prim: <none>
    assign limb_3_8 = ({1'h0, a}); // decl: <none>; prim: <none>
    assign limb_3_9 = ({1'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign limb_3_10 = limb_3_8[16:0]; // decl: <none>; prim: <none>
    assign limb_3_11 = limb_3_9[16:0]; // decl: <none>; prim: <none>
    assign limb_3_12 = 18'((({1'h0, limb_3_10}) + ({1'h0, limb_3_11}) + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_3_13 = limb_3_12[16:0]; // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_12[17]; // decl: <none>; prim: <none>
    assign limb_3_15 = limb_3_8[33:17]; // decl: <none>; prim: <none>
    assign limb_3_16 = limb_3_9[33:17]; // decl: <none>; prim: <none>
    assign limb_3_17 = 18'((({1'h0, rtlzz_pipe_15_s1}) + ({1'h0, rtlzz_pipe_16_s1}) + ({17'h0, rtlzz_pipe_14_s1}))); // decl: <none>; prim: <none>
    assign limb_3_18 = limb_3_17[16:0]; // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_17[17]; // decl: <none>; prim: <none>
    assign limb_3_20 = limb_3_8[50:34]; // decl: <none>; prim: <none>
    assign limb_3_21 = limb_3_9[50:34]; // decl: <none>; prim: <none>
    assign limb_3_22 = 18'((({1'h0, rtlzz_pipe_20_s2}) + ({1'h0, rtlzz_pipe_21_s2}) + ({17'h0, rtlzz_pipe_19_s2}))); // decl: <none>; prim: <none>
    assign limb_3_23 = limb_3_22[16:0]; // decl: <none>; prim: <none>
    assign limb_3_24 = limb_3_22[17]; // decl: <none>; prim: <none>
    assign limb_3_25 = limb_3_8[67:51]; // decl: <none>; prim: <none>
    assign limb_3_26 = limb_3_9[67:51]; // decl: <none>; prim: <none>
    assign limb_3_27 = 18'((({1'h0, rtlzz_pipe_25_s3}) + ({1'h0, rtlzz_pipe_26_s3}) + ({17'h0, rtlzz_pipe_24_s3}))); // decl: <none>; prim: <none>
    assign limb_3_28 = limb_3_27[16:0]; // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_27[17]; // decl: <none>; prim: <none>
    assign limb_3_30 = limb_3_8[84:68]; // decl: <none>; prim: <none>
    assign limb_3_31 = limb_3_9[84:68]; // decl: <none>; prim: <none>
    assign limb_3_32 = 18'((({1'h0, rtlzz_pipe_30_s3}) + ({1'h0, rtlzz_pipe_31_s3}) + ({17'h0, limb_3_29}))); // decl: <none>; prim: <none>
    assign limb_3_33 = limb_3_32[16:0]; // decl: <none>; prim: <none>
    assign limb_3_34 = limb_3_32[17]; // decl: <none>; prim: <none>
    assign limb_3_35 = limb_3_8[101:85]; // decl: <none>; prim: <none>
    assign limb_3_36 = limb_3_9[101:85]; // decl: <none>; prim: <none>
    assign limb_3_37 = 18'((({1'h0, rtlzz_pipe_35_s3}) + ({1'h0, rtlzz_pipe_36_s3}) + ({17'h0, limb_3_34}))); // decl: <none>; prim: <none>
    assign limb_3_38 = limb_3_37[16:0]; // decl: <none>; prim: <none>
    assign limb_3_39 = limb_3_37[17]; // decl: <none>; prim: <none>
    assign limb_3_40 = limb_3_8[118:102]; // decl: <none>; prim: <none>
    assign limb_3_41 = limb_3_9[118:102]; // decl: <none>; prim: <none>
    assign limb_3_42 = 18'((({1'h0, rtlzz_pipe_40_s3}) + ({1'h0, rtlzz_pipe_41_s3}) + ({17'h0, limb_3_39}))); // decl: <none>; prim: <none>
    assign limb_3_43 = limb_3_42[16:0]; // decl: <none>; prim: <none>
    assign limb_3_44 = limb_3_42[17]; // decl: <none>; prim: <none>
    assign limb_3_45 = limb_3_8[127:119]; // decl: <none>; prim: <none>
    assign limb_3_46 = limb_3_9[127:119]; // decl: <none>; prim: <none>
    assign limb_3_47 = 10'((({1'h0, rtlzz_pipe_45_s3}) + ({1'h0, rtlzz_pipe_46_s3}) + ({9'h0, limb_3_44}))); // decl: <none>; prim: <none>
    assign limb_3_48 = limb_3_47[8:0]; // decl: <none>; prim: <none>
    assign limb_3_49 = {limb_3_48, limb_3_43, limb_3_38, limb_3_33, limb_3_28, rtlzz_pipe_23_s3, rtlzz_pipe_18_s3, rtlzz_pipe_13_s3}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 17'h0;
            rtlzz_pipe_13_s2 <= 17'h0;
            rtlzz_pipe_13_s3 <= 17'h0;
            rtlzz_pipe_14_s1 <= 1'h0;
            rtlzz_pipe_15_s1 <= 17'h0;
            rtlzz_pipe_16_s1 <= 17'h0;
            rtlzz_pipe_18_s2 <= 17'h0;
            rtlzz_pipe_18_s3 <= 17'h0;
            rtlzz_pipe_19_s2 <= 1'h0;
            rtlzz_pipe_20_s1 <= 17'h0;
            rtlzz_pipe_20_s2 <= 17'h0;
            rtlzz_pipe_21_s1 <= 17'h0;
            rtlzz_pipe_21_s2 <= 17'h0;
            rtlzz_pipe_23_s3 <= 17'h0;
            rtlzz_pipe_24_s3 <= 1'h0;
            rtlzz_pipe_25_s1 <= 17'h0;
            rtlzz_pipe_25_s2 <= 17'h0;
            rtlzz_pipe_25_s3 <= 17'h0;
            rtlzz_pipe_26_s1 <= 17'h0;
            rtlzz_pipe_26_s2 <= 17'h0;
            rtlzz_pipe_26_s3 <= 17'h0;
            rtlzz_pipe_30_s1 <= 17'h0;
            rtlzz_pipe_30_s2 <= 17'h0;
            rtlzz_pipe_30_s3 <= 17'h0;
            rtlzz_pipe_31_s1 <= 17'h0;
            rtlzz_pipe_31_s2 <= 17'h0;
            rtlzz_pipe_31_s3 <= 17'h0;
            rtlzz_pipe_35_s1 <= 17'h0;
            rtlzz_pipe_35_s2 <= 17'h0;
            rtlzz_pipe_35_s3 <= 17'h0;
            rtlzz_pipe_36_s1 <= 17'h0;
            rtlzz_pipe_36_s2 <= 17'h0;
            rtlzz_pipe_36_s3 <= 17'h0;
            rtlzz_pipe_40_s1 <= 17'h0;
            rtlzz_pipe_40_s2 <= 17'h0;
            rtlzz_pipe_40_s3 <= 17'h0;
            rtlzz_pipe_41_s1 <= 17'h0;
            rtlzz_pipe_41_s2 <= 17'h0;
            rtlzz_pipe_41_s3 <= 17'h0;
            rtlzz_pipe_45_s1 <= 9'h0;
            rtlzz_pipe_45_s2 <= 9'h0;
            rtlzz_pipe_45_s3 <= 9'h0;
            rtlzz_pipe_46_s1 <= 9'h0;
            rtlzz_pipe_46_s2 <= 9'h0;
            rtlzz_pipe_46_s3 <= 9'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= limb_3_13; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_13_s2 <= rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_13_s3 <= rtlzz_pipe_13_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= limb_3_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_16_s1 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_18_s2 <= limb_3_18; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_18_s3 <= rtlzz_pipe_18_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_19_s2 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_20_s1 <= limb_3_20; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_20_s2 <= rtlzz_pipe_20_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_21_s2 <= rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= limb_3_23; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_24_s3 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= limb_3_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_3_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_26_s3 <= rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= limb_3_30; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_30_s3 <= rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= limb_3_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_31_s3 <= rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= limb_3_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_36_s1 <= limb_3_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_36_s2 <= rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_36_s3 <= rtlzz_pipe_36_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_40_s1 <= limb_3_40; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_40_s2 <= rtlzz_pipe_40_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_40_s3 <= rtlzz_pipe_40_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= limb_3_41; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_41_s3 <= rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= limb_3_45; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_45_s2 <= rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_45_s3 <= rtlzz_pipe_45_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= limb_3_46; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_46_s2 <= rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_46_s3 <= rtlzz_pipe_46_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [126:0] a_data,input wire a_wen,input wire [64:0] b_data,input wire b_wen,output reg [128:0] y);
reg liv;wire cov;
reg [126:0] l_a;
reg [64:0] l_b;
wire [128:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=127'h00000000000000000;l_b<=65'h00000000000000000;y<=129'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
