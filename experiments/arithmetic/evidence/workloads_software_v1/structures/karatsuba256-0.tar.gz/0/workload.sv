`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [512:0] rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] rtlzz_pipe_156_s7; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_84_s1; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_234_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_164_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] rtlzz_pipe_235_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] rtlzz_pipe_165_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_266_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_238_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] rtlzz_pipe_239_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_272_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] rtlzz_pipe_242_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [65:0] rtlzz_pipe_180_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_243_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [128:0] rtlzz_pipe_248_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [33:0] rtlzz_pipe_198_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_94_s3; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_206_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_249_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [33:0] rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_114_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [63:0] rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] rtlzz_pipe_253_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] rtlzz_pipe_284_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_256_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] rtlzz_pipe_113_s4; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [33:0] rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_210_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s2; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_211_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_288_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_290_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_260_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] rtlzz_pipe_291_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_261_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_299_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_302_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_305_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_319_s7; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_323_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_335_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_341_s5; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_37_s2; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s3; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] rtlzz_pipe_37_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [255:0] rtlzz_pipe_11_s4; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_44_s5; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] rtlzz_pipe_45_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [129:0] rtlzz_pipe_39_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] rtlzz_pipe_39_s7; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [255:0] rtlzz_pipe_222_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [67:0] rtlzz_pipe_28_s7; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_79_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [129:0] rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] rtlzz_pipe_75_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [255:0] rtlzz_pipe_82_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] rtlzz_pipe_82_s4; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [255:0] rtlzz_pipe_83_s6; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [129:0] rtlzz_pipe_77_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] rtlzz_pipe_77_s7; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [255:0] rtlzz_pipe_220_s7; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [67:0] rtlzz_pipe_102_s4; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] rtlzz_pipe_102_s5; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [129:0] rtlzz_pipe_202_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_106_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] rtlzz_pipe_203_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_108_s6; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [131:0] rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] rtlzz_pipe_139_s6; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [257:0] rtlzz_pipe_145_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] rtlzz_pipe_145_s6; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [131:0] rtlzz_pipe_132_s5; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] rtlzz_pipe_132_s6; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [67:0] rtlzz_pipe_128_s5; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [131:0] rtlzz_pipe_119_s6; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [131:0] rtlzz_pipe_133_s6; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [257:0] rtlzz_pipe_219_s7; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = (rtlzz_pipe_12_s5 + rtlzz_pipe_234_s5); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = (tmp_workload_top_int_65__23_v0 + rtlzz_pipe_235_s4); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    assign tmp_workload_top_int_66__32_v0 = (rtlzz_pipe_164_s6 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (rtlzz_pipe_165_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign s8_norm_add_36_v0 = (tmp_workload_top_int_34__42_v0 + rtlzz_pipe_238_s7); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_add_39_v0 = (tmp_workload_top_int_34__47_v0 + rtlzz_pipe_239_s6); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = (n20_v0 - rtlzz_pipe_28_s7); // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = (s8_norm_sub_45_v0 - tmp_workload_top_int_68__60_v0); // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (__beopt_width_560 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (__beopt_width_561 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = (__beopt_width_317 - rtlzz_pipe_37_s7); // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    assign tmp_workload_top_int_130__76_v0 = (__beopt_width_562 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = (s8_norm_sub_56_v0 - rtlzz_pipe_39_s7); // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s6 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s4 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_44_s5 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = (tmp_workload_top_int_65__103_v0 + rtlzz_pipe_242_s6); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = (tmp_workload_top_int_65__108_v0 + rtlzz_pipe_243_s7); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    assign tmp_workload_top_int_66__117_v0 = (rtlzz_pipe_180_s7 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (__beopt_width_579 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign s8_norm_add_98_v0 = (tmp_workload_top_int_34__127_v0 + __beopt_width_367); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_add_101_v0 = (tmp_workload_top_int_34__132_v0 + __beopt_width_370); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = (n41_v0 - tmp_workload_top_int_68__142_v0); // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = (s8_norm_sub_107_v0 - tmp_workload_top_int_68__145_v0); // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = (__beopt_width_313 - rtlzz_pipe_75_s7); // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = (s8_norm_sub_118_v0 - rtlzz_pipe_77_s7); // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    assign tmp_workload_top_int_256__164_v0 = (s8_norm_mul_72_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_82_s4 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = (rtlzz_pipe_84_s1 + rtlzz_pipe_248_s1); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = (tmp_workload_top_int_129__179_v0 + rtlzz_pipe_249_s1); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (rtlzz_pipe_114_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s2 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign s8_norm_add_152_v0 = (rtlzz_pipe_94_s3 + __beopt_width_388); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_add_155_v0 = (tmp_workload_top_int_34__207_v0 + rtlzz_pipe_253_s5); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (__beopt_width_609 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = (n60_v0 - rtlzz_pipe_102_s5); // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = (s8_norm_sub_161_v0 - tmp_workload_top_int_68__220_v0); // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    assign tmp_workload_top_int_130__223_v0 = (rtlzz_pipe_202_s4 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s6 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (rtlzz_pipe_206_s3 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = (tmp_workload_top_int_66__238_v0 + rtlzz_pipe_256_s3); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = (tmp_workload_top_int_66__243_v0 + __beopt_width_404); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    assign tmp_workload_top_int_66__252_v0 = (rtlzz_pipe_113_s4 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s2 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (rtlzz_pipe_210_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign s8_norm_add_195_v0 = (tmp_workload_top_int_34__262_v0 + rtlzz_pipe_260_s5); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_add_198_v0 = (tmp_workload_top_int_34__267_v0 + rtlzz_pipe_261_s3); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = (n74_v0 - rtlzz_pipe_128_s5); // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = (s8_norm_sub_204_v0 - tmp_workload_top_int_68__280_v0); // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (rtlzz_pipe_133_s6 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (rtlzz_pipe_119_s6 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = (__beopt_width_307 - tmp_workload_top_int_132__293_v0); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = (s8_norm_sub_215_v0 - rtlzz_pipe_139_s6); // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__305_v0 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = (rtlzz_pipe_219_s7 - tmp_workload_top_int_258__309_v0); // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = (s8_norm_sub_226_v0 - tmp_workload_top_int_258__312_v0); // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = (tmp_workload_top_int_513__325_v0 + rtlzz_pipe_156_s7); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = (tmp_workload_top_int_512__315_v0 + s8_norm_shift_234_v0); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    assign __beopt_width_294 = (__beopt_width_292 + s8_norm_shift_231_v0); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    assign __beopt_width_295 = (rtlzz_pipe_145_s6 + tmp_workload_top_int_258__299_v0); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    assign __beopt_width_297 = (__beopt_width_295 + s8_norm_shift_220_v0); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    assign __beopt_width_299 = (rtlzz_pipe_79_s6 + rtlzz_pipe_83_s6); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    assign __beopt_width_301 = (rtlzz_pipe_220_s7 + s8_norm_shift_123_v0); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    assign __beopt_width_302 = (tmp_workload_top_int_256__79_v0 + rtlzz_pipe_45_s6); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    assign __beopt_width_303 = (rtlzz_pipe_222_s7 + s8_norm_shift_61_v0); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    assign __beopt_width_305 = (rtlzz_pipe_132_s6 + s8_norm_shift_212_v0); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    assign __beopt_width_307 = (__beopt_width_305 + s8_norm_shift_209_v0); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    assign __beopt_width_309 = (rtlzz_pipe_106_s6 + s8_norm_shift_169_v0); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    assign __beopt_width_310 = (__beopt_width_309 + rtlzz_pipe_108_s6); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    assign __beopt_width_311 = (tmp_workload_top_int_130__148_v0 + s8_norm_shift_115_v0); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    assign __beopt_width_313 = (__beopt_width_311 + s8_norm_shift_112_v0); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    assign __beopt_width_315 = (tmp_workload_top_int_130__63_v0 + s8_norm_shift_53_v0); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    assign __beopt_width_317 = (__beopt_width_315 + s8_norm_shift_50_v0); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (__beopt_width_325 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (__beopt_width_337 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (__beopt_width_340 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s1 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (rtlzz_pipe_272_s3 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s2 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (__beopt_width_362 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (__beopt_width_380 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (__beopt_width_386 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (__beopt_width_399 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (rtlzz_pipe_285_s4 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s2 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (__beopt_width_413 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (rtlzz_pipe_288_s4 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s5 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (rtlzz_pipe_290_s4 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s2 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_292_s1))) * $unsigned(128'($unsigned(mul_precision_293))))); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    assign arith_original_344 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_295_s3))) * $unsigned(128'($unsigned(mul_precision_296))))); // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    assign arith_original_345 = 66'(($unsigned(66'($unsigned(mul_precision_298))) * $unsigned(66'($unsigned(rtlzz_pipe_299_s6))))); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    assign arith_original_346 = 64'(($unsigned(64'($unsigned(mul_precision_301))) * $unsigned(64'($unsigned(rtlzz_pipe_302_s7))))); // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    assign arith_original_347 = 68'(($unsigned(68'($unsigned(mul_precision_304))) * $unsigned(68'($unsigned(rtlzz_pipe_305_s7))))); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign arith_original_348 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_307_s5))) * $unsigned(128'($unsigned(mul_precision_308))))); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    assign arith_original_349 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_310_s2))) * $unsigned(128'($unsigned(mul_precision_311))))); // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    assign arith_original_350 = 66'(($unsigned(66'($unsigned(mul_precision_313))) * $unsigned(66'($unsigned(mul_precision_314))))); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    assign arith_original_351 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_316_s7))) * $unsigned(64'($unsigned(mul_precision_317))))); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    assign arith_original_352 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_319_s7))) * $unsigned(68'($unsigned(mul_precision_320))))); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign arith_original_353 = 66'(($unsigned(66'($unsigned(mul_precision_322))) * $unsigned(66'($unsigned(rtlzz_pipe_323_s3))))); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    assign arith_original_354 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_325_s5))) * $unsigned(64'($unsigned(mul_precision_326))))); // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    assign arith_original_355 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_328_s5))) * $unsigned(68'($unsigned(mul_precision_329))))); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign arith_original_356 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_331_s4))) * $unsigned(128'($unsigned(mul_precision_332))))); // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    assign arith_original_357 = 66'(($unsigned(66'($unsigned(mul_precision_334))) * $unsigned(66'($unsigned(rtlzz_pipe_335_s4))))); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    assign arith_original_358 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_337_s5))) * $unsigned(66'($unsigned(mul_precision_338))))); // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    assign arith_original_359 = 68'(($unsigned(68'($unsigned(mul_precision_340))) * $unsigned(68'($unsigned(rtlzz_pipe_341_s5))))); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_156_s1 <= 513'h0;
            rtlzz_pipe_156_s2 <= 513'h0;
            rtlzz_pipe_156_s3 <= 513'h0;
            rtlzz_pipe_156_s4 <= 513'h0;
            rtlzz_pipe_156_s5 <= 513'h0;
            rtlzz_pipe_156_s6 <= 513'h0;
            rtlzz_pipe_156_s7 <= 513'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_12_s3 <= 65'h0;
            rtlzz_pipe_12_s4 <= 65'h0;
            rtlzz_pipe_12_s5 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_84_s1 <= 129'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_234_s5 <= 65'h0;
            rtlzz_pipe_164_s6 <= 66'h0;
            rtlzz_pipe_168_s6 <= 34'h0;
            rtlzz_pipe_168_s7 <= 34'h0;
            rtlzz_pipe_235_s1 <= 65'h0;
            rtlzz_pipe_235_s2 <= 65'h0;
            rtlzz_pipe_235_s3 <= 65'h0;
            rtlzz_pipe_235_s4 <= 65'h0;
            rtlzz_pipe_165_s5 <= 66'h0;
            rtlzz_pipe_169_s5 <= 34'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_266_s6 <= 64'h0;
            rtlzz_pipe_266_s7 <= 64'h0;
            rtlzz_pipe_238_s6 <= 34'h0;
            rtlzz_pipe_238_s7 <= 34'h0;
            rtlzz_pipe_239_s5 <= 34'h0;
            rtlzz_pipe_239_s6 <= 34'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_272_s1 <= 65'h0;
            rtlzz_pipe_272_s2 <= 65'h0;
            rtlzz_pipe_272_s3 <= 65'h0;
            rtlzz_pipe_242_s4 <= 65'h0;
            rtlzz_pipe_242_s5 <= 65'h0;
            rtlzz_pipe_242_s6 <= 65'h0;
            rtlzz_pipe_180_s7 <= 66'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_273_s2 <= 65'h0;
            rtlzz_pipe_243_s3 <= 65'h0;
            rtlzz_pipe_243_s4 <= 65'h0;
            rtlzz_pipe_243_s5 <= 65'h0;
            rtlzz_pipe_243_s6 <= 65'h0;
            rtlzz_pipe_243_s7 <= 65'h0;
            rtlzz_pipe_248_s1 <= 129'h0;
            rtlzz_pipe_198_s2 <= 34'h0;
            rtlzz_pipe_94_s3 <= 34'h0;
            rtlzz_pipe_206_s2 <= 66'h0;
            rtlzz_pipe_206_s3 <= 66'h0;
            rtlzz_pipe_249_s1 <= 129'h0;
            rtlzz_pipe_199_s2 <= 34'h0;
            rtlzz_pipe_199_s3 <= 34'h0;
            rtlzz_pipe_199_s4 <= 34'h0;
            rtlzz_pipe_199_s5 <= 34'h0;
            rtlzz_pipe_114_s2 <= 66'h0;
            rtlzz_pipe_280_s2 <= 64'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_280_s4 <= 64'h0;
            rtlzz_pipe_281_s2 <= 64'h0;
            rtlzz_pipe_281_s3 <= 64'h0;
            rtlzz_pipe_281_s4 <= 64'h0;
            rtlzz_pipe_281_s5 <= 64'h0;
            rtlzz_pipe_282_s2 <= 34'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_253_s2 <= 34'h0;
            rtlzz_pipe_253_s3 <= 34'h0;
            rtlzz_pipe_253_s4 <= 34'h0;
            rtlzz_pipe_253_s5 <= 34'h0;
            rtlzz_pipe_284_s2 <= 128'h0;
            rtlzz_pipe_285_s2 <= 128'h0;
            rtlzz_pipe_285_s3 <= 128'h0;
            rtlzz_pipe_285_s4 <= 128'h0;
            rtlzz_pipe_286_s2 <= 66'h0;
            rtlzz_pipe_256_s3 <= 66'h0;
            rtlzz_pipe_113_s4 <= 66'h0;
            rtlzz_pipe_210_s4 <= 34'h0;
            rtlzz_pipe_210_s5 <= 34'h0;
            rtlzz_pipe_115_s2 <= 66'h0;
            rtlzz_pipe_211_s2 <= 34'h0;
            rtlzz_pipe_211_s3 <= 34'h0;
            rtlzz_pipe_288_s4 <= 66'h0;
            rtlzz_pipe_289_s2 <= 66'h0;
            rtlzz_pipe_289_s3 <= 66'h0;
            rtlzz_pipe_289_s4 <= 66'h0;
            rtlzz_pipe_289_s5 <= 66'h0;
            rtlzz_pipe_290_s4 <= 34'h0;
            rtlzz_pipe_260_s5 <= 34'h0;
            rtlzz_pipe_291_s2 <= 34'h0;
            rtlzz_pipe_261_s3 <= 34'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_299_s6 <= 33'h0;
            rtlzz_pipe_302_s5 <= 32'h0;
            rtlzz_pipe_302_s6 <= 32'h0;
            rtlzz_pipe_302_s7 <= 32'h0;
            rtlzz_pipe_305_s7 <= 34'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s2 <= 64'h0;
            rtlzz_pipe_316_s7 <= 32'h0;
            rtlzz_pipe_319_s7 <= 34'h0;
            rtlzz_pipe_323_s3 <= 33'h0;
            rtlzz_pipe_325_s5 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_328_s5 <= 34'h0;
            rtlzz_pipe_331_s3 <= 64'h0;
            rtlzz_pipe_331_s4 <= 64'h0;
            rtlzz_pipe_335_s3 <= 33'h0;
            rtlzz_pipe_335_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_341_s4 <= 34'h0;
            rtlzz_pipe_341_s5 <= 34'h0;
            rtlzz_pipe_10_s2 <= 256'h0;
            rtlzz_pipe_10_s3 <= 256'h0;
            rtlzz_pipe_10_s4 <= 256'h0;
            rtlzz_pipe_10_s5 <= 256'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_37_s2 <= 130'h0;
            rtlzz_pipe_37_s3 <= 130'h0;
            rtlzz_pipe_37_s4 <= 130'h0;
            rtlzz_pipe_37_s5 <= 130'h0;
            rtlzz_pipe_37_s6 <= 130'h0;
            rtlzz_pipe_37_s7 <= 130'h0;
            rtlzz_pipe_11_s4 <= 256'h0;
            rtlzz_pipe_44_s5 <= 256'h0;
            rtlzz_pipe_45_s6 <= 256'h0;
            rtlzz_pipe_39_s4 <= 130'h0;
            rtlzz_pipe_39_s5 <= 130'h0;
            rtlzz_pipe_39_s6 <= 130'h0;
            rtlzz_pipe_39_s7 <= 130'h0;
            rtlzz_pipe_222_s7 <= 256'h0;
            rtlzz_pipe_28_s7 <= 68'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_79_s6 <= 256'h0;
            rtlzz_pipe_75_s6 <= 130'h0;
            rtlzz_pipe_75_s7 <= 130'h0;
            rtlzz_pipe_82_s3 <= 256'h0;
            rtlzz_pipe_82_s4 <= 256'h0;
            rtlzz_pipe_83_s5 <= 256'h0;
            rtlzz_pipe_83_s6 <= 256'h0;
            rtlzz_pipe_77_s3 <= 130'h0;
            rtlzz_pipe_77_s4 <= 130'h0;
            rtlzz_pipe_77_s5 <= 130'h0;
            rtlzz_pipe_77_s6 <= 130'h0;
            rtlzz_pipe_77_s7 <= 130'h0;
            rtlzz_pipe_220_s7 <= 256'h0;
            rtlzz_pipe_102_s4 <= 68'h0;
            rtlzz_pipe_102_s5 <= 68'h0;
            rtlzz_pipe_202_s4 <= 130'h0;
            rtlzz_pipe_106_s5 <= 130'h0;
            rtlzz_pipe_106_s6 <= 130'h0;
            rtlzz_pipe_203_s6 <= 130'h0;
            rtlzz_pipe_108_s6 <= 130'h0;
            rtlzz_pipe_139_s5 <= 132'h0;
            rtlzz_pipe_139_s6 <= 132'h0;
            rtlzz_pipe_145_s5 <= 258'h0;
            rtlzz_pipe_145_s6 <= 258'h0;
            rtlzz_pipe_132_s5 <= 132'h0;
            rtlzz_pipe_132_s6 <= 132'h0;
            rtlzz_pipe_128_s5 <= 68'h0;
            rtlzz_pipe_119_s6 <= 132'h0;
            rtlzz_pipe_133_s6 <= 132'h0;
            rtlzz_pipe_219_s7 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_156_s1 <= tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_156_s2 <= rtlzz_pipe_156_s1; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_156_s3 <= rtlzz_pipe_156_s2; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_156_s4 <= rtlzz_pipe_156_s3; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_156_s5 <= rtlzz_pipe_156_s4; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_156_s6 <= rtlzz_pipe_156_s5; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_156_s7 <= rtlzz_pipe_156_s6; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_84_s1 <= tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_234_s5 <= __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_164_s6 <= __beopt_width_545; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_168_s6 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_168_s7 <= rtlzz_pipe_168_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_235_s1 <= __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_235_s2 <= rtlzz_pipe_235_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_235_s3 <= rtlzz_pipe_235_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_235_s4 <= rtlzz_pipe_235_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_165_s5 <= __beopt_width_546; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_169_s5 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= rtlzz_pipe_169_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_266_s6 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_266_s7 <= rtlzz_pipe_266_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_238_s6 <= __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_238_s7 <= rtlzz_pipe_238_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_239_s5 <= __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_239_s6 <= rtlzz_pipe_239_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_272_s1 <= __beopt_width_353; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_272_s2 <= rtlzz_pipe_272_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_272_s3 <= rtlzz_pipe_272_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_242_s4 <= __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_242_s5 <= rtlzz_pipe_242_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_242_s6 <= rtlzz_pipe_242_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_180_s7 <= __beopt_width_573; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_273_s2 <= rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_243_s3 <= __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_243_s4 <= rtlzz_pipe_243_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_243_s5 <= rtlzz_pipe_243_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_243_s6 <= rtlzz_pipe_243_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_243_s7 <= rtlzz_pipe_243_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_248_s1 <= __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_198_s2 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_94_s3 <= tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_206_s2 <= __beopt_width_617; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_206_s3 <= rtlzz_pipe_206_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_249_s1 <= __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_199_s2 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_199_s3 <= rtlzz_pipe_199_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_199_s4 <= rtlzz_pipe_199_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_199_s5 <= rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_114_s2 <= tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_280_s2 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= rtlzz_pipe_280_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_280_s4 <= rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_281_s2 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_281_s3 <= rtlzz_pipe_281_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_281_s4 <= rtlzz_pipe_281_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_281_s5 <= rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_282_s2 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= rtlzz_pipe_282_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_253_s2 <= __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_253_s3 <= rtlzz_pipe_253_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_253_s4 <= rtlzz_pipe_253_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_253_s5 <= rtlzz_pipe_253_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_284_s2 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_285_s2 <= __beopt_width_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_285_s3 <= rtlzz_pipe_285_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_285_s4 <= rtlzz_pipe_285_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_286_s2 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_256_s3 <= __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_113_s4 <= s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_210_s4 <= __beopt_width_627; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_210_s5 <= rtlzz_pipe_210_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_115_s2 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_211_s2 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_211_s3 <= rtlzz_pipe_211_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_288_s4 <= __beopt_width_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_289_s2 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_289_s3 <= rtlzz_pipe_289_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_289_s4 <= rtlzz_pipe_289_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= rtlzz_pipe_289_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_290_s4 <= __beopt_width_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_260_s5 <= __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_291_s2 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_261_s3 <= __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_299_s6 <= mul_precision_299; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_302_s5 <= mul_precision_302; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_302_s6 <= rtlzz_pipe_302_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_302_s7 <= rtlzz_pipe_302_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_305_s7 <= mul_precision_305; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_310_s2 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_316_s7 <= mul_precision_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_319_s7 <= mul_precision_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_323_s3 <= mul_precision_323; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_325_s5 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_328_s5 <= rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_331_s3 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_331_s4 <= rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_335_s3 <= mul_precision_335; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_335_s4 <= rtlzz_pipe_335_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_341_s4 <= mul_precision_341; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_341_s5 <= rtlzz_pipe_341_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_10_s3 <= rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_10_s4 <= rtlzz_pipe_10_s3; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_10_s5 <= rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_37_s3 <= rtlzz_pipe_37_s2; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_37_s4 <= rtlzz_pipe_37_s3; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_37_s5 <= rtlzz_pipe_37_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_37_s6 <= rtlzz_pipe_37_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_37_s7 <= rtlzz_pipe_37_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_11_s4 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_39_s4 <= tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_39_s5 <= rtlzz_pipe_39_s4; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_39_s6 <= rtlzz_pipe_39_s5; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_39_s7 <= rtlzz_pipe_39_s6; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_222_s7 <= __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_28_s7 <= tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_75_s7 <= rtlzz_pipe_75_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_82_s3 <= tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_82_s4 <= rtlzz_pipe_82_s3; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_83_s5 <= s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= rtlzz_pipe_83_s5; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_77_s3 <= tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_77_s4 <= rtlzz_pipe_77_s3; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_77_s5 <= rtlzz_pipe_77_s4; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_77_s6 <= rtlzz_pipe_77_s5; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_77_s7 <= rtlzz_pipe_77_s6; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_220_s7 <= __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_102_s4 <= tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_102_s5 <= rtlzz_pipe_102_s4; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_202_s4 <= __beopt_width_611; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_106_s6 <= rtlzz_pipe_106_s5; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_203_s6 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_108_s6 <= s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_139_s5 <= tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_139_s6 <= rtlzz_pipe_139_s5; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_145_s5 <= s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_145_s6 <= rtlzz_pipe_145_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_132_s5 <= tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_132_s6 <= rtlzz_pipe_132_s5; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_128_s5 <= tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_119_s6 <= s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_133_s6 <= tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_219_s7 <= __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
