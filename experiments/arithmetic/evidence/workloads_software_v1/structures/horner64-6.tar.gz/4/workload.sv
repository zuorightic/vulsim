`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [31:0] mul_tree_17_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_25; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_26; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_28; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_29; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_30; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_17_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_32; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_17_33; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_34; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_17_35; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_36; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_37; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_17_38; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_39; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_40; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_17_41; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_42; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_43; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_17_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_17_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_50; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_51; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_52; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_54; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_55; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_18_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_18_58; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_59; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_18_60; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_61; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_62; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_18_63; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_64; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_65; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_18_66; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_67; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_68; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_18_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_18_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_72; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_74; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_75; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_76; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_77; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_78; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_79; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_80; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_19_81; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_82; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_19_83; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_84; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_19_85; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_86; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_87; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_19_88; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_89; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_90; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_19_91; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_92; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_93; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_19_94; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_19_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_96; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_97; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_98; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_100; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_101; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_102; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_104; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_105; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_20_106; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_20_108; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_109; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_20_110; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_20_113; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_114; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_115; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_20_116; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_20_119; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_20_120; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_1_s7; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_2_s7; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [63:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_3_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_4_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [63:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_41_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_7_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] rtlzz_pipe_8_s4; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] rtlzz_pipe_48_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_56_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_60_s5; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_63_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_66_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_73_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_77_s7; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_81_s7; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_85_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = (rtlzz_pipe_7_s3 + rtlzz_pipe_4_s3); // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_add_5_v0 = (s8_norm_mul_3_v0 + rtlzz_pipe_3_s6); // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    assign s8_norm_add_8_v0 = (s8_norm_mul_6_v0 + rtlzz_pipe_2_s7); // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_add_11_v0 = (s8_norm_mul_9_v0 + rtlzz_pipe_1_s7); // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign arith_original_17 = mul_tree_17_45; // decl: <none>; prim: <none>
    assign arith_original_18 = mul_tree_18_70; // decl: <none>; prim: <none>
    assign arith_original_19 = mul_tree_19_95; // decl: <none>; prim: <none>
    assign arith_original_20 = mul_tree_20_120; // decl: <none>; prim: <none>
    assign mul_tree_17_21 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_22 = x[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_23 = 64'(($unsigned(64'($unsigned(mul_tree_17_21))) * $unsigned(64'($unsigned(mul_tree_17_22))))); // decl: <none>; prim: <none>
    assign mul_tree_17_24 = c4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_25 = x[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_26 = 64'(($unsigned(64'($unsigned(mul_tree_17_24))) * $unsigned(64'($unsigned(mul_tree_17_25))))); // decl: <none>; prim: <none>
    assign mul_tree_17_27 = {mul_tree_17_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_28 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_29 = x[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_17_30 = 64'(($unsigned(64'($unsigned(mul_tree_17_28))) * $unsigned(64'($unsigned(mul_tree_17_29))))); // decl: <none>; prim: <none>
    assign mul_tree_17_31 = {mul_tree_17_30, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_32 = c4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_33 = x[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_17_34 = 64'(($unsigned(64'($unsigned(mul_tree_17_32))) * $unsigned(64'($unsigned(mul_tree_17_33))))); // decl: <none>; prim: <none>
    assign mul_tree_17_35 = {mul_tree_17_34, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_17_36 = ({33'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_37 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_38 = 97'((mul_tree_17_36 + mul_tree_17_37 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_39 = ({33'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_40 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_17_41 = 129'((mul_tree_17_39 + mul_tree_17_40 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_42 = ({33'h0, rtlzz_pipe_38_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_43 = ({1'h0, rtlzz_pipe_41_s2}); // decl: <none>; prim: <none>
    assign mul_tree_17_44 = 130'((mul_tree_17_42 + mul_tree_17_43 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_17_45 = mul_tree_17_44[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_46 = rtlzz_pipe_8_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_47 = rtlzz_pipe_0_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_48 = 64'(($unsigned(64'($unsigned(mul_tree_18_46))) * $unsigned(64'($unsigned(mul_tree_18_47))))); // decl: <none>; prim: <none>
    assign mul_tree_18_49 = rtlzz_pipe_8_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_50 = rtlzz_pipe_0_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_51 = 64'(($unsigned(64'($unsigned(mul_tree_18_49))) * $unsigned(64'($unsigned(mul_tree_18_50))))); // decl: <none>; prim: <none>
    assign mul_tree_18_52 = {mul_tree_18_51, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_53 = rtlzz_pipe_8_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_54 = rtlzz_pipe_0_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_18_55 = 64'(($unsigned(64'($unsigned(mul_tree_18_53))) * $unsigned(64'($unsigned(mul_tree_18_54))))); // decl: <none>; prim: <none>
    assign mul_tree_18_56 = {mul_tree_18_55, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_57 = rtlzz_pipe_8_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_58 = rtlzz_pipe_0_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_18_59 = 64'(($unsigned(64'($unsigned(mul_tree_18_57))) * $unsigned(64'($unsigned(mul_tree_18_58))))); // decl: <none>; prim: <none>
    assign mul_tree_18_60 = {mul_tree_18_59, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_18_61 = ({33'h0, rtlzz_pipe_48_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_62 = ({1'h0, rtlzz_pipe_52_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_63 = 97'((mul_tree_18_61 + mul_tree_18_62 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_18_64 = ({33'h0, rtlzz_pipe_56_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_65 = ({1'h0, rtlzz_pipe_60_s5}); // decl: <none>; prim: <none>
    assign mul_tree_18_66 = 129'((mul_tree_18_64 + mul_tree_18_65 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_18_67 = ({33'h0, rtlzz_pipe_63_s6}); // decl: <none>; prim: <none>
    assign mul_tree_18_68 = ({1'h0, rtlzz_pipe_66_s6}); // decl: <none>; prim: <none>
    assign mul_tree_18_69 = 130'((mul_tree_18_67 + mul_tree_18_68 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_18_70 = mul_tree_18_69[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_71 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_72 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_73 = 64'(($unsigned(64'($unsigned(mul_tree_19_71))) * $unsigned(64'($unsigned(mul_tree_19_72))))); // decl: <none>; prim: <none>
    assign mul_tree_19_74 = s8_norm_add_5_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_75 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_76 = 64'(($unsigned(64'($unsigned(mul_tree_19_74))) * $unsigned(64'($unsigned(mul_tree_19_75))))); // decl: <none>; prim: <none>
    assign mul_tree_19_77 = {mul_tree_19_76, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_78 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_79 = rtlzz_pipe_0_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_19_80 = 64'(($unsigned(64'($unsigned(mul_tree_19_78))) * $unsigned(64'($unsigned(mul_tree_19_79))))); // decl: <none>; prim: <none>
    assign mul_tree_19_81 = {mul_tree_19_80, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_82 = s8_norm_add_5_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_83 = rtlzz_pipe_0_s6[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_19_84 = 64'(($unsigned(64'($unsigned(mul_tree_19_82))) * $unsigned(64'($unsigned(mul_tree_19_83))))); // decl: <none>; prim: <none>
    assign mul_tree_19_85 = {mul_tree_19_84, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_19_86 = ({33'h0, rtlzz_pipe_73_s7}); // decl: <none>; prim: <none>
    assign mul_tree_19_87 = ({1'h0, rtlzz_pipe_77_s7}); // decl: <none>; prim: <none>
    assign mul_tree_19_88 = 97'((mul_tree_19_86 + mul_tree_19_87 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_19_89 = ({33'h0, rtlzz_pipe_81_s7}); // decl: <none>; prim: <none>
    assign mul_tree_19_90 = ({1'h0, rtlzz_pipe_85_s7}); // decl: <none>; prim: <none>
    assign mul_tree_19_91 = 129'((mul_tree_19_89 + mul_tree_19_90 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_19_92 = ({33'h0, mul_tree_19_88}); // decl: <none>; prim: <none>
    assign mul_tree_19_93 = ({1'h0, mul_tree_19_91}); // decl: <none>; prim: <none>
    assign mul_tree_19_94 = 130'((mul_tree_19_92 + mul_tree_19_93 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_19_95 = mul_tree_19_94[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_96 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_97 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_98 = 64'(($unsigned(64'($unsigned(mul_tree_20_96))) * $unsigned(64'($unsigned(mul_tree_20_97))))); // decl: <none>; prim: <none>
    assign mul_tree_20_99 = s8_norm_add_8_v0[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_100 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_101 = 64'(($unsigned(64'($unsigned(mul_tree_20_99))) * $unsigned(64'($unsigned(mul_tree_20_100))))); // decl: <none>; prim: <none>
    assign mul_tree_20_102 = {mul_tree_20_101, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_103 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_104 = rtlzz_pipe_0_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_20_105 = 64'(($unsigned(64'($unsigned(mul_tree_20_103))) * $unsigned(64'($unsigned(mul_tree_20_104))))); // decl: <none>; prim: <none>
    assign mul_tree_20_106 = {mul_tree_20_105, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_107 = s8_norm_add_8_v0[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_108 = rtlzz_pipe_0_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_20_109 = 64'(($unsigned(64'($unsigned(mul_tree_20_107))) * $unsigned(64'($unsigned(mul_tree_20_108))))); // decl: <none>; prim: <none>
    assign mul_tree_20_110 = {mul_tree_20_109, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_20_111 = ({33'h0, mul_tree_20_98}); // decl: <none>; prim: <none>
    assign mul_tree_20_112 = ({1'h0, mul_tree_20_102}); // decl: <none>; prim: <none>
    assign mul_tree_20_113 = 97'((mul_tree_20_111 + mul_tree_20_112 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_20_114 = ({33'h0, mul_tree_20_106}); // decl: <none>; prim: <none>
    assign mul_tree_20_115 = ({1'h0, mul_tree_20_110}); // decl: <none>; prim: <none>
    assign mul_tree_20_116 = 129'((mul_tree_20_114 + mul_tree_20_115 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_20_117 = ({33'h0, mul_tree_20_113}); // decl: <none>; prim: <none>
    assign mul_tree_20_118 = ({1'h0, mul_tree_20_116}); // decl: <none>; prim: <none>
    assign mul_tree_20_119 = 130'((mul_tree_20_117 + mul_tree_20_118 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_20_120 = mul_tree_20_119[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_1_s1 <= 64'h0;
            rtlzz_pipe_1_s2 <= 64'h0;
            rtlzz_pipe_1_s3 <= 64'h0;
            rtlzz_pipe_1_s4 <= 64'h0;
            rtlzz_pipe_1_s5 <= 64'h0;
            rtlzz_pipe_1_s6 <= 64'h0;
            rtlzz_pipe_1_s7 <= 64'h0;
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_2_s3 <= 64'h0;
            rtlzz_pipe_2_s4 <= 64'h0;
            rtlzz_pipe_2_s5 <= 64'h0;
            rtlzz_pipe_2_s6 <= 64'h0;
            rtlzz_pipe_2_s7 <= 64'h0;
            rtlzz_pipe_3_s1 <= 64'h0;
            rtlzz_pipe_3_s2 <= 64'h0;
            rtlzz_pipe_3_s3 <= 64'h0;
            rtlzz_pipe_3_s4 <= 64'h0;
            rtlzz_pipe_3_s5 <= 64'h0;
            rtlzz_pipe_3_s6 <= 64'h0;
            rtlzz_pipe_4_s1 <= 64'h0;
            rtlzz_pipe_4_s2 <= 64'h0;
            rtlzz_pipe_4_s3 <= 64'h0;
            rtlzz_pipe_23_s1 <= 64'h0;
            rtlzz_pipe_27_s1 <= 96'h0;
            rtlzz_pipe_31_s1 <= 96'h0;
            rtlzz_pipe_35_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 97'h0;
            rtlzz_pipe_41_s2 <= 129'h0;
            rtlzz_pipe_7_s3 <= 64'h0;
            rtlzz_pipe_8_s4 <= 64'h0;
            rtlzz_pipe_48_s5 <= 64'h0;
            rtlzz_pipe_52_s5 <= 96'h0;
            rtlzz_pipe_56_s5 <= 96'h0;
            rtlzz_pipe_60_s5 <= 128'h0;
            rtlzz_pipe_63_s6 <= 97'h0;
            rtlzz_pipe_66_s6 <= 129'h0;
            rtlzz_pipe_73_s7 <= 64'h0;
            rtlzz_pipe_77_s7 <= 96'h0;
            rtlzz_pipe_81_s7 <= 96'h0;
            rtlzz_pipe_85_s7 <= 128'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_1_s1 <= c0; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1_s2 <= rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1_s3 <= rtlzz_pipe_1_s2; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1_s4 <= rtlzz_pipe_1_s3; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1_s5 <= rtlzz_pipe_1_s4; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1_s6 <= rtlzz_pipe_1_s5; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1_s7 <= rtlzz_pipe_1_s6; // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
        end
        if (iv) begin
        rtlzz_pipe_2_s1 <= c1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_2_s3 <= rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_2_s4 <= rtlzz_pipe_2_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_2_s5 <= rtlzz_pipe_2_s4; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_2_s6 <= rtlzz_pipe_2_s5; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_2_s7 <= rtlzz_pipe_2_s6; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= c2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_3_s2 <= rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= rtlzz_pipe_3_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_3_s4 <= rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_3_s5 <= rtlzz_pipe_3_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_3_s6 <= rtlzz_pipe_3_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= c3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_4_s3 <= rtlzz_pipe_4_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_17_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_17_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_17_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_17_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= mul_tree_17_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= mul_tree_17_41; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_8_s4 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_48_s5 <= mul_tree_18_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= mul_tree_18_52; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_56_s5 <= mul_tree_18_56; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_60_s5 <= mul_tree_18_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_63_s6 <= mul_tree_18_63; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_66_s6 <= mul_tree_18_66; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_73_s7 <= mul_tree_19_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_77_s7 <= mul_tree_19_77; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_81_s7 <= mul_tree_19_81; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_85_s7 <= mul_tree_19_85; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
