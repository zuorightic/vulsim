`timescale 1ns/1ps

module WorkloadCore(
    input logic [511:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [511:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [512:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:10-13:35; prim: /home/zyrv/vulsim/workload.cpp:13:24-13:35
    logic [512:0] limb_3_6; // decl: <none>; prim: <none>
    logic [512:0] limb_3_7; // decl: <none>; prim: <none>
    logic [31:0] limb_3_8; // decl: <none>; prim: <none>
    logic [31:0] limb_3_9; // decl: <none>; prim: <none>
    logic [32:0] limb_3_10; // decl: <none>; prim: <none>
    logic [31:0] limb_3_11; // decl: <none>; prim: <none>
    logic limb_3_12; // decl: <none>; prim: <none>
    logic [31:0] limb_3_13; // decl: <none>; prim: <none>
    logic [31:0] limb_3_14; // decl: <none>; prim: <none>
    logic [32:0] limb_3_15; // decl: <none>; prim: <none>
    logic [31:0] limb_3_16; // decl: <none>; prim: <none>
    logic limb_3_17; // decl: <none>; prim: <none>
    logic [31:0] limb_3_18; // decl: <none>; prim: <none>
    logic [31:0] limb_3_19; // decl: <none>; prim: <none>
    logic [32:0] limb_3_20; // decl: <none>; prim: <none>
    logic [31:0] limb_3_21; // decl: <none>; prim: <none>
    logic limb_3_22; // decl: <none>; prim: <none>
    logic [31:0] limb_3_23; // decl: <none>; prim: <none>
    logic [31:0] limb_3_24; // decl: <none>; prim: <none>
    logic [32:0] limb_3_25; // decl: <none>; prim: <none>
    logic [31:0] limb_3_26; // decl: <none>; prim: <none>
    logic limb_3_27; // decl: <none>; prim: <none>
    logic [31:0] limb_3_28; // decl: <none>; prim: <none>
    logic [31:0] limb_3_29; // decl: <none>; prim: <none>
    logic [32:0] limb_3_30; // decl: <none>; prim: <none>
    logic [31:0] limb_3_31; // decl: <none>; prim: <none>
    logic limb_3_32; // decl: <none>; prim: <none>
    logic [31:0] limb_3_33; // decl: <none>; prim: <none>
    logic [31:0] limb_3_34; // decl: <none>; prim: <none>
    logic [32:0] limb_3_35; // decl: <none>; prim: <none>
    logic [31:0] limb_3_36; // decl: <none>; prim: <none>
    logic limb_3_37; // decl: <none>; prim: <none>
    logic [31:0] limb_3_38; // decl: <none>; prim: <none>
    logic [31:0] limb_3_39; // decl: <none>; prim: <none>
    logic [32:0] limb_3_40; // decl: <none>; prim: <none>
    logic [31:0] limb_3_41; // decl: <none>; prim: <none>
    logic limb_3_42; // decl: <none>; prim: <none>
    logic [31:0] limb_3_43; // decl: <none>; prim: <none>
    logic [31:0] limb_3_44; // decl: <none>; prim: <none>
    logic [32:0] limb_3_45; // decl: <none>; prim: <none>
    logic [31:0] limb_3_46; // decl: <none>; prim: <none>
    logic limb_3_47; // decl: <none>; prim: <none>
    logic [31:0] limb_3_48; // decl: <none>; prim: <none>
    logic [31:0] limb_3_49; // decl: <none>; prim: <none>
    logic [32:0] limb_3_50; // decl: <none>; prim: <none>
    logic [31:0] limb_3_51; // decl: <none>; prim: <none>
    logic limb_3_52; // decl: <none>; prim: <none>
    logic [31:0] limb_3_53; // decl: <none>; prim: <none>
    logic [31:0] limb_3_54; // decl: <none>; prim: <none>
    logic [32:0] limb_3_55; // decl: <none>; prim: <none>
    logic [31:0] limb_3_56; // decl: <none>; prim: <none>
    logic limb_3_57; // decl: <none>; prim: <none>
    logic [31:0] limb_3_58; // decl: <none>; prim: <none>
    logic [31:0] limb_3_59; // decl: <none>; prim: <none>
    logic [32:0] limb_3_60; // decl: <none>; prim: <none>
    logic [31:0] limb_3_61; // decl: <none>; prim: <none>
    logic limb_3_62; // decl: <none>; prim: <none>
    logic [31:0] limb_3_63; // decl: <none>; prim: <none>
    logic [31:0] limb_3_64; // decl: <none>; prim: <none>
    logic [32:0] limb_3_65; // decl: <none>; prim: <none>
    logic [31:0] limb_3_66; // decl: <none>; prim: <none>
    logic limb_3_67; // decl: <none>; prim: <none>
    logic [31:0] limb_3_68; // decl: <none>; prim: <none>
    logic [31:0] limb_3_69; // decl: <none>; prim: <none>
    logic [32:0] limb_3_70; // decl: <none>; prim: <none>
    logic [31:0] limb_3_71; // decl: <none>; prim: <none>
    logic limb_3_72; // decl: <none>; prim: <none>
    logic [31:0] limb_3_73; // decl: <none>; prim: <none>
    logic [31:0] limb_3_74; // decl: <none>; prim: <none>
    logic [32:0] limb_3_75; // decl: <none>; prim: <none>
    logic [31:0] limb_3_76; // decl: <none>; prim: <none>
    logic limb_3_77; // decl: <none>; prim: <none>
    logic [31:0] limb_3_78; // decl: <none>; prim: <none>
    logic [31:0] limb_3_79; // decl: <none>; prim: <none>
    logic [32:0] limb_3_80; // decl: <none>; prim: <none>
    logic [31:0] limb_3_81; // decl: <none>; prim: <none>
    logic limb_3_82; // decl: <none>; prim: <none>
    logic [31:0] limb_3_83; // decl: <none>; prim: <none>
    logic [31:0] limb_3_84; // decl: <none>; prim: <none>
    logic [32:0] limb_3_85; // decl: <none>; prim: <none>
    logic [31:0] limb_3_86; // decl: <none>; prim: <none>
    logic limb_3_87; // decl: <none>; prim: <none>
    logic limb_3_88; // decl: <none>; prim: <none>
    logic limb_3_89; // decl: <none>; prim: <none>
    logic [1:0] limb_3_90; // decl: <none>; prim: <none>
    logic limb_3_91; // decl: <none>; prim: <none>
    logic [512:0] limb_3_92; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_11_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_11_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_11_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_12_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_14_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_16_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_21_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_21_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_22_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_23_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_26_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_28_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_29_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_31_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_33_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_33_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_34_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_34_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_38_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_39_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_39_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_43_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_43_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_44_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_48_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_49_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_49_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_53_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_53_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_54_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_58_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_58_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_59_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_59_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_63_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_63_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_64_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_64_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_64_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_68_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_68_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_68_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_69_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_69_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_73_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_73_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_74_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_74_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_78_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_78_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_79_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_83_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_83_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_83_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_84_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_84_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_84_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_88_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_89_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_89_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_add_2_v0 = limb_3_92; // decl: <none>; prim: <none>
    assign y = s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign limb_3_6 = ({1'h0, a}); // decl: <none>; prim: <none>
    assign limb_3_7 = ({1'h0, b}); // decl: <none>; prim: <none>
    assign limb_3_8 = limb_3_6[31:0]; // decl: <none>; prim: <none>
    assign limb_3_9 = limb_3_7[31:0]; // decl: <none>; prim: <none>
    assign limb_3_10 = 33'((({1'h0, limb_3_8}) + ({1'h0, limb_3_9}) + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_3_11 = limb_3_10[31:0]; // decl: <none>; prim: <none>
    assign limb_3_12 = limb_3_10[32]; // decl: <none>; prim: <none>
    assign limb_3_13 = limb_3_6[63:32]; // decl: <none>; prim: <none>
    assign limb_3_14 = limb_3_7[63:32]; // decl: <none>; prim: <none>
    assign limb_3_15 = 33'((({1'h0, rtlzz_pipe_13_s1}) + ({1'h0, rtlzz_pipe_14_s1}) + ({32'h0, rtlzz_pipe_12_s1}))); // decl: <none>; prim: <none>
    assign limb_3_16 = limb_3_15[31:0]; // decl: <none>; prim: <none>
    assign limb_3_17 = limb_3_15[32]; // decl: <none>; prim: <none>
    assign limb_3_18 = limb_3_6[95:64]; // decl: <none>; prim: <none>
    assign limb_3_19 = limb_3_7[95:64]; // decl: <none>; prim: <none>
    assign limb_3_20 = 33'((({1'h0, rtlzz_pipe_18_s1}) + ({1'h0, rtlzz_pipe_19_s1}) + ({32'h0, limb_3_17}))); // decl: <none>; prim: <none>
    assign limb_3_21 = limb_3_20[31:0]; // decl: <none>; prim: <none>
    assign limb_3_22 = limb_3_20[32]; // decl: <none>; prim: <none>
    assign limb_3_23 = limb_3_6[127:96]; // decl: <none>; prim: <none>
    assign limb_3_24 = limb_3_7[127:96]; // decl: <none>; prim: <none>
    assign limb_3_25 = 33'((({1'h0, rtlzz_pipe_23_s2}) + ({1'h0, rtlzz_pipe_24_s2}) + ({32'h0, rtlzz_pipe_22_s2}))); // decl: <none>; prim: <none>
    assign limb_3_26 = limb_3_25[31:0]; // decl: <none>; prim: <none>
    assign limb_3_27 = limb_3_25[32]; // decl: <none>; prim: <none>
    assign limb_3_28 = limb_3_6[159:128]; // decl: <none>; prim: <none>
    assign limb_3_29 = limb_3_7[159:128]; // decl: <none>; prim: <none>
    assign limb_3_30 = 33'((({1'h0, rtlzz_pipe_28_s2}) + ({1'h0, rtlzz_pipe_29_s2}) + ({32'h0, limb_3_27}))); // decl: <none>; prim: <none>
    assign limb_3_31 = limb_3_30[31:0]; // decl: <none>; prim: <none>
    assign limb_3_32 = limb_3_30[32]; // decl: <none>; prim: <none>
    assign limb_3_33 = limb_3_6[191:160]; // decl: <none>; prim: <none>
    assign limb_3_34 = limb_3_7[191:160]; // decl: <none>; prim: <none>
    assign limb_3_35 = 33'((({1'h0, rtlzz_pipe_33_s3}) + ({1'h0, rtlzz_pipe_34_s3}) + ({32'h0, rtlzz_pipe_32_s3}))); // decl: <none>; prim: <none>
    assign limb_3_36 = limb_3_35[31:0]; // decl: <none>; prim: <none>
    assign limb_3_37 = limb_3_35[32]; // decl: <none>; prim: <none>
    assign limb_3_38 = limb_3_6[223:192]; // decl: <none>; prim: <none>
    assign limb_3_39 = limb_3_7[223:192]; // decl: <none>; prim: <none>
    assign limb_3_40 = 33'((({1'h0, rtlzz_pipe_38_s3}) + ({1'h0, rtlzz_pipe_39_s3}) + ({32'h0, limb_3_37}))); // decl: <none>; prim: <none>
    assign limb_3_41 = limb_3_40[31:0]; // decl: <none>; prim: <none>
    assign limb_3_42 = limb_3_40[32]; // decl: <none>; prim: <none>
    assign limb_3_43 = limb_3_6[255:224]; // decl: <none>; prim: <none>
    assign limb_3_44 = limb_3_7[255:224]; // decl: <none>; prim: <none>
    assign limb_3_45 = 33'((({1'h0, rtlzz_pipe_43_s3}) + ({1'h0, rtlzz_pipe_44_s3}) + ({32'h0, limb_3_42}))); // decl: <none>; prim: <none>
    assign limb_3_46 = limb_3_45[31:0]; // decl: <none>; prim: <none>
    assign limb_3_47 = limb_3_45[32]; // decl: <none>; prim: <none>
    assign limb_3_48 = limb_3_6[287:256]; // decl: <none>; prim: <none>
    assign limb_3_49 = limb_3_7[287:256]; // decl: <none>; prim: <none>
    assign limb_3_50 = 33'((({1'h0, rtlzz_pipe_48_s3}) + ({1'h0, rtlzz_pipe_49_s3}) + ({32'h0, limb_3_47}))); // decl: <none>; prim: <none>
    assign limb_3_51 = limb_3_50[31:0]; // decl: <none>; prim: <none>
    assign limb_3_52 = limb_3_50[32]; // decl: <none>; prim: <none>
    assign limb_3_53 = limb_3_6[319:288]; // decl: <none>; prim: <none>
    assign limb_3_54 = limb_3_7[319:288]; // decl: <none>; prim: <none>
    assign limb_3_55 = 33'((({1'h0, rtlzz_pipe_53_s3}) + ({1'h0, rtlzz_pipe_54_s3}) + ({32'h0, limb_3_52}))); // decl: <none>; prim: <none>
    assign limb_3_56 = limb_3_55[31:0]; // decl: <none>; prim: <none>
    assign limb_3_57 = limb_3_55[32]; // decl: <none>; prim: <none>
    assign limb_3_58 = limb_3_6[351:320]; // decl: <none>; prim: <none>
    assign limb_3_59 = limb_3_7[351:320]; // decl: <none>; prim: <none>
    assign limb_3_60 = 33'((({1'h0, rtlzz_pipe_58_s3}) + ({1'h0, rtlzz_pipe_59_s3}) + ({32'h0, limb_3_57}))); // decl: <none>; prim: <none>
    assign limb_3_61 = limb_3_60[31:0]; // decl: <none>; prim: <none>
    assign limb_3_62 = limb_3_60[32]; // decl: <none>; prim: <none>
    assign limb_3_63 = limb_3_6[383:352]; // decl: <none>; prim: <none>
    assign limb_3_64 = limb_3_7[383:352]; // decl: <none>; prim: <none>
    assign limb_3_65 = 33'((({1'h0, rtlzz_pipe_63_s3}) + ({1'h0, rtlzz_pipe_64_s3}) + ({32'h0, limb_3_62}))); // decl: <none>; prim: <none>
    assign limb_3_66 = limb_3_65[31:0]; // decl: <none>; prim: <none>
    assign limb_3_67 = limb_3_65[32]; // decl: <none>; prim: <none>
    assign limb_3_68 = limb_3_6[415:384]; // decl: <none>; prim: <none>
    assign limb_3_69 = limb_3_7[415:384]; // decl: <none>; prim: <none>
    assign limb_3_70 = 33'((({1'h0, rtlzz_pipe_68_s3}) + ({1'h0, rtlzz_pipe_69_s3}) + ({32'h0, limb_3_67}))); // decl: <none>; prim: <none>
    assign limb_3_71 = limb_3_70[31:0]; // decl: <none>; prim: <none>
    assign limb_3_72 = limb_3_70[32]; // decl: <none>; prim: <none>
    assign limb_3_73 = limb_3_6[447:416]; // decl: <none>; prim: <none>
    assign limb_3_74 = limb_3_7[447:416]; // decl: <none>; prim: <none>
    assign limb_3_75 = 33'((({1'h0, rtlzz_pipe_73_s3}) + ({1'h0, rtlzz_pipe_74_s3}) + ({32'h0, limb_3_72}))); // decl: <none>; prim: <none>
    assign limb_3_76 = limb_3_75[31:0]; // decl: <none>; prim: <none>
    assign limb_3_77 = limb_3_75[32]; // decl: <none>; prim: <none>
    assign limb_3_78 = limb_3_6[479:448]; // decl: <none>; prim: <none>
    assign limb_3_79 = limb_3_7[479:448]; // decl: <none>; prim: <none>
    assign limb_3_80 = 33'((({1'h0, rtlzz_pipe_78_s3}) + ({1'h0, rtlzz_pipe_79_s3}) + ({32'h0, limb_3_77}))); // decl: <none>; prim: <none>
    assign limb_3_81 = limb_3_80[31:0]; // decl: <none>; prim: <none>
    assign limb_3_82 = limb_3_80[32]; // decl: <none>; prim: <none>
    assign limb_3_83 = limb_3_6[511:480]; // decl: <none>; prim: <none>
    assign limb_3_84 = limb_3_7[511:480]; // decl: <none>; prim: <none>
    assign limb_3_85 = 33'((({1'h0, rtlzz_pipe_83_s3}) + ({1'h0, rtlzz_pipe_84_s3}) + ({32'h0, limb_3_82}))); // decl: <none>; prim: <none>
    assign limb_3_86 = limb_3_85[31:0]; // decl: <none>; prim: <none>
    assign limb_3_87 = limb_3_85[32]; // decl: <none>; prim: <none>
    assign limb_3_88 = limb_3_6[512]; // decl: <none>; prim: <none>
    assign limb_3_89 = limb_3_7[512]; // decl: <none>; prim: <none>
    assign limb_3_90 = 2'((({1'h0, rtlzz_pipe_88_s3}) + ({1'h0, rtlzz_pipe_89_s3}) + ({1'h0, limb_3_87}))); // decl: <none>; prim: <none>
    assign limb_3_91 = limb_3_90[0]; // decl: <none>; prim: <none>
    assign limb_3_92 = {limb_3_91, limb_3_86, limb_3_81, limb_3_76, limb_3_71, limb_3_66, limb_3_61, limb_3_56, limb_3_51, limb_3_46, limb_3_41, limb_3_36, rtlzz_pipe_31_s3, rtlzz_pipe_26_s3, rtlzz_pipe_21_s3, rtlzz_pipe_16_s3, rtlzz_pipe_11_s3}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_11_s1 <= 32'h0;
            rtlzz_pipe_11_s2 <= 32'h0;
            rtlzz_pipe_11_s3 <= 32'h0;
            rtlzz_pipe_12_s1 <= 1'h0;
            rtlzz_pipe_13_s1 <= 32'h0;
            rtlzz_pipe_14_s1 <= 32'h0;
            rtlzz_pipe_16_s2 <= 32'h0;
            rtlzz_pipe_16_s3 <= 32'h0;
            rtlzz_pipe_18_s1 <= 32'h0;
            rtlzz_pipe_19_s1 <= 32'h0;
            rtlzz_pipe_21_s2 <= 32'h0;
            rtlzz_pipe_21_s3 <= 32'h0;
            rtlzz_pipe_22_s2 <= 1'h0;
            rtlzz_pipe_23_s1 <= 32'h0;
            rtlzz_pipe_23_s2 <= 32'h0;
            rtlzz_pipe_24_s1 <= 32'h0;
            rtlzz_pipe_24_s2 <= 32'h0;
            rtlzz_pipe_26_s3 <= 32'h0;
            rtlzz_pipe_28_s1 <= 32'h0;
            rtlzz_pipe_28_s2 <= 32'h0;
            rtlzz_pipe_29_s1 <= 32'h0;
            rtlzz_pipe_29_s2 <= 32'h0;
            rtlzz_pipe_31_s3 <= 32'h0;
            rtlzz_pipe_32_s3 <= 1'h0;
            rtlzz_pipe_33_s1 <= 32'h0;
            rtlzz_pipe_33_s2 <= 32'h0;
            rtlzz_pipe_33_s3 <= 32'h0;
            rtlzz_pipe_34_s1 <= 32'h0;
            rtlzz_pipe_34_s2 <= 32'h0;
            rtlzz_pipe_34_s3 <= 32'h0;
            rtlzz_pipe_38_s1 <= 32'h0;
            rtlzz_pipe_38_s2 <= 32'h0;
            rtlzz_pipe_38_s3 <= 32'h0;
            rtlzz_pipe_39_s1 <= 32'h0;
            rtlzz_pipe_39_s2 <= 32'h0;
            rtlzz_pipe_39_s3 <= 32'h0;
            rtlzz_pipe_43_s1 <= 32'h0;
            rtlzz_pipe_43_s2 <= 32'h0;
            rtlzz_pipe_43_s3 <= 32'h0;
            rtlzz_pipe_44_s1 <= 32'h0;
            rtlzz_pipe_44_s2 <= 32'h0;
            rtlzz_pipe_44_s3 <= 32'h0;
            rtlzz_pipe_48_s1 <= 32'h0;
            rtlzz_pipe_48_s2 <= 32'h0;
            rtlzz_pipe_48_s3 <= 32'h0;
            rtlzz_pipe_49_s1 <= 32'h0;
            rtlzz_pipe_49_s2 <= 32'h0;
            rtlzz_pipe_49_s3 <= 32'h0;
            rtlzz_pipe_53_s1 <= 32'h0;
            rtlzz_pipe_53_s2 <= 32'h0;
            rtlzz_pipe_53_s3 <= 32'h0;
            rtlzz_pipe_54_s1 <= 32'h0;
            rtlzz_pipe_54_s2 <= 32'h0;
            rtlzz_pipe_54_s3 <= 32'h0;
            rtlzz_pipe_58_s1 <= 32'h0;
            rtlzz_pipe_58_s2 <= 32'h0;
            rtlzz_pipe_58_s3 <= 32'h0;
            rtlzz_pipe_59_s1 <= 32'h0;
            rtlzz_pipe_59_s2 <= 32'h0;
            rtlzz_pipe_59_s3 <= 32'h0;
            rtlzz_pipe_63_s1 <= 32'h0;
            rtlzz_pipe_63_s2 <= 32'h0;
            rtlzz_pipe_63_s3 <= 32'h0;
            rtlzz_pipe_64_s1 <= 32'h0;
            rtlzz_pipe_64_s2 <= 32'h0;
            rtlzz_pipe_64_s3 <= 32'h0;
            rtlzz_pipe_68_s1 <= 32'h0;
            rtlzz_pipe_68_s2 <= 32'h0;
            rtlzz_pipe_68_s3 <= 32'h0;
            rtlzz_pipe_69_s1 <= 32'h0;
            rtlzz_pipe_69_s2 <= 32'h0;
            rtlzz_pipe_69_s3 <= 32'h0;
            rtlzz_pipe_73_s1 <= 32'h0;
            rtlzz_pipe_73_s2 <= 32'h0;
            rtlzz_pipe_73_s3 <= 32'h0;
            rtlzz_pipe_74_s1 <= 32'h0;
            rtlzz_pipe_74_s2 <= 32'h0;
            rtlzz_pipe_74_s3 <= 32'h0;
            rtlzz_pipe_78_s1 <= 32'h0;
            rtlzz_pipe_78_s2 <= 32'h0;
            rtlzz_pipe_78_s3 <= 32'h0;
            rtlzz_pipe_79_s1 <= 32'h0;
            rtlzz_pipe_79_s2 <= 32'h0;
            rtlzz_pipe_79_s3 <= 32'h0;
            rtlzz_pipe_83_s1 <= 32'h0;
            rtlzz_pipe_83_s2 <= 32'h0;
            rtlzz_pipe_83_s3 <= 32'h0;
            rtlzz_pipe_84_s1 <= 32'h0;
            rtlzz_pipe_84_s2 <= 32'h0;
            rtlzz_pipe_84_s3 <= 32'h0;
            rtlzz_pipe_88_s1 <= 1'h0;
            rtlzz_pipe_88_s2 <= 1'h0;
            rtlzz_pipe_88_s3 <= 1'h0;
            rtlzz_pipe_89_s1 <= 1'h0;
            rtlzz_pipe_89_s2 <= 1'h0;
            rtlzz_pipe_89_s3 <= 1'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_11_s1 <= limb_3_11; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= rtlzz_pipe_11_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_11_s3 <= rtlzz_pipe_11_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_12_s1 <= limb_3_12; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_13_s1 <= limb_3_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_14_s1 <= limb_3_14; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_16_s2 <= limb_3_16; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_16_s3 <= rtlzz_pipe_16_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_18_s1 <= limb_3_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= limb_3_19; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_21_s2 <= limb_3_21; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_21_s3 <= rtlzz_pipe_21_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_22_s2 <= limb_3_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= limb_3_23; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_23_s2 <= rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_24_s1 <= limb_3_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= rtlzz_pipe_24_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_26_s3 <= limb_3_26; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_28_s1 <= limb_3_28; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_28_s2 <= rtlzz_pipe_28_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= limb_3_29; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_29_s2 <= rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_31_s3 <= limb_3_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= limb_3_32; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= limb_3_33; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_34_s1 <= limb_3_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_34_s2 <= rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= rtlzz_pipe_34_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= limb_3_38; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= limb_3_39; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_39_s2 <= rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_39_s3 <= rtlzz_pipe_39_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= limb_3_43; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_43_s3 <= rtlzz_pipe_43_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_44_s1 <= limb_3_44; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_44_s2 <= rtlzz_pipe_44_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= rtlzz_pipe_44_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_48_s1 <= limb_3_48; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= rtlzz_pipe_48_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= rtlzz_pipe_48_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= limb_3_49; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_49_s2 <= rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_49_s3 <= rtlzz_pipe_49_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= limb_3_53; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_53_s2 <= rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_53_s3 <= rtlzz_pipe_53_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= limb_3_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_54_s2 <= rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_54_s3 <= rtlzz_pipe_54_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_58_s1 <= limb_3_58; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_58_s2 <= rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_58_s3 <= rtlzz_pipe_58_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= limb_3_59; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_59_s2 <= rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_59_s3 <= rtlzz_pipe_59_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= limb_3_63; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_63_s2 <= rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_63_s3 <= rtlzz_pipe_63_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_64_s1 <= limb_3_64; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_64_s2 <= rtlzz_pipe_64_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_64_s3 <= rtlzz_pipe_64_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_68_s1 <= limb_3_68; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_68_s2 <= rtlzz_pipe_68_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_68_s3 <= rtlzz_pipe_68_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= limb_3_69; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_69_s2 <= rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_69_s3 <= rtlzz_pipe_69_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= limb_3_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_73_s2 <= rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_73_s3 <= rtlzz_pipe_73_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_74_s1 <= limb_3_74; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_74_s2 <= rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_74_s3 <= rtlzz_pipe_74_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_78_s1 <= limb_3_78; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_78_s2 <= rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_78_s3 <= rtlzz_pipe_78_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= limb_3_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_79_s2 <= rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_79_s3 <= rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_83_s1 <= limb_3_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_83_s2 <= rtlzz_pipe_83_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_83_s3 <= rtlzz_pipe_83_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_84_s1 <= limb_3_84; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_84_s2 <= rtlzz_pipe_84_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_84_s3 <= rtlzz_pipe_84_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= limb_3_88; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_88_s2 <= rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_88_s3 <= rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_89_s1 <= limb_3_89; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_89_s2 <= rtlzz_pipe_89_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_89_s3 <= rtlzz_pipe_89_s2; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [511:0] a_data,input wire a_wen,input wire [511:0] b_data,input wire b_wen,output reg [512:0] y);
reg liv;wire cov;
reg [511:0] l_a;
reg [511:0] l_b;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;l_b<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
