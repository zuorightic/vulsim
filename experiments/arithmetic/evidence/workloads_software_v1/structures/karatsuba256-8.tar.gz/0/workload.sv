`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_360; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_361; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_362; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_363; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_364; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_365; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_366; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_367; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_368; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_369; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_343_370; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_371; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_343_372; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_343_373; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_374; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_375; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_376; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_343_377; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_378; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_379; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_343_380; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_381; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_382; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_343_383; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_343_384; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_385; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_386; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_387; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_388; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_389; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_390; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_391; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_392; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_393; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_394; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_344_395; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_396; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_344_397; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_344_398; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_399; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_400; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_401; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_344_402; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_403; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_404; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_344_405; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_406; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_407; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_344_408; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_344_409; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_410; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_411; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_345_412; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_413; // decl: <none>; prim: <none>
    logic mul_tree_345_414; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_415; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_416; // decl: <none>; prim: <none>
    logic mul_tree_345_417; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_345_418; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_345_419; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_345_420; // decl: <none>; prim: <none>
    logic mul_tree_345_421; // decl: <none>; prim: <none>
    logic mul_tree_345_422; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_345_423; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_424; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_425; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_426; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_427; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_428; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_429; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_345_430; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_431; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_432; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_345_433; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_345_434; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_435; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_346_436; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_346_437; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_438; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_439; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_347_440; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_441; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_442; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_443; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_444; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_445; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_347_446; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_347_447; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_347_448; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_449; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_347_450; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_347_451; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_452; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_453; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_454; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_347_455; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_456; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_457; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_347_458; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_459; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_460; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_347_461; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_347_462; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_463; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_464; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_465; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_466; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_467; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_468; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_469; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_470; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_471; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_472; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_348_473; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_474; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_348_475; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_348_476; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_477; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_478; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_479; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_348_480; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_481; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_482; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_348_483; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_484; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_485; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_348_486; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_348_487; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_488; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_489; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_490; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_491; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_492; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_493; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_494; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_495; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_496; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_497; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_349_498; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_499; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_349_500; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_349_501; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_502; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_503; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_504; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_349_505; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_506; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_507; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_349_508; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_509; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_510; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_349_511; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_349_512; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_513; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_514; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_350_515; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_516; // decl: <none>; prim: <none>
    logic mul_tree_350_517; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_518; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_519; // decl: <none>; prim: <none>
    logic mul_tree_350_520; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_350_521; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_350_522; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_350_523; // decl: <none>; prim: <none>
    logic mul_tree_350_524; // decl: <none>; prim: <none>
    logic mul_tree_350_525; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_350_526; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_527; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_528; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_529; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_530; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_531; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_532; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_350_533; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_534; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_535; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_350_536; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_350_537; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_538; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_351_539; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_351_540; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_541; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_542; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_352_543; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_544; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_545; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_546; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_547; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_548; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_352_549; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_352_550; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_352_551; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_552; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_352_553; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_352_554; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_555; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_556; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_557; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_352_558; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_559; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_560; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_352_561; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_562; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_563; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_352_564; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_352_565; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_566; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_567; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_353_568; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_569; // decl: <none>; prim: <none>
    logic mul_tree_353_570; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_571; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_572; // decl: <none>; prim: <none>
    logic mul_tree_353_573; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_353_574; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_353_575; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_353_576; // decl: <none>; prim: <none>
    logic mul_tree_353_577; // decl: <none>; prim: <none>
    logic mul_tree_353_578; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_353_579; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_580; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_581; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_582; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_583; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_584; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_585; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_353_586; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_587; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_588; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_353_589; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_353_590; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_591; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_354_592; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_354_593; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_594; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_595; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_355_596; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_597; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_598; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_599; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_600; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_601; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_355_602; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_355_603; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_355_604; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_605; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_355_606; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_355_607; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_608; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_609; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_610; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_355_611; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_612; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_613; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_355_614; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_615; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_616; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_355_617; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_355_618; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_619; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_620; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_621; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_622; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_623; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_624; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_625; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_626; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_627; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_628; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_356_629; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_630; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_356_631; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_356_632; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_633; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_634; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_635; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_356_636; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_637; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_638; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_356_639; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_640; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_641; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_356_642; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_356_643; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_644; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_645; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_357_646; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_647; // decl: <none>; prim: <none>
    logic mul_tree_357_648; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_649; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_650; // decl: <none>; prim: <none>
    logic mul_tree_357_651; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_357_652; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_357_653; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_357_654; // decl: <none>; prim: <none>
    logic mul_tree_357_655; // decl: <none>; prim: <none>
    logic mul_tree_357_656; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_357_657; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_658; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_659; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_660; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_661; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_662; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_663; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_357_664; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_665; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_666; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_357_667; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_357_668; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_669; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_670; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_358_671; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_672; // decl: <none>; prim: <none>
    logic mul_tree_358_673; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_674; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_675; // decl: <none>; prim: <none>
    logic mul_tree_358_676; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_358_677; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_358_678; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_358_679; // decl: <none>; prim: <none>
    logic mul_tree_358_680; // decl: <none>; prim: <none>
    logic mul_tree_358_681; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_358_682; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_683; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_684; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_685; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_686; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_687; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_688; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_358_689; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_690; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_691; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_358_692; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_358_693; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_694; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_695; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_359_696; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_697; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_698; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_699; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_700; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_701; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_359_702; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_359_703; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_359_704; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_705; // decl: <none>; prim: <none>
    logic [1:0] mul_tree_359_706; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_359_707; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_708; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_709; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_710; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_359_711; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_712; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_713; // decl: <none>; prim: <none>
    logic [68:0] mul_tree_359_714; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_715; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_716; // decl: <none>; prim: <none>
    logic [69:0] mul_tree_359_717; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_359_718; // decl: <none>; prim: <none>
    logic [63:0] limb_13_719; // decl: <none>; prim: <none>
    logic [63:0] limb_13_720; // decl: <none>; prim: <none>
    logic [64:0] limb_13_721; // decl: <none>; prim: <none>
    logic [63:0] limb_13_722; // decl: <none>; prim: <none>
    logic limb_13_723; // decl: <none>; prim: <none>
    logic limb_13_724; // decl: <none>; prim: <none>
    logic limb_13_725; // decl: <none>; prim: <none>
    logic [1:0] limb_13_726; // decl: <none>; prim: <none>
    logic limb_13_727; // decl: <none>; prim: <none>
    logic [64:0] limb_13_728; // decl: <none>; prim: <none>
    logic [63:0] limb_15_729; // decl: <none>; prim: <none>
    logic [63:0] limb_15_730; // decl: <none>; prim: <none>
    logic [64:0] limb_15_731; // decl: <none>; prim: <none>
    logic [63:0] limb_15_732; // decl: <none>; prim: <none>
    logic limb_15_733; // decl: <none>; prim: <none>
    logic limb_15_734; // decl: <none>; prim: <none>
    logic limb_15_735; // decl: <none>; prim: <none>
    logic [1:0] limb_15_736; // decl: <none>; prim: <none>
    logic limb_15_737; // decl: <none>; prim: <none>
    logic [64:0] limb_15_738; // decl: <none>; prim: <none>
    logic [63:0] limb_29_739; // decl: <none>; prim: <none>
    logic [63:0] limb_29_740; // decl: <none>; prim: <none>
    logic [63:0] limb_29_741; // decl: <none>; prim: <none>
    logic [64:0] limb_29_742; // decl: <none>; prim: <none>
    logic [63:0] limb_29_743; // decl: <none>; prim: <none>
    logic limb_29_744; // decl: <none>; prim: <none>
    logic [3:0] limb_29_745; // decl: <none>; prim: <none>
    logic [3:0] limb_29_746; // decl: <none>; prim: <none>
    logic [3:0] limb_29_747; // decl: <none>; prim: <none>
    logic [4:0] limb_29_748; // decl: <none>; prim: <none>
    logic [3:0] limb_29_749; // decl: <none>; prim: <none>
    logic [67:0] limb_29_750; // decl: <none>; prim: <none>
    logic [63:0] limb_31_751; // decl: <none>; prim: <none>
    logic [63:0] limb_31_752; // decl: <none>; prim: <none>
    logic [63:0] limb_31_753; // decl: <none>; prim: <none>
    logic [64:0] limb_31_754; // decl: <none>; prim: <none>
    logic [63:0] limb_31_755; // decl: <none>; prim: <none>
    logic limb_31_756; // decl: <none>; prim: <none>
    logic [3:0] limb_31_757; // decl: <none>; prim: <none>
    logic [3:0] limb_31_758; // decl: <none>; prim: <none>
    logic [3:0] limb_31_759; // decl: <none>; prim: <none>
    logic [4:0] limb_31_760; // decl: <none>; prim: <none>
    logic [3:0] limb_31_761; // decl: <none>; prim: <none>
    logic [67:0] limb_31_762; // decl: <none>; prim: <none>
    logic [63:0] limb_38_763; // decl: <none>; prim: <none>
    logic [63:0] limb_38_764; // decl: <none>; prim: <none>
    logic [63:0] limb_38_765; // decl: <none>; prim: <none>
    logic [64:0] limb_38_766; // decl: <none>; prim: <none>
    logic [63:0] limb_38_767; // decl: <none>; prim: <none>
    logic limb_38_768; // decl: <none>; prim: <none>
    logic [63:0] limb_38_769; // decl: <none>; prim: <none>
    logic [63:0] limb_38_770; // decl: <none>; prim: <none>
    logic [63:0] limb_38_771; // decl: <none>; prim: <none>
    logic [64:0] limb_38_772; // decl: <none>; prim: <none>
    logic [63:0] limb_38_773; // decl: <none>; prim: <none>
    logic limb_38_774; // decl: <none>; prim: <none>
    logic [1:0] limb_38_775; // decl: <none>; prim: <none>
    logic [1:0] limb_38_776; // decl: <none>; prim: <none>
    logic [1:0] limb_38_777; // decl: <none>; prim: <none>
    logic [2:0] limb_38_778; // decl: <none>; prim: <none>
    logic [1:0] limb_38_779; // decl: <none>; prim: <none>
    logic [129:0] limb_38_780; // decl: <none>; prim: <none>
    logic [63:0] limb_40_781; // decl: <none>; prim: <none>
    logic [63:0] limb_40_782; // decl: <none>; prim: <none>
    logic [63:0] limb_40_783; // decl: <none>; prim: <none>
    logic [64:0] limb_40_784; // decl: <none>; prim: <none>
    logic [63:0] limb_40_785; // decl: <none>; prim: <none>
    logic limb_40_786; // decl: <none>; prim: <none>
    logic [63:0] limb_40_787; // decl: <none>; prim: <none>
    logic [63:0] limb_40_788; // decl: <none>; prim: <none>
    logic [63:0] limb_40_789; // decl: <none>; prim: <none>
    logic [64:0] limb_40_790; // decl: <none>; prim: <none>
    logic [63:0] limb_40_791; // decl: <none>; prim: <none>
    logic limb_40_792; // decl: <none>; prim: <none>
    logic [1:0] limb_40_793; // decl: <none>; prim: <none>
    logic [1:0] limb_40_794; // decl: <none>; prim: <none>
    logic [1:0] limb_40_795; // decl: <none>; prim: <none>
    logic [2:0] limb_40_796; // decl: <none>; prim: <none>
    logic [1:0] limb_40_797; // decl: <none>; prim: <none>
    logic [129:0] limb_40_798; // decl: <none>; prim: <none>
    logic [63:0] limb_51_799; // decl: <none>; prim: <none>
    logic [63:0] limb_51_800; // decl: <none>; prim: <none>
    logic [64:0] limb_51_801; // decl: <none>; prim: <none>
    logic [63:0] limb_51_802; // decl: <none>; prim: <none>
    logic limb_51_803; // decl: <none>; prim: <none>
    logic limb_51_804; // decl: <none>; prim: <none>
    logic limb_51_805; // decl: <none>; prim: <none>
    logic [1:0] limb_51_806; // decl: <none>; prim: <none>
    logic limb_51_807; // decl: <none>; prim: <none>
    logic [64:0] limb_51_808; // decl: <none>; prim: <none>
    logic [63:0] limb_53_809; // decl: <none>; prim: <none>
    logic [63:0] limb_53_810; // decl: <none>; prim: <none>
    logic [64:0] limb_53_811; // decl: <none>; prim: <none>
    logic [63:0] limb_53_812; // decl: <none>; prim: <none>
    logic limb_53_813; // decl: <none>; prim: <none>
    logic limb_53_814; // decl: <none>; prim: <none>
    logic limb_53_815; // decl: <none>; prim: <none>
    logic [1:0] limb_53_816; // decl: <none>; prim: <none>
    logic limb_53_817; // decl: <none>; prim: <none>
    logic [64:0] limb_53_818; // decl: <none>; prim: <none>
    logic [63:0] limb_67_819; // decl: <none>; prim: <none>
    logic [63:0] limb_67_820; // decl: <none>; prim: <none>
    logic [63:0] limb_67_821; // decl: <none>; prim: <none>
    logic [64:0] limb_67_822; // decl: <none>; prim: <none>
    logic [63:0] limb_67_823; // decl: <none>; prim: <none>
    logic limb_67_824; // decl: <none>; prim: <none>
    logic [3:0] limb_67_825; // decl: <none>; prim: <none>
    logic [3:0] limb_67_826; // decl: <none>; prim: <none>
    logic [3:0] limb_67_827; // decl: <none>; prim: <none>
    logic [4:0] limb_67_828; // decl: <none>; prim: <none>
    logic [3:0] limb_67_829; // decl: <none>; prim: <none>
    logic [67:0] limb_67_830; // decl: <none>; prim: <none>
    logic [63:0] limb_69_831; // decl: <none>; prim: <none>
    logic [63:0] limb_69_832; // decl: <none>; prim: <none>
    logic [63:0] limb_69_833; // decl: <none>; prim: <none>
    logic [64:0] limb_69_834; // decl: <none>; prim: <none>
    logic [63:0] limb_69_835; // decl: <none>; prim: <none>
    logic limb_69_836; // decl: <none>; prim: <none>
    logic [3:0] limb_69_837; // decl: <none>; prim: <none>
    logic [3:0] limb_69_838; // decl: <none>; prim: <none>
    logic [3:0] limb_69_839; // decl: <none>; prim: <none>
    logic [4:0] limb_69_840; // decl: <none>; prim: <none>
    logic [3:0] limb_69_841; // decl: <none>; prim: <none>
    logic [67:0] limb_69_842; // decl: <none>; prim: <none>
    logic [63:0] limb_76_843; // decl: <none>; prim: <none>
    logic [63:0] limb_76_844; // decl: <none>; prim: <none>
    logic [63:0] limb_76_845; // decl: <none>; prim: <none>
    logic [64:0] limb_76_846; // decl: <none>; prim: <none>
    logic [63:0] limb_76_847; // decl: <none>; prim: <none>
    logic limb_76_848; // decl: <none>; prim: <none>
    logic [63:0] limb_76_849; // decl: <none>; prim: <none>
    logic [63:0] limb_76_850; // decl: <none>; prim: <none>
    logic [63:0] limb_76_851; // decl: <none>; prim: <none>
    logic [64:0] limb_76_852; // decl: <none>; prim: <none>
    logic [63:0] limb_76_853; // decl: <none>; prim: <none>
    logic limb_76_854; // decl: <none>; prim: <none>
    logic [1:0] limb_76_855; // decl: <none>; prim: <none>
    logic [1:0] limb_76_856; // decl: <none>; prim: <none>
    logic [1:0] limb_76_857; // decl: <none>; prim: <none>
    logic [2:0] limb_76_858; // decl: <none>; prim: <none>
    logic [1:0] limb_76_859; // decl: <none>; prim: <none>
    logic [129:0] limb_76_860; // decl: <none>; prim: <none>
    logic [63:0] limb_78_861; // decl: <none>; prim: <none>
    logic [63:0] limb_78_862; // decl: <none>; prim: <none>
    logic [63:0] limb_78_863; // decl: <none>; prim: <none>
    logic [64:0] limb_78_864; // decl: <none>; prim: <none>
    logic [63:0] limb_78_865; // decl: <none>; prim: <none>
    logic limb_78_866; // decl: <none>; prim: <none>
    logic [63:0] limb_78_867; // decl: <none>; prim: <none>
    logic [63:0] limb_78_868; // decl: <none>; prim: <none>
    logic [63:0] limb_78_869; // decl: <none>; prim: <none>
    logic [64:0] limb_78_870; // decl: <none>; prim: <none>
    logic [63:0] limb_78_871; // decl: <none>; prim: <none>
    logic limb_78_872; // decl: <none>; prim: <none>
    logic [1:0] limb_78_873; // decl: <none>; prim: <none>
    logic [1:0] limb_78_874; // decl: <none>; prim: <none>
    logic [1:0] limb_78_875; // decl: <none>; prim: <none>
    logic [2:0] limb_78_876; // decl: <none>; prim: <none>
    logic [1:0] limb_78_877; // decl: <none>; prim: <none>
    logic [129:0] limb_78_878; // decl: <none>; prim: <none>
    logic [63:0] limb_85_879; // decl: <none>; prim: <none>
    logic [63:0] limb_85_880; // decl: <none>; prim: <none>
    logic [64:0] limb_85_881; // decl: <none>; prim: <none>
    logic [63:0] limb_85_882; // decl: <none>; prim: <none>
    logic limb_85_883; // decl: <none>; prim: <none>
    logic [63:0] limb_85_884; // decl: <none>; prim: <none>
    logic [63:0] limb_85_885; // decl: <none>; prim: <none>
    logic [64:0] limb_85_886; // decl: <none>; prim: <none>
    logic [63:0] limb_85_887; // decl: <none>; prim: <none>
    logic limb_85_888; // decl: <none>; prim: <none>
    logic limb_85_889; // decl: <none>; prim: <none>
    logic limb_85_890; // decl: <none>; prim: <none>
    logic [1:0] limb_85_891; // decl: <none>; prim: <none>
    logic limb_85_892; // decl: <none>; prim: <none>
    logic [128:0] limb_85_893; // decl: <none>; prim: <none>
    logic [63:0] limb_87_894; // decl: <none>; prim: <none>
    logic [63:0] limb_87_895; // decl: <none>; prim: <none>
    logic [64:0] limb_87_896; // decl: <none>; prim: <none>
    logic [63:0] limb_87_897; // decl: <none>; prim: <none>
    logic limb_87_898; // decl: <none>; prim: <none>
    logic [63:0] limb_87_899; // decl: <none>; prim: <none>
    logic [63:0] limb_87_900; // decl: <none>; prim: <none>
    logic [64:0] limb_87_901; // decl: <none>; prim: <none>
    logic [63:0] limb_87_902; // decl: <none>; prim: <none>
    logic limb_87_903; // decl: <none>; prim: <none>
    logic limb_87_904; // decl: <none>; prim: <none>
    logic limb_87_905; // decl: <none>; prim: <none>
    logic [1:0] limb_87_906; // decl: <none>; prim: <none>
    logic limb_87_907; // decl: <none>; prim: <none>
    logic [128:0] limb_87_908; // decl: <none>; prim: <none>
    logic [63:0] limb_103_909; // decl: <none>; prim: <none>
    logic [63:0] limb_103_910; // decl: <none>; prim: <none>
    logic [63:0] limb_103_911; // decl: <none>; prim: <none>
    logic [64:0] limb_103_912; // decl: <none>; prim: <none>
    logic [63:0] limb_103_913; // decl: <none>; prim: <none>
    logic limb_103_914; // decl: <none>; prim: <none>
    logic [3:0] limb_103_915; // decl: <none>; prim: <none>
    logic [3:0] limb_103_916; // decl: <none>; prim: <none>
    logic [3:0] limb_103_917; // decl: <none>; prim: <none>
    logic [4:0] limb_103_918; // decl: <none>; prim: <none>
    logic [3:0] limb_103_919; // decl: <none>; prim: <none>
    logic [67:0] limb_103_920; // decl: <none>; prim: <none>
    logic [63:0] limb_105_921; // decl: <none>; prim: <none>
    logic [63:0] limb_105_922; // decl: <none>; prim: <none>
    logic [63:0] limb_105_923; // decl: <none>; prim: <none>
    logic [64:0] limb_105_924; // decl: <none>; prim: <none>
    logic [63:0] limb_105_925; // decl: <none>; prim: <none>
    logic limb_105_926; // decl: <none>; prim: <none>
    logic [3:0] limb_105_927; // decl: <none>; prim: <none>
    logic [3:0] limb_105_928; // decl: <none>; prim: <none>
    logic [3:0] limb_105_929; // decl: <none>; prim: <none>
    logic [4:0] limb_105_930; // decl: <none>; prim: <none>
    logic [3:0] limb_105_931; // decl: <none>; prim: <none>
    logic [67:0] limb_105_932; // decl: <none>; prim: <none>
    logic [63:0] limb_113_933; // decl: <none>; prim: <none>
    logic [63:0] limb_113_934; // decl: <none>; prim: <none>
    logic [64:0] limb_113_935; // decl: <none>; prim: <none>
    logic [63:0] limb_113_936; // decl: <none>; prim: <none>
    logic limb_113_937; // decl: <none>; prim: <none>
    logic [1:0] limb_113_938; // decl: <none>; prim: <none>
    logic [1:0] limb_113_939; // decl: <none>; prim: <none>
    logic [2:0] limb_113_940; // decl: <none>; prim: <none>
    logic [1:0] limb_113_941; // decl: <none>; prim: <none>
    logic [65:0] limb_113_942; // decl: <none>; prim: <none>
    logic [63:0] limb_115_943; // decl: <none>; prim: <none>
    logic [63:0] limb_115_944; // decl: <none>; prim: <none>
    logic [64:0] limb_115_945; // decl: <none>; prim: <none>
    logic [63:0] limb_115_946; // decl: <none>; prim: <none>
    logic limb_115_947; // decl: <none>; prim: <none>
    logic [1:0] limb_115_948; // decl: <none>; prim: <none>
    logic [1:0] limb_115_949; // decl: <none>; prim: <none>
    logic [2:0] limb_115_950; // decl: <none>; prim: <none>
    logic [1:0] limb_115_951; // decl: <none>; prim: <none>
    logic [65:0] limb_115_952; // decl: <none>; prim: <none>
    logic [63:0] limb_129_953; // decl: <none>; prim: <none>
    logic [63:0] limb_129_954; // decl: <none>; prim: <none>
    logic [63:0] limb_129_955; // decl: <none>; prim: <none>
    logic [64:0] limb_129_956; // decl: <none>; prim: <none>
    logic [63:0] limb_129_957; // decl: <none>; prim: <none>
    logic limb_129_958; // decl: <none>; prim: <none>
    logic [3:0] limb_129_959; // decl: <none>; prim: <none>
    logic [3:0] limb_129_960; // decl: <none>; prim: <none>
    logic [3:0] limb_129_961; // decl: <none>; prim: <none>
    logic [4:0] limb_129_962; // decl: <none>; prim: <none>
    logic [3:0] limb_129_963; // decl: <none>; prim: <none>
    logic [67:0] limb_129_964; // decl: <none>; prim: <none>
    logic [63:0] limb_131_965; // decl: <none>; prim: <none>
    logic [63:0] limb_131_966; // decl: <none>; prim: <none>
    logic [63:0] limb_131_967; // decl: <none>; prim: <none>
    logic [64:0] limb_131_968; // decl: <none>; prim: <none>
    logic [63:0] limb_131_969; // decl: <none>; prim: <none>
    logic limb_131_970; // decl: <none>; prim: <none>
    logic [3:0] limb_131_971; // decl: <none>; prim: <none>
    logic [3:0] limb_131_972; // decl: <none>; prim: <none>
    logic [3:0] limb_131_973; // decl: <none>; prim: <none>
    logic [4:0] limb_131_974; // decl: <none>; prim: <none>
    logic [3:0] limb_131_975; // decl: <none>; prim: <none>
    logic [67:0] limb_131_976; // decl: <none>; prim: <none>
    logic [63:0] limb_138_977; // decl: <none>; prim: <none>
    logic [63:0] limb_138_978; // decl: <none>; prim: <none>
    logic [63:0] limb_138_979; // decl: <none>; prim: <none>
    logic [64:0] limb_138_980; // decl: <none>; prim: <none>
    logic [63:0] limb_138_981; // decl: <none>; prim: <none>
    logic limb_138_982; // decl: <none>; prim: <none>
    logic [63:0] limb_138_983; // decl: <none>; prim: <none>
    logic [63:0] limb_138_984; // decl: <none>; prim: <none>
    logic [63:0] limb_138_985; // decl: <none>; prim: <none>
    logic [64:0] limb_138_986; // decl: <none>; prim: <none>
    logic [63:0] limb_138_987; // decl: <none>; prim: <none>
    logic limb_138_988; // decl: <none>; prim: <none>
    logic [3:0] limb_138_989; // decl: <none>; prim: <none>
    logic [3:0] limb_138_990; // decl: <none>; prim: <none>
    logic [3:0] limb_138_991; // decl: <none>; prim: <none>
    logic [4:0] limb_138_992; // decl: <none>; prim: <none>
    logic [3:0] limb_138_993; // decl: <none>; prim: <none>
    logic [131:0] limb_138_994; // decl: <none>; prim: <none>
    logic [63:0] limb_140_995; // decl: <none>; prim: <none>
    logic [63:0] limb_140_996; // decl: <none>; prim: <none>
    logic [63:0] limb_140_997; // decl: <none>; prim: <none>
    logic [64:0] limb_140_998; // decl: <none>; prim: <none>
    logic [63:0] limb_140_999; // decl: <none>; prim: <none>
    logic limb_140_1000; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1001; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1002; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1003; // decl: <none>; prim: <none>
    logic [64:0] limb_140_1004; // decl: <none>; prim: <none>
    logic [63:0] limb_140_1005; // decl: <none>; prim: <none>
    logic limb_140_1006; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1007; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1008; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1009; // decl: <none>; prim: <none>
    logic [4:0] limb_140_1010; // decl: <none>; prim: <none>
    logic [3:0] limb_140_1011; // decl: <none>; prim: <none>
    logic [131:0] limb_140_1012; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1013; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1014; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1015; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1016; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1017; // decl: <none>; prim: <none>
    logic limb_147_1018; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1019; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1020; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1021; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1022; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1023; // decl: <none>; prim: <none>
    logic limb_147_1024; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1025; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1026; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1027; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1028; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1029; // decl: <none>; prim: <none>
    logic limb_147_1030; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1031; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1032; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1033; // decl: <none>; prim: <none>
    logic [64:0] limb_147_1034; // decl: <none>; prim: <none>
    logic [63:0] limb_147_1035; // decl: <none>; prim: <none>
    logic limb_147_1036; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1037; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1038; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1039; // decl: <none>; prim: <none>
    logic [2:0] limb_147_1040; // decl: <none>; prim: <none>
    logic [1:0] limb_147_1041; // decl: <none>; prim: <none>
    logic [257:0] limb_147_1042; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1043; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1044; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1045; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1046; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1047; // decl: <none>; prim: <none>
    logic limb_149_1048; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1049; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1050; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1051; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1052; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1053; // decl: <none>; prim: <none>
    logic limb_149_1054; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1055; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1056; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1057; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1058; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1059; // decl: <none>; prim: <none>
    logic limb_149_1060; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1061; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1062; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1063; // decl: <none>; prim: <none>
    logic [64:0] limb_149_1064; // decl: <none>; prim: <none>
    logic [63:0] limb_149_1065; // decl: <none>; prim: <none>
    logic limb_149_1066; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1067; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1068; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1069; // decl: <none>; prim: <none>
    logic [2:0] limb_149_1070; // decl: <none>; prim: <none>
    logic [1:0] limb_149_1071; // decl: <none>; prim: <none>
    logic [257:0] limb_149_1072; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1073; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1074; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1075; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1076; // decl: <none>; prim: <none>
    logic limb_157_1077; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1078; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1079; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1080; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1081; // decl: <none>; prim: <none>
    logic limb_157_1082; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1083; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1084; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1085; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1086; // decl: <none>; prim: <none>
    logic limb_157_1087; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1088; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1089; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1090; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1091; // decl: <none>; prim: <none>
    logic limb_157_1092; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1093; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1094; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1095; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1096; // decl: <none>; prim: <none>
    logic limb_157_1097; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1098; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1099; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1100; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1101; // decl: <none>; prim: <none>
    logic limb_157_1102; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1103; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1104; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1105; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1106; // decl: <none>; prim: <none>
    logic limb_157_1107; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1108; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1109; // decl: <none>; prim: <none>
    logic [64:0] limb_157_1110; // decl: <none>; prim: <none>
    logic [63:0] limb_157_1111; // decl: <none>; prim: <none>
    logic limb_157_1112; // decl: <none>; prim: <none>
    logic limb_157_1113; // decl: <none>; prim: <none>
    logic limb_157_1114; // decl: <none>; prim: <none>
    logic [1:0] limb_157_1115; // decl: <none>; prim: <none>
    logic limb_157_1116; // decl: <none>; prim: <none>
    logic [512:0] limb_157_1117; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1118; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1119; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1120; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1121; // decl: <none>; prim: <none>
    logic limb_216_1122; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1123; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1124; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1125; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1126; // decl: <none>; prim: <none>
    logic limb_216_1127; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1128; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1129; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1130; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1131; // decl: <none>; prim: <none>
    logic limb_216_1132; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1133; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1134; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1135; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1136; // decl: <none>; prim: <none>
    logic limb_216_1137; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1138; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1139; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1140; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1141; // decl: <none>; prim: <none>
    logic limb_216_1142; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1143; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1144; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1145; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1146; // decl: <none>; prim: <none>
    logic limb_216_1147; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1148; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1149; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1150; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1151; // decl: <none>; prim: <none>
    logic limb_216_1152; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1153; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1154; // decl: <none>; prim: <none>
    logic [64:0] limb_216_1155; // decl: <none>; prim: <none>
    logic [63:0] limb_216_1156; // decl: <none>; prim: <none>
    logic [511:0] limb_216_1157; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1158; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1159; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1160; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1161; // decl: <none>; prim: <none>
    logic limb_217_1162; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1163; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1164; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1165; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1166; // decl: <none>; prim: <none>
    logic limb_217_1167; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1168; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1169; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1170; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1171; // decl: <none>; prim: <none>
    logic limb_217_1172; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1173; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1174; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1175; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1176; // decl: <none>; prim: <none>
    logic limb_217_1177; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1178; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1179; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1180; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1181; // decl: <none>; prim: <none>
    logic limb_217_1182; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1183; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1184; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1185; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1186; // decl: <none>; prim: <none>
    logic limb_217_1187; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1188; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1189; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1190; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1191; // decl: <none>; prim: <none>
    logic limb_217_1192; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1193; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1194; // decl: <none>; prim: <none>
    logic [64:0] limb_217_1195; // decl: <none>; prim: <none>
    logic [63:0] limb_217_1196; // decl: <none>; prim: <none>
    logic [511:0] limb_217_1197; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1198; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1199; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1200; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1201; // decl: <none>; prim: <none>
    logic limb_218_1202; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1203; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1204; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1205; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1206; // decl: <none>; prim: <none>
    logic limb_218_1207; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1208; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1209; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1210; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1211; // decl: <none>; prim: <none>
    logic limb_218_1212; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1213; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1214; // decl: <none>; prim: <none>
    logic [64:0] limb_218_1215; // decl: <none>; prim: <none>
    logic [63:0] limb_218_1216; // decl: <none>; prim: <none>
    logic limb_218_1217; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1218; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1219; // decl: <none>; prim: <none>
    logic [2:0] limb_218_1220; // decl: <none>; prim: <none>
    logic [1:0] limb_218_1221; // decl: <none>; prim: <none>
    logic [257:0] limb_218_1222; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1223; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1224; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1225; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1226; // decl: <none>; prim: <none>
    logic limb_219_1227; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1228; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1229; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1230; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1231; // decl: <none>; prim: <none>
    logic limb_219_1232; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1233; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1234; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1235; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1236; // decl: <none>; prim: <none>
    logic limb_219_1237; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1238; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1239; // decl: <none>; prim: <none>
    logic [64:0] limb_219_1240; // decl: <none>; prim: <none>
    logic [63:0] limb_219_1241; // decl: <none>; prim: <none>
    logic limb_219_1242; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1243; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1244; // decl: <none>; prim: <none>
    logic [2:0] limb_219_1245; // decl: <none>; prim: <none>
    logic [1:0] limb_219_1246; // decl: <none>; prim: <none>
    logic [257:0] limb_219_1247; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1248; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1249; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1250; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1251; // decl: <none>; prim: <none>
    logic limb_220_1252; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1253; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1254; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1255; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1256; // decl: <none>; prim: <none>
    logic limb_220_1257; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1258; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1259; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1260; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1261; // decl: <none>; prim: <none>
    logic limb_220_1262; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1263; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1264; // decl: <none>; prim: <none>
    logic [64:0] limb_220_1265; // decl: <none>; prim: <none>
    logic [63:0] limb_220_1266; // decl: <none>; prim: <none>
    logic [255:0] limb_220_1267; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1268; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1269; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1270; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1271; // decl: <none>; prim: <none>
    logic limb_221_1272; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1273; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1274; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1275; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1276; // decl: <none>; prim: <none>
    logic limb_221_1277; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1278; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1279; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1280; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1281; // decl: <none>; prim: <none>
    logic limb_221_1282; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1283; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1284; // decl: <none>; prim: <none>
    logic [64:0] limb_221_1285; // decl: <none>; prim: <none>
    logic [63:0] limb_221_1286; // decl: <none>; prim: <none>
    logic [255:0] limb_221_1287; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1288; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1289; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1290; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1291; // decl: <none>; prim: <none>
    logic limb_222_1292; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1293; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1294; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1295; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1296; // decl: <none>; prim: <none>
    logic limb_222_1297; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1298; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1299; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1300; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1301; // decl: <none>; prim: <none>
    logic limb_222_1302; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1303; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1304; // decl: <none>; prim: <none>
    logic [64:0] limb_222_1305; // decl: <none>; prim: <none>
    logic [63:0] limb_222_1306; // decl: <none>; prim: <none>
    logic [255:0] limb_222_1307; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1308; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1309; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1310; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1311; // decl: <none>; prim: <none>
    logic limb_223_1312; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1313; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1314; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1315; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1316; // decl: <none>; prim: <none>
    logic limb_223_1317; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1318; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1319; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1320; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1321; // decl: <none>; prim: <none>
    logic limb_223_1322; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1323; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1324; // decl: <none>; prim: <none>
    logic [64:0] limb_223_1325; // decl: <none>; prim: <none>
    logic [63:0] limb_223_1326; // decl: <none>; prim: <none>
    logic [255:0] limb_223_1327; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1328; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1329; // decl: <none>; prim: <none>
    logic [64:0] limb_224_1330; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1331; // decl: <none>; prim: <none>
    logic limb_224_1332; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1333; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1334; // decl: <none>; prim: <none>
    logic [64:0] limb_224_1335; // decl: <none>; prim: <none>
    logic [63:0] limb_224_1336; // decl: <none>; prim: <none>
    logic limb_224_1337; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1338; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1339; // decl: <none>; prim: <none>
    logic [4:0] limb_224_1340; // decl: <none>; prim: <none>
    logic [3:0] limb_224_1341; // decl: <none>; prim: <none>
    logic [131:0] limb_224_1342; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1343; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1344; // decl: <none>; prim: <none>
    logic [64:0] limb_225_1345; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1346; // decl: <none>; prim: <none>
    logic limb_225_1347; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1348; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1349; // decl: <none>; prim: <none>
    logic [64:0] limb_225_1350; // decl: <none>; prim: <none>
    logic [63:0] limb_225_1351; // decl: <none>; prim: <none>
    logic limb_225_1352; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1353; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1354; // decl: <none>; prim: <none>
    logic [4:0] limb_225_1355; // decl: <none>; prim: <none>
    logic [3:0] limb_225_1356; // decl: <none>; prim: <none>
    logic [131:0] limb_225_1357; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1358; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1359; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1360; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1361; // decl: <none>; prim: <none>
    logic limb_226_1362; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1363; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1364; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1365; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1366; // decl: <none>; prim: <none>
    logic limb_226_1367; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1368; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1369; // decl: <none>; prim: <none>
    logic [2:0] limb_226_1370; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1371; // decl: <none>; prim: <none>
    logic [129:0] limb_226_1372; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1373; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1374; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1375; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1376; // decl: <none>; prim: <none>
    logic limb_227_1377; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1378; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1379; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1380; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1381; // decl: <none>; prim: <none>
    logic limb_227_1382; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1383; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1384; // decl: <none>; prim: <none>
    logic [2:0] limb_227_1385; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1386; // decl: <none>; prim: <none>
    logic [129:0] limb_227_1387; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1388; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1389; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1390; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1391; // decl: <none>; prim: <none>
    logic limb_228_1392; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1393; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1394; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1395; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1396; // decl: <none>; prim: <none>
    logic limb_228_1397; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1398; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1399; // decl: <none>; prim: <none>
    logic [2:0] limb_228_1400; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1401; // decl: <none>; prim: <none>
    logic [129:0] limb_228_1402; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1403; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1404; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1405; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1406; // decl: <none>; prim: <none>
    logic limb_229_1407; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1408; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1409; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1410; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1411; // decl: <none>; prim: <none>
    logic limb_229_1412; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1413; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1414; // decl: <none>; prim: <none>
    logic [2:0] limb_229_1415; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1416; // decl: <none>; prim: <none>
    logic [129:0] limb_229_1417; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1418; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1419; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1420; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1421; // decl: <none>; prim: <none>
    logic limb_230_1422; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1423; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1424; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1425; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1426; // decl: <none>; prim: <none>
    logic limb_230_1427; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1428; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1429; // decl: <none>; prim: <none>
    logic [2:0] limb_230_1430; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1431; // decl: <none>; prim: <none>
    logic [129:0] limb_230_1432; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1433; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1434; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1435; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1436; // decl: <none>; prim: <none>
    logic limb_231_1437; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1438; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1439; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1440; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1441; // decl: <none>; prim: <none>
    logic limb_231_1442; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1443; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1444; // decl: <none>; prim: <none>
    logic [2:0] limb_231_1445; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1446; // decl: <none>; prim: <none>
    logic [129:0] limb_231_1447; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_362_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_366_s5; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_370_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_374_s5; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_174_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_387_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_391_s4; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_395_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_399_s4; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [255:0] rtlzz_pipe_11_s7; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [129:0] rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_175_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_465_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_469_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_473_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_477_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_48_s7; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [63:0] rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_719_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_724_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_168_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_20_s6; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [63:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_729_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_734_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_269_s6; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_427_s6; // decl: <none>; prim: <none>
    logic [66:0] rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_172_s7; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s6; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_173_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_739_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_745_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_747_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_753_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_753_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_759_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_759_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_765_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_771_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_777_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_783_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_788_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_794_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_800_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_805_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_184_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_274_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_246_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [32:0] rtlzz_pipe_313_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_810_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_815_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_845_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_851_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_857_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_879_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_879_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_884_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_884_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_889_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_889_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_198_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_894_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_894_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_899_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_899_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_904_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_904_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_199_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_281_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_283_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_287_s4; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_200_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
    logic [131:0] rtlzz_pipe_214_s4; // decl: <none>; prim: <none>
    logic [131:0] rtlzz_pipe_214_s5; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_144_s4; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] rtlzz_pipe_144_s5; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [63:0] rtlzz_pipe_921_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_922_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_927_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_928_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_933_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_933_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_938_s3; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_938_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_120_s5; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] rtlzz_pipe_288_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_290_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_943_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_948_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_115_s5; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [33:0] rtlzz_pipe_122_s5; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] rtlzz_pipe_122_s6; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [65:0] rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_289_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_955_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_961_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_997_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1003_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1009_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1074_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1079_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1084_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1089_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1094_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1099_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1104_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1109_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_1114_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1328_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1333_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_1338_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1358_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1358_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1363_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1363_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1368_s4; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1368_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_979_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_985_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_991_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1223_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1228_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1233_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1238_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1243_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1013_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1019_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1025_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1031_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1037_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = limb_13_728; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = limb_15_738; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__32_v0 = (__beopt_width_545 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (__beopt_width_546 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (rtlzz_pipe_168_s5 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign s8_norm_add_36_v0 = (rtlzz_pipe_20_s6 + __beopt_width_332); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_add_39_v0 = (tmp_workload_top_int_34__47_v0 + __beopt_width_336); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = limb_29_750; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = limb_31_762; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s7 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (rtlzz_pipe_173_s7 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (rtlzz_pipe_174_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = limb_38_780; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__76_v0 = (rtlzz_pipe_175_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = limb_40_798; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (rtlzz_pipe_11_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__85_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = limb_51_808; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = limb_53_818; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__117_v0 = (__beopt_width_573 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (rtlzz_pipe_184_s7 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign s8_norm_add_98_v0 = (tmp_workload_top_int_34__127_v0 + rtlzz_pipe_246_s7); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_add_101_v0 = (tmp_workload_top_int_34__132_v0 + __beopt_width_370); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = limb_67_830; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = limb_69_842; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = limb_76_860; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = limb_78_878; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__164_v0 = (rtlzz_pipe_48_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = limb_85_893; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = limb_87_908; // decl: <none>; prim: <none>
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (tmp_workload_top_int_66__243_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign s8_norm_add_152_v0 = (tmp_workload_top_int_34__202_v0 + __beopt_width_388); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    assign tmp_workload_top_int_34__207_v0 = (rtlzz_pipe_199_s4 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_add_155_v0 = (tmp_workload_top_int_34__207_v0 + __beopt_width_391); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (rtlzz_pipe_200_s4 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = limb_103_920; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = limb_105_932; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__223_v0 = (__beopt_width_611 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s5 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (__beopt_width_617 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = limb_113_942; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = limb_115_952; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__252_v0 = (s8_norm_add_177_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (rtlzz_pipe_115_s5 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (__beopt_width_627 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign s8_norm_add_195_v0 = (rtlzz_pipe_120_s5 + __beopt_width_416); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    assign tmp_workload_top_int_34__267_v0 = (__beopt_width_630 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_add_198_v0 = (rtlzz_pipe_122_s6 + __beopt_width_424); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (__beopt_width_633 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = limb_129_964; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = limb_131_976; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__289_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = limb_138_994; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__296_v0 = (rtlzz_pipe_214_s5 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = limb_140_1012; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (tmp_workload_top_int_258__301_v0 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (rtlzz_pipe_144_s5 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = limb_147_1042; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = limb_149_1072; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = limb_157_1117; // decl: <none>; prim: <none>
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = limb_216_1157; // decl: <none>; prim: <none>
    assign __beopt_width_294 = limb_217_1197; // decl: <none>; prim: <none>
    assign __beopt_width_295 = limb_218_1222; // decl: <none>; prim: <none>
    assign __beopt_width_297 = limb_219_1247; // decl: <none>; prim: <none>
    assign __beopt_width_299 = limb_220_1267; // decl: <none>; prim: <none>
    assign __beopt_width_301 = limb_221_1287; // decl: <none>; prim: <none>
    assign __beopt_width_302 = limb_222_1307; // decl: <none>; prim: <none>
    assign __beopt_width_303 = limb_223_1327; // decl: <none>; prim: <none>
    assign __beopt_width_305 = limb_224_1342; // decl: <none>; prim: <none>
    assign __beopt_width_307 = limb_225_1357; // decl: <none>; prim: <none>
    assign __beopt_width_309 = limb_226_1372; // decl: <none>; prim: <none>
    assign __beopt_width_310 = limb_227_1387; // decl: <none>; prim: <none>
    assign __beopt_width_311 = limb_228_1402; // decl: <none>; prim: <none>
    assign __beopt_width_313 = limb_229_1417; // decl: <none>; prim: <none>
    assign __beopt_width_315 = limb_230_1432; // decl: <none>; prim: <none>
    assign __beopt_width_317 = limb_231_1447; // decl: <none>; prim: <none>
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (rtlzz_pipe_265_s5 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (__beopt_width_333 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (rtlzz_pipe_268_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (rtlzz_pipe_269_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s6 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s7 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (__beopt_width_353 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s1 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (rtlzz_pipe_274_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (rtlzz_pipe_278_s2 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (rtlzz_pipe_279_s3 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s3 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (rtlzz_pipe_281_s4 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (rtlzz_pipe_283_s4 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (__beopt_width_403 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (__beopt_width_406 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s4 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (rtlzz_pipe_287_s4 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (rtlzz_pipe_288_s5 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (rtlzz_pipe_289_s6 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (rtlzz_pipe_290_s5 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s6 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = mul_tree_343_384; // decl: <none>; prim: <none>
    assign arith_original_344 = mul_tree_344_409; // decl: <none>; prim: <none>
    assign arith_original_345 = mul_tree_345_434; // decl: <none>; prim: <none>
    assign arith_original_346 = mul_tree_346_437; // decl: <none>; prim: <none>
    assign arith_original_347 = mul_tree_347_462; // decl: <none>; prim: <none>
    assign arith_original_348 = mul_tree_348_487; // decl: <none>; prim: <none>
    assign arith_original_349 = mul_tree_349_512; // decl: <none>; prim: <none>
    assign arith_original_350 = mul_tree_350_537; // decl: <none>; prim: <none>
    assign arith_original_351 = mul_tree_351_540; // decl: <none>; prim: <none>
    assign arith_original_352 = mul_tree_352_565; // decl: <none>; prim: <none>
    assign arith_original_353 = mul_tree_353_590; // decl: <none>; prim: <none>
    assign arith_original_354 = mul_tree_354_593; // decl: <none>; prim: <none>
    assign arith_original_355 = mul_tree_355_618; // decl: <none>; prim: <none>
    assign arith_original_356 = mul_tree_356_643; // decl: <none>; prim: <none>
    assign arith_original_357 = mul_tree_357_668; // decl: <none>; prim: <none>
    assign arith_original_358 = mul_tree_358_693; // decl: <none>; prim: <none>
    assign arith_original_359 = mul_tree_359_718; // decl: <none>; prim: <none>
    assign mul_tree_343_360 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_361 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_362 = 64'(($unsigned(64'($unsigned(mul_tree_343_360))) * $unsigned(64'($unsigned(mul_tree_343_361))))); // decl: <none>; prim: <none>
    assign mul_tree_343_363 = rtlzz_pipe_292_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_364 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_365 = 64'(($unsigned(64'($unsigned(mul_tree_343_363))) * $unsigned(64'($unsigned(mul_tree_343_364))))); // decl: <none>; prim: <none>
    assign mul_tree_343_366 = {mul_tree_343_365, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_367 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_368 = rtlzz_pipe_293_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_343_369 = 64'(($unsigned(64'($unsigned(mul_tree_343_367))) * $unsigned(64'($unsigned(mul_tree_343_368))))); // decl: <none>; prim: <none>
    assign mul_tree_343_370 = {mul_tree_343_369, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_371 = rtlzz_pipe_292_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_372 = rtlzz_pipe_293_s4[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_343_373 = 64'(($unsigned(64'($unsigned(mul_tree_343_371))) * $unsigned(64'($unsigned(mul_tree_343_372))))); // decl: <none>; prim: <none>
    assign mul_tree_343_374 = {mul_tree_343_373, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_343_375 = ({33'h0, rtlzz_pipe_362_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_376 = ({1'h0, rtlzz_pipe_366_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_377 = 97'((mul_tree_343_375 + mul_tree_343_376 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_343_378 = ({33'h0, rtlzz_pipe_370_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_379 = ({1'h0, rtlzz_pipe_374_s5}); // decl: <none>; prim: <none>
    assign mul_tree_343_380 = 129'((mul_tree_343_378 + mul_tree_343_379 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_343_381 = ({33'h0, mul_tree_343_377}); // decl: <none>; prim: <none>
    assign mul_tree_343_382 = ({1'h0, mul_tree_343_380}); // decl: <none>; prim: <none>
    assign mul_tree_343_383 = 130'((mul_tree_343_381 + mul_tree_343_382 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_343_384 = mul_tree_343_383[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_385 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_386 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_387 = 64'(($unsigned(64'($unsigned(mul_tree_344_385))) * $unsigned(64'($unsigned(mul_tree_344_386))))); // decl: <none>; prim: <none>
    assign mul_tree_344_388 = rtlzz_pipe_295_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_389 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_390 = 64'(($unsigned(64'($unsigned(mul_tree_344_388))) * $unsigned(64'($unsigned(mul_tree_344_389))))); // decl: <none>; prim: <none>
    assign mul_tree_344_391 = {mul_tree_344_390, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_392 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_393 = mul_precision_296[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_344_394 = 64'(($unsigned(64'($unsigned(mul_tree_344_392))) * $unsigned(64'($unsigned(mul_tree_344_393))))); // decl: <none>; prim: <none>
    assign mul_tree_344_395 = {mul_tree_344_394, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_396 = rtlzz_pipe_295_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_397 = mul_precision_296[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_344_398 = 64'(($unsigned(64'($unsigned(mul_tree_344_396))) * $unsigned(64'($unsigned(mul_tree_344_397))))); // decl: <none>; prim: <none>
    assign mul_tree_344_399 = {mul_tree_344_398, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_344_400 = ({33'h0, rtlzz_pipe_387_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_401 = ({1'h0, rtlzz_pipe_391_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_402 = 97'((mul_tree_344_400 + mul_tree_344_401 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_344_403 = ({33'h0, rtlzz_pipe_395_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_404 = ({1'h0, rtlzz_pipe_399_s4}); // decl: <none>; prim: <none>
    assign mul_tree_344_405 = 129'((mul_tree_344_403 + mul_tree_344_404 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_344_406 = ({33'h0, mul_tree_344_402}); // decl: <none>; prim: <none>
    assign mul_tree_344_407 = ({1'h0, mul_tree_344_405}); // decl: <none>; prim: <none>
    assign mul_tree_344_408 = 130'((mul_tree_344_406 + mul_tree_344_407 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_344_409 = mul_tree_344_408[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_410 = rtlzz_pipe_298_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_411 = mul_precision_299[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_412 = 64'(($unsigned(64'($unsigned(mul_tree_345_410))) * $unsigned(64'($unsigned(mul_tree_345_411))))); // decl: <none>; prim: <none>
    assign mul_tree_345_413 = rtlzz_pipe_298_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_414 = mul_precision_299[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_415 = 33'(($unsigned(33'($unsigned(mul_tree_345_413))) * $unsigned(33'($unsigned(mul_tree_345_414))))); // decl: <none>; prim: <none>
    assign mul_tree_345_416 = {mul_tree_345_415, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_417 = rtlzz_pipe_298_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_418 = mul_precision_299[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_345_419 = 33'(($unsigned(33'($unsigned(mul_tree_345_417))) * $unsigned(33'($unsigned(mul_tree_345_418))))); // decl: <none>; prim: <none>
    assign mul_tree_345_420 = {mul_tree_345_419, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_421 = rtlzz_pipe_298_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_422 = mul_precision_299[32]; // decl: <none>; prim: <none>
    assign mul_tree_345_423 = 2'(($unsigned(2'($unsigned(mul_tree_345_421))) * $unsigned(2'($unsigned(mul_tree_345_422))))); // decl: <none>; prim: <none>
    assign mul_tree_345_424 = {mul_tree_345_423, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_345_425 = ({2'h0, mul_tree_345_412}); // decl: <none>; prim: <none>
    assign mul_tree_345_426 = ({1'h0, mul_tree_345_416}); // decl: <none>; prim: <none>
    assign mul_tree_345_427 = 66'((mul_tree_345_425 + mul_tree_345_426 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_345_428 = ({2'h0, mul_tree_345_420}); // decl: <none>; prim: <none>
    assign mul_tree_345_429 = ({1'h0, mul_tree_345_424}); // decl: <none>; prim: <none>
    assign mul_tree_345_430 = 67'((mul_tree_345_428 + mul_tree_345_429 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_345_431 = ({2'h0, rtlzz_pipe_427_s6}); // decl: <none>; prim: <none>
    assign mul_tree_345_432 = ({1'h0, rtlzz_pipe_430_s6}); // decl: <none>; prim: <none>
    assign mul_tree_345_433 = 68'((mul_tree_345_431 + mul_tree_345_432 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_345_434 = mul_tree_345_433[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_435 = mul_precision_301[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_436 = mul_precision_302[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_346_437 = 64'(($unsigned(64'($unsigned(mul_tree_346_435))) * $unsigned(64'($unsigned(mul_tree_346_436))))); // decl: <none>; prim: <none>
    assign mul_tree_347_438 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_439 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_440 = 64'(($unsigned(64'($unsigned(mul_tree_347_438))) * $unsigned(64'($unsigned(mul_tree_347_439))))); // decl: <none>; prim: <none>
    assign mul_tree_347_441 = mul_precision_304[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_442 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_443 = 34'(($unsigned(34'($unsigned(mul_tree_347_441))) * $unsigned(34'($unsigned(mul_tree_347_442))))); // decl: <none>; prim: <none>
    assign mul_tree_347_444 = {mul_tree_347_443, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_445 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_446 = mul_precision_305[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_347_447 = 34'(($unsigned(34'($unsigned(mul_tree_347_445))) * $unsigned(34'($unsigned(mul_tree_347_446))))); // decl: <none>; prim: <none>
    assign mul_tree_347_448 = {mul_tree_347_447, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_449 = mul_precision_304[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_450 = mul_precision_305[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_347_451 = 4'(($unsigned(4'($unsigned(mul_tree_347_449))) * $unsigned(4'($unsigned(mul_tree_347_450))))); // decl: <none>; prim: <none>
    assign mul_tree_347_452 = {mul_tree_347_451, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_347_453 = ({3'h0, mul_tree_347_440}); // decl: <none>; prim: <none>
    assign mul_tree_347_454 = ({1'h0, mul_tree_347_444}); // decl: <none>; prim: <none>
    assign mul_tree_347_455 = 67'((mul_tree_347_453 + mul_tree_347_454 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_347_456 = ({3'h0, mul_tree_347_448}); // decl: <none>; prim: <none>
    assign mul_tree_347_457 = ({1'h0, mul_tree_347_452}); // decl: <none>; prim: <none>
    assign mul_tree_347_458 = 69'((mul_tree_347_456 + mul_tree_347_457 + ({68'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_347_459 = ({3'h0, mul_tree_347_455}); // decl: <none>; prim: <none>
    assign mul_tree_347_460 = ({1'h0, mul_tree_347_458}); // decl: <none>; prim: <none>
    assign mul_tree_347_461 = 70'((mul_tree_347_459 + mul_tree_347_460 + ({69'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_347_462 = mul_tree_347_461[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_463 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_464 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_465 = 64'(($unsigned(64'($unsigned(mul_tree_348_463))) * $unsigned(64'($unsigned(mul_tree_348_464))))); // decl: <none>; prim: <none>
    assign mul_tree_348_466 = rtlzz_pipe_307_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_467 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_468 = 64'(($unsigned(64'($unsigned(mul_tree_348_466))) * $unsigned(64'($unsigned(mul_tree_348_467))))); // decl: <none>; prim: <none>
    assign mul_tree_348_469 = {mul_tree_348_468, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_470 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_471 = mul_precision_308[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_348_472 = 64'(($unsigned(64'($unsigned(mul_tree_348_470))) * $unsigned(64'($unsigned(mul_tree_348_471))))); // decl: <none>; prim: <none>
    assign mul_tree_348_473 = {mul_tree_348_472, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_474 = rtlzz_pipe_307_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_475 = mul_precision_308[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_348_476 = 64'(($unsigned(64'($unsigned(mul_tree_348_474))) * $unsigned(64'($unsigned(mul_tree_348_475))))); // decl: <none>; prim: <none>
    assign mul_tree_348_477 = {mul_tree_348_476, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_348_478 = ({33'h0, rtlzz_pipe_465_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_479 = ({1'h0, rtlzz_pipe_469_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_480 = 97'((mul_tree_348_478 + mul_tree_348_479 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_348_481 = ({33'h0, rtlzz_pipe_473_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_482 = ({1'h0, rtlzz_pipe_477_s6}); // decl: <none>; prim: <none>
    assign mul_tree_348_483 = 129'((mul_tree_348_481 + mul_tree_348_482 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_348_484 = ({33'h0, mul_tree_348_480}); // decl: <none>; prim: <none>
    assign mul_tree_348_485 = ({1'h0, mul_tree_348_483}); // decl: <none>; prim: <none>
    assign mul_tree_348_486 = 130'((mul_tree_348_484 + mul_tree_348_485 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_348_487 = mul_tree_348_486[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_488 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_489 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_490 = 64'(($unsigned(64'($unsigned(mul_tree_349_488))) * $unsigned(64'($unsigned(mul_tree_349_489))))); // decl: <none>; prim: <none>
    assign mul_tree_349_491 = rtlzz_pipe_310_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_492 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_493 = 64'(($unsigned(64'($unsigned(mul_tree_349_491))) * $unsigned(64'($unsigned(mul_tree_349_492))))); // decl: <none>; prim: <none>
    assign mul_tree_349_494 = {mul_tree_349_493, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_495 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_496 = mul_precision_311[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_349_497 = 64'(($unsigned(64'($unsigned(mul_tree_349_495))) * $unsigned(64'($unsigned(mul_tree_349_496))))); // decl: <none>; prim: <none>
    assign mul_tree_349_498 = {mul_tree_349_497, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_499 = rtlzz_pipe_310_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_500 = mul_precision_311[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_349_501 = 64'(($unsigned(64'($unsigned(mul_tree_349_499))) * $unsigned(64'($unsigned(mul_tree_349_500))))); // decl: <none>; prim: <none>
    assign mul_tree_349_502 = {mul_tree_349_501, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_349_503 = ({33'h0, mul_tree_349_490}); // decl: <none>; prim: <none>
    assign mul_tree_349_504 = ({1'h0, mul_tree_349_494}); // decl: <none>; prim: <none>
    assign mul_tree_349_505 = 97'((mul_tree_349_503 + mul_tree_349_504 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_349_506 = ({33'h0, mul_tree_349_498}); // decl: <none>; prim: <none>
    assign mul_tree_349_507 = ({1'h0, mul_tree_349_502}); // decl: <none>; prim: <none>
    assign mul_tree_349_508 = 129'((mul_tree_349_506 + mul_tree_349_507 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_349_509 = ({33'h0, mul_tree_349_505}); // decl: <none>; prim: <none>
    assign mul_tree_349_510 = ({1'h0, mul_tree_349_508}); // decl: <none>; prim: <none>
    assign mul_tree_349_511 = 130'((mul_tree_349_509 + mul_tree_349_510 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_349_512 = mul_tree_349_511[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_513 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_514 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_515 = 64'(($unsigned(64'($unsigned(mul_tree_350_513))) * $unsigned(64'($unsigned(mul_tree_350_514))))); // decl: <none>; prim: <none>
    assign mul_tree_350_516 = rtlzz_pipe_313_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_517 = mul_precision_314[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_518 = 33'(($unsigned(33'($unsigned(mul_tree_350_516))) * $unsigned(33'($unsigned(mul_tree_350_517))))); // decl: <none>; prim: <none>
    assign mul_tree_350_519 = {mul_tree_350_518, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_520 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_521 = mul_precision_314[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_350_522 = 33'(($unsigned(33'($unsigned(mul_tree_350_520))) * $unsigned(33'($unsigned(mul_tree_350_521))))); // decl: <none>; prim: <none>
    assign mul_tree_350_523 = {mul_tree_350_522, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_524 = rtlzz_pipe_313_s7[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_525 = mul_precision_314[32]; // decl: <none>; prim: <none>
    assign mul_tree_350_526 = 2'(($unsigned(2'($unsigned(mul_tree_350_524))) * $unsigned(2'($unsigned(mul_tree_350_525))))); // decl: <none>; prim: <none>
    assign mul_tree_350_527 = {mul_tree_350_526, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_350_528 = ({2'h0, mul_tree_350_515}); // decl: <none>; prim: <none>
    assign mul_tree_350_529 = ({1'h0, mul_tree_350_519}); // decl: <none>; prim: <none>
    assign mul_tree_350_530 = 66'((mul_tree_350_528 + mul_tree_350_529 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_350_531 = ({2'h0, mul_tree_350_523}); // decl: <none>; prim: <none>
    assign mul_tree_350_532 = ({1'h0, mul_tree_350_527}); // decl: <none>; prim: <none>
    assign mul_tree_350_533 = 67'((mul_tree_350_531 + mul_tree_350_532 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_350_534 = ({2'h0, mul_tree_350_530}); // decl: <none>; prim: <none>
    assign mul_tree_350_535 = ({1'h0, mul_tree_350_533}); // decl: <none>; prim: <none>
    assign mul_tree_350_536 = 68'((mul_tree_350_534 + mul_tree_350_535 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_350_537 = mul_tree_350_536[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_538 = mul_precision_316[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_539 = mul_precision_317[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_351_540 = 64'(($unsigned(64'($unsigned(mul_tree_351_538))) * $unsigned(64'($unsigned(mul_tree_351_539))))); // decl: <none>; prim: <none>
    assign mul_tree_352_541 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_542 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_543 = 64'(($unsigned(64'($unsigned(mul_tree_352_541))) * $unsigned(64'($unsigned(mul_tree_352_542))))); // decl: <none>; prim: <none>
    assign mul_tree_352_544 = mul_precision_319[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_545 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_546 = 34'(($unsigned(34'($unsigned(mul_tree_352_544))) * $unsigned(34'($unsigned(mul_tree_352_545))))); // decl: <none>; prim: <none>
    assign mul_tree_352_547 = {mul_tree_352_546, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_548 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_549 = mul_precision_320[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_352_550 = 34'(($unsigned(34'($unsigned(mul_tree_352_548))) * $unsigned(34'($unsigned(mul_tree_352_549))))); // decl: <none>; prim: <none>
    assign mul_tree_352_551 = {mul_tree_352_550, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_552 = mul_precision_319[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_553 = mul_precision_320[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_352_554 = 4'(($unsigned(4'($unsigned(mul_tree_352_552))) * $unsigned(4'($unsigned(mul_tree_352_553))))); // decl: <none>; prim: <none>
    assign mul_tree_352_555 = {mul_tree_352_554, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_352_556 = ({3'h0, mul_tree_352_543}); // decl: <none>; prim: <none>
    assign mul_tree_352_557 = ({1'h0, mul_tree_352_547}); // decl: <none>; prim: <none>
    assign mul_tree_352_558 = 67'((mul_tree_352_556 + mul_tree_352_557 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_352_559 = ({3'h0, mul_tree_352_551}); // decl: <none>; prim: <none>
    assign mul_tree_352_560 = ({1'h0, mul_tree_352_555}); // decl: <none>; prim: <none>
    assign mul_tree_352_561 = 69'((mul_tree_352_559 + mul_tree_352_560 + ({68'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_352_562 = ({3'h0, mul_tree_352_558}); // decl: <none>; prim: <none>
    assign mul_tree_352_563 = ({1'h0, mul_tree_352_561}); // decl: <none>; prim: <none>
    assign mul_tree_352_564 = 70'((mul_tree_352_562 + mul_tree_352_563 + ({69'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_352_565 = mul_tree_352_564[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_566 = rtlzz_pipe_322_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_567 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_568 = 64'(($unsigned(64'($unsigned(mul_tree_353_566))) * $unsigned(64'($unsigned(mul_tree_353_567))))); // decl: <none>; prim: <none>
    assign mul_tree_353_569 = rtlzz_pipe_322_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_570 = mul_precision_323[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_571 = 33'(($unsigned(33'($unsigned(mul_tree_353_569))) * $unsigned(33'($unsigned(mul_tree_353_570))))); // decl: <none>; prim: <none>
    assign mul_tree_353_572 = {mul_tree_353_571, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_573 = rtlzz_pipe_322_s3[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_574 = mul_precision_323[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_353_575 = 33'(($unsigned(33'($unsigned(mul_tree_353_573))) * $unsigned(33'($unsigned(mul_tree_353_574))))); // decl: <none>; prim: <none>
    assign mul_tree_353_576 = {mul_tree_353_575, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_577 = rtlzz_pipe_322_s3[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_578 = mul_precision_323[32]; // decl: <none>; prim: <none>
    assign mul_tree_353_579 = 2'(($unsigned(2'($unsigned(mul_tree_353_577))) * $unsigned(2'($unsigned(mul_tree_353_578))))); // decl: <none>; prim: <none>
    assign mul_tree_353_580 = {mul_tree_353_579, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_353_581 = ({2'h0, mul_tree_353_568}); // decl: <none>; prim: <none>
    assign mul_tree_353_582 = ({1'h0, mul_tree_353_572}); // decl: <none>; prim: <none>
    assign mul_tree_353_583 = 66'((mul_tree_353_581 + mul_tree_353_582 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_353_584 = ({2'h0, mul_tree_353_576}); // decl: <none>; prim: <none>
    assign mul_tree_353_585 = ({1'h0, mul_tree_353_580}); // decl: <none>; prim: <none>
    assign mul_tree_353_586 = 67'((mul_tree_353_584 + mul_tree_353_585 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_353_587 = ({2'h0, mul_tree_353_583}); // decl: <none>; prim: <none>
    assign mul_tree_353_588 = ({1'h0, mul_tree_353_586}); // decl: <none>; prim: <none>
    assign mul_tree_353_589 = 68'((mul_tree_353_587 + mul_tree_353_588 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_353_590 = mul_tree_353_589[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_591 = rtlzz_pipe_325_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_592 = mul_precision_326[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_354_593 = 64'(($unsigned(64'($unsigned(mul_tree_354_591))) * $unsigned(64'($unsigned(mul_tree_354_592))))); // decl: <none>; prim: <none>
    assign mul_tree_355_594 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_595 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_596 = 64'(($unsigned(64'($unsigned(mul_tree_355_594))) * $unsigned(64'($unsigned(mul_tree_355_595))))); // decl: <none>; prim: <none>
    assign mul_tree_355_597 = rtlzz_pipe_328_s4[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_598 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_599 = 34'(($unsigned(34'($unsigned(mul_tree_355_597))) * $unsigned(34'($unsigned(mul_tree_355_598))))); // decl: <none>; prim: <none>
    assign mul_tree_355_600 = {mul_tree_355_599, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_601 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_602 = mul_precision_329[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_355_603 = 34'(($unsigned(34'($unsigned(mul_tree_355_601))) * $unsigned(34'($unsigned(mul_tree_355_602))))); // decl: <none>; prim: <none>
    assign mul_tree_355_604 = {mul_tree_355_603, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_605 = rtlzz_pipe_328_s4[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_606 = mul_precision_329[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_355_607 = 4'(($unsigned(4'($unsigned(mul_tree_355_605))) * $unsigned(4'($unsigned(mul_tree_355_606))))); // decl: <none>; prim: <none>
    assign mul_tree_355_608 = {mul_tree_355_607, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_355_609 = ({3'h0, mul_tree_355_596}); // decl: <none>; prim: <none>
    assign mul_tree_355_610 = ({1'h0, mul_tree_355_600}); // decl: <none>; prim: <none>
    assign mul_tree_355_611 = 67'((mul_tree_355_609 + mul_tree_355_610 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_355_612 = ({3'h0, mul_tree_355_604}); // decl: <none>; prim: <none>
    assign mul_tree_355_613 = ({1'h0, mul_tree_355_608}); // decl: <none>; prim: <none>
    assign mul_tree_355_614 = 69'((mul_tree_355_612 + mul_tree_355_613 + ({68'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_355_615 = ({3'h0, mul_tree_355_611}); // decl: <none>; prim: <none>
    assign mul_tree_355_616 = ({1'h0, mul_tree_355_614}); // decl: <none>; prim: <none>
    assign mul_tree_355_617 = 70'((mul_tree_355_615 + mul_tree_355_616 + ({69'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_355_618 = mul_tree_355_617[67:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_619 = rtlzz_pipe_331_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_620 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_621 = 64'(($unsigned(64'($unsigned(mul_tree_356_619))) * $unsigned(64'($unsigned(mul_tree_356_620))))); // decl: <none>; prim: <none>
    assign mul_tree_356_622 = rtlzz_pipe_331_s3[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_623 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_624 = 64'(($unsigned(64'($unsigned(mul_tree_356_622))) * $unsigned(64'($unsigned(mul_tree_356_623))))); // decl: <none>; prim: <none>
    assign mul_tree_356_625 = {mul_tree_356_624, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_626 = rtlzz_pipe_331_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_627 = mul_precision_332[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_356_628 = 64'(($unsigned(64'($unsigned(mul_tree_356_626))) * $unsigned(64'($unsigned(mul_tree_356_627))))); // decl: <none>; prim: <none>
    assign mul_tree_356_629 = {mul_tree_356_628, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_630 = rtlzz_pipe_331_s3[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_631 = mul_precision_332[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_356_632 = 64'(($unsigned(64'($unsigned(mul_tree_356_630))) * $unsigned(64'($unsigned(mul_tree_356_631))))); // decl: <none>; prim: <none>
    assign mul_tree_356_633 = {mul_tree_356_632, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_356_634 = ({33'h0, mul_tree_356_621}); // decl: <none>; prim: <none>
    assign mul_tree_356_635 = ({1'h0, mul_tree_356_625}); // decl: <none>; prim: <none>
    assign mul_tree_356_636 = 97'((mul_tree_356_634 + mul_tree_356_635 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_356_637 = ({33'h0, mul_tree_356_629}); // decl: <none>; prim: <none>
    assign mul_tree_356_638 = ({1'h0, mul_tree_356_633}); // decl: <none>; prim: <none>
    assign mul_tree_356_639 = 129'((mul_tree_356_637 + mul_tree_356_638 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_356_640 = ({33'h0, mul_tree_356_636}); // decl: <none>; prim: <none>
    assign mul_tree_356_641 = ({1'h0, mul_tree_356_639}); // decl: <none>; prim: <none>
    assign mul_tree_356_642 = 130'((mul_tree_356_640 + mul_tree_356_641 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_356_643 = mul_tree_356_642[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_644 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_645 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_646 = 64'(($unsigned(64'($unsigned(mul_tree_357_644))) * $unsigned(64'($unsigned(mul_tree_357_645))))); // decl: <none>; prim: <none>
    assign mul_tree_357_647 = rtlzz_pipe_334_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_648 = mul_precision_335[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_649 = 33'(($unsigned(33'($unsigned(mul_tree_357_647))) * $unsigned(33'($unsigned(mul_tree_357_648))))); // decl: <none>; prim: <none>
    assign mul_tree_357_650 = {mul_tree_357_649, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_651 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_652 = mul_precision_335[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_357_653 = 33'(($unsigned(33'($unsigned(mul_tree_357_651))) * $unsigned(33'($unsigned(mul_tree_357_652))))); // decl: <none>; prim: <none>
    assign mul_tree_357_654 = {mul_tree_357_653, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_655 = rtlzz_pipe_334_s5[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_656 = mul_precision_335[32]; // decl: <none>; prim: <none>
    assign mul_tree_357_657 = 2'(($unsigned(2'($unsigned(mul_tree_357_655))) * $unsigned(2'($unsigned(mul_tree_357_656))))); // decl: <none>; prim: <none>
    assign mul_tree_357_658 = {mul_tree_357_657, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_357_659 = ({2'h0, mul_tree_357_646}); // decl: <none>; prim: <none>
    assign mul_tree_357_660 = ({1'h0, mul_tree_357_650}); // decl: <none>; prim: <none>
    assign mul_tree_357_661 = 66'((mul_tree_357_659 + mul_tree_357_660 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_357_662 = ({2'h0, mul_tree_357_654}); // decl: <none>; prim: <none>
    assign mul_tree_357_663 = ({1'h0, mul_tree_357_658}); // decl: <none>; prim: <none>
    assign mul_tree_357_664 = 67'((mul_tree_357_662 + mul_tree_357_663 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_357_665 = ({2'h0, mul_tree_357_661}); // decl: <none>; prim: <none>
    assign mul_tree_357_666 = ({1'h0, mul_tree_357_664}); // decl: <none>; prim: <none>
    assign mul_tree_357_667 = 68'((mul_tree_357_665 + mul_tree_357_666 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_357_668 = mul_tree_357_667[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_669 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_670 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_671 = 64'(($unsigned(64'($unsigned(mul_tree_358_669))) * $unsigned(64'($unsigned(mul_tree_358_670))))); // decl: <none>; prim: <none>
    assign mul_tree_358_672 = rtlzz_pipe_337_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_673 = mul_precision_338[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_674 = 33'(($unsigned(33'($unsigned(mul_tree_358_672))) * $unsigned(33'($unsigned(mul_tree_358_673))))); // decl: <none>; prim: <none>
    assign mul_tree_358_675 = {mul_tree_358_674, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_676 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_677 = mul_precision_338[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_358_678 = 33'(($unsigned(33'($unsigned(mul_tree_358_676))) * $unsigned(33'($unsigned(mul_tree_358_677))))); // decl: <none>; prim: <none>
    assign mul_tree_358_679 = {mul_tree_358_678, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_680 = rtlzz_pipe_337_s6[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_681 = mul_precision_338[32]; // decl: <none>; prim: <none>
    assign mul_tree_358_682 = 2'(($unsigned(2'($unsigned(mul_tree_358_680))) * $unsigned(2'($unsigned(mul_tree_358_681))))); // decl: <none>; prim: <none>
    assign mul_tree_358_683 = {mul_tree_358_682, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_358_684 = ({2'h0, mul_tree_358_671}); // decl: <none>; prim: <none>
    assign mul_tree_358_685 = ({1'h0, mul_tree_358_675}); // decl: <none>; prim: <none>
    assign mul_tree_358_686 = 66'((mul_tree_358_684 + mul_tree_358_685 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_358_687 = ({2'h0, mul_tree_358_679}); // decl: <none>; prim: <none>
    assign mul_tree_358_688 = ({1'h0, mul_tree_358_683}); // decl: <none>; prim: <none>
    assign mul_tree_358_689 = 67'((mul_tree_358_687 + mul_tree_358_688 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_358_690 = ({2'h0, mul_tree_358_686}); // decl: <none>; prim: <none>
    assign mul_tree_358_691 = ({1'h0, mul_tree_358_689}); // decl: <none>; prim: <none>
    assign mul_tree_358_692 = 68'((mul_tree_358_690 + mul_tree_358_691 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_358_693 = mul_tree_358_692[65:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_694 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_695 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_696 = 64'(($unsigned(64'($unsigned(mul_tree_359_694))) * $unsigned(64'($unsigned(mul_tree_359_695))))); // decl: <none>; prim: <none>
    assign mul_tree_359_697 = rtlzz_pipe_340_s6[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_698 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_699 = 34'(($unsigned(34'($unsigned(mul_tree_359_697))) * $unsigned(34'($unsigned(mul_tree_359_698))))); // decl: <none>; prim: <none>
    assign mul_tree_359_700 = {mul_tree_359_699, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_701 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_702 = mul_precision_341[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_359_703 = 34'(($unsigned(34'($unsigned(mul_tree_359_701))) * $unsigned(34'($unsigned(mul_tree_359_702))))); // decl: <none>; prim: <none>
    assign mul_tree_359_704 = {mul_tree_359_703, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_705 = rtlzz_pipe_340_s6[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_706 = mul_precision_341[33:32]; // decl: <none>; prim: <none>
    assign mul_tree_359_707 = 4'(($unsigned(4'($unsigned(mul_tree_359_705))) * $unsigned(4'($unsigned(mul_tree_359_706))))); // decl: <none>; prim: <none>
    assign mul_tree_359_708 = {mul_tree_359_707, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_359_709 = ({3'h0, mul_tree_359_696}); // decl: <none>; prim: <none>
    assign mul_tree_359_710 = ({1'h0, mul_tree_359_700}); // decl: <none>; prim: <none>
    assign mul_tree_359_711 = 67'((mul_tree_359_709 + mul_tree_359_710 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_359_712 = ({3'h0, mul_tree_359_704}); // decl: <none>; prim: <none>
    assign mul_tree_359_713 = ({1'h0, mul_tree_359_708}); // decl: <none>; prim: <none>
    assign mul_tree_359_714 = 69'((mul_tree_359_712 + mul_tree_359_713 + ({68'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_359_715 = ({3'h0, mul_tree_359_711}); // decl: <none>; prim: <none>
    assign mul_tree_359_716 = ({1'h0, mul_tree_359_714}); // decl: <none>; prim: <none>
    assign mul_tree_359_717 = 70'((mul_tree_359_715 + mul_tree_359_716 + ({69'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_359_718 = mul_tree_359_717[67:0]; // decl: <none>; prim: <none>
    assign limb_13_719 = tmp_workload_top_int_65__18_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_13_720 = __beopt_width_312[63:0]; // decl: <none>; prim: <none>
    assign limb_13_721 = 65'((({1'h0, rtlzz_pipe_719_s4}) + ({1'h0, limb_13_720}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_13_722 = limb_13_721[63:0]; // decl: <none>; prim: <none>
    assign limb_13_723 = limb_13_721[64]; // decl: <none>; prim: <none>
    assign limb_13_724 = tmp_workload_top_int_65__18_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_725 = __beopt_width_312[64]; // decl: <none>; prim: <none>
    assign limb_13_726 = 2'((({1'h0, rtlzz_pipe_724_s4}) + ({1'h0, limb_13_725}) + ({1'h0, limb_13_723}))); // decl: <none>; prim: <none>
    assign limb_13_727 = limb_13_726[0]; // decl: <none>; prim: <none>
    assign limb_13_728 = {limb_13_727, limb_13_722}; // decl: <none>; prim: <none>
    assign limb_15_729 = tmp_workload_top_int_65__23_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_15_730 = __beopt_width_318[63:0]; // decl: <none>; prim: <none>
    assign limb_15_731 = 65'((({1'h0, rtlzz_pipe_729_s5}) + ({1'h0, limb_15_730}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_15_732 = limb_15_731[63:0]; // decl: <none>; prim: <none>
    assign limb_15_733 = limb_15_731[64]; // decl: <none>; prim: <none>
    assign limb_15_734 = tmp_workload_top_int_65__23_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_735 = __beopt_width_318[64]; // decl: <none>; prim: <none>
    assign limb_15_736 = 2'((({1'h0, rtlzz_pipe_734_s5}) + ({1'h0, limb_15_735}) + ({1'h0, limb_15_733}))); // decl: <none>; prim: <none>
    assign limb_15_737 = limb_15_736[0]; // decl: <none>; prim: <none>
    assign limb_15_738 = {limb_15_737, limb_15_732}; // decl: <none>; prim: <none>
    assign limb_29_739 = n20_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_740 = tmp_workload_top_int_68__57_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_741 = (~rtlzz_pipe_740_s7); // decl: <none>; prim: <none>
    assign limb_29_742 = 65'((({1'h0, rtlzz_pipe_739_s7}) + ({1'h0, limb_29_741}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_29_743 = limb_29_742[63:0]; // decl: <none>; prim: <none>
    assign limb_29_744 = limb_29_742[64]; // decl: <none>; prim: <none>
    assign limb_29_745 = n20_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_746 = tmp_workload_top_int_68__57_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_747 = (~limb_29_746); // decl: <none>; prim: <none>
    assign limb_29_748 = 5'((({1'h0, rtlzz_pipe_745_s7}) + ({1'h0, rtlzz_pipe_747_s7}) + ({4'h0, limb_29_744}))); // decl: <none>; prim: <none>
    assign limb_29_749 = limb_29_748[3:0]; // decl: <none>; prim: <none>
    assign limb_29_750 = {limb_29_749, limb_29_743}; // decl: <none>; prim: <none>
    assign limb_31_751 = s8_norm_sub_45_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_752 = tmp_workload_top_int_68__60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_753 = (~limb_31_752); // decl: <none>; prim: <none>
    assign limb_31_754 = 65'((({1'h0, limb_31_751}) + ({1'h0, rtlzz_pipe_753_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_31_755 = limb_31_754[63:0]; // decl: <none>; prim: <none>
    assign limb_31_756 = limb_31_754[64]; // decl: <none>; prim: <none>
    assign limb_31_757 = s8_norm_sub_45_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_758 = tmp_workload_top_int_68__60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_759 = (~limb_31_758); // decl: <none>; prim: <none>
    assign limb_31_760 = 5'((({1'h0, limb_31_757}) + ({1'h0, rtlzz_pipe_759_s7}) + ({4'h0, limb_31_756}))); // decl: <none>; prim: <none>
    assign limb_31_761 = limb_31_760[3:0]; // decl: <none>; prim: <none>
    assign limb_31_762 = {limb_31_761, limb_31_755}; // decl: <none>; prim: <none>
    assign limb_38_763 = __beopt_width_317[63:0]; // decl: <none>; prim: <none>
    assign limb_38_764 = tmp_workload_top_int_130__73_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_38_765 = (~limb_38_764); // decl: <none>; prim: <none>
    assign limb_38_766 = 65'((({1'h0, limb_38_763}) + ({1'h0, rtlzz_pipe_765_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_38_767 = limb_38_766[63:0]; // decl: <none>; prim: <none>
    assign limb_38_768 = limb_38_766[64]; // decl: <none>; prim: <none>
    assign limb_38_769 = __beopt_width_317[127:64]; // decl: <none>; prim: <none>
    assign limb_38_770 = tmp_workload_top_int_130__73_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_38_771 = (~limb_38_770); // decl: <none>; prim: <none>
    assign limb_38_772 = 65'((({1'h0, limb_38_769}) + ({1'h0, rtlzz_pipe_771_s7}) + ({64'h0, limb_38_768}))); // decl: <none>; prim: <none>
    assign limb_38_773 = limb_38_772[63:0]; // decl: <none>; prim: <none>
    assign limb_38_774 = limb_38_772[64]; // decl: <none>; prim: <none>
    assign limb_38_775 = __beopt_width_317[129:128]; // decl: <none>; prim: <none>
    assign limb_38_776 = tmp_workload_top_int_130__73_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_38_777 = (~limb_38_776); // decl: <none>; prim: <none>
    assign limb_38_778 = 3'((({1'h0, limb_38_775}) + ({1'h0, rtlzz_pipe_777_s7}) + ({2'h0, limb_38_774}))); // decl: <none>; prim: <none>
    assign limb_38_779 = limb_38_778[1:0]; // decl: <none>; prim: <none>
    assign limb_38_780 = {limb_38_779, limb_38_773, limb_38_767}; // decl: <none>; prim: <none>
    assign limb_40_781 = s8_norm_sub_56_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_782 = tmp_workload_top_int_130__76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_783 = (~limb_40_782); // decl: <none>; prim: <none>
    assign limb_40_784 = 65'((({1'h0, limb_40_781}) + ({1'h0, rtlzz_pipe_783_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_40_785 = limb_40_784[63:0]; // decl: <none>; prim: <none>
    assign limb_40_786 = limb_40_784[64]; // decl: <none>; prim: <none>
    assign limb_40_787 = s8_norm_sub_56_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_788 = tmp_workload_top_int_130__76_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_789 = (~rtlzz_pipe_788_s7); // decl: <none>; prim: <none>
    assign limb_40_790 = 65'((({1'h0, limb_40_787}) + ({1'h0, limb_40_789}) + ({64'h0, limb_40_786}))); // decl: <none>; prim: <none>
    assign limb_40_791 = limb_40_790[63:0]; // decl: <none>; prim: <none>
    assign limb_40_792 = limb_40_790[64]; // decl: <none>; prim: <none>
    assign limb_40_793 = s8_norm_sub_56_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_794 = tmp_workload_top_int_130__76_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_795 = (~rtlzz_pipe_794_s7); // decl: <none>; prim: <none>
    assign limb_40_796 = 3'((({1'h0, limb_40_793}) + ({1'h0, limb_40_795}) + ({2'h0, limb_40_792}))); // decl: <none>; prim: <none>
    assign limb_40_797 = limb_40_796[1:0]; // decl: <none>; prim: <none>
    assign limb_40_798 = {limb_40_797, limb_40_791, limb_40_785}; // decl: <none>; prim: <none>
    assign limb_51_799 = tmp_workload_top_int_65__103_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_51_800 = __beopt_width_352[63:0]; // decl: <none>; prim: <none>
    assign limb_51_801 = 65'((({1'h0, limb_51_799}) + ({1'h0, rtlzz_pipe_800_s6}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_51_802 = limb_51_801[63:0]; // decl: <none>; prim: <none>
    assign limb_51_803 = limb_51_801[64]; // decl: <none>; prim: <none>
    assign limb_51_804 = tmp_workload_top_int_65__103_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_805 = __beopt_width_352[64]; // decl: <none>; prim: <none>
    assign limb_51_806 = 2'((({1'h0, limb_51_804}) + ({1'h0, rtlzz_pipe_805_s6}) + ({1'h0, limb_51_803}))); // decl: <none>; prim: <none>
    assign limb_51_807 = limb_51_806[0]; // decl: <none>; prim: <none>
    assign limb_51_808 = {limb_51_807, limb_51_802}; // decl: <none>; prim: <none>
    assign limb_53_809 = tmp_workload_top_int_65__108_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_53_810 = __beopt_width_357[63:0]; // decl: <none>; prim: <none>
    assign limb_53_811 = 65'((({1'h0, limb_53_809}) + ({1'h0, rtlzz_pipe_810_s7}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_53_812 = limb_53_811[63:0]; // decl: <none>; prim: <none>
    assign limb_53_813 = limb_53_811[64]; // decl: <none>; prim: <none>
    assign limb_53_814 = tmp_workload_top_int_65__108_v0[64]; // decl: <none>; prim: <none>
    assign limb_53_815 = __beopt_width_357[64]; // decl: <none>; prim: <none>
    assign limb_53_816 = 2'((({1'h0, limb_53_814}) + ({1'h0, rtlzz_pipe_815_s7}) + ({1'h0, limb_53_813}))); // decl: <none>; prim: <none>
    assign limb_53_817 = limb_53_816[0]; // decl: <none>; prim: <none>
    assign limb_53_818 = {limb_53_817, limb_53_812}; // decl: <none>; prim: <none>
    assign limb_67_819 = n41_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_820 = tmp_workload_top_int_68__142_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_821 = (~limb_67_820); // decl: <none>; prim: <none>
    assign limb_67_822 = 65'((({1'h0, limb_67_819}) + ({1'h0, limb_67_821}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_67_823 = limb_67_822[63:0]; // decl: <none>; prim: <none>
    assign limb_67_824 = limb_67_822[64]; // decl: <none>; prim: <none>
    assign limb_67_825 = n41_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_826 = tmp_workload_top_int_68__142_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_827 = (~limb_67_826); // decl: <none>; prim: <none>
    assign limb_67_828 = 5'((({1'h0, limb_67_825}) + ({1'h0, limb_67_827}) + ({4'h0, limb_67_824}))); // decl: <none>; prim: <none>
    assign limb_67_829 = limb_67_828[3:0]; // decl: <none>; prim: <none>
    assign limb_67_830 = {limb_67_829, limb_67_823}; // decl: <none>; prim: <none>
    assign limb_69_831 = s8_norm_sub_107_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_832 = tmp_workload_top_int_68__145_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_833 = (~limb_69_832); // decl: <none>; prim: <none>
    assign limb_69_834 = 65'((({1'h0, limb_69_831}) + ({1'h0, limb_69_833}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_69_835 = limb_69_834[63:0]; // decl: <none>; prim: <none>
    assign limb_69_836 = limb_69_834[64]; // decl: <none>; prim: <none>
    assign limb_69_837 = s8_norm_sub_107_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_838 = tmp_workload_top_int_68__145_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_839 = (~limb_69_838); // decl: <none>; prim: <none>
    assign limb_69_840 = 5'((({1'h0, limb_69_837}) + ({1'h0, limb_69_839}) + ({4'h0, limb_69_836}))); // decl: <none>; prim: <none>
    assign limb_69_841 = limb_69_840[3:0]; // decl: <none>; prim: <none>
    assign limb_69_842 = {limb_69_841, limb_69_835}; // decl: <none>; prim: <none>
    assign limb_76_843 = __beopt_width_313[63:0]; // decl: <none>; prim: <none>
    assign limb_76_844 = tmp_workload_top_int_130__158_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_76_845 = (~limb_76_844); // decl: <none>; prim: <none>
    assign limb_76_846 = 65'((({1'h0, limb_76_843}) + ({1'h0, rtlzz_pipe_845_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_76_847 = limb_76_846[63:0]; // decl: <none>; prim: <none>
    assign limb_76_848 = limb_76_846[64]; // decl: <none>; prim: <none>
    assign limb_76_849 = __beopt_width_313[127:64]; // decl: <none>; prim: <none>
    assign limb_76_850 = tmp_workload_top_int_130__158_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_76_851 = (~limb_76_850); // decl: <none>; prim: <none>
    assign limb_76_852 = 65'((({1'h0, limb_76_849}) + ({1'h0, rtlzz_pipe_851_s7}) + ({64'h0, limb_76_848}))); // decl: <none>; prim: <none>
    assign limb_76_853 = limb_76_852[63:0]; // decl: <none>; prim: <none>
    assign limb_76_854 = limb_76_852[64]; // decl: <none>; prim: <none>
    assign limb_76_855 = __beopt_width_313[129:128]; // decl: <none>; prim: <none>
    assign limb_76_856 = tmp_workload_top_int_130__158_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_76_857 = (~limb_76_856); // decl: <none>; prim: <none>
    assign limb_76_858 = 3'((({1'h0, limb_76_855}) + ({1'h0, rtlzz_pipe_857_s7}) + ({2'h0, limb_76_854}))); // decl: <none>; prim: <none>
    assign limb_76_859 = limb_76_858[1:0]; // decl: <none>; prim: <none>
    assign limb_76_860 = {limb_76_859, limb_76_853, limb_76_847}; // decl: <none>; prim: <none>
    assign limb_78_861 = s8_norm_sub_118_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_862 = tmp_workload_top_int_130__161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_863 = (~limb_78_862); // decl: <none>; prim: <none>
    assign limb_78_864 = 65'((({1'h0, limb_78_861}) + ({1'h0, limb_78_863}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_78_865 = limb_78_864[63:0]; // decl: <none>; prim: <none>
    assign limb_78_866 = limb_78_864[64]; // decl: <none>; prim: <none>
    assign limb_78_867 = s8_norm_sub_118_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_868 = tmp_workload_top_int_130__161_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_869 = (~limb_78_868); // decl: <none>; prim: <none>
    assign limb_78_870 = 65'((({1'h0, limb_78_867}) + ({1'h0, limb_78_869}) + ({64'h0, limb_78_866}))); // decl: <none>; prim: <none>
    assign limb_78_871 = limb_78_870[63:0]; // decl: <none>; prim: <none>
    assign limb_78_872 = limb_78_870[64]; // decl: <none>; prim: <none>
    assign limb_78_873 = s8_norm_sub_118_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_874 = tmp_workload_top_int_130__161_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_875 = (~limb_78_874); // decl: <none>; prim: <none>
    assign limb_78_876 = 3'((({1'h0, limb_78_873}) + ({1'h0, limb_78_875}) + ({2'h0, limb_78_872}))); // decl: <none>; prim: <none>
    assign limb_78_877 = limb_78_876[1:0]; // decl: <none>; prim: <none>
    assign limb_78_878 = {limb_78_877, limb_78_871, limb_78_865}; // decl: <none>; prim: <none>
    assign limb_85_879 = tmp_workload_top_int_129__174_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_85_880 = __beopt_width_374[63:0]; // decl: <none>; prim: <none>
    assign limb_85_881 = 65'((({1'h0, rtlzz_pipe_879_s2}) + ({1'h0, limb_85_880}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_85_882 = limb_85_881[63:0]; // decl: <none>; prim: <none>
    assign limb_85_883 = limb_85_881[64]; // decl: <none>; prim: <none>
    assign limb_85_884 = tmp_workload_top_int_129__174_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_85_885 = __beopt_width_374[127:64]; // decl: <none>; prim: <none>
    assign limb_85_886 = 65'((({1'h0, rtlzz_pipe_884_s2}) + ({1'h0, limb_85_885}) + ({64'h0, limb_85_883}))); // decl: <none>; prim: <none>
    assign limb_85_887 = limb_85_886[63:0]; // decl: <none>; prim: <none>
    assign limb_85_888 = limb_85_886[64]; // decl: <none>; prim: <none>
    assign limb_85_889 = tmp_workload_top_int_129__174_v0[128]; // decl: <none>; prim: <none>
    assign limb_85_890 = __beopt_width_374[128]; // decl: <none>; prim: <none>
    assign limb_85_891 = 2'((({1'h0, rtlzz_pipe_889_s2}) + ({1'h0, limb_85_890}) + ({1'h0, limb_85_888}))); // decl: <none>; prim: <none>
    assign limb_85_892 = limb_85_891[0]; // decl: <none>; prim: <none>
    assign limb_85_893 = {limb_85_892, limb_85_887, limb_85_882}; // decl: <none>; prim: <none>
    assign limb_87_894 = tmp_workload_top_int_129__179_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_87_895 = __beopt_width_378[63:0]; // decl: <none>; prim: <none>
    assign limb_87_896 = 65'((({1'h0, rtlzz_pipe_894_s3}) + ({1'h0, limb_87_895}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_87_897 = limb_87_896[63:0]; // decl: <none>; prim: <none>
    assign limb_87_898 = limb_87_896[64]; // decl: <none>; prim: <none>
    assign limb_87_899 = tmp_workload_top_int_129__179_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_87_900 = __beopt_width_378[127:64]; // decl: <none>; prim: <none>
    assign limb_87_901 = 65'((({1'h0, rtlzz_pipe_899_s3}) + ({1'h0, limb_87_900}) + ({64'h0, limb_87_898}))); // decl: <none>; prim: <none>
    assign limb_87_902 = limb_87_901[63:0]; // decl: <none>; prim: <none>
    assign limb_87_903 = limb_87_901[64]; // decl: <none>; prim: <none>
    assign limb_87_904 = tmp_workload_top_int_129__179_v0[128]; // decl: <none>; prim: <none>
    assign limb_87_905 = __beopt_width_378[128]; // decl: <none>; prim: <none>
    assign limb_87_906 = 2'((({1'h0, rtlzz_pipe_904_s3}) + ({1'h0, limb_87_905}) + ({1'h0, limb_87_903}))); // decl: <none>; prim: <none>
    assign limb_87_907 = limb_87_906[0]; // decl: <none>; prim: <none>
    assign limb_87_908 = {limb_87_907, limb_87_902, limb_87_897}; // decl: <none>; prim: <none>
    assign limb_103_909 = n60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_910 = tmp_workload_top_int_68__217_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_911 = (~limb_103_910); // decl: <none>; prim: <none>
    assign limb_103_912 = 65'((({1'h0, limb_103_909}) + ({1'h0, limb_103_911}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_103_913 = limb_103_912[63:0]; // decl: <none>; prim: <none>
    assign limb_103_914 = limb_103_912[64]; // decl: <none>; prim: <none>
    assign limb_103_915 = n60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_916 = tmp_workload_top_int_68__217_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_917 = (~limb_103_916); // decl: <none>; prim: <none>
    assign limb_103_918 = 5'((({1'h0, limb_103_915}) + ({1'h0, limb_103_917}) + ({4'h0, limb_103_914}))); // decl: <none>; prim: <none>
    assign limb_103_919 = limb_103_918[3:0]; // decl: <none>; prim: <none>
    assign limb_103_920 = {limb_103_919, limb_103_913}; // decl: <none>; prim: <none>
    assign limb_105_921 = s8_norm_sub_161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_922 = tmp_workload_top_int_68__220_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_923 = (~rtlzz_pipe_922_s5); // decl: <none>; prim: <none>
    assign limb_105_924 = 65'((({1'h0, rtlzz_pipe_921_s5}) + ({1'h0, limb_105_923}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_105_925 = limb_105_924[63:0]; // decl: <none>; prim: <none>
    assign limb_105_926 = limb_105_924[64]; // decl: <none>; prim: <none>
    assign limb_105_927 = s8_norm_sub_161_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_928 = tmp_workload_top_int_68__220_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_929 = (~rtlzz_pipe_928_s5); // decl: <none>; prim: <none>
    assign limb_105_930 = 5'((({1'h0, rtlzz_pipe_927_s5}) + ({1'h0, limb_105_929}) + ({4'h0, limb_105_926}))); // decl: <none>; prim: <none>
    assign limb_105_931 = limb_105_930[3:0]; // decl: <none>; prim: <none>
    assign limb_105_932 = {limb_105_931, limb_105_925}; // decl: <none>; prim: <none>
    assign limb_113_933 = tmp_workload_top_int_66__238_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_113_934 = __beopt_width_401[63:0]; // decl: <none>; prim: <none>
    assign limb_113_935 = 65'((({1'h0, rtlzz_pipe_933_s4}) + ({1'h0, limb_113_934}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_113_936 = limb_113_935[63:0]; // decl: <none>; prim: <none>
    assign limb_113_937 = limb_113_935[64]; // decl: <none>; prim: <none>
    assign limb_113_938 = tmp_workload_top_int_66__238_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_113_939 = __beopt_width_401[65:64]; // decl: <none>; prim: <none>
    assign limb_113_940 = 3'((({1'h0, rtlzz_pipe_938_s4}) + ({1'h0, limb_113_939}) + ({2'h0, limb_113_937}))); // decl: <none>; prim: <none>
    assign limb_113_941 = limb_113_940[1:0]; // decl: <none>; prim: <none>
    assign limb_113_942 = {limb_113_941, limb_113_936}; // decl: <none>; prim: <none>
    assign limb_115_943 = tmp_workload_top_int_66__243_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_115_944 = __beopt_width_404[63:0]; // decl: <none>; prim: <none>
    assign limb_115_945 = 65'((({1'h0, rtlzz_pipe_943_s4}) + ({1'h0, limb_115_944}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_115_946 = limb_115_945[63:0]; // decl: <none>; prim: <none>
    assign limb_115_947 = limb_115_945[64]; // decl: <none>; prim: <none>
    assign limb_115_948 = tmp_workload_top_int_66__243_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_115_949 = __beopt_width_404[65:64]; // decl: <none>; prim: <none>
    assign limb_115_950 = 3'((({1'h0, rtlzz_pipe_948_s4}) + ({1'h0, limb_115_949}) + ({2'h0, limb_115_947}))); // decl: <none>; prim: <none>
    assign limb_115_951 = limb_115_950[1:0]; // decl: <none>; prim: <none>
    assign limb_115_952 = {limb_115_951, limb_115_946}; // decl: <none>; prim: <none>
    assign limb_129_953 = n74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_954 = tmp_workload_top_int_68__277_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_955 = (~limb_129_954); // decl: <none>; prim: <none>
    assign limb_129_956 = 65'((({1'h0, limb_129_953}) + ({1'h0, rtlzz_pipe_955_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_129_957 = limb_129_956[63:0]; // decl: <none>; prim: <none>
    assign limb_129_958 = limb_129_956[64]; // decl: <none>; prim: <none>
    assign limb_129_959 = n74_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_960 = tmp_workload_top_int_68__277_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_961 = (~limb_129_960); // decl: <none>; prim: <none>
    assign limb_129_962 = 5'((({1'h0, limb_129_959}) + ({1'h0, rtlzz_pipe_961_s6}) + ({4'h0, limb_129_958}))); // decl: <none>; prim: <none>
    assign limb_129_963 = limb_129_962[3:0]; // decl: <none>; prim: <none>
    assign limb_129_964 = {limb_129_963, limb_129_957}; // decl: <none>; prim: <none>
    assign limb_131_965 = s8_norm_sub_204_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_966 = tmp_workload_top_int_68__280_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_967 = (~limb_131_966); // decl: <none>; prim: <none>
    assign limb_131_968 = 65'((({1'h0, limb_131_965}) + ({1'h0, limb_131_967}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_131_969 = limb_131_968[63:0]; // decl: <none>; prim: <none>
    assign limb_131_970 = limb_131_968[64]; // decl: <none>; prim: <none>
    assign limb_131_971 = s8_norm_sub_204_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_972 = tmp_workload_top_int_68__280_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_973 = (~limb_131_972); // decl: <none>; prim: <none>
    assign limb_131_974 = 5'((({1'h0, limb_131_971}) + ({1'h0, limb_131_973}) + ({4'h0, limb_131_970}))); // decl: <none>; prim: <none>
    assign limb_131_975 = limb_131_974[3:0]; // decl: <none>; prim: <none>
    assign limb_131_976 = {limb_131_975, limb_131_969}; // decl: <none>; prim: <none>
    assign limb_138_977 = __beopt_width_307[63:0]; // decl: <none>; prim: <none>
    assign limb_138_978 = tmp_workload_top_int_132__293_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_138_979 = (~limb_138_978); // decl: <none>; prim: <none>
    assign limb_138_980 = 65'((({1'h0, limb_138_977}) + ({1'h0, rtlzz_pipe_979_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_138_981 = limb_138_980[63:0]; // decl: <none>; prim: <none>
    assign limb_138_982 = limb_138_980[64]; // decl: <none>; prim: <none>
    assign limb_138_983 = __beopt_width_307[127:64]; // decl: <none>; prim: <none>
    assign limb_138_984 = tmp_workload_top_int_132__293_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_138_985 = (~limb_138_984); // decl: <none>; prim: <none>
    assign limb_138_986 = 65'((({1'h0, limb_138_983}) + ({1'h0, rtlzz_pipe_985_s6}) + ({64'h0, limb_138_982}))); // decl: <none>; prim: <none>
    assign limb_138_987 = limb_138_986[63:0]; // decl: <none>; prim: <none>
    assign limb_138_988 = limb_138_986[64]; // decl: <none>; prim: <none>
    assign limb_138_989 = __beopt_width_307[131:128]; // decl: <none>; prim: <none>
    assign limb_138_990 = tmp_workload_top_int_132__293_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_138_991 = (~limb_138_990); // decl: <none>; prim: <none>
    assign limb_138_992 = 5'((({1'h0, limb_138_989}) + ({1'h0, rtlzz_pipe_991_s6}) + ({4'h0, limb_138_988}))); // decl: <none>; prim: <none>
    assign limb_138_993 = limb_138_992[3:0]; // decl: <none>; prim: <none>
    assign limb_138_994 = {limb_138_993, limb_138_987, limb_138_981}; // decl: <none>; prim: <none>
    assign limb_140_995 = s8_norm_sub_215_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_996 = tmp_workload_top_int_132__296_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_997 = (~limb_140_996); // decl: <none>; prim: <none>
    assign limb_140_998 = 65'((({1'h0, limb_140_995}) + ({1'h0, rtlzz_pipe_997_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_140_999 = limb_140_998[63:0]; // decl: <none>; prim: <none>
    assign limb_140_1000 = limb_140_998[64]; // decl: <none>; prim: <none>
    assign limb_140_1001 = s8_norm_sub_215_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_1002 = tmp_workload_top_int_132__296_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_1003 = (~limb_140_1002); // decl: <none>; prim: <none>
    assign limb_140_1004 = 65'((({1'h0, limb_140_1001}) + ({1'h0, rtlzz_pipe_1003_s6}) + ({64'h0, limb_140_1000}))); // decl: <none>; prim: <none>
    assign limb_140_1005 = limb_140_1004[63:0]; // decl: <none>; prim: <none>
    assign limb_140_1006 = limb_140_1004[64]; // decl: <none>; prim: <none>
    assign limb_140_1007 = s8_norm_sub_215_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1008 = tmp_workload_top_int_132__296_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_1009 = (~limb_140_1008); // decl: <none>; prim: <none>
    assign limb_140_1010 = 5'((({1'h0, limb_140_1007}) + ({1'h0, rtlzz_pipe_1009_s6}) + ({4'h0, limb_140_1006}))); // decl: <none>; prim: <none>
    assign limb_140_1011 = limb_140_1010[3:0]; // decl: <none>; prim: <none>
    assign limb_140_1012 = {limb_140_1011, limb_140_1005, limb_140_999}; // decl: <none>; prim: <none>
    assign limb_147_1013 = __beopt_width_297[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1014 = tmp_workload_top_int_258__309_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1015 = (~limb_147_1014); // decl: <none>; prim: <none>
    assign limb_147_1016 = 65'((({1'h0, rtlzz_pipe_1013_s7}) + ({1'h0, limb_147_1015}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_147_1017 = limb_147_1016[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1018 = limb_147_1016[64]; // decl: <none>; prim: <none>
    assign limb_147_1019 = __beopt_width_297[127:64]; // decl: <none>; prim: <none>
    assign limb_147_1020 = tmp_workload_top_int_258__309_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_147_1021 = (~limb_147_1020); // decl: <none>; prim: <none>
    assign limb_147_1022 = 65'((({1'h0, rtlzz_pipe_1019_s7}) + ({1'h0, limb_147_1021}) + ({64'h0, limb_147_1018}))); // decl: <none>; prim: <none>
    assign limb_147_1023 = limb_147_1022[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1024 = limb_147_1022[64]; // decl: <none>; prim: <none>
    assign limb_147_1025 = __beopt_width_297[191:128]; // decl: <none>; prim: <none>
    assign limb_147_1026 = tmp_workload_top_int_258__309_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_147_1027 = (~limb_147_1026); // decl: <none>; prim: <none>
    assign limb_147_1028 = 65'((({1'h0, rtlzz_pipe_1025_s7}) + ({1'h0, limb_147_1027}) + ({64'h0, limb_147_1024}))); // decl: <none>; prim: <none>
    assign limb_147_1029 = limb_147_1028[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1030 = limb_147_1028[64]; // decl: <none>; prim: <none>
    assign limb_147_1031 = __beopt_width_297[255:192]; // decl: <none>; prim: <none>
    assign limb_147_1032 = tmp_workload_top_int_258__309_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_147_1033 = (~limb_147_1032); // decl: <none>; prim: <none>
    assign limb_147_1034 = 65'((({1'h0, rtlzz_pipe_1031_s7}) + ({1'h0, limb_147_1033}) + ({64'h0, limb_147_1030}))); // decl: <none>; prim: <none>
    assign limb_147_1035 = limb_147_1034[63:0]; // decl: <none>; prim: <none>
    assign limb_147_1036 = limb_147_1034[64]; // decl: <none>; prim: <none>
    assign limb_147_1037 = __beopt_width_297[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1038 = tmp_workload_top_int_258__309_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_147_1039 = (~limb_147_1038); // decl: <none>; prim: <none>
    assign limb_147_1040 = 3'((({1'h0, rtlzz_pipe_1037_s7}) + ({1'h0, limb_147_1039}) + ({2'h0, limb_147_1036}))); // decl: <none>; prim: <none>
    assign limb_147_1041 = limb_147_1040[1:0]; // decl: <none>; prim: <none>
    assign limb_147_1042 = {limb_147_1041, limb_147_1035, limb_147_1029, limb_147_1023, limb_147_1017}; // decl: <none>; prim: <none>
    assign limb_149_1043 = s8_norm_sub_226_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1044 = tmp_workload_top_int_258__312_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1045 = (~limb_149_1044); // decl: <none>; prim: <none>
    assign limb_149_1046 = 65'((({1'h0, limb_149_1043}) + ({1'h0, limb_149_1045}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_149_1047 = limb_149_1046[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1048 = limb_149_1046[64]; // decl: <none>; prim: <none>
    assign limb_149_1049 = s8_norm_sub_226_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_1050 = tmp_workload_top_int_258__312_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_1051 = (~limb_149_1050); // decl: <none>; prim: <none>
    assign limb_149_1052 = 65'((({1'h0, limb_149_1049}) + ({1'h0, limb_149_1051}) + ({64'h0, limb_149_1048}))); // decl: <none>; prim: <none>
    assign limb_149_1053 = limb_149_1052[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1054 = limb_149_1052[64]; // decl: <none>; prim: <none>
    assign limb_149_1055 = s8_norm_sub_226_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_1056 = tmp_workload_top_int_258__312_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_1057 = (~limb_149_1056); // decl: <none>; prim: <none>
    assign limb_149_1058 = 65'((({1'h0, limb_149_1055}) + ({1'h0, limb_149_1057}) + ({64'h0, limb_149_1054}))); // decl: <none>; prim: <none>
    assign limb_149_1059 = limb_149_1058[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1060 = limb_149_1058[64]; // decl: <none>; prim: <none>
    assign limb_149_1061 = s8_norm_sub_226_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_1062 = tmp_workload_top_int_258__312_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_1063 = (~limb_149_1062); // decl: <none>; prim: <none>
    assign limb_149_1064 = 65'((({1'h0, limb_149_1061}) + ({1'h0, limb_149_1063}) + ({64'h0, limb_149_1060}))); // decl: <none>; prim: <none>
    assign limb_149_1065 = limb_149_1064[63:0]; // decl: <none>; prim: <none>
    assign limb_149_1066 = limb_149_1064[64]; // decl: <none>; prim: <none>
    assign limb_149_1067 = s8_norm_sub_226_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1068 = tmp_workload_top_int_258__312_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_1069 = (~limb_149_1068); // decl: <none>; prim: <none>
    assign limb_149_1070 = 3'((({1'h0, limb_149_1067}) + ({1'h0, limb_149_1069}) + ({2'h0, limb_149_1066}))); // decl: <none>; prim: <none>
    assign limb_149_1071 = limb_149_1070[1:0]; // decl: <none>; prim: <none>
    assign limb_149_1072 = {limb_149_1071, limb_149_1065, limb_149_1059, limb_149_1053, limb_149_1047}; // decl: <none>; prim: <none>
    assign limb_157_1073 = tmp_workload_top_int_513__325_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1074 = tmp_workload_top_int_513__327_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1075 = 65'((({1'h0, limb_157_1073}) + ({1'h0, rtlzz_pipe_1074_s7}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_157_1076 = limb_157_1075[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1077 = limb_157_1075[64]; // decl: <none>; prim: <none>
    assign limb_157_1078 = tmp_workload_top_int_513__325_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_157_1079 = tmp_workload_top_int_513__327_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_157_1080 = 65'((({1'h0, limb_157_1078}) + ({1'h0, rtlzz_pipe_1079_s7}) + ({64'h0, limb_157_1077}))); // decl: <none>; prim: <none>
    assign limb_157_1081 = limb_157_1080[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1082 = limb_157_1080[64]; // decl: <none>; prim: <none>
    assign limb_157_1083 = tmp_workload_top_int_513__325_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_157_1084 = tmp_workload_top_int_513__327_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_157_1085 = 65'((({1'h0, limb_157_1083}) + ({1'h0, rtlzz_pipe_1084_s7}) + ({64'h0, limb_157_1082}))); // decl: <none>; prim: <none>
    assign limb_157_1086 = limb_157_1085[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1087 = limb_157_1085[64]; // decl: <none>; prim: <none>
    assign limb_157_1088 = tmp_workload_top_int_513__325_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_157_1089 = tmp_workload_top_int_513__327_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_157_1090 = 65'((({1'h0, limb_157_1088}) + ({1'h0, rtlzz_pipe_1089_s7}) + ({64'h0, limb_157_1087}))); // decl: <none>; prim: <none>
    assign limb_157_1091 = limb_157_1090[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1092 = limb_157_1090[64]; // decl: <none>; prim: <none>
    assign limb_157_1093 = tmp_workload_top_int_513__325_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_157_1094 = tmp_workload_top_int_513__327_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_157_1095 = 65'((({1'h0, limb_157_1093}) + ({1'h0, rtlzz_pipe_1094_s7}) + ({64'h0, limb_157_1092}))); // decl: <none>; prim: <none>
    assign limb_157_1096 = limb_157_1095[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1097 = limb_157_1095[64]; // decl: <none>; prim: <none>
    assign limb_157_1098 = tmp_workload_top_int_513__325_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_157_1099 = tmp_workload_top_int_513__327_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_157_1100 = 65'((({1'h0, limb_157_1098}) + ({1'h0, rtlzz_pipe_1099_s7}) + ({64'h0, limb_157_1097}))); // decl: <none>; prim: <none>
    assign limb_157_1101 = limb_157_1100[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1102 = limb_157_1100[64]; // decl: <none>; prim: <none>
    assign limb_157_1103 = tmp_workload_top_int_513__325_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_157_1104 = tmp_workload_top_int_513__327_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_157_1105 = 65'((({1'h0, limb_157_1103}) + ({1'h0, rtlzz_pipe_1104_s7}) + ({64'h0, limb_157_1102}))); // decl: <none>; prim: <none>
    assign limb_157_1106 = limb_157_1105[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1107 = limb_157_1105[64]; // decl: <none>; prim: <none>
    assign limb_157_1108 = tmp_workload_top_int_513__325_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_157_1109 = tmp_workload_top_int_513__327_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_157_1110 = 65'((({1'h0, limb_157_1108}) + ({1'h0, rtlzz_pipe_1109_s7}) + ({64'h0, limb_157_1107}))); // decl: <none>; prim: <none>
    assign limb_157_1111 = limb_157_1110[63:0]; // decl: <none>; prim: <none>
    assign limb_157_1112 = limb_157_1110[64]; // decl: <none>; prim: <none>
    assign limb_157_1113 = tmp_workload_top_int_513__325_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_1114 = tmp_workload_top_int_513__327_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_1115 = 2'((({1'h0, limb_157_1113}) + ({1'h0, rtlzz_pipe_1114_s7}) + ({1'h0, limb_157_1112}))); // decl: <none>; prim: <none>
    assign limb_157_1116 = limb_157_1115[0]; // decl: <none>; prim: <none>
    assign limb_157_1117 = {limb_157_1116, limb_157_1111, limb_157_1106, limb_157_1101, limb_157_1096, limb_157_1091, limb_157_1086, limb_157_1081, limb_157_1076}; // decl: <none>; prim: <none>
    assign limb_216_1118 = tmp_workload_top_int_512__315_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1119 = s8_norm_shift_234_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1120 = 65'((({1'h0, limb_216_1118}) + ({1'h0, limb_216_1119}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_216_1121 = limb_216_1120[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1122 = limb_216_1120[64]; // decl: <none>; prim: <none>
    assign limb_216_1123 = tmp_workload_top_int_512__315_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_216_1124 = s8_norm_shift_234_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_216_1125 = 65'((({1'h0, limb_216_1123}) + ({1'h0, limb_216_1124}) + ({64'h0, limb_216_1122}))); // decl: <none>; prim: <none>
    assign limb_216_1126 = limb_216_1125[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1127 = limb_216_1125[64]; // decl: <none>; prim: <none>
    assign limb_216_1128 = tmp_workload_top_int_512__315_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_216_1129 = s8_norm_shift_234_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_216_1130 = 65'((({1'h0, limb_216_1128}) + ({1'h0, limb_216_1129}) + ({64'h0, limb_216_1127}))); // decl: <none>; prim: <none>
    assign limb_216_1131 = limb_216_1130[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1132 = limb_216_1130[64]; // decl: <none>; prim: <none>
    assign limb_216_1133 = tmp_workload_top_int_512__315_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_216_1134 = s8_norm_shift_234_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_216_1135 = 65'((({1'h0, limb_216_1133}) + ({1'h0, limb_216_1134}) + ({64'h0, limb_216_1132}))); // decl: <none>; prim: <none>
    assign limb_216_1136 = limb_216_1135[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1137 = limb_216_1135[64]; // decl: <none>; prim: <none>
    assign limb_216_1138 = tmp_workload_top_int_512__315_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_216_1139 = s8_norm_shift_234_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_216_1140 = 65'((({1'h0, limb_216_1138}) + ({1'h0, limb_216_1139}) + ({64'h0, limb_216_1137}))); // decl: <none>; prim: <none>
    assign limb_216_1141 = limb_216_1140[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1142 = limb_216_1140[64]; // decl: <none>; prim: <none>
    assign limb_216_1143 = tmp_workload_top_int_512__315_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_216_1144 = s8_norm_shift_234_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_216_1145 = 65'((({1'h0, limb_216_1143}) + ({1'h0, limb_216_1144}) + ({64'h0, limb_216_1142}))); // decl: <none>; prim: <none>
    assign limb_216_1146 = limb_216_1145[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1147 = limb_216_1145[64]; // decl: <none>; prim: <none>
    assign limb_216_1148 = tmp_workload_top_int_512__315_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_216_1149 = s8_norm_shift_234_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_216_1150 = 65'((({1'h0, limb_216_1148}) + ({1'h0, limb_216_1149}) + ({64'h0, limb_216_1147}))); // decl: <none>; prim: <none>
    assign limb_216_1151 = limb_216_1150[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1152 = limb_216_1150[64]; // decl: <none>; prim: <none>
    assign limb_216_1153 = tmp_workload_top_int_512__315_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_216_1154 = s8_norm_shift_234_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_216_1155 = 65'((({1'h0, limb_216_1153}) + ({1'h0, limb_216_1154}) + ({64'h0, limb_216_1152}))); // decl: <none>; prim: <none>
    assign limb_216_1156 = limb_216_1155[63:0]; // decl: <none>; prim: <none>
    assign limb_216_1157 = {limb_216_1156, limb_216_1151, limb_216_1146, limb_216_1141, limb_216_1136, limb_216_1131, limb_216_1126, limb_216_1121}; // decl: <none>; prim: <none>
    assign limb_217_1158 = __beopt_width_292[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1159 = s8_norm_shift_231_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1160 = 65'((({1'h0, limb_217_1158}) + ({1'h0, limb_217_1159}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_217_1161 = limb_217_1160[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1162 = limb_217_1160[64]; // decl: <none>; prim: <none>
    assign limb_217_1163 = __beopt_width_292[127:64]; // decl: <none>; prim: <none>
    assign limb_217_1164 = s8_norm_shift_231_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_217_1165 = 65'((({1'h0, limb_217_1163}) + ({1'h0, limb_217_1164}) + ({64'h0, limb_217_1162}))); // decl: <none>; prim: <none>
    assign limb_217_1166 = limb_217_1165[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1167 = limb_217_1165[64]; // decl: <none>; prim: <none>
    assign limb_217_1168 = __beopt_width_292[191:128]; // decl: <none>; prim: <none>
    assign limb_217_1169 = s8_norm_shift_231_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_217_1170 = 65'((({1'h0, limb_217_1168}) + ({1'h0, limb_217_1169}) + ({64'h0, limb_217_1167}))); // decl: <none>; prim: <none>
    assign limb_217_1171 = limb_217_1170[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1172 = limb_217_1170[64]; // decl: <none>; prim: <none>
    assign limb_217_1173 = __beopt_width_292[255:192]; // decl: <none>; prim: <none>
    assign limb_217_1174 = s8_norm_shift_231_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_217_1175 = 65'((({1'h0, limb_217_1173}) + ({1'h0, limb_217_1174}) + ({64'h0, limb_217_1172}))); // decl: <none>; prim: <none>
    assign limb_217_1176 = limb_217_1175[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1177 = limb_217_1175[64]; // decl: <none>; prim: <none>
    assign limb_217_1178 = __beopt_width_292[319:256]; // decl: <none>; prim: <none>
    assign limb_217_1179 = s8_norm_shift_231_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_217_1180 = 65'((({1'h0, limb_217_1178}) + ({1'h0, limb_217_1179}) + ({64'h0, limb_217_1177}))); // decl: <none>; prim: <none>
    assign limb_217_1181 = limb_217_1180[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1182 = limb_217_1180[64]; // decl: <none>; prim: <none>
    assign limb_217_1183 = __beopt_width_292[383:320]; // decl: <none>; prim: <none>
    assign limb_217_1184 = s8_norm_shift_231_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_217_1185 = 65'((({1'h0, limb_217_1183}) + ({1'h0, limb_217_1184}) + ({64'h0, limb_217_1182}))); // decl: <none>; prim: <none>
    assign limb_217_1186 = limb_217_1185[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1187 = limb_217_1185[64]; // decl: <none>; prim: <none>
    assign limb_217_1188 = __beopt_width_292[447:384]; // decl: <none>; prim: <none>
    assign limb_217_1189 = s8_norm_shift_231_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_217_1190 = 65'((({1'h0, limb_217_1188}) + ({1'h0, limb_217_1189}) + ({64'h0, limb_217_1187}))); // decl: <none>; prim: <none>
    assign limb_217_1191 = limb_217_1190[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1192 = limb_217_1190[64]; // decl: <none>; prim: <none>
    assign limb_217_1193 = __beopt_width_292[511:448]; // decl: <none>; prim: <none>
    assign limb_217_1194 = s8_norm_shift_231_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_217_1195 = 65'((({1'h0, limb_217_1193}) + ({1'h0, limb_217_1194}) + ({64'h0, limb_217_1192}))); // decl: <none>; prim: <none>
    assign limb_217_1196 = limb_217_1195[63:0]; // decl: <none>; prim: <none>
    assign limb_217_1197 = {limb_217_1196, limb_217_1191, limb_217_1186, limb_217_1181, limb_217_1176, limb_217_1171, limb_217_1166, limb_217_1161}; // decl: <none>; prim: <none>
    assign limb_218_1198 = s8_norm_shift_223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1199 = tmp_workload_top_int_258__299_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1200 = 65'((({1'h0, limb_218_1198}) + ({1'h0, limb_218_1199}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_218_1201 = limb_218_1200[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1202 = limb_218_1200[64]; // decl: <none>; prim: <none>
    assign limb_218_1203 = s8_norm_shift_223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_218_1204 = tmp_workload_top_int_258__299_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_218_1205 = 65'((({1'h0, limb_218_1203}) + ({1'h0, limb_218_1204}) + ({64'h0, limb_218_1202}))); // decl: <none>; prim: <none>
    assign limb_218_1206 = limb_218_1205[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1207 = limb_218_1205[64]; // decl: <none>; prim: <none>
    assign limb_218_1208 = s8_norm_shift_223_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_218_1209 = tmp_workload_top_int_258__299_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_218_1210 = 65'((({1'h0, limb_218_1208}) + ({1'h0, limb_218_1209}) + ({64'h0, limb_218_1207}))); // decl: <none>; prim: <none>
    assign limb_218_1211 = limb_218_1210[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1212 = limb_218_1210[64]; // decl: <none>; prim: <none>
    assign limb_218_1213 = s8_norm_shift_223_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_218_1214 = tmp_workload_top_int_258__299_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_218_1215 = 65'((({1'h0, limb_218_1213}) + ({1'h0, limb_218_1214}) + ({64'h0, limb_218_1212}))); // decl: <none>; prim: <none>
    assign limb_218_1216 = limb_218_1215[63:0]; // decl: <none>; prim: <none>
    assign limb_218_1217 = limb_218_1215[64]; // decl: <none>; prim: <none>
    assign limb_218_1218 = s8_norm_shift_223_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_1219 = tmp_workload_top_int_258__299_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_1220 = 3'((({1'h0, limb_218_1218}) + ({1'h0, limb_218_1219}) + ({2'h0, limb_218_1217}))); // decl: <none>; prim: <none>
    assign limb_218_1221 = limb_218_1220[1:0]; // decl: <none>; prim: <none>
    assign limb_218_1222 = {limb_218_1221, limb_218_1216, limb_218_1211, limb_218_1206, limb_218_1201}; // decl: <none>; prim: <none>
    assign limb_219_1223 = __beopt_width_295[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1224 = s8_norm_shift_220_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1225 = 65'((({1'h0, rtlzz_pipe_1223_s6}) + ({1'h0, limb_219_1224}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_219_1226 = limb_219_1225[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1227 = limb_219_1225[64]; // decl: <none>; prim: <none>
    assign limb_219_1228 = __beopt_width_295[127:64]; // decl: <none>; prim: <none>
    assign limb_219_1229 = s8_norm_shift_220_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_219_1230 = 65'((({1'h0, rtlzz_pipe_1228_s6}) + ({1'h0, limb_219_1229}) + ({64'h0, limb_219_1227}))); // decl: <none>; prim: <none>
    assign limb_219_1231 = limb_219_1230[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1232 = limb_219_1230[64]; // decl: <none>; prim: <none>
    assign limb_219_1233 = __beopt_width_295[191:128]; // decl: <none>; prim: <none>
    assign limb_219_1234 = s8_norm_shift_220_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_219_1235 = 65'((({1'h0, rtlzz_pipe_1233_s6}) + ({1'h0, limb_219_1234}) + ({64'h0, limb_219_1232}))); // decl: <none>; prim: <none>
    assign limb_219_1236 = limb_219_1235[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1237 = limb_219_1235[64]; // decl: <none>; prim: <none>
    assign limb_219_1238 = __beopt_width_295[255:192]; // decl: <none>; prim: <none>
    assign limb_219_1239 = s8_norm_shift_220_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_219_1240 = 65'((({1'h0, rtlzz_pipe_1238_s6}) + ({1'h0, limb_219_1239}) + ({64'h0, limb_219_1237}))); // decl: <none>; prim: <none>
    assign limb_219_1241 = limb_219_1240[63:0]; // decl: <none>; prim: <none>
    assign limb_219_1242 = limb_219_1240[64]; // decl: <none>; prim: <none>
    assign limb_219_1243 = __beopt_width_295[257:256]; // decl: <none>; prim: <none>
    assign limb_219_1244 = s8_norm_shift_220_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_219_1245 = 3'((({1'h0, rtlzz_pipe_1243_s6}) + ({1'h0, limb_219_1244}) + ({2'h0, limb_219_1242}))); // decl: <none>; prim: <none>
    assign limb_219_1246 = limb_219_1245[1:0]; // decl: <none>; prim: <none>
    assign limb_219_1247 = {limb_219_1246, limb_219_1241, limb_219_1236, limb_219_1231, limb_219_1226}; // decl: <none>; prim: <none>
    assign limb_220_1248 = tmp_workload_top_int_256__164_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1249 = s8_norm_shift_126_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1250 = 65'((({1'h0, limb_220_1248}) + ({1'h0, limb_220_1249}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_220_1251 = limb_220_1250[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1252 = limb_220_1250[64]; // decl: <none>; prim: <none>
    assign limb_220_1253 = tmp_workload_top_int_256__164_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_220_1254 = s8_norm_shift_126_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_220_1255 = 65'((({1'h0, limb_220_1253}) + ({1'h0, limb_220_1254}) + ({64'h0, limb_220_1252}))); // decl: <none>; prim: <none>
    assign limb_220_1256 = limb_220_1255[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1257 = limb_220_1255[64]; // decl: <none>; prim: <none>
    assign limb_220_1258 = tmp_workload_top_int_256__164_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_220_1259 = s8_norm_shift_126_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_220_1260 = 65'((({1'h0, limb_220_1258}) + ({1'h0, limb_220_1259}) + ({64'h0, limb_220_1257}))); // decl: <none>; prim: <none>
    assign limb_220_1261 = limb_220_1260[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1262 = limb_220_1260[64]; // decl: <none>; prim: <none>
    assign limb_220_1263 = tmp_workload_top_int_256__164_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_220_1264 = s8_norm_shift_126_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_220_1265 = 65'((({1'h0, limb_220_1263}) + ({1'h0, limb_220_1264}) + ({64'h0, limb_220_1262}))); // decl: <none>; prim: <none>
    assign limb_220_1266 = limb_220_1265[63:0]; // decl: <none>; prim: <none>
    assign limb_220_1267 = {limb_220_1266, limb_220_1261, limb_220_1256, limb_220_1251}; // decl: <none>; prim: <none>
    assign limb_221_1268 = __beopt_width_299[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1269 = s8_norm_shift_123_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1270 = 65'((({1'h0, limb_221_1268}) + ({1'h0, limb_221_1269}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_221_1271 = limb_221_1270[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1272 = limb_221_1270[64]; // decl: <none>; prim: <none>
    assign limb_221_1273 = __beopt_width_299[127:64]; // decl: <none>; prim: <none>
    assign limb_221_1274 = s8_norm_shift_123_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_221_1275 = 65'((({1'h0, limb_221_1273}) + ({1'h0, limb_221_1274}) + ({64'h0, limb_221_1272}))); // decl: <none>; prim: <none>
    assign limb_221_1276 = limb_221_1275[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1277 = limb_221_1275[64]; // decl: <none>; prim: <none>
    assign limb_221_1278 = __beopt_width_299[191:128]; // decl: <none>; prim: <none>
    assign limb_221_1279 = s8_norm_shift_123_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_221_1280 = 65'((({1'h0, limb_221_1278}) + ({1'h0, limb_221_1279}) + ({64'h0, limb_221_1277}))); // decl: <none>; prim: <none>
    assign limb_221_1281 = limb_221_1280[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1282 = limb_221_1280[64]; // decl: <none>; prim: <none>
    assign limb_221_1283 = __beopt_width_299[255:192]; // decl: <none>; prim: <none>
    assign limb_221_1284 = s8_norm_shift_123_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_221_1285 = 65'((({1'h0, limb_221_1283}) + ({1'h0, limb_221_1284}) + ({64'h0, limb_221_1282}))); // decl: <none>; prim: <none>
    assign limb_221_1286 = limb_221_1285[63:0]; // decl: <none>; prim: <none>
    assign limb_221_1287 = {limb_221_1286, limb_221_1281, limb_221_1276, limb_221_1271}; // decl: <none>; prim: <none>
    assign limb_222_1288 = tmp_workload_top_int_256__79_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1289 = s8_norm_shift_64_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1290 = 65'((({1'h0, limb_222_1288}) + ({1'h0, limb_222_1289}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_222_1291 = limb_222_1290[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1292 = limb_222_1290[64]; // decl: <none>; prim: <none>
    assign limb_222_1293 = tmp_workload_top_int_256__79_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_222_1294 = s8_norm_shift_64_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_222_1295 = 65'((({1'h0, limb_222_1293}) + ({1'h0, limb_222_1294}) + ({64'h0, limb_222_1292}))); // decl: <none>; prim: <none>
    assign limb_222_1296 = limb_222_1295[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1297 = limb_222_1295[64]; // decl: <none>; prim: <none>
    assign limb_222_1298 = tmp_workload_top_int_256__79_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_222_1299 = s8_norm_shift_64_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_222_1300 = 65'((({1'h0, limb_222_1298}) + ({1'h0, limb_222_1299}) + ({64'h0, limb_222_1297}))); // decl: <none>; prim: <none>
    assign limb_222_1301 = limb_222_1300[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1302 = limb_222_1300[64]; // decl: <none>; prim: <none>
    assign limb_222_1303 = tmp_workload_top_int_256__79_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_222_1304 = s8_norm_shift_64_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_222_1305 = 65'((({1'h0, limb_222_1303}) + ({1'h0, limb_222_1304}) + ({64'h0, limb_222_1302}))); // decl: <none>; prim: <none>
    assign limb_222_1306 = limb_222_1305[63:0]; // decl: <none>; prim: <none>
    assign limb_222_1307 = {limb_222_1306, limb_222_1301, limb_222_1296, limb_222_1291}; // decl: <none>; prim: <none>
    assign limb_223_1308 = __beopt_width_302[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1309 = s8_norm_shift_61_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1310 = 65'((({1'h0, limb_223_1308}) + ({1'h0, limb_223_1309}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_223_1311 = limb_223_1310[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1312 = limb_223_1310[64]; // decl: <none>; prim: <none>
    assign limb_223_1313 = __beopt_width_302[127:64]; // decl: <none>; prim: <none>
    assign limb_223_1314 = s8_norm_shift_61_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_223_1315 = 65'((({1'h0, limb_223_1313}) + ({1'h0, limb_223_1314}) + ({64'h0, limb_223_1312}))); // decl: <none>; prim: <none>
    assign limb_223_1316 = limb_223_1315[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1317 = limb_223_1315[64]; // decl: <none>; prim: <none>
    assign limb_223_1318 = __beopt_width_302[191:128]; // decl: <none>; prim: <none>
    assign limb_223_1319 = s8_norm_shift_61_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_223_1320 = 65'((({1'h0, limb_223_1318}) + ({1'h0, limb_223_1319}) + ({64'h0, limb_223_1317}))); // decl: <none>; prim: <none>
    assign limb_223_1321 = limb_223_1320[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1322 = limb_223_1320[64]; // decl: <none>; prim: <none>
    assign limb_223_1323 = __beopt_width_302[255:192]; // decl: <none>; prim: <none>
    assign limb_223_1324 = s8_norm_shift_61_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_223_1325 = 65'((({1'h0, limb_223_1323}) + ({1'h0, limb_223_1324}) + ({64'h0, limb_223_1322}))); // decl: <none>; prim: <none>
    assign limb_223_1326 = limb_223_1325[63:0]; // decl: <none>; prim: <none>
    assign limb_223_1327 = {limb_223_1326, limb_223_1321, limb_223_1316, limb_223_1311}; // decl: <none>; prim: <none>
    assign limb_224_1328 = tmp_workload_top_int_132__283_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1329 = s8_norm_shift_212_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1330 = 65'((({1'h0, rtlzz_pipe_1328_s6}) + ({1'h0, limb_224_1329}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_224_1331 = limb_224_1330[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1332 = limb_224_1330[64]; // decl: <none>; prim: <none>
    assign limb_224_1333 = tmp_workload_top_int_132__283_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_224_1334 = s8_norm_shift_212_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_224_1335 = 65'((({1'h0, rtlzz_pipe_1333_s6}) + ({1'h0, limb_224_1334}) + ({64'h0, limb_224_1332}))); // decl: <none>; prim: <none>
    assign limb_224_1336 = limb_224_1335[63:0]; // decl: <none>; prim: <none>
    assign limb_224_1337 = limb_224_1335[64]; // decl: <none>; prim: <none>
    assign limb_224_1338 = tmp_workload_top_int_132__283_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_1339 = s8_norm_shift_212_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_1340 = 5'((({1'h0, rtlzz_pipe_1338_s6}) + ({1'h0, limb_224_1339}) + ({4'h0, limb_224_1337}))); // decl: <none>; prim: <none>
    assign limb_224_1341 = limb_224_1340[3:0]; // decl: <none>; prim: <none>
    assign limb_224_1342 = {limb_224_1341, limb_224_1336, limb_224_1331}; // decl: <none>; prim: <none>
    assign limb_225_1343 = __beopt_width_305[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1344 = s8_norm_shift_209_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1345 = 65'((({1'h0, limb_225_1343}) + ({1'h0, limb_225_1344}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_225_1346 = limb_225_1345[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1347 = limb_225_1345[64]; // decl: <none>; prim: <none>
    assign limb_225_1348 = __beopt_width_305[127:64]; // decl: <none>; prim: <none>
    assign limb_225_1349 = s8_norm_shift_209_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_225_1350 = 65'((({1'h0, limb_225_1348}) + ({1'h0, limb_225_1349}) + ({64'h0, limb_225_1347}))); // decl: <none>; prim: <none>
    assign limb_225_1351 = limb_225_1350[63:0]; // decl: <none>; prim: <none>
    assign limb_225_1352 = limb_225_1350[64]; // decl: <none>; prim: <none>
    assign limb_225_1353 = __beopt_width_305[131:128]; // decl: <none>; prim: <none>
    assign limb_225_1354 = s8_norm_shift_209_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_225_1355 = 5'((({1'h0, limb_225_1353}) + ({1'h0, limb_225_1354}) + ({4'h0, limb_225_1352}))); // decl: <none>; prim: <none>
    assign limb_225_1356 = limb_225_1355[3:0]; // decl: <none>; prim: <none>
    assign limb_225_1357 = {limb_225_1356, limb_225_1351, limb_225_1346}; // decl: <none>; prim: <none>
    assign limb_226_1358 = tmp_workload_top_int_130__223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1359 = s8_norm_shift_169_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1360 = 65'((({1'h0, rtlzz_pipe_1358_s5}) + ({1'h0, limb_226_1359}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_226_1361 = limb_226_1360[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1362 = limb_226_1360[64]; // decl: <none>; prim: <none>
    assign limb_226_1363 = tmp_workload_top_int_130__223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_226_1364 = s8_norm_shift_169_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_226_1365 = 65'((({1'h0, rtlzz_pipe_1363_s5}) + ({1'h0, limb_226_1364}) + ({64'h0, limb_226_1362}))); // decl: <none>; prim: <none>
    assign limb_226_1366 = limb_226_1365[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1367 = limb_226_1365[64]; // decl: <none>; prim: <none>
    assign limb_226_1368 = tmp_workload_top_int_130__223_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1369 = s8_norm_shift_169_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1370 = 3'((({1'h0, rtlzz_pipe_1368_s5}) + ({1'h0, limb_226_1369}) + ({2'h0, limb_226_1367}))); // decl: <none>; prim: <none>
    assign limb_226_1371 = limb_226_1370[1:0]; // decl: <none>; prim: <none>
    assign limb_226_1372 = {limb_226_1371, limb_226_1366, limb_226_1361}; // decl: <none>; prim: <none>
    assign limb_227_1373 = __beopt_width_309[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1374 = s8_norm_shift_166_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1375 = 65'((({1'h0, limb_227_1373}) + ({1'h0, limb_227_1374}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_227_1376 = limb_227_1375[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1377 = limb_227_1375[64]; // decl: <none>; prim: <none>
    assign limb_227_1378 = __beopt_width_309[127:64]; // decl: <none>; prim: <none>
    assign limb_227_1379 = s8_norm_shift_166_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_227_1380 = 65'((({1'h0, limb_227_1378}) + ({1'h0, limb_227_1379}) + ({64'h0, limb_227_1377}))); // decl: <none>; prim: <none>
    assign limb_227_1381 = limb_227_1380[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1382 = limb_227_1380[64]; // decl: <none>; prim: <none>
    assign limb_227_1383 = __beopt_width_309[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1384 = s8_norm_shift_166_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1385 = 3'((({1'h0, limb_227_1383}) + ({1'h0, limb_227_1384}) + ({2'h0, limb_227_1382}))); // decl: <none>; prim: <none>
    assign limb_227_1386 = limb_227_1385[1:0]; // decl: <none>; prim: <none>
    assign limb_227_1387 = {limb_227_1386, limb_227_1381, limb_227_1376}; // decl: <none>; prim: <none>
    assign limb_228_1388 = tmp_workload_top_int_130__148_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1389 = s8_norm_shift_115_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1390 = 65'((({1'h0, limb_228_1388}) + ({1'h0, limb_228_1389}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_228_1391 = limb_228_1390[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1392 = limb_228_1390[64]; // decl: <none>; prim: <none>
    assign limb_228_1393 = tmp_workload_top_int_130__148_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_228_1394 = s8_norm_shift_115_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_228_1395 = 65'((({1'h0, limb_228_1393}) + ({1'h0, limb_228_1394}) + ({64'h0, limb_228_1392}))); // decl: <none>; prim: <none>
    assign limb_228_1396 = limb_228_1395[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1397 = limb_228_1395[64]; // decl: <none>; prim: <none>
    assign limb_228_1398 = tmp_workload_top_int_130__148_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1399 = s8_norm_shift_115_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1400 = 3'((({1'h0, limb_228_1398}) + ({1'h0, limb_228_1399}) + ({2'h0, limb_228_1397}))); // decl: <none>; prim: <none>
    assign limb_228_1401 = limb_228_1400[1:0]; // decl: <none>; prim: <none>
    assign limb_228_1402 = {limb_228_1401, limb_228_1396, limb_228_1391}; // decl: <none>; prim: <none>
    assign limb_229_1403 = __beopt_width_311[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1404 = s8_norm_shift_112_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1405 = 65'((({1'h0, limb_229_1403}) + ({1'h0, limb_229_1404}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_229_1406 = limb_229_1405[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1407 = limb_229_1405[64]; // decl: <none>; prim: <none>
    assign limb_229_1408 = __beopt_width_311[127:64]; // decl: <none>; prim: <none>
    assign limb_229_1409 = s8_norm_shift_112_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_229_1410 = 65'((({1'h0, limb_229_1408}) + ({1'h0, limb_229_1409}) + ({64'h0, limb_229_1407}))); // decl: <none>; prim: <none>
    assign limb_229_1411 = limb_229_1410[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1412 = limb_229_1410[64]; // decl: <none>; prim: <none>
    assign limb_229_1413 = __beopt_width_311[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1414 = s8_norm_shift_112_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1415 = 3'((({1'h0, limb_229_1413}) + ({1'h0, limb_229_1414}) + ({2'h0, limb_229_1412}))); // decl: <none>; prim: <none>
    assign limb_229_1416 = limb_229_1415[1:0]; // decl: <none>; prim: <none>
    assign limb_229_1417 = {limb_229_1416, limb_229_1411, limb_229_1406}; // decl: <none>; prim: <none>
    assign limb_230_1418 = tmp_workload_top_int_130__63_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1419 = s8_norm_shift_53_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1420 = 65'((({1'h0, limb_230_1418}) + ({1'h0, limb_230_1419}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_230_1421 = limb_230_1420[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1422 = limb_230_1420[64]; // decl: <none>; prim: <none>
    assign limb_230_1423 = tmp_workload_top_int_130__63_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_230_1424 = s8_norm_shift_53_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_230_1425 = 65'((({1'h0, limb_230_1423}) + ({1'h0, limb_230_1424}) + ({64'h0, limb_230_1422}))); // decl: <none>; prim: <none>
    assign limb_230_1426 = limb_230_1425[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1427 = limb_230_1425[64]; // decl: <none>; prim: <none>
    assign limb_230_1428 = tmp_workload_top_int_130__63_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1429 = s8_norm_shift_53_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1430 = 3'((({1'h0, limb_230_1428}) + ({1'h0, limb_230_1429}) + ({2'h0, limb_230_1427}))); // decl: <none>; prim: <none>
    assign limb_230_1431 = limb_230_1430[1:0]; // decl: <none>; prim: <none>
    assign limb_230_1432 = {limb_230_1431, limb_230_1426, limb_230_1421}; // decl: <none>; prim: <none>
    assign limb_231_1433 = __beopt_width_315[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1434 = s8_norm_shift_50_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1435 = 65'((({1'h0, limb_231_1433}) + ({1'h0, limb_231_1434}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_231_1436 = limb_231_1435[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1437 = limb_231_1435[64]; // decl: <none>; prim: <none>
    assign limb_231_1438 = __beopt_width_315[127:64]; // decl: <none>; prim: <none>
    assign limb_231_1439 = s8_norm_shift_50_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_231_1440 = 65'((({1'h0, limb_231_1438}) + ({1'h0, limb_231_1439}) + ({64'h0, limb_231_1437}))); // decl: <none>; prim: <none>
    assign limb_231_1441 = limb_231_1440[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1442 = limb_231_1440[64]; // decl: <none>; prim: <none>
    assign limb_231_1443 = __beopt_width_315[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1444 = s8_norm_shift_50_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1445 = 3'((({1'h0, limb_231_1443}) + ({1'h0, limb_231_1444}) + ({2'h0, limb_231_1442}))); // decl: <none>; prim: <none>
    assign limb_231_1446 = limb_231_1445[1:0]; // decl: <none>; prim: <none>
    assign limb_231_1447 = {limb_231_1446, limb_231_1441, limb_231_1436}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_265_s1 <= 65'h0;
            rtlzz_pipe_265_s2 <= 65'h0;
            rtlzz_pipe_265_s3 <= 65'h0;
            rtlzz_pipe_265_s4 <= 65'h0;
            rtlzz_pipe_265_s5 <= 65'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_270_s2 <= 128'h0;
            rtlzz_pipe_270_s3 <= 128'h0;
            rtlzz_pipe_270_s4 <= 128'h0;
            rtlzz_pipe_270_s5 <= 128'h0;
            rtlzz_pipe_270_s6 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_271_s3 <= 128'h0;
            rtlzz_pipe_271_s4 <= 128'h0;
            rtlzz_pipe_271_s5 <= 128'h0;
            rtlzz_pipe_271_s6 <= 128'h0;
            rtlzz_pipe_271_s7 <= 128'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_278_s1 <= 129'h0;
            rtlzz_pipe_278_s2 <= 129'h0;
            rtlzz_pipe_279_s1 <= 129'h0;
            rtlzz_pipe_279_s2 <= 129'h0;
            rtlzz_pipe_279_s3 <= 129'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_292_s3 <= 64'h0;
            rtlzz_pipe_292_s4 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_293_s3 <= 64'h0;
            rtlzz_pipe_293_s4 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_310_s7 <= 64'h0;
            rtlzz_pipe_362_s5 <= 64'h0;
            rtlzz_pipe_366_s5 <= 96'h0;
            rtlzz_pipe_370_s5 <= 96'h0;
            rtlzz_pipe_374_s5 <= 128'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_10_s7 <= 256'h0;
            rtlzz_pipe_174_s6 <= 130'h0;
            rtlzz_pipe_387_s4 <= 64'h0;
            rtlzz_pipe_391_s4 <= 96'h0;
            rtlzz_pipe_395_s4 <= 96'h0;
            rtlzz_pipe_399_s4 <= 128'h0;
            rtlzz_pipe_11_s5 <= 256'h0;
            rtlzz_pipe_11_s6 <= 256'h0;
            rtlzz_pipe_11_s7 <= 256'h0;
            rtlzz_pipe_175_s5 <= 130'h0;
            rtlzz_pipe_175_s6 <= 130'h0;
            rtlzz_pipe_465_s6 <= 64'h0;
            rtlzz_pipe_469_s6 <= 96'h0;
            rtlzz_pipe_473_s6 <= 96'h0;
            rtlzz_pipe_477_s6 <= 128'h0;
            rtlzz_pipe_48_s7 <= 256'h0;
            rtlzz_pipe_719_s3 <= 64'h0;
            rtlzz_pipe_719_s4 <= 64'h0;
            rtlzz_pipe_724_s3 <= 1'h0;
            rtlzz_pipe_724_s4 <= 1'h0;
            rtlzz_pipe_168_s5 <= 34'h0;
            rtlzz_pipe_20_s6 <= 34'h0;
            rtlzz_pipe_266_s5 <= 64'h0;
            rtlzz_pipe_268_s5 <= 34'h0;
            rtlzz_pipe_268_s6 <= 34'h0;
            rtlzz_pipe_298_s5 <= 33'h0;
            rtlzz_pipe_729_s5 <= 64'h0;
            rtlzz_pipe_734_s5 <= 1'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_269_s6 <= 34'h0;
            rtlzz_pipe_427_s6 <= 66'h0;
            rtlzz_pipe_430_s6 <= 67'h0;
            rtlzz_pipe_172_s7 <= 130'h0;
            rtlzz_pipe_173_s6 <= 130'h0;
            rtlzz_pipe_173_s7 <= 130'h0;
            rtlzz_pipe_739_s7 <= 64'h0;
            rtlzz_pipe_740_s7 <= 64'h0;
            rtlzz_pipe_745_s7 <= 4'h0;
            rtlzz_pipe_747_s7 <= 4'hf;
            rtlzz_pipe_753_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_753_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_759_s6 <= 4'hf;
            rtlzz_pipe_759_s7 <= 4'hf;
            rtlzz_pipe_765_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_771_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_777_s7 <= 2'h3;
            rtlzz_pipe_783_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_788_s7 <= 64'h0;
            rtlzz_pipe_794_s7 <= 2'h0;
            rtlzz_pipe_800_s1 <= 64'h0;
            rtlzz_pipe_800_s2 <= 64'h0;
            rtlzz_pipe_800_s3 <= 64'h0;
            rtlzz_pipe_800_s4 <= 64'h0;
            rtlzz_pipe_800_s5 <= 64'h0;
            rtlzz_pipe_800_s6 <= 64'h0;
            rtlzz_pipe_805_s1 <= 1'h0;
            rtlzz_pipe_805_s2 <= 1'h0;
            rtlzz_pipe_805_s3 <= 1'h0;
            rtlzz_pipe_805_s4 <= 1'h0;
            rtlzz_pipe_805_s5 <= 1'h0;
            rtlzz_pipe_805_s6 <= 1'h0;
            rtlzz_pipe_184_s7 <= 34'h0;
            rtlzz_pipe_274_s7 <= 64'h0;
            rtlzz_pipe_246_s7 <= 34'h0;
            rtlzz_pipe_313_s7 <= 33'h0;
            rtlzz_pipe_810_s2 <= 64'h0;
            rtlzz_pipe_810_s3 <= 64'h0;
            rtlzz_pipe_810_s4 <= 64'h0;
            rtlzz_pipe_810_s5 <= 64'h0;
            rtlzz_pipe_810_s6 <= 64'h0;
            rtlzz_pipe_810_s7 <= 64'h0;
            rtlzz_pipe_815_s2 <= 1'h0;
            rtlzz_pipe_815_s3 <= 1'h0;
            rtlzz_pipe_815_s4 <= 1'h0;
            rtlzz_pipe_815_s5 <= 1'h0;
            rtlzz_pipe_815_s6 <= 1'h0;
            rtlzz_pipe_815_s7 <= 1'h0;
            rtlzz_pipe_845_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_851_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_857_s7 <= 2'h3;
            rtlzz_pipe_879_s1 <= 64'h0;
            rtlzz_pipe_879_s2 <= 64'h0;
            rtlzz_pipe_884_s1 <= 64'h0;
            rtlzz_pipe_884_s2 <= 64'h0;
            rtlzz_pipe_889_s1 <= 1'h0;
            rtlzz_pipe_889_s2 <= 1'h0;
            rtlzz_pipe_198_s3 <= 34'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_286_s3 <= 66'h0;
            rtlzz_pipe_286_s4 <= 66'h0;
            rtlzz_pipe_322_s3 <= 33'h0;
            rtlzz_pipe_325_s4 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_331_s3 <= 64'h0;
            rtlzz_pipe_894_s2 <= 64'h0;
            rtlzz_pipe_894_s3 <= 64'h0;
            rtlzz_pipe_899_s2 <= 64'h0;
            rtlzz_pipe_899_s3 <= 64'h0;
            rtlzz_pipe_904_s2 <= 1'h0;
            rtlzz_pipe_904_s3 <= 1'h0;
            rtlzz_pipe_199_s4 <= 34'h0;
            rtlzz_pipe_281_s4 <= 64'h0;
            rtlzz_pipe_283_s4 <= 34'h0;
            rtlzz_pipe_287_s4 <= 66'h0;
            rtlzz_pipe_200_s4 <= 68'h0;
            rtlzz_pipe_203_s5 <= 130'h0;
            rtlzz_pipe_214_s4 <= 132'h0;
            rtlzz_pipe_214_s5 <= 132'h0;
            rtlzz_pipe_144_s4 <= 258'h0;
            rtlzz_pipe_144_s5 <= 258'h0;
            rtlzz_pipe_921_s5 <= 64'h0;
            rtlzz_pipe_922_s5 <= 64'h0;
            rtlzz_pipe_927_s5 <= 4'h0;
            rtlzz_pipe_928_s5 <= 4'h0;
            rtlzz_pipe_933_s3 <= 64'h0;
            rtlzz_pipe_933_s4 <= 64'h0;
            rtlzz_pipe_938_s3 <= 2'h0;
            rtlzz_pipe_938_s4 <= 2'h0;
            rtlzz_pipe_120_s5 <= 34'h0;
            rtlzz_pipe_288_s5 <= 66'h0;
            rtlzz_pipe_290_s5 <= 34'h0;
            rtlzz_pipe_334_s5 <= 33'h0;
            rtlzz_pipe_337_s6 <= 33'h0;
            rtlzz_pipe_340_s6 <= 34'h0;
            rtlzz_pipe_943_s4 <= 64'h0;
            rtlzz_pipe_948_s4 <= 2'h0;
            rtlzz_pipe_115_s5 <= 66'h0;
            rtlzz_pipe_122_s5 <= 34'h0;
            rtlzz_pipe_122_s6 <= 34'h0;
            rtlzz_pipe_289_s5 <= 66'h0;
            rtlzz_pipe_289_s6 <= 66'h0;
            rtlzz_pipe_291_s5 <= 34'h0;
            rtlzz_pipe_291_s6 <= 34'h0;
            rtlzz_pipe_955_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_961_s6 <= 4'hf;
            rtlzz_pipe_997_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_1003_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_1009_s6 <= 4'hf;
            rtlzz_pipe_1074_s1 <= 64'h0;
            rtlzz_pipe_1074_s2 <= 64'h0;
            rtlzz_pipe_1074_s3 <= 64'h0;
            rtlzz_pipe_1074_s4 <= 64'h0;
            rtlzz_pipe_1074_s5 <= 64'h0;
            rtlzz_pipe_1074_s6 <= 64'h0;
            rtlzz_pipe_1074_s7 <= 64'h0;
            rtlzz_pipe_1079_s1 <= 64'h0;
            rtlzz_pipe_1079_s2 <= 64'h0;
            rtlzz_pipe_1079_s3 <= 64'h0;
            rtlzz_pipe_1079_s4 <= 64'h0;
            rtlzz_pipe_1079_s5 <= 64'h0;
            rtlzz_pipe_1079_s6 <= 64'h0;
            rtlzz_pipe_1079_s7 <= 64'h0;
            rtlzz_pipe_1084_s1 <= 64'h0;
            rtlzz_pipe_1084_s2 <= 64'h0;
            rtlzz_pipe_1084_s3 <= 64'h0;
            rtlzz_pipe_1084_s4 <= 64'h0;
            rtlzz_pipe_1084_s5 <= 64'h0;
            rtlzz_pipe_1084_s6 <= 64'h0;
            rtlzz_pipe_1084_s7 <= 64'h0;
            rtlzz_pipe_1089_s1 <= 64'h0;
            rtlzz_pipe_1089_s2 <= 64'h0;
            rtlzz_pipe_1089_s3 <= 64'h0;
            rtlzz_pipe_1089_s4 <= 64'h0;
            rtlzz_pipe_1089_s5 <= 64'h0;
            rtlzz_pipe_1089_s6 <= 64'h0;
            rtlzz_pipe_1089_s7 <= 64'h0;
            rtlzz_pipe_1094_s1 <= 64'h0;
            rtlzz_pipe_1094_s2 <= 64'h0;
            rtlzz_pipe_1094_s3 <= 64'h0;
            rtlzz_pipe_1094_s4 <= 64'h0;
            rtlzz_pipe_1094_s5 <= 64'h0;
            rtlzz_pipe_1094_s6 <= 64'h0;
            rtlzz_pipe_1094_s7 <= 64'h0;
            rtlzz_pipe_1099_s1 <= 64'h0;
            rtlzz_pipe_1099_s2 <= 64'h0;
            rtlzz_pipe_1099_s3 <= 64'h0;
            rtlzz_pipe_1099_s4 <= 64'h0;
            rtlzz_pipe_1099_s5 <= 64'h0;
            rtlzz_pipe_1099_s6 <= 64'h0;
            rtlzz_pipe_1099_s7 <= 64'h0;
            rtlzz_pipe_1104_s1 <= 64'h0;
            rtlzz_pipe_1104_s2 <= 64'h0;
            rtlzz_pipe_1104_s3 <= 64'h0;
            rtlzz_pipe_1104_s4 <= 64'h0;
            rtlzz_pipe_1104_s5 <= 64'h0;
            rtlzz_pipe_1104_s6 <= 64'h0;
            rtlzz_pipe_1104_s7 <= 64'h0;
            rtlzz_pipe_1109_s1 <= 64'h0;
            rtlzz_pipe_1109_s2 <= 64'h0;
            rtlzz_pipe_1109_s3 <= 64'h0;
            rtlzz_pipe_1109_s4 <= 64'h0;
            rtlzz_pipe_1109_s5 <= 64'h0;
            rtlzz_pipe_1109_s6 <= 64'h0;
            rtlzz_pipe_1109_s7 <= 64'h0;
            rtlzz_pipe_1114_s1 <= 1'h0;
            rtlzz_pipe_1114_s2 <= 1'h0;
            rtlzz_pipe_1114_s3 <= 1'h0;
            rtlzz_pipe_1114_s4 <= 1'h0;
            rtlzz_pipe_1114_s5 <= 1'h0;
            rtlzz_pipe_1114_s6 <= 1'h0;
            rtlzz_pipe_1114_s7 <= 1'h0;
            rtlzz_pipe_1328_s6 <= 64'h0;
            rtlzz_pipe_1333_s6 <= 64'h0;
            rtlzz_pipe_1338_s6 <= 4'h0;
            rtlzz_pipe_1358_s4 <= 64'h0;
            rtlzz_pipe_1358_s5 <= 64'h0;
            rtlzz_pipe_1363_s4 <= 64'h0;
            rtlzz_pipe_1363_s5 <= 64'h0;
            rtlzz_pipe_1368_s4 <= 2'h0;
            rtlzz_pipe_1368_s5 <= 2'h0;
            rtlzz_pipe_979_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_985_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_991_s6 <= 4'hf;
            rtlzz_pipe_1223_s6 <= 64'h0;
            rtlzz_pipe_1228_s6 <= 64'h0;
            rtlzz_pipe_1233_s6 <= 64'h0;
            rtlzz_pipe_1238_s6 <= 64'h0;
            rtlzz_pipe_1243_s6 <= 2'h0;
            rtlzz_pipe_1013_s7 <= 64'h0;
            rtlzz_pipe_1019_s7 <= 64'h0;
            rtlzz_pipe_1025_s7 <= 64'h0;
            rtlzz_pipe_1031_s7 <= 64'h0;
            rtlzz_pipe_1037_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= __beopt_width_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_265_s2 <= rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_265_s3 <= rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_265_s4 <= rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_265_s5 <= rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_270_s2 <= rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_270_s3 <= rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_270_s4 <= rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_270_s5 <= rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_270_s6 <= rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_271_s3 <= rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_271_s4 <= rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_271_s5 <= rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_271_s6 <= rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_271_s7 <= rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_278_s1 <= __beopt_width_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_278_s2 <= rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= __beopt_width_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_279_s2 <= rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_279_s3 <= rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_292_s3 <= rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_292_s4 <= rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_293_s3 <= rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_293_s4 <= rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_310_s7 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_362_s5 <= mul_tree_343_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_366_s5 <= mul_tree_343_366; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_370_s5 <= mul_tree_343_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_374_s5 <= mul_tree_343_374; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_174_s6 <= __beopt_width_561; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_387_s4 <= mul_tree_344_387; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_391_s4 <= mul_tree_344_391; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_395_s4 <= mul_tree_344_395; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_399_s4 <= mul_tree_344_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_11_s5 <= s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_11_s6 <= rtlzz_pipe_11_s5; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_11_s7 <= rtlzz_pipe_11_s6; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_175_s5 <= __beopt_width_562; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_175_s6 <= rtlzz_pipe_175_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_465_s6 <= mul_tree_348_465; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_469_s6 <= mul_tree_348_469; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_473_s6 <= mul_tree_348_473; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_477_s6 <= mul_tree_348_477; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_48_s7 <= s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_719_s3 <= limb_13_719; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_719_s4 <= rtlzz_pipe_719_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_724_s3 <= limb_13_724; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_724_s4 <= rtlzz_pipe_724_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_168_s5 <= __beopt_width_551; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_20_s6 <= tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_268_s5 <= __beopt_width_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_268_s6 <= rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_298_s5 <= mul_precision_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_729_s5 <= limb_15_729; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_734_s5 <= limb_15_734; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_269_s6 <= __beopt_width_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_427_s6 <= mul_tree_345_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_430_s6 <= mul_tree_345_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_172_s7 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_173_s6 <= __beopt_width_560; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_173_s7 <= rtlzz_pipe_173_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_739_s7 <= limb_29_739; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_740_s7 <= limb_29_740; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_745_s7 <= limb_29_745; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_747_s7 <= limb_29_747; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_753_s6 <= limb_31_753; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_753_s7 <= rtlzz_pipe_753_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_759_s6 <= limb_31_759; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_759_s7 <= rtlzz_pipe_759_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_765_s7 <= limb_38_765; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_771_s7 <= limb_38_771; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_777_s7 <= limb_38_777; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_783_s7 <= limb_40_783; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_788_s7 <= limb_40_788; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_794_s7 <= limb_40_794; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_800_s1 <= limb_51_800; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_800_s2 <= rtlzz_pipe_800_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_800_s3 <= rtlzz_pipe_800_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_800_s4 <= rtlzz_pipe_800_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_800_s5 <= rtlzz_pipe_800_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_800_s6 <= rtlzz_pipe_800_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_805_s1 <= limb_51_805; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_805_s2 <= rtlzz_pipe_805_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_805_s3 <= rtlzz_pipe_805_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_805_s4 <= rtlzz_pipe_805_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_805_s5 <= rtlzz_pipe_805_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_805_s6 <= rtlzz_pipe_805_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_184_s7 <= __beopt_width_579; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_274_s7 <= __beopt_width_362; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_246_s7 <= __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_313_s7 <= mul_precision_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_810_s2 <= limb_53_810; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_810_s3 <= rtlzz_pipe_810_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_810_s4 <= rtlzz_pipe_810_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_810_s5 <= rtlzz_pipe_810_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_810_s6 <= rtlzz_pipe_810_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_810_s7 <= rtlzz_pipe_810_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_815_s2 <= limb_53_815; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_815_s3 <= rtlzz_pipe_815_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_815_s4 <= rtlzz_pipe_815_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_815_s5 <= rtlzz_pipe_815_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_815_s6 <= rtlzz_pipe_815_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_815_s7 <= rtlzz_pipe_815_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_845_s7 <= limb_76_845; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_851_s7 <= limb_76_851; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_857_s7 <= limb_76_857; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_879_s1 <= limb_85_879; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_879_s2 <= rtlzz_pipe_879_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_884_s1 <= limb_85_884; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_884_s2 <= rtlzz_pipe_884_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_889_s1 <= limb_85_889; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_889_s2 <= rtlzz_pipe_889_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_198_s3 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_286_s3 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_286_s4 <= rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_322_s3 <= mul_precision_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_325_s4 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_331_s3 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_894_s2 <= limb_87_894; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_894_s3 <= rtlzz_pipe_894_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_899_s2 <= limb_87_899; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_899_s3 <= rtlzz_pipe_899_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_904_s2 <= limb_87_904; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_904_s3 <= rtlzz_pipe_904_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_199_s4 <= __beopt_width_606; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_281_s4 <= __beopt_width_393; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_283_s4 <= __beopt_width_399; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_287_s4 <= __beopt_width_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_200_s4 <= __beopt_width_609; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_203_s5 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_214_s4 <= __beopt_width_635; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_214_s5 <= rtlzz_pipe_214_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_144_s4 <= tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_144_s5 <= rtlzz_pipe_144_s4; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_921_s5 <= limb_105_921; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_922_s5 <= limb_105_922; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_927_s5 <= limb_105_927; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_928_s5 <= limb_105_928; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_933_s3 <= limb_113_933; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_933_s4 <= rtlzz_pipe_933_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_938_s3 <= limb_113_938; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_938_s4 <= rtlzz_pipe_938_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_120_s5 <= tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_288_s5 <= __beopt_width_417; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_290_s5 <= __beopt_width_423; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= mul_precision_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_337_s6 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= mul_precision_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_943_s4 <= limb_115_943; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_948_s4 <= limb_115_948; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_115_s5 <= s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_122_s5 <= tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_122_s6 <= rtlzz_pipe_122_s5; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_289_s5 <= __beopt_width_420; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_289_s6 <= rtlzz_pipe_289_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_291_s5 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_291_s6 <= rtlzz_pipe_291_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_955_s6 <= limb_129_955; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_961_s6 <= limb_129_961; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_997_s6 <= limb_140_997; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1003_s6 <= limb_140_1003; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1009_s6 <= limb_140_1009; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1074_s1 <= limb_157_1074; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1074_s2 <= rtlzz_pipe_1074_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1074_s3 <= rtlzz_pipe_1074_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1074_s4 <= rtlzz_pipe_1074_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1074_s5 <= rtlzz_pipe_1074_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1074_s6 <= rtlzz_pipe_1074_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1074_s7 <= rtlzz_pipe_1074_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1079_s1 <= limb_157_1079; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1079_s2 <= rtlzz_pipe_1079_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1079_s3 <= rtlzz_pipe_1079_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1079_s4 <= rtlzz_pipe_1079_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1079_s5 <= rtlzz_pipe_1079_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1079_s6 <= rtlzz_pipe_1079_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1079_s7 <= rtlzz_pipe_1079_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1084_s1 <= limb_157_1084; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1084_s2 <= rtlzz_pipe_1084_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1084_s3 <= rtlzz_pipe_1084_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1084_s4 <= rtlzz_pipe_1084_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1084_s5 <= rtlzz_pipe_1084_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1084_s6 <= rtlzz_pipe_1084_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1084_s7 <= rtlzz_pipe_1084_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1089_s1 <= limb_157_1089; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1089_s2 <= rtlzz_pipe_1089_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1089_s3 <= rtlzz_pipe_1089_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1089_s4 <= rtlzz_pipe_1089_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1089_s5 <= rtlzz_pipe_1089_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1089_s6 <= rtlzz_pipe_1089_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1089_s7 <= rtlzz_pipe_1089_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1094_s1 <= limb_157_1094; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1094_s2 <= rtlzz_pipe_1094_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1094_s3 <= rtlzz_pipe_1094_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1094_s4 <= rtlzz_pipe_1094_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1094_s5 <= rtlzz_pipe_1094_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1094_s6 <= rtlzz_pipe_1094_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1094_s7 <= rtlzz_pipe_1094_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1099_s1 <= limb_157_1099; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1099_s2 <= rtlzz_pipe_1099_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1099_s3 <= rtlzz_pipe_1099_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1099_s4 <= rtlzz_pipe_1099_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1099_s5 <= rtlzz_pipe_1099_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1099_s6 <= rtlzz_pipe_1099_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1099_s7 <= rtlzz_pipe_1099_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1104_s1 <= limb_157_1104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1104_s2 <= rtlzz_pipe_1104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1104_s3 <= rtlzz_pipe_1104_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1104_s4 <= rtlzz_pipe_1104_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1104_s5 <= rtlzz_pipe_1104_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1104_s6 <= rtlzz_pipe_1104_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1104_s7 <= rtlzz_pipe_1104_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1109_s1 <= limb_157_1109; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1109_s2 <= rtlzz_pipe_1109_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1109_s3 <= rtlzz_pipe_1109_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1109_s4 <= rtlzz_pipe_1109_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1109_s5 <= rtlzz_pipe_1109_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1109_s6 <= rtlzz_pipe_1109_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1109_s7 <= rtlzz_pipe_1109_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_1114_s1 <= limb_157_1114; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_1114_s2 <= rtlzz_pipe_1114_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_1114_s3 <= rtlzz_pipe_1114_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1114_s4 <= rtlzz_pipe_1114_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1114_s5 <= rtlzz_pipe_1114_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1114_s6 <= rtlzz_pipe_1114_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1114_s7 <= rtlzz_pipe_1114_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1328_s6 <= limb_224_1328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1333_s6 <= limb_224_1333; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1338_s6 <= limb_224_1338; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1358_s4 <= limb_226_1358; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1358_s5 <= rtlzz_pipe_1358_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1363_s4 <= limb_226_1363; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1363_s5 <= rtlzz_pipe_1363_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_1368_s4 <= limb_226_1368; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_1368_s5 <= rtlzz_pipe_1368_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_979_s6 <= limb_138_979; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_985_s6 <= limb_138_985; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_991_s6 <= limb_138_991; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1223_s6 <= limb_219_1223; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1228_s6 <= limb_219_1228; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1233_s6 <= limb_219_1233; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1238_s6 <= limb_219_1238; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1243_s6 <= limb_219_1243; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1013_s7 <= limb_147_1013; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1019_s7 <= limb_147_1019; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1025_s7 <= limb_147_1025; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1031_s7 <= limb_147_1031; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1037_s7 <= limb_147_1037; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
