`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] x, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] c0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] c1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] c2, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] c3, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] c4, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:8; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_mul_3_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] s8_norm_add_5_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:18-24:25; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_mul_9_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [63:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:28:18-28:25; prim: /home/zyrv/vulsim/workload.cpp:28:18-28:25
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    logic [63:0] arith_original_18; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [63:0] arith_original_19; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    logic [63:0] arith_original_20; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [31:0] limb_8_21; // decl: <none>; prim: <none>
    logic [31:0] limb_8_22; // decl: <none>; prim: <none>
    logic [32:0] limb_8_23; // decl: <none>; prim: <none>
    logic [31:0] limb_8_24; // decl: <none>; prim: <none>
    logic limb_8_25; // decl: <none>; prim: <none>
    logic [31:0] limb_8_26; // decl: <none>; prim: <none>
    logic [31:0] limb_8_27; // decl: <none>; prim: <none>
    logic [32:0] limb_8_28; // decl: <none>; prim: <none>
    logic [31:0] limb_8_29; // decl: <none>; prim: <none>
    logic [63:0] limb_8_30; // decl: <none>; prim: <none>
    logic [31:0] limb_10_31; // decl: <none>; prim: <none>
    logic [31:0] limb_10_32; // decl: <none>; prim: <none>
    logic [32:0] limb_10_33; // decl: <none>; prim: <none>
    logic [31:0] limb_10_34; // decl: <none>; prim: <none>
    logic limb_10_35; // decl: <none>; prim: <none>
    logic [31:0] limb_10_36; // decl: <none>; prim: <none>
    logic [31:0] limb_10_37; // decl: <none>; prim: <none>
    logic [32:0] limb_10_38; // decl: <none>; prim: <none>
    logic [31:0] limb_10_39; // decl: <none>; prim: <none>
    logic [63:0] limb_10_40; // decl: <none>; prim: <none>
    logic [31:0] limb_12_41; // decl: <none>; prim: <none>
    logic [31:0] limb_12_42; // decl: <none>; prim: <none>
    logic [32:0] limb_12_43; // decl: <none>; prim: <none>
    logic [31:0] limb_12_44; // decl: <none>; prim: <none>
    logic limb_12_45; // decl: <none>; prim: <none>
    logic [31:0] limb_12_46; // decl: <none>; prim: <none>
    logic [31:0] limb_12_47; // decl: <none>; prim: <none>
    logic [32:0] limb_12_48; // decl: <none>; prim: <none>
    logic [31:0] limb_12_49; // decl: <none>; prim: <none>
    logic [63:0] limb_12_50; // decl: <none>; prim: <none>
    logic [31:0] limb_14_51; // decl: <none>; prim: <none>
    logic [31:0] limb_14_52; // decl: <none>; prim: <none>
    logic [32:0] limb_14_53; // decl: <none>; prim: <none>
    logic [31:0] limb_14_54; // decl: <none>; prim: <none>
    logic limb_14_55; // decl: <none>; prim: <none>
    logic [31:0] limb_14_56; // decl: <none>; prim: <none>
    logic [31:0] limb_14_57; // decl: <none>; prim: <none>
    logic [32:0] limb_14_58; // decl: <none>; prim: <none>
    logic [31:0] limb_14_59; // decl: <none>; prim: <none>
    logic [63:0] limb_14_60; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] rtlzz_pipe_0_s7; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [31:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_24_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_25_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_26_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_27_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_8_s3; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    logic [31:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_34_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_36_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_36_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_37_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_37_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_37_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_41_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_42_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_46_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_47_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    logic [31:0] rtlzz_pipe_52_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_52_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s3; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_57_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8


    assign s8_norm_mul_0_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_add_2_v0 = limb_8_30; // decl: <none>; prim: <none>
    assign s8_norm_mul_3_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_add_5_v0 = limb_10_40; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_19; // decl: <none>; prim: <none>
    assign s8_norm_add_8_v0 = limb_12_50; // decl: <none>; prim: <none>
    assign s8_norm_mul_9_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_add_11_v0 = limb_14_60; // decl: <none>; prim: <none>
    assign y = s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:10; prim: /home/zyrv/vulsim/workload.cpp:29:5-29:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign arith_original_17 = 64'(($unsigned(64'($unsigned(c4))) * $unsigned(64'($unsigned(x))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:21:18-21:24
    assign arith_original_18 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_8_s3))) * $unsigned(64'($unsigned(rtlzz_pipe_0_s3))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
    assign arith_original_19 = 64'(($unsigned(64'($unsigned(s8_norm_add_5_v0))) * $unsigned(64'($unsigned(rtlzz_pipe_0_s5))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:24:18-24:25
    assign arith_original_20 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_12_s7))) * $unsigned(64'($unsigned(rtlzz_pipe_0_s7))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
    assign limb_8_21 = s8_norm_mul_0_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_8_22 = c3[31:0]; // decl: <none>; prim: <none>
    assign limb_8_23 = 33'((({1'h0, rtlzz_pipe_21_s1}) + ({1'h0, rtlzz_pipe_22_s1}) + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_8_24 = limb_8_23[31:0]; // decl: <none>; prim: <none>
    assign limb_8_25 = limb_8_23[32]; // decl: <none>; prim: <none>
    assign limb_8_26 = s8_norm_mul_0_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_8_27 = c3[63:32]; // decl: <none>; prim: <none>
    assign limb_8_28 = 33'((({1'h0, rtlzz_pipe_26_s2}) + ({1'h0, rtlzz_pipe_27_s2}) + ({32'h0, rtlzz_pipe_25_s2}))); // decl: <none>; prim: <none>
    assign limb_8_29 = limb_8_28[31:0]; // decl: <none>; prim: <none>
    assign limb_8_30 = {limb_8_29, rtlzz_pipe_24_s2}; // decl: <none>; prim: <none>
    assign limb_10_31 = s8_norm_mul_3_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_10_32 = c2[31:0]; // decl: <none>; prim: <none>
    assign limb_10_33 = 33'((({1'h0, rtlzz_pipe_31_s4}) + ({1'h0, rtlzz_pipe_32_s4}) + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_10_34 = limb_10_33[31:0]; // decl: <none>; prim: <none>
    assign limb_10_35 = limb_10_33[32]; // decl: <none>; prim: <none>
    assign limb_10_36 = s8_norm_mul_3_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_10_37 = c2[63:32]; // decl: <none>; prim: <none>
    assign limb_10_38 = 33'((({1'h0, rtlzz_pipe_36_s5}) + ({1'h0, rtlzz_pipe_37_s5}) + ({32'h0, rtlzz_pipe_35_s5}))); // decl: <none>; prim: <none>
    assign limb_10_39 = limb_10_38[31:0]; // decl: <none>; prim: <none>
    assign limb_10_40 = {limb_10_39, rtlzz_pipe_34_s5}; // decl: <none>; prim: <none>
    assign limb_12_41 = s8_norm_mul_6_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_12_42 = c1[31:0]; // decl: <none>; prim: <none>
    assign limb_12_43 = 33'((({1'h0, rtlzz_pipe_41_s6}) + ({1'h0, rtlzz_pipe_42_s6}) + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_12_44 = limb_12_43[31:0]; // decl: <none>; prim: <none>
    assign limb_12_45 = limb_12_43[32]; // decl: <none>; prim: <none>
    assign limb_12_46 = s8_norm_mul_6_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_12_47 = c1[63:32]; // decl: <none>; prim: <none>
    assign limb_12_48 = 33'((({1'h0, rtlzz_pipe_46_s6}) + ({1'h0, rtlzz_pipe_47_s6}) + ({32'h0, limb_12_45}))); // decl: <none>; prim: <none>
    assign limb_12_49 = limb_12_48[31:0]; // decl: <none>; prim: <none>
    assign limb_12_50 = {limb_12_49, limb_12_44}; // decl: <none>; prim: <none>
    assign limb_14_51 = s8_norm_mul_9_v0[31:0]; // decl: <none>; prim: <none>
    assign limb_14_52 = c0[31:0]; // decl: <none>; prim: <none>
    assign limb_14_53 = 33'((({1'h0, limb_14_51}) + ({1'h0, rtlzz_pipe_52_s7}) + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_14_54 = limb_14_53[31:0]; // decl: <none>; prim: <none>
    assign limb_14_55 = limb_14_53[32]; // decl: <none>; prim: <none>
    assign limb_14_56 = s8_norm_mul_9_v0[63:32]; // decl: <none>; prim: <none>
    assign limb_14_57 = c0[63:32]; // decl: <none>; prim: <none>
    assign limb_14_58 = 33'((({1'h0, limb_14_56}) + ({1'h0, rtlzz_pipe_57_s7}) + ({32'h0, limb_14_55}))); // decl: <none>; prim: <none>
    assign limb_14_59 = limb_14_58[31:0]; // decl: <none>; prim: <none>
    assign limb_14_60 = {limb_14_59, limb_14_54}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_0_s1 <= 64'h0;
            rtlzz_pipe_0_s2 <= 64'h0;
            rtlzz_pipe_0_s3 <= 64'h0;
            rtlzz_pipe_0_s4 <= 64'h0;
            rtlzz_pipe_0_s5 <= 64'h0;
            rtlzz_pipe_0_s6 <= 64'h0;
            rtlzz_pipe_0_s7 <= 64'h0;
            rtlzz_pipe_21_s1 <= 32'h0;
            rtlzz_pipe_22_s1 <= 32'h0;
            rtlzz_pipe_24_s2 <= 32'h0;
            rtlzz_pipe_25_s2 <= 1'h0;
            rtlzz_pipe_26_s1 <= 32'h0;
            rtlzz_pipe_26_s2 <= 32'h0;
            rtlzz_pipe_27_s1 <= 32'h0;
            rtlzz_pipe_27_s2 <= 32'h0;
            rtlzz_pipe_8_s3 <= 64'h0;
            rtlzz_pipe_31_s4 <= 32'h0;
            rtlzz_pipe_32_s1 <= 32'h0;
            rtlzz_pipe_32_s2 <= 32'h0;
            rtlzz_pipe_32_s3 <= 32'h0;
            rtlzz_pipe_32_s4 <= 32'h0;
            rtlzz_pipe_34_s5 <= 32'h0;
            rtlzz_pipe_35_s5 <= 1'h0;
            rtlzz_pipe_36_s4 <= 32'h0;
            rtlzz_pipe_36_s5 <= 32'h0;
            rtlzz_pipe_37_s1 <= 32'h0;
            rtlzz_pipe_37_s2 <= 32'h0;
            rtlzz_pipe_37_s3 <= 32'h0;
            rtlzz_pipe_37_s4 <= 32'h0;
            rtlzz_pipe_37_s5 <= 32'h0;
            rtlzz_pipe_41_s6 <= 32'h0;
            rtlzz_pipe_42_s1 <= 32'h0;
            rtlzz_pipe_42_s2 <= 32'h0;
            rtlzz_pipe_42_s3 <= 32'h0;
            rtlzz_pipe_42_s4 <= 32'h0;
            rtlzz_pipe_42_s5 <= 32'h0;
            rtlzz_pipe_42_s6 <= 32'h0;
            rtlzz_pipe_46_s6 <= 32'h0;
            rtlzz_pipe_47_s1 <= 32'h0;
            rtlzz_pipe_47_s2 <= 32'h0;
            rtlzz_pipe_47_s3 <= 32'h0;
            rtlzz_pipe_47_s4 <= 32'h0;
            rtlzz_pipe_47_s5 <= 32'h0;
            rtlzz_pipe_47_s6 <= 32'h0;
            rtlzz_pipe_12_s7 <= 64'h0;
            rtlzz_pipe_52_s1 <= 32'h0;
            rtlzz_pipe_52_s2 <= 32'h0;
            rtlzz_pipe_52_s3 <= 32'h0;
            rtlzz_pipe_52_s4 <= 32'h0;
            rtlzz_pipe_52_s5 <= 32'h0;
            rtlzz_pipe_52_s6 <= 32'h0;
            rtlzz_pipe_52_s7 <= 32'h0;
            rtlzz_pipe_57_s1 <= 32'h0;
            rtlzz_pipe_57_s2 <= 32'h0;
            rtlzz_pipe_57_s3 <= 32'h0;
            rtlzz_pipe_57_s4 <= 32'h0;
            rtlzz_pipe_57_s5 <= 32'h0;
            rtlzz_pipe_57_s6 <= 32'h0;
            rtlzz_pipe_57_s7 <= 32'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_0_s1 <= x; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_0_s2 <= rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_0_s3 <= rtlzz_pipe_0_s2; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_0_s4 <= rtlzz_pipe_0_s3; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_0_s5 <= rtlzz_pipe_0_s4; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_0_s6 <= rtlzz_pipe_0_s5; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_0_s7 <= rtlzz_pipe_0_s6; // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= limb_8_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= limb_8_22; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_24_s2 <= limb_8_24; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_25_s2 <= limb_8_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= limb_8_26; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_26_s2 <= rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= limb_8_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_27_s2 <= rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_8_s3 <= s8_norm_add_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:18-22:25; prim: /home/zyrv/vulsim/workload.cpp:22:18-22:25
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= limb_10_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= limb_10_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_34_s5 <= limb_10_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= limb_10_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_36_s4 <= limb_10_36; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= rtlzz_pipe_36_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= limb_10_37; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_37_s2 <= rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_37_s3 <= rtlzz_pipe_37_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_37_s4 <= rtlzz_pipe_37_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_37_s5 <= rtlzz_pipe_37_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_41_s6 <= limb_12_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= limb_12_42; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_42_s2 <= rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_42_s3 <= rtlzz_pipe_42_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_42_s4 <= rtlzz_pipe_42_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_42_s5 <= rtlzz_pipe_42_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_42_s6 <= rtlzz_pipe_42_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_46_s6 <= limb_12_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= limb_12_47; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_47_s3 <= rtlzz_pipe_47_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_47_s4 <= rtlzz_pipe_47_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_47_s5 <= rtlzz_pipe_47_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_47_s6 <= rtlzz_pipe_47_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:18-26:25; prim: /home/zyrv/vulsim/workload.cpp:26:18-26:25
        end
        if (iv) begin
        rtlzz_pipe_52_s1 <= limb_14_52; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_52_s2 <= rtlzz_pipe_52_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_52_s3 <= rtlzz_pipe_52_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= rtlzz_pipe_52_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_52_s7 <= rtlzz_pipe_52_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= limb_14_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_57_s3 <= rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_57_s4 <= rtlzz_pipe_57_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_57_s5 <= rtlzz_pipe_57_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_57_s6 <= rtlzz_pipe_57_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_57_s7 <= rtlzz_pipe_57_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] x_data,input wire x_wen,input wire [63:0] c0_data,input wire c0_wen,input wire [63:0] c1_data,input wire c1_wen,input wire [63:0] c2_data,input wire c2_wen,input wire [63:0] c3_data,input wire c3_wen,input wire [63:0] c4_data,input wire c4_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_x;
reg [63:0] l_c0;
reg [63:0] l_c1;
reg [63:0] l_c2;
reg [63:0] l_c3;
reg [63:0] l_c4;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.x(l_x),.c0(l_c0),.c1(l_c1),.c2(l_c2),.c3(l_c3),.c4(l_c4),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_x<=64'h0;l_c0<=64'h0;l_c1<=64'h0;l_c2<=64'h0;l_c3<=64'h0;l_c4<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(x_wen)l_x<=x_data;if(c0_wen)l_c0<=c0_data;if(c1_wen)l_c1<=c1_data;if(c2_wen)l_c2<=c2_data;if(c3_wen)l_c3<=c3_data;if(c4_wen)l_c4<=c4_data;y<=c_y;end
endmodule
