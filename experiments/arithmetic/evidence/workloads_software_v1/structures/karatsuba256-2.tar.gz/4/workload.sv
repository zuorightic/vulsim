`timescale 1ns/1ps

module WorkloadCore(
    input logic [255:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [255:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [511:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [512:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_hw_0_v0; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] tmp_workload_top_int_128__8_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [127:0] tmp_workload_top_int_128__10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [255:0] s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] s8_norm_mul_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    logic [64:0] tmp_workload_top_int_65__18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    logic [64:0] s8_norm_add_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:44; prim: /home/zyrv/vulsim/workload.cpp:25:19-25:44
    logic [64:0] tmp_workload_top_int_65__23_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    logic [64:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:44; prim: /home/zyrv/vulsim/workload.cpp:26:19-26:44
    logic [65:0] tmp_workload_top_int_66__32_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [65:0] tmp_workload_top_int_66__34_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [131:0] s8_norm_mul_28_v0; // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    logic [127:0] s8_norm_mul_32_v0; // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    logic [33:0] tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] s8_norm_add_36_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    logic [33:0] tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [33:0] s8_norm_add_39_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    logic [67:0] tmp_workload_top_int_68__52_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    logic [67:0] tmp_workload_top_int_68__54_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    logic [135:0] s8_norm_mul_42_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] n20_v0; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    logic [67:0] tmp_workload_top_int_68__57_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    logic [67:0] s8_norm_sub_45_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:37
    logic [67:0] tmp_workload_top_int_68__60_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    logic [67:0] s8_norm_sub_47_v0; // decl: /home/zyrv/vulsim/workload.cpp:36:19-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:19-36:52
    logic [129:0] tmp_workload_top_int_130__63_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    logic [129:0] tmp_workload_top_int_130__65_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    logic [129:0] s8_norm_shift_50_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    logic [129:0] tmp_workload_top_int_130__69_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    logic [129:0] s8_norm_shift_53_v0; // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    logic [129:0] tmp_workload_top_int_130__73_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    logic [129:0] s8_norm_sub_56_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:38
    logic [129:0] tmp_workload_top_int_130__76_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    logic [129:0] s8_norm_sub_58_v0; // decl: /home/zyrv/vulsim/workload.cpp:38:20-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:20-38:53
    logic [255:0] tmp_workload_top_int_256__79_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    logic [255:0] tmp_workload_top_int_256__81_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    logic [255:0] s8_norm_shift_61_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    logic [255:0] tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] s8_norm_shift_64_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    logic [127:0] tmp_workload_top_int_128__93_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [127:0] tmp_workload_top_int_128__95_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [255:0] s8_norm_mul_72_v0; // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    logic [255:0] s8_norm_mul_76_v0; // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    logic [64:0] tmp_workload_top_int_65__103_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    logic [64:0] s8_norm_add_80_v0; // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:46; prim: /home/zyrv/vulsim/workload.cpp:46:19-46:46
    logic [64:0] tmp_workload_top_int_65__108_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    logic [64:0] s8_norm_add_83_v0; // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:46; prim: /home/zyrv/vulsim/workload.cpp:47:19-47:46
    logic [65:0] tmp_workload_top_int_66__117_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [65:0] tmp_workload_top_int_66__119_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [131:0] s8_norm_mul_90_v0; // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    logic [127:0] s8_norm_mul_94_v0; // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    logic [33:0] tmp_workload_top_int_34__127_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    logic [33:0] s8_norm_add_98_v0; // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    logic [33:0] tmp_workload_top_int_34__132_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    logic [33:0] s8_norm_add_101_v0; // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    logic [67:0] tmp_workload_top_int_68__137_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    logic [67:0] tmp_workload_top_int_68__139_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    logic [135:0] s8_norm_mul_104_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] n41_v0; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    logic [67:0] tmp_workload_top_int_68__142_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    logic [67:0] s8_norm_sub_107_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:37
    logic [67:0] tmp_workload_top_int_68__145_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    logic [67:0] s8_norm_sub_109_v0; // decl: /home/zyrv/vulsim/workload.cpp:57:19-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:19-57:52
    logic [129:0] tmp_workload_top_int_130__148_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    logic [129:0] tmp_workload_top_int_130__150_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    logic [129:0] s8_norm_shift_112_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    logic [129:0] tmp_workload_top_int_130__154_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    logic [129:0] s8_norm_shift_115_v0; // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    logic [129:0] tmp_workload_top_int_130__158_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    logic [129:0] s8_norm_sub_118_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:39
    logic [129:0] tmp_workload_top_int_130__161_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    logic [129:0] s8_norm_sub_120_v0; // decl: /home/zyrv/vulsim/workload.cpp:59:20-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:20-59:55
    logic [255:0] tmp_workload_top_int_256__164_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    logic [255:0] tmp_workload_top_int_256__166_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    logic [255:0] s8_norm_shift_123_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    logic [255:0] tmp_workload_top_int_256__170_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    logic [255:0] s8_norm_shift_126_v0; // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    logic [128:0] tmp_workload_top_int_129__174_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [128:0] s8_norm_add_130_v0; // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:47; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:47
    logic [128:0] tmp_workload_top_int_129__179_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [128:0] s8_norm_add_133_v0; // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:47; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:47
    logic [64:0] s8_norm_hw_134_v0; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [64:0] s8_norm_hw_135_v0; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [65:0] tmp_workload_top_int_66__192_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [65:0] tmp_workload_top_int_66__194_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [131:0] s8_norm_mul_144_v0; // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    logic [127:0] s8_norm_mul_148_v0; // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    logic [33:0] tmp_workload_top_int_34__202_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    logic [33:0] s8_norm_add_152_v0; // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    logic [33:0] tmp_workload_top_int_34__207_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    logic [33:0] s8_norm_add_155_v0; // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    logic [67:0] tmp_workload_top_int_68__212_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    logic [67:0] tmp_workload_top_int_68__214_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    logic [135:0] s8_norm_mul_158_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] n60_v0; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    logic [67:0] tmp_workload_top_int_68__217_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    logic [67:0] s8_norm_sub_161_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:37
    logic [67:0] tmp_workload_top_int_68__220_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    logic [67:0] s8_norm_sub_163_v0; // decl: /home/zyrv/vulsim/workload.cpp:76:19-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:19-76:52
    logic [129:0] tmp_workload_top_int_130__223_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    logic [129:0] tmp_workload_top_int_130__225_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    logic [129:0] s8_norm_shift_166_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    logic [129:0] tmp_workload_top_int_130__229_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    logic [129:0] s8_norm_shift_169_v0; // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    logic [255:0] s8_norm_mul_173_v0; // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    logic [65:0] tmp_workload_top_int_66__238_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    logic [65:0] s8_norm_add_177_v0; // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:46; prim: /home/zyrv/vulsim/workload.cpp:79:19-79:46
    logic [65:0] tmp_workload_top_int_66__243_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    logic [65:0] s8_norm_add_180_v0; // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:46; prim: /home/zyrv/vulsim/workload.cpp:80:19-80:46
    logic [65:0] tmp_workload_top_int_66__252_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [65:0] tmp_workload_top_int_66__254_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [131:0] s8_norm_mul_187_v0; // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    logic [131:0] s8_norm_mul_191_v0; // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    logic [33:0] tmp_workload_top_int_34__262_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    logic [33:0] s8_norm_add_195_v0; // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    logic [33:0] tmp_workload_top_int_34__267_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    logic [33:0] s8_norm_add_198_v0; // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    logic [67:0] tmp_workload_top_int_68__272_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    logic [67:0] tmp_workload_top_int_68__274_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    logic [135:0] s8_norm_mul_201_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] n74_v0; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    logic [67:0] tmp_workload_top_int_68__277_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    logic [67:0] s8_norm_sub_204_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:37
    logic [67:0] tmp_workload_top_int_68__280_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    logic [67:0] s8_norm_sub_206_v0; // decl: /home/zyrv/vulsim/workload.cpp:90:19-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:19-90:52
    logic [131:0] tmp_workload_top_int_132__283_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    logic [131:0] tmp_workload_top_int_132__285_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    logic [131:0] s8_norm_shift_209_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    logic [131:0] tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [131:0] s8_norm_shift_212_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    logic [131:0] tmp_workload_top_int_132__293_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    logic [131:0] s8_norm_sub_215_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:39
    logic [131:0] tmp_workload_top_int_132__296_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    logic [131:0] s8_norm_sub_217_v0; // decl: /home/zyrv/vulsim/workload.cpp:92:20-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:20-92:55
    logic [257:0] tmp_workload_top_int_258__299_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    logic [257:0] tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [257:0] s8_norm_shift_220_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    logic [257:0] tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [257:0] s8_norm_shift_223_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    logic [257:0] tmp_workload_top_int_258__309_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    logic [257:0] s8_norm_sub_226_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:39
    logic [257:0] tmp_workload_top_int_258__312_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    logic [257:0] s8_norm_sub_228_v0; // decl: /home/zyrv/vulsim/workload.cpp:94:20-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:20-94:55
    logic [511:0] tmp_workload_top_int_512__315_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    logic [511:0] tmp_workload_top_int_512__317_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    logic [511:0] s8_norm_shift_231_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    logic [511:0] tmp_workload_top_int_512__321_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    logic [511:0] s8_norm_shift_234_v0; // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    logic [512:0] tmp_workload_top_int_513__325_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    logic [512:0] tmp_workload_top_int_513__327_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    logic [512:0] s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:47
    logic [63:0] __beopt_width_535; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_537; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_539; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_542; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_545; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_546; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_547; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_549; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_551; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_554; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_557; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_558; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_559; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_560; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_561; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_562; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_563; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_565; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_567; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_570; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_573; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_574; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_575; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_577; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_579; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_582; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_585; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_586; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_587; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_588; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_589; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_590; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_591; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_592; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_594; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_595; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_599; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_601; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_603; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_606; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_609; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_610; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_611; // decl: <none>; prim: <none>
    logic [129:0] __beopt_width_612; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_613; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_615; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_617; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_620; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_623; // decl: <none>; prim: <none>
    logic [32:0] __beopt_width_625; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_627; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_630; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_633; // decl: <none>; prim: <none>
    logic [67:0] __beopt_width_634; // decl: <none>; prim: <none>
    logic [131:0] __beopt_width_635; // decl: <none>; prim: <none>
    logic [257:0] __beopt_width_636; // decl: <none>; prim: <none>
    logic [511:0] __beopt_width_292; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [511:0] __beopt_width_294; // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:83; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:83
    logic [257:0] __beopt_width_295; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [257:0] __beopt_width_297; // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:82; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:82
    logic [255:0] __beopt_width_299; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_301; // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:82; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:82
    logic [255:0] __beopt_width_302; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [255:0] __beopt_width_303; // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:80; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:80
    logic [131:0] __beopt_width_305; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [131:0] __beopt_width_307; // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:81; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:81
    logic [129:0] __beopt_width_309; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_310; // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:81; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:81
    logic [129:0] __beopt_width_311; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_313; // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:81; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:81
    logic [129:0] __beopt_width_315; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [129:0] __beopt_width_317; // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:81; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:81
    logic [127:0] __beopt_width_296; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_304; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [64:0] __beopt_width_312; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [64:0] __beopt_width_318; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [63:0] __beopt_width_322; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [63:0] __beopt_width_328; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [33:0] __beopt_width_332; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    logic [33:0] __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [127:0] __beopt_width_342; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] __beopt_width_346; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] __beopt_width_352; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [64:0] __beopt_width_357; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [63:0] __beopt_width_360; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [63:0] __beopt_width_363; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [33:0] __beopt_width_367; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    logic [33:0] __beopt_width_370; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    logic [128:0] __beopt_width_374; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [128:0] __beopt_width_378; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    logic [63:0] __beopt_width_382; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [63:0] __beopt_width_385; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [33:0] __beopt_width_388; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    logic [33:0] __beopt_width_391; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    logic [127:0] __beopt_width_395; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [127:0] __beopt_width_397; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_401; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    logic [65:0] __beopt_width_404; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [65:0] __beopt_width_407; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [65:0] __beopt_width_411; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [33:0] __beopt_width_416; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    logic [33:0] __beopt_width_424; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    logic [127:0] __beopt_width_298; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_314; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_321; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_325; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_329; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_333; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_337; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_340; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_344; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_349; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_353; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_356; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_362; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_366; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_372; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_376; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_380; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_386; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_389; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_393; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_396; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_399; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_403; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_406; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_410; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_413; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_417; // decl: <none>; prim: <none>
    logic [65:0] __beopt_width_420; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_423; // decl: <none>; prim: <none>
    logic [33:0] __beopt_width_427; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_292; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_293; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_294; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_295; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_296; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_297; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_298; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_299; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_300; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_301; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_302; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_303; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_304; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_305; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_306; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_307; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_308; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_309; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_310; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_311; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_312; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_313; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_314; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_315; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_316; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_317; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_318; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_319; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_320; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_321; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_322; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_323; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_324; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_325; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_326; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_327; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_328; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_329; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_330; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_331; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_332; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_333; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_334; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_335; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_336; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_337; // decl: <none>; prim: <none>
    logic [32:0] mul_precision_338; // decl: <none>; prim: <none>
    logic [65:0] mul_precision_339; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_340; // decl: <none>; prim: <none>
    logic [33:0] mul_precision_341; // decl: <none>; prim: <none>
    logic [67:0] mul_precision_342; // decl: <none>; prim: <none>
    logic [127:0] arith_original_343; // decl: <none>; prim: <none>
    logic [127:0] arith_original_344; // decl: <none>; prim: <none>
    logic [65:0] arith_original_345; // decl: <none>; prim: <none>
    logic [63:0] arith_original_346; // decl: <none>; prim: <none>
    logic [67:0] arith_original_347; // decl: <none>; prim: <none>
    logic [127:0] arith_original_348; // decl: <none>; prim: <none>
    logic [127:0] arith_original_349; // decl: <none>; prim: <none>
    logic [65:0] arith_original_350; // decl: <none>; prim: <none>
    logic [63:0] arith_original_351; // decl: <none>; prim: <none>
    logic [67:0] arith_original_352; // decl: <none>; prim: <none>
    logic [65:0] arith_original_353; // decl: <none>; prim: <none>
    logic [63:0] arith_original_354; // decl: <none>; prim: <none>
    logic [67:0] arith_original_355; // decl: <none>; prim: <none>
    logic [127:0] arith_original_356; // decl: <none>; prim: <none>
    logic [65:0] arith_original_357; // decl: <none>; prim: <none>
    logic [65:0] arith_original_358; // decl: <none>; prim: <none>
    logic [67:0] arith_original_359; // decl: <none>; prim: <none>
    logic [63:0] limb_13_360; // decl: <none>; prim: <none>
    logic [63:0] limb_13_361; // decl: <none>; prim: <none>
    logic [64:0] limb_13_362; // decl: <none>; prim: <none>
    logic [63:0] limb_13_363; // decl: <none>; prim: <none>
    logic limb_13_364; // decl: <none>; prim: <none>
    logic limb_13_365; // decl: <none>; prim: <none>
    logic limb_13_366; // decl: <none>; prim: <none>
    logic [1:0] limb_13_367; // decl: <none>; prim: <none>
    logic limb_13_368; // decl: <none>; prim: <none>
    logic [64:0] limb_13_369; // decl: <none>; prim: <none>
    logic [63:0] limb_15_370; // decl: <none>; prim: <none>
    logic [63:0] limb_15_371; // decl: <none>; prim: <none>
    logic [64:0] limb_15_372; // decl: <none>; prim: <none>
    logic [63:0] limb_15_373; // decl: <none>; prim: <none>
    logic limb_15_374; // decl: <none>; prim: <none>
    logic limb_15_375; // decl: <none>; prim: <none>
    logic limb_15_376; // decl: <none>; prim: <none>
    logic [1:0] limb_15_377; // decl: <none>; prim: <none>
    logic limb_15_378; // decl: <none>; prim: <none>
    logic [64:0] limb_15_379; // decl: <none>; prim: <none>
    logic [63:0] limb_29_380; // decl: <none>; prim: <none>
    logic [63:0] limb_29_381; // decl: <none>; prim: <none>
    logic [63:0] limb_29_382; // decl: <none>; prim: <none>
    logic [64:0] limb_29_383; // decl: <none>; prim: <none>
    logic [63:0] limb_29_384; // decl: <none>; prim: <none>
    logic limb_29_385; // decl: <none>; prim: <none>
    logic [3:0] limb_29_386; // decl: <none>; prim: <none>
    logic [3:0] limb_29_387; // decl: <none>; prim: <none>
    logic [3:0] limb_29_388; // decl: <none>; prim: <none>
    logic [4:0] limb_29_389; // decl: <none>; prim: <none>
    logic [3:0] limb_29_390; // decl: <none>; prim: <none>
    logic [67:0] limb_29_391; // decl: <none>; prim: <none>
    logic [63:0] limb_31_392; // decl: <none>; prim: <none>
    logic [63:0] limb_31_393; // decl: <none>; prim: <none>
    logic [63:0] limb_31_394; // decl: <none>; prim: <none>
    logic [64:0] limb_31_395; // decl: <none>; prim: <none>
    logic [63:0] limb_31_396; // decl: <none>; prim: <none>
    logic limb_31_397; // decl: <none>; prim: <none>
    logic [3:0] limb_31_398; // decl: <none>; prim: <none>
    logic [3:0] limb_31_399; // decl: <none>; prim: <none>
    logic [3:0] limb_31_400; // decl: <none>; prim: <none>
    logic [4:0] limb_31_401; // decl: <none>; prim: <none>
    logic [3:0] limb_31_402; // decl: <none>; prim: <none>
    logic [67:0] limb_31_403; // decl: <none>; prim: <none>
    logic [63:0] limb_38_404; // decl: <none>; prim: <none>
    logic [63:0] limb_38_405; // decl: <none>; prim: <none>
    logic [63:0] limb_38_406; // decl: <none>; prim: <none>
    logic [64:0] limb_38_407; // decl: <none>; prim: <none>
    logic [63:0] limb_38_408; // decl: <none>; prim: <none>
    logic limb_38_409; // decl: <none>; prim: <none>
    logic [63:0] limb_38_410; // decl: <none>; prim: <none>
    logic [63:0] limb_38_411; // decl: <none>; prim: <none>
    logic [63:0] limb_38_412; // decl: <none>; prim: <none>
    logic [64:0] limb_38_413; // decl: <none>; prim: <none>
    logic [63:0] limb_38_414; // decl: <none>; prim: <none>
    logic limb_38_415; // decl: <none>; prim: <none>
    logic [1:0] limb_38_416; // decl: <none>; prim: <none>
    logic [1:0] limb_38_417; // decl: <none>; prim: <none>
    logic [1:0] limb_38_418; // decl: <none>; prim: <none>
    logic [2:0] limb_38_419; // decl: <none>; prim: <none>
    logic [1:0] limb_38_420; // decl: <none>; prim: <none>
    logic [129:0] limb_38_421; // decl: <none>; prim: <none>
    logic [63:0] limb_40_422; // decl: <none>; prim: <none>
    logic [63:0] limb_40_423; // decl: <none>; prim: <none>
    logic [63:0] limb_40_424; // decl: <none>; prim: <none>
    logic [64:0] limb_40_425; // decl: <none>; prim: <none>
    logic [63:0] limb_40_426; // decl: <none>; prim: <none>
    logic limb_40_427; // decl: <none>; prim: <none>
    logic [63:0] limb_40_428; // decl: <none>; prim: <none>
    logic [63:0] limb_40_429; // decl: <none>; prim: <none>
    logic [63:0] limb_40_430; // decl: <none>; prim: <none>
    logic [64:0] limb_40_431; // decl: <none>; prim: <none>
    logic [63:0] limb_40_432; // decl: <none>; prim: <none>
    logic limb_40_433; // decl: <none>; prim: <none>
    logic [1:0] limb_40_434; // decl: <none>; prim: <none>
    logic [1:0] limb_40_435; // decl: <none>; prim: <none>
    logic [1:0] limb_40_436; // decl: <none>; prim: <none>
    logic [2:0] limb_40_437; // decl: <none>; prim: <none>
    logic [1:0] limb_40_438; // decl: <none>; prim: <none>
    logic [129:0] limb_40_439; // decl: <none>; prim: <none>
    logic [63:0] limb_51_440; // decl: <none>; prim: <none>
    logic [63:0] limb_51_441; // decl: <none>; prim: <none>
    logic [64:0] limb_51_442; // decl: <none>; prim: <none>
    logic [63:0] limb_51_443; // decl: <none>; prim: <none>
    logic limb_51_444; // decl: <none>; prim: <none>
    logic limb_51_445; // decl: <none>; prim: <none>
    logic limb_51_446; // decl: <none>; prim: <none>
    logic [1:0] limb_51_447; // decl: <none>; prim: <none>
    logic limb_51_448; // decl: <none>; prim: <none>
    logic [64:0] limb_51_449; // decl: <none>; prim: <none>
    logic [63:0] limb_53_450; // decl: <none>; prim: <none>
    logic [63:0] limb_53_451; // decl: <none>; prim: <none>
    logic [64:0] limb_53_452; // decl: <none>; prim: <none>
    logic [63:0] limb_53_453; // decl: <none>; prim: <none>
    logic limb_53_454; // decl: <none>; prim: <none>
    logic limb_53_455; // decl: <none>; prim: <none>
    logic limb_53_456; // decl: <none>; prim: <none>
    logic [1:0] limb_53_457; // decl: <none>; prim: <none>
    logic limb_53_458; // decl: <none>; prim: <none>
    logic [64:0] limb_53_459; // decl: <none>; prim: <none>
    logic [63:0] limb_67_460; // decl: <none>; prim: <none>
    logic [63:0] limb_67_461; // decl: <none>; prim: <none>
    logic [63:0] limb_67_462; // decl: <none>; prim: <none>
    logic [64:0] limb_67_463; // decl: <none>; prim: <none>
    logic [63:0] limb_67_464; // decl: <none>; prim: <none>
    logic limb_67_465; // decl: <none>; prim: <none>
    logic [3:0] limb_67_466; // decl: <none>; prim: <none>
    logic [3:0] limb_67_467; // decl: <none>; prim: <none>
    logic [3:0] limb_67_468; // decl: <none>; prim: <none>
    logic [4:0] limb_67_469; // decl: <none>; prim: <none>
    logic [3:0] limb_67_470; // decl: <none>; prim: <none>
    logic [67:0] limb_67_471; // decl: <none>; prim: <none>
    logic [63:0] limb_69_472; // decl: <none>; prim: <none>
    logic [63:0] limb_69_473; // decl: <none>; prim: <none>
    logic [63:0] limb_69_474; // decl: <none>; prim: <none>
    logic [64:0] limb_69_475; // decl: <none>; prim: <none>
    logic [63:0] limb_69_476; // decl: <none>; prim: <none>
    logic limb_69_477; // decl: <none>; prim: <none>
    logic [3:0] limb_69_478; // decl: <none>; prim: <none>
    logic [3:0] limb_69_479; // decl: <none>; prim: <none>
    logic [3:0] limb_69_480; // decl: <none>; prim: <none>
    logic [4:0] limb_69_481; // decl: <none>; prim: <none>
    logic [3:0] limb_69_482; // decl: <none>; prim: <none>
    logic [67:0] limb_69_483; // decl: <none>; prim: <none>
    logic [63:0] limb_76_484; // decl: <none>; prim: <none>
    logic [63:0] limb_76_485; // decl: <none>; prim: <none>
    logic [63:0] limb_76_486; // decl: <none>; prim: <none>
    logic [64:0] limb_76_487; // decl: <none>; prim: <none>
    logic [63:0] limb_76_488; // decl: <none>; prim: <none>
    logic limb_76_489; // decl: <none>; prim: <none>
    logic [63:0] limb_76_490; // decl: <none>; prim: <none>
    logic [63:0] limb_76_491; // decl: <none>; prim: <none>
    logic [63:0] limb_76_492; // decl: <none>; prim: <none>
    logic [64:0] limb_76_493; // decl: <none>; prim: <none>
    logic [63:0] limb_76_494; // decl: <none>; prim: <none>
    logic limb_76_495; // decl: <none>; prim: <none>
    logic [1:0] limb_76_496; // decl: <none>; prim: <none>
    logic [1:0] limb_76_497; // decl: <none>; prim: <none>
    logic [1:0] limb_76_498; // decl: <none>; prim: <none>
    logic [2:0] limb_76_499; // decl: <none>; prim: <none>
    logic [1:0] limb_76_500; // decl: <none>; prim: <none>
    logic [129:0] limb_76_501; // decl: <none>; prim: <none>
    logic [63:0] limb_78_502; // decl: <none>; prim: <none>
    logic [63:0] limb_78_503; // decl: <none>; prim: <none>
    logic [63:0] limb_78_504; // decl: <none>; prim: <none>
    logic [64:0] limb_78_505; // decl: <none>; prim: <none>
    logic [63:0] limb_78_506; // decl: <none>; prim: <none>
    logic limb_78_507; // decl: <none>; prim: <none>
    logic [63:0] limb_78_508; // decl: <none>; prim: <none>
    logic [63:0] limb_78_509; // decl: <none>; prim: <none>
    logic [63:0] limb_78_510; // decl: <none>; prim: <none>
    logic [64:0] limb_78_511; // decl: <none>; prim: <none>
    logic [63:0] limb_78_512; // decl: <none>; prim: <none>
    logic limb_78_513; // decl: <none>; prim: <none>
    logic [1:0] limb_78_514; // decl: <none>; prim: <none>
    logic [1:0] limb_78_515; // decl: <none>; prim: <none>
    logic [1:0] limb_78_516; // decl: <none>; prim: <none>
    logic [2:0] limb_78_517; // decl: <none>; prim: <none>
    logic [1:0] limb_78_518; // decl: <none>; prim: <none>
    logic [129:0] limb_78_519; // decl: <none>; prim: <none>
    logic [63:0] limb_85_520; // decl: <none>; prim: <none>
    logic [63:0] limb_85_521; // decl: <none>; prim: <none>
    logic [64:0] limb_85_522; // decl: <none>; prim: <none>
    logic [63:0] limb_85_523; // decl: <none>; prim: <none>
    logic limb_85_524; // decl: <none>; prim: <none>
    logic [63:0] limb_85_525; // decl: <none>; prim: <none>
    logic [63:0] limb_85_526; // decl: <none>; prim: <none>
    logic [64:0] limb_85_527; // decl: <none>; prim: <none>
    logic [63:0] limb_85_528; // decl: <none>; prim: <none>
    logic limb_85_529; // decl: <none>; prim: <none>
    logic limb_85_530; // decl: <none>; prim: <none>
    logic limb_85_531; // decl: <none>; prim: <none>
    logic [1:0] limb_85_532; // decl: <none>; prim: <none>
    logic limb_85_533; // decl: <none>; prim: <none>
    logic [128:0] limb_85_534; // decl: <none>; prim: <none>
    logic [63:0] limb_87_535; // decl: <none>; prim: <none>
    logic [63:0] limb_87_536; // decl: <none>; prim: <none>
    logic [64:0] limb_87_537; // decl: <none>; prim: <none>
    logic [63:0] limb_87_538; // decl: <none>; prim: <none>
    logic limb_87_539; // decl: <none>; prim: <none>
    logic [63:0] limb_87_540; // decl: <none>; prim: <none>
    logic [63:0] limb_87_541; // decl: <none>; prim: <none>
    logic [64:0] limb_87_542; // decl: <none>; prim: <none>
    logic [63:0] limb_87_543; // decl: <none>; prim: <none>
    logic limb_87_544; // decl: <none>; prim: <none>
    logic limb_87_545; // decl: <none>; prim: <none>
    logic limb_87_546; // decl: <none>; prim: <none>
    logic [1:0] limb_87_547; // decl: <none>; prim: <none>
    logic limb_87_548; // decl: <none>; prim: <none>
    logic [128:0] limb_87_549; // decl: <none>; prim: <none>
    logic [63:0] limb_103_550; // decl: <none>; prim: <none>
    logic [63:0] limb_103_551; // decl: <none>; prim: <none>
    logic [63:0] limb_103_552; // decl: <none>; prim: <none>
    logic [64:0] limb_103_553; // decl: <none>; prim: <none>
    logic [63:0] limb_103_554; // decl: <none>; prim: <none>
    logic limb_103_555; // decl: <none>; prim: <none>
    logic [3:0] limb_103_556; // decl: <none>; prim: <none>
    logic [3:0] limb_103_557; // decl: <none>; prim: <none>
    logic [3:0] limb_103_558; // decl: <none>; prim: <none>
    logic [4:0] limb_103_559; // decl: <none>; prim: <none>
    logic [3:0] limb_103_560; // decl: <none>; prim: <none>
    logic [67:0] limb_103_561; // decl: <none>; prim: <none>
    logic [63:0] limb_105_562; // decl: <none>; prim: <none>
    logic [63:0] limb_105_563; // decl: <none>; prim: <none>
    logic [63:0] limb_105_564; // decl: <none>; prim: <none>
    logic [64:0] limb_105_565; // decl: <none>; prim: <none>
    logic [63:0] limb_105_566; // decl: <none>; prim: <none>
    logic limb_105_567; // decl: <none>; prim: <none>
    logic [3:0] limb_105_568; // decl: <none>; prim: <none>
    logic [3:0] limb_105_569; // decl: <none>; prim: <none>
    logic [3:0] limb_105_570; // decl: <none>; prim: <none>
    logic [4:0] limb_105_571; // decl: <none>; prim: <none>
    logic [3:0] limb_105_572; // decl: <none>; prim: <none>
    logic [67:0] limb_105_573; // decl: <none>; prim: <none>
    logic [63:0] limb_113_574; // decl: <none>; prim: <none>
    logic [63:0] limb_113_575; // decl: <none>; prim: <none>
    logic [64:0] limb_113_576; // decl: <none>; prim: <none>
    logic [63:0] limb_113_577; // decl: <none>; prim: <none>
    logic limb_113_578; // decl: <none>; prim: <none>
    logic [1:0] limb_113_579; // decl: <none>; prim: <none>
    logic [1:0] limb_113_580; // decl: <none>; prim: <none>
    logic [2:0] limb_113_581; // decl: <none>; prim: <none>
    logic [1:0] limb_113_582; // decl: <none>; prim: <none>
    logic [65:0] limb_113_583; // decl: <none>; prim: <none>
    logic [63:0] limb_115_584; // decl: <none>; prim: <none>
    logic [63:0] limb_115_585; // decl: <none>; prim: <none>
    logic [64:0] limb_115_586; // decl: <none>; prim: <none>
    logic [63:0] limb_115_587; // decl: <none>; prim: <none>
    logic limb_115_588; // decl: <none>; prim: <none>
    logic [1:0] limb_115_589; // decl: <none>; prim: <none>
    logic [1:0] limb_115_590; // decl: <none>; prim: <none>
    logic [2:0] limb_115_591; // decl: <none>; prim: <none>
    logic [1:0] limb_115_592; // decl: <none>; prim: <none>
    logic [65:0] limb_115_593; // decl: <none>; prim: <none>
    logic [63:0] limb_129_594; // decl: <none>; prim: <none>
    logic [63:0] limb_129_595; // decl: <none>; prim: <none>
    logic [63:0] limb_129_596; // decl: <none>; prim: <none>
    logic [64:0] limb_129_597; // decl: <none>; prim: <none>
    logic [63:0] limb_129_598; // decl: <none>; prim: <none>
    logic limb_129_599; // decl: <none>; prim: <none>
    logic [3:0] limb_129_600; // decl: <none>; prim: <none>
    logic [3:0] limb_129_601; // decl: <none>; prim: <none>
    logic [3:0] limb_129_602; // decl: <none>; prim: <none>
    logic [4:0] limb_129_603; // decl: <none>; prim: <none>
    logic [3:0] limb_129_604; // decl: <none>; prim: <none>
    logic [67:0] limb_129_605; // decl: <none>; prim: <none>
    logic [63:0] limb_131_606; // decl: <none>; prim: <none>
    logic [63:0] limb_131_607; // decl: <none>; prim: <none>
    logic [63:0] limb_131_608; // decl: <none>; prim: <none>
    logic [64:0] limb_131_609; // decl: <none>; prim: <none>
    logic [63:0] limb_131_610; // decl: <none>; prim: <none>
    logic limb_131_611; // decl: <none>; prim: <none>
    logic [3:0] limb_131_612; // decl: <none>; prim: <none>
    logic [3:0] limb_131_613; // decl: <none>; prim: <none>
    logic [3:0] limb_131_614; // decl: <none>; prim: <none>
    logic [4:0] limb_131_615; // decl: <none>; prim: <none>
    logic [3:0] limb_131_616; // decl: <none>; prim: <none>
    logic [67:0] limb_131_617; // decl: <none>; prim: <none>
    logic [63:0] limb_138_618; // decl: <none>; prim: <none>
    logic [63:0] limb_138_619; // decl: <none>; prim: <none>
    logic [63:0] limb_138_620; // decl: <none>; prim: <none>
    logic [64:0] limb_138_621; // decl: <none>; prim: <none>
    logic [63:0] limb_138_622; // decl: <none>; prim: <none>
    logic limb_138_623; // decl: <none>; prim: <none>
    logic [63:0] limb_138_624; // decl: <none>; prim: <none>
    logic [63:0] limb_138_625; // decl: <none>; prim: <none>
    logic [63:0] limb_138_626; // decl: <none>; prim: <none>
    logic [64:0] limb_138_627; // decl: <none>; prim: <none>
    logic [63:0] limb_138_628; // decl: <none>; prim: <none>
    logic limb_138_629; // decl: <none>; prim: <none>
    logic [3:0] limb_138_630; // decl: <none>; prim: <none>
    logic [3:0] limb_138_631; // decl: <none>; prim: <none>
    logic [3:0] limb_138_632; // decl: <none>; prim: <none>
    logic [4:0] limb_138_633; // decl: <none>; prim: <none>
    logic [3:0] limb_138_634; // decl: <none>; prim: <none>
    logic [131:0] limb_138_635; // decl: <none>; prim: <none>
    logic [63:0] limb_140_636; // decl: <none>; prim: <none>
    logic [63:0] limb_140_637; // decl: <none>; prim: <none>
    logic [63:0] limb_140_638; // decl: <none>; prim: <none>
    logic [64:0] limb_140_639; // decl: <none>; prim: <none>
    logic [63:0] limb_140_640; // decl: <none>; prim: <none>
    logic limb_140_641; // decl: <none>; prim: <none>
    logic [63:0] limb_140_642; // decl: <none>; prim: <none>
    logic [63:0] limb_140_643; // decl: <none>; prim: <none>
    logic [63:0] limb_140_644; // decl: <none>; prim: <none>
    logic [64:0] limb_140_645; // decl: <none>; prim: <none>
    logic [63:0] limb_140_646; // decl: <none>; prim: <none>
    logic limb_140_647; // decl: <none>; prim: <none>
    logic [3:0] limb_140_648; // decl: <none>; prim: <none>
    logic [3:0] limb_140_649; // decl: <none>; prim: <none>
    logic [3:0] limb_140_650; // decl: <none>; prim: <none>
    logic [4:0] limb_140_651; // decl: <none>; prim: <none>
    logic [3:0] limb_140_652; // decl: <none>; prim: <none>
    logic [131:0] limb_140_653; // decl: <none>; prim: <none>
    logic [63:0] limb_147_654; // decl: <none>; prim: <none>
    logic [63:0] limb_147_655; // decl: <none>; prim: <none>
    logic [63:0] limb_147_656; // decl: <none>; prim: <none>
    logic [64:0] limb_147_657; // decl: <none>; prim: <none>
    logic [63:0] limb_147_658; // decl: <none>; prim: <none>
    logic limb_147_659; // decl: <none>; prim: <none>
    logic [63:0] limb_147_660; // decl: <none>; prim: <none>
    logic [63:0] limb_147_661; // decl: <none>; prim: <none>
    logic [63:0] limb_147_662; // decl: <none>; prim: <none>
    logic [64:0] limb_147_663; // decl: <none>; prim: <none>
    logic [63:0] limb_147_664; // decl: <none>; prim: <none>
    logic limb_147_665; // decl: <none>; prim: <none>
    logic [63:0] limb_147_666; // decl: <none>; prim: <none>
    logic [63:0] limb_147_667; // decl: <none>; prim: <none>
    logic [63:0] limb_147_668; // decl: <none>; prim: <none>
    logic [64:0] limb_147_669; // decl: <none>; prim: <none>
    logic [63:0] limb_147_670; // decl: <none>; prim: <none>
    logic limb_147_671; // decl: <none>; prim: <none>
    logic [63:0] limb_147_672; // decl: <none>; prim: <none>
    logic [63:0] limb_147_673; // decl: <none>; prim: <none>
    logic [63:0] limb_147_674; // decl: <none>; prim: <none>
    logic [64:0] limb_147_675; // decl: <none>; prim: <none>
    logic [63:0] limb_147_676; // decl: <none>; prim: <none>
    logic limb_147_677; // decl: <none>; prim: <none>
    logic [1:0] limb_147_678; // decl: <none>; prim: <none>
    logic [1:0] limb_147_679; // decl: <none>; prim: <none>
    logic [1:0] limb_147_680; // decl: <none>; prim: <none>
    logic [2:0] limb_147_681; // decl: <none>; prim: <none>
    logic [1:0] limb_147_682; // decl: <none>; prim: <none>
    logic [257:0] limb_147_683; // decl: <none>; prim: <none>
    logic [63:0] limb_149_684; // decl: <none>; prim: <none>
    logic [63:0] limb_149_685; // decl: <none>; prim: <none>
    logic [63:0] limb_149_686; // decl: <none>; prim: <none>
    logic [64:0] limb_149_687; // decl: <none>; prim: <none>
    logic [63:0] limb_149_688; // decl: <none>; prim: <none>
    logic limb_149_689; // decl: <none>; prim: <none>
    logic [63:0] limb_149_690; // decl: <none>; prim: <none>
    logic [63:0] limb_149_691; // decl: <none>; prim: <none>
    logic [63:0] limb_149_692; // decl: <none>; prim: <none>
    logic [64:0] limb_149_693; // decl: <none>; prim: <none>
    logic [63:0] limb_149_694; // decl: <none>; prim: <none>
    logic limb_149_695; // decl: <none>; prim: <none>
    logic [63:0] limb_149_696; // decl: <none>; prim: <none>
    logic [63:0] limb_149_697; // decl: <none>; prim: <none>
    logic [63:0] limb_149_698; // decl: <none>; prim: <none>
    logic [64:0] limb_149_699; // decl: <none>; prim: <none>
    logic [63:0] limb_149_700; // decl: <none>; prim: <none>
    logic limb_149_701; // decl: <none>; prim: <none>
    logic [63:0] limb_149_702; // decl: <none>; prim: <none>
    logic [63:0] limb_149_703; // decl: <none>; prim: <none>
    logic [63:0] limb_149_704; // decl: <none>; prim: <none>
    logic [64:0] limb_149_705; // decl: <none>; prim: <none>
    logic [63:0] limb_149_706; // decl: <none>; prim: <none>
    logic limb_149_707; // decl: <none>; prim: <none>
    logic [1:0] limb_149_708; // decl: <none>; prim: <none>
    logic [1:0] limb_149_709; // decl: <none>; prim: <none>
    logic [1:0] limb_149_710; // decl: <none>; prim: <none>
    logic [2:0] limb_149_711; // decl: <none>; prim: <none>
    logic [1:0] limb_149_712; // decl: <none>; prim: <none>
    logic [257:0] limb_149_713; // decl: <none>; prim: <none>
    logic [63:0] limb_157_714; // decl: <none>; prim: <none>
    logic [63:0] limb_157_715; // decl: <none>; prim: <none>
    logic [64:0] limb_157_716; // decl: <none>; prim: <none>
    logic [63:0] limb_157_717; // decl: <none>; prim: <none>
    logic limb_157_718; // decl: <none>; prim: <none>
    logic [63:0] limb_157_719; // decl: <none>; prim: <none>
    logic [63:0] limb_157_720; // decl: <none>; prim: <none>
    logic [64:0] limb_157_721; // decl: <none>; prim: <none>
    logic [63:0] limb_157_722; // decl: <none>; prim: <none>
    logic limb_157_723; // decl: <none>; prim: <none>
    logic [63:0] limb_157_724; // decl: <none>; prim: <none>
    logic [63:0] limb_157_725; // decl: <none>; prim: <none>
    logic [64:0] limb_157_726; // decl: <none>; prim: <none>
    logic [63:0] limb_157_727; // decl: <none>; prim: <none>
    logic limb_157_728; // decl: <none>; prim: <none>
    logic [63:0] limb_157_729; // decl: <none>; prim: <none>
    logic [63:0] limb_157_730; // decl: <none>; prim: <none>
    logic [64:0] limb_157_731; // decl: <none>; prim: <none>
    logic [63:0] limb_157_732; // decl: <none>; prim: <none>
    logic limb_157_733; // decl: <none>; prim: <none>
    logic [63:0] limb_157_734; // decl: <none>; prim: <none>
    logic [63:0] limb_157_735; // decl: <none>; prim: <none>
    logic [64:0] limb_157_736; // decl: <none>; prim: <none>
    logic [63:0] limb_157_737; // decl: <none>; prim: <none>
    logic limb_157_738; // decl: <none>; prim: <none>
    logic [63:0] limb_157_739; // decl: <none>; prim: <none>
    logic [63:0] limb_157_740; // decl: <none>; prim: <none>
    logic [64:0] limb_157_741; // decl: <none>; prim: <none>
    logic [63:0] limb_157_742; // decl: <none>; prim: <none>
    logic limb_157_743; // decl: <none>; prim: <none>
    logic [63:0] limb_157_744; // decl: <none>; prim: <none>
    logic [63:0] limb_157_745; // decl: <none>; prim: <none>
    logic [64:0] limb_157_746; // decl: <none>; prim: <none>
    logic [63:0] limb_157_747; // decl: <none>; prim: <none>
    logic limb_157_748; // decl: <none>; prim: <none>
    logic [63:0] limb_157_749; // decl: <none>; prim: <none>
    logic [63:0] limb_157_750; // decl: <none>; prim: <none>
    logic [64:0] limb_157_751; // decl: <none>; prim: <none>
    logic [63:0] limb_157_752; // decl: <none>; prim: <none>
    logic limb_157_753; // decl: <none>; prim: <none>
    logic limb_157_754; // decl: <none>; prim: <none>
    logic limb_157_755; // decl: <none>; prim: <none>
    logic [1:0] limb_157_756; // decl: <none>; prim: <none>
    logic limb_157_757; // decl: <none>; prim: <none>
    logic [512:0] limb_157_758; // decl: <none>; prim: <none>
    logic [63:0] limb_216_759; // decl: <none>; prim: <none>
    logic [63:0] limb_216_760; // decl: <none>; prim: <none>
    logic [64:0] limb_216_761; // decl: <none>; prim: <none>
    logic [63:0] limb_216_762; // decl: <none>; prim: <none>
    logic limb_216_763; // decl: <none>; prim: <none>
    logic [63:0] limb_216_764; // decl: <none>; prim: <none>
    logic [63:0] limb_216_765; // decl: <none>; prim: <none>
    logic [64:0] limb_216_766; // decl: <none>; prim: <none>
    logic [63:0] limb_216_767; // decl: <none>; prim: <none>
    logic limb_216_768; // decl: <none>; prim: <none>
    logic [63:0] limb_216_769; // decl: <none>; prim: <none>
    logic [63:0] limb_216_770; // decl: <none>; prim: <none>
    logic [64:0] limb_216_771; // decl: <none>; prim: <none>
    logic [63:0] limb_216_772; // decl: <none>; prim: <none>
    logic limb_216_773; // decl: <none>; prim: <none>
    logic [63:0] limb_216_774; // decl: <none>; prim: <none>
    logic [63:0] limb_216_775; // decl: <none>; prim: <none>
    logic [64:0] limb_216_776; // decl: <none>; prim: <none>
    logic [63:0] limb_216_777; // decl: <none>; prim: <none>
    logic limb_216_778; // decl: <none>; prim: <none>
    logic [63:0] limb_216_779; // decl: <none>; prim: <none>
    logic [63:0] limb_216_780; // decl: <none>; prim: <none>
    logic [64:0] limb_216_781; // decl: <none>; prim: <none>
    logic [63:0] limb_216_782; // decl: <none>; prim: <none>
    logic limb_216_783; // decl: <none>; prim: <none>
    logic [63:0] limb_216_784; // decl: <none>; prim: <none>
    logic [63:0] limb_216_785; // decl: <none>; prim: <none>
    logic [64:0] limb_216_786; // decl: <none>; prim: <none>
    logic [63:0] limb_216_787; // decl: <none>; prim: <none>
    logic limb_216_788; // decl: <none>; prim: <none>
    logic [63:0] limb_216_789; // decl: <none>; prim: <none>
    logic [63:0] limb_216_790; // decl: <none>; prim: <none>
    logic [64:0] limb_216_791; // decl: <none>; prim: <none>
    logic [63:0] limb_216_792; // decl: <none>; prim: <none>
    logic limb_216_793; // decl: <none>; prim: <none>
    logic [63:0] limb_216_794; // decl: <none>; prim: <none>
    logic [63:0] limb_216_795; // decl: <none>; prim: <none>
    logic [64:0] limb_216_796; // decl: <none>; prim: <none>
    logic [63:0] limb_216_797; // decl: <none>; prim: <none>
    logic [511:0] limb_216_798; // decl: <none>; prim: <none>
    logic [63:0] limb_217_799; // decl: <none>; prim: <none>
    logic [63:0] limb_217_800; // decl: <none>; prim: <none>
    logic [64:0] limb_217_801; // decl: <none>; prim: <none>
    logic [63:0] limb_217_802; // decl: <none>; prim: <none>
    logic limb_217_803; // decl: <none>; prim: <none>
    logic [63:0] limb_217_804; // decl: <none>; prim: <none>
    logic [63:0] limb_217_805; // decl: <none>; prim: <none>
    logic [64:0] limb_217_806; // decl: <none>; prim: <none>
    logic [63:0] limb_217_807; // decl: <none>; prim: <none>
    logic limb_217_808; // decl: <none>; prim: <none>
    logic [63:0] limb_217_809; // decl: <none>; prim: <none>
    logic [63:0] limb_217_810; // decl: <none>; prim: <none>
    logic [64:0] limb_217_811; // decl: <none>; prim: <none>
    logic [63:0] limb_217_812; // decl: <none>; prim: <none>
    logic limb_217_813; // decl: <none>; prim: <none>
    logic [63:0] limb_217_814; // decl: <none>; prim: <none>
    logic [63:0] limb_217_815; // decl: <none>; prim: <none>
    logic [64:0] limb_217_816; // decl: <none>; prim: <none>
    logic [63:0] limb_217_817; // decl: <none>; prim: <none>
    logic limb_217_818; // decl: <none>; prim: <none>
    logic [63:0] limb_217_819; // decl: <none>; prim: <none>
    logic [63:0] limb_217_820; // decl: <none>; prim: <none>
    logic [64:0] limb_217_821; // decl: <none>; prim: <none>
    logic [63:0] limb_217_822; // decl: <none>; prim: <none>
    logic limb_217_823; // decl: <none>; prim: <none>
    logic [63:0] limb_217_824; // decl: <none>; prim: <none>
    logic [63:0] limb_217_825; // decl: <none>; prim: <none>
    logic [64:0] limb_217_826; // decl: <none>; prim: <none>
    logic [63:0] limb_217_827; // decl: <none>; prim: <none>
    logic limb_217_828; // decl: <none>; prim: <none>
    logic [63:0] limb_217_829; // decl: <none>; prim: <none>
    logic [63:0] limb_217_830; // decl: <none>; prim: <none>
    logic [64:0] limb_217_831; // decl: <none>; prim: <none>
    logic [63:0] limb_217_832; // decl: <none>; prim: <none>
    logic limb_217_833; // decl: <none>; prim: <none>
    logic [63:0] limb_217_834; // decl: <none>; prim: <none>
    logic [63:0] limb_217_835; // decl: <none>; prim: <none>
    logic [64:0] limb_217_836; // decl: <none>; prim: <none>
    logic [63:0] limb_217_837; // decl: <none>; prim: <none>
    logic [511:0] limb_217_838; // decl: <none>; prim: <none>
    logic [63:0] limb_218_839; // decl: <none>; prim: <none>
    logic [63:0] limb_218_840; // decl: <none>; prim: <none>
    logic [64:0] limb_218_841; // decl: <none>; prim: <none>
    logic [63:0] limb_218_842; // decl: <none>; prim: <none>
    logic limb_218_843; // decl: <none>; prim: <none>
    logic [63:0] limb_218_844; // decl: <none>; prim: <none>
    logic [63:0] limb_218_845; // decl: <none>; prim: <none>
    logic [64:0] limb_218_846; // decl: <none>; prim: <none>
    logic [63:0] limb_218_847; // decl: <none>; prim: <none>
    logic limb_218_848; // decl: <none>; prim: <none>
    logic [63:0] limb_218_849; // decl: <none>; prim: <none>
    logic [63:0] limb_218_850; // decl: <none>; prim: <none>
    logic [64:0] limb_218_851; // decl: <none>; prim: <none>
    logic [63:0] limb_218_852; // decl: <none>; prim: <none>
    logic limb_218_853; // decl: <none>; prim: <none>
    logic [63:0] limb_218_854; // decl: <none>; prim: <none>
    logic [63:0] limb_218_855; // decl: <none>; prim: <none>
    logic [64:0] limb_218_856; // decl: <none>; prim: <none>
    logic [63:0] limb_218_857; // decl: <none>; prim: <none>
    logic limb_218_858; // decl: <none>; prim: <none>
    logic [1:0] limb_218_859; // decl: <none>; prim: <none>
    logic [1:0] limb_218_860; // decl: <none>; prim: <none>
    logic [2:0] limb_218_861; // decl: <none>; prim: <none>
    logic [1:0] limb_218_862; // decl: <none>; prim: <none>
    logic [257:0] limb_218_863; // decl: <none>; prim: <none>
    logic [63:0] limb_219_864; // decl: <none>; prim: <none>
    logic [63:0] limb_219_865; // decl: <none>; prim: <none>
    logic [64:0] limb_219_866; // decl: <none>; prim: <none>
    logic [63:0] limb_219_867; // decl: <none>; prim: <none>
    logic limb_219_868; // decl: <none>; prim: <none>
    logic [63:0] limb_219_869; // decl: <none>; prim: <none>
    logic [63:0] limb_219_870; // decl: <none>; prim: <none>
    logic [64:0] limb_219_871; // decl: <none>; prim: <none>
    logic [63:0] limb_219_872; // decl: <none>; prim: <none>
    logic limb_219_873; // decl: <none>; prim: <none>
    logic [63:0] limb_219_874; // decl: <none>; prim: <none>
    logic [63:0] limb_219_875; // decl: <none>; prim: <none>
    logic [64:0] limb_219_876; // decl: <none>; prim: <none>
    logic [63:0] limb_219_877; // decl: <none>; prim: <none>
    logic limb_219_878; // decl: <none>; prim: <none>
    logic [63:0] limb_219_879; // decl: <none>; prim: <none>
    logic [63:0] limb_219_880; // decl: <none>; prim: <none>
    logic [64:0] limb_219_881; // decl: <none>; prim: <none>
    logic [63:0] limb_219_882; // decl: <none>; prim: <none>
    logic limb_219_883; // decl: <none>; prim: <none>
    logic [1:0] limb_219_884; // decl: <none>; prim: <none>
    logic [1:0] limb_219_885; // decl: <none>; prim: <none>
    logic [2:0] limb_219_886; // decl: <none>; prim: <none>
    logic [1:0] limb_219_887; // decl: <none>; prim: <none>
    logic [257:0] limb_219_888; // decl: <none>; prim: <none>
    logic [63:0] limb_220_889; // decl: <none>; prim: <none>
    logic [63:0] limb_220_890; // decl: <none>; prim: <none>
    logic [64:0] limb_220_891; // decl: <none>; prim: <none>
    logic [63:0] limb_220_892; // decl: <none>; prim: <none>
    logic limb_220_893; // decl: <none>; prim: <none>
    logic [63:0] limb_220_894; // decl: <none>; prim: <none>
    logic [63:0] limb_220_895; // decl: <none>; prim: <none>
    logic [64:0] limb_220_896; // decl: <none>; prim: <none>
    logic [63:0] limb_220_897; // decl: <none>; prim: <none>
    logic limb_220_898; // decl: <none>; prim: <none>
    logic [63:0] limb_220_899; // decl: <none>; prim: <none>
    logic [63:0] limb_220_900; // decl: <none>; prim: <none>
    logic [64:0] limb_220_901; // decl: <none>; prim: <none>
    logic [63:0] limb_220_902; // decl: <none>; prim: <none>
    logic limb_220_903; // decl: <none>; prim: <none>
    logic [63:0] limb_220_904; // decl: <none>; prim: <none>
    logic [63:0] limb_220_905; // decl: <none>; prim: <none>
    logic [64:0] limb_220_906; // decl: <none>; prim: <none>
    logic [63:0] limb_220_907; // decl: <none>; prim: <none>
    logic [255:0] limb_220_908; // decl: <none>; prim: <none>
    logic [63:0] limb_221_909; // decl: <none>; prim: <none>
    logic [63:0] limb_221_910; // decl: <none>; prim: <none>
    logic [64:0] limb_221_911; // decl: <none>; prim: <none>
    logic [63:0] limb_221_912; // decl: <none>; prim: <none>
    logic limb_221_913; // decl: <none>; prim: <none>
    logic [63:0] limb_221_914; // decl: <none>; prim: <none>
    logic [63:0] limb_221_915; // decl: <none>; prim: <none>
    logic [64:0] limb_221_916; // decl: <none>; prim: <none>
    logic [63:0] limb_221_917; // decl: <none>; prim: <none>
    logic limb_221_918; // decl: <none>; prim: <none>
    logic [63:0] limb_221_919; // decl: <none>; prim: <none>
    logic [63:0] limb_221_920; // decl: <none>; prim: <none>
    logic [64:0] limb_221_921; // decl: <none>; prim: <none>
    logic [63:0] limb_221_922; // decl: <none>; prim: <none>
    logic limb_221_923; // decl: <none>; prim: <none>
    logic [63:0] limb_221_924; // decl: <none>; prim: <none>
    logic [63:0] limb_221_925; // decl: <none>; prim: <none>
    logic [64:0] limb_221_926; // decl: <none>; prim: <none>
    logic [63:0] limb_221_927; // decl: <none>; prim: <none>
    logic [255:0] limb_221_928; // decl: <none>; prim: <none>
    logic [63:0] limb_222_929; // decl: <none>; prim: <none>
    logic [63:0] limb_222_930; // decl: <none>; prim: <none>
    logic [64:0] limb_222_931; // decl: <none>; prim: <none>
    logic [63:0] limb_222_932; // decl: <none>; prim: <none>
    logic limb_222_933; // decl: <none>; prim: <none>
    logic [63:0] limb_222_934; // decl: <none>; prim: <none>
    logic [63:0] limb_222_935; // decl: <none>; prim: <none>
    logic [64:0] limb_222_936; // decl: <none>; prim: <none>
    logic [63:0] limb_222_937; // decl: <none>; prim: <none>
    logic limb_222_938; // decl: <none>; prim: <none>
    logic [63:0] limb_222_939; // decl: <none>; prim: <none>
    logic [63:0] limb_222_940; // decl: <none>; prim: <none>
    logic [64:0] limb_222_941; // decl: <none>; prim: <none>
    logic [63:0] limb_222_942; // decl: <none>; prim: <none>
    logic limb_222_943; // decl: <none>; prim: <none>
    logic [63:0] limb_222_944; // decl: <none>; prim: <none>
    logic [63:0] limb_222_945; // decl: <none>; prim: <none>
    logic [64:0] limb_222_946; // decl: <none>; prim: <none>
    logic [63:0] limb_222_947; // decl: <none>; prim: <none>
    logic [255:0] limb_222_948; // decl: <none>; prim: <none>
    logic [63:0] limb_223_949; // decl: <none>; prim: <none>
    logic [63:0] limb_223_950; // decl: <none>; prim: <none>
    logic [64:0] limb_223_951; // decl: <none>; prim: <none>
    logic [63:0] limb_223_952; // decl: <none>; prim: <none>
    logic limb_223_953; // decl: <none>; prim: <none>
    logic [63:0] limb_223_954; // decl: <none>; prim: <none>
    logic [63:0] limb_223_955; // decl: <none>; prim: <none>
    logic [64:0] limb_223_956; // decl: <none>; prim: <none>
    logic [63:0] limb_223_957; // decl: <none>; prim: <none>
    logic limb_223_958; // decl: <none>; prim: <none>
    logic [63:0] limb_223_959; // decl: <none>; prim: <none>
    logic [63:0] limb_223_960; // decl: <none>; prim: <none>
    logic [64:0] limb_223_961; // decl: <none>; prim: <none>
    logic [63:0] limb_223_962; // decl: <none>; prim: <none>
    logic limb_223_963; // decl: <none>; prim: <none>
    logic [63:0] limb_223_964; // decl: <none>; prim: <none>
    logic [63:0] limb_223_965; // decl: <none>; prim: <none>
    logic [64:0] limb_223_966; // decl: <none>; prim: <none>
    logic [63:0] limb_223_967; // decl: <none>; prim: <none>
    logic [255:0] limb_223_968; // decl: <none>; prim: <none>
    logic [63:0] limb_224_969; // decl: <none>; prim: <none>
    logic [63:0] limb_224_970; // decl: <none>; prim: <none>
    logic [64:0] limb_224_971; // decl: <none>; prim: <none>
    logic [63:0] limb_224_972; // decl: <none>; prim: <none>
    logic limb_224_973; // decl: <none>; prim: <none>
    logic [63:0] limb_224_974; // decl: <none>; prim: <none>
    logic [63:0] limb_224_975; // decl: <none>; prim: <none>
    logic [64:0] limb_224_976; // decl: <none>; prim: <none>
    logic [63:0] limb_224_977; // decl: <none>; prim: <none>
    logic limb_224_978; // decl: <none>; prim: <none>
    logic [3:0] limb_224_979; // decl: <none>; prim: <none>
    logic [3:0] limb_224_980; // decl: <none>; prim: <none>
    logic [4:0] limb_224_981; // decl: <none>; prim: <none>
    logic [3:0] limb_224_982; // decl: <none>; prim: <none>
    logic [131:0] limb_224_983; // decl: <none>; prim: <none>
    logic [63:0] limb_225_984; // decl: <none>; prim: <none>
    logic [63:0] limb_225_985; // decl: <none>; prim: <none>
    logic [64:0] limb_225_986; // decl: <none>; prim: <none>
    logic [63:0] limb_225_987; // decl: <none>; prim: <none>
    logic limb_225_988; // decl: <none>; prim: <none>
    logic [63:0] limb_225_989; // decl: <none>; prim: <none>
    logic [63:0] limb_225_990; // decl: <none>; prim: <none>
    logic [64:0] limb_225_991; // decl: <none>; prim: <none>
    logic [63:0] limb_225_992; // decl: <none>; prim: <none>
    logic limb_225_993; // decl: <none>; prim: <none>
    logic [3:0] limb_225_994; // decl: <none>; prim: <none>
    logic [3:0] limb_225_995; // decl: <none>; prim: <none>
    logic [4:0] limb_225_996; // decl: <none>; prim: <none>
    logic [3:0] limb_225_997; // decl: <none>; prim: <none>
    logic [131:0] limb_225_998; // decl: <none>; prim: <none>
    logic [63:0] limb_226_999; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1000; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1001; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1002; // decl: <none>; prim: <none>
    logic limb_226_1003; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1004; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1005; // decl: <none>; prim: <none>
    logic [64:0] limb_226_1006; // decl: <none>; prim: <none>
    logic [63:0] limb_226_1007; // decl: <none>; prim: <none>
    logic limb_226_1008; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1009; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1010; // decl: <none>; prim: <none>
    logic [2:0] limb_226_1011; // decl: <none>; prim: <none>
    logic [1:0] limb_226_1012; // decl: <none>; prim: <none>
    logic [129:0] limb_226_1013; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1014; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1015; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1016; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1017; // decl: <none>; prim: <none>
    logic limb_227_1018; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1019; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1020; // decl: <none>; prim: <none>
    logic [64:0] limb_227_1021; // decl: <none>; prim: <none>
    logic [63:0] limb_227_1022; // decl: <none>; prim: <none>
    logic limb_227_1023; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1024; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1025; // decl: <none>; prim: <none>
    logic [2:0] limb_227_1026; // decl: <none>; prim: <none>
    logic [1:0] limb_227_1027; // decl: <none>; prim: <none>
    logic [129:0] limb_227_1028; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1029; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1030; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1031; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1032; // decl: <none>; prim: <none>
    logic limb_228_1033; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1034; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1035; // decl: <none>; prim: <none>
    logic [64:0] limb_228_1036; // decl: <none>; prim: <none>
    logic [63:0] limb_228_1037; // decl: <none>; prim: <none>
    logic limb_228_1038; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1039; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1040; // decl: <none>; prim: <none>
    logic [2:0] limb_228_1041; // decl: <none>; prim: <none>
    logic [1:0] limb_228_1042; // decl: <none>; prim: <none>
    logic [129:0] limb_228_1043; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1044; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1045; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1046; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1047; // decl: <none>; prim: <none>
    logic limb_229_1048; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1049; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1050; // decl: <none>; prim: <none>
    logic [64:0] limb_229_1051; // decl: <none>; prim: <none>
    logic [63:0] limb_229_1052; // decl: <none>; prim: <none>
    logic limb_229_1053; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1054; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1055; // decl: <none>; prim: <none>
    logic [2:0] limb_229_1056; // decl: <none>; prim: <none>
    logic [1:0] limb_229_1057; // decl: <none>; prim: <none>
    logic [129:0] limb_229_1058; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1059; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1060; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1061; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1062; // decl: <none>; prim: <none>
    logic limb_230_1063; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1064; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1065; // decl: <none>; prim: <none>
    logic [64:0] limb_230_1066; // decl: <none>; prim: <none>
    logic [63:0] limb_230_1067; // decl: <none>; prim: <none>
    logic limb_230_1068; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1069; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1070; // decl: <none>; prim: <none>
    logic [2:0] limb_230_1071; // decl: <none>; prim: <none>
    logic [1:0] limb_230_1072; // decl: <none>; prim: <none>
    logic [129:0] limb_230_1073; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1074; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1075; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1076; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1077; // decl: <none>; prim: <none>
    logic limb_231_1078; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1079; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1080; // decl: <none>; prim: <none>
    logic [64:0] limb_231_1081; // decl: <none>; prim: <none>
    logic [63:0] limb_231_1082; // decl: <none>; prim: <none>
    logic limb_231_1083; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1084; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1085; // decl: <none>; prim: <none>
    logic [2:0] limb_231_1086; // decl: <none>; prim: <none>
    logic [1:0] limb_231_1087; // decl: <none>; prim: <none>
    logic [129:0] limb_231_1088; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_6_s3; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [127:0] rtlzz_pipe_7_s5; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    logic [64:0] rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_162_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_163_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_178_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_179_s7; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_194_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_262_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_263_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_264_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_265_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_270_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_271_s7; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_273_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_278_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_279_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_292_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_293_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_295_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_296_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_296_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_307_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_308_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_310_s7; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [255:0] rtlzz_pipe_10_s7; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    logic [129:0] rtlzz_pipe_174_s4; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_174_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_174_s6; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [255:0] rtlzz_pipe_44_s7; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    logic [63:0] rtlzz_pipe_360_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_360_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_365_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_365_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_20_s5; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [33:0] rtlzz_pipe_20_s6; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    logic [63:0] rtlzz_pipe_266_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_268_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_298_s5; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_301_s6; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_301_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_304_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_370_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_375_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_169_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_22_s7; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    logic [63:0] rtlzz_pipe_267_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_267_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_269_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_239_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    logic [129:0] rtlzz_pipe_172_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_382_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_382_s7; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_388_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_388_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_406_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_412_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_418_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_424_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_424_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_430_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_436_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_436_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_441_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_446_s6; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_313_s7; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_316_s7; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_319_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_451_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_456_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_486_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_492_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_498_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_520_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_520_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_525_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_525_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_530_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_530_s2; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_198_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_280_s3; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_282_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_284_s3; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_284_s4; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_286_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_322_s4; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_325_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_328_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_331_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_535_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_535_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_535_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_540_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_540_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_540_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_545_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_545_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_545_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_285_s5; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_287_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_202_s5; // decl: <none>; prim: <none>
    logic [129:0] rtlzz_pipe_203_s5; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_144_s6; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    logic [63:0] rtlzz_pipe_554_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_555_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_556_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_558_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_562_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_564_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_564_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_568_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_569_s5; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_570_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_574_s3; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_579_s3; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_334_s5; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_337_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_340_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_584_s5; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_589_s5; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_211_s6; // decl: <none>; prim: <none>
    logic [33:0] rtlzz_pipe_291_s6; // decl: <none>; prim: <none>
    logic [67:0] rtlzz_pipe_212_s6; // decl: <none>; prim: <none>
    logic [131:0] rtlzz_pipe_135_s6; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    logic [63:0] rtlzz_pipe_608_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_614_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_638_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_644_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_650_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_715_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_720_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_725_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_730_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_735_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_740_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_745_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_750_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_755_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_844_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_849_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_854_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_859_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_889_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_894_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_899_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_904_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_969_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_974_s6; // decl: <none>; prim: <none>
    logic [3:0] rtlzz_pipe_979_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1014_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1019_s6; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1024_s6; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_142_s7; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    logic [63:0] rtlzz_pipe_842_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_843_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_845_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_850_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_855_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_860_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1059_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_1064_s7; // decl: <none>; prim: <none>
    logic [1:0] rtlzz_pipe_1069_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_hw_0_v0 = a[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:15:19-15:20; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_hw_1_v0 = b[127:0]; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_hw_2_v0 = a[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign s8_norm_hw_3_v0 = b[255:128]; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign tmp_workload_top_int_128__8_v0 = (s8_norm_hw_0_v0 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:31; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign tmp_workload_top_int_128__10_v0 = (rtlzz_pipe_5_s1 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:23:34-23:46; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_mul_10_v0 = ({128'h0, mul_precision_294}); // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = ({128'h0, mul_precision_297}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__18_v0 = (rtlzz_pipe_162_s2 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:25:19-25:30; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:33
    assign s8_norm_add_18_v0 = limb_13_369; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__23_v0 = (rtlzz_pipe_163_s4 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:26:19-26:30; prim: /home/zyrv/vulsim/workload.cpp:16:5-16:33
    assign s8_norm_add_21_v0 = limb_15_379; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__32_v0 = (__beopt_width_545 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign tmp_workload_top_int_66__34_v0 = (__beopt_width_546 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:31:34-31:46; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_mul_28_v0 = ({66'h0, mul_precision_300}); // decl: <none>; prim: <none>
    assign s8_norm_mul_32_v0 = ({64'h0, mul_precision_303}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__42_v0 = (__beopt_width_551 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
    assign s8_norm_add_36_v0 = (rtlzz_pipe_20_s6 + __beopt_width_332); // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:46; prim: /home/zyrv/vulsim/workload.cpp:33:19-33:46
    assign tmp_workload_top_int_34__47_v0 = (rtlzz_pipe_169_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
    assign s8_norm_add_39_v0 = (rtlzz_pipe_22_s7 + rtlzz_pipe_239_s7); // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:46; prim: /home/zyrv/vulsim/workload.cpp:34:19-34:46
    assign tmp_workload_top_int_68__52_v0 = ({34'h0, s8_norm_add_36_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:31; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:31
    assign tmp_workload_top_int_68__54_v0 = ({34'h0, s8_norm_add_39_v0}); // decl: /home/zyrv/vulsim/workload.cpp:35:34-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:34-35:46
    assign s8_norm_mul_42_v0 = ({68'h0, mul_precision_306}); // decl: <none>; prim: <none>
    assign n20_v0 = s8_norm_mul_42_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:35:5-35:47; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign tmp_workload_top_int_68__57_v0 = (__beopt_width_557 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:25-36:37; prim: /home/zyrv/vulsim/workload.cpp:36:25-36:37
    assign s8_norm_sub_45_v0 = limb_29_391; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__60_v0 = (__beopt_width_558 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:36:40-36:52; prim: /home/zyrv/vulsim/workload.cpp:36:40-36:52
    assign s8_norm_sub_47_v0 = limb_31_403; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__63_v0 = (rtlzz_pipe_172_s6 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:20-37:33; prim: /home/zyrv/vulsim/workload.cpp:37:20-37:33
    assign tmp_workload_top_int_130__65_v0 = ({62'h0, s8_norm_sub_47_v0}); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:50; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:50
    assign s8_norm_shift_50_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__65_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:37:37-37:56; prim: /home/zyrv/vulsim/workload.cpp:37:37-37:56
    assign tmp_workload_top_int_130__69_v0 = (__beopt_width_560 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:74; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:74
    assign s8_norm_shift_53_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__69_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:37:61-37:80; prim: /home/zyrv/vulsim/workload.cpp:37:61-37:80
    assign tmp_workload_top_int_130__73_v0 = (rtlzz_pipe_174_s6 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:26-38:38; prim: /home/zyrv/vulsim/workload.cpp:38:26-38:38
    assign s8_norm_sub_56_v0 = limb_38_421; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__76_v0 = (__beopt_width_562 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:38:41-38:53; prim: /home/zyrv/vulsim/workload.cpp:38:41-38:53
    assign s8_norm_sub_58_v0 = limb_40_439; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__79_v0 = (rtlzz_pipe_10_s7 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:20-39:32; prim: /home/zyrv/vulsim/workload.cpp:39:20-39:32
    assign tmp_workload_top_int_256__81_v0 = ({126'h0, s8_norm_sub_58_v0}); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:49; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:49
    assign s8_norm_shift_61_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__81_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:39:36-39:55; prim: /home/zyrv/vulsim/workload.cpp:39:36-39:55
    assign tmp_workload_top_int_256__85_v0 = (s8_norm_mul_14_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
    assign s8_norm_shift_64_v0 = (32'h80 >= 32'd256 ? 256'h0 : (rtlzz_pipe_44_s7 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:79; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:79
    assign tmp_workload_top_int_128__93_v0 = (rtlzz_pipe_6_s3 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:33; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign tmp_workload_top_int_128__95_v0 = (rtlzz_pipe_7_s5 & 128'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:44:36-44:49; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_mul_72_v0 = ({128'h0, mul_precision_309}); // decl: <none>; prim: <none>
    assign s8_norm_mul_76_v0 = ({128'h0, mul_precision_312}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__103_v0 = (rtlzz_pipe_178_s6 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:46:19-46:31; prim: /home/zyrv/vulsim/workload.cpp:17:5-17:35
    assign s8_norm_add_80_v0 = limb_51_449; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_65__108_v0 = (rtlzz_pipe_179_s7 & 65'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:47:19-47:31; prim: /home/zyrv/vulsim/workload.cpp:18:5-18:35
    assign s8_norm_add_83_v0 = limb_53_459; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__117_v0 = (__beopt_width_573 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign tmp_workload_top_int_66__119_v0 = (__beopt_width_574 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:52:34-52:46; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_mul_90_v0 = ({66'h0, mul_precision_315}); // decl: <none>; prim: <none>
    assign s8_norm_mul_94_v0 = ({64'h0, mul_precision_318}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__127_v0 = (__beopt_width_579 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:31; prim: /home/zyrv/vulsim/workload.cpp:46:5-46:47
    assign s8_norm_add_98_v0 = (tmp_workload_top_int_34__127_v0 + __beopt_width_367); // decl: /home/zyrv/vulsim/workload.cpp:54:19-54:46; prim: /home/zyrv/vulsim/workload.cpp:54:19-54:46
    assign tmp_workload_top_int_34__132_v0 = (__beopt_width_582 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:31; prim: /home/zyrv/vulsim/workload.cpp:47:5-47:47
    assign s8_norm_add_101_v0 = (tmp_workload_top_int_34__132_v0 + __beopt_width_370); // decl: /home/zyrv/vulsim/workload.cpp:55:19-55:46; prim: /home/zyrv/vulsim/workload.cpp:55:19-55:46
    assign tmp_workload_top_int_68__137_v0 = ({34'h0, s8_norm_add_98_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:31; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:31
    assign tmp_workload_top_int_68__139_v0 = ({34'h0, s8_norm_add_101_v0}); // decl: /home/zyrv/vulsim/workload.cpp:56:34-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:34-56:46
    assign s8_norm_mul_104_v0 = ({68'h0, mul_precision_321}); // decl: <none>; prim: <none>
    assign n41_v0 = s8_norm_mul_104_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:56:5-56:47; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign tmp_workload_top_int_68__142_v0 = (__beopt_width_585 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:25-57:37; prim: /home/zyrv/vulsim/workload.cpp:57:25-57:37
    assign s8_norm_sub_107_v0 = limb_67_471; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__145_v0 = (__beopt_width_586 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:57:40-57:52; prim: /home/zyrv/vulsim/workload.cpp:57:40-57:52
    assign s8_norm_sub_109_v0 = limb_69_483; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__148_v0 = (__beopt_width_587 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:20-58:33; prim: /home/zyrv/vulsim/workload.cpp:58:20-58:33
    assign tmp_workload_top_int_130__150_v0 = ({62'h0, s8_norm_sub_109_v0}); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:50; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:50
    assign s8_norm_shift_112_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__150_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:58:37-58:56; prim: /home/zyrv/vulsim/workload.cpp:58:37-58:56
    assign tmp_workload_top_int_130__154_v0 = (__beopt_width_588 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:74; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:74
    assign s8_norm_shift_115_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__154_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:58:61-58:80; prim: /home/zyrv/vulsim/workload.cpp:58:61-58:80
    assign tmp_workload_top_int_130__158_v0 = (__beopt_width_589 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:26-59:39; prim: /home/zyrv/vulsim/workload.cpp:59:26-59:39
    assign s8_norm_sub_118_v0 = limb_76_501; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__161_v0 = (__beopt_width_590 & 130'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:59:42-59:55; prim: /home/zyrv/vulsim/workload.cpp:59:42-59:55
    assign s8_norm_sub_120_v0 = limb_78_519; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_256__164_v0 = (s8_norm_mul_72_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:20-60:33; prim: /home/zyrv/vulsim/workload.cpp:60:20-60:33
    assign tmp_workload_top_int_256__166_v0 = ({126'h0, s8_norm_sub_120_v0}); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:50; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:50
    assign s8_norm_shift_123_v0 = (32'h40 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__166_v0 << 32'h40)); // decl: /home/zyrv/vulsim/workload.cpp:60:37-60:56; prim: /home/zyrv/vulsim/workload.cpp:60:37-60:56
    assign tmp_workload_top_int_256__170_v0 = (s8_norm_mul_76_v0 & 256'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:74; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:74
    assign s8_norm_shift_126_v0 = (32'h80 >= 32'd256 ? 256'h0 : (tmp_workload_top_int_256__170_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:60:61-60:81; prim: /home/zyrv/vulsim/workload.cpp:60:61-60:81
    assign tmp_workload_top_int_129__174_v0 = (__beopt_width_591 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:61:20-61:32; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign s8_norm_add_130_v0 = limb_85_534; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_129__179_v0 = (rtlzz_pipe_194_s1 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:62:20-62:32; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign s8_norm_add_133_v0 = limb_87_549; // decl: <none>; prim: <none>
    assign s8_norm_hw_134_v0 = s8_norm_add_130_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:63:19-63:22; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign s8_norm_hw_135_v0 = s8_norm_add_133_v0[64:0]; // decl: /home/zyrv/vulsim/workload.cpp:64:19-64:22; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign tmp_workload_top_int_66__192_v0 = (tmp_workload_top_int_66__238_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign tmp_workload_top_int_66__194_v0 = (tmp_workload_top_int_66__243_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:71:34-71:46; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_mul_144_v0 = ({66'h0, mul_precision_324}); // decl: <none>; prim: <none>
    assign s8_norm_mul_148_v0 = ({64'h0, mul_precision_327}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__202_v0 = (rtlzz_pipe_198_s3 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:31; prim: /home/zyrv/vulsim/workload.cpp:63:5-63:34
    assign s8_norm_add_152_v0 = (tmp_workload_top_int_34__202_v0 + __beopt_width_388); // decl: /home/zyrv/vulsim/workload.cpp:73:19-73:46; prim: /home/zyrv/vulsim/workload.cpp:73:19-73:46
    assign tmp_workload_top_int_34__207_v0 = (__beopt_width_606 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:31; prim: /home/zyrv/vulsim/workload.cpp:64:5-64:34
    assign s8_norm_add_155_v0 = (tmp_workload_top_int_34__207_v0 + __beopt_width_391); // decl: /home/zyrv/vulsim/workload.cpp:74:19-74:46; prim: /home/zyrv/vulsim/workload.cpp:74:19-74:46
    assign tmp_workload_top_int_68__212_v0 = ({34'h0, s8_norm_add_152_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:31; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:31
    assign tmp_workload_top_int_68__214_v0 = ({34'h0, s8_norm_add_155_v0}); // decl: /home/zyrv/vulsim/workload.cpp:75:34-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:34-75:46
    assign s8_norm_mul_158_v0 = ({68'h0, mul_precision_330}); // decl: <none>; prim: <none>
    assign n60_v0 = s8_norm_mul_158_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:75:5-75:47; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign tmp_workload_top_int_68__217_v0 = (__beopt_width_609 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:25-76:37; prim: /home/zyrv/vulsim/workload.cpp:76:25-76:37
    assign s8_norm_sub_161_v0 = limb_103_561; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__220_v0 = (__beopt_width_610 & 68'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:76:40-76:52; prim: /home/zyrv/vulsim/workload.cpp:76:40-76:52
    assign s8_norm_sub_163_v0 = limb_105_573; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_130__223_v0 = (rtlzz_pipe_202_s5 & 130'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:20-77:33; prim: /home/zyrv/vulsim/workload.cpp:77:20-77:33
    assign tmp_workload_top_int_130__225_v0 = ({62'h0, s8_norm_sub_163_v0}); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:50; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:50
    assign s8_norm_shift_166_v0 = (32'h21 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__225_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:77:37-77:56; prim: /home/zyrv/vulsim/workload.cpp:77:37-77:56
    assign tmp_workload_top_int_130__229_v0 = (rtlzz_pipe_203_s5 & 130'hffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:74; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:74
    assign s8_norm_shift_169_v0 = (32'h42 >= 32'd130 ? 130'h0 : (tmp_workload_top_int_130__229_v0 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:77:61-77:80; prim: /home/zyrv/vulsim/workload.cpp:77:61-77:80
    assign s8_norm_mul_173_v0 = ({128'h0, mul_precision_333}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__238_v0 = (__beopt_width_617 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:79:19-79:31; prim: /home/zyrv/vulsim/workload.cpp:61:5-61:48
    assign s8_norm_add_177_v0 = limb_113_583; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__243_v0 = (__beopt_width_620 & 66'h1ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:80:19-80:31; prim: /home/zyrv/vulsim/workload.cpp:62:5-62:48
    assign s8_norm_add_180_v0 = limb_115_593; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_66__252_v0 = (s8_norm_add_177_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign tmp_workload_top_int_66__254_v0 = (s8_norm_add_180_v0 & 66'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:85:34-85:46; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_mul_187_v0 = ({66'h0, mul_precision_336}); // decl: <none>; prim: <none>
    assign s8_norm_mul_191_v0 = ({66'h0, mul_precision_339}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_34__262_v0 = (__beopt_width_627 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:31; prim: /home/zyrv/vulsim/workload.cpp:79:5-79:47
    assign s8_norm_add_195_v0 = (tmp_workload_top_int_34__262_v0 + __beopt_width_416); // decl: /home/zyrv/vulsim/workload.cpp:87:19-87:46; prim: /home/zyrv/vulsim/workload.cpp:87:19-87:46
    assign tmp_workload_top_int_34__267_v0 = (rtlzz_pipe_211_s6 & 34'h1ffffffff); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:31; prim: /home/zyrv/vulsim/workload.cpp:80:5-80:47
    assign s8_norm_add_198_v0 = (tmp_workload_top_int_34__267_v0 + __beopt_width_424); // decl: /home/zyrv/vulsim/workload.cpp:88:19-88:46; prim: /home/zyrv/vulsim/workload.cpp:88:19-88:46
    assign tmp_workload_top_int_68__272_v0 = ({34'h0, s8_norm_add_195_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:31; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:31
    assign tmp_workload_top_int_68__274_v0 = ({34'h0, s8_norm_add_198_v0}); // decl: /home/zyrv/vulsim/workload.cpp:89:34-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:34-89:46
    assign s8_norm_mul_201_v0 = ({68'h0, mul_precision_342}); // decl: <none>; prim: <none>
    assign n74_v0 = s8_norm_mul_201_v0[67:0]; // decl: /home/zyrv/vulsim/workload.cpp:89:5-89:47; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign tmp_workload_top_int_68__277_v0 = (rtlzz_pipe_212_s6 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:25-90:37; prim: /home/zyrv/vulsim/workload.cpp:90:25-90:37
    assign s8_norm_sub_204_v0 = limb_129_605; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_68__280_v0 = (__beopt_width_634 & 68'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:90:40-90:52; prim: /home/zyrv/vulsim/workload.cpp:90:40-90:52
    assign s8_norm_sub_206_v0 = limb_131_617; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__283_v0 = (s8_norm_mul_187_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:20-91:33; prim: /home/zyrv/vulsim/workload.cpp:91:20-91:33
    assign tmp_workload_top_int_132__285_v0 = ({64'h0, s8_norm_sub_206_v0}); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:50; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:50
    assign s8_norm_shift_209_v0 = (32'h21 >= 32'd132 ? 132'h0 : (tmp_workload_top_int_132__285_v0 << 32'h21)); // decl: /home/zyrv/vulsim/workload.cpp:91:37-91:56; prim: /home/zyrv/vulsim/workload.cpp:91:37-91:56
    assign tmp_workload_top_int_132__289_v0 = (s8_norm_mul_191_v0 & 132'h3ffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
    assign s8_norm_shift_212_v0 = (32'h42 >= 32'd132 ? 132'h0 : (rtlzz_pipe_135_s6 << 32'h42)); // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:80; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:80
    assign tmp_workload_top_int_132__293_v0 = ({2'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:92:26-92:39; prim: /home/zyrv/vulsim/workload.cpp:92:26-92:39
    assign s8_norm_sub_215_v0 = limb_138_635; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_132__296_v0 = (__beopt_width_635 & 132'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:92:42-92:55; prim: /home/zyrv/vulsim/workload.cpp:92:42-92:55
    assign s8_norm_sub_217_v0 = limb_140_653; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__299_v0 = ({128'h0, __beopt_width_310}); // decl: /home/zyrv/vulsim/workload.cpp:93:20-93:33; prim: /home/zyrv/vulsim/workload.cpp:93:20-93:33
    assign tmp_workload_top_int_258__301_v0 = ({126'h0, s8_norm_sub_217_v0}); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
    assign s8_norm_shift_220_v0 = (32'h41 >= 32'd258 ? 258'h0 : (rtlzz_pipe_142_s7 << 32'h41)); // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:56; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:56
    assign tmp_workload_top_int_258__305_v0 = (__beopt_width_636 & 258'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
    assign s8_norm_shift_223_v0 = (32'h82 >= 32'd258 ? 258'h0 : (rtlzz_pipe_144_s6 << 32'h82)); // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:81; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:81
    assign tmp_workload_top_int_258__309_v0 = ({2'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:94:26-94:39; prim: /home/zyrv/vulsim/workload.cpp:94:26-94:39
    assign s8_norm_sub_226_v0 = limb_147_683; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_258__312_v0 = ({2'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:94:42-94:55; prim: /home/zyrv/vulsim/workload.cpp:94:42-94:55
    assign s8_norm_sub_228_v0 = limb_149_713; // decl: <none>; prim: <none>
    assign tmp_workload_top_int_512__315_v0 = ({256'h0, __beopt_width_303}); // decl: /home/zyrv/vulsim/workload.cpp:95:20-95:33; prim: /home/zyrv/vulsim/workload.cpp:95:20-95:33
    assign tmp_workload_top_int_512__317_v0 = ({254'h0, s8_norm_sub_228_v0}); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:50; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:50
    assign s8_norm_shift_231_v0 = (32'h80 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__317_v0 << 32'h80)); // decl: /home/zyrv/vulsim/workload.cpp:95:37-95:57; prim: /home/zyrv/vulsim/workload.cpp:95:37-95:57
    assign tmp_workload_top_int_512__321_v0 = ({256'h0, __beopt_width_301}); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:75; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:75
    assign s8_norm_shift_234_v0 = (32'h100 >= 32'd512 ? 512'h0 : (tmp_workload_top_int_512__321_v0 << 32'h100)); // decl: /home/zyrv/vulsim/workload.cpp:95:62-95:82; prim: /home/zyrv/vulsim/workload.cpp:95:62-95:82
    assign tmp_workload_top_int_513__325_v0 = ({1'h0, __beopt_width_294}); // decl: /home/zyrv/vulsim/workload.cpp:96:20-96:33; prim: /home/zyrv/vulsim/workload.cpp:96:20-96:33
    assign tmp_workload_top_int_513__327_v0 = ({1'h0, c}); // decl: /home/zyrv/vulsim/workload.cpp:96:36-96:47; prim: /home/zyrv/vulsim/workload.cpp:96:36-96:47
    assign s8_norm_add_238_v0 = limb_157_758; // decl: <none>; prim: <none>
    assign y = s8_norm_add_238_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:12
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_535 = s8_norm_hw_0_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_537 = s8_norm_hw_1_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_539 = s8_norm_hw_0_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_542 = s8_norm_hw_1_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_545 = ({1'h0, s8_norm_add_18_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_546 = ({1'h0, s8_norm_add_21_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_547 = s8_norm_add_18_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_549 = s8_norm_add_21_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_551 = s8_norm_add_18_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_554 = s8_norm_add_21_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_557 = s8_norm_mul_28_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_558 = s8_norm_mul_32_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_559 = s8_norm_mul_28_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_560 = ({2'h0, s8_norm_mul_32_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_561 = s8_norm_mul_10_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_562 = s8_norm_mul_14_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_563 = s8_norm_hw_2_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_565 = s8_norm_hw_3_v0[127:64]; // decl: <none>; prim: <none>
    assign __beopt_width_567 = s8_norm_hw_2_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_570 = s8_norm_hw_3_v0[64:0]; // decl: <none>; prim: <none>
    assign __beopt_width_573 = ({1'h0, s8_norm_add_80_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_574 = ({1'h0, s8_norm_add_83_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_575 = s8_norm_add_80_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_577 = s8_norm_add_83_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_579 = s8_norm_add_80_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_582 = s8_norm_add_83_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_585 = s8_norm_mul_90_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_586 = s8_norm_mul_94_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_587 = s8_norm_mul_90_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_588 = ({2'h0, s8_norm_mul_94_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_589 = s8_norm_mul_72_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_590 = s8_norm_mul_76_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_591 = a[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_592 = a[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_594 = b[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_595 = b[255:128]; // decl: <none>; prim: <none>
    assign __beopt_width_599 = s8_norm_hw_134_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_601 = s8_norm_hw_135_v0[64:33]; // decl: <none>; prim: <none>
    assign __beopt_width_603 = s8_norm_hw_134_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_606 = s8_norm_hw_135_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_609 = s8_norm_mul_144_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_610 = s8_norm_mul_148_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_611 = s8_norm_mul_144_v0[129:0]; // decl: <none>; prim: <none>
    assign __beopt_width_612 = ({2'h0, s8_norm_mul_148_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_613 = s8_norm_add_130_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_615 = s8_norm_add_133_v0[128:65]; // decl: <none>; prim: <none>
    assign __beopt_width_617 = s8_norm_add_130_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_620 = s8_norm_add_133_v0[65:0]; // decl: <none>; prim: <none>
    assign __beopt_width_623 = s8_norm_add_177_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_625 = s8_norm_add_180_v0[65:33]; // decl: <none>; prim: <none>
    assign __beopt_width_627 = s8_norm_add_177_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_630 = s8_norm_add_180_v0[33:0]; // decl: <none>; prim: <none>
    assign __beopt_width_633 = s8_norm_mul_187_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_634 = s8_norm_mul_191_v0[67:0]; // decl: <none>; prim: <none>
    assign __beopt_width_635 = s8_norm_mul_173_v0[131:0]; // decl: <none>; prim: <none>
    assign __beopt_width_636 = ({2'h0, s8_norm_mul_173_v0}); // decl: <none>; prim: <none>
    assign __beopt_width_292 = limb_216_798; // decl: <none>; prim: <none>
    assign __beopt_width_294 = limb_217_838; // decl: <none>; prim: <none>
    assign __beopt_width_295 = limb_218_863; // decl: <none>; prim: <none>
    assign __beopt_width_297 = limb_219_888; // decl: <none>; prim: <none>
    assign __beopt_width_299 = limb_220_908; // decl: <none>; prim: <none>
    assign __beopt_width_301 = limb_221_928; // decl: <none>; prim: <none>
    assign __beopt_width_302 = limb_222_948; // decl: <none>; prim: <none>
    assign __beopt_width_303 = limb_223_968; // decl: <none>; prim: <none>
    assign __beopt_width_305 = limb_224_983; // decl: <none>; prim: <none>
    assign __beopt_width_307 = limb_225_998; // decl: <none>; prim: <none>
    assign __beopt_width_309 = limb_226_1013; // decl: <none>; prim: <none>
    assign __beopt_width_310 = limb_227_1028; // decl: <none>; prim: <none>
    assign __beopt_width_311 = limb_228_1043; // decl: <none>; prim: <none>
    assign __beopt_width_313 = limb_229_1058; // decl: <none>; prim: <none>
    assign __beopt_width_315 = limb_230_1073; // decl: <none>; prim: <none>
    assign __beopt_width_317 = limb_231_1088; // decl: <none>; prim: <none>
    assign __beopt_width_296 = (rtlzz_pipe_262_s2 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_304 = (rtlzz_pipe_263_s3 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_312 = (rtlzz_pipe_264_s4 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_318 = (rtlzz_pipe_265_s5 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_322 = (rtlzz_pipe_266_s5 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_328 = (rtlzz_pipe_267_s7 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_332 = (rtlzz_pipe_268_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:18-19:20
    assign __beopt_width_336 = (rtlzz_pipe_269_s6 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
    assign __beopt_width_342 = (rtlzz_pipe_270_s6 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_346 = (rtlzz_pipe_271_s7 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_352 = (__beopt_width_353 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
    assign __beopt_width_357 = (rtlzz_pipe_273_s1 & 65'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
    assign __beopt_width_360 = (__beopt_width_362 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_363 = (__beopt_width_366 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_367 = (__beopt_width_372 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:40:19-40:21
    assign __beopt_width_370 = (__beopt_width_376 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:41:19-41:21
    assign __beopt_width_374 = (rtlzz_pipe_278_s2 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign __beopt_width_378 = (rtlzz_pipe_279_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    assign __beopt_width_382 = (rtlzz_pipe_280_s3 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_385 = (__beopt_width_393 & 64'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_388 = (rtlzz_pipe_282_s3 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:61:20-61:32
    assign __beopt_width_391 = (__beopt_width_399 & 34'hffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:62:20-62:32
    assign __beopt_width_395 = (rtlzz_pipe_284_s4 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_397 = (rtlzz_pipe_285_s5 & 128'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_401 = (rtlzz_pipe_286_s3 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:19-15:20
    assign __beopt_width_404 = (rtlzz_pipe_287_s5 & 66'hffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
    assign __beopt_width_407 = (__beopt_width_417 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_411 = (__beopt_width_420 & 66'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_416 = (__beopt_width_423 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:19-63:22
    assign __beopt_width_424 = (rtlzz_pipe_291_s6 & 34'h1ffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:64:19-64:22
    assign __beopt_width_298 = ({64'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_314 = ({64'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_321 = ({1'h0, __beopt_width_535}); // decl: <none>; prim: <none>
    assign __beopt_width_325 = ({1'h0, __beopt_width_537}); // decl: <none>; prim: <none>
    assign __beopt_width_329 = ({32'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_333 = ({32'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_337 = ({2'h0, __beopt_width_547}); // decl: <none>; prim: <none>
    assign __beopt_width_340 = ({2'h0, __beopt_width_549}); // decl: <none>; prim: <none>
    assign __beopt_width_344 = ({64'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_349 = ({64'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_353 = ({1'h0, __beopt_width_563}); // decl: <none>; prim: <none>
    assign __beopt_width_356 = ({1'h0, __beopt_width_565}); // decl: <none>; prim: <none>
    assign __beopt_width_362 = ({32'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_366 = ({32'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_372 = ({2'h0, __beopt_width_575}); // decl: <none>; prim: <none>
    assign __beopt_width_376 = ({2'h0, __beopt_width_577}); // decl: <none>; prim: <none>
    assign __beopt_width_380 = ({1'h0, __beopt_width_592}); // decl: <none>; prim: <none>
    assign __beopt_width_386 = ({1'h0, __beopt_width_595}); // decl: <none>; prim: <none>
    assign __beopt_width_389 = ({32'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_393 = ({32'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_396 = ({2'h0, __beopt_width_599}); // decl: <none>; prim: <none>
    assign __beopt_width_399 = ({2'h0, __beopt_width_601}); // decl: <none>; prim: <none>
    assign __beopt_width_403 = ({64'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_406 = ({64'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_410 = ({2'h0, __beopt_width_613}); // decl: <none>; prim: <none>
    assign __beopt_width_413 = ({2'h0, __beopt_width_615}); // decl: <none>; prim: <none>
    assign __beopt_width_417 = ({33'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_420 = ({33'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign __beopt_width_423 = ({1'h0, __beopt_width_623}); // decl: <none>; prim: <none>
    assign __beopt_width_427 = ({1'h0, __beopt_width_625}); // decl: <none>; prim: <none>
    assign mul_precision_292 = tmp_workload_top_int_128__8_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_293 = tmp_workload_top_int_128__10_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_294 = arith_original_343; // decl: <none>; prim: <none>
    assign mul_precision_295 = __beopt_width_296[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_296 = __beopt_width_304[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_297 = arith_original_344; // decl: <none>; prim: <none>
    assign mul_precision_298 = tmp_workload_top_int_66__32_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_299 = tmp_workload_top_int_66__34_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_300 = arith_original_345; // decl: <none>; prim: <none>
    assign mul_precision_301 = __beopt_width_322[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_302 = __beopt_width_328[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_303 = arith_original_346; // decl: <none>; prim: <none>
    assign mul_precision_304 = tmp_workload_top_int_68__52_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_305 = tmp_workload_top_int_68__54_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_306 = arith_original_347; // decl: <none>; prim: <none>
    assign mul_precision_307 = tmp_workload_top_int_128__93_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_308 = tmp_workload_top_int_128__95_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_309 = arith_original_348; // decl: <none>; prim: <none>
    assign mul_precision_310 = __beopt_width_342[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_311 = __beopt_width_346[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_312 = arith_original_349; // decl: <none>; prim: <none>
    assign mul_precision_313 = tmp_workload_top_int_66__117_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_314 = tmp_workload_top_int_66__119_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_315 = arith_original_350; // decl: <none>; prim: <none>
    assign mul_precision_316 = __beopt_width_360[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_317 = __beopt_width_363[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_318 = arith_original_351; // decl: <none>; prim: <none>
    assign mul_precision_319 = tmp_workload_top_int_68__137_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_320 = tmp_workload_top_int_68__139_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_321 = arith_original_352; // decl: <none>; prim: <none>
    assign mul_precision_322 = tmp_workload_top_int_66__192_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_323 = tmp_workload_top_int_66__194_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_324 = arith_original_353; // decl: <none>; prim: <none>
    assign mul_precision_325 = __beopt_width_382[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_326 = __beopt_width_385[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_327 = arith_original_354; // decl: <none>; prim: <none>
    assign mul_precision_328 = tmp_workload_top_int_68__212_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_329 = tmp_workload_top_int_68__214_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_330 = arith_original_355; // decl: <none>; prim: <none>
    assign mul_precision_331 = __beopt_width_395[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_332 = __beopt_width_397[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_333 = arith_original_356; // decl: <none>; prim: <none>
    assign mul_precision_334 = tmp_workload_top_int_66__252_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_335 = tmp_workload_top_int_66__254_v0[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_336 = arith_original_357; // decl: <none>; prim: <none>
    assign mul_precision_337 = __beopt_width_407[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_338 = __beopt_width_411[32:0]; // decl: <none>; prim: <none>
    assign mul_precision_339 = arith_original_358; // decl: <none>; prim: <none>
    assign mul_precision_340 = tmp_workload_top_int_68__272_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_341 = tmp_workload_top_int_68__274_v0[33:0]; // decl: <none>; prim: <none>
    assign mul_precision_342 = arith_original_359; // decl: <none>; prim: <none>
    assign arith_original_343 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_292_s3))) * $unsigned(128'($unsigned(rtlzz_pipe_293_s3))))); // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
    assign arith_original_344 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_295_s5))) * $unsigned(128'($unsigned(rtlzz_pipe_296_s5))))); // decl: /home/zyrv/vulsim/workload.cpp:24:19-24:46; prim: /home/zyrv/vulsim/workload.cpp:24:19-24:46
    assign arith_original_345 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_298_s5))) * $unsigned(66'($unsigned(mul_precision_299))))); // decl: /home/zyrv/vulsim/workload.cpp:31:19-31:46; prim: /home/zyrv/vulsim/workload.cpp:31:19-31:46
    assign arith_original_346 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_301_s7))) * $unsigned(64'($unsigned(mul_precision_302))))); // decl: /home/zyrv/vulsim/workload.cpp:32:19-32:46; prim: /home/zyrv/vulsim/workload.cpp:32:19-32:46
    assign arith_original_347 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_304_s7))) * $unsigned(68'($unsigned(mul_precision_305))))); // decl: /home/zyrv/vulsim/workload.cpp:35:19-35:46; prim: /home/zyrv/vulsim/workload.cpp:35:19-35:46
    assign arith_original_348 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_307_s6))) * $unsigned(128'($unsigned(rtlzz_pipe_308_s6))))); // decl: /home/zyrv/vulsim/workload.cpp:44:20-44:49; prim: /home/zyrv/vulsim/workload.cpp:44:20-44:49
    assign arith_original_349 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_310_s7))) * $unsigned(128'($unsigned(mul_precision_311))))); // decl: /home/zyrv/vulsim/workload.cpp:45:20-45:49; prim: /home/zyrv/vulsim/workload.cpp:45:20-45:49
    assign arith_original_350 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_313_s7))) * $unsigned(66'($unsigned(mul_precision_314))))); // decl: /home/zyrv/vulsim/workload.cpp:52:19-52:46; prim: /home/zyrv/vulsim/workload.cpp:52:19-52:46
    assign arith_original_351 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_316_s7))) * $unsigned(64'($unsigned(mul_precision_317))))); // decl: /home/zyrv/vulsim/workload.cpp:53:19-53:46; prim: /home/zyrv/vulsim/workload.cpp:53:19-53:46
    assign arith_original_352 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_319_s7))) * $unsigned(68'($unsigned(mul_precision_320))))); // decl: /home/zyrv/vulsim/workload.cpp:56:19-56:46; prim: /home/zyrv/vulsim/workload.cpp:56:19-56:46
    assign arith_original_353 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_322_s4))) * $unsigned(66'($unsigned(mul_precision_323))))); // decl: /home/zyrv/vulsim/workload.cpp:71:19-71:46; prim: /home/zyrv/vulsim/workload.cpp:71:19-71:46
    assign arith_original_354 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_325_s4))) * $unsigned(64'($unsigned(mul_precision_326))))); // decl: /home/zyrv/vulsim/workload.cpp:72:19-72:46; prim: /home/zyrv/vulsim/workload.cpp:72:19-72:46
    assign arith_original_355 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_328_s4))) * $unsigned(68'($unsigned(mul_precision_329))))); // decl: /home/zyrv/vulsim/workload.cpp:75:19-75:46; prim: /home/zyrv/vulsim/workload.cpp:75:19-75:46
    assign arith_original_356 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_331_s5))) * $unsigned(128'($unsigned(mul_precision_332))))); // decl: /home/zyrv/vulsim/workload.cpp:78:20-78:49; prim: /home/zyrv/vulsim/workload.cpp:78:20-78:49
    assign arith_original_357 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_334_s5))) * $unsigned(66'($unsigned(mul_precision_335))))); // decl: /home/zyrv/vulsim/workload.cpp:85:19-85:46; prim: /home/zyrv/vulsim/workload.cpp:85:19-85:46
    assign arith_original_358 = 66'(($unsigned(66'($unsigned(rtlzz_pipe_337_s5))) * $unsigned(66'($unsigned(mul_precision_338))))); // decl: /home/zyrv/vulsim/workload.cpp:86:19-86:46; prim: /home/zyrv/vulsim/workload.cpp:86:19-86:46
    assign arith_original_359 = 68'(($unsigned(68'($unsigned(rtlzz_pipe_340_s6))) * $unsigned(68'($unsigned(mul_precision_341))))); // decl: /home/zyrv/vulsim/workload.cpp:89:19-89:46; prim: /home/zyrv/vulsim/workload.cpp:89:19-89:46
    assign limb_13_360 = tmp_workload_top_int_65__18_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_13_361 = __beopt_width_312[63:0]; // decl: <none>; prim: <none>
    assign limb_13_362 = 65'((({1'h0, rtlzz_pipe_360_s4}) + ({1'h0, limb_13_361}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_13_363 = limb_13_362[63:0]; // decl: <none>; prim: <none>
    assign limb_13_364 = limb_13_362[64]; // decl: <none>; prim: <none>
    assign limb_13_365 = tmp_workload_top_int_65__18_v0[64]; // decl: <none>; prim: <none>
    assign limb_13_366 = __beopt_width_312[64]; // decl: <none>; prim: <none>
    assign limb_13_367 = 2'((({1'h0, rtlzz_pipe_365_s4}) + ({1'h0, limb_13_366}) + ({1'h0, limb_13_364}))); // decl: <none>; prim: <none>
    assign limb_13_368 = limb_13_367[0]; // decl: <none>; prim: <none>
    assign limb_13_369 = {limb_13_368, limb_13_363}; // decl: <none>; prim: <none>
    assign limb_15_370 = tmp_workload_top_int_65__23_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_15_371 = __beopt_width_318[63:0]; // decl: <none>; prim: <none>
    assign limb_15_372 = 65'((({1'h0, rtlzz_pipe_370_s5}) + ({1'h0, limb_15_371}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_15_373 = limb_15_372[63:0]; // decl: <none>; prim: <none>
    assign limb_15_374 = limb_15_372[64]; // decl: <none>; prim: <none>
    assign limb_15_375 = tmp_workload_top_int_65__23_v0[64]; // decl: <none>; prim: <none>
    assign limb_15_376 = __beopt_width_318[64]; // decl: <none>; prim: <none>
    assign limb_15_377 = 2'((({1'h0, rtlzz_pipe_375_s5}) + ({1'h0, limb_15_376}) + ({1'h0, limb_15_374}))); // decl: <none>; prim: <none>
    assign limb_15_378 = limb_15_377[0]; // decl: <none>; prim: <none>
    assign limb_15_379 = {limb_15_378, limb_15_373}; // decl: <none>; prim: <none>
    assign limb_29_380 = n20_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_381 = tmp_workload_top_int_68__57_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_29_382 = (~limb_29_381); // decl: <none>; prim: <none>
    assign limb_29_383 = 65'((({1'h0, limb_29_380}) + ({1'h0, rtlzz_pipe_382_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_29_384 = limb_29_383[63:0]; // decl: <none>; prim: <none>
    assign limb_29_385 = limb_29_383[64]; // decl: <none>; prim: <none>
    assign limb_29_386 = n20_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_387 = tmp_workload_top_int_68__57_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_29_388 = (~limb_29_387); // decl: <none>; prim: <none>
    assign limb_29_389 = 5'((({1'h0, limb_29_386}) + ({1'h0, rtlzz_pipe_388_s7}) + ({4'h0, limb_29_385}))); // decl: <none>; prim: <none>
    assign limb_29_390 = limb_29_389[3:0]; // decl: <none>; prim: <none>
    assign limb_29_391 = {limb_29_390, limb_29_384}; // decl: <none>; prim: <none>
    assign limb_31_392 = s8_norm_sub_45_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_393 = tmp_workload_top_int_68__60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_31_394 = (~limb_31_393); // decl: <none>; prim: <none>
    assign limb_31_395 = 65'((({1'h0, limb_31_392}) + ({1'h0, limb_31_394}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_31_396 = limb_31_395[63:0]; // decl: <none>; prim: <none>
    assign limb_31_397 = limb_31_395[64]; // decl: <none>; prim: <none>
    assign limb_31_398 = s8_norm_sub_45_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_399 = tmp_workload_top_int_68__60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_31_400 = (~limb_31_399); // decl: <none>; prim: <none>
    assign limb_31_401 = 5'((({1'h0, limb_31_398}) + ({1'h0, limb_31_400}) + ({4'h0, limb_31_397}))); // decl: <none>; prim: <none>
    assign limb_31_402 = limb_31_401[3:0]; // decl: <none>; prim: <none>
    assign limb_31_403 = {limb_31_402, limb_31_396}; // decl: <none>; prim: <none>
    assign limb_38_404 = __beopt_width_317[63:0]; // decl: <none>; prim: <none>
    assign limb_38_405 = tmp_workload_top_int_130__73_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_38_406 = (~limb_38_405); // decl: <none>; prim: <none>
    assign limb_38_407 = 65'((({1'h0, limb_38_404}) + ({1'h0, rtlzz_pipe_406_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_38_408 = limb_38_407[63:0]; // decl: <none>; prim: <none>
    assign limb_38_409 = limb_38_407[64]; // decl: <none>; prim: <none>
    assign limb_38_410 = __beopt_width_317[127:64]; // decl: <none>; prim: <none>
    assign limb_38_411 = tmp_workload_top_int_130__73_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_38_412 = (~limb_38_411); // decl: <none>; prim: <none>
    assign limb_38_413 = 65'((({1'h0, limb_38_410}) + ({1'h0, rtlzz_pipe_412_s7}) + ({64'h0, limb_38_409}))); // decl: <none>; prim: <none>
    assign limb_38_414 = limb_38_413[63:0]; // decl: <none>; prim: <none>
    assign limb_38_415 = limb_38_413[64]; // decl: <none>; prim: <none>
    assign limb_38_416 = __beopt_width_317[129:128]; // decl: <none>; prim: <none>
    assign limb_38_417 = tmp_workload_top_int_130__73_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_38_418 = (~limb_38_417); // decl: <none>; prim: <none>
    assign limb_38_419 = 3'((({1'h0, limb_38_416}) + ({1'h0, rtlzz_pipe_418_s7}) + ({2'h0, limb_38_415}))); // decl: <none>; prim: <none>
    assign limb_38_420 = limb_38_419[1:0]; // decl: <none>; prim: <none>
    assign limb_38_421 = {limb_38_420, limb_38_414, limb_38_408}; // decl: <none>; prim: <none>
    assign limb_40_422 = s8_norm_sub_56_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_423 = tmp_workload_top_int_130__76_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_40_424 = (~limb_40_423); // decl: <none>; prim: <none>
    assign limb_40_425 = 65'((({1'h0, limb_40_422}) + ({1'h0, rtlzz_pipe_424_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_40_426 = limb_40_425[63:0]; // decl: <none>; prim: <none>
    assign limb_40_427 = limb_40_425[64]; // decl: <none>; prim: <none>
    assign limb_40_428 = s8_norm_sub_56_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_429 = tmp_workload_top_int_130__76_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_40_430 = (~limb_40_429); // decl: <none>; prim: <none>
    assign limb_40_431 = 65'((({1'h0, limb_40_428}) + ({1'h0, rtlzz_pipe_430_s7}) + ({64'h0, limb_40_427}))); // decl: <none>; prim: <none>
    assign limb_40_432 = limb_40_431[63:0]; // decl: <none>; prim: <none>
    assign limb_40_433 = limb_40_431[64]; // decl: <none>; prim: <none>
    assign limb_40_434 = s8_norm_sub_56_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_435 = tmp_workload_top_int_130__76_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_40_436 = (~limb_40_435); // decl: <none>; prim: <none>
    assign limb_40_437 = 3'((({1'h0, limb_40_434}) + ({1'h0, rtlzz_pipe_436_s7}) + ({2'h0, limb_40_433}))); // decl: <none>; prim: <none>
    assign limb_40_438 = limb_40_437[1:0]; // decl: <none>; prim: <none>
    assign limb_40_439 = {limb_40_438, limb_40_432, limb_40_426}; // decl: <none>; prim: <none>
    assign limb_51_440 = tmp_workload_top_int_65__103_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_51_441 = __beopt_width_352[63:0]; // decl: <none>; prim: <none>
    assign limb_51_442 = 65'((({1'h0, limb_51_440}) + ({1'h0, rtlzz_pipe_441_s6}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_51_443 = limb_51_442[63:0]; // decl: <none>; prim: <none>
    assign limb_51_444 = limb_51_442[64]; // decl: <none>; prim: <none>
    assign limb_51_445 = tmp_workload_top_int_65__103_v0[64]; // decl: <none>; prim: <none>
    assign limb_51_446 = __beopt_width_352[64]; // decl: <none>; prim: <none>
    assign limb_51_447 = 2'((({1'h0, limb_51_445}) + ({1'h0, rtlzz_pipe_446_s6}) + ({1'h0, limb_51_444}))); // decl: <none>; prim: <none>
    assign limb_51_448 = limb_51_447[0]; // decl: <none>; prim: <none>
    assign limb_51_449 = {limb_51_448, limb_51_443}; // decl: <none>; prim: <none>
    assign limb_53_450 = tmp_workload_top_int_65__108_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_53_451 = __beopt_width_357[63:0]; // decl: <none>; prim: <none>
    assign limb_53_452 = 65'((({1'h0, limb_53_450}) + ({1'h0, rtlzz_pipe_451_s7}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_53_453 = limb_53_452[63:0]; // decl: <none>; prim: <none>
    assign limb_53_454 = limb_53_452[64]; // decl: <none>; prim: <none>
    assign limb_53_455 = tmp_workload_top_int_65__108_v0[64]; // decl: <none>; prim: <none>
    assign limb_53_456 = __beopt_width_357[64]; // decl: <none>; prim: <none>
    assign limb_53_457 = 2'((({1'h0, limb_53_455}) + ({1'h0, rtlzz_pipe_456_s7}) + ({1'h0, limb_53_454}))); // decl: <none>; prim: <none>
    assign limb_53_458 = limb_53_457[0]; // decl: <none>; prim: <none>
    assign limb_53_459 = {limb_53_458, limb_53_453}; // decl: <none>; prim: <none>
    assign limb_67_460 = n41_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_461 = tmp_workload_top_int_68__142_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_67_462 = (~limb_67_461); // decl: <none>; prim: <none>
    assign limb_67_463 = 65'((({1'h0, limb_67_460}) + ({1'h0, limb_67_462}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_67_464 = limb_67_463[63:0]; // decl: <none>; prim: <none>
    assign limb_67_465 = limb_67_463[64]; // decl: <none>; prim: <none>
    assign limb_67_466 = n41_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_467 = tmp_workload_top_int_68__142_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_67_468 = (~limb_67_467); // decl: <none>; prim: <none>
    assign limb_67_469 = 5'((({1'h0, limb_67_466}) + ({1'h0, limb_67_468}) + ({4'h0, limb_67_465}))); // decl: <none>; prim: <none>
    assign limb_67_470 = limb_67_469[3:0]; // decl: <none>; prim: <none>
    assign limb_67_471 = {limb_67_470, limb_67_464}; // decl: <none>; prim: <none>
    assign limb_69_472 = s8_norm_sub_107_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_473 = tmp_workload_top_int_68__145_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_69_474 = (~limb_69_473); // decl: <none>; prim: <none>
    assign limb_69_475 = 65'((({1'h0, limb_69_472}) + ({1'h0, limb_69_474}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_69_476 = limb_69_475[63:0]; // decl: <none>; prim: <none>
    assign limb_69_477 = limb_69_475[64]; // decl: <none>; prim: <none>
    assign limb_69_478 = s8_norm_sub_107_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_479 = tmp_workload_top_int_68__145_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_69_480 = (~limb_69_479); // decl: <none>; prim: <none>
    assign limb_69_481 = 5'((({1'h0, limb_69_478}) + ({1'h0, limb_69_480}) + ({4'h0, limb_69_477}))); // decl: <none>; prim: <none>
    assign limb_69_482 = limb_69_481[3:0]; // decl: <none>; prim: <none>
    assign limb_69_483 = {limb_69_482, limb_69_476}; // decl: <none>; prim: <none>
    assign limb_76_484 = __beopt_width_313[63:0]; // decl: <none>; prim: <none>
    assign limb_76_485 = tmp_workload_top_int_130__158_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_76_486 = (~limb_76_485); // decl: <none>; prim: <none>
    assign limb_76_487 = 65'((({1'h0, limb_76_484}) + ({1'h0, rtlzz_pipe_486_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_76_488 = limb_76_487[63:0]; // decl: <none>; prim: <none>
    assign limb_76_489 = limb_76_487[64]; // decl: <none>; prim: <none>
    assign limb_76_490 = __beopt_width_313[127:64]; // decl: <none>; prim: <none>
    assign limb_76_491 = tmp_workload_top_int_130__158_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_76_492 = (~limb_76_491); // decl: <none>; prim: <none>
    assign limb_76_493 = 65'((({1'h0, limb_76_490}) + ({1'h0, rtlzz_pipe_492_s7}) + ({64'h0, limb_76_489}))); // decl: <none>; prim: <none>
    assign limb_76_494 = limb_76_493[63:0]; // decl: <none>; prim: <none>
    assign limb_76_495 = limb_76_493[64]; // decl: <none>; prim: <none>
    assign limb_76_496 = __beopt_width_313[129:128]; // decl: <none>; prim: <none>
    assign limb_76_497 = tmp_workload_top_int_130__158_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_76_498 = (~limb_76_497); // decl: <none>; prim: <none>
    assign limb_76_499 = 3'((({1'h0, limb_76_496}) + ({1'h0, rtlzz_pipe_498_s7}) + ({2'h0, limb_76_495}))); // decl: <none>; prim: <none>
    assign limb_76_500 = limb_76_499[1:0]; // decl: <none>; prim: <none>
    assign limb_76_501 = {limb_76_500, limb_76_494, limb_76_488}; // decl: <none>; prim: <none>
    assign limb_78_502 = s8_norm_sub_118_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_503 = tmp_workload_top_int_130__161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_78_504 = (~limb_78_503); // decl: <none>; prim: <none>
    assign limb_78_505 = 65'((({1'h0, limb_78_502}) + ({1'h0, limb_78_504}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_78_506 = limb_78_505[63:0]; // decl: <none>; prim: <none>
    assign limb_78_507 = limb_78_505[64]; // decl: <none>; prim: <none>
    assign limb_78_508 = s8_norm_sub_118_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_509 = tmp_workload_top_int_130__161_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_78_510 = (~limb_78_509); // decl: <none>; prim: <none>
    assign limb_78_511 = 65'((({1'h0, limb_78_508}) + ({1'h0, limb_78_510}) + ({64'h0, limb_78_507}))); // decl: <none>; prim: <none>
    assign limb_78_512 = limb_78_511[63:0]; // decl: <none>; prim: <none>
    assign limb_78_513 = limb_78_511[64]; // decl: <none>; prim: <none>
    assign limb_78_514 = s8_norm_sub_118_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_515 = tmp_workload_top_int_130__161_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_78_516 = (~limb_78_515); // decl: <none>; prim: <none>
    assign limb_78_517 = 3'((({1'h0, limb_78_514}) + ({1'h0, limb_78_516}) + ({2'h0, limb_78_513}))); // decl: <none>; prim: <none>
    assign limb_78_518 = limb_78_517[1:0]; // decl: <none>; prim: <none>
    assign limb_78_519 = {limb_78_518, limb_78_512, limb_78_506}; // decl: <none>; prim: <none>
    assign limb_85_520 = tmp_workload_top_int_129__174_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_85_521 = __beopt_width_374[63:0]; // decl: <none>; prim: <none>
    assign limb_85_522 = 65'((({1'h0, rtlzz_pipe_520_s2}) + ({1'h0, limb_85_521}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_85_523 = limb_85_522[63:0]; // decl: <none>; prim: <none>
    assign limb_85_524 = limb_85_522[64]; // decl: <none>; prim: <none>
    assign limb_85_525 = tmp_workload_top_int_129__174_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_85_526 = __beopt_width_374[127:64]; // decl: <none>; prim: <none>
    assign limb_85_527 = 65'((({1'h0, rtlzz_pipe_525_s2}) + ({1'h0, limb_85_526}) + ({64'h0, limb_85_524}))); // decl: <none>; prim: <none>
    assign limb_85_528 = limb_85_527[63:0]; // decl: <none>; prim: <none>
    assign limb_85_529 = limb_85_527[64]; // decl: <none>; prim: <none>
    assign limb_85_530 = tmp_workload_top_int_129__174_v0[128]; // decl: <none>; prim: <none>
    assign limb_85_531 = __beopt_width_374[128]; // decl: <none>; prim: <none>
    assign limb_85_532 = 2'((({1'h0, rtlzz_pipe_530_s2}) + ({1'h0, limb_85_531}) + ({1'h0, limb_85_529}))); // decl: <none>; prim: <none>
    assign limb_85_533 = limb_85_532[0]; // decl: <none>; prim: <none>
    assign limb_85_534 = {limb_85_533, limb_85_528, limb_85_523}; // decl: <none>; prim: <none>
    assign limb_87_535 = tmp_workload_top_int_129__179_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_87_536 = __beopt_width_378[63:0]; // decl: <none>; prim: <none>
    assign limb_87_537 = 65'((({1'h0, rtlzz_pipe_535_s4}) + ({1'h0, limb_87_536}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_87_538 = limb_87_537[63:0]; // decl: <none>; prim: <none>
    assign limb_87_539 = limb_87_537[64]; // decl: <none>; prim: <none>
    assign limb_87_540 = tmp_workload_top_int_129__179_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_87_541 = __beopt_width_378[127:64]; // decl: <none>; prim: <none>
    assign limb_87_542 = 65'((({1'h0, rtlzz_pipe_540_s4}) + ({1'h0, limb_87_541}) + ({64'h0, limb_87_539}))); // decl: <none>; prim: <none>
    assign limb_87_543 = limb_87_542[63:0]; // decl: <none>; prim: <none>
    assign limb_87_544 = limb_87_542[64]; // decl: <none>; prim: <none>
    assign limb_87_545 = tmp_workload_top_int_129__179_v0[128]; // decl: <none>; prim: <none>
    assign limb_87_546 = __beopt_width_378[128]; // decl: <none>; prim: <none>
    assign limb_87_547 = 2'((({1'h0, rtlzz_pipe_545_s4}) + ({1'h0, limb_87_546}) + ({1'h0, limb_87_544}))); // decl: <none>; prim: <none>
    assign limb_87_548 = limb_87_547[0]; // decl: <none>; prim: <none>
    assign limb_87_549 = {limb_87_548, limb_87_543, limb_87_538}; // decl: <none>; prim: <none>
    assign limb_103_550 = n60_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_551 = tmp_workload_top_int_68__217_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_103_552 = (~limb_103_551); // decl: <none>; prim: <none>
    assign limb_103_553 = 65'((({1'h0, limb_103_550}) + ({1'h0, limb_103_552}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_103_554 = limb_103_553[63:0]; // decl: <none>; prim: <none>
    assign limb_103_555 = limb_103_553[64]; // decl: <none>; prim: <none>
    assign limb_103_556 = n60_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_557 = tmp_workload_top_int_68__217_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_103_558 = (~limb_103_557); // decl: <none>; prim: <none>
    assign limb_103_559 = 5'((({1'h0, rtlzz_pipe_556_s5}) + ({1'h0, rtlzz_pipe_558_s5}) + ({4'h0, rtlzz_pipe_555_s5}))); // decl: <none>; prim: <none>
    assign limb_103_560 = limb_103_559[3:0]; // decl: <none>; prim: <none>
    assign limb_103_561 = {limb_103_560, rtlzz_pipe_554_s5}; // decl: <none>; prim: <none>
    assign limb_105_562 = s8_norm_sub_161_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_563 = tmp_workload_top_int_68__220_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_105_564 = (~limb_105_563); // decl: <none>; prim: <none>
    assign limb_105_565 = 65'((({1'h0, rtlzz_pipe_562_s6}) + ({1'h0, rtlzz_pipe_564_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_105_566 = limb_105_565[63:0]; // decl: <none>; prim: <none>
    assign limb_105_567 = limb_105_565[64]; // decl: <none>; prim: <none>
    assign limb_105_568 = s8_norm_sub_161_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_569 = tmp_workload_top_int_68__220_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_105_570 = (~rtlzz_pipe_569_s5); // decl: <none>; prim: <none>
    assign limb_105_571 = 5'((({1'h0, rtlzz_pipe_568_s6}) + ({1'h0, rtlzz_pipe_570_s6}) + ({4'h0, limb_105_567}))); // decl: <none>; prim: <none>
    assign limb_105_572 = limb_105_571[3:0]; // decl: <none>; prim: <none>
    assign limb_105_573 = {limb_105_572, limb_105_566}; // decl: <none>; prim: <none>
    assign limb_113_574 = tmp_workload_top_int_66__238_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_113_575 = __beopt_width_401[63:0]; // decl: <none>; prim: <none>
    assign limb_113_576 = 65'((({1'h0, rtlzz_pipe_574_s3}) + ({1'h0, limb_113_575}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_113_577 = limb_113_576[63:0]; // decl: <none>; prim: <none>
    assign limb_113_578 = limb_113_576[64]; // decl: <none>; prim: <none>
    assign limb_113_579 = tmp_workload_top_int_66__238_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_113_580 = __beopt_width_401[65:64]; // decl: <none>; prim: <none>
    assign limb_113_581 = 3'((({1'h0, rtlzz_pipe_579_s3}) + ({1'h0, limb_113_580}) + ({2'h0, limb_113_578}))); // decl: <none>; prim: <none>
    assign limb_113_582 = limb_113_581[1:0]; // decl: <none>; prim: <none>
    assign limb_113_583 = {limb_113_582, limb_113_577}; // decl: <none>; prim: <none>
    assign limb_115_584 = tmp_workload_top_int_66__243_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_115_585 = __beopt_width_404[63:0]; // decl: <none>; prim: <none>
    assign limb_115_586 = 65'((({1'h0, rtlzz_pipe_584_s5}) + ({1'h0, limb_115_585}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_115_587 = limb_115_586[63:0]; // decl: <none>; prim: <none>
    assign limb_115_588 = limb_115_586[64]; // decl: <none>; prim: <none>
    assign limb_115_589 = tmp_workload_top_int_66__243_v0[65:64]; // decl: <none>; prim: <none>
    assign limb_115_590 = __beopt_width_404[65:64]; // decl: <none>; prim: <none>
    assign limb_115_591 = 3'((({1'h0, rtlzz_pipe_589_s5}) + ({1'h0, limb_115_590}) + ({2'h0, limb_115_588}))); // decl: <none>; prim: <none>
    assign limb_115_592 = limb_115_591[1:0]; // decl: <none>; prim: <none>
    assign limb_115_593 = {limb_115_592, limb_115_587}; // decl: <none>; prim: <none>
    assign limb_129_594 = n74_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_595 = tmp_workload_top_int_68__277_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_129_596 = (~limb_129_595); // decl: <none>; prim: <none>
    assign limb_129_597 = 65'((({1'h0, limb_129_594}) + ({1'h0, limb_129_596}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_129_598 = limb_129_597[63:0]; // decl: <none>; prim: <none>
    assign limb_129_599 = limb_129_597[64]; // decl: <none>; prim: <none>
    assign limb_129_600 = n74_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_601 = tmp_workload_top_int_68__277_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_129_602 = (~limb_129_601); // decl: <none>; prim: <none>
    assign limb_129_603 = 5'((({1'h0, limb_129_600}) + ({1'h0, limb_129_602}) + ({4'h0, limb_129_599}))); // decl: <none>; prim: <none>
    assign limb_129_604 = limb_129_603[3:0]; // decl: <none>; prim: <none>
    assign limb_129_605 = {limb_129_604, limb_129_598}; // decl: <none>; prim: <none>
    assign limb_131_606 = s8_norm_sub_204_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_607 = tmp_workload_top_int_68__280_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_131_608 = (~limb_131_607); // decl: <none>; prim: <none>
    assign limb_131_609 = 65'((({1'h0, limb_131_606}) + ({1'h0, rtlzz_pipe_608_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_131_610 = limb_131_609[63:0]; // decl: <none>; prim: <none>
    assign limb_131_611 = limb_131_609[64]; // decl: <none>; prim: <none>
    assign limb_131_612 = s8_norm_sub_204_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_613 = tmp_workload_top_int_68__280_v0[67:64]; // decl: <none>; prim: <none>
    assign limb_131_614 = (~limb_131_613); // decl: <none>; prim: <none>
    assign limb_131_615 = 5'((({1'h0, limb_131_612}) + ({1'h0, rtlzz_pipe_614_s6}) + ({4'h0, limb_131_611}))); // decl: <none>; prim: <none>
    assign limb_131_616 = limb_131_615[3:0]; // decl: <none>; prim: <none>
    assign limb_131_617 = {limb_131_616, limb_131_610}; // decl: <none>; prim: <none>
    assign limb_138_618 = __beopt_width_307[63:0]; // decl: <none>; prim: <none>
    assign limb_138_619 = tmp_workload_top_int_132__293_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_138_620 = (~limb_138_619); // decl: <none>; prim: <none>
    assign limb_138_621 = 65'((({1'h0, limb_138_618}) + ({1'h0, limb_138_620}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_138_622 = limb_138_621[63:0]; // decl: <none>; prim: <none>
    assign limb_138_623 = limb_138_621[64]; // decl: <none>; prim: <none>
    assign limb_138_624 = __beopt_width_307[127:64]; // decl: <none>; prim: <none>
    assign limb_138_625 = tmp_workload_top_int_132__293_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_138_626 = (~limb_138_625); // decl: <none>; prim: <none>
    assign limb_138_627 = 65'((({1'h0, limb_138_624}) + ({1'h0, limb_138_626}) + ({64'h0, limb_138_623}))); // decl: <none>; prim: <none>
    assign limb_138_628 = limb_138_627[63:0]; // decl: <none>; prim: <none>
    assign limb_138_629 = limb_138_627[64]; // decl: <none>; prim: <none>
    assign limb_138_630 = __beopt_width_307[131:128]; // decl: <none>; prim: <none>
    assign limb_138_631 = tmp_workload_top_int_132__293_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_138_632 = (~limb_138_631); // decl: <none>; prim: <none>
    assign limb_138_633 = 5'((({1'h0, limb_138_630}) + ({1'h0, limb_138_632}) + ({4'h0, limb_138_629}))); // decl: <none>; prim: <none>
    assign limb_138_634 = limb_138_633[3:0]; // decl: <none>; prim: <none>
    assign limb_138_635 = {limb_138_634, limb_138_628, limb_138_622}; // decl: <none>; prim: <none>
    assign limb_140_636 = s8_norm_sub_215_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_637 = tmp_workload_top_int_132__296_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_140_638 = (~limb_140_637); // decl: <none>; prim: <none>
    assign limb_140_639 = 65'((({1'h0, limb_140_636}) + ({1'h0, rtlzz_pipe_638_s6}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_140_640 = limb_140_639[63:0]; // decl: <none>; prim: <none>
    assign limb_140_641 = limb_140_639[64]; // decl: <none>; prim: <none>
    assign limb_140_642 = s8_norm_sub_215_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_643 = tmp_workload_top_int_132__296_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_140_644 = (~limb_140_643); // decl: <none>; prim: <none>
    assign limb_140_645 = 65'((({1'h0, limb_140_642}) + ({1'h0, rtlzz_pipe_644_s6}) + ({64'h0, limb_140_641}))); // decl: <none>; prim: <none>
    assign limb_140_646 = limb_140_645[63:0]; // decl: <none>; prim: <none>
    assign limb_140_647 = limb_140_645[64]; // decl: <none>; prim: <none>
    assign limb_140_648 = s8_norm_sub_215_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_649 = tmp_workload_top_int_132__296_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_140_650 = (~limb_140_649); // decl: <none>; prim: <none>
    assign limb_140_651 = 5'((({1'h0, limb_140_648}) + ({1'h0, rtlzz_pipe_650_s6}) + ({4'h0, limb_140_647}))); // decl: <none>; prim: <none>
    assign limb_140_652 = limb_140_651[3:0]; // decl: <none>; prim: <none>
    assign limb_140_653 = {limb_140_652, limb_140_646, limb_140_640}; // decl: <none>; prim: <none>
    assign limb_147_654 = __beopt_width_297[63:0]; // decl: <none>; prim: <none>
    assign limb_147_655 = tmp_workload_top_int_258__309_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_147_656 = (~limb_147_655); // decl: <none>; prim: <none>
    assign limb_147_657 = 65'((({1'h0, limb_147_654}) + ({1'h0, limb_147_656}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_147_658 = limb_147_657[63:0]; // decl: <none>; prim: <none>
    assign limb_147_659 = limb_147_657[64]; // decl: <none>; prim: <none>
    assign limb_147_660 = __beopt_width_297[127:64]; // decl: <none>; prim: <none>
    assign limb_147_661 = tmp_workload_top_int_258__309_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_147_662 = (~limb_147_661); // decl: <none>; prim: <none>
    assign limb_147_663 = 65'((({1'h0, limb_147_660}) + ({1'h0, limb_147_662}) + ({64'h0, limb_147_659}))); // decl: <none>; prim: <none>
    assign limb_147_664 = limb_147_663[63:0]; // decl: <none>; prim: <none>
    assign limb_147_665 = limb_147_663[64]; // decl: <none>; prim: <none>
    assign limb_147_666 = __beopt_width_297[191:128]; // decl: <none>; prim: <none>
    assign limb_147_667 = tmp_workload_top_int_258__309_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_147_668 = (~limb_147_667); // decl: <none>; prim: <none>
    assign limb_147_669 = 65'((({1'h0, limb_147_666}) + ({1'h0, limb_147_668}) + ({64'h0, limb_147_665}))); // decl: <none>; prim: <none>
    assign limb_147_670 = limb_147_669[63:0]; // decl: <none>; prim: <none>
    assign limb_147_671 = limb_147_669[64]; // decl: <none>; prim: <none>
    assign limb_147_672 = __beopt_width_297[255:192]; // decl: <none>; prim: <none>
    assign limb_147_673 = tmp_workload_top_int_258__309_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_147_674 = (~limb_147_673); // decl: <none>; prim: <none>
    assign limb_147_675 = 65'((({1'h0, limb_147_672}) + ({1'h0, limb_147_674}) + ({64'h0, limb_147_671}))); // decl: <none>; prim: <none>
    assign limb_147_676 = limb_147_675[63:0]; // decl: <none>; prim: <none>
    assign limb_147_677 = limb_147_675[64]; // decl: <none>; prim: <none>
    assign limb_147_678 = __beopt_width_297[257:256]; // decl: <none>; prim: <none>
    assign limb_147_679 = tmp_workload_top_int_258__309_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_147_680 = (~limb_147_679); // decl: <none>; prim: <none>
    assign limb_147_681 = 3'((({1'h0, limb_147_678}) + ({1'h0, limb_147_680}) + ({2'h0, limb_147_677}))); // decl: <none>; prim: <none>
    assign limb_147_682 = limb_147_681[1:0]; // decl: <none>; prim: <none>
    assign limb_147_683 = {limb_147_682, limb_147_676, limb_147_670, limb_147_664, limb_147_658}; // decl: <none>; prim: <none>
    assign limb_149_684 = s8_norm_sub_226_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_685 = tmp_workload_top_int_258__312_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_149_686 = (~limb_149_685); // decl: <none>; prim: <none>
    assign limb_149_687 = 65'((({1'h0, limb_149_684}) + ({1'h0, limb_149_686}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_149_688 = limb_149_687[63:0]; // decl: <none>; prim: <none>
    assign limb_149_689 = limb_149_687[64]; // decl: <none>; prim: <none>
    assign limb_149_690 = s8_norm_sub_226_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_691 = tmp_workload_top_int_258__312_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_149_692 = (~limb_149_691); // decl: <none>; prim: <none>
    assign limb_149_693 = 65'((({1'h0, limb_149_690}) + ({1'h0, limb_149_692}) + ({64'h0, limb_149_689}))); // decl: <none>; prim: <none>
    assign limb_149_694 = limb_149_693[63:0]; // decl: <none>; prim: <none>
    assign limb_149_695 = limb_149_693[64]; // decl: <none>; prim: <none>
    assign limb_149_696 = s8_norm_sub_226_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_697 = tmp_workload_top_int_258__312_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_149_698 = (~limb_149_697); // decl: <none>; prim: <none>
    assign limb_149_699 = 65'((({1'h0, limb_149_696}) + ({1'h0, limb_149_698}) + ({64'h0, limb_149_695}))); // decl: <none>; prim: <none>
    assign limb_149_700 = limb_149_699[63:0]; // decl: <none>; prim: <none>
    assign limb_149_701 = limb_149_699[64]; // decl: <none>; prim: <none>
    assign limb_149_702 = s8_norm_sub_226_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_703 = tmp_workload_top_int_258__312_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_149_704 = (~limb_149_703); // decl: <none>; prim: <none>
    assign limb_149_705 = 65'((({1'h0, limb_149_702}) + ({1'h0, limb_149_704}) + ({64'h0, limb_149_701}))); // decl: <none>; prim: <none>
    assign limb_149_706 = limb_149_705[63:0]; // decl: <none>; prim: <none>
    assign limb_149_707 = limb_149_705[64]; // decl: <none>; prim: <none>
    assign limb_149_708 = s8_norm_sub_226_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_709 = tmp_workload_top_int_258__312_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_149_710 = (~limb_149_709); // decl: <none>; prim: <none>
    assign limb_149_711 = 3'((({1'h0, limb_149_708}) + ({1'h0, limb_149_710}) + ({2'h0, limb_149_707}))); // decl: <none>; prim: <none>
    assign limb_149_712 = limb_149_711[1:0]; // decl: <none>; prim: <none>
    assign limb_149_713 = {limb_149_712, limb_149_706, limb_149_700, limb_149_694, limb_149_688}; // decl: <none>; prim: <none>
    assign limb_157_714 = tmp_workload_top_int_513__325_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_157_715 = tmp_workload_top_int_513__327_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_157_716 = 65'((({1'h0, limb_157_714}) + ({1'h0, rtlzz_pipe_715_s7}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_157_717 = limb_157_716[63:0]; // decl: <none>; prim: <none>
    assign limb_157_718 = limb_157_716[64]; // decl: <none>; prim: <none>
    assign limb_157_719 = tmp_workload_top_int_513__325_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_157_720 = tmp_workload_top_int_513__327_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_157_721 = 65'((({1'h0, limb_157_719}) + ({1'h0, rtlzz_pipe_720_s7}) + ({64'h0, limb_157_718}))); // decl: <none>; prim: <none>
    assign limb_157_722 = limb_157_721[63:0]; // decl: <none>; prim: <none>
    assign limb_157_723 = limb_157_721[64]; // decl: <none>; prim: <none>
    assign limb_157_724 = tmp_workload_top_int_513__325_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_157_725 = tmp_workload_top_int_513__327_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_157_726 = 65'((({1'h0, limb_157_724}) + ({1'h0, rtlzz_pipe_725_s7}) + ({64'h0, limb_157_723}))); // decl: <none>; prim: <none>
    assign limb_157_727 = limb_157_726[63:0]; // decl: <none>; prim: <none>
    assign limb_157_728 = limb_157_726[64]; // decl: <none>; prim: <none>
    assign limb_157_729 = tmp_workload_top_int_513__325_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_157_730 = tmp_workload_top_int_513__327_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_157_731 = 65'((({1'h0, limb_157_729}) + ({1'h0, rtlzz_pipe_730_s7}) + ({64'h0, limb_157_728}))); // decl: <none>; prim: <none>
    assign limb_157_732 = limb_157_731[63:0]; // decl: <none>; prim: <none>
    assign limb_157_733 = limb_157_731[64]; // decl: <none>; prim: <none>
    assign limb_157_734 = tmp_workload_top_int_513__325_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_157_735 = tmp_workload_top_int_513__327_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_157_736 = 65'((({1'h0, limb_157_734}) + ({1'h0, rtlzz_pipe_735_s7}) + ({64'h0, limb_157_733}))); // decl: <none>; prim: <none>
    assign limb_157_737 = limb_157_736[63:0]; // decl: <none>; prim: <none>
    assign limb_157_738 = limb_157_736[64]; // decl: <none>; prim: <none>
    assign limb_157_739 = tmp_workload_top_int_513__325_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_157_740 = tmp_workload_top_int_513__327_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_157_741 = 65'((({1'h0, limb_157_739}) + ({1'h0, rtlzz_pipe_740_s7}) + ({64'h0, limb_157_738}))); // decl: <none>; prim: <none>
    assign limb_157_742 = limb_157_741[63:0]; // decl: <none>; prim: <none>
    assign limb_157_743 = limb_157_741[64]; // decl: <none>; prim: <none>
    assign limb_157_744 = tmp_workload_top_int_513__325_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_157_745 = tmp_workload_top_int_513__327_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_157_746 = 65'((({1'h0, limb_157_744}) + ({1'h0, rtlzz_pipe_745_s7}) + ({64'h0, limb_157_743}))); // decl: <none>; prim: <none>
    assign limb_157_747 = limb_157_746[63:0]; // decl: <none>; prim: <none>
    assign limb_157_748 = limb_157_746[64]; // decl: <none>; prim: <none>
    assign limb_157_749 = tmp_workload_top_int_513__325_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_157_750 = tmp_workload_top_int_513__327_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_157_751 = 65'((({1'h0, limb_157_749}) + ({1'h0, rtlzz_pipe_750_s7}) + ({64'h0, limb_157_748}))); // decl: <none>; prim: <none>
    assign limb_157_752 = limb_157_751[63:0]; // decl: <none>; prim: <none>
    assign limb_157_753 = limb_157_751[64]; // decl: <none>; prim: <none>
    assign limb_157_754 = tmp_workload_top_int_513__325_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_755 = tmp_workload_top_int_513__327_v0[512]; // decl: <none>; prim: <none>
    assign limb_157_756 = 2'((({1'h0, limb_157_754}) + ({1'h0, rtlzz_pipe_755_s7}) + ({1'h0, limb_157_753}))); // decl: <none>; prim: <none>
    assign limb_157_757 = limb_157_756[0]; // decl: <none>; prim: <none>
    assign limb_157_758 = {limb_157_757, limb_157_752, limb_157_747, limb_157_742, limb_157_737, limb_157_732, limb_157_727, limb_157_722, limb_157_717}; // decl: <none>; prim: <none>
    assign limb_216_759 = tmp_workload_top_int_512__315_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_216_760 = s8_norm_shift_234_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_216_761 = 65'((({1'h0, limb_216_759}) + ({1'h0, limb_216_760}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_216_762 = limb_216_761[63:0]; // decl: <none>; prim: <none>
    assign limb_216_763 = limb_216_761[64]; // decl: <none>; prim: <none>
    assign limb_216_764 = tmp_workload_top_int_512__315_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_216_765 = s8_norm_shift_234_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_216_766 = 65'((({1'h0, limb_216_764}) + ({1'h0, limb_216_765}) + ({64'h0, limb_216_763}))); // decl: <none>; prim: <none>
    assign limb_216_767 = limb_216_766[63:0]; // decl: <none>; prim: <none>
    assign limb_216_768 = limb_216_766[64]; // decl: <none>; prim: <none>
    assign limb_216_769 = tmp_workload_top_int_512__315_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_216_770 = s8_norm_shift_234_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_216_771 = 65'((({1'h0, limb_216_769}) + ({1'h0, limb_216_770}) + ({64'h0, limb_216_768}))); // decl: <none>; prim: <none>
    assign limb_216_772 = limb_216_771[63:0]; // decl: <none>; prim: <none>
    assign limb_216_773 = limb_216_771[64]; // decl: <none>; prim: <none>
    assign limb_216_774 = tmp_workload_top_int_512__315_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_216_775 = s8_norm_shift_234_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_216_776 = 65'((({1'h0, limb_216_774}) + ({1'h0, limb_216_775}) + ({64'h0, limb_216_773}))); // decl: <none>; prim: <none>
    assign limb_216_777 = limb_216_776[63:0]; // decl: <none>; prim: <none>
    assign limb_216_778 = limb_216_776[64]; // decl: <none>; prim: <none>
    assign limb_216_779 = tmp_workload_top_int_512__315_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_216_780 = s8_norm_shift_234_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_216_781 = 65'((({1'h0, limb_216_779}) + ({1'h0, limb_216_780}) + ({64'h0, limb_216_778}))); // decl: <none>; prim: <none>
    assign limb_216_782 = limb_216_781[63:0]; // decl: <none>; prim: <none>
    assign limb_216_783 = limb_216_781[64]; // decl: <none>; prim: <none>
    assign limb_216_784 = tmp_workload_top_int_512__315_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_216_785 = s8_norm_shift_234_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_216_786 = 65'((({1'h0, limb_216_784}) + ({1'h0, limb_216_785}) + ({64'h0, limb_216_783}))); // decl: <none>; prim: <none>
    assign limb_216_787 = limb_216_786[63:0]; // decl: <none>; prim: <none>
    assign limb_216_788 = limb_216_786[64]; // decl: <none>; prim: <none>
    assign limb_216_789 = tmp_workload_top_int_512__315_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_216_790 = s8_norm_shift_234_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_216_791 = 65'((({1'h0, limb_216_789}) + ({1'h0, limb_216_790}) + ({64'h0, limb_216_788}))); // decl: <none>; prim: <none>
    assign limb_216_792 = limb_216_791[63:0]; // decl: <none>; prim: <none>
    assign limb_216_793 = limb_216_791[64]; // decl: <none>; prim: <none>
    assign limb_216_794 = tmp_workload_top_int_512__315_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_216_795 = s8_norm_shift_234_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_216_796 = 65'((({1'h0, limb_216_794}) + ({1'h0, limb_216_795}) + ({64'h0, limb_216_793}))); // decl: <none>; prim: <none>
    assign limb_216_797 = limb_216_796[63:0]; // decl: <none>; prim: <none>
    assign limb_216_798 = {limb_216_797, limb_216_792, limb_216_787, limb_216_782, limb_216_777, limb_216_772, limb_216_767, limb_216_762}; // decl: <none>; prim: <none>
    assign limb_217_799 = __beopt_width_292[63:0]; // decl: <none>; prim: <none>
    assign limb_217_800 = s8_norm_shift_231_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_217_801 = 65'((({1'h0, limb_217_799}) + ({1'h0, limb_217_800}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_217_802 = limb_217_801[63:0]; // decl: <none>; prim: <none>
    assign limb_217_803 = limb_217_801[64]; // decl: <none>; prim: <none>
    assign limb_217_804 = __beopt_width_292[127:64]; // decl: <none>; prim: <none>
    assign limb_217_805 = s8_norm_shift_231_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_217_806 = 65'((({1'h0, limb_217_804}) + ({1'h0, limb_217_805}) + ({64'h0, limb_217_803}))); // decl: <none>; prim: <none>
    assign limb_217_807 = limb_217_806[63:0]; // decl: <none>; prim: <none>
    assign limb_217_808 = limb_217_806[64]; // decl: <none>; prim: <none>
    assign limb_217_809 = __beopt_width_292[191:128]; // decl: <none>; prim: <none>
    assign limb_217_810 = s8_norm_shift_231_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_217_811 = 65'((({1'h0, limb_217_809}) + ({1'h0, limb_217_810}) + ({64'h0, limb_217_808}))); // decl: <none>; prim: <none>
    assign limb_217_812 = limb_217_811[63:0]; // decl: <none>; prim: <none>
    assign limb_217_813 = limb_217_811[64]; // decl: <none>; prim: <none>
    assign limb_217_814 = __beopt_width_292[255:192]; // decl: <none>; prim: <none>
    assign limb_217_815 = s8_norm_shift_231_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_217_816 = 65'((({1'h0, limb_217_814}) + ({1'h0, limb_217_815}) + ({64'h0, limb_217_813}))); // decl: <none>; prim: <none>
    assign limb_217_817 = limb_217_816[63:0]; // decl: <none>; prim: <none>
    assign limb_217_818 = limb_217_816[64]; // decl: <none>; prim: <none>
    assign limb_217_819 = __beopt_width_292[319:256]; // decl: <none>; prim: <none>
    assign limb_217_820 = s8_norm_shift_231_v0[319:256]; // decl: <none>; prim: <none>
    assign limb_217_821 = 65'((({1'h0, limb_217_819}) + ({1'h0, limb_217_820}) + ({64'h0, limb_217_818}))); // decl: <none>; prim: <none>
    assign limb_217_822 = limb_217_821[63:0]; // decl: <none>; prim: <none>
    assign limb_217_823 = limb_217_821[64]; // decl: <none>; prim: <none>
    assign limb_217_824 = __beopt_width_292[383:320]; // decl: <none>; prim: <none>
    assign limb_217_825 = s8_norm_shift_231_v0[383:320]; // decl: <none>; prim: <none>
    assign limb_217_826 = 65'((({1'h0, limb_217_824}) + ({1'h0, limb_217_825}) + ({64'h0, limb_217_823}))); // decl: <none>; prim: <none>
    assign limb_217_827 = limb_217_826[63:0]; // decl: <none>; prim: <none>
    assign limb_217_828 = limb_217_826[64]; // decl: <none>; prim: <none>
    assign limb_217_829 = __beopt_width_292[447:384]; // decl: <none>; prim: <none>
    assign limb_217_830 = s8_norm_shift_231_v0[447:384]; // decl: <none>; prim: <none>
    assign limb_217_831 = 65'((({1'h0, limb_217_829}) + ({1'h0, limb_217_830}) + ({64'h0, limb_217_828}))); // decl: <none>; prim: <none>
    assign limb_217_832 = limb_217_831[63:0]; // decl: <none>; prim: <none>
    assign limb_217_833 = limb_217_831[64]; // decl: <none>; prim: <none>
    assign limb_217_834 = __beopt_width_292[511:448]; // decl: <none>; prim: <none>
    assign limb_217_835 = s8_norm_shift_231_v0[511:448]; // decl: <none>; prim: <none>
    assign limb_217_836 = 65'((({1'h0, limb_217_834}) + ({1'h0, limb_217_835}) + ({64'h0, limb_217_833}))); // decl: <none>; prim: <none>
    assign limb_217_837 = limb_217_836[63:0]; // decl: <none>; prim: <none>
    assign limb_217_838 = {limb_217_837, limb_217_832, limb_217_827, limb_217_822, limb_217_817, limb_217_812, limb_217_807, limb_217_802}; // decl: <none>; prim: <none>
    assign limb_218_839 = s8_norm_shift_223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_218_840 = tmp_workload_top_int_258__299_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_218_841 = 65'((({1'h0, limb_218_839}) + ({1'h0, limb_218_840}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_218_842 = limb_218_841[63:0]; // decl: <none>; prim: <none>
    assign limb_218_843 = limb_218_841[64]; // decl: <none>; prim: <none>
    assign limb_218_844 = s8_norm_shift_223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_218_845 = tmp_workload_top_int_258__299_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_218_846 = 65'((({1'h0, rtlzz_pipe_844_s7}) + ({1'h0, rtlzz_pipe_845_s7}) + ({64'h0, rtlzz_pipe_843_s7}))); // decl: <none>; prim: <none>
    assign limb_218_847 = limb_218_846[63:0]; // decl: <none>; prim: <none>
    assign limb_218_848 = limb_218_846[64]; // decl: <none>; prim: <none>
    assign limb_218_849 = s8_norm_shift_223_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_218_850 = tmp_workload_top_int_258__299_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_218_851 = 65'((({1'h0, rtlzz_pipe_849_s7}) + ({1'h0, rtlzz_pipe_850_s7}) + ({64'h0, limb_218_848}))); // decl: <none>; prim: <none>
    assign limb_218_852 = limb_218_851[63:0]; // decl: <none>; prim: <none>
    assign limb_218_853 = limb_218_851[64]; // decl: <none>; prim: <none>
    assign limb_218_854 = s8_norm_shift_223_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_218_855 = tmp_workload_top_int_258__299_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_218_856 = 65'((({1'h0, rtlzz_pipe_854_s7}) + ({1'h0, rtlzz_pipe_855_s7}) + ({64'h0, limb_218_853}))); // decl: <none>; prim: <none>
    assign limb_218_857 = limb_218_856[63:0]; // decl: <none>; prim: <none>
    assign limb_218_858 = limb_218_856[64]; // decl: <none>; prim: <none>
    assign limb_218_859 = s8_norm_shift_223_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_860 = tmp_workload_top_int_258__299_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_218_861 = 3'((({1'h0, rtlzz_pipe_859_s7}) + ({1'h0, rtlzz_pipe_860_s7}) + ({2'h0, limb_218_858}))); // decl: <none>; prim: <none>
    assign limb_218_862 = limb_218_861[1:0]; // decl: <none>; prim: <none>
    assign limb_218_863 = {limb_218_862, limb_218_857, limb_218_852, limb_218_847, rtlzz_pipe_842_s7}; // decl: <none>; prim: <none>
    assign limb_219_864 = __beopt_width_295[63:0]; // decl: <none>; prim: <none>
    assign limb_219_865 = s8_norm_shift_220_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_219_866 = 65'((({1'h0, limb_219_864}) + ({1'h0, limb_219_865}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_219_867 = limb_219_866[63:0]; // decl: <none>; prim: <none>
    assign limb_219_868 = limb_219_866[64]; // decl: <none>; prim: <none>
    assign limb_219_869 = __beopt_width_295[127:64]; // decl: <none>; prim: <none>
    assign limb_219_870 = s8_norm_shift_220_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_219_871 = 65'((({1'h0, limb_219_869}) + ({1'h0, limb_219_870}) + ({64'h0, limb_219_868}))); // decl: <none>; prim: <none>
    assign limb_219_872 = limb_219_871[63:0]; // decl: <none>; prim: <none>
    assign limb_219_873 = limb_219_871[64]; // decl: <none>; prim: <none>
    assign limb_219_874 = __beopt_width_295[191:128]; // decl: <none>; prim: <none>
    assign limb_219_875 = s8_norm_shift_220_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_219_876 = 65'((({1'h0, limb_219_874}) + ({1'h0, limb_219_875}) + ({64'h0, limb_219_873}))); // decl: <none>; prim: <none>
    assign limb_219_877 = limb_219_876[63:0]; // decl: <none>; prim: <none>
    assign limb_219_878 = limb_219_876[64]; // decl: <none>; prim: <none>
    assign limb_219_879 = __beopt_width_295[255:192]; // decl: <none>; prim: <none>
    assign limb_219_880 = s8_norm_shift_220_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_219_881 = 65'((({1'h0, limb_219_879}) + ({1'h0, limb_219_880}) + ({64'h0, limb_219_878}))); // decl: <none>; prim: <none>
    assign limb_219_882 = limb_219_881[63:0]; // decl: <none>; prim: <none>
    assign limb_219_883 = limb_219_881[64]; // decl: <none>; prim: <none>
    assign limb_219_884 = __beopt_width_295[257:256]; // decl: <none>; prim: <none>
    assign limb_219_885 = s8_norm_shift_220_v0[257:256]; // decl: <none>; prim: <none>
    assign limb_219_886 = 3'((({1'h0, limb_219_884}) + ({1'h0, limb_219_885}) + ({2'h0, limb_219_883}))); // decl: <none>; prim: <none>
    assign limb_219_887 = limb_219_886[1:0]; // decl: <none>; prim: <none>
    assign limb_219_888 = {limb_219_887, limb_219_882, limb_219_877, limb_219_872, limb_219_867}; // decl: <none>; prim: <none>
    assign limb_220_889 = tmp_workload_top_int_256__164_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_220_890 = s8_norm_shift_126_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_220_891 = 65'((({1'h0, rtlzz_pipe_889_s7}) + ({1'h0, limb_220_890}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_220_892 = limb_220_891[63:0]; // decl: <none>; prim: <none>
    assign limb_220_893 = limb_220_891[64]; // decl: <none>; prim: <none>
    assign limb_220_894 = tmp_workload_top_int_256__164_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_220_895 = s8_norm_shift_126_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_220_896 = 65'((({1'h0, rtlzz_pipe_894_s7}) + ({1'h0, limb_220_895}) + ({64'h0, limb_220_893}))); // decl: <none>; prim: <none>
    assign limb_220_897 = limb_220_896[63:0]; // decl: <none>; prim: <none>
    assign limb_220_898 = limb_220_896[64]; // decl: <none>; prim: <none>
    assign limb_220_899 = tmp_workload_top_int_256__164_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_220_900 = s8_norm_shift_126_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_220_901 = 65'((({1'h0, rtlzz_pipe_899_s7}) + ({1'h0, limb_220_900}) + ({64'h0, limb_220_898}))); // decl: <none>; prim: <none>
    assign limb_220_902 = limb_220_901[63:0]; // decl: <none>; prim: <none>
    assign limb_220_903 = limb_220_901[64]; // decl: <none>; prim: <none>
    assign limb_220_904 = tmp_workload_top_int_256__164_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_220_905 = s8_norm_shift_126_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_220_906 = 65'((({1'h0, rtlzz_pipe_904_s7}) + ({1'h0, limb_220_905}) + ({64'h0, limb_220_903}))); // decl: <none>; prim: <none>
    assign limb_220_907 = limb_220_906[63:0]; // decl: <none>; prim: <none>
    assign limb_220_908 = {limb_220_907, limb_220_902, limb_220_897, limb_220_892}; // decl: <none>; prim: <none>
    assign limb_221_909 = __beopt_width_299[63:0]; // decl: <none>; prim: <none>
    assign limb_221_910 = s8_norm_shift_123_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_221_911 = 65'((({1'h0, limb_221_909}) + ({1'h0, limb_221_910}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_221_912 = limb_221_911[63:0]; // decl: <none>; prim: <none>
    assign limb_221_913 = limb_221_911[64]; // decl: <none>; prim: <none>
    assign limb_221_914 = __beopt_width_299[127:64]; // decl: <none>; prim: <none>
    assign limb_221_915 = s8_norm_shift_123_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_221_916 = 65'((({1'h0, limb_221_914}) + ({1'h0, limb_221_915}) + ({64'h0, limb_221_913}))); // decl: <none>; prim: <none>
    assign limb_221_917 = limb_221_916[63:0]; // decl: <none>; prim: <none>
    assign limb_221_918 = limb_221_916[64]; // decl: <none>; prim: <none>
    assign limb_221_919 = __beopt_width_299[191:128]; // decl: <none>; prim: <none>
    assign limb_221_920 = s8_norm_shift_123_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_221_921 = 65'((({1'h0, limb_221_919}) + ({1'h0, limb_221_920}) + ({64'h0, limb_221_918}))); // decl: <none>; prim: <none>
    assign limb_221_922 = limb_221_921[63:0]; // decl: <none>; prim: <none>
    assign limb_221_923 = limb_221_921[64]; // decl: <none>; prim: <none>
    assign limb_221_924 = __beopt_width_299[255:192]; // decl: <none>; prim: <none>
    assign limb_221_925 = s8_norm_shift_123_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_221_926 = 65'((({1'h0, limb_221_924}) + ({1'h0, limb_221_925}) + ({64'h0, limb_221_923}))); // decl: <none>; prim: <none>
    assign limb_221_927 = limb_221_926[63:0]; // decl: <none>; prim: <none>
    assign limb_221_928 = {limb_221_927, limb_221_922, limb_221_917, limb_221_912}; // decl: <none>; prim: <none>
    assign limb_222_929 = tmp_workload_top_int_256__79_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_222_930 = s8_norm_shift_64_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_222_931 = 65'((({1'h0, limb_222_929}) + ({1'h0, limb_222_930}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_222_932 = limb_222_931[63:0]; // decl: <none>; prim: <none>
    assign limb_222_933 = limb_222_931[64]; // decl: <none>; prim: <none>
    assign limb_222_934 = tmp_workload_top_int_256__79_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_222_935 = s8_norm_shift_64_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_222_936 = 65'((({1'h0, limb_222_934}) + ({1'h0, limb_222_935}) + ({64'h0, limb_222_933}))); // decl: <none>; prim: <none>
    assign limb_222_937 = limb_222_936[63:0]; // decl: <none>; prim: <none>
    assign limb_222_938 = limb_222_936[64]; // decl: <none>; prim: <none>
    assign limb_222_939 = tmp_workload_top_int_256__79_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_222_940 = s8_norm_shift_64_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_222_941 = 65'((({1'h0, limb_222_939}) + ({1'h0, limb_222_940}) + ({64'h0, limb_222_938}))); // decl: <none>; prim: <none>
    assign limb_222_942 = limb_222_941[63:0]; // decl: <none>; prim: <none>
    assign limb_222_943 = limb_222_941[64]; // decl: <none>; prim: <none>
    assign limb_222_944 = tmp_workload_top_int_256__79_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_222_945 = s8_norm_shift_64_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_222_946 = 65'((({1'h0, limb_222_944}) + ({1'h0, limb_222_945}) + ({64'h0, limb_222_943}))); // decl: <none>; prim: <none>
    assign limb_222_947 = limb_222_946[63:0]; // decl: <none>; prim: <none>
    assign limb_222_948 = {limb_222_947, limb_222_942, limb_222_937, limb_222_932}; // decl: <none>; prim: <none>
    assign limb_223_949 = __beopt_width_302[63:0]; // decl: <none>; prim: <none>
    assign limb_223_950 = s8_norm_shift_61_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_223_951 = 65'((({1'h0, limb_223_949}) + ({1'h0, limb_223_950}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_223_952 = limb_223_951[63:0]; // decl: <none>; prim: <none>
    assign limb_223_953 = limb_223_951[64]; // decl: <none>; prim: <none>
    assign limb_223_954 = __beopt_width_302[127:64]; // decl: <none>; prim: <none>
    assign limb_223_955 = s8_norm_shift_61_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_223_956 = 65'((({1'h0, limb_223_954}) + ({1'h0, limb_223_955}) + ({64'h0, limb_223_953}))); // decl: <none>; prim: <none>
    assign limb_223_957 = limb_223_956[63:0]; // decl: <none>; prim: <none>
    assign limb_223_958 = limb_223_956[64]; // decl: <none>; prim: <none>
    assign limb_223_959 = __beopt_width_302[191:128]; // decl: <none>; prim: <none>
    assign limb_223_960 = s8_norm_shift_61_v0[191:128]; // decl: <none>; prim: <none>
    assign limb_223_961 = 65'((({1'h0, limb_223_959}) + ({1'h0, limb_223_960}) + ({64'h0, limb_223_958}))); // decl: <none>; prim: <none>
    assign limb_223_962 = limb_223_961[63:0]; // decl: <none>; prim: <none>
    assign limb_223_963 = limb_223_961[64]; // decl: <none>; prim: <none>
    assign limb_223_964 = __beopt_width_302[255:192]; // decl: <none>; prim: <none>
    assign limb_223_965 = s8_norm_shift_61_v0[255:192]; // decl: <none>; prim: <none>
    assign limb_223_966 = 65'((({1'h0, limb_223_964}) + ({1'h0, limb_223_965}) + ({64'h0, limb_223_963}))); // decl: <none>; prim: <none>
    assign limb_223_967 = limb_223_966[63:0]; // decl: <none>; prim: <none>
    assign limb_223_968 = {limb_223_967, limb_223_962, limb_223_957, limb_223_952}; // decl: <none>; prim: <none>
    assign limb_224_969 = tmp_workload_top_int_132__283_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_224_970 = s8_norm_shift_212_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_224_971 = 65'((({1'h0, rtlzz_pipe_969_s6}) + ({1'h0, limb_224_970}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_224_972 = limb_224_971[63:0]; // decl: <none>; prim: <none>
    assign limb_224_973 = limb_224_971[64]; // decl: <none>; prim: <none>
    assign limb_224_974 = tmp_workload_top_int_132__283_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_224_975 = s8_norm_shift_212_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_224_976 = 65'((({1'h0, rtlzz_pipe_974_s6}) + ({1'h0, limb_224_975}) + ({64'h0, limb_224_973}))); // decl: <none>; prim: <none>
    assign limb_224_977 = limb_224_976[63:0]; // decl: <none>; prim: <none>
    assign limb_224_978 = limb_224_976[64]; // decl: <none>; prim: <none>
    assign limb_224_979 = tmp_workload_top_int_132__283_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_980 = s8_norm_shift_212_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_224_981 = 5'((({1'h0, rtlzz_pipe_979_s6}) + ({1'h0, limb_224_980}) + ({4'h0, limb_224_978}))); // decl: <none>; prim: <none>
    assign limb_224_982 = limb_224_981[3:0]; // decl: <none>; prim: <none>
    assign limb_224_983 = {limb_224_982, limb_224_977, limb_224_972}; // decl: <none>; prim: <none>
    assign limb_225_984 = __beopt_width_305[63:0]; // decl: <none>; prim: <none>
    assign limb_225_985 = s8_norm_shift_209_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_225_986 = 65'((({1'h0, limb_225_984}) + ({1'h0, limb_225_985}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_225_987 = limb_225_986[63:0]; // decl: <none>; prim: <none>
    assign limb_225_988 = limb_225_986[64]; // decl: <none>; prim: <none>
    assign limb_225_989 = __beopt_width_305[127:64]; // decl: <none>; prim: <none>
    assign limb_225_990 = s8_norm_shift_209_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_225_991 = 65'((({1'h0, limb_225_989}) + ({1'h0, limb_225_990}) + ({64'h0, limb_225_988}))); // decl: <none>; prim: <none>
    assign limb_225_992 = limb_225_991[63:0]; // decl: <none>; prim: <none>
    assign limb_225_993 = limb_225_991[64]; // decl: <none>; prim: <none>
    assign limb_225_994 = __beopt_width_305[131:128]; // decl: <none>; prim: <none>
    assign limb_225_995 = s8_norm_shift_209_v0[131:128]; // decl: <none>; prim: <none>
    assign limb_225_996 = 5'((({1'h0, limb_225_994}) + ({1'h0, limb_225_995}) + ({4'h0, limb_225_993}))); // decl: <none>; prim: <none>
    assign limb_225_997 = limb_225_996[3:0]; // decl: <none>; prim: <none>
    assign limb_225_998 = {limb_225_997, limb_225_992, limb_225_987}; // decl: <none>; prim: <none>
    assign limb_226_999 = tmp_workload_top_int_130__223_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1000 = s8_norm_shift_169_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1001 = 65'((({1'h0, limb_226_999}) + ({1'h0, limb_226_1000}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_226_1002 = limb_226_1001[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1003 = limb_226_1001[64]; // decl: <none>; prim: <none>
    assign limb_226_1004 = tmp_workload_top_int_130__223_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_226_1005 = s8_norm_shift_169_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_226_1006 = 65'((({1'h0, limb_226_1004}) + ({1'h0, limb_226_1005}) + ({64'h0, limb_226_1003}))); // decl: <none>; prim: <none>
    assign limb_226_1007 = limb_226_1006[63:0]; // decl: <none>; prim: <none>
    assign limb_226_1008 = limb_226_1006[64]; // decl: <none>; prim: <none>
    assign limb_226_1009 = tmp_workload_top_int_130__223_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1010 = s8_norm_shift_169_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_226_1011 = 3'((({1'h0, limb_226_1009}) + ({1'h0, limb_226_1010}) + ({2'h0, limb_226_1008}))); // decl: <none>; prim: <none>
    assign limb_226_1012 = limb_226_1011[1:0]; // decl: <none>; prim: <none>
    assign limb_226_1013 = {limb_226_1012, limb_226_1007, limb_226_1002}; // decl: <none>; prim: <none>
    assign limb_227_1014 = __beopt_width_309[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1015 = s8_norm_shift_166_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1016 = 65'((({1'h0, rtlzz_pipe_1014_s6}) + ({1'h0, limb_227_1015}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_227_1017 = limb_227_1016[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1018 = limb_227_1016[64]; // decl: <none>; prim: <none>
    assign limb_227_1019 = __beopt_width_309[127:64]; // decl: <none>; prim: <none>
    assign limb_227_1020 = s8_norm_shift_166_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_227_1021 = 65'((({1'h0, rtlzz_pipe_1019_s6}) + ({1'h0, limb_227_1020}) + ({64'h0, limb_227_1018}))); // decl: <none>; prim: <none>
    assign limb_227_1022 = limb_227_1021[63:0]; // decl: <none>; prim: <none>
    assign limb_227_1023 = limb_227_1021[64]; // decl: <none>; prim: <none>
    assign limb_227_1024 = __beopt_width_309[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1025 = s8_norm_shift_166_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_227_1026 = 3'((({1'h0, rtlzz_pipe_1024_s6}) + ({1'h0, limb_227_1025}) + ({2'h0, limb_227_1023}))); // decl: <none>; prim: <none>
    assign limb_227_1027 = limb_227_1026[1:0]; // decl: <none>; prim: <none>
    assign limb_227_1028 = {limb_227_1027, limb_227_1022, limb_227_1017}; // decl: <none>; prim: <none>
    assign limb_228_1029 = tmp_workload_top_int_130__148_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1030 = s8_norm_shift_115_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1031 = 65'((({1'h0, limb_228_1029}) + ({1'h0, limb_228_1030}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_228_1032 = limb_228_1031[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1033 = limb_228_1031[64]; // decl: <none>; prim: <none>
    assign limb_228_1034 = tmp_workload_top_int_130__148_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_228_1035 = s8_norm_shift_115_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_228_1036 = 65'((({1'h0, limb_228_1034}) + ({1'h0, limb_228_1035}) + ({64'h0, limb_228_1033}))); // decl: <none>; prim: <none>
    assign limb_228_1037 = limb_228_1036[63:0]; // decl: <none>; prim: <none>
    assign limb_228_1038 = limb_228_1036[64]; // decl: <none>; prim: <none>
    assign limb_228_1039 = tmp_workload_top_int_130__148_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1040 = s8_norm_shift_115_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_228_1041 = 3'((({1'h0, limb_228_1039}) + ({1'h0, limb_228_1040}) + ({2'h0, limb_228_1038}))); // decl: <none>; prim: <none>
    assign limb_228_1042 = limb_228_1041[1:0]; // decl: <none>; prim: <none>
    assign limb_228_1043 = {limb_228_1042, limb_228_1037, limb_228_1032}; // decl: <none>; prim: <none>
    assign limb_229_1044 = __beopt_width_311[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1045 = s8_norm_shift_112_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1046 = 65'((({1'h0, limb_229_1044}) + ({1'h0, limb_229_1045}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_229_1047 = limb_229_1046[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1048 = limb_229_1046[64]; // decl: <none>; prim: <none>
    assign limb_229_1049 = __beopt_width_311[127:64]; // decl: <none>; prim: <none>
    assign limb_229_1050 = s8_norm_shift_112_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_229_1051 = 65'((({1'h0, limb_229_1049}) + ({1'h0, limb_229_1050}) + ({64'h0, limb_229_1048}))); // decl: <none>; prim: <none>
    assign limb_229_1052 = limb_229_1051[63:0]; // decl: <none>; prim: <none>
    assign limb_229_1053 = limb_229_1051[64]; // decl: <none>; prim: <none>
    assign limb_229_1054 = __beopt_width_311[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1055 = s8_norm_shift_112_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_229_1056 = 3'((({1'h0, limb_229_1054}) + ({1'h0, limb_229_1055}) + ({2'h0, limb_229_1053}))); // decl: <none>; prim: <none>
    assign limb_229_1057 = limb_229_1056[1:0]; // decl: <none>; prim: <none>
    assign limb_229_1058 = {limb_229_1057, limb_229_1052, limb_229_1047}; // decl: <none>; prim: <none>
    assign limb_230_1059 = tmp_workload_top_int_130__63_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1060 = s8_norm_shift_53_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1061 = 65'((({1'h0, rtlzz_pipe_1059_s7}) + ({1'h0, limb_230_1060}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_230_1062 = limb_230_1061[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1063 = limb_230_1061[64]; // decl: <none>; prim: <none>
    assign limb_230_1064 = tmp_workload_top_int_130__63_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_230_1065 = s8_norm_shift_53_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_230_1066 = 65'((({1'h0, rtlzz_pipe_1064_s7}) + ({1'h0, limb_230_1065}) + ({64'h0, limb_230_1063}))); // decl: <none>; prim: <none>
    assign limb_230_1067 = limb_230_1066[63:0]; // decl: <none>; prim: <none>
    assign limb_230_1068 = limb_230_1066[64]; // decl: <none>; prim: <none>
    assign limb_230_1069 = tmp_workload_top_int_130__63_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1070 = s8_norm_shift_53_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_230_1071 = 3'((({1'h0, rtlzz_pipe_1069_s7}) + ({1'h0, limb_230_1070}) + ({2'h0, limb_230_1068}))); // decl: <none>; prim: <none>
    assign limb_230_1072 = limb_230_1071[1:0]; // decl: <none>; prim: <none>
    assign limb_230_1073 = {limb_230_1072, limb_230_1067, limb_230_1062}; // decl: <none>; prim: <none>
    assign limb_231_1074 = __beopt_width_315[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1075 = s8_norm_shift_50_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1076 = 65'((({1'h0, limb_231_1074}) + ({1'h0, limb_231_1075}) + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign limb_231_1077 = limb_231_1076[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1078 = limb_231_1076[64]; // decl: <none>; prim: <none>
    assign limb_231_1079 = __beopt_width_315[127:64]; // decl: <none>; prim: <none>
    assign limb_231_1080 = s8_norm_shift_50_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_231_1081 = 65'((({1'h0, limb_231_1079}) + ({1'h0, limb_231_1080}) + ({64'h0, limb_231_1078}))); // decl: <none>; prim: <none>
    assign limb_231_1082 = limb_231_1081[63:0]; // decl: <none>; prim: <none>
    assign limb_231_1083 = limb_231_1081[64]; // decl: <none>; prim: <none>
    assign limb_231_1084 = __beopt_width_315[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1085 = s8_norm_shift_50_v0[129:128]; // decl: <none>; prim: <none>
    assign limb_231_1086 = 3'((({1'h0, limb_231_1084}) + ({1'h0, limb_231_1085}) + ({2'h0, limb_231_1083}))); // decl: <none>; prim: <none>
    assign limb_231_1087 = limb_231_1086[1:0]; // decl: <none>; prim: <none>
    assign limb_231_1088 = {limb_231_1087, limb_231_1082, limb_231_1077}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 128'h0;
            rtlzz_pipe_6_s1 <= 128'h0;
            rtlzz_pipe_6_s2 <= 128'h0;
            rtlzz_pipe_6_s3 <= 128'h0;
            rtlzz_pipe_7_s1 <= 128'h0;
            rtlzz_pipe_7_s2 <= 128'h0;
            rtlzz_pipe_7_s3 <= 128'h0;
            rtlzz_pipe_7_s4 <= 128'h0;
            rtlzz_pipe_7_s5 <= 128'h0;
            rtlzz_pipe_162_s1 <= 65'h0;
            rtlzz_pipe_162_s2 <= 65'h0;
            rtlzz_pipe_163_s1 <= 65'h0;
            rtlzz_pipe_163_s2 <= 65'h0;
            rtlzz_pipe_163_s3 <= 65'h0;
            rtlzz_pipe_163_s4 <= 65'h0;
            rtlzz_pipe_178_s1 <= 65'h0;
            rtlzz_pipe_178_s2 <= 65'h0;
            rtlzz_pipe_178_s3 <= 65'h0;
            rtlzz_pipe_178_s4 <= 65'h0;
            rtlzz_pipe_178_s5 <= 65'h0;
            rtlzz_pipe_178_s6 <= 65'h0;
            rtlzz_pipe_179_s1 <= 65'h0;
            rtlzz_pipe_179_s2 <= 65'h0;
            rtlzz_pipe_179_s3 <= 65'h0;
            rtlzz_pipe_179_s4 <= 65'h0;
            rtlzz_pipe_179_s5 <= 65'h0;
            rtlzz_pipe_179_s6 <= 65'h0;
            rtlzz_pipe_179_s7 <= 65'h0;
            rtlzz_pipe_194_s1 <= 129'h0;
            rtlzz_pipe_262_s1 <= 128'h0;
            rtlzz_pipe_262_s2 <= 128'h0;
            rtlzz_pipe_263_s1 <= 128'h0;
            rtlzz_pipe_263_s2 <= 128'h0;
            rtlzz_pipe_263_s3 <= 128'h0;
            rtlzz_pipe_264_s1 <= 65'h0;
            rtlzz_pipe_264_s2 <= 65'h0;
            rtlzz_pipe_264_s3 <= 65'h0;
            rtlzz_pipe_264_s4 <= 65'h0;
            rtlzz_pipe_265_s1 <= 65'h0;
            rtlzz_pipe_265_s2 <= 65'h0;
            rtlzz_pipe_265_s3 <= 65'h0;
            rtlzz_pipe_265_s4 <= 65'h0;
            rtlzz_pipe_265_s5 <= 65'h0;
            rtlzz_pipe_270_s1 <= 128'h0;
            rtlzz_pipe_270_s2 <= 128'h0;
            rtlzz_pipe_270_s3 <= 128'h0;
            rtlzz_pipe_270_s4 <= 128'h0;
            rtlzz_pipe_270_s5 <= 128'h0;
            rtlzz_pipe_270_s6 <= 128'h0;
            rtlzz_pipe_271_s1 <= 128'h0;
            rtlzz_pipe_271_s2 <= 128'h0;
            rtlzz_pipe_271_s3 <= 128'h0;
            rtlzz_pipe_271_s4 <= 128'h0;
            rtlzz_pipe_271_s5 <= 128'h0;
            rtlzz_pipe_271_s6 <= 128'h0;
            rtlzz_pipe_271_s7 <= 128'h0;
            rtlzz_pipe_273_s1 <= 65'h0;
            rtlzz_pipe_278_s1 <= 129'h0;
            rtlzz_pipe_278_s2 <= 129'h0;
            rtlzz_pipe_279_s1 <= 129'h0;
            rtlzz_pipe_279_s2 <= 129'h0;
            rtlzz_pipe_279_s3 <= 129'h0;
            rtlzz_pipe_279_s4 <= 129'h0;
            rtlzz_pipe_292_s1 <= 64'h0;
            rtlzz_pipe_292_s2 <= 64'h0;
            rtlzz_pipe_292_s3 <= 64'h0;
            rtlzz_pipe_293_s2 <= 64'h0;
            rtlzz_pipe_293_s3 <= 64'h0;
            rtlzz_pipe_295_s3 <= 64'h0;
            rtlzz_pipe_295_s4 <= 64'h0;
            rtlzz_pipe_295_s5 <= 64'h0;
            rtlzz_pipe_296_s4 <= 64'h0;
            rtlzz_pipe_296_s5 <= 64'h0;
            rtlzz_pipe_307_s4 <= 64'h0;
            rtlzz_pipe_307_s5 <= 64'h0;
            rtlzz_pipe_307_s6 <= 64'h0;
            rtlzz_pipe_308_s6 <= 64'h0;
            rtlzz_pipe_310_s7 <= 64'h0;
            rtlzz_pipe_10_s4 <= 256'h0;
            rtlzz_pipe_10_s5 <= 256'h0;
            rtlzz_pipe_10_s6 <= 256'h0;
            rtlzz_pipe_10_s7 <= 256'h0;
            rtlzz_pipe_174_s4 <= 130'h0;
            rtlzz_pipe_174_s5 <= 130'h0;
            rtlzz_pipe_174_s6 <= 130'h0;
            rtlzz_pipe_44_s6 <= 256'h0;
            rtlzz_pipe_44_s7 <= 256'h0;
            rtlzz_pipe_360_s3 <= 64'h0;
            rtlzz_pipe_360_s4 <= 64'h0;
            rtlzz_pipe_365_s3 <= 1'h0;
            rtlzz_pipe_365_s4 <= 1'h0;
            rtlzz_pipe_20_s5 <= 34'h0;
            rtlzz_pipe_20_s6 <= 34'h0;
            rtlzz_pipe_266_s5 <= 64'h0;
            rtlzz_pipe_268_s5 <= 34'h0;
            rtlzz_pipe_268_s6 <= 34'h0;
            rtlzz_pipe_298_s5 <= 33'h0;
            rtlzz_pipe_301_s6 <= 32'h0;
            rtlzz_pipe_301_s7 <= 32'h0;
            rtlzz_pipe_304_s7 <= 34'h0;
            rtlzz_pipe_370_s5 <= 64'h0;
            rtlzz_pipe_375_s5 <= 1'h0;
            rtlzz_pipe_169_s6 <= 34'h0;
            rtlzz_pipe_22_s7 <= 34'h0;
            rtlzz_pipe_267_s6 <= 64'h0;
            rtlzz_pipe_267_s7 <= 64'h0;
            rtlzz_pipe_269_s6 <= 34'h0;
            rtlzz_pipe_239_s7 <= 34'h0;
            rtlzz_pipe_172_s6 <= 130'h0;
            rtlzz_pipe_382_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_382_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_388_s6 <= 4'hf;
            rtlzz_pipe_388_s7 <= 4'hf;
            rtlzz_pipe_406_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_412_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_418_s7 <= 2'h3;
            rtlzz_pipe_424_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_424_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_430_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_430_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_436_s6 <= 2'h3;
            rtlzz_pipe_436_s7 <= 2'h3;
            rtlzz_pipe_441_s1 <= 64'h0;
            rtlzz_pipe_441_s2 <= 64'h0;
            rtlzz_pipe_441_s3 <= 64'h0;
            rtlzz_pipe_441_s4 <= 64'h0;
            rtlzz_pipe_441_s5 <= 64'h0;
            rtlzz_pipe_441_s6 <= 64'h0;
            rtlzz_pipe_446_s1 <= 1'h0;
            rtlzz_pipe_446_s2 <= 1'h0;
            rtlzz_pipe_446_s3 <= 1'h0;
            rtlzz_pipe_446_s4 <= 1'h0;
            rtlzz_pipe_446_s5 <= 1'h0;
            rtlzz_pipe_446_s6 <= 1'h0;
            rtlzz_pipe_313_s7 <= 33'h0;
            rtlzz_pipe_316_s7 <= 32'h0;
            rtlzz_pipe_319_s7 <= 34'h0;
            rtlzz_pipe_451_s2 <= 64'h0;
            rtlzz_pipe_451_s3 <= 64'h0;
            rtlzz_pipe_451_s4 <= 64'h0;
            rtlzz_pipe_451_s5 <= 64'h0;
            rtlzz_pipe_451_s6 <= 64'h0;
            rtlzz_pipe_451_s7 <= 64'h0;
            rtlzz_pipe_456_s2 <= 1'h0;
            rtlzz_pipe_456_s3 <= 1'h0;
            rtlzz_pipe_456_s4 <= 1'h0;
            rtlzz_pipe_456_s5 <= 1'h0;
            rtlzz_pipe_456_s6 <= 1'h0;
            rtlzz_pipe_456_s7 <= 1'h0;
            rtlzz_pipe_486_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_492_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_498_s7 <= 2'h3;
            rtlzz_pipe_520_s1 <= 64'h0;
            rtlzz_pipe_520_s2 <= 64'h0;
            rtlzz_pipe_525_s1 <= 64'h0;
            rtlzz_pipe_525_s2 <= 64'h0;
            rtlzz_pipe_530_s1 <= 1'h0;
            rtlzz_pipe_530_s2 <= 1'h0;
            rtlzz_pipe_198_s3 <= 34'h0;
            rtlzz_pipe_280_s3 <= 64'h0;
            rtlzz_pipe_282_s3 <= 34'h0;
            rtlzz_pipe_284_s3 <= 128'h0;
            rtlzz_pipe_284_s4 <= 128'h0;
            rtlzz_pipe_286_s3 <= 66'h0;
            rtlzz_pipe_322_s3 <= 33'h0;
            rtlzz_pipe_322_s4 <= 33'h0;
            rtlzz_pipe_325_s4 <= 32'h0;
            rtlzz_pipe_328_s4 <= 34'h0;
            rtlzz_pipe_331_s5 <= 64'h0;
            rtlzz_pipe_535_s2 <= 64'h0;
            rtlzz_pipe_535_s3 <= 64'h0;
            rtlzz_pipe_535_s4 <= 64'h0;
            rtlzz_pipe_540_s2 <= 64'h0;
            rtlzz_pipe_540_s3 <= 64'h0;
            rtlzz_pipe_540_s4 <= 64'h0;
            rtlzz_pipe_545_s2 <= 1'h0;
            rtlzz_pipe_545_s3 <= 1'h0;
            rtlzz_pipe_545_s4 <= 1'h0;
            rtlzz_pipe_285_s5 <= 128'h0;
            rtlzz_pipe_287_s5 <= 66'h0;
            rtlzz_pipe_202_s5 <= 130'h0;
            rtlzz_pipe_203_s5 <= 130'h0;
            rtlzz_pipe_144_s6 <= 258'h0;
            rtlzz_pipe_554_s5 <= 64'h0;
            rtlzz_pipe_555_s5 <= 1'h1;
            rtlzz_pipe_556_s5 <= 4'h0;
            rtlzz_pipe_558_s5 <= 4'hf;
            rtlzz_pipe_562_s6 <= 64'h0;
            rtlzz_pipe_564_s5 <= 64'hffffffffffffffff;
            rtlzz_pipe_564_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_568_s6 <= 4'h0;
            rtlzz_pipe_569_s5 <= 4'h0;
            rtlzz_pipe_570_s6 <= 4'hf;
            rtlzz_pipe_574_s3 <= 64'h0;
            rtlzz_pipe_579_s3 <= 2'h0;
            rtlzz_pipe_334_s4 <= 33'h0;
            rtlzz_pipe_334_s5 <= 33'h0;
            rtlzz_pipe_337_s4 <= 33'h0;
            rtlzz_pipe_337_s5 <= 33'h0;
            rtlzz_pipe_340_s4 <= 34'h0;
            rtlzz_pipe_340_s5 <= 34'h0;
            rtlzz_pipe_340_s6 <= 34'h0;
            rtlzz_pipe_584_s5 <= 64'h0;
            rtlzz_pipe_589_s5 <= 2'h0;
            rtlzz_pipe_211_s6 <= 34'h0;
            rtlzz_pipe_291_s6 <= 34'h0;
            rtlzz_pipe_212_s6 <= 68'h0;
            rtlzz_pipe_135_s6 <= 132'h0;
            rtlzz_pipe_608_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_614_s6 <= 4'hf;
            rtlzz_pipe_638_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_644_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_650_s6 <= 4'hf;
            rtlzz_pipe_715_s1 <= 64'h0;
            rtlzz_pipe_715_s2 <= 64'h0;
            rtlzz_pipe_715_s3 <= 64'h0;
            rtlzz_pipe_715_s4 <= 64'h0;
            rtlzz_pipe_715_s5 <= 64'h0;
            rtlzz_pipe_715_s6 <= 64'h0;
            rtlzz_pipe_715_s7 <= 64'h0;
            rtlzz_pipe_720_s1 <= 64'h0;
            rtlzz_pipe_720_s2 <= 64'h0;
            rtlzz_pipe_720_s3 <= 64'h0;
            rtlzz_pipe_720_s4 <= 64'h0;
            rtlzz_pipe_720_s5 <= 64'h0;
            rtlzz_pipe_720_s6 <= 64'h0;
            rtlzz_pipe_720_s7 <= 64'h0;
            rtlzz_pipe_725_s1 <= 64'h0;
            rtlzz_pipe_725_s2 <= 64'h0;
            rtlzz_pipe_725_s3 <= 64'h0;
            rtlzz_pipe_725_s4 <= 64'h0;
            rtlzz_pipe_725_s5 <= 64'h0;
            rtlzz_pipe_725_s6 <= 64'h0;
            rtlzz_pipe_725_s7 <= 64'h0;
            rtlzz_pipe_730_s1 <= 64'h0;
            rtlzz_pipe_730_s2 <= 64'h0;
            rtlzz_pipe_730_s3 <= 64'h0;
            rtlzz_pipe_730_s4 <= 64'h0;
            rtlzz_pipe_730_s5 <= 64'h0;
            rtlzz_pipe_730_s6 <= 64'h0;
            rtlzz_pipe_730_s7 <= 64'h0;
            rtlzz_pipe_735_s1 <= 64'h0;
            rtlzz_pipe_735_s2 <= 64'h0;
            rtlzz_pipe_735_s3 <= 64'h0;
            rtlzz_pipe_735_s4 <= 64'h0;
            rtlzz_pipe_735_s5 <= 64'h0;
            rtlzz_pipe_735_s6 <= 64'h0;
            rtlzz_pipe_735_s7 <= 64'h0;
            rtlzz_pipe_740_s1 <= 64'h0;
            rtlzz_pipe_740_s2 <= 64'h0;
            rtlzz_pipe_740_s3 <= 64'h0;
            rtlzz_pipe_740_s4 <= 64'h0;
            rtlzz_pipe_740_s5 <= 64'h0;
            rtlzz_pipe_740_s6 <= 64'h0;
            rtlzz_pipe_740_s7 <= 64'h0;
            rtlzz_pipe_745_s1 <= 64'h0;
            rtlzz_pipe_745_s2 <= 64'h0;
            rtlzz_pipe_745_s3 <= 64'h0;
            rtlzz_pipe_745_s4 <= 64'h0;
            rtlzz_pipe_745_s5 <= 64'h0;
            rtlzz_pipe_745_s6 <= 64'h0;
            rtlzz_pipe_745_s7 <= 64'h0;
            rtlzz_pipe_750_s1 <= 64'h0;
            rtlzz_pipe_750_s2 <= 64'h0;
            rtlzz_pipe_750_s3 <= 64'h0;
            rtlzz_pipe_750_s4 <= 64'h0;
            rtlzz_pipe_750_s5 <= 64'h0;
            rtlzz_pipe_750_s6 <= 64'h0;
            rtlzz_pipe_750_s7 <= 64'h0;
            rtlzz_pipe_755_s1 <= 1'h0;
            rtlzz_pipe_755_s2 <= 1'h0;
            rtlzz_pipe_755_s3 <= 1'h0;
            rtlzz_pipe_755_s4 <= 1'h0;
            rtlzz_pipe_755_s5 <= 1'h0;
            rtlzz_pipe_755_s6 <= 1'h0;
            rtlzz_pipe_755_s7 <= 1'h0;
            rtlzz_pipe_844_s7 <= 64'h0;
            rtlzz_pipe_849_s7 <= 64'h0;
            rtlzz_pipe_854_s7 <= 64'h0;
            rtlzz_pipe_859_s7 <= 2'h0;
            rtlzz_pipe_889_s7 <= 64'h0;
            rtlzz_pipe_894_s7 <= 64'h0;
            rtlzz_pipe_899_s7 <= 64'h0;
            rtlzz_pipe_904_s7 <= 64'h0;
            rtlzz_pipe_969_s6 <= 64'h0;
            rtlzz_pipe_974_s6 <= 64'h0;
            rtlzz_pipe_979_s6 <= 4'h0;
            rtlzz_pipe_1014_s6 <= 64'h0;
            rtlzz_pipe_1019_s6 <= 64'h0;
            rtlzz_pipe_1024_s6 <= 2'h0;
            rtlzz_pipe_142_s7 <= 258'h0;
            rtlzz_pipe_842_s7 <= 64'h0;
            rtlzz_pipe_843_s7 <= 1'h0;
            rtlzz_pipe_845_s7 <= 64'h0;
            rtlzz_pipe_850_s7 <= 64'h0;
            rtlzz_pipe_855_s7 <= 64'h0;
            rtlzz_pipe_860_s7 <= 2'h0;
            rtlzz_pipe_1059_s7 <= 64'h0;
            rtlzz_pipe_1064_s7 <= 64'h0;
            rtlzz_pipe_1069_s7 <= 2'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_hw_1_v0; // decl: /home/zyrv/vulsim/workload.cpp:16:19-16:20; prim: /home/zyrv/vulsim/workload.cpp:16:19-16:20
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_hw_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_6_s2 <= rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_6_s3 <= rtlzz_pipe_6_s2; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:20; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:20
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_hw_3_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_7_s3 <= rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_7_s4 <= rtlzz_pipe_7_s3; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_7_s5 <= rtlzz_pipe_7_s4; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:20; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:20
        end
        if (iv) begin
        rtlzz_pipe_162_s1 <= __beopt_width_539; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_162_s2 <= rtlzz_pipe_162_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= __beopt_width_542; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_163_s2 <= rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_163_s3 <= rtlzz_pipe_163_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_163_s4 <= rtlzz_pipe_163_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_178_s1 <= __beopt_width_567; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_178_s2 <= rtlzz_pipe_178_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_178_s3 <= rtlzz_pipe_178_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_178_s4 <= rtlzz_pipe_178_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_178_s5 <= rtlzz_pipe_178_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_178_s6 <= rtlzz_pipe_178_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= __beopt_width_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_179_s2 <= rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_179_s3 <= rtlzz_pipe_179_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_179_s4 <= rtlzz_pipe_179_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_179_s5 <= rtlzz_pipe_179_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_179_s6 <= rtlzz_pipe_179_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_179_s7 <= rtlzz_pipe_179_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_194_s1 <= __beopt_width_594; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_262_s1 <= __beopt_width_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_262_s2 <= rtlzz_pipe_262_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_263_s1 <= __beopt_width_314; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_263_s2 <= rtlzz_pipe_263_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_263_s3 <= rtlzz_pipe_263_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_264_s1 <= __beopt_width_321; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_264_s2 <= rtlzz_pipe_264_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_264_s3 <= rtlzz_pipe_264_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_264_s4 <= rtlzz_pipe_264_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_265_s1 <= __beopt_width_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_265_s2 <= rtlzz_pipe_265_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_265_s3 <= rtlzz_pipe_265_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_265_s4 <= rtlzz_pipe_265_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_265_s5 <= rtlzz_pipe_265_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_270_s1 <= __beopt_width_344; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_270_s2 <= rtlzz_pipe_270_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_270_s3 <= rtlzz_pipe_270_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_270_s4 <= rtlzz_pipe_270_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_270_s5 <= rtlzz_pipe_270_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_270_s6 <= rtlzz_pipe_270_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_271_s1 <= __beopt_width_349; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_271_s2 <= rtlzz_pipe_271_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_271_s3 <= rtlzz_pipe_271_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_271_s4 <= rtlzz_pipe_271_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_271_s5 <= rtlzz_pipe_271_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_271_s6 <= rtlzz_pipe_271_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_271_s7 <= rtlzz_pipe_271_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_273_s1 <= __beopt_width_356; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_278_s1 <= __beopt_width_380; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_278_s2 <= rtlzz_pipe_278_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_279_s1 <= __beopt_width_386; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_279_s2 <= rtlzz_pipe_279_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_279_s3 <= rtlzz_pipe_279_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_279_s4 <= rtlzz_pipe_279_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_292_s1 <= mul_precision_292; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_292_s2 <= rtlzz_pipe_292_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_292_s3 <= rtlzz_pipe_292_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_293_s2 <= mul_precision_293; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_293_s3 <= rtlzz_pipe_293_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_295_s3 <= mul_precision_295; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_295_s4 <= rtlzz_pipe_295_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_295_s5 <= rtlzz_pipe_295_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_296_s4 <= mul_precision_296; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_296_s5 <= rtlzz_pipe_296_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_307_s4 <= mul_precision_307; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_307_s5 <= rtlzz_pipe_307_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_307_s6 <= rtlzz_pipe_307_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_308_s6 <= mul_precision_308; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_310_s7 <= mul_precision_310; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_10_s4 <= s8_norm_mul_10_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_10_s5 <= rtlzz_pipe_10_s4; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_10_s6 <= rtlzz_pipe_10_s5; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_10_s7 <= rtlzz_pipe_10_s6; // decl: /home/zyrv/vulsim/workload.cpp:23:19-23:46; prim: /home/zyrv/vulsim/workload.cpp:23:19-23:46
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_174_s4 <= __beopt_width_561; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_174_s5 <= rtlzz_pipe_174_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_174_s6 <= rtlzz_pipe_174_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_44_s6 <= tmp_workload_top_int_256__85_v0; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_44_s7 <= rtlzz_pipe_44_s6; // decl: /home/zyrv/vulsim/workload.cpp:39:60-39:72; prim: /home/zyrv/vulsim/workload.cpp:39:60-39:72
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_360_s3 <= limb_13_360; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_360_s4 <= rtlzz_pipe_360_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_365_s3 <= limb_13_365; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_365_s4 <= rtlzz_pipe_365_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_20_s5 <= tmp_workload_top_int_34__42_v0; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_20_s6 <= rtlzz_pipe_20_s5; // decl: /home/zyrv/vulsim/workload.cpp:33:19-33:31; prim: /home/zyrv/vulsim/workload.cpp:25:5-25:45
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_266_s5 <= __beopt_width_329; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_268_s5 <= __beopt_width_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_268_s6 <= rtlzz_pipe_268_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_298_s5 <= mul_precision_298; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_301_s6 <= mul_precision_301; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_301_s7 <= rtlzz_pipe_301_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_304_s7 <= mul_precision_304; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_370_s5 <= limb_15_370; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_375_s5 <= limb_15_375; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_169_s6 <= __beopt_width_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_22_s7 <= tmp_workload_top_int_34__47_v0; // decl: /home/zyrv/vulsim/workload.cpp:34:19-34:31; prim: /home/zyrv/vulsim/workload.cpp:26:5-26:45
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_267_s6 <= __beopt_width_333; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_267_s7 <= rtlzz_pipe_267_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_269_s6 <= __beopt_width_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_239_s7 <= __beopt_width_336; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:20:18-20:20
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_172_s6 <= __beopt_width_559; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_382_s6 <= limb_29_382; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_382_s7 <= rtlzz_pipe_382_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_388_s6 <= limb_29_388; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_388_s7 <= rtlzz_pipe_388_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_406_s7 <= limb_38_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_412_s7 <= limb_38_412; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_418_s7 <= limb_38_418; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_424_s6 <= limb_40_424; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_424_s7 <= rtlzz_pipe_424_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_430_s6 <= limb_40_430; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_430_s7 <= rtlzz_pipe_430_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_436_s6 <= limb_40_436; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_436_s7 <= rtlzz_pipe_436_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_441_s1 <= limb_51_441; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_441_s2 <= rtlzz_pipe_441_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_441_s3 <= rtlzz_pipe_441_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_441_s4 <= rtlzz_pipe_441_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_441_s5 <= rtlzz_pipe_441_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_441_s6 <= rtlzz_pipe_441_s5; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_446_s1 <= limb_51_446; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_446_s2 <= rtlzz_pipe_446_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_446_s3 <= rtlzz_pipe_446_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_446_s4 <= rtlzz_pipe_446_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_446_s5 <= rtlzz_pipe_446_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_446_s6 <= rtlzz_pipe_446_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_313_s7 <= mul_precision_313; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_316_s7 <= mul_precision_316; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_319_s7 <= mul_precision_319; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_451_s2 <= limb_53_451; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_451_s3 <= rtlzz_pipe_451_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_451_s4 <= rtlzz_pipe_451_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_451_s5 <= rtlzz_pipe_451_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_451_s6 <= rtlzz_pipe_451_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_451_s7 <= rtlzz_pipe_451_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_456_s2 <= limb_53_456; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_456_s3 <= rtlzz_pipe_456_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_456_s4 <= rtlzz_pipe_456_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_456_s5 <= rtlzz_pipe_456_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_456_s6 <= rtlzz_pipe_456_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_456_s7 <= rtlzz_pipe_456_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_486_s7 <= limb_76_486; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_492_s7 <= limb_76_492; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_498_s7 <= limb_76_498; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_520_s1 <= limb_85_520; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_520_s2 <= rtlzz_pipe_520_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_525_s1 <= limb_85_525; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_525_s2 <= rtlzz_pipe_525_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_530_s1 <= limb_85_530; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_530_s2 <= rtlzz_pipe_530_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_198_s3 <= __beopt_width_603; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_280_s3 <= __beopt_width_389; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_282_s3 <= __beopt_width_396; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_284_s3 <= __beopt_width_403; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_284_s4 <= rtlzz_pipe_284_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_286_s3 <= __beopt_width_410; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_322_s3 <= mul_precision_322; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_322_s4 <= rtlzz_pipe_322_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_325_s4 <= mul_precision_325; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_328_s4 <= mul_precision_328; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_331_s5 <= mul_precision_331; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_535_s2 <= limb_87_535; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_535_s3 <= rtlzz_pipe_535_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_535_s4 <= rtlzz_pipe_535_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_540_s2 <= limb_87_540; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_540_s3 <= rtlzz_pipe_540_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_540_s4 <= rtlzz_pipe_540_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_545_s2 <= limb_87_545; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_545_s3 <= rtlzz_pipe_545_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_545_s4 <= rtlzz_pipe_545_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_285_s5 <= __beopt_width_406; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_287_s5 <= __beopt_width_413; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_202_s5 <= __beopt_width_611; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_203_s5 <= __beopt_width_612; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_144_s6 <= tmp_workload_top_int_258__305_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:61-93:74; prim: /home/zyrv/vulsim/workload.cpp:93:61-93:74
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_554_s5 <= limb_103_554; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_555_s5 <= limb_103_555; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_556_s5 <= limb_103_556; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_558_s5 <= limb_103_558; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_562_s6 <= limb_105_562; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_564_s5 <= limb_105_564; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_564_s6 <= rtlzz_pipe_564_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_568_s6 <= limb_105_568; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_569_s5 <= limb_105_569; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_570_s6 <= limb_105_570; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_574_s3 <= limb_113_574; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_579_s3 <= limb_113_579; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_334_s4 <= mul_precision_334; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_334_s5 <= rtlzz_pipe_334_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_337_s4 <= mul_precision_337; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_337_s5 <= rtlzz_pipe_337_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_340_s4 <= mul_precision_340; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_340_s5 <= rtlzz_pipe_340_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_340_s6 <= rtlzz_pipe_340_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_584_s5 <= limb_115_584; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_589_s5 <= limb_115_589; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_211_s6 <= __beopt_width_630; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_291_s6 <= __beopt_width_427; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_212_s6 <= __beopt_width_633; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_135_s6 <= tmp_workload_top_int_132__289_v0; // decl: /home/zyrv/vulsim/workload.cpp:91:61-91:74; prim: /home/zyrv/vulsim/workload.cpp:91:61-91:74
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_608_s6 <= limb_131_608; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_614_s6 <= limb_131_614; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_638_s6 <= limb_140_638; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_644_s6 <= limb_140_644; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_650_s6 <= limb_140_650; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_715_s1 <= limb_157_715; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_715_s2 <= rtlzz_pipe_715_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_715_s3 <= rtlzz_pipe_715_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_715_s4 <= rtlzz_pipe_715_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_715_s5 <= rtlzz_pipe_715_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_715_s6 <= rtlzz_pipe_715_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_715_s7 <= rtlzz_pipe_715_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_720_s1 <= limb_157_720; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_720_s2 <= rtlzz_pipe_720_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_720_s3 <= rtlzz_pipe_720_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_720_s4 <= rtlzz_pipe_720_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_720_s5 <= rtlzz_pipe_720_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_720_s6 <= rtlzz_pipe_720_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_720_s7 <= rtlzz_pipe_720_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_725_s1 <= limb_157_725; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_725_s2 <= rtlzz_pipe_725_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_725_s3 <= rtlzz_pipe_725_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_725_s4 <= rtlzz_pipe_725_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_725_s5 <= rtlzz_pipe_725_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_725_s6 <= rtlzz_pipe_725_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_725_s7 <= rtlzz_pipe_725_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_730_s1 <= limb_157_730; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_730_s2 <= rtlzz_pipe_730_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_730_s3 <= rtlzz_pipe_730_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_730_s4 <= rtlzz_pipe_730_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_730_s5 <= rtlzz_pipe_730_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_730_s6 <= rtlzz_pipe_730_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_730_s7 <= rtlzz_pipe_730_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_735_s1 <= limb_157_735; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_735_s2 <= rtlzz_pipe_735_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_735_s3 <= rtlzz_pipe_735_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_735_s4 <= rtlzz_pipe_735_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_735_s5 <= rtlzz_pipe_735_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_735_s6 <= rtlzz_pipe_735_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_735_s7 <= rtlzz_pipe_735_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_740_s1 <= limb_157_740; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_740_s2 <= rtlzz_pipe_740_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_740_s3 <= rtlzz_pipe_740_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_740_s4 <= rtlzz_pipe_740_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_740_s5 <= rtlzz_pipe_740_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_740_s6 <= rtlzz_pipe_740_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_740_s7 <= rtlzz_pipe_740_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_745_s1 <= limb_157_745; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_745_s2 <= rtlzz_pipe_745_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_745_s3 <= rtlzz_pipe_745_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_745_s4 <= rtlzz_pipe_745_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_745_s5 <= rtlzz_pipe_745_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_745_s6 <= rtlzz_pipe_745_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_745_s7 <= rtlzz_pipe_745_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_750_s1 <= limb_157_750; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_750_s2 <= rtlzz_pipe_750_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_750_s3 <= rtlzz_pipe_750_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_750_s4 <= rtlzz_pipe_750_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_750_s5 <= rtlzz_pipe_750_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_750_s6 <= rtlzz_pipe_750_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_750_s7 <= rtlzz_pipe_750_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_755_s1 <= limb_157_755; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_755_s2 <= rtlzz_pipe_755_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_755_s3 <= rtlzz_pipe_755_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_755_s4 <= rtlzz_pipe_755_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_755_s5 <= rtlzz_pipe_755_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_755_s6 <= rtlzz_pipe_755_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_755_s7 <= rtlzz_pipe_755_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_844_s7 <= limb_218_844; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_849_s7 <= limb_218_849; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_854_s7 <= limb_218_854; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_859_s7 <= limb_218_859; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_889_s7 <= limb_220_889; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_894_s7 <= limb_220_894; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_899_s7 <= limb_220_899; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_904_s7 <= limb_220_904; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_969_s6 <= limb_224_969; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_974_s6 <= limb_224_974; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_979_s6 <= limb_224_979; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1014_s6 <= limb_227_1014; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1019_s6 <= limb_227_1019; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_1024_s6 <= limb_227_1024; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_142_s7 <= tmp_workload_top_int_258__301_v0; // decl: /home/zyrv/vulsim/workload.cpp:93:37-93:50; prim: /home/zyrv/vulsim/workload.cpp:93:37-93:50
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_842_s7 <= limb_218_842; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_843_s7 <= limb_218_843; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_845_s7 <= limb_218_845; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_850_s7 <= limb_218_850; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_855_s7 <= limb_218_855; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_860_s7 <= limb_218_860; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1059_s7 <= limb_230_1059; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1064_s7 <= limb_230_1064; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_1069_s7 <= limb_230_1069; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [255:0] a_data,input wire a_wen,input wire [255:0] b_data,input wire b_wen,input wire [511:0] c_data,input wire c_wen,output reg [512:0] y);
reg liv;wire cov;
reg [255:0] l_a;
reg [255:0] l_b;
reg [511:0] l_c;
wire [512:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=256'h0000000000000000000000000000000000000000000000000;l_b<=256'h0000000000000000000000000000000000000000000000000;l_c<=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;y<=513'h000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
