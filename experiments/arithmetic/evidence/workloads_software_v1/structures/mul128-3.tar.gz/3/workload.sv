`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_76_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_79_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_82_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_85_s2; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_88_s2; // decl: <none>; prim: <none>
    logic [224:0] rtlzz_pipe_91_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_94_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_97_s2; // decl: <none>; prim: <none>
    logic [161:0] rtlzz_pipe_100_s3; // decl: <none>; prim: <none>
    logic [193:0] rtlzz_pipe_103_s3; // decl: <none>; prim: <none>
    logic [225:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [257:0] rtlzz_pipe_109_s3; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 64'(($unsigned(64'($unsigned(mul_tree_10_11))) * $unsigned(64'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 64'(($unsigned(64'($unsigned(mul_tree_10_14))) * $unsigned(64'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 64'(($unsigned(64'($unsigned(mul_tree_10_18))) * $unsigned(64'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 64'(($unsigned(64'($unsigned(mul_tree_10_22))) * $unsigned(64'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 64'(($unsigned(64'($unsigned(mul_tree_10_26))) * $unsigned(64'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 64'(($unsigned(64'($unsigned(mul_tree_10_30))) * $unsigned(64'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 64'(($unsigned(64'($unsigned(mul_tree_10_34))) * $unsigned(64'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = mul_precision_8[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 64'(($unsigned(64'($unsigned(mul_tree_10_38))) * $unsigned(64'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 64'(($unsigned(64'($unsigned(mul_tree_10_42))) * $unsigned(64'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 64'(($unsigned(64'($unsigned(mul_tree_10_46))) * $unsigned(64'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 64'(($unsigned(64'($unsigned(mul_tree_10_50))) * $unsigned(64'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = mul_precision_8[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 64'(($unsigned(64'($unsigned(mul_tree_10_54))) * $unsigned(64'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = mul_precision_9[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 64'(($unsigned(64'($unsigned(mul_tree_10_58))) * $unsigned(64'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = mul_precision_9[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 64'(($unsigned(64'($unsigned(mul_tree_10_62))) * $unsigned(64'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = mul_precision_9[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 64'(($unsigned(64'($unsigned(mul_tree_10_66))) * $unsigned(64'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = mul_precision_8[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = mul_precision_9[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 64'(($unsigned(64'($unsigned(mul_tree_10_70))) * $unsigned(64'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 97'((mul_tree_10_74 + mul_tree_10_75 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({33'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 161'((mul_tree_10_77 + mul_tree_10_78 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({33'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 129'((mul_tree_10_80 + mul_tree_10_81 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({33'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 193'((mul_tree_10_83 + mul_tree_10_84 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({33'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 161'((mul_tree_10_86 + mul_tree_10_87 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({33'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 225'((mul_tree_10_89 + mul_tree_10_90 + ({224'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({33'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 193'((mul_tree_10_92 + mul_tree_10_93 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({33'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 257'((mul_tree_10_95 + mul_tree_10_96 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({65'h0, rtlzz_pipe_76_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 162'((mul_tree_10_98 + mul_tree_10_99 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({65'h0, rtlzz_pipe_82_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 194'((mul_tree_10_101 + mul_tree_10_102 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({65'h0, rtlzz_pipe_88_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 226'((mul_tree_10_104 + mul_tree_10_105 + ({225'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({65'h0, rtlzz_pipe_94_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 258'((mul_tree_10_107 + mul_tree_10_108 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({33'h0, rtlzz_pipe_100_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, rtlzz_pipe_103_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 195'((mul_tree_10_110 + mul_tree_10_111 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({33'h0, rtlzz_pipe_106_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, rtlzz_pipe_109_s3}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 259'((mul_tree_10_113 + mul_tree_10_114 + ({258'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({65'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 260'((mul_tree_10_116 + mul_tree_10_117 + ({259'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 64'h0;
            rtlzz_pipe_17_s1 <= 96'h0;
            rtlzz_pipe_21_s1 <= 128'h0;
            rtlzz_pipe_25_s1 <= 160'h0;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_37_s1 <= 160'h0;
            rtlzz_pipe_41_s1 <= 192'h0;
            rtlzz_pipe_45_s1 <= 128'h0;
            rtlzz_pipe_49_s1 <= 160'h0;
            rtlzz_pipe_53_s1 <= 192'h0;
            rtlzz_pipe_57_s1 <= 224'h0;
            rtlzz_pipe_61_s1 <= 160'h0;
            rtlzz_pipe_65_s1 <= 192'h0;
            rtlzz_pipe_69_s1 <= 224'h0;
            rtlzz_pipe_73_s1 <= 256'h0;
            rtlzz_pipe_76_s2 <= 97'h0;
            rtlzz_pipe_79_s2 <= 161'h0;
            rtlzz_pipe_82_s2 <= 129'h0;
            rtlzz_pipe_85_s2 <= 193'h0;
            rtlzz_pipe_88_s2 <= 161'h0;
            rtlzz_pipe_91_s2 <= 225'h0;
            rtlzz_pipe_94_s2 <= 193'h0;
            rtlzz_pipe_97_s2 <= 257'h0;
            rtlzz_pipe_100_s3 <= 162'h0;
            rtlzz_pipe_103_s3 <= 194'h0;
            rtlzz_pipe_106_s3 <= 226'h0;
            rtlzz_pipe_109_s3 <= 258'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_76_s2 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_79_s2 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_82_s2 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_85_s2 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_88_s2 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_91_s2 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_94_s2 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_97_s2 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_100_s3 <= mul_tree_10_100; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_103_s3 <= mul_tree_10_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= mul_tree_10_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_109_s3 <= mul_tree_10_109; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
