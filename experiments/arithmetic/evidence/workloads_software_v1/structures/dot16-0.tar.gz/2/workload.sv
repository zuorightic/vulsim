`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a0, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [63:0] b0, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic [63:0] a1, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:11; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    input logic [63:0] b1, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic [63:0] a2, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:11; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    input logic [63:0] b2, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:11; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:11
    input logic [63:0] a3, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:11; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    input logic [63:0] b3, // decl: /home/zyrv/vulsim/workload.cpp:17:1-17:11; prim: /home/zyrv/vulsim/workload.cpp:17:1-17:11
    input logic [63:0] a4, // decl: /home/zyrv/vulsim/workload.cpp:19:1-19:11; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    input logic [63:0] b4, // decl: /home/zyrv/vulsim/workload.cpp:21:1-21:11; prim: /home/zyrv/vulsim/workload.cpp:21:1-21:11
    input logic [63:0] a5, // decl: /home/zyrv/vulsim/workload.cpp:23:1-23:11; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    input logic [63:0] b5, // decl: /home/zyrv/vulsim/workload.cpp:25:1-25:11; prim: /home/zyrv/vulsim/workload.cpp:25:1-25:11
    input logic [63:0] a6, // decl: /home/zyrv/vulsim/workload.cpp:27:1-27:11; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    input logic [63:0] b6, // decl: /home/zyrv/vulsim/workload.cpp:29:1-29:11; prim: /home/zyrv/vulsim/workload.cpp:29:1-29:11
    input logic [63:0] a7, // decl: /home/zyrv/vulsim/workload.cpp:31:1-31:11; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    input logic [63:0] b7, // decl: /home/zyrv/vulsim/workload.cpp:33:1-33:11; prim: /home/zyrv/vulsim/workload.cpp:33:1-33:11
    input logic [63:0] a8, // decl: /home/zyrv/vulsim/workload.cpp:35:1-35:11; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    input logic [63:0] b8, // decl: /home/zyrv/vulsim/workload.cpp:37:1-37:11; prim: /home/zyrv/vulsim/workload.cpp:37:1-37:11
    input logic [63:0] a9, // decl: /home/zyrv/vulsim/workload.cpp:39:1-39:11; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    input logic [63:0] b9, // decl: /home/zyrv/vulsim/workload.cpp:41:1-41:11; prim: /home/zyrv/vulsim/workload.cpp:41:1-41:11
    input logic [63:0] a10, // decl: /home/zyrv/vulsim/workload.cpp:43:1-43:12; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    input logic [63:0] b10, // decl: /home/zyrv/vulsim/workload.cpp:45:1-45:12; prim: /home/zyrv/vulsim/workload.cpp:45:1-45:12
    input logic [63:0] a11, // decl: /home/zyrv/vulsim/workload.cpp:47:1-47:12; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    input logic [63:0] b11, // decl: /home/zyrv/vulsim/workload.cpp:49:1-49:12; prim: /home/zyrv/vulsim/workload.cpp:49:1-49:12
    input logic [63:0] a12, // decl: /home/zyrv/vulsim/workload.cpp:51:1-51:12; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    input logic [63:0] b12, // decl: /home/zyrv/vulsim/workload.cpp:53:1-53:12; prim: /home/zyrv/vulsim/workload.cpp:53:1-53:12
    input logic [63:0] a13, // decl: /home/zyrv/vulsim/workload.cpp:55:1-55:12; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    input logic [63:0] b13, // decl: /home/zyrv/vulsim/workload.cpp:57:1-57:12; prim: /home/zyrv/vulsim/workload.cpp:57:1-57:12
    input logic [63:0] a14, // decl: /home/zyrv/vulsim/workload.cpp:59:1-59:12; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    input logic [63:0] b14, // decl: /home/zyrv/vulsim/workload.cpp:61:1-61:12; prim: /home/zyrv/vulsim/workload.cpp:61:1-61:12
    input logic [63:0] a15, // decl: /home/zyrv/vulsim/workload.cpp:63:1-63:12; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    input logic [63:0] b15, // decl: /home/zyrv/vulsim/workload.cpp:65:1-65:12; prim: /home/zyrv/vulsim/workload.cpp:65:1-65:12
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    output logic [131:0] y, // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:71:1-71:8; prim: /home/zyrv/vulsim/workload.cpp:71:1-71:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] s8_norm_mul_18_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] s8_norm_mul_38_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] s8_norm_mul_54_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [128:0] s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [128:0] s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [128:0] s8_norm_add_70_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    logic [128:0] s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [129:0] s8_norm_add_72_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    logic [129:0] s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [129:0] s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [129:0] s8_norm_add_75_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    logic [130:0] s8_norm_add_76_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    logic [130:0] s8_norm_add_77_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    logic [131:0] s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    logic [127:0] __beopt_width_98; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_99; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_100; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_101; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_102; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_103; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_104; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_105; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_106; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_107; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_108; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_109; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_110; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_111; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_112; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_113; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_114; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_115; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_116; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_117; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_118; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_119; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_120; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_121; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_122; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_123; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_124; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_125; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_126; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_127; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_128; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_129; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_98; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_99; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_100; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_101; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_102; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_103; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_104; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_105; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_106; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_107; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_108; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_109; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_110; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_111; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_112; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_113; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_114; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_115; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_116; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_117; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_118; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_119; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_120; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_121; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_122; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_123; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_124; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_125; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_126; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_127; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_128; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_129; // decl: <none>; prim: <none>
    logic [127:0] arith_original_130; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] arith_original_131; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] arith_original_132; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] arith_original_133; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] arith_original_134; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    logic [127:0] arith_original_135; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] arith_original_136; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] arith_original_137; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [127:0] arith_original_138; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] arith_original_139; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    logic [127:0] arith_original_140; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] arith_original_141; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] arith_original_142; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] arith_original_143; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    logic [127:0] arith_original_144; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] arith_original_145; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [63:0] rtlzz_pipe_100_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_101_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_102_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_103_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_104_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_105_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_106_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_107_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_110_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_112_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_113_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_116_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_117_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_118_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_119_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_120_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_121_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_122_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_123_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_124_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_125_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_128_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_129_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_33_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [127:0] rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [127:0] rtlzz_pipe_34_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    logic [128:0] rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [128:0] rtlzz_pipe_49_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    logic [127:0] rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_35_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    logic [127:0] rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [127:0] rtlzz_pipe_36_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    logic [128:0] rtlzz_pipe_50_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    logic [127:0] rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [127:0] rtlzz_pipe_38_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    logic [128:0] rtlzz_pipe_51_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    logic [127:0] rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_39_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    logic [127:0] rtlzz_pipe_40_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    logic [128:0] rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [128:0] rtlzz_pipe_52_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    logic [129:0] rtlzz_pipe_58_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    logic [127:0] rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [127:0] rtlzz_pipe_41_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    logic [128:0] rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [128:0] rtlzz_pipe_53_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    logic [127:0] rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_43_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    logic [127:0] rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [127:0] rtlzz_pipe_44_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    logic [128:0] rtlzz_pipe_54_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    logic [129:0] rtlzz_pipe_59_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    logic [127:0] rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_45_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    logic [127:0] rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_47_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    logic [127:0] rtlzz_pipe_48_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [127:0] rtlzz_pipe_48_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    logic [128:0] rtlzz_pipe_56_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [128:0] rtlzz_pipe_56_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic [128:0] rtlzz_pipe_56_s7; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8


    assign s8_norm_mul_2_v0 = arith_original_130; // decl: <none>; prim: <none>
    assign s8_norm_mul_6_v0 = arith_original_131; // decl: <none>; prim: <none>
    assign s8_norm_mul_10_v0 = arith_original_132; // decl: <none>; prim: <none>
    assign s8_norm_mul_14_v0 = arith_original_133; // decl: <none>; prim: <none>
    assign s8_norm_mul_18_v0 = arith_original_134; // decl: <none>; prim: <none>
    assign s8_norm_mul_22_v0 = arith_original_135; // decl: <none>; prim: <none>
    assign s8_norm_mul_26_v0 = arith_original_136; // decl: <none>; prim: <none>
    assign s8_norm_mul_30_v0 = arith_original_137; // decl: <none>; prim: <none>
    assign s8_norm_mul_34_v0 = arith_original_138; // decl: <none>; prim: <none>
    assign s8_norm_mul_38_v0 = arith_original_139; // decl: <none>; prim: <none>
    assign s8_norm_mul_42_v0 = arith_original_140; // decl: <none>; prim: <none>
    assign s8_norm_mul_46_v0 = arith_original_141; // decl: <none>; prim: <none>
    assign s8_norm_mul_50_v0 = arith_original_142; // decl: <none>; prim: <none>
    assign s8_norm_mul_54_v0 = arith_original_143; // decl: <none>; prim: <none>
    assign s8_norm_mul_58_v0 = arith_original_144; // decl: <none>; prim: <none>
    assign s8_norm_mul_62_v0 = arith_original_145; // decl: <none>; prim: <none>
    assign s8_norm_add_64_v0 = (rtlzz_pipe_33_s3 + rtlzz_pipe_34_s3); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
    assign s8_norm_add_65_v0 = (rtlzz_pipe_35_s6 + rtlzz_pipe_36_s6); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
    assign s8_norm_add_66_v0 = (s8_norm_mul_18_v0 + rtlzz_pipe_38_s5); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
    assign s8_norm_add_67_v0 = (rtlzz_pipe_39_s3 + rtlzz_pipe_40_s3); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
    assign s8_norm_add_68_v0 = (rtlzz_pipe_41_s4 + s8_norm_mul_38_v0); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
    assign s8_norm_add_69_v0 = (rtlzz_pipe_43_s5 + rtlzz_pipe_44_s5); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
    assign s8_norm_add_70_v0 = (rtlzz_pipe_45_s7 + s8_norm_mul_54_v0); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:29-85:58
    assign s8_norm_add_71_v0 = (rtlzz_pipe_47_s4 + rtlzz_pipe_48_s4); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
    assign s8_norm_add_72_v0 = (rtlzz_pipe_49_s7 + rtlzz_pipe_50_s7); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:5-73:57
    assign s8_norm_add_73_v0 = (rtlzz_pipe_51_s6 + rtlzz_pipe_52_s6); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
    assign s8_norm_add_74_v0 = (rtlzz_pipe_53_s6 + rtlzz_pipe_54_s6); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
    assign s8_norm_add_75_v0 = (s8_norm_add_70_v0 + rtlzz_pipe_56_s7); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:85:5-85:60
    assign s8_norm_add_76_v0 = (s8_norm_add_72_v0 + rtlzz_pipe_58_s7); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:89:5-89:29
    assign s8_norm_add_77_v0 = (rtlzz_pipe_59_s7 + s8_norm_add_75_v0); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:93:5-93:29
    assign s8_norm_add_78_v0 = (s8_norm_add_76_v0 + s8_norm_add_77_v0); // decl: /home/zyrv/vulsim/workload.cpp:103:21-103:32; prim: /home/zyrv/vulsim/workload.cpp:97:5-97:33
    assign y = s8_norm_add_78_v0; // decl: /home/zyrv/vulsim/workload.cpp:69:1-69:11; prim: /home/zyrv/vulsim/workload.cpp:104:5-104:13
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_98 = ({64'h0, a0}); // decl: <none>; prim: <none>
    assign __beopt_width_99 = ({64'h0, b0}); // decl: <none>; prim: <none>
    assign __beopt_width_100 = ({64'h0, a1}); // decl: <none>; prim: <none>
    assign __beopt_width_101 = ({64'h0, b1}); // decl: <none>; prim: <none>
    assign __beopt_width_102 = ({64'h0, a2}); // decl: <none>; prim: <none>
    assign __beopt_width_103 = ({64'h0, b2}); // decl: <none>; prim: <none>
    assign __beopt_width_104 = ({64'h0, a3}); // decl: <none>; prim: <none>
    assign __beopt_width_105 = ({64'h0, b3}); // decl: <none>; prim: <none>
    assign __beopt_width_106 = ({64'h0, a4}); // decl: <none>; prim: <none>
    assign __beopt_width_107 = ({64'h0, b4}); // decl: <none>; prim: <none>
    assign __beopt_width_108 = ({64'h0, a5}); // decl: <none>; prim: <none>
    assign __beopt_width_109 = ({64'h0, b5}); // decl: <none>; prim: <none>
    assign __beopt_width_110 = ({64'h0, a6}); // decl: <none>; prim: <none>
    assign __beopt_width_111 = ({64'h0, b6}); // decl: <none>; prim: <none>
    assign __beopt_width_112 = ({64'h0, a7}); // decl: <none>; prim: <none>
    assign __beopt_width_113 = ({64'h0, b7}); // decl: <none>; prim: <none>
    assign __beopt_width_114 = ({64'h0, a8}); // decl: <none>; prim: <none>
    assign __beopt_width_115 = ({64'h0, b8}); // decl: <none>; prim: <none>
    assign __beopt_width_116 = ({64'h0, a9}); // decl: <none>; prim: <none>
    assign __beopt_width_117 = ({64'h0, b9}); // decl: <none>; prim: <none>
    assign __beopt_width_118 = ({64'h0, a10}); // decl: <none>; prim: <none>
    assign __beopt_width_119 = ({64'h0, b10}); // decl: <none>; prim: <none>
    assign __beopt_width_120 = ({64'h0, a11}); // decl: <none>; prim: <none>
    assign __beopt_width_121 = ({64'h0, b11}); // decl: <none>; prim: <none>
    assign __beopt_width_122 = ({64'h0, a12}); // decl: <none>; prim: <none>
    assign __beopt_width_123 = ({64'h0, b12}); // decl: <none>; prim: <none>
    assign __beopt_width_124 = ({64'h0, a13}); // decl: <none>; prim: <none>
    assign __beopt_width_125 = ({64'h0, b13}); // decl: <none>; prim: <none>
    assign __beopt_width_126 = ({64'h0, a14}); // decl: <none>; prim: <none>
    assign __beopt_width_127 = ({64'h0, b14}); // decl: <none>; prim: <none>
    assign __beopt_width_128 = ({64'h0, a15}); // decl: <none>; prim: <none>
    assign __beopt_width_129 = ({64'h0, b15}); // decl: <none>; prim: <none>
    assign mul_precision_98 = __beopt_width_98[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_99 = __beopt_width_99[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_100 = __beopt_width_100[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_101 = __beopt_width_101[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_102 = __beopt_width_102[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_103 = __beopt_width_103[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_104 = __beopt_width_104[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_105 = __beopt_width_105[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_106 = __beopt_width_106[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_107 = __beopt_width_107[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_108 = __beopt_width_108[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_109 = __beopt_width_109[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_110 = __beopt_width_110[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_111 = __beopt_width_111[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_112 = __beopt_width_112[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_113 = __beopt_width_113[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_114 = __beopt_width_114[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_115 = __beopt_width_115[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_116 = __beopt_width_116[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_117 = __beopt_width_117[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_118 = __beopt_width_118[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_119 = __beopt_width_119[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_120 = __beopt_width_120[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_121 = __beopt_width_121[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_122 = __beopt_width_122[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_123 = __beopt_width_123[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_124 = __beopt_width_124[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_125 = __beopt_width_125[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_126 = __beopt_width_126[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_127 = __beopt_width_127[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_128 = __beopt_width_128[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_129 = __beopt_width_129[63:0]; // decl: <none>; prim: <none>
    assign arith_original_130 = 128'(($unsigned(128'($unsigned(mul_precision_98))) * $unsigned(128'($unsigned(mul_precision_99))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    assign arith_original_131 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_100_s1))) * $unsigned(128'($unsigned(rtlzz_pipe_101_s1))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
    assign arith_original_132 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_102_s2))) * $unsigned(128'($unsigned(rtlzz_pipe_103_s2))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
    assign arith_original_133 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_104_s4))) * $unsigned(128'($unsigned(rtlzz_pipe_105_s4))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
    assign arith_original_134 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_106_s5))) * $unsigned(128'($unsigned(rtlzz_pipe_107_s5))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:19:1-19:11
    assign arith_original_135 = 128'(($unsigned(128'($unsigned(mul_precision_108))) * $unsigned(128'($unsigned(mul_precision_109))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
    assign arith_original_136 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_110_s1))) * $unsigned(128'($unsigned(rtlzz_pipe_111_s1))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
    assign arith_original_137 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_112_s2))) * $unsigned(128'($unsigned(rtlzz_pipe_113_s2))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
    assign arith_original_138 = 128'(($unsigned(128'($unsigned(mul_precision_114))) * $unsigned(128'($unsigned(mul_precision_115))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
    assign arith_original_139 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_116_s4))) * $unsigned(128'($unsigned(rtlzz_pipe_117_s4))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:39:1-39:11
    assign arith_original_140 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_118_s1))) * $unsigned(128'($unsigned(rtlzz_pipe_119_s1))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
    assign arith_original_141 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_120_s2))) * $unsigned(128'($unsigned(rtlzz_pipe_121_s2))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
    assign arith_original_142 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_122_s3))) * $unsigned(128'($unsigned(rtlzz_pipe_123_s3))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
    assign arith_original_143 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_124_s7))) * $unsigned(128'($unsigned(rtlzz_pipe_125_s7))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:55:1-55:12
    assign arith_original_144 = 128'(($unsigned(128'($unsigned(mul_precision_126))) * $unsigned(128'($unsigned(mul_precision_127))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
    assign arith_original_145 = 128'(($unsigned(128'($unsigned(rtlzz_pipe_128_s1))) * $unsigned(128'($unsigned(rtlzz_pipe_129_s1))))); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_100_s1 <= 64'h0;
            rtlzz_pipe_101_s1 <= 64'h0;
            rtlzz_pipe_102_s1 <= 64'h0;
            rtlzz_pipe_102_s2 <= 64'h0;
            rtlzz_pipe_103_s1 <= 64'h0;
            rtlzz_pipe_103_s2 <= 64'h0;
            rtlzz_pipe_104_s1 <= 64'h0;
            rtlzz_pipe_104_s2 <= 64'h0;
            rtlzz_pipe_104_s3 <= 64'h0;
            rtlzz_pipe_104_s4 <= 64'h0;
            rtlzz_pipe_105_s1 <= 64'h0;
            rtlzz_pipe_105_s2 <= 64'h0;
            rtlzz_pipe_105_s3 <= 64'h0;
            rtlzz_pipe_105_s4 <= 64'h0;
            rtlzz_pipe_106_s1 <= 64'h0;
            rtlzz_pipe_106_s2 <= 64'h0;
            rtlzz_pipe_106_s3 <= 64'h0;
            rtlzz_pipe_106_s4 <= 64'h0;
            rtlzz_pipe_106_s5 <= 64'h0;
            rtlzz_pipe_107_s1 <= 64'h0;
            rtlzz_pipe_107_s2 <= 64'h0;
            rtlzz_pipe_107_s3 <= 64'h0;
            rtlzz_pipe_107_s4 <= 64'h0;
            rtlzz_pipe_107_s5 <= 64'h0;
            rtlzz_pipe_110_s1 <= 64'h0;
            rtlzz_pipe_111_s1 <= 64'h0;
            rtlzz_pipe_112_s1 <= 64'h0;
            rtlzz_pipe_112_s2 <= 64'h0;
            rtlzz_pipe_113_s1 <= 64'h0;
            rtlzz_pipe_113_s2 <= 64'h0;
            rtlzz_pipe_116_s1 <= 64'h0;
            rtlzz_pipe_116_s2 <= 64'h0;
            rtlzz_pipe_116_s3 <= 64'h0;
            rtlzz_pipe_116_s4 <= 64'h0;
            rtlzz_pipe_117_s1 <= 64'h0;
            rtlzz_pipe_117_s2 <= 64'h0;
            rtlzz_pipe_117_s3 <= 64'h0;
            rtlzz_pipe_117_s4 <= 64'h0;
            rtlzz_pipe_118_s1 <= 64'h0;
            rtlzz_pipe_119_s1 <= 64'h0;
            rtlzz_pipe_120_s1 <= 64'h0;
            rtlzz_pipe_120_s2 <= 64'h0;
            rtlzz_pipe_121_s1 <= 64'h0;
            rtlzz_pipe_121_s2 <= 64'h0;
            rtlzz_pipe_122_s1 <= 64'h0;
            rtlzz_pipe_122_s2 <= 64'h0;
            rtlzz_pipe_122_s3 <= 64'h0;
            rtlzz_pipe_123_s1 <= 64'h0;
            rtlzz_pipe_123_s2 <= 64'h0;
            rtlzz_pipe_123_s3 <= 64'h0;
            rtlzz_pipe_124_s1 <= 64'h0;
            rtlzz_pipe_124_s2 <= 64'h0;
            rtlzz_pipe_124_s3 <= 64'h0;
            rtlzz_pipe_124_s4 <= 64'h0;
            rtlzz_pipe_124_s5 <= 64'h0;
            rtlzz_pipe_124_s6 <= 64'h0;
            rtlzz_pipe_124_s7 <= 64'h0;
            rtlzz_pipe_125_s1 <= 64'h0;
            rtlzz_pipe_125_s2 <= 64'h0;
            rtlzz_pipe_125_s3 <= 64'h0;
            rtlzz_pipe_125_s4 <= 64'h0;
            rtlzz_pipe_125_s5 <= 64'h0;
            rtlzz_pipe_125_s6 <= 64'h0;
            rtlzz_pipe_125_s7 <= 64'h0;
            rtlzz_pipe_128_s1 <= 64'h0;
            rtlzz_pipe_129_s1 <= 64'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_33_s2 <= 128'h0;
            rtlzz_pipe_33_s3 <= 128'h0;
            rtlzz_pipe_34_s2 <= 128'h0;
            rtlzz_pipe_34_s3 <= 128'h0;
            rtlzz_pipe_49_s4 <= 129'h0;
            rtlzz_pipe_49_s5 <= 129'h0;
            rtlzz_pipe_49_s6 <= 129'h0;
            rtlzz_pipe_49_s7 <= 129'h0;
            rtlzz_pipe_35_s3 <= 128'h0;
            rtlzz_pipe_35_s4 <= 128'h0;
            rtlzz_pipe_35_s5 <= 128'h0;
            rtlzz_pipe_35_s6 <= 128'h0;
            rtlzz_pipe_36_s5 <= 128'h0;
            rtlzz_pipe_36_s6 <= 128'h0;
            rtlzz_pipe_50_s7 <= 129'h0;
            rtlzz_pipe_38_s1 <= 128'h0;
            rtlzz_pipe_38_s2 <= 128'h0;
            rtlzz_pipe_38_s3 <= 128'h0;
            rtlzz_pipe_38_s4 <= 128'h0;
            rtlzz_pipe_38_s5 <= 128'h0;
            rtlzz_pipe_51_s6 <= 129'h0;
            rtlzz_pipe_39_s2 <= 128'h0;
            rtlzz_pipe_39_s3 <= 128'h0;
            rtlzz_pipe_40_s3 <= 128'h0;
            rtlzz_pipe_52_s4 <= 129'h0;
            rtlzz_pipe_52_s5 <= 129'h0;
            rtlzz_pipe_52_s6 <= 129'h0;
            rtlzz_pipe_58_s7 <= 130'h0;
            rtlzz_pipe_41_s1 <= 128'h0;
            rtlzz_pipe_41_s2 <= 128'h0;
            rtlzz_pipe_41_s3 <= 128'h0;
            rtlzz_pipe_41_s4 <= 128'h0;
            rtlzz_pipe_53_s5 <= 129'h0;
            rtlzz_pipe_53_s6 <= 129'h0;
            rtlzz_pipe_43_s2 <= 128'h0;
            rtlzz_pipe_43_s3 <= 128'h0;
            rtlzz_pipe_43_s4 <= 128'h0;
            rtlzz_pipe_43_s5 <= 128'h0;
            rtlzz_pipe_44_s3 <= 128'h0;
            rtlzz_pipe_44_s4 <= 128'h0;
            rtlzz_pipe_44_s5 <= 128'h0;
            rtlzz_pipe_54_s6 <= 129'h0;
            rtlzz_pipe_59_s7 <= 130'h0;
            rtlzz_pipe_45_s4 <= 128'h0;
            rtlzz_pipe_45_s5 <= 128'h0;
            rtlzz_pipe_45_s6 <= 128'h0;
            rtlzz_pipe_45_s7 <= 128'h0;
            rtlzz_pipe_47_s1 <= 128'h0;
            rtlzz_pipe_47_s2 <= 128'h0;
            rtlzz_pipe_47_s3 <= 128'h0;
            rtlzz_pipe_47_s4 <= 128'h0;
            rtlzz_pipe_48_s2 <= 128'h0;
            rtlzz_pipe_48_s3 <= 128'h0;
            rtlzz_pipe_48_s4 <= 128'h0;
            rtlzz_pipe_56_s5 <= 129'h0;
            rtlzz_pipe_56_s6 <= 129'h0;
            rtlzz_pipe_56_s7 <= 129'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_100_s1 <= mul_precision_100; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_101_s1 <= mul_precision_101; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_precision_102; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_102_s2 <= rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_103_s1 <= mul_precision_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_103_s2 <= rtlzz_pipe_103_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_104_s1 <= mul_precision_104; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_104_s2 <= rtlzz_pipe_104_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_104_s3 <= rtlzz_pipe_104_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_104_s4 <= rtlzz_pipe_104_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_precision_105; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_105_s2 <= rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_105_s3 <= rtlzz_pipe_105_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_105_s4 <= rtlzz_pipe_105_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_106_s1 <= mul_precision_106; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_106_s2 <= rtlzz_pipe_106_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_106_s3 <= rtlzz_pipe_106_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_106_s4 <= rtlzz_pipe_106_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_106_s5 <= rtlzz_pipe_106_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_107_s1 <= mul_precision_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_107_s2 <= rtlzz_pipe_107_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_107_s3 <= rtlzz_pipe_107_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_107_s4 <= rtlzz_pipe_107_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_107_s5 <= rtlzz_pipe_107_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_110_s1 <= mul_precision_110; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_precision_111; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_112_s1 <= mul_precision_112; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_112_s2 <= rtlzz_pipe_112_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_113_s1 <= mul_precision_113; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_113_s2 <= rtlzz_pipe_113_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_116_s1 <= mul_precision_116; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_116_s2 <= rtlzz_pipe_116_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_116_s3 <= rtlzz_pipe_116_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_116_s4 <= rtlzz_pipe_116_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_117_s1 <= mul_precision_117; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_117_s2 <= rtlzz_pipe_117_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_117_s3 <= rtlzz_pipe_117_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_117_s4 <= rtlzz_pipe_117_s3; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_118_s1 <= mul_precision_118; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_119_s1 <= mul_precision_119; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_120_s1 <= mul_precision_120; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_120_s2 <= rtlzz_pipe_120_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_121_s1 <= mul_precision_121; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_121_s2 <= rtlzz_pipe_121_s1; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_122_s1 <= mul_precision_122; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_122_s2 <= rtlzz_pipe_122_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_122_s3 <= rtlzz_pipe_122_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_123_s1 <= mul_precision_123; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_123_s2 <= rtlzz_pipe_123_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_123_s3 <= rtlzz_pipe_123_s2; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_124_s1 <= mul_precision_124; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_124_s2 <= rtlzz_pipe_124_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_124_s3 <= rtlzz_pipe_124_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_124_s4 <= rtlzz_pipe_124_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_124_s5 <= rtlzz_pipe_124_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_124_s6 <= rtlzz_pipe_124_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_124_s7 <= rtlzz_pipe_124_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_125_s1 <= mul_precision_125; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_125_s2 <= rtlzz_pipe_125_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_125_s3 <= rtlzz_pipe_125_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_125_s4 <= rtlzz_pipe_125_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_125_s5 <= rtlzz_pipe_125_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_125_s6 <= rtlzz_pipe_125_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_125_s7 <= rtlzz_pipe_125_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_128_s1 <= mul_precision_128; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_129_s1 <= mul_precision_129; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= rtlzz_pipe_33_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_33_s3 <= rtlzz_pipe_33_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_34_s2 <= s8_norm_mul_6_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_34_s3 <= rtlzz_pipe_34_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_49_s4 <= s8_norm_add_64_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_49_s5 <= rtlzz_pipe_49_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_49_s6 <= rtlzz_pipe_49_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_49_s7 <= rtlzz_pipe_49_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:73:28-73:55
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_36_s5 <= s8_norm_mul_14_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_36_s6 <= rtlzz_pipe_36_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:11
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_50_s7 <= s8_norm_add_65_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:75:28-75:55
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= s8_norm_mul_22_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_38_s2 <= rtlzz_pipe_38_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_38_s3 <= rtlzz_pipe_38_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_38_s4 <= rtlzz_pipe_38_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_38_s5 <= rtlzz_pipe_38_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:23:1-23:11
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_51_s6 <= s8_norm_add_66_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:28-77:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_39_s2 <= s8_norm_mul_26_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_39_s3 <= rtlzz_pipe_39_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:27:1-27:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_40_s3 <= s8_norm_mul_30_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:31:1-31:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_52_s4 <= s8_norm_add_67_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_52_s5 <= rtlzz_pipe_52_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_52_s6 <= rtlzz_pipe_52_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:79:28-79:55
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_58_s7 <= s8_norm_add_73_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:77:5-77:57
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= s8_norm_mul_34_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_41_s2 <= rtlzz_pipe_41_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_41_s3 <= rtlzz_pipe_41_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_41_s4 <= rtlzz_pipe_41_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:35:1-35:11
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_53_s5 <= s8_norm_add_68_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_53_s6 <= rtlzz_pipe_53_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:28-81:55
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_43_s2 <= s8_norm_mul_42_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_43_s3 <= rtlzz_pipe_43_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_43_s4 <= rtlzz_pipe_43_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_43_s5 <= rtlzz_pipe_43_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:43:1-43:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_44_s3 <= s8_norm_mul_46_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_44_s4 <= rtlzz_pipe_44_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_44_s5 <= rtlzz_pipe_44_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:47:1-47:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_54_s6 <= s8_norm_add_69_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:83:29-83:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_59_s7 <= s8_norm_add_74_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:81:5-81:57
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_45_s4 <= s8_norm_mul_50_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_45_s5 <= rtlzz_pipe_45_s4; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_45_s6 <= rtlzz_pipe_45_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_45_s7 <= rtlzz_pipe_45_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:51:1-51:12
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= s8_norm_mul_58_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_47_s2 <= rtlzz_pipe_47_s1; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_47_s3 <= rtlzz_pipe_47_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_47_s4 <= rtlzz_pipe_47_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:59:1-59:12
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_48_s2 <= s8_norm_mul_62_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_48_s3 <= rtlzz_pipe_48_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_48_s4 <= rtlzz_pipe_48_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:63:1-63:12
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_56_s5 <= s8_norm_add_71_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_56_s6 <= rtlzz_pipe_56_s5; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_56_s7 <= rtlzz_pipe_56_s6; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:87:29-87:58
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:67:1-67:8; prim: /home/zyrv/vulsim/workload.cpp:67:1-67:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a0_data,input wire a0_wen,input wire [63:0] b0_data,input wire b0_wen,input wire [63:0] a1_data,input wire a1_wen,input wire [63:0] b1_data,input wire b1_wen,input wire [63:0] a2_data,input wire a2_wen,input wire [63:0] b2_data,input wire b2_wen,input wire [63:0] a3_data,input wire a3_wen,input wire [63:0] b3_data,input wire b3_wen,input wire [63:0] a4_data,input wire a4_wen,input wire [63:0] b4_data,input wire b4_wen,input wire [63:0] a5_data,input wire a5_wen,input wire [63:0] b5_data,input wire b5_wen,input wire [63:0] a6_data,input wire a6_wen,input wire [63:0] b6_data,input wire b6_wen,input wire [63:0] a7_data,input wire a7_wen,input wire [63:0] b7_data,input wire b7_wen,input wire [63:0] a8_data,input wire a8_wen,input wire [63:0] b8_data,input wire b8_wen,input wire [63:0] a9_data,input wire a9_wen,input wire [63:0] b9_data,input wire b9_wen,input wire [63:0] a10_data,input wire a10_wen,input wire [63:0] b10_data,input wire b10_wen,input wire [63:0] a11_data,input wire a11_wen,input wire [63:0] b11_data,input wire b11_wen,input wire [63:0] a12_data,input wire a12_wen,input wire [63:0] b12_data,input wire b12_wen,input wire [63:0] a13_data,input wire a13_wen,input wire [63:0] b13_data,input wire b13_wen,input wire [63:0] a14_data,input wire a14_wen,input wire [63:0] b14_data,input wire b14_wen,input wire [63:0] a15_data,input wire a15_wen,input wire [63:0] b15_data,input wire b15_wen,output reg [131:0] y);
reg liv;wire cov;
reg [63:0] l_a0;
reg [63:0] l_b0;
reg [63:0] l_a1;
reg [63:0] l_b1;
reg [63:0] l_a2;
reg [63:0] l_b2;
reg [63:0] l_a3;
reg [63:0] l_b3;
reg [63:0] l_a4;
reg [63:0] l_b4;
reg [63:0] l_a5;
reg [63:0] l_b5;
reg [63:0] l_a6;
reg [63:0] l_b6;
reg [63:0] l_a7;
reg [63:0] l_b7;
reg [63:0] l_a8;
reg [63:0] l_b8;
reg [63:0] l_a9;
reg [63:0] l_b9;
reg [63:0] l_a10;
reg [63:0] l_b10;
reg [63:0] l_a11;
reg [63:0] l_b11;
reg [63:0] l_a12;
reg [63:0] l_b12;
reg [63:0] l_a13;
reg [63:0] l_b13;
reg [63:0] l_a14;
reg [63:0] l_b14;
reg [63:0] l_a15;
reg [63:0] l_b15;
wire [131:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a0(l_a0),.b0(l_b0),.a1(l_a1),.b1(l_b1),.a2(l_a2),.b2(l_b2),.a3(l_a3),.b3(l_b3),.a4(l_a4),.b4(l_b4),.a5(l_a5),.b5(l_b5),.a6(l_a6),.b6(l_b6),.a7(l_a7),.b7(l_b7),.a8(l_a8),.b8(l_b8),.a9(l_a9),.b9(l_b9),.a10(l_a10),.b10(l_b10),.a11(l_a11),.b11(l_b11),.a12(l_a12),.b12(l_b12),.a13(l_a13),.b13(l_b13),.a14(l_a14),.b14(l_b14),.a15(l_a15),.b15(l_b15),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a0<=64'h0;l_b0<=64'h0;l_a1<=64'h0;l_b1<=64'h0;l_a2<=64'h0;l_b2<=64'h0;l_a3<=64'h0;l_b3<=64'h0;l_a4<=64'h0;l_b4<=64'h0;l_a5<=64'h0;l_b5<=64'h0;l_a6<=64'h0;l_b6<=64'h0;l_a7<=64'h0;l_b7<=64'h0;l_a8<=64'h0;l_b8<=64'h0;l_a9<=64'h0;l_b9<=64'h0;l_a10<=64'h0;l_b10<=64'h0;l_a11<=64'h0;l_b11<=64'h0;l_a12<=64'h0;l_b12<=64'h0;l_a13<=64'h0;l_b13<=64'h0;l_a14<=64'h0;l_b14<=64'h0;l_a15<=64'h0;l_b15<=64'h0;y<=132'h000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a0_wen)l_a0<=a0_data;if(b0_wen)l_b0<=b0_data;if(a1_wen)l_a1<=a1_data;if(b1_wen)l_b1<=b1_data;if(a2_wen)l_a2<=a2_data;if(b2_wen)l_b2<=b2_data;if(a3_wen)l_a3<=a3_data;if(b3_wen)l_b3<=b3_data;if(a4_wen)l_a4<=a4_data;if(b4_wen)l_b4<=b4_data;if(a5_wen)l_a5<=a5_data;if(b5_wen)l_b5<=b5_data;if(a6_wen)l_a6<=a6_data;if(b6_wen)l_b6<=b6_data;if(a7_wen)l_a7<=a7_data;if(b7_wen)l_b7<=b7_data;if(a8_wen)l_a8<=a8_data;if(b8_wen)l_b8<=b8_data;if(a9_wen)l_a9<=a9_data;if(b9_wen)l_b9<=b9_data;if(a10_wen)l_a10<=a10_data;if(b10_wen)l_b10<=b10_data;if(a11_wen)l_a11<=a11_data;if(b11_wen)l_b11<=b11_data;if(a12_wen)l_a12<=a12_data;if(b12_wen)l_b12<=b12_data;if(a13_wen)l_a13<=a13_data;if(b13_wen)l_b13<=b13_data;if(a14_wen)l_a14<=a14_data;if(b14_wen)l_b14<=b14_data;if(a15_wen)l_a15<=a15_data;if(b15_wen)l_b15<=b15_data;y<=c_y;end
endmodule
