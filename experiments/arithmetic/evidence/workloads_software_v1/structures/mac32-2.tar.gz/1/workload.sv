`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [7:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [41:0] rtlzz_pipe_102_s1; // decl: <none>; prim: <none>
    logic [49:0] rtlzz_pipe_105_s1; // decl: <none>; prim: <none>
    logic [57:0] rtlzz_pipe_108_s1; // decl: <none>; prim: <none>
    logic [65:0] rtlzz_pipe_111_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_4_s2; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (rtlzz_pipe_4_s2 + rtlzz_pipe_2_s2); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 16'(($unsigned(16'($unsigned(mul_tree_12_13))) * $unsigned(16'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 16'(($unsigned(16'($unsigned(mul_tree_12_16))) * $unsigned(16'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 16'(($unsigned(16'($unsigned(mul_tree_12_20))) * $unsigned(16'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 16'(($unsigned(16'($unsigned(mul_tree_12_24))) * $unsigned(16'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 16'(($unsigned(16'($unsigned(mul_tree_12_28))) * $unsigned(16'($unsigned(mul_tree_12_29))))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = {mul_tree_12_30, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_34 = 16'(($unsigned(16'($unsigned(mul_tree_12_32))) * $unsigned(16'($unsigned(mul_tree_12_33))))); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = {mul_tree_12_34, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_38 = 16'(($unsigned(16'($unsigned(mul_tree_12_36))) * $unsigned(16'($unsigned(mul_tree_12_37))))); // decl: <none>; prim: <none>
    assign mul_tree_12_39 = {mul_tree_12_38, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = mul_precision_10[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_42 = 16'(($unsigned(16'($unsigned(mul_tree_12_40))) * $unsigned(16'($unsigned(mul_tree_12_41))))); // decl: <none>; prim: <none>
    assign mul_tree_12_43 = {mul_tree_12_42, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_46 = 16'(($unsigned(16'($unsigned(mul_tree_12_44))) * $unsigned(16'($unsigned(mul_tree_12_45))))); // decl: <none>; prim: <none>
    assign mul_tree_12_47 = {mul_tree_12_46, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_50 = 16'(($unsigned(16'($unsigned(mul_tree_12_48))) * $unsigned(16'($unsigned(mul_tree_12_49))))); // decl: <none>; prim: <none>
    assign mul_tree_12_51 = {mul_tree_12_50, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_54 = 16'(($unsigned(16'($unsigned(mul_tree_12_52))) * $unsigned(16'($unsigned(mul_tree_12_53))))); // decl: <none>; prim: <none>
    assign mul_tree_12_55 = {mul_tree_12_54, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = mul_precision_10[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_58 = 16'(($unsigned(16'($unsigned(mul_tree_12_56))) * $unsigned(16'($unsigned(mul_tree_12_57))))); // decl: <none>; prim: <none>
    assign mul_tree_12_59 = {mul_tree_12_58, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = mul_precision_11[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_62 = 16'(($unsigned(16'($unsigned(mul_tree_12_60))) * $unsigned(16'($unsigned(mul_tree_12_61))))); // decl: <none>; prim: <none>
    assign mul_tree_12_63 = {mul_tree_12_62, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = mul_precision_11[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_12_66 = 16'(($unsigned(16'($unsigned(mul_tree_12_64))) * $unsigned(16'($unsigned(mul_tree_12_65))))); // decl: <none>; prim: <none>
    assign mul_tree_12_67 = {mul_tree_12_66, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = mul_precision_11[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_70 = 16'(($unsigned(16'($unsigned(mul_tree_12_68))) * $unsigned(16'($unsigned(mul_tree_12_69))))); // decl: <none>; prim: <none>
    assign mul_tree_12_71 = {mul_tree_12_70, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = mul_precision_10[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = mul_precision_11[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_74 = 16'(($unsigned(16'($unsigned(mul_tree_12_72))) * $unsigned(16'($unsigned(mul_tree_12_73))))); // decl: <none>; prim: <none>
    assign mul_tree_12_75 = {mul_tree_12_74, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({9'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    assign mul_tree_12_78 = 25'((mul_tree_12_76 + mul_tree_12_77 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({9'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    assign mul_tree_12_81 = 41'((mul_tree_12_79 + mul_tree_12_80 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({9'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    assign mul_tree_12_84 = 33'((mul_tree_12_82 + mul_tree_12_83 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({9'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    assign mul_tree_12_87 = 49'((mul_tree_12_85 + mul_tree_12_86 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({9'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    assign mul_tree_12_90 = 41'((mul_tree_12_88 + mul_tree_12_89 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({9'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    assign mul_tree_12_93 = 57'((mul_tree_12_91 + mul_tree_12_92 + ({56'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({9'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    assign mul_tree_12_96 = 49'((mul_tree_12_94 + mul_tree_12_95 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({9'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    assign mul_tree_12_99 = 65'((mul_tree_12_97 + mul_tree_12_98 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({17'h0, mul_tree_12_78}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, mul_tree_12_81}); // decl: <none>; prim: <none>
    assign mul_tree_12_102 = 42'((mul_tree_12_100 + mul_tree_12_101 + ({41'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_103 = ({17'h0, mul_tree_12_84}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_105 = 50'((mul_tree_12_103 + mul_tree_12_104 + ({49'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_106 = ({17'h0, mul_tree_12_90}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, mul_tree_12_93}); // decl: <none>; prim: <none>
    assign mul_tree_12_108 = 58'((mul_tree_12_106 + mul_tree_12_107 + ({57'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_109 = ({17'h0, mul_tree_12_96}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    assign mul_tree_12_111 = 66'((mul_tree_12_109 + mul_tree_12_110 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_112 = ({9'h0, rtlzz_pipe_102_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, rtlzz_pipe_105_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_114 = 51'((mul_tree_12_112 + mul_tree_12_113 + ({50'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_115 = ({9'h0, rtlzz_pipe_108_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, rtlzz_pipe_111_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_117 = 67'((mul_tree_12_115 + mul_tree_12_116 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_118 = ({17'h0, mul_tree_12_114}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, mul_tree_12_117}); // decl: <none>; prim: <none>
    assign mul_tree_12_120 = 68'((mul_tree_12_118 + mul_tree_12_119 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_102_s1 <= 42'h0;
            rtlzz_pipe_105_s1 <= 50'h0;
            rtlzz_pipe_108_s1 <= 58'h0;
            rtlzz_pipe_111_s1 <= 66'h0;
            rtlzz_pipe_4_s2 <= 64'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_102_s1 <= mul_tree_12_102; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_105_s1 <= mul_tree_12_105; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_108_s1 <= mul_tree_12_108; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_111_s1 <= mul_tree_12_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_4_s2 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
