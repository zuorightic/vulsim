`timescale 1ns/1ps

module WorkloadCore(
    input logic [31:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:8; prim: /home/zyrv/vulsim/workload.cpp:13:1-13:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [63:0] s8_norm_add_4_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    logic [63:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_10; // decl: <none>; prim: <none>
    logic [31:0] mul_precision_11; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    logic [15:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [63:0] rtlzz_pipe_2_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
    logic [31:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_30_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_33_s2; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8


    assign s8_norm_mul_2_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + rtlzz_pipe_2_s2); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:15:23-15:33
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:10; prim: /home/zyrv/vulsim/workload.cpp:15:5-15:47
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign __beopt_width_10 = ({32'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({32'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_10 = __beopt_width_10[31:0]; // decl: <none>; prim: <none>
    assign mul_precision_11 = __beopt_width_11[31:0]; // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_37; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 32'(($unsigned(32'($unsigned(mul_tree_12_13))) * $unsigned(32'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = mul_precision_10[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 32'(($unsigned(32'($unsigned(mul_tree_12_16))) * $unsigned(32'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = mul_precision_11[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 32'(($unsigned(32'($unsigned(mul_tree_12_20))) * $unsigned(32'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = mul_precision_10[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = mul_precision_11[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 32'(($unsigned(32'($unsigned(mul_tree_12_24))) * $unsigned(32'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = ({17'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_29 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 49'((mul_tree_12_28 + mul_tree_12_29 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = ({17'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_32 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_33 = 65'((mul_tree_12_31 + mul_tree_12_32 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_34 = ({17'h0, rtlzz_pipe_30_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = ({1'h0, rtlzz_pipe_33_s2}); // decl: <none>; prim: <none>
    assign mul_tree_12_36 = 66'((mul_tree_12_34 + mul_tree_12_35 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_tree_12_36[63:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_2_s1 <= 64'h0;
            rtlzz_pipe_2_s2 <= 64'h0;
            rtlzz_pipe_15_s1 <= 32'h0;
            rtlzz_pipe_19_s1 <= 48'h0;
            rtlzz_pipe_23_s1 <= 48'h0;
            rtlzz_pipe_27_s1 <= 64'h0;
            rtlzz_pipe_30_s2 <= 49'h0;
            rtlzz_pipe_33_s2 <= 65'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_2_s1 <= c; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_2_s2 <= rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:10; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_30_s2 <= mul_tree_12_30; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_33_s2 <= mul_tree_12_33; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:8; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [31:0] a_data,input wire a_wen,input wire [31:0] b_data,input wire b_wen,input wire [63:0] c_data,input wire c_wen,output reg [63:0] y);
reg liv;wire cov;
reg [31:0] l_a;
reg [31:0] l_b;
reg [63:0] l_c;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.c(l_c),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=32'h0;l_b<=32'h0;l_c<=64'h0;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(c_wen)l_c<=c_data;y<=c_y;end
endmodule
