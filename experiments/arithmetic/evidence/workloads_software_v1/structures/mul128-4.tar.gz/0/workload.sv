`timescale 1ns/1ps

module WorkloadCore(
    input logic [127:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:11; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:11; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    output logic [255:0] y, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [255:0] __beopt_width_8; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_9; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_8; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_9; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic [63:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_28_s2; // decl: <none>; prim: <none>
    logic [256:0] rtlzz_pipe_31_s2; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_3_s3; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8


    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_3_s3; // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:13:5-13:36
    assign ov = rtlzz_valid_s3; // decl: <none>; prim: <none>
    assign __beopt_width_8 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_9 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign mul_precision_8 = __beopt_width_8[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_9 = __beopt_width_9[127:0]; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = mul_precision_8[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = mul_precision_9[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 128'(($unsigned(128'($unsigned(mul_tree_10_11))) * $unsigned(128'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = mul_precision_8[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = mul_precision_9[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 128'(($unsigned(128'($unsigned(mul_tree_10_14))) * $unsigned(128'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = mul_precision_8[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = mul_precision_9[63:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 128'(($unsigned(128'($unsigned(mul_tree_10_18))) * $unsigned(128'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = mul_precision_8[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = mul_precision_9[127:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 128'(($unsigned(128'($unsigned(mul_tree_10_22))) * $unsigned(128'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({65'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 193'((mul_tree_10_26 + mul_tree_10_27 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({65'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 257'((mul_tree_10_29 + mul_tree_10_30 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({65'h0, rtlzz_pipe_28_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, rtlzz_pipe_31_s2}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 258'((mul_tree_10_32 + mul_tree_10_33 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 128'h0;
            rtlzz_pipe_17_s1 <= 192'h0;
            rtlzz_pipe_21_s1 <= 192'h0;
            rtlzz_pipe_25_s1 <= 256'h0;
            rtlzz_pipe_28_s2 <= 193'h0;
            rtlzz_pipe_31_s2 <= 257'h0;
            rtlzz_pipe_3_s3 <= 256'h0;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_28_s2 <= mul_tree_10_28; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_31_s2 <= mul_tree_10_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_3_s3 <= s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:8; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [127:0] a_data,input wire a_wen,input wire [127:0] b_data,input wire b_wen,output reg [255:0] y);
reg liv;wire cov;
reg [127:0] l_a;
reg [127:0] l_b;
wire [255:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=128'h00000000000000000;l_b<=128'h00000000000000000;y<=256'h0000000000000000000000000000000000000000000000000;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;y<=c_y;end
endmodule
