`timescale 1ns/1ps

module WorkloadCore(
    input logic [63:0] a, // decl: /home/zyrv/vulsim/workload.cpp:3:1-3:10; prim: /home/zyrv/vulsim/workload.cpp:3:1-3:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/workload.cpp:5:1-5:10; prim: /home/zyrv/vulsim/workload.cpp:5:1-5:10
    input logic [63:0] modulus, // decl: /home/zyrv/vulsim/workload.cpp:7:1-7:16; prim: /home/zyrv/vulsim/workload.cpp:7:1-7:16
    input logic [64:0] mu, // decl: /home/zyrv/vulsim/workload.cpp:9:1-9:11; prim: /home/zyrv/vulsim/workload.cpp:9:1-9:11
    input logic iv, // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    output logic [63:0] y, // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    output logic ov, // decl: /home/zyrv/vulsim/workload.cpp:15:1-15:8; prim: /home/zyrv/vulsim/workload.cpp:15:1-15:8
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] tmp_workload_top_int_128__0_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    logic [127:0] tmp_workload_top_int_128__2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    logic [255:0] s8_norm_mul_2_v0; // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:44
    logic [192:0] tmp_workload_top_int_193__5_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    logic [192:0] tmp_workload_top_int_193__7_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [385:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [192:0] n1_v0; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    logic [128:0] tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [257:0] s8_norm_mul_11_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:19-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] n3_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    logic [128:0] tmp_workload_top_int_129__16_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    logic [128:0] s8_norm_sub_14_v0; // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:36; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:36
    logic s8_norm_cmp_16_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    logic [128:0] s8_norm_sub_18_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:52-22:74; prim: /home/zyrv/vulsim/workload.cpp:22:52-22:74
    logic [128:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    logic [63:0] tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    logic [192:0] __beopt_width_54; // decl: <none>; prim: <none>
    logic [64:0] __beopt_width_55; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_57; // decl: <none>; prim: <none>
    logic [128:0] __beopt_width_31; // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    logic [128:0] __beopt_width_29; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_28; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_29; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_30; // decl: <none>; prim: <none>
    logic [127:0] mul_precision_31; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_32; // decl: <none>; prim: <none>
    logic [192:0] mul_precision_33; // decl: <none>; prim: <none>
    logic [64:0] mul_precision_34; // decl: <none>; prim: <none>
    logic [63:0] mul_precision_35; // decl: <none>; prim: <none>
    logic [128:0] mul_precision_36; // decl: <none>; prim: <none>
    logic [127:0] arith_original_37; // decl: <none>; prim: <none>
    logic [192:0] arith_original_38; // decl: <none>; prim: <none>
    logic [128:0] arith_original_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_41; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_49; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_37_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_37_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_37_53; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_54; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_55; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_56; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_37_57; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_58; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_59; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_37_60; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_61; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_62; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_37_63; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_37_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_66; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_69; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_70; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_72; // decl: <none>; prim: <none>
    logic mul_tree_38_73; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_77; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_78; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_38_79; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_80; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_81; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_82; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_83; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_84; // decl: <none>; prim: <none>
    logic mul_tree_38_85; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_38_87; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_88; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_89; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_90; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_38_91; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_92; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_93; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_94; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_95; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_96; // decl: <none>; prim: <none>
    logic mul_tree_38_97; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_98; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_101; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_102; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_38_103; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_104; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_105; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_38_106; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_38_107; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_38_108; // decl: <none>; prim: <none>
    logic mul_tree_38_109; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_38_110; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_111; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_112; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_113; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_38_114; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_115; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_116; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_38_117; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_118; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_119; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_38_120; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_121; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_122; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_38_123; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_124; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_125; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_126; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_127; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_128; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_38_129; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_130; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_131; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_38_132; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_133; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_134; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_38_135; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_136; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_137; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_38_138; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_139; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_140; // decl: <none>; prim: <none>
    logic [162:0] mul_tree_38_141; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_142; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_143; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_38_144; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_38_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_146; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_147; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_150; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_151; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_154; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_155; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_39_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_39_159; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_39_160; // decl: <none>; prim: <none>
    logic mul_tree_39_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_162; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_163; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_164; // decl: <none>; prim: <none>
    logic mul_tree_39_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_39_166; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_39_167; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_168; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_169; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_170; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_39_171; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_172; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_173; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_174; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_175; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_176; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_177; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_178; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_179; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_39_180; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_181; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_182; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_39_183; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_39_184; // decl: <none>; prim: <none>
    logic [63:0] limb_16_185; // decl: <none>; prim: <none>
    logic [63:0] limb_16_186; // decl: <none>; prim: <none>
    logic [63:0] limb_16_187; // decl: <none>; prim: <none>
    logic [64:0] limb_16_188; // decl: <none>; prim: <none>
    logic [63:0] limb_16_189; // decl: <none>; prim: <none>
    logic limb_16_190; // decl: <none>; prim: <none>
    logic [63:0] limb_16_191; // decl: <none>; prim: <none>
    logic [63:0] limb_16_192; // decl: <none>; prim: <none>
    logic [63:0] limb_16_193; // decl: <none>; prim: <none>
    logic [64:0] limb_16_194; // decl: <none>; prim: <none>
    logic [63:0] limb_16_195; // decl: <none>; prim: <none>
    logic limb_16_196; // decl: <none>; prim: <none>
    logic limb_16_197; // decl: <none>; prim: <none>
    logic limb_16_198; // decl: <none>; prim: <none>
    logic limb_16_199; // decl: <none>; prim: <none>
    logic [1:0] limb_16_200; // decl: <none>; prim: <none>
    logic limb_16_201; // decl: <none>; prim: <none>
    logic [128:0] limb_16_202; // decl: <none>; prim: <none>
    logic [63:0] limb_18_203; // decl: <none>; prim: <none>
    logic [63:0] limb_18_204; // decl: <none>; prim: <none>
    logic [63:0] limb_18_205; // decl: <none>; prim: <none>
    logic [64:0] limb_18_206; // decl: <none>; prim: <none>
    logic [63:0] limb_18_207; // decl: <none>; prim: <none>
    logic limb_18_208; // decl: <none>; prim: <none>
    logic [63:0] limb_18_209; // decl: <none>; prim: <none>
    logic [63:0] limb_18_210; // decl: <none>; prim: <none>
    logic [63:0] limb_18_211; // decl: <none>; prim: <none>
    logic [64:0] limb_18_212; // decl: <none>; prim: <none>
    logic [63:0] limb_18_213; // decl: <none>; prim: <none>
    logic limb_18_214; // decl: <none>; prim: <none>
    logic limb_18_215; // decl: <none>; prim: <none>
    logic limb_18_216; // decl: <none>; prim: <none>
    logic limb_18_217; // decl: <none>; prim: <none>
    logic [1:0] limb_18_218; // decl: <none>; prim: <none>
    logic limb_18_219; // decl: <none>; prim: <none>
    logic [128:0] limb_18_220; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [128:0] rtlzz_pipe_12_s7; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    logic [64:0] rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_32_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_57_s2; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_60_s2; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_23_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_25_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_31_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_67_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_71_s6; // decl: <none>; prim: <none>
    logic [96:0] rtlzz_pipe_75_s6; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_79_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_83_s6; // decl: <none>; prim: <none>
    logic [128:0] rtlzz_pipe_87_s6; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_91_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_95_s6; // decl: <none>; prim: <none>
    logic [160:0] rtlzz_pipe_99_s6; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_103_s6; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_107_s6; // decl: <none>; prim: <none>
    logic [192:0] rtlzz_pipe_111_s6; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_34_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_185_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_185_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_185_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_191_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_191_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_197_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_205_s7; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_210_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_210_s2; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_211_s3; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_211_s4; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_211_s5; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_211_s6; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_211_s7; // decl: <none>; prim: <none>
    logic rtlzz_pipe_216_s1; // decl: <none>; prim: <none>
    logic rtlzz_pipe_216_s2; // decl: <none>; prim: <none>
    logic rtlzz_pipe_216_s3; // decl: <none>; prim: <none>
    logic rtlzz_pipe_216_s4; // decl: <none>; prim: <none>
    logic rtlzz_pipe_217_s5; // decl: <none>; prim: <none>
    logic rtlzz_pipe_217_s6; // decl: <none>; prim: <none>
    logic rtlzz_pipe_217_s7; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
    logic rtlzz_valid_s7; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8


    assign tmp_workload_top_int_128__0_v0 = ({64'h0, a}); // decl: /home/zyrv/vulsim/workload.cpp:17:19-17:30; prim: /home/zyrv/vulsim/workload.cpp:17:19-17:30
    assign tmp_workload_top_int_128__2_v0 = ({64'h0, b}); // decl: /home/zyrv/vulsim/workload.cpp:17:33-17:44; prim: /home/zyrv/vulsim/workload.cpp:17:33-17:44
    assign s8_norm_mul_2_v0 = ({128'h0, mul_precision_30}); // decl: <none>; prim: <none>
    assign tmp_workload_top_int_193__5_v0 = (rtlzz_pipe_23_s3 & 193'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:18:19-18:31; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:31
    assign tmp_workload_top_int_193__7_v0 = ({128'h0, mu}); // decl: /home/zyrv/vulsim/workload.cpp:18:34-18:46; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign s8_norm_mul_6_v0 = ({193'h0, mul_precision_33}); // decl: <none>; prim: <none>
    assign n1_v0 = s8_norm_mul_6_v0[192:0]; // decl: /home/zyrv/vulsim/workload.cpp:18:5-18:47; prim: /home/zyrv/vulsim/workload.cpp:18:19-18:46
    assign tmp_workload_top_int_129__13_v0 = ({65'h0, modulus}); // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
    assign s8_norm_mul_11_v0 = ({129'h0, mul_precision_36}); // decl: <none>; prim: <none>
    assign n3_v0 = s8_norm_mul_11_v0[128:0]; // decl: /home/zyrv/vulsim/workload.cpp:20:5-20:52; prim: /home/zyrv/vulsim/workload.cpp:20:19-20:51
    assign tmp_workload_top_int_129__16_v0 = (rtlzz_pipe_25_s4 & 129'hffffffffffffffffffffffffffffffff); // decl: /home/zyrv/vulsim/workload.cpp:21:19-21:31; prim: /home/zyrv/vulsim/workload.cpp:21:19-21:31
    assign s8_norm_sub_14_v0 = limb_16_202; // decl: <none>; prim: <none>
    assign s8_norm_cmp_16_v0 = (s8_norm_sub_14_v0 < rtlzz_pipe_12_s7); // decl: /home/zyrv/vulsim/workload.cpp:22:20-22:42; prim: /home/zyrv/vulsim/workload.cpp:22:20-22:42
    assign s8_norm_sub_18_v0 = limb_18_220; // decl: <none>; prim: <none>
    assign s8_norm_mux_19_v0 = (s8_norm_cmp_16_v0 ? s8_norm_sub_14_v0 : s8_norm_sub_18_v0); // decl: /home/zyrv/vulsim/workload.cpp:22:19-22:75; prim: /home/zyrv/vulsim/workload.cpp:22:19-22:75
    assign tmp_workload_top_int_64__27_v0 = s8_norm_mux_19_v0[63:0]; // decl: /home/zyrv/vulsim/workload.cpp:23:18-23:29; prim: /home/zyrv/vulsim/workload.cpp:23:18-23:29
    assign y = tmp_workload_top_int_64__27_v0; // decl: /home/zyrv/vulsim/workload.cpp:13:1-13:10; prim: /home/zyrv/vulsim/workload.cpp:24:5-24:11
    assign ov = rtlzz_valid_s7; // decl: <none>; prim: <none>
    assign __beopt_width_54 = s8_norm_mul_2_v0[192:0]; // decl: <none>; prim: <none>
    assign __beopt_width_55 = n1_v0[192:128]; // decl: <none>; prim: <none>
    assign __beopt_width_57 = s8_norm_mul_2_v0[128:0]; // decl: <none>; prim: <none>
    assign __beopt_width_31 = (__beopt_width_29 & 129'h1ffffffffffffffff); // decl: <none>; prim: /home/zyrv/vulsim/workload.cpp:18:34-18:46
    assign __beopt_width_29 = ({64'h0, __beopt_width_55}); // decl: <none>; prim: <none>
    assign mul_precision_28 = tmp_workload_top_int_128__0_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_29 = tmp_workload_top_int_128__2_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_30 = arith_original_37; // decl: <none>; prim: <none>
    assign mul_precision_31 = tmp_workload_top_int_193__5_v0[127:0]; // decl: <none>; prim: <none>
    assign mul_precision_32 = tmp_workload_top_int_193__7_v0[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_33 = arith_original_38; // decl: <none>; prim: <none>
    assign mul_precision_34 = __beopt_width_31[64:0]; // decl: <none>; prim: <none>
    assign mul_precision_35 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign mul_precision_36 = arith_original_39; // decl: <none>; prim: <none>
    assign arith_original_37 = mul_tree_37_64; // decl: <none>; prim: <none>
    assign arith_original_38 = mul_tree_38_145; // decl: <none>; prim: <none>
    assign arith_original_39 = mul_tree_39_184; // decl: <none>; prim: <none>
    assign mul_tree_37_40 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_41 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_42 = 64'(($unsigned(64'($unsigned(mul_tree_37_40))) * $unsigned(64'($unsigned(mul_tree_37_41))))); // decl: <none>; prim: <none>
    assign mul_tree_37_43 = mul_precision_28[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_44 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_45 = 64'(($unsigned(64'($unsigned(mul_tree_37_43))) * $unsigned(64'($unsigned(mul_tree_37_44))))); // decl: <none>; prim: <none>
    assign mul_tree_37_46 = {mul_tree_37_45, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_47 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_48 = mul_precision_29[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_37_49 = 64'(($unsigned(64'($unsigned(mul_tree_37_47))) * $unsigned(64'($unsigned(mul_tree_37_48))))); // decl: <none>; prim: <none>
    assign mul_tree_37_50 = {mul_tree_37_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_51 = mul_precision_28[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_52 = mul_precision_29[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_37_53 = 64'(($unsigned(64'($unsigned(mul_tree_37_51))) * $unsigned(64'($unsigned(mul_tree_37_52))))); // decl: <none>; prim: <none>
    assign mul_tree_37_54 = {mul_tree_37_53, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_37_55 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_56 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_57 = 97'((mul_tree_37_55 + mul_tree_37_56 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_37_58 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_59 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    assign mul_tree_37_60 = 129'((mul_tree_37_58 + mul_tree_37_59 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_37_61 = ({33'h0, rtlzz_pipe_57_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_62 = ({1'h0, rtlzz_pipe_60_s2}); // decl: <none>; prim: <none>
    assign mul_tree_37_63 = 130'((mul_tree_37_61 + mul_tree_37_62 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_37_64 = mul_tree_37_63[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_65 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_66 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_67 = 64'(($unsigned(64'($unsigned(mul_tree_38_65))) * $unsigned(64'($unsigned(mul_tree_38_66))))); // decl: <none>; prim: <none>
    assign mul_tree_38_68 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_69 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_70 = 64'(($unsigned(64'($unsigned(mul_tree_38_68))) * $unsigned(64'($unsigned(mul_tree_38_69))))); // decl: <none>; prim: <none>
    assign mul_tree_38_71 = {mul_tree_38_70, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_72 = rtlzz_pipe_31_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_73 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    assign mul_tree_38_74 = 33'(($unsigned(33'($unsigned(mul_tree_38_72))) * $unsigned(33'($unsigned(mul_tree_38_73))))); // decl: <none>; prim: <none>
    assign mul_tree_38_75 = {mul_tree_38_74, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_76 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_77 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_78 = 64'(($unsigned(64'($unsigned(mul_tree_38_76))) * $unsigned(64'($unsigned(mul_tree_38_77))))); // decl: <none>; prim: <none>
    assign mul_tree_38_79 = {mul_tree_38_78, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_80 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_81 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_82 = 64'(($unsigned(64'($unsigned(mul_tree_38_80))) * $unsigned(64'($unsigned(mul_tree_38_81))))); // decl: <none>; prim: <none>
    assign mul_tree_38_83 = {mul_tree_38_82, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_84 = rtlzz_pipe_31_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_85 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    assign mul_tree_38_86 = 33'(($unsigned(33'($unsigned(mul_tree_38_84))) * $unsigned(33'($unsigned(mul_tree_38_85))))); // decl: <none>; prim: <none>
    assign mul_tree_38_87 = {mul_tree_38_86, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_88 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_89 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_90 = 64'(($unsigned(64'($unsigned(mul_tree_38_88))) * $unsigned(64'($unsigned(mul_tree_38_89))))); // decl: <none>; prim: <none>
    assign mul_tree_38_91 = {mul_tree_38_90, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_92 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_93 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_94 = 64'(($unsigned(64'($unsigned(mul_tree_38_92))) * $unsigned(64'($unsigned(mul_tree_38_93))))); // decl: <none>; prim: <none>
    assign mul_tree_38_95 = {mul_tree_38_94, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_96 = rtlzz_pipe_31_s5[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_38_97 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    assign mul_tree_38_98 = 33'(($unsigned(33'($unsigned(mul_tree_38_96))) * $unsigned(33'($unsigned(mul_tree_38_97))))); // decl: <none>; prim: <none>
    assign mul_tree_38_99 = {mul_tree_38_98, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_100 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_101 = rtlzz_pipe_32_s5[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_38_102 = 64'(($unsigned(64'($unsigned(mul_tree_38_100))) * $unsigned(64'($unsigned(mul_tree_38_101))))); // decl: <none>; prim: <none>
    assign mul_tree_38_103 = {mul_tree_38_102, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_104 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_105 = rtlzz_pipe_32_s5[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_38_106 = 64'(($unsigned(64'($unsigned(mul_tree_38_104))) * $unsigned(64'($unsigned(mul_tree_38_105))))); // decl: <none>; prim: <none>
    assign mul_tree_38_107 = {mul_tree_38_106, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_108 = rtlzz_pipe_31_s5[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_38_109 = rtlzz_pipe_32_s5[64]; // decl: <none>; prim: <none>
    assign mul_tree_38_110 = 33'(($unsigned(33'($unsigned(mul_tree_38_108))) * $unsigned(33'($unsigned(mul_tree_38_109))))); // decl: <none>; prim: <none>
    assign mul_tree_38_111 = {mul_tree_38_110, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_38_112 = ({33'h0, rtlzz_pipe_67_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_113 = ({1'h0, rtlzz_pipe_71_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_114 = 97'((mul_tree_38_112 + mul_tree_38_113 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_115 = ({1'h0, rtlzz_pipe_75_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_116 = ({2'h0, rtlzz_pipe_79_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_117 = 98'((mul_tree_38_115 + mul_tree_38_116 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_118 = ({2'h0, rtlzz_pipe_83_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_119 = ({1'h0, rtlzz_pipe_87_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_120 = 130'((mul_tree_38_118 + mul_tree_38_119 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_121 = ({33'h0, rtlzz_pipe_91_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_122 = ({1'h0, rtlzz_pipe_95_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_123 = 161'((mul_tree_38_121 + mul_tree_38_122 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_124 = ({1'h0, rtlzz_pipe_99_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_125 = ({2'h0, rtlzz_pipe_103_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_126 = 162'((mul_tree_38_124 + mul_tree_38_125 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_127 = ({2'h0, rtlzz_pipe_107_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_128 = ({1'h0, rtlzz_pipe_111_s6}); // decl: <none>; prim: <none>
    assign mul_tree_38_129 = 194'((mul_tree_38_127 + mul_tree_38_128 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_130 = ({2'h0, mul_tree_38_114}); // decl: <none>; prim: <none>
    assign mul_tree_38_131 = ({1'h0, mul_tree_38_117}); // decl: <none>; prim: <none>
    assign mul_tree_38_132 = 99'((mul_tree_38_130 + mul_tree_38_131 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_133 = ({32'h0, mul_tree_38_120}); // decl: <none>; prim: <none>
    assign mul_tree_38_134 = ({1'h0, mul_tree_38_123}); // decl: <none>; prim: <none>
    assign mul_tree_38_135 = 162'((mul_tree_38_133 + mul_tree_38_134 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_136 = ({33'h0, mul_tree_38_126}); // decl: <none>; prim: <none>
    assign mul_tree_38_137 = ({1'h0, mul_tree_38_129}); // decl: <none>; prim: <none>
    assign mul_tree_38_138 = 195'((mul_tree_38_136 + mul_tree_38_137 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_139 = ({64'h0, mul_tree_38_132}); // decl: <none>; prim: <none>
    assign mul_tree_38_140 = ({1'h0, mul_tree_38_135}); // decl: <none>; prim: <none>
    assign mul_tree_38_141 = 163'((mul_tree_38_139 + mul_tree_38_140 + ({162'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_142 = ({33'h0, mul_tree_38_141}); // decl: <none>; prim: <none>
    assign mul_tree_38_143 = ({1'h0, mul_tree_38_138}); // decl: <none>; prim: <none>
    assign mul_tree_38_144 = 196'((mul_tree_38_142 + mul_tree_38_143 + ({195'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_38_145 = mul_tree_38_144[192:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_146 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_147 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_148 = 64'(($unsigned(64'($unsigned(mul_tree_39_146))) * $unsigned(64'($unsigned(mul_tree_39_147))))); // decl: <none>; prim: <none>
    assign mul_tree_39_149 = rtlzz_pipe_34_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_150 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_151 = 64'(($unsigned(64'($unsigned(mul_tree_39_149))) * $unsigned(64'($unsigned(mul_tree_39_150))))); // decl: <none>; prim: <none>
    assign mul_tree_39_152 = {mul_tree_39_151, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_153 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_154 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_155 = 64'(($unsigned(64'($unsigned(mul_tree_39_153))) * $unsigned(64'($unsigned(mul_tree_39_154))))); // decl: <none>; prim: <none>
    assign mul_tree_39_156 = {mul_tree_39_155, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_157 = rtlzz_pipe_34_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_158 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_159 = 64'(($unsigned(64'($unsigned(mul_tree_39_157))) * $unsigned(64'($unsigned(mul_tree_39_158))))); // decl: <none>; prim: <none>
    assign mul_tree_39_160 = {mul_tree_39_159, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_161 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_162 = rtlzz_pipe_35_s7[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_39_163 = 33'(($unsigned(33'($unsigned(mul_tree_39_161))) * $unsigned(33'($unsigned(mul_tree_39_162))))); // decl: <none>; prim: <none>
    assign mul_tree_39_164 = {mul_tree_39_163, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_165 = rtlzz_pipe_34_s7[64]; // decl: <none>; prim: <none>
    assign mul_tree_39_166 = rtlzz_pipe_35_s7[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_39_167 = 33'(($unsigned(33'($unsigned(mul_tree_39_165))) * $unsigned(33'($unsigned(mul_tree_39_166))))); // decl: <none>; prim: <none>
    assign mul_tree_39_168 = {mul_tree_39_167, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_39_169 = ({33'h0, mul_tree_39_148}); // decl: <none>; prim: <none>
    assign mul_tree_39_170 = ({1'h0, mul_tree_39_152}); // decl: <none>; prim: <none>
    assign mul_tree_39_171 = 97'((mul_tree_39_169 + mul_tree_39_170 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_39_172 = ({33'h0, mul_tree_39_156}); // decl: <none>; prim: <none>
    assign mul_tree_39_173 = ({1'h0, mul_tree_39_160}); // decl: <none>; prim: <none>
    assign mul_tree_39_174 = 129'((mul_tree_39_172 + mul_tree_39_173 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_39_175 = ({33'h0, mul_tree_39_164}); // decl: <none>; prim: <none>
    assign mul_tree_39_176 = ({1'h0, mul_tree_39_168}); // decl: <none>; prim: <none>
    assign mul_tree_39_177 = 130'((mul_tree_39_175 + mul_tree_39_176 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_39_178 = ({33'h0, mul_tree_39_171}); // decl: <none>; prim: <none>
    assign mul_tree_39_179 = ({1'h0, mul_tree_39_174}); // decl: <none>; prim: <none>
    assign mul_tree_39_180 = 130'((mul_tree_39_178 + mul_tree_39_179 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_39_181 = ({1'h0, mul_tree_39_180}); // decl: <none>; prim: <none>
    assign mul_tree_39_182 = ({1'h0, mul_tree_39_177}); // decl: <none>; prim: <none>
    assign mul_tree_39_183 = 131'((mul_tree_39_181 + mul_tree_39_182 + ({130'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_39_184 = mul_tree_39_183[128:0]; // decl: <none>; prim: <none>
    assign limb_16_185 = tmp_workload_top_int_129__16_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_186 = n3_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_16_187 = (~limb_16_186); // decl: <none>; prim: <none>
    assign limb_16_188 = 65'((({1'h0, rtlzz_pipe_185_s7}) + ({1'h0, limb_16_187}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_16_189 = limb_16_188[63:0]; // decl: <none>; prim: <none>
    assign limb_16_190 = limb_16_188[64]; // decl: <none>; prim: <none>
    assign limb_16_191 = tmp_workload_top_int_129__16_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_16_192 = n3_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_16_193 = (~limb_16_192); // decl: <none>; prim: <none>
    assign limb_16_194 = 65'((({1'h0, rtlzz_pipe_191_s7}) + ({1'h0, limb_16_193}) + ({64'h0, limb_16_190}))); // decl: <none>; prim: <none>
    assign limb_16_195 = limb_16_194[63:0]; // decl: <none>; prim: <none>
    assign limb_16_196 = limb_16_194[64]; // decl: <none>; prim: <none>
    assign limb_16_197 = tmp_workload_top_int_129__16_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_198 = n3_v0[128]; // decl: <none>; prim: <none>
    assign limb_16_199 = (~limb_16_198); // decl: <none>; prim: <none>
    assign limb_16_200 = 2'((({1'h0, rtlzz_pipe_197_s7}) + ({1'h0, limb_16_199}) + ({1'h0, limb_16_196}))); // decl: <none>; prim: <none>
    assign limb_16_201 = limb_16_200[0]; // decl: <none>; prim: <none>
    assign limb_16_202 = {limb_16_201, limb_16_195, limb_16_189}; // decl: <none>; prim: <none>
    assign limb_18_203 = s8_norm_sub_14_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_18_204 = tmp_workload_top_int_129__13_v0[63:0]; // decl: <none>; prim: <none>
    assign limb_18_205 = (~limb_18_204); // decl: <none>; prim: <none>
    assign limb_18_206 = 65'((({1'h0, limb_18_203}) + ({1'h0, rtlzz_pipe_205_s7}) + ({64'h0, 1'h1}))); // decl: <none>; prim: <none>
    assign limb_18_207 = limb_18_206[63:0]; // decl: <none>; prim: <none>
    assign limb_18_208 = limb_18_206[64]; // decl: <none>; prim: <none>
    assign limb_18_209 = s8_norm_sub_14_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_18_210 = tmp_workload_top_int_129__13_v0[127:64]; // decl: <none>; prim: <none>
    assign limb_18_211 = (~rtlzz_pipe_210_s2); // decl: <none>; prim: <none>
    assign limb_18_212 = 65'((({1'h0, limb_18_209}) + ({1'h0, rtlzz_pipe_211_s7}) + ({64'h0, limb_18_208}))); // decl: <none>; prim: <none>
    assign limb_18_213 = limb_18_212[63:0]; // decl: <none>; prim: <none>
    assign limb_18_214 = limb_18_212[64]; // decl: <none>; prim: <none>
    assign limb_18_215 = s8_norm_sub_14_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_216 = tmp_workload_top_int_129__13_v0[128]; // decl: <none>; prim: <none>
    assign limb_18_217 = (~rtlzz_pipe_216_s4); // decl: <none>; prim: <none>
    assign limb_18_218 = 2'((({1'h0, limb_18_215}) + ({1'h0, rtlzz_pipe_217_s7}) + ({1'h0, limb_18_214}))); // decl: <none>; prim: <none>
    assign limb_18_219 = limb_18_218[0]; // decl: <none>; prim: <none>
    assign limb_18_220 = {limb_18_219, limb_18_213, limb_18_207}; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_12_s1 <= 129'h0;
            rtlzz_pipe_12_s2 <= 129'h0;
            rtlzz_pipe_12_s3 <= 129'h0;
            rtlzz_pipe_12_s4 <= 129'h0;
            rtlzz_pipe_12_s5 <= 129'h0;
            rtlzz_pipe_12_s6 <= 129'h0;
            rtlzz_pipe_12_s7 <= 129'h0;
            rtlzz_pipe_32_s1 <= 65'h0;
            rtlzz_pipe_32_s2 <= 65'h0;
            rtlzz_pipe_32_s3 <= 65'h0;
            rtlzz_pipe_32_s4 <= 65'h0;
            rtlzz_pipe_32_s5 <= 65'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_35_s2 <= 64'h0;
            rtlzz_pipe_35_s3 <= 64'h0;
            rtlzz_pipe_35_s4 <= 64'h0;
            rtlzz_pipe_35_s5 <= 64'h0;
            rtlzz_pipe_35_s6 <= 64'h0;
            rtlzz_pipe_35_s7 <= 64'h0;
            rtlzz_pipe_42_s1 <= 64'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 96'h0;
            rtlzz_pipe_54_s1 <= 128'h0;
            rtlzz_pipe_57_s2 <= 97'h0;
            rtlzz_pipe_60_s2 <= 129'h0;
            rtlzz_pipe_23_s3 <= 193'h0;
            rtlzz_pipe_25_s3 <= 129'h0;
            rtlzz_pipe_25_s4 <= 129'h0;
            rtlzz_pipe_31_s4 <= 128'h0;
            rtlzz_pipe_31_s5 <= 128'h0;
            rtlzz_pipe_67_s6 <= 64'h0;
            rtlzz_pipe_71_s6 <= 96'h0;
            rtlzz_pipe_75_s6 <= 97'h0;
            rtlzz_pipe_79_s6 <= 96'h0;
            rtlzz_pipe_83_s6 <= 128'h0;
            rtlzz_pipe_87_s6 <= 129'h0;
            rtlzz_pipe_91_s6 <= 128'h0;
            rtlzz_pipe_95_s6 <= 160'h0;
            rtlzz_pipe_99_s6 <= 161'h0;
            rtlzz_pipe_103_s6 <= 160'h0;
            rtlzz_pipe_107_s6 <= 192'h0;
            rtlzz_pipe_111_s6 <= 193'h0;
            rtlzz_pipe_34_s7 <= 65'h0;
            rtlzz_pipe_185_s5 <= 64'h0;
            rtlzz_pipe_185_s6 <= 64'h0;
            rtlzz_pipe_185_s7 <= 64'h0;
            rtlzz_pipe_191_s5 <= 64'h0;
            rtlzz_pipe_191_s6 <= 64'h0;
            rtlzz_pipe_191_s7 <= 64'h0;
            rtlzz_pipe_197_s5 <= 1'h0;
            rtlzz_pipe_197_s6 <= 1'h0;
            rtlzz_pipe_197_s7 <= 1'h0;
            rtlzz_pipe_205_s1 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s2 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s3 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s4 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s5 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_205_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_210_s1 <= 64'h0;
            rtlzz_pipe_210_s2 <= 64'h0;
            rtlzz_pipe_211_s3 <= 64'hffffffffffffffff;
            rtlzz_pipe_211_s4 <= 64'hffffffffffffffff;
            rtlzz_pipe_211_s5 <= 64'hffffffffffffffff;
            rtlzz_pipe_211_s6 <= 64'hffffffffffffffff;
            rtlzz_pipe_211_s7 <= 64'hffffffffffffffff;
            rtlzz_pipe_216_s1 <= 1'h0;
            rtlzz_pipe_216_s2 <= 1'h0;
            rtlzz_pipe_216_s3 <= 1'h0;
            rtlzz_pipe_216_s4 <= 1'h0;
            rtlzz_pipe_217_s5 <= 1'h1;
            rtlzz_pipe_217_s6 <= 1'h1;
            rtlzz_pipe_217_s7 <= 1'h1;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
            rtlzz_valid_s3 <= 1'h0;
            rtlzz_valid_s4 <= 1'h0;
            rtlzz_valid_s5 <= 1'h0;
            rtlzz_valid_s6 <= 1'h0;
            rtlzz_valid_s7 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_12_s1 <= tmp_workload_top_int_129__13_v0; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_12_s2 <= rtlzz_pipe_12_s1; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_12_s3 <= rtlzz_pipe_12_s2; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_12_s4 <= rtlzz_pipe_12_s3; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_12_s5 <= rtlzz_pipe_12_s4; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_12_s6 <= rtlzz_pipe_12_s5; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_12_s7 <= rtlzz_pipe_12_s6; // decl: /home/zyrv/vulsim/workload.cpp:20:34-20:51; prim: /home/zyrv/vulsim/workload.cpp:20:34-20:51
        end
        if (iv) begin
        rtlzz_pipe_32_s1 <= mul_precision_32; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_32_s2 <= rtlzz_pipe_32_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_32_s3 <= rtlzz_pipe_32_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_32_s4 <= rtlzz_pipe_32_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_32_s5 <= rtlzz_pipe_32_s4; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_precision_35; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_35_s2 <= rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_35_s3 <= rtlzz_pipe_35_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_35_s4 <= rtlzz_pipe_35_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_35_s5 <= rtlzz_pipe_35_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_35_s6 <= rtlzz_pipe_35_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_35_s7 <= rtlzz_pipe_35_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_37_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_37_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_37_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_37_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_57_s2 <= mul_tree_37_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_60_s2 <= mul_tree_37_60; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_23_s3 <= __beopt_width_54; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_25_s3 <= __beopt_width_57; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_25_s4 <= rtlzz_pipe_25_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_31_s4 <= mul_precision_31; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_31_s5 <= rtlzz_pipe_31_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_67_s6 <= mul_tree_38_67; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_71_s6 <= mul_tree_38_71; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_75_s6 <= mul_tree_38_75; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_79_s6 <= mul_tree_38_79; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_83_s6 <= mul_tree_38_83; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_87_s6 <= mul_tree_38_87; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_91_s6 <= mul_tree_38_91; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_95_s6 <= mul_tree_38_95; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_99_s6 <= mul_tree_38_99; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_103_s6 <= mul_tree_38_103; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_107_s6 <= mul_tree_38_107; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_111_s6 <= mul_tree_38_111; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_34_s7 <= mul_precision_34; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_185_s5 <= limb_16_185; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_185_s6 <= rtlzz_pipe_185_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_185_s7 <= rtlzz_pipe_185_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_191_s5 <= limb_16_191; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_191_s6 <= rtlzz_pipe_191_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_191_s7 <= rtlzz_pipe_191_s6; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_197_s5 <= limb_16_197; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_197_s6 <= rtlzz_pipe_197_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_197_s7 <= rtlzz_pipe_197_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_205_s1 <= limb_18_205; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_205_s2 <= rtlzz_pipe_205_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_205_s3 <= rtlzz_pipe_205_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_205_s4 <= rtlzz_pipe_205_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_205_s5 <= rtlzz_pipe_205_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_205_s6 <= rtlzz_pipe_205_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_205_s7 <= rtlzz_pipe_205_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_210_s1 <= limb_18_210; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_210_s2 <= rtlzz_pipe_210_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_211_s3 <= limb_18_211; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_211_s4 <= rtlzz_pipe_211_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_211_s5 <= rtlzz_pipe_211_s4; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_211_s6 <= rtlzz_pipe_211_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_211_s7 <= rtlzz_pipe_211_s6; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_216_s1 <= limb_18_216; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_216_s2 <= rtlzz_pipe_216_s1; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s2) begin
        rtlzz_pipe_216_s3 <= rtlzz_pipe_216_s2; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s3) begin
        rtlzz_pipe_216_s4 <= rtlzz_pipe_216_s3; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s4) begin
        rtlzz_pipe_217_s5 <= limb_18_217; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s5) begin
        rtlzz_pipe_217_s6 <= rtlzz_pipe_217_s5; // decl: <none>; prim: <none>
        end
        if (rtlzz_valid_s6) begin
        rtlzz_pipe_217_s7 <= rtlzz_pipe_217_s6; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s3 <= rtlzz_valid_s2; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s4 <= rtlzz_valid_s3; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s5 <= rtlzz_valid_s4; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s6 <= rtlzz_valid_s5; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        rtlzz_valid_s7 <= rtlzz_valid_s6; // decl: /home/zyrv/vulsim/workload.cpp:11:1-11:8; prim: /home/zyrv/vulsim/workload.cpp:11:1-11:8
        end
    end
endmodule

module Workload(input wire clk,input wire rstn,input wire iv_data,input wire iv_wen,output reg ov,input wire [63:0] a_data,input wire a_wen,input wire [63:0] b_data,input wire b_wen,input wire [63:0] modulus_data,input wire modulus_wen,input wire [64:0] mu_data,input wire mu_wen,output reg [63:0] y);
reg liv;wire cov;
reg [63:0] l_a;
reg [63:0] l_b;
reg [63:0] l_modulus;
reg [64:0] l_mu;
wire [63:0] c_y;
WorkloadCore core(.iv(liv),.ov(cov),.clk(clk),.rstn(rstn),.a(l_a),.b(l_b),.modulus(l_modulus),.mu(l_mu),.y(c_y));
always @(posedge clk)if(!rstn)begin liv<=1'b0;ov<=1'b0;l_a<=64'h0;l_b<=64'h0;l_modulus<=64'h0;l_mu<=65'h00000000000000000;y<=64'h0;end else begin if(iv_wen)liv<=iv_data;ov<=cov;if(a_wen)l_a<=a_data;if(b_wen)l_b<=b_data;if(modulus_wen)l_modulus<=modulus_data;if(mu_wen)l_mu<=mu_data;y<=c_y;end
endmodule
