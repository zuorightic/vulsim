`timescale 1ns/1ps

module shared_divrem_64_C(
    input logic iv, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10
    input logic [63:0] d, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10
    output logic [63:0] q, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:47-16:64
    output logic [63:0] r, // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:65-16:87
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:9:15-9:27; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10
    logic [63:0] s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:10:17-10:33; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
    logic [63:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24
    logic [63:0] s8_norm_mul_8_v0; // decl: <none>; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:31-8:39
    logic [63:0] s8_norm_sub_10_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:14:18-14:38; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:14:18-14:38
    logic [63:0] s8_norm_mux_13_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:15:14-15:35; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
    logic [63:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26
    logic [127:0] s8_norm_hw_15_v0; // decl: <none>; prim: <none>
    logic [63:0] tmp_shared_divrem_64_c_int_64__2_v0; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:49-16:64; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:49-16:64
    logic [63:0] s8_norm_shift_1_v0; // decl: <none>; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26
    logic [63:0] arith_original_16; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24
    logic [63:0] arith_original_17; // decl: <none>; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:31-8:39
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:9:15-9:27; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:10:17-10:33; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
    logic [63:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 64'h0); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:9:15-9:27; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10
    assign s8_norm_mux_6_v0 = (s8_norm_cmp_4_v0 ? 64'h1 : d); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:10:17-10:33; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
    assign s8_norm_udivmod_7_v0 = arith_original_16; // decl: <none>; prim: <none>
    assign s8_norm_mul_8_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_sub_10_v0 = (rtlzz_pipe_1_s1 - s8_norm_mul_8_v0); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:14:18-14:38; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:14:18-14:38
    assign s8_norm_mux_13_v0 = (rtlzz_pipe_3_s1 ? 64'hffffffffffffffff : rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:15:14-15:35; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
    assign s8_norm_mux_14_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : s8_norm_sub_10_v0); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26
    assign s8_norm_hw_15_v0 = {s8_norm_mux_14_v0, s8_norm_mux_13_v0}; // decl: <none>; prim: <none>
    assign tmp_shared_divrem_64_c_int_64__2_v0 = s8_norm_hw_15_v0[63:0]; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:49-16:64; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:49-16:64
    assign s8_norm_shift_1_v0 = s8_norm_hw_15_v0[127:64]; // decl: <none>; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:16:14-16:26
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = tmp_shared_divrem_64_c_int_64__2_v0; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:47-16:64
    assign r = s8_norm_shift_1_v0; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:16:65-16:87
    assign arith_original_16 = (a / s8_norm_mux_6_v0); // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24
    assign arith_original_17 = 64'(($unsigned(64'($unsigned(rtlzz_pipe_5_s1))) * $unsigned(64'($unsigned(rtlzz_pipe_4_s1))))); // decl: <none>; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:31-8:39
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 64'h8000000000000035;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 64'h1;
            rtlzz_pipe_5_s1 <= 64'h8000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:9:15-9:27; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:9:1-9:10
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:10:17-10:33; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:8:40-8:48
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24; prim: /home/zyrv/vulsim/vullib/unsigned_divrem.hpp:11:18-11:24
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/shared_divrem_64_C.logic.cpp:4:1-4:8
        end
    end
endmodule
