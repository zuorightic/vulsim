`timescale 1ns/1ps

module MIX_128_C(
    input logic iv, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:9:1-9:11
    input logic [127:0] mask, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:11:1-11:14; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:11:1-11:14
    input logic [127:0] d, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:13:1-13:11
    input logic [8:0] s, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:15:1-15:9
    output logic [127:0] y, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:46:5-46:17
    output logic less, // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:47:5-47:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_7_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:22-22:36
    logic [127:0] s8_norm_bitnot_8_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:29:31-29:36; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:29:31-29:36
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25
    logic s8_norm_cmp_10_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:25:27-25:41
    logic [127:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:46; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:46
    logic [127:0] s8_norm_sub_12_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:46; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:46
    logic [127:0] s8_norm_mux_13_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:34:30-34:59; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:25:5-25:42
    logic [127:0] s8_norm_udivmod_15_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45
    logic [127:0] s8_norm_shift_17_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:37:25-37:55; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:32
    logic [127:0] s8_norm_shift_19_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:38:25-38:55; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:32
    logic [127:0] s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:39:24-39:53; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:5-22:37
    logic [127:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:40:25-40:56; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:40:25-40:56
    logic [127:0] s8_norm_mux_22_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:41:25-41:54; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:5-22:37
    logic [127:0] s8_norm_bitop_23_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:42:28-42:41; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:42:28-42:41
    logic [127:0] s8_norm_bitop_24_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:43:28-43:52; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:43:28-43:52
    logic [127:0] s8_norm_bitop_25_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:44:26-44:49; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:44:26-44:49
    logic [127:0] s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44
    logic [127:0] arith_original_26; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45
    logic rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25
    logic [127:0] rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_7_v0 = (s < 9'h80); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:22-22:36
    assign s8_norm_bitnot_8_v0 = (~mask); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:29:31-29:36; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:29:31-29:36
    assign s8_norm_cmp_9_v0 = (a < b); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25
    assign s8_norm_cmp_10_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:25:27-25:41
    assign s8_norm_add_11_v0 = (a + b); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:46; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:46
    assign s8_norm_sub_12_v0 = (a - b); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:46; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:46
    assign s8_norm_mux_13_v0 = (s8_norm_cmp_10_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:34:30-34:59; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:25:5-25:42
    assign s8_norm_udivmod_15_v0 = arith_original_26; // decl: <none>; prim: <none>
    assign s8_norm_shift_17_v0 = (s >= 9'd128 ? 128'h0 : (s8_norm_add_11_v0 << s)); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:37:25-37:55; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:32:21-32:32
    assign s8_norm_shift_19_v0 = (s >= 9'd128 ? 128'h0 : (s8_norm_sub_12_v0 >> s)); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:38:25-38:55; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:33:21-33:32
    assign s8_norm_mux_20_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_17_v0 : 128'h0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:39:24-39:53; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:5-22:37
    assign s8_norm_mux_21_v0 = (s8_norm_cmp_10_v0 ? a : s8_norm_udivmod_15_v0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:40:25-40:56; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:40:25-40:56
    assign s8_norm_mux_22_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_19_v0 : 128'h0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:41:25-41:54; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:22:5-22:37
    assign s8_norm_bitop_23_v0 = (s8_norm_mux_20_v0 & mask); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:42:28-42:41; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:42:28-42:41
    assign s8_norm_bitop_24_v0 = (s8_norm_mux_22_v0 & s8_norm_bitnot_8_v0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:43:28-43:52; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:43:28-43:52
    assign s8_norm_bitop_25_v0 = (s8_norm_bitop_23_v0 | s8_norm_bitop_24_v0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:44:26-44:49; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:44:26-44:49
    assign s8_norm_bitop_26_v0 = (s8_norm_bitop_25_v0 ^ s8_norm_mux_21_v0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:46:5-46:17
    assign less = rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:47:5-47:18
    assign arith_original_26 = (a % s8_norm_mux_13_v0); // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:36:29-36:45
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_8_s1 <= 1'h0;
            rtlzz_pipe_22_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_8_s1 <= s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:30:20-30:25
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:45:26-45:44
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_128_C.logic.cpp:4:1-4:8
        end
    end
endmodule
