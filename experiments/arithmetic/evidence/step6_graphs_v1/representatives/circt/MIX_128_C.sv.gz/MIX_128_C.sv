module MIX_128_C(	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:1
  input          iv,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:25
  input  [127:0] a,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:38
                 b,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:52
                 mask,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:66
                 d,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:83
  input  [8:0]   s,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:97
  input          rstn,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:109
                 clk,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:124
  output         ov,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:139
  output [127:0] y,	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:152
  output         less	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:1:166
);

  wire         _GEN = ~rstn;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9
  reg          rtlzz_pipe_8_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:7:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:7:22
    if (_GEN)	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :7:22
      rtlzz_pipe_8_s1 <= 1'h0;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:7:22
    else	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :7:22
      rtlzz_pipe_8_s1 <= iv ? a < b : rtlzz_pipe_8_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:5:9, :7:22
  end // always_ff @(posedge)
  reg  [127:0] rtlzz_pipe_22_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:43:23
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:43:23
    if (_GEN)	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :43:23
      rtlzz_pipe_22_s1 <= 128'h80000000000000020000000000000035;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:42:10, :43:23
    else begin	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :43:23
      automatic logic [127:0] _GEN_0 = {119'h0, s};	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:11:9
      automatic logic         _GEN_1 = |(s[8:7]);	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:14:10
      automatic logic         _GEN_2 = d == 128'h0;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:37:10
      rtlzz_pipe_22_s1 <=
        iv
          ? ((_GEN_1 ? 128'h0 : a + b << _GEN_0) & mask
             | (_GEN_1 ? 128'h0 : a - b >> _GEN_0) & ~mask)
            ^ (_GEN_2 ? a : a % (_GEN_2 ? 128'h1 : d))
          : rtlzz_pipe_22_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:9:9, :11:9, :12:9, :14:10, :19:10, :20:10, :22:10, :25:10, :30:10, :32:10, :33:10, :34:10, :35:10, :37:10, :38:10, :39:10, :40:10, :41:10, :43:23
    end
  end // always_ff @(posedge)
  reg          rtlzz_valid_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:45:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:45:21
    if (_GEN)	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :45:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:45:21
    else	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:4:9, :45:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:45:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:45:21, :46:3
  assign y = rtlzz_pipe_22_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:43:23, :46:3
  assign less = rtlzz_pipe_8_s1;	// /tmp/rtlzz-circt-8-2022779478059484/input.mlir:7:22, :46:3
endmodule
