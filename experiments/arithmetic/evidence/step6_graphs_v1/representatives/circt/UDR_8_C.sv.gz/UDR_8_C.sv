module UDR_8_C(	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:1
  input        iv,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:23
  input  [7:0] a,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:36
               d,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:48
  input        rstn,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:60
               clk,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:75
  output       ov,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:90
  output [7:0] q,	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:103
               r	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:1:115
);

  wire       _GEN = ~rstn;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9
  reg  [7:0] rtlzz_pipe_1_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:6:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:6:22
    if (_GEN)	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :6:22
      rtlzz_pipe_1_s1 <= 8'hB5;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:5:9, :6:22
    else	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :6:22
      rtlzz_pipe_1_s1 <= iv ? a : rtlzz_pipe_1_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:6:22
  end // always_ff @(posedge)
  wire       _GEN_0 = d == 8'h0;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:7:9, :8:9
  reg        rtlzz_pipe_3_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:10:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:10:22
    if (_GEN)	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :10:22
      rtlzz_pipe_3_s1 <= 1'h1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:10:22
    else	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :10:22
      rtlzz_pipe_3_s1 <= iv ? _GEN_0 : rtlzz_pipe_3_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:8:9, :10:22
  end // always_ff @(posedge)
  reg  [7:0] rtlzz_pipe_4_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:14:22
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:14:22
    if (_GEN)	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :14:22
      rtlzz_pipe_4_s1 <= 8'h1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:14:22
    else	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :14:22
      rtlzz_pipe_4_s1 <= iv ? (_GEN_0 ? 8'h1 : d) : rtlzz_pipe_4_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:8:9, :12:9, :14:22
  end // always_ff @(posedge)
  reg        rtlzz_valid_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:16:21
  always_ff @(posedge clk) begin	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:16:21
    if (_GEN)	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :16:21
      rtlzz_valid_s1 <= 1'h0;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:15:10, :16:21
    else	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:4:9, :16:21
      rtlzz_valid_s1 <= iv;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:16:21
  end // always_ff @(posedge)
  assign ov = rtlzz_valid_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:16:21, :22:3
  assign q = rtlzz_pipe_3_s1 ? 8'hFF : rtlzz_pipe_1_s1 / rtlzz_pipe_4_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:6:22, :10:22, :14:22, :17:10, :18:10, :19:10, :22:3
  assign r = rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : rtlzz_pipe_1_s1 % rtlzz_pipe_4_s1;	// /tmp/rtlzz-circt-8-2022778746753719/input.mlir:6:22, :10:22, :14:22, :20:10, :21:10, :22:3
endmodule
