`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [15:0] result__query__,
  input push__vld__,
  input [31:0] push_value__,
  input [0:0] push_v__
);

reg [7:0] __vul_pipeline_q_a;
wire [7:0] resetvalue_a__;
wire wen_a__;
wire [7:0] wdata_a__;
reg [7:0] __vul_pipeline_q_b;
wire [7:0] resetvalue_b__;
wire wen_b__;
wire [7:0] wdata_b__;
reg [15:0] __vul_pipeline_q_c;
wire [15:0] resetvalue_c__;
wire wen_c__;
wire [15:0] wdata_c__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [15:0] __vul_pipeline_q_y;
wire [15:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 16'h2e;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [7:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic [7:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    logic [15:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19
    logic [15:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:47:1-47:50
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [7:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic [7:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    logic [15:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19
    logic [15:0] s8_norm_mul_5_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:31:26-31:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:37:17-37:48
    logic [15:0] s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:32:22-32:53; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:32:22-32:53
    logic [15:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:47:1-47:50
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19
    logic [7:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic [7:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    logic [15:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [15:0] arith_original_12; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:31:26-31:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:37:17-37:48
    logic [3:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_2_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21
    logic [12:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:47:1-47:50
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19

    assign s8_norm_mul_5_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_6_v0 = (s8_norm_mul_5_v0 + rtlzz_pipe_2_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:32:22-32:53; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:32:22-32:53
    assign vul_port_y = s8_norm_add_6_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:47:1-47:50
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign __beopt_width_10 = vul_port_a; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    assign __beopt_width_11 = vul_port_b; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    assign __beopt_width_12 = ({8'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({8'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_37; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 8'(($unsigned(8'($unsigned(mul_tree_12_13))) * $unsigned(8'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 8'(($unsigned(8'($unsigned(mul_tree_12_16))) * $unsigned(8'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 8'(($unsigned(8'($unsigned(mul_tree_12_20))) * $unsigned(8'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 8'(($unsigned(8'($unsigned(mul_tree_12_24))) * $unsigned(8'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = ({5'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_29 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 13'((mul_tree_12_28 + mul_tree_12_29 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = ({5'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_32 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    assign mul_tree_12_33 = 17'((mul_tree_12_31 + mul_tree_12_32 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_34 = ({5'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_36 = 18'((mul_tree_12_34 + mul_tree_12_35 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_tree_12_36[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_2_s1 <= 16'h8035;
            rtlzz_pipe_30_s1 <= 13'h389;
            rtlzz_pipe_33_s1 <= 17'h7c70;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_2_s1 <= vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:21
        end
        if (vul_port_iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_12_30; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_12_33; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:19
        end
    end
end

    logic [15:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:34:1-34:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:34:1-34:17
    logic [31:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:36:1-36:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:36:1-36:21
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:38:1-38:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:38:1-38:16
    logic [15:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18
    logic [7:0] s8_norm_hw_33_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:176:20-176:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:176:20-176:32
    logic [7:0] s8_norm_hw_34_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:177:20-177:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:177:20-177:32
    logic [15:0] s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:178:21-178:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:178:21-178:33
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:84:3-84:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:166:3-166:26
    logic [15:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:172:3-172:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13
    logic [7:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17
    logic [7:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:128:3-128:35
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13
    logic [7:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17
    logic [7:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:135:3-135:35
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13
    logic [15:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18
    logic [15:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:142:3-142:37
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:62:1-62:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:148:3-148:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:166:3-166:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:172:3-172:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:34:1-34:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:34:1-34:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:36:1-36:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:36:1-36:21
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:38:1-38:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:38:1-38:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:128:3-128:35
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:135:3-135:35
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:142:3-142:37
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:62:1-62:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:148:3-148:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:64:1-64:18
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:66:1-66:18

    assign s8_norm_hw_33_v0 = push_value[7:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:176:20-176:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:176:20-176:32
    assign s8_norm_hw_34_v0 = push_value[15:8]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:177:20-177:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:177:20-177:32
    assign s8_norm_hw_35_v0 = push_value[31:16]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:178:21-178:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:178:21-178:33
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:84:3-84:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:166:3-166:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:172:3-172:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:40:1-40:13
    assign wdata_a = s8_norm_hw_33_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:42:1-42:17
    assign resetvalue_a = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:128:3-128:35
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:46:1-46:13
    assign wdata_b = s8_norm_hw_34_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:48:1-48:17
    assign resetvalue_b = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:135:3-135:35
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:52:1-52:13
    assign wdata_c = s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:54:1-54:18
    assign resetvalue_c = 16'h8035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:142:3-142:37
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:58:1-58:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:60:1-60:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:62:1-62:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MAC_8/sim/top.logic.cpp:148:3-148:37
endmodule

