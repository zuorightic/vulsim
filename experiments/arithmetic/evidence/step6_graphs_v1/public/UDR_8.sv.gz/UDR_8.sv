`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [15:0] result__query__,
  input push__vld__,
  input [15:0] push_value__,
  input [0:0] push_v__
);

reg [7:0] __vul_pipeline_q_a;
wire [7:0] resetvalue_a__;
wire wen_a__;
wire [7:0] wdata_a__;
reg [7:0] __vul_pipeline_q_d;
wire [7:0] resetvalue_d__;
wire wen_d__;
wire [7:0] wdata_d__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [7:0] __vul_pipeline_q_q;
wire [7:0] __vul_pipeline_d_q;
reg [7:0] __vul_pipeline_q_r;
wire [7:0] __vul_pipeline_d_r;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_q <= 8'hff;
  end else begin
  __vul_pipeline_q_q <= __vul_pipeline_d_q;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_r <= 8'hb5;
  end else begin
  __vul_pipeline_q_r <= __vul_pipeline_d_r;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [7:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic [7:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19
    logic [7:0] __vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:48
    logic [7:0] __vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:56:1-56:48
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [7:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic [7:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19
    logic s8_norm_cmp_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:34:29-34:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
    logic [7:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:35:30-35:63; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
    logic [7:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47
    logic [7:0] s8_norm_udivmod_13_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47
    logic [7:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:38:25-38:71; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
    logic [7:0] s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:39:25-39:60; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:39:25-39:60
    logic [7:0] vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:48
    logic [7:0] vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:56:1-56:48
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19
    logic [7:0] arith_original_12; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47
    logic [7:0] arith_original_13; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47
    logic [7:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:34:29-34:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
    logic [7:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:35:30-35:63; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_q = __vul_port_q;
    assign __vul_pipeline_d_r = __vul_port_r;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:20
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19
    assign __vul_port_q = vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:48
    assign __vul_port_r = vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:56:1-56:48
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:19

    assign s8_norm_cmp_10_v0 = (vul_port_d == 8'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:34:29-34:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
    assign s8_norm_mux_11_v0 = (s8_norm_cmp_10_v0 ? 8'h1 : vul_port_d); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:35:30-35:63; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
    assign s8_norm_udivmod_12_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_13_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_14_v0 = (rtlzz_pipe_3_s1 ? 8'hff : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:38:25-38:71; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
    assign s8_norm_mux_15_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_0_s1 : s8_norm_udivmod_13_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:39:25-39:60; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:39:25-39:60
    assign vul_port_q = s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:48
    assign vul_port_r = s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:56:1-56:48
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign arith_original_12 = (rtlzz_pipe_0_s1 / rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:36:29-36:47
    assign arith_original_13 = (rtlzz_pipe_0_s1 % rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:37:29-37:47
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_0_s1 <= 8'hb5;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 8'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_0_s1 <= vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:19:1-19:20
        end
        if (vul_port_iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:34:29-34:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
        end
        if (vul_port_iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:35:30-35:63; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:46:1-46:24
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:19
        end
    end
end

    logic [7:0] rdata_q__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17
    logic [7:0] rdata_r__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:34:1-34:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:34:1-34:17
    logic [15:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:36:1-36:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:36:1-36:21
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:38:1-38:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:38:1-38:16
    logic [7:0] rdata_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17
    logic [7:0] rdata_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18
    logic [15:0] s8_norm_hw_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:158:3-158:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:158:3-158:9
    logic [7:0] s8_norm_hw_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:163:20-163:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:163:20-163:32
    logic [7:0] s8_norm_hw_29_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:164:20-164:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:164:20-164:32
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:87:3-87:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:152:3-152:26
    logic [15:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:159:3-159:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13
    logic [7:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17
    logic [7:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:121:3-121:35
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13
    logic [7:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17
    logic [7:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:128:3-128:35
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:134:3-134:37

    assign rdata_q__ = __vul_pipeline_q_q;
    assign rdata_r__ = __vul_pipeline_q_r;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:152:3-152:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:159:3-159:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:34:1-34:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:34:1-34:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:36:1-36:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:36:1-36:21
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:38:1-38:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:38:1-38:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:121:3-121:35
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:128:3-128:35
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:134:3-134:37
    assign rdata_q = rdata_q__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:58:1-58:17
    assign rdata_r = rdata_r__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:60:1-60:17
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:62:1-62:18

    assign s8_norm_hw_27_v0 = {rdata_r, rdata_q}; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:158:3-158:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:158:3-158:9
    assign s8_norm_hw_28_v0 = push_value[7:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:163:20-163:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:163:20-163:32
    assign s8_norm_hw_29_v0 = push_value[15:8]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:164:20-164:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:164:20-164:32
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:87:3-87:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:152:3-152:26
    assign result__query = s8_norm_hw_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:32:1-32:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:159:3-159:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:40:1-40:13
    assign wdata_a = s8_norm_hw_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:42:1-42:17
    assign resetvalue_a = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:44:1-44:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:121:3-121:35
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:46:1-46:13
    assign wdata_d = s8_norm_hw_29_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:48:1-48:17
    assign resetvalue_d = 8'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:50:1-50:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:128:3-128:35
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:52:1-52:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:54:1-54:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:56:1-56:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/UDR_8/sim/top.logic.cpp:134:3-134:37
endmodule

