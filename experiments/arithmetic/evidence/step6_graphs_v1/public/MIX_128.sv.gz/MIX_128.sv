`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [128:0] result__query__,
  input push__vld__,
  input [520:0] push_value__,
  input [0:0] push_v__
);

reg [127:0] __vul_pipeline_q_a;
wire [127:0] resetvalue_a__;
wire wen_a__;
wire [127:0] wdata_a__;
reg [127:0] __vul_pipeline_q_b;
wire [127:0] resetvalue_b__;
wire wen_b__;
wire [127:0] wdata_b__;
reg [127:0] __vul_pipeline_q_mask;
wire [127:0] resetvalue_mask__;
wire wen_mask__;
wire [127:0] wdata_mask__;
reg [127:0] __vul_pipeline_q_d;
wire [127:0] resetvalue_d__;
wire wen_d__;
wire [127:0] wdata_d__;
reg [8:0] __vul_pipeline_q_s;
wire [8:0] resetvalue_s__;
wire wen_s__;
wire [8:0] wdata_s__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [127:0] __vul_pipeline_q_y;
wire [127:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_less;
wire [0:0] __vul_pipeline_d_less;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_mask <= resetvalue_mask__;
  end else begin
begin
    if (wen_mask__) begin
      __vul_pipeline_q_mask <= wdata_mask__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_s <= resetvalue_s__;
  end else begin
begin
    if (wen_s__) begin
      __vul_pipeline_q_s <= wdata_s__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 128'h80000000000000020000000000000035;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_less <= 1'h0;
  end else begin
  __vul_pipeline_q_less <= __vul_pipeline_d_less;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [127:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] __vul_port_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    logic [127:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22
    logic [8:0] __vul_port_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [127:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:84:1-84:52
    logic __vul_port_less; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:86:1-86:54
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [127:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] vul_port_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    logic [127:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22
    logic [8:0] vul_port_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic s8_norm_cmp_17_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:46:24-46:35; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:77:17-77:48
    logic [127:0] s8_norm_bitnot_18_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:36; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:36
    logic s8_norm_cmp_19_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25
    logic s8_norm_cmp_20_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:42; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:75:17-75:52
    logic [127:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:46
    logic [127:0] s8_norm_sub_22_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:46
    logic [127:0] s8_norm_mux_23_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:52:30-52:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:74:1-74:26
    logic [127:0] s8_norm_udivmod_25_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45
    logic [127:0] s8_norm_shift_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:55:25-55:55; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:32
    logic [127:0] s8_norm_shift_29_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:56:25-56:55; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:32
    logic [127:0] s8_norm_mux_30_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:57:24-57:53; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:76:1-76:24
    logic [127:0] s8_norm_mux_31_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:58:25-58:56; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:58:25-58:56
    logic [127:0] s8_norm_mux_32_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:59:25-59:54; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:76:1-76:24
    logic [127:0] s8_norm_bitop_33_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:60:28-60:41; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:60:28-60:41
    logic [127:0] s8_norm_bitop_34_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:61:28-61:52; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:61:28-61:52
    logic [127:0] s8_norm_bitop_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:62:26-62:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:62:26-62:49
    logic [127:0] s8_norm_bitop_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44
    logic [127:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:84:1-84:52
    logic vul_port_less; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:86:1-86:54
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19
    logic [127:0] arith_original_26; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45
    logic rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25
    logic [127:0] rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_mask = __vul_pipeline_q_mask;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_s = __vul_pipeline_q_s;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_less = __vul_port_less;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    assign vul_port_mask = __vul_port_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:22
    assign vul_port_s = __vul_port_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:20
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:84:1-84:52
    assign __vul_port_less = vul_port_less; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:86:1-86:54
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19

    assign s8_norm_cmp_17_v0 = (vul_port_s < 9'h80); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:46:24-46:35; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:77:17-77:48
    assign s8_norm_bitnot_18_v0 = (~vul_port_mask); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:36; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:36
    assign s8_norm_cmp_19_v0 = (vul_port_a < vul_port_b); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25
    assign s8_norm_cmp_20_v0 = (vul_port_d == 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:42; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:75:17-75:52
    assign s8_norm_add_21_v0 = (vul_port_a + vul_port_b); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:46
    assign s8_norm_sub_22_v0 = (vul_port_a - vul_port_b); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:46
    assign s8_norm_mux_23_v0 = (s8_norm_cmp_20_v0 ? 128'h1 : vul_port_d); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:52:30-52:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:74:1-74:26
    assign s8_norm_udivmod_25_v0 = arith_original_26; // decl: <none>; prim: <none>
    assign s8_norm_shift_27_v0 = (vul_port_s >= 9'd128 ? 128'h0 : (s8_norm_add_21_v0 << vul_port_s)); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:55:25-55:55; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:50:21-50:32
    assign s8_norm_shift_29_v0 = (vul_port_s >= 9'd128 ? 128'h0 : (s8_norm_sub_22_v0 >> vul_port_s)); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:56:25-56:55; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:51:21-51:32
    assign s8_norm_mux_30_v0 = (s8_norm_cmp_17_v0 ? s8_norm_shift_27_v0 : 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:57:24-57:53; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:76:1-76:24
    assign s8_norm_mux_31_v0 = (s8_norm_cmp_20_v0 ? vul_port_a : s8_norm_udivmod_25_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:58:25-58:56; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:58:25-58:56
    assign s8_norm_mux_32_v0 = (s8_norm_cmp_17_v0 ? s8_norm_shift_29_v0 : 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:59:25-59:54; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:76:1-76:24
    assign s8_norm_bitop_33_v0 = (s8_norm_mux_30_v0 & vul_port_mask); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:60:28-60:41; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:60:28-60:41
    assign s8_norm_bitop_34_v0 = (s8_norm_mux_32_v0 & s8_norm_bitnot_18_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:61:28-61:52; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:61:28-61:52
    assign s8_norm_bitop_35_v0 = (s8_norm_bitop_33_v0 | s8_norm_bitop_34_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:62:26-62:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:62:26-62:49
    assign s8_norm_bitop_36_v0 = (s8_norm_bitop_35_v0 ^ s8_norm_mux_31_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44
    assign vul_port_y = rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:84:1-84:52
    assign vul_port_less = rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:86:1-86:54
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign arith_original_26 = (vul_port_a % s8_norm_mux_23_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:54:29-54:45
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_8_s1 <= 1'h0;
            rtlzz_pipe_22_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_8_s1 <= s8_norm_cmp_19_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:48:20-48:25
        end
        if (vul_port_iv) begin
        rtlzz_pipe_22_s1 <= s8_norm_bitop_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:63:26-63:44
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
        end
    end
end

    logic [127:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19
    logic rdata_less__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:37:1-37:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:37:1-37:17
    logic [520:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:39:1-39:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:39:1-39:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:41:1-41:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:41:1-41:16
    logic [127:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19
    logic rdata_less; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18
    logic [128:0] s8_norm_hw_46_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:230:3-230:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:230:3-230:9
    logic [127:0] s8_norm_hw_47_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:235:22-235:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:235:22-235:34
    logic [127:0] s8_norm_hw_48_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:236:22-236:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:236:22-236:34
    logic [127:0] s8_norm_hw_49_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:237:25-237:37; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:237:25-237:37
    logic [127:0] s8_norm_hw_50_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:238:22-238:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:238:22-238:34
    logic [8:0] s8_norm_hw_51_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:239:20-239:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:239:20-239:32
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:101:3-101:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:224:3-224:26
    logic [128:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:231:3-231:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13
    logic [127:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19
    logic [127:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:172:3-172:39
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13
    logic [127:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19
    logic [127:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:179:3-179:39
    logic wen_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16
    logic [127:0] wdata_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22
    logic [127:0] resetvalue_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:186:3-186:45
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13
    logic [127:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19
    logic [127:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:65:1-65:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:193:3-193:39
    logic wen_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13
    logic [8:0] wdata_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17
    logic [8:0] resetvalue_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:71:1-71:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:200:3-200:35
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:206:3-206:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_less__ = __vul_pipeline_q_less;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:224:3-224:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:231:3-231:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:37:1-37:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:37:1-37:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:39:1-39:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:39:1-39:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:41:1-41:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:41:1-41:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:172:3-172:39
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:179:3-179:39
    assign wen_mask__ = wen_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16
    assign wdata_mask__ = wdata_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22
    assign resetvalue_mask__ = resetvalue_mask; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:186:3-186:45
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:65:1-65:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:193:3-193:39
    assign wen_s__ = wen_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13
    assign wdata_s__ = wdata_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17
    assign resetvalue_s__ = resetvalue_s; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:71:1-71:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:200:3-200:35
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:206:3-206:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:79:1-79:19
    assign rdata_less = rdata_less__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:81:1-81:20
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:83:1-83:18

    assign s8_norm_hw_46_v0 = {rdata_less, rdata_y}; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:230:3-230:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:230:3-230:9
    assign s8_norm_hw_47_v0 = push_value[127:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:235:22-235:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:235:22-235:34
    assign s8_norm_hw_48_v0 = push_value[255:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:236:22-236:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:236:22-236:34
    assign s8_norm_hw_49_v0 = push_value[383:256]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:237:25-237:37; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:237:25-237:37
    assign s8_norm_hw_50_v0 = push_value[511:384]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:238:22-238:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:238:22-238:34
    assign s8_norm_hw_51_v0 = push_value[520:512]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:239:20-239:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:239:20-239:32
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:101:3-101:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:224:3-224:26
    assign result__query = s8_norm_hw_46_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:231:3-231:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:43:1-43:13
    assign wdata_a = s8_norm_hw_47_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:45:1-45:19
    assign resetvalue_a = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:172:3-172:39
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:49:1-49:13
    assign wdata_b = s8_norm_hw_48_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:51:1-51:19
    assign resetvalue_b = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:179:3-179:39
    assign wen_mask = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:55:1-55:16
    assign wdata_mask = s8_norm_hw_49_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:57:1-57:22
    assign resetvalue_mask = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:186:3-186:45
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:61:1-61:13
    assign wdata_d = s8_norm_hw_50_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:63:1-63:19
    assign resetvalue_d = 128'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:65:1-65:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:193:3-193:39
    assign wen_s = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:67:1-67:13
    assign wdata_s = s8_norm_hw_51_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:69:1-69:17
    assign resetvalue_s = 9'h1ff; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:71:1-71:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:200:3-200:35
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:73:1-73:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:75:1-75:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/MIX_128/sim/top.logic.cpp:206:3-206:37
endmodule

